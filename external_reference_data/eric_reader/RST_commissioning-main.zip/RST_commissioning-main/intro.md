# Welcome to the Roman Research Nexus – Roman Commissioning (ROMCOM)

The Roman Research Nexus (RRN) is the cloud-based platform where users will access and analyze Roman mission data during commissioning. It brings Roman software, analysis tools, compute resources, and data products together in a single workspace that runs directly in your browser through JupyterLab.

## ROMCOM Breaking News

<div style="background-color: #fff3cd; border-left: 6px solid #ffc107; padding: 12px; border-radius: 4px; color: #000000">
  <span>⚠️</span> <b>Note:</b> Breaking news items will appear below! Newer items are displayed first.
</div><br />

- **September 12, 2026 14:00 EDT** - Please report data discrepancies on the [Outerspace DR tracker](https://outerspace.stsci.edu/spaces/RSC/pages/415108418/Science+Data+Discrepancy+Reports).
- **September 12, 2026 02:04 EDT** - Data from commissioning now available in MAST! You can [monitor CAR data status](https://outerspace.stsci.edu/spaces/RSC/pages/428053784/Commissioning+Program+Data+Status).

## Getting Started 

<img src="./images/icons/jupyter.svg" style="vertical-align: middle; width:1.5em; margin-right:0.25em;"/> [Working in JupyterLab](./docs/jupyter.md)

<img src="./images/icons/cloud_download.svg" style="vertical-align: bottom; width:1.5em; margin-right:0.25em;"/> [Managing Your Server](./docs/server.md)

<img src="./images/icons/database.svg" style="vertical-align: bottom; width:1.5em; margin-right:0.25em;"/> [Available Data](./docs/available-data.md)

<img src="./images/icons/team.svg" style="vertical-align: bottom; width:1.5em; margin-right:0.25em;"/> [Working on a Team](./docs/teams.md) - Includes information on Real Time Collaboration Servers!

<img src="./images/icons/download.svg" style="vertical-align: bottom; width:1.5em; margin-right:0.25em;"/> [Installing Extra Software](./docs/software.md)

<img src="./images/icons/lightbulb.svg" style="vertical-align: bottom; width:1.5em; margin-right:0.25em;"/> [Tips and Tricks](./docs/tipstricks.md)

<img src="./images/icons/book.svg" style="vertical-align: middle; width:1.5em; margin-right:0.25em;"/> [Roman Space Telescope Documentation Home](https://roman-docs.stsci.edu/)


## Storage and Session Behavior
Your home directory and any team directories you belong to persist across sessions and remain available even when servers are stopped. Software installed inside a running session does not persist unless saved in a custom environment located in persistent storage. More information is available on the [Installing extra software](./docs/software.md) page.  


## More Information
Additional background and reference materials are available through:
- [RDox](https://roman-docs.stsci.edu/) — Roman data products, software documentation, simulation tools, and pipeline information
- [MAST Roman pages](https://roman-docs.stsci.edu/data-handbook-home/accessing-wfi-data/the-roman-archive-in-mast) — public data releases and archive information
- [JupyterLab documentation](https://jupyterlab.readthedocs.io/en/latest/) — general guidance on using the Jupyter interface


## Support and Feedback
If you have questions or suggestions, please contact the [Roman Help Desk](https://stsci.service-now.com/roman). Feedback from Early Access users helps guide future improvements to the Nexus.

---
*Last Updated: September 2026*
