# RST_commissioning
Libraries and notebooks to support commissioning work

**MUST READ**:
* Do not use this area for any data or code which are export controlled.
* Commissioning analysis requires agreement to dataset confidentiality, which is coordinated through the PIT PIs. Follow the [embargo policy](https://outerspace.stsci.edu/spaces/RSC/pages/428050352/Roman+Space+Telescope+Commissioning+and+First+Look+Observations+Confidentiality+and+Embargo+Policy).
* Do not distribute this repo, including via readable paths on shared computer infrastructure. Access is gated by the Commissioning Team on github and RRN-ROMCOM.
* Do not commit binary or data files to the git repo. Small data tables or configurations are OK: max file size target 100k, xlsx files acceptable but discouraged in favor of ecsv or similar. Data should go in romcom S3 bucket areas using the docs/DATASET guidelines for describing those data.
* Please develop in the ROMCOM area RRN. To get access to RRN, see https://roman.science.stsci.edu/hub/login?next=%2Fhub%2F -- if you have a MyST account you can use that, otherwise there is a link to MyST.
 
This repository is a shared workspace for activity-specific analyses, reusable Python tools, configuration files, examples, and supporting documentation.

# Key documentation
* [CONTRIBUTING.md](https://github.com/RomanSpaceTelescope/RST_commissioning/blob/main/CONTRIBUTING.md) how to contribute to this repo, both for CAR-specific analysis and shared code.
* [docs/DATASET.md](https://github.com/RomanSpaceTelescope/RST_commissioning/blob/main/docs/DATASET.md) describes organization of the ROMCOM S3 bucket.

# Description of paths:
* `activities/` contains one path per CAR. Analysts can push to main for contributions here.
* `shared/` is `.py` modules for common use. Use PRs to coordinate updates here.
* `config/` is configuration files for common use. Use PRs to coordinate updates here.
* `docs/` is for documentation. 
* `scripts/` is for short scripts with common use
* `notebooks/` is `.ipynb` modules for demonstrations
* `tests/` can be used to define unit tests

# Getting set up across systems
* To be added to ROMAN-SCIENCE-COMMISSIONING@MAILLIST.STSCI.EDU (used for meeting notifications, non-CUI) or get access to the commissioning area of outerspace please write to Mario Gennaro (gennaro@stsci.edu). Jeremy Perkins (jeremy.s.perkins@nasa.gov) maintains a CUI mailing list.
* ROMCOM access in RRN: email Tyler Desjardins (desjard@stsci.edu), Gisella De Rosa (gderosa@stsci.edu), and Claire Murray (cmurray1@stsci.edu)
* MAST/OPS access (ie roman commissioning data access prior to embrago lift) contact Mario Gennaro (gennaro@stsci.edu), Gisella (gderosa@stsci.edu) and Ariel Bowers (abowers@stsci.edu). Give enough context in your request and that we know who you are, who you work with and why you should be in the whitelist.
* github commissioning and RST org access or usage questions: slack to @Eric Switzer @Tom Barclay 
* SMDC HPC access: email SSH public keys to Eric Switzer (eric.r.switzer@nasa.gov) and David Saeva (david.saeva@nasa.gov), or use the [ticket system](https://github.com/RomanSpaceTelescope/rst-smdc-onboarding) if you’re familiar.

# Data access and product management
* Cold boot: how do I get to commissioning data? The commissioning data will be available via MAST/astroquery. See [notebooks/streaming_from_mast/comm_streaming_example.ipynb](https://github.com/RomanSpaceTelescope/RST_commissioning/blob/main/notebooks/streaming_from_mast/comm_streaming_example.ipynb) At this time, there are not trial data in OPS, but this demonstrates the data path.
* When are data available: [Commissioning Program Data Status](https://outerspace.stsci.edu/spaces/RSC/pages/428053784/Commissioning+Program+Data+Status) and [RST_commissioning/scripts/astroquery_cron](https://github.com/RomanSpaceTelescope/RST_commissioning/tree/main/scripts/astroquery_cron)
* Engineering data (see notebooks for demo) are organized by [mnemonics](https://outerspace.stsci.edu/spaces/MASTDOCS/pages/428055857/Searching+with+Roman+Mnemonics) that match previous testing
* S3 policies, see [docs/DATASET.md](https://github.com/RomanSpaceTelescope/RST_commissioning/blob/main/docs/DATASET.md) for organization guidance on the ROMCOM S3 bucket. [notebooks/s3_dataset.ipynb](https://github.com/RomanSpaceTelescope/RST_commissioning/blob/main/notebooks/s3_dataset.ipynb) and [notebooks/working_with_romcom_s3/romcom_s3_tutorial.ipynb](https://github.com/RomanSpaceTelescope/RST_commissioning/blob/main/notebooks/working_with_romcom_s3/romcom_s3_tutorial.ipynb) for examples on using the S3 areas.

## SMDC data management quick-start
Prefer SMDC East-1. East2 is available but has egress for commissioning (special case use for HPC/GPU nodes)
* R/W from SMDC, read from RRN: `/mnt/smdc-rom-com-ops/rrn-ops/`
* R/W from RRN, read from SMDC: `/mnt/roman-s3-romcom/`
* R/W from SMDC, nowhere else `/mnt/roman-science-internal`

Within those paths, aiming to keep a directory structure like the commissioning git repo https://github.com/RomanSpaceTelescope/RST_commissioning with “activities” holding per-CAR analysis and a directory like science_analysis (it does not exist yet, but it would be my recommendation). 

## RRN data management quick-start
* On RRN, **Aim to use the ROMCOM s3 bucket for analysis products** rather than RRN "local" filesystems. Its URI is `s3://roman-s3-romcom` and you can navigate as `aws s3 ls s3://roman-s3-romcom`. See `docs/DATASET.md` for more information and approach for organizing work areas and metadata there. As a reminder, this bucket is for your analysis products and outputs or coordination activities, rather than the distribution site for commissioning data. 
* The RRN ROMCOM data bucket is accessible on SMDC. For security reasons, this is read-only from SMDC `/mnt/roman-s3-romcom/`, so is meant to provide a quick way to pull RRN derived data products into batch processing on SMDC. 
* The SMDC ROMCOM bucket is accessible from RRN-ROMCOM `aws s3 ls s3://smdc-rom-com-ops/rrn-ops/` (on either SMDC or RRN)  and mounted on SMDC East-1 as `/mnt/smdc-rom-com-ops/`. SMDC-ROMCOM bucket is read-only from RRN.
* Read-only flow driven by cross-institutional policy that needs TFA for write access, so cannot just be one shared mountpoint.
* Basic flow: SMDC batch analysis processes commissioning data to products on SMDC-ROMCOM -> read in RRN notebook for post-processing etc. -> outputs to RRN-ROMCOM S3.
