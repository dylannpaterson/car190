# TODO:
* Template notebook: pull data from S3, do basic operation and push to S3.
* Record which version of romancal, CRDS
* Consider adding environment.yml, requirements.txt, pyproject.toml, pytest.ini as needed
* Consider docs style_guide.md, git_quickstart.md, data_policy.md
* Consider `.github` path with pull_request_template.md and `ISSUE_TEMPLATE/` for activity_request.md, bug_report.md, shared_tool_proposal.md etc.
