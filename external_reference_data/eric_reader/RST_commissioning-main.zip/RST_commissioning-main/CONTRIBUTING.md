# Guide to contibuting to the commissioning repo 

Aims:
- Maintain a record of commissioning code
- Aggregate and maintain shared code 
- Avoid losing work on personal laptops/accounts
- Keep contribution friction low

# Data policy

**MUST READ**:
* Do not commit binary or data files to the git repo. Small data tables or configurations are OK: max file size target 100k, xlsx files acceptable but discouraged in favor of ecsv or similar. Data should go in romcom S3 bucket areas using the docs/DATASET guidelines for describing those data.
* Do not use this area for any data or code which are export controlled.
* Commissioning analysis requires agreement to dataset confidentiality, which is coordinated through the PIT PIs. Follow https://outerspace.stsci.edu/spaces/RSC/pages/428050352/Roman+Space+Telescope+Commissioning+and+First+Look+Observations+Confidentiality+and+Embargo+Policy 
 
In addition to data files, do not commit:
- Credentials
- API tokens
- Personal secrets
- Local environment directories
- Temporary scratch files
- Cache files
- Files that can be regenerated easily 

If you accidentally commit a large file, stop and ask for help. Do not keep making more commits on top of it. Large files can remain in Git history even after deletion, so they may need special cleanup.

# Types of contributions

## Commissioning activity analysis

Contents:
   - One-off notebooks, scripts, configs, figures, and notes for a specific activity.
   - Aim to move actual code content out of notebooks and into `.py` files. 
   - Maintain low friction
   - Lives under `activities/<activity-name>/`.

Create a new activity folder:
```text
activities/car-number-short-description/
```

This can include subdirectories, noting that data should not be committed to git. 

Each activity should include a `README.md` with: Purpose, main contributors, input data description, main notebooks/scripts, how to reproduce key results, notes, caveats, and known issues. The `DATASET.yaml` is described in `docs/` and is a key artifact to track data in S3. Each activity should include a `requirements.txt` file. 

### Analysis of multiple CARs

If your analysis combined several CARs but is closely related to CARs and exit criteria, please maintain it under the `activities/` path without the CAR number in the filename, so just a short description of the analysis goals. If it combined multiple CARs but is not directly related to exit criteria (more for science application), follow guidelines in the next section for science analysis.

## Science analysis/PIT work

Use `science_analysis/` for science-related analysis which is not directly related to a CAR. This area can be used by participants from PITs.

Contents:
   - One-off notebooks, scripts, configs, figures, and notes for a specific activity.
   - Aim to move actual code content out of notebooks and into `.py` files. 
   - Maintain low friction
   - Lives under `science_analysis/<analysis-name>/`.

This can include subdirectories, noting that data should not be committed to git. 

Each activity should include a `README.md` with: Purpose, main contributors, input data description, main notebooks/scripts, how to reproduce key results, notes, caveats, and known issues. The `DATASET.yaml` is described in `docs/` and is a key artifact to track data in S3. Each activity should include a `requirements.txt` file. 

## Guidelines for developing notebooks

Guidelines for notebooks:
- Use clear section headings.
- Keep imports near the top.
- Avoid hidden dependencies on previous notebook state.
- Use relative paths where possible.
- Move repeated code into an activity-local `.py` file.
- Avoid committing massive notebook outputs: general guide is to clear all cells and then commit rather than save outputs.
- Restart and run all cells before sharing final results, when practical.

Instead of putting all logic in a notebook, consider creating a helper `.py` file:
A good helper file:
- Has a clear purpose.
- Contains functions, not just top-level script code.
- Has docstrings for non-obvious behavior.
- Uses relative paths or accepts paths as function arguments.
- Does not depend on one person's home directory.
- Can be imported by a notebook.

As useful tools spin off into python files, they can move to the shared reusable tools contribution approach described below.

## Shared reusable tools

Goals:
   - Code intended to be used across activities.
   - These live under `shared/`.
   - Shared code should be reviewed more carefully, documented, and preferably tested.

Shared code should have: A clear name, docstrings, minimal hardcoded paths/magic, small example, tests as appropriate. 

If you are unsure whether code belongs in `shared/`, start with activity-local and ask later in the analysis meeting. Please use pull requests to add code to the `shared/` directory. Update the original activity notebook to import from `shared/`.

Moving code into `shared/` does not need to be perfect. It should be understandable, documented, and unlikely to break other users.

A typical path is:
1. Try something in a notebook.
2. Move repeated code into `activities/<activity>/helper.py`.
3. If another activity needs it, move it to `shared/`.
4. If it becomes important, add tests and examples.

Trigger: Consider moving code to `shared/` when:
- Two or more activities use the same function.
- People are copying the same code between notebooks.
- The code is stable enough to document.
- The input/output behavior is reasonably clear.
- The function is not tightly tied to one activity.

Shared code should generally include: Clear function names, docstrings, minimal hardcoded paths, explicit inputs and outputs, reasonable error messages; examples and tests as practical.
Shared code should not: Depend on one user's local file paths, silently read or write files in unexpected locations, require large untracked data files without documentation, break existing activity notebooks without coordination.

# Git workflow

## Hybrid policy for ease of contributions

This repo uses a hybrid policy:
* Commissioning analysts can push to main for code in their activity directory, avoiding the need for PRs
* All other material in the common areas or changes to other activities is contributed by PR (anything that affects someone else's work)

Please do not create long-lived personal branches for activity development. They tend to diverge and become hard to merge. Prefer working in `main` inside your activity folder, or use a short-lived branch for a specific shared-code change and open a PR quickly.

From github, you can directly edit files. When you save, you have the option of committing to main or starting a PR so can choose at that time.

Note that this repo overall is:
* As-is: you're likely to encounter something that does not work, especially if running specific CAR analysis. Please reach out on #commissioning-analysis to troubleshoot.
* High trust: members can push to main anywhere, but trust that contributors to shared areas use a PR to avoid interference. We will monitor and run interference. 
* Rapid development: commissioning is very dynamic and implementations and results may evolve rapidly. As results move toward final or versioned results analysis WG will coordinate on ways to tag.
* Implemented across a range of approaches: spans disciplined software engineering (through PRs, testing) to rapid trials in jupyter notebooks and direct editing on github.

## Quick start from JupyterHub

From a terminal:

```bash
git clone https://github.com/RomanSpaceTelescope/RST_commissioning
cd RST_commissioning
```

TBD, if using a specific environment:
```bash
conda env create -f environment.yml
conda activate <env-name>
```

Or, if using pip:
```bash
pip install -r requirements.txt
```

Note that `RST_commissioning` will be installed in the commissioning image and will be pulled from the most recent version. So, we will not likely use `pyproject.toml` and `pip install -e .` but will instead develop only in the live tree and use the image module for reference.

## Working on the `main` branch

Before starting work:

```bash
git pull
```

After making changes:

```bash
git status
git add <files>
git commit -m "Brief description of change"
git pull
git push
```

## Pull request workflow for shared code

Create a branch:

```bash
git checkout -b short-description-of-change
```

Make edits, commit:

```bash
git add shared/some_file.py tests/test_some_file.py
git commit -m "Add helper for reading config files"
```

Push branch:

```bash
git push -u origin short-description-of-change
```

Then open a pull request on GitHub.

After the PR is merged, return to main:

```bash
git checkout main
git pull
```

Delete the old local branch if desired:

```bash
git branch -d short-description-of-change
```
