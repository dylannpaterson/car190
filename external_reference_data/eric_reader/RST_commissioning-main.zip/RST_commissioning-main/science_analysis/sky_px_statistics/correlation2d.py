"""
2-Point Correlation Function for a 2D Boolean Array

Written by Rick Kessler with the help of Claude.
====================================================
Computes the normalised pair correlation g(r) using the Ripley DD/RR estimator:

    g(r) = DD(r) / RR(r)

where
    DD(r) = number of observed signal-signal pairs at distance r
    RR(r) = expected pairs if points were drawn randomly from the
            allowed domain (field2 if supplied, else the full array)

Performance
-----------
All pair counting uses scipy.spatial.cKDTree.  Only pairs within r_max
are examined, reducing complexity from O(N²) to O(N·k) where k is the
mean neighbour count within r_max.  This gives 50–1000× speedups on
large sparse fields compared to the brute-force distance matrix.

KD-trees are built once and reused:
  - sig_tree  : built from signal points, used for DD counting
  - ctrl_tree : built from all True positions of field2, used to draw
                spatially-correct random samples each MC repeat (sampling
                is O(1) index lookup, not a tree query)

Typical usage
-------------
    # No mask — analytic Poisson baseline
    result = two_point_correlation(field, r_max=300, dr=2.0)
    result.plot("out.png")

    # With mask — RR estimated from random points confined to field2
    result = two_point_correlation(field, field2=mask, r_max=300, dr=2.0)
    result.plot("out.png")

    # Chained
    two_point_correlation(field, field2=mask, r_max=200).plot("out.png")

Dependencies
------------
    numpy, scipy   (pip install numpy scipy)
    matplotlib     (only for .plot())
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree


# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------

@dataclass
class CorrelationResult:
    """
    Return value of two_point_correlation.

    Attributes
    ----------
    r_centers : (n_bins,) float
        Mid-point of each distance bin (pixels).
    g_r : (n_bins,) float
        Normalised pair correlation g(r) = DD/RR.
        g = 1  →  signal is spatially consistent with the control baseline.
        g > 1  →  clustering at that scale.
        g < 1  →  spatial exclusion at that scale.
    counts : (n_bins,) int64
        Raw DD pair counts (signal-signal pairs) per bin.
    dr : float
        Bin width used (pixels).
    r_max : float
        Maximum search radius used for the KD-tree query (pixels).
    masked : bool
        True when a field2 mask was supplied for the RR baseline.
    """

    r_centers: np.ndarray
    g_r:       np.ndarray
    counts:    np.ndarray
    dr:        float = 1.0
    r_max:     float = 0.0
    masked:    bool  = False

    def __iter__(self):
        """Tuple-style unpacking:  r, g, counts = result"""
        return iter((self.r_centers, self.g_r, self.counts))

    def plot(
        self,
        output_path: str | Path,
        *,
        rmax: float | None = None,
        min_counts: int = 5,
        title: str = "2-Point Pair Correlation Function",
    ) -> Path:
        """
        Plot g(r) with Poisson error bars and save to a PNG file.

        Parameters
        ----------
        output_path : destination PNG filename (e.g. "result.png")
        rmax        : clip x-axis at this distance (pixels); None = self.r_max
        min_counts  : bins with fewer DD pairs are shown greyed-out
        title       : figure title string

        Returns
        -------
        Path of the saved PNG file.

        Example
        -------
            result = two_point_correlation(field, field2=mask, r_max=200, dr=2.0)
            result.plot("output.png", rmax=150, min_counts=10)
        """
        import matplotlib.pyplot as plt
        import matplotlib.ticker as ticker

        r, g, counts = self.r_centers, self.g_r, self.counts
        output_path  = Path(output_path)

        # Poisson error bars: σ_g = g / √DD  (DD is the limiting Poisson count)
        with np.errstate(invalid="ignore", divide="ignore"):
            g_err = np.where(counts > 0, g / np.sqrt(counts), 0.0)

        r_ceil   = rmax if rmax is not None else self.r_max
        in_range = r <= r_ceil
        good     = in_range & (counts >= min_counts)
        poor     = in_range & (counts <  min_counts)

        fig, (ax_main, ax_counts) = plt.subplots(
            2, 1, figsize=(8, 6),
            gridspec_kw={"height_ratios": [3, 1], "hspace": 0.08},
            sharex=True,
        )

        if poor.any():
            ax_main.errorbar(
                r[poor], g[poor], yerr=g_err[poor],
                fmt="o", ms=3, lw=0.8, capsize=2,
                color="#AAAAAA", ecolor="#CCCCCC",
                label=f"< {min_counts} pairs (unreliable)", zorder=2,
            )
        if good.any():
            ax_main.fill_between(
                r[good], g[good] - g_err[good], g[good] + g_err[good],
                alpha=0.18, color="#2563EB",
            )
            ax_main.plot(r[good], g[good], lw=1.6, color="#2563EB", zorder=3)
            ax_main.errorbar(
                r[good], g[good], yerr=g_err[good],
                fmt="o", ms=4, lw=0, capsize=3, elinewidth=1.2,
                color="#2563EB", ecolor="#1D4ED8",
                label="g(r) ± Poisson σ", zorder=4,
            )

        baseline_label = (
            "Control baseline  g = 1  (field2 mask)"
            if self.masked else
            "Poisson baseline  g = 1"
        )
        ax_main.axhline(1.0, color="#DC2626", lw=1.2, ls="--",
                        label=baseline_label, zorder=1)
        ax_main.set_ylabel("g(r)", fontsize=12)
        ax_main.set_title(title, fontsize=13, pad=10)
        ax_main.legend(fontsize=9, framealpha=0.7)
        ax_main.yaxis.set_minor_locator(ticker.AutoMinorLocator())
        ax_main.grid(axis="y", lw=0.4, alpha=0.5)
        ax_main.set_ylim(bottom=0)
        ax_main.set_xlim(0, r_ceil)

        bar_colors = np.where(counts[in_range] >= min_counts, "#2563EB", "#AAAAAA")
        ax_counts.bar(r[in_range], counts[in_range],
                      width=self.dr * 0.85, color=bar_colors,
                      alpha=0.75, align="center")
        ax_counts.axhline(min_counts, color="#DC2626", lw=0.9, ls=":",
                          label=f"min-counts = {min_counts}")
        ax_counts.set_ylabel("pairs", fontsize=10)
        ax_counts.set_xlabel(
            f"Euclidean distance r (pixels),  bin width Δr = {self.dr}",
            fontsize=11,
        )
        ax_counts.yaxis.set_minor_locator(ticker.AutoMinorLocator())
        ax_counts.legend(fontsize=8, framealpha=0.7)

        fig.savefig(output_path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        return output_path


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _build_bins(r_max: float, dr: float) -> tuple[np.ndarray, np.ndarray, int]:
    """Return (r_bins, r_centers, n_bins) covering [0, r_max] with step dr."""
    r_bins    = np.arange(0.0, r_max + dr, dr)
    r_centers = 0.5 * (r_bins[:-1] + r_bins[1:])
    return r_bins, r_centers, len(r_centers)


def _bin_pair_distances(
    coords_i: np.ndarray,
    coords_j: np.ndarray,
    r_bins:   np.ndarray,
    n_bins:   int,
) -> np.ndarray:
    """
    Given two equal-length arrays of matched pair endpoints, compute their
    Euclidean distances and accumulate into histogram bins.

    coords_i[k] and coords_j[k] are the two endpoints of pair k.
    All pairs are counted (no upper-triangle filtering — caller controls this).
    """
    diff      = coords_i - coords_j                       # (P, 2)
    distances = np.sqrt((diff * diff).sum(axis=1))        # (P,)
    bin_idx   = np.searchsorted(r_bins, distances, side="right") - 1
    valid     = (bin_idx >= 0) & (bin_idx < n_bins)
    counts    = np.zeros(n_bins, dtype=np.int64)
    np.add.at(counts, bin_idx[valid], 1)
    return counts


def _count_DD(
    sig_coords: np.ndarray,
    sig_tree:   cKDTree,
    r_bins:     np.ndarray,
    n_bins:     int,
    r_max:      float,
) -> np.ndarray:
    """
    DD: count all unique signal-signal pairs within r_max.

    Uses cKDTree.query_pairs which returns upper-triangle (i < j) pairs
    only, so each pair is counted exactly once.  Distances are recomputed
    from coordinates (query_pairs does not return them directly).
    """
    # output_type='ndarray' avoids a Python set and is faster for large P
    pairs = sig_tree.query_pairs(r_max, output_type="ndarray")  # (P, 2)
    if len(pairs) == 0:
        return np.zeros(n_bins, dtype=np.int64)

    return _bin_pair_distances(
        sig_coords[pairs[:, 0]],
        sig_coords[pairs[:, 1]],
        r_bins, n_bins,
    )


def _count_RR_one_repeat(
    ctrl_coords: np.ndarray,
    ctrl_tree:   cKDTree,
    n_draw:      int,
    r_bins:      np.ndarray,
    n_bins:      int,
    r_max:       float,
    rng:         np.random.Generator,
) -> np.ndarray:
    """
    RR for one Monte-Carlo repeat: draw n_draw random points from
    ctrl_coords (with replacement), build a KD-tree from the sample,
    count self-pairs within r_max.

    ctrl_tree is the tree of the *full* field2 domain and is used only
    for fast nearest-neighbour snapping when ctrl_coords are integer pixel
    positions (here we sample by index, so ctrl_tree is kept for potential
    future use such as jittered sampling).
    """
    idx      = rng.integers(0, len(ctrl_coords), size=n_draw)
    rand_pts = ctrl_coords[idx].astype(np.float64)
    rand_tree = cKDTree(rand_pts)
    return _count_DD(rand_pts, rand_tree, r_bins, n_bins, r_max)


def _RR_from_field2(
    sig_coords:       np.ndarray,
    ctrl_coords:      np.ndarray,
    ctrl_tree:        cKDTree,
    r_bins:           np.ndarray,
    n_bins:           int,
    r_max:            float,
    n_rand_repeats:   int,
    rng:              np.random.Generator,
    ctrl_sample_size: int | None,
) -> np.ndarray:
    """
    Estimate RR by Monte-Carlo over field2-allowed positions.

    For each repeat:
      1. Draw n_draw points uniformly from ctrl_coords (True positions of field2).
      2. Build a KD-tree from the sample.
      3. Count self-pairs within r_max — this is one RR sample.
    Return the mean over all repeats.

    Parameters
    ----------
    ctrl_tree        : pre-built KD-tree of the full field2 domain (built once,
                       passed in so it is never rebuilt inside the loop).
    ctrl_sample_size : points drawn per repeat; None → same count as signal (n_true).
                       Smaller values are faster but give a noisier RR baseline.
    """
    n_draw      = ctrl_sample_size if ctrl_sample_size is not None else len(sig_coords)
    accumulated = np.zeros(n_bins, dtype=np.float64)

    for _ in range(n_rand_repeats):
        accumulated += _count_RR_one_repeat(
            ctrl_coords, ctrl_tree, n_draw, r_bins, n_bins, r_max, rng
        )

    return accumulated / n_rand_repeats


def _RR_analytic(
    n_true:  int,
    n_total: int,
    r_bins:  np.ndarray,
    n_bins:  int,
) -> np.ndarray:
    """
    Analytic RR for a uniform Poisson field (no field2 mask):

        RR(r) = ½ · n · ρ · π(r_hi² − r_lo²)

    where ρ = n / N_total is the mean signal density.
    """
    rho        = n_true / n_total
    shell_area = np.pi * (r_bins[1:n_bins + 1] ** 2 - r_bins[:n_bins] ** 2)
    return 0.5 * n_true * rho * shell_area


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def two_point_correlation(
    field:  np.ndarray,
    field2: np.ndarray | None = None,
    *,
    r_max:            float | None = None,
    dr:               float = 1.0,
    n_rand_repeats:   int   = 20,
    ctrl_sample_size: int | None = None,
    random_seed:      int | None = None,
    workers:          int   = -1,
) -> CorrelationResult:
    """
    Compute the 2-point pair correlation function g(r) = DD/RR.

    Uses a KD-tree to restrict pair search to within r_max, giving
    O(N·k) complexity instead of O(N²).

    Parameters
    ----------
    field : 2D bool array, shape (H, W)
        Signal field.  Only True elements are used as data points (DD).

    field2 : 2D bool array, same shape as field, optional
        Mask that defines the allowed domain for random control points (RR).
        When supplied:
          - A KD-tree is built once from all True positions of field2.
          - Each Monte-Carlo repeat draws ctrl_sample_size points from those
            positions (with replacement) and counts their self-pairs as RR.
          - This correctly accounts for any domain geometry: irregular
            boundaries, holes, non-rectangular regions, etc.
        When None (default):
          - The analytic uniform-Poisson formula is used for RR, assuming
            every pixel in the array is a valid position.

    r_max : float, optional
        Maximum search radius in pixels.  The KD-tree only examines pairs
        within this radius — set it to the largest scale you care about.
        Halving r_max reduces pair-counting work by ~4×.
        Default: half the array diagonal (conservative; usually much smaller
        values are appropriate).

    dr : float
        Bin width in pixels.  Default 1.0.

    n_rand_repeats : int
        Number of independent RR Monte-Carlo draws (field2 path only).
        More repeats → smoother RR baseline → less noise in g(r) at large r.
        Default 20.  50–100 is safer for publication-quality results.

    ctrl_sample_size : int or None
        Number of random points drawn from field2 per repeat.
        None → same count as the number of signal True elements (n_true).
        Reducing this speeds up the MC loop at the cost of a noisier RR.

    random_seed : int or None
        Seed for the Monte-Carlo RNG (field2 path only).
        None = non-deterministic.

    workers : int
        Number of threads for KD-tree queries (-1 = all available CPUs).
        Passed to cKDTree.query_pairs.  Default -1.

    Returns
    -------
    CorrelationResult
        Dataclass with attributes r_centers, g_r, counts, dr, r_max, masked
        and a .plot() method.  Supports tuple unpacking:
            r, g, counts = two_point_correlation(field)

    Raises
    ------
    ValueError
        If field is not 2-D, has fewer than 2 True elements, or field2
        has a different shape or fewer than 2 True elements.

    Examples
    --------
        # Analytic baseline, search within 200 px
        result = two_point_correlation(field, r_max=200, dr=2.0)
        result.plot("out.png")

        # Domain-masked MC baseline
        result = two_point_correlation(
            field, field2=valid_region,
            r_max=200, dr=2.0,
            n_rand_repeats=50, random_seed=42,
        )
        result.plot("out.png")

        # Chained
        two_point_correlation(field, field2=mask, r_max=200).plot("out.png")

        # Tuple unpacking (backward compatible)
        r, g, counts = two_point_correlation(field, r_max=100)
    """
    # ── validate field ────────────────────────────────────────────────────────
    field = np.asarray(field, dtype=bool)
    if field.ndim != 2:
        raise ValueError("field must be a 2-D array")
    H, W = field.shape

    sr, sc = np.where(field)
    n_true = len(sr)
    if n_true < 2:
        raise ValueError("field must have at least 2 True elements")
    sig_coords = np.stack([sr, sc], axis=1).astype(np.float64)

    # ── validate field2 & build ctrl KD-tree (built once, reused per repeat) ──
    use_mask  = field2 is not None
    ctrl_coords: np.ndarray | None = None
    ctrl_tree:   cKDTree   | None  = None

    if use_mask:
        field2 = np.asarray(field2, dtype=bool)
        if field2.shape != (H, W):
            raise ValueError(
                f"field2 shape {field2.shape} must match field shape {(H, W)}"
            )
        cr, cc = np.where(field2)
        if len(cr) < 2:
            raise ValueError("field2 must have at least 2 True elements")
        ctrl_coords = np.stack([cr, cc], axis=1).astype(np.float64)
        ctrl_tree   = cKDTree(ctrl_coords)   # built once; reused across MC repeats

    # ── r_max & distance bins ─────────────────────────────────────────────────
    if r_max is None:
        r_max = 0.5 * np.hypot(H, W)
    r_bins, r_centers, n_bins = _build_bins(r_max, dr)

    # ── signal KD-tree (built once for DD counting) ───────────────────────────
    sig_tree = cKDTree(sig_coords)

    # ── DD: observed signal-signal pair counts ────────────────────────────────
    DD = _count_DD(sig_coords, sig_tree, r_bins, n_bins, r_max)

    # ── RR: expected baseline ─────────────────────────────────────────────────
    if use_mask:
        rng = np.random.default_rng(random_seed)
        RR  = _RR_from_field2(
            sig_coords, ctrl_coords, ctrl_tree,
            r_bins, n_bins, r_max,
            n_rand_repeats, rng, ctrl_sample_size,
        )
    else:
        RR = _RR_analytic(n_true, H * W, r_bins, n_bins)

    # ── g(r) = DD / RR ────────────────────────────────────────────────────────
    with np.errstate(invalid="ignore", divide="ignore"):
        g_r = np.where(RR > 0, DD / RR, 0.0)

    return CorrelationResult(
        r_centers, g_r, DD, dr=dr, r_max=r_max, masked=use_mask
    )


# ---------------------------------------------------------------------------
# Demo + sanity checks
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import time

    rng = np.random.default_rng(42)
    H, W = 600, 600

    # ── clustered signal field ───────────────────────────────────────────────
    field = np.zeros((H, W), dtype=bool)
    for _ in range(40):
        cx, cy = rng.integers(30, H - 30), rng.integers(30, W - 30)
        for _ in range(40):
            dx, dy = rng.normal(0, 6, size=2).astype(int)
            field[np.clip(cx + dx, 0, H - 1), np.clip(cy + dy, 0, W - 1)] = True

    n_sig = int(field.sum())
    print(f"Field {H}×{W},  {n_sig:,} signal True elements  "
          f"({100 * n_sig / H / W:.2f}%)")

    # ── circular mask for field2 ─────────────────────────────────────────────
    yy, xx = np.ogrid[:H, :W]
    field2  = ((xx - W // 2) ** 2 + (yy - H // 2) ** 2) <= (240 ** 2)
    n_ctrl  = int(field2.sum())
    print(f"field2 circular mask: {n_ctrl:,} allowed positions  "
          f"({100 * n_ctrl / H / W:.1f}% of array)\n")

    # ── no mask, analytic RR ─────────────────────────────────────────────────
    t0 = time.perf_counter()
    res = two_point_correlation(field, r_max=180, dr=2.0)
    print(f"No mask   r_max=180  {time.perf_counter()-t0:.3f}s  "
          f"DD total={res.counts.sum():,}")
    res.plot(
        "/mnt/user-data/outputs/correlation2d_demo.png",
        title="g(r) — KD-tree, analytic Poisson baseline",
    )

    # ── with field2 mask, MC RR ──────────────────────────────────────────────
    t0 = time.perf_counter()
    res_m = two_point_correlation(
        field, field2=field2,
        r_max=180, dr=2.0,
        n_rand_repeats=30, random_seed=0,
    )
    print(f"Masked    r_max=180  {time.perf_counter()-t0:.3f}s  "
          f"DD total={res_m.counts.sum():,}  (same DD, different RR)")
    res_m.plot(
        "/mnt/user-data/outputs/correlation2d_demo_masked.png",
        title="g(r) — KD-tree, field2 circular-mask MC baseline",
    )

    # ── sanity: Poisson signal → g(r) ≈ 1, no mask ──────────────────────────
    f_rand = rng.random((H, W)) < 0.08
    r1 = two_point_correlation(f_rand, r_max=100, dr=2.0)
    print(f"\nSanity — random field, no mask:      "
          f"g mean bins[2:20] = {r1.g_r[2:20].mean():.4f}  (expect ≈ 1)")

    # ── sanity: Poisson signal inside mask → g(r) ≈ 1, with mask ───────────
    f_rand_m = f_rand & field2
    r2 = two_point_correlation(
        f_rand_m, field2=field2,
        r_max=100, dr=2.0, n_rand_repeats=40, random_seed=7,
    )
    print(f"Sanity — random field, field2 mask:  "
          f"g mean bins[2:20] = {r2.g_r[2:20].mean():.4f}  (expect ≈ 1)")

    # ── tuple unpacking backward-compat ─────────────────────────────────────
    r, g, counts = two_point_correlation(field, r_max=50, dr=1.0)
    assert len(r) == len(g) == len(counts)
    print("\nTuple unpacking: OK")
    print("Saved: correlation2d_demo.png, correlation2d_demo_masked.png")
