### test_sky_background_uniformity.py
This test examines the sky/background uniformity of images. The test 
detects sources, masks the detections, and fits a Gaussian to the 
background pixel values. It also does a 2pt correlation on the pixel
values of the background images.

Written for Roman commissioning.

### History
Sep 17 2026: R. Kessler minor refactor and add call to blank 
              analyze_2ptcor; added args.cutoutsize (default=4088)
              and args.nsigma_2ptcor (default=None)

Sep 18 2026: L. Aldoroty minor refactor, version bump +0.1.1

Sep 21 2026: L. Aldoroty add variance stats to output of plot,
             bugfix plot save locations. Version bump +0.0.1
             to 0.1.2.


### Usage
```
python test_sky_background_uniformity.py [path1] [path2] ...
```
Optional flags:
--include-sources will not mask out sources.
--fig-subdir changes the default subdirectory where figures are saved.
--nsigma-2ptcor is list of nsigma to select pixels for 2pt corr.

Example:
```
python test_sky_background_uniformity.py asdfimage.asdf \
--nsigma-2ptcor -4 -3 -2.5 2.5 3 4
```
