#!/usr/bin/env python

"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
This test examines the sky/background uniformity of images. The test 
detects sources, masks the detections, and fits a Gaussian to the 
background pixel values. It also does a 2pt correlation on the pixel
values of the background images.

Written for Roman commissioning.

         HISTORY

 Sep 17 2026: R. Kessler minor refactor and add call to blank 
              analyze_2ptcor; added args.cutoutsize (default=4088)
              and args.nsigma_2ptcor (default=None)

Sep 18 2026: L. Aldoroty minor refactor, version bump +0.1.1

Sep 21 2026: L. Aldoroty add variance stats to output of plot,
             bugfix plot save locations. Version bump +0.0.1
             to 0.1.2.

Sep 22 2026: L. Aldoroty add percent masked to output of plot

********************************************************************
USAGE:

python test_sky_background_uniformity.py [path1] [path2] ...

Optional flags:
--include-sources will not mask out sources.
--fig-subdir changes the default subdirectory where figures are saved.
--nsigma-2ptcor is list of nsigma to select pixels for 2pt corr.

EXAMPLE:

python test_sky_background_uniformity.py asdfimage.asdf \
--nsigma-2ptcor -4 -3 -2.5 2.5 3 4
********************************************************************
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

__author__ = 'Lauren Aldoroty, UMBC/NASA GSFC'
__version__ = '0.1.2'
__date__ = '2026-09-16'

import os, sys, argparse, logging
import numpy as np
import asdf
import roman_datamodels as rdm
from astropy.stats import SigmaClip, sigma_clipped_stats
from astropy.convolution import convolve
from astropy.visualization import ZScaleInterval
from lmfit.models import GaussianModel
from photutils.utils import CutoutImage
from photutils.segmentation import detect_sources, detect_threshold, make_2dgaussian_kernel
from scipy.stats import median_abs_deviation
import matplotlib.pyplot as plt

from correlation2d import two_point_correlation


# ======================================================
# hard-wired parameters

CUTOUTSIZE_DEFAULT   = 4088
SUBDIR_FIGS_DEFAULT  = "background"

# ======================================================
def mk_arrays(path, cutoutsize, include_sources=False):
    """
    AUTHOR: Lauren Aldoroty

    Prepare your image mask arrays.
    """

    af  = asdf.open(path)
    img = rdm.open(af).copy().data
    af  = asdf.open(path) # If I don't do this again, it says "OSError: Cannot access data
                          # from closed ASDF file." I don't understand it, but duplicating
                          # this line fixes it.
    # Also, exclude known bad pixels. Make a DQ mask.
    dq_array = rdm.open(af).copy().dq
    bad_mask = np.isnan(img) | (dq_array > 0) # Good pixels are False, bad are True.
    center_coord = np.floor(np.shape(img)[0]/2)
    cutout = CutoutImage( img,
                          (center_coord, center_coord),
                          (cutoutsize, cutoutsize)
                        )
    # And also of the DQ mask.
    cutout_dq = CutoutImage( bad_mask,
                            (center_coord, center_coord),
                            (cutoutsize, cutoutsize)
                           )

    if not include_sources:
      # Mask out sources in addition to poor-quality pixels.
      # For the purposes of making the detection mask, convolve the image with a Gaussian kernel.
      kernel = make_2dgaussian_kernel(3.0, size=5)
      convolved_data = convolve(cutout.data, kernel)
      sigclip = SigmaClip(sigma=3.0, maxiters=10)

      # Detect threshold and sources.
      threshold = detect_threshold(convolved_data, n_sigma=2.0, sigma_clip=sigclip)
      segmap = detect_sources(convolved_data, threshold, n_pixels=5)
      mask = segmap.make_source_mask(size=5)

      # Join the provided DQ mask with the source mask. Also, invert the booleans so that now
      # the sources (which will be masked) are marked as False.
      final_mask = np.logical_not(np.logical_or(mask, cutout_dq.data)) 
    else:
      # Only mask out the poor-quality pixels.
      final_mask = np.logical_not(cutout_dq.data)

    return cutout.data, final_mask

def fit_gaussian_and_plot(args, img, mask, path, cutoutsize):
    """
    AUTHOR: Lauren Aldoroty

    Fit a Gaussian to the unmasked pixels and plot results.
    """

    # First, make a 1D array of the background pixels.
    masked_data = img[mask] 

    # This next part is just for plotting so that the masked pixels aren't assigned
    # a value in the color map. 
    plot_mask = mask.astype(float)
    idx = np.where(mask == 0)
    plot_mask[idx] = np.nan
    npix_unmasked = np.count_nonzero(mask)
    npix_tot = cutoutsize ** 2
    masked_frac = (npix_tot - npix_unmasked)/npix_tot
    logging.info(f"Total pixels = {npix_tot}")
    logging.info(f"Masked pixels = {npix_tot - npix_unmasked}")
    logging.info(f"Masked fraction = {masked_frac}")

    # Get plotting.
    fig, ax = plt.subplots(2,2, figsize=(10,10))
    plt.subplots_adjust(wspace=.4)
    cmap = 'viridis'

    # Plot the original image.
    vmin, vmax = ZScaleInterval().get_limits(img)
    imgax = ax[0,0].imshow(img, vmin=vmin, vmax=vmax, cmap=cmap)
    plt.colorbar(imgax, ax=ax[0,0], fraction=0.046, pad=0.04)
    ax[0,0].set_title('Original image')

    # Plot the mask.
    maskax = ax[0,1].imshow(plot_mask, cmap=cmap)
    plt.colorbar(maskax, ax=ax[0,1], fraction=0.046, pad=0.04)
    ax[0,1].set_title('Mask (values are 1 or NaN)')

    # Plot the original image with the mask applied.
    vmin, vmax = ZScaleInterval().get_limits(img * plot_mask)
    maskedax = ax[1,0].imshow(img * plot_mask, vmin=vmin, vmax=vmax, cmap=cmap)
    plt.colorbar(maskedax, ax=ax[1,0], fraction=0.046, pad=0.04)
    ax[1,0].set_title('Mask applied to original')

    # Plot histogram. 
    _, median, std = sigma_clipped_stats(img, sigma=3.0, mask=mask)
    bins = np.arange(median-(7*std), median+(7*std), std/4)
    counts, hbins, bars = plt.hist(masked_data, bins=bins, color='mediumpurple')

    # Fit Gaussian.
    gaussian = GaussianModel()
    hist, bin_edges = np.histogram(masked_data, bins=bins)
    bincenters = [(bin_edges[i] + bin_edges[i+1])/2 for i in range(len(hist))]
    pars = gaussian.make_params(center=0.7, amplitude=1e6, sigma=1.2)
    res  = gaussian.fit(hist, pars, x=bincenters)
    mad = median_abs_deviation(masked_data)
    logging.info(f"{res.fit_report()}")

    # Plot Gaussian.
    ax[1,1].plot(bincenters, res.best_fit, label='Gaussian fit', color='k', lw=3)
    title_str = rf'$\mu =$ {np.round(res.params['center'].value, 3)}'
    title_str += '\n'
    title_str += rf'$\sigma_{{fit}} =$ {np.round(res.params['sigma'].value, 3)}'
    title_str += '\n'
    title_str += rf'$\chi^{{2}}_{{DOF}} =$ {np.round(res.redchi, 3)}'
    ax[1,1].set_title(title_str)

    mad_sq = str(np.round(mad**2, 5))
    var = str(np.round(np.std(masked_data)**2, 5))
    fit_var = str(np.round(res.params['sigma'].value**2, 5))
    masked_frac_str = str(np.round(masked_frac, 2) * 100)

    ax[1,1].annotate(rf'$\sigma_{{MAD}}^{{2}} = {mad_sq}$', xy=(0.05,0.94), xycoords='axes fraction')
    ax[1,1].annotate(rf'$\sigma^{{2}} = {var}$', xy=(0.05,0.88), xycoords='axes fraction')
    ax[1,1].annotate(rf'$\sigma^{{2}}_{{fit}} = {fit_var}$', xy=(0.05,0.82), xycoords='axes fraction')
    ax[1,1].annotate(f'{masked_frac_str}% masked', xy=(0.65, 0.86), xycoords='axes fraction')

    ax[1,1].set_xlabel('Background pixel value')
    ax[1,1].set_ylabel(r'$N$')
    ax[1,1].set_yscale('log')
    ax[1,1].legend()
    ax[1,1].set_ylim(bottom=.1)

    # Plotting housekeeping.
    title    = os.path.basename(path).split('.')[0]
    png_file = get_png_name(f'figs/{args.fig_subdir}/bkg_uniformity_test/bkg_uniformity_test', path)

    plt.suptitle(title, y=0.9)
    plt.savefig(png_file, bbox_inches='tight', dpi=300)
    plt.close()

    return res

def get_png_name(prefix, path_asdf):
    """
    AUTHOR: Rick Kessler

    """
    path_base = os.path.basename(path_asdf)
    name      = prefix + '_' + path_base.split('.')[0] + '.png'
    return name
    
def analyze_sky(args, path):
    """
    AUTHOR: Rick Kessler

    """
    include_sources = args.include_sources
    cutoutsize      = args.cutoutsize
    
    logging.info(f"# =============================================== ")    
    logging.info(f" Analyze sky bkg for {path}; include_sources = {include_sources}")
    
    img, mask = mk_arrays(path, cutoutsize, include_sources=include_sources)
    result_gauss_fit = fit_gaussian_and_plot(args, img, mask, path, cutoutsize)

    return img, mask, result_gauss_fit

def analyze_2ptcor(nsigma, path, img, mask_sky, result_gauss_fit):
    """
    AUTHOR: Rick Kessler

    """
    logging.info(f"# =============================================== ")
    logging.info(f" Analyze 2pt correlation for {path} and {nsigma} sigma outliers")

    mean  = result_gauss_fit.params['center'].value
    sigma = result_gauss_fit.params['sigma'].value
    logging.info(f"  Gauss mean={mean:.4f}   sigma={sigma:.4f}")

    if nsigma > 0:
        mask_outlier = img > (nsigma*sigma + mean)
    else:
        mask_outlier = img < (nsigma*sigma + mean)
        
    mask_final   = np.logical_and(mask_outlier, mask_sky)

    npix_sky     = np.count_nonzero(mask_sky)
    npix_outlier = np.count_nonzero(mask_outlier)
    npix_final   = np.count_nonzero(mask_final)

    logging.info(f"  npix[sky / outlier / final] = {npix_sky} / {npix_outlier} / {npix_final}")

    # - - - - - - - - - - - - - -
    DO_RANDOM_TEST = 0 # debug flag to pick random pixels to get g(r) = 1 everywhere
    if DO_RANDOM_TEST:
        true_indices    = np.argwhere(mask_sky)
        n_sample        = npix_final
        logging.info(f" DO_RANDOM_TEST with n_sample = {n_sample}")
        sampled_indices = true_indices[np.random.choice(len(true_indices), size=n_sample, replace=False)]
        mask_final      = np.zeros_like(mask_sky)
        mask_final[sampled_indices[:, 0], sampled_indices[:, 1]] = True
        npix_final      = np.count_nonzero(mask_final)
        logging.info(f" DO_RANDOM_TEST with npix_final = {npix_final}")
    # - - - - - - - - - - - - - -
    
    string_nsigma = f"{nsigma:+.1f}"  # show explicit + or - sign
    png_prefix    = f"figs/{args.fig_subdir}/bkg_2ptcor/bkg_2ptcor_nsigma{string_nsigma}"
    png_file      = get_png_name(png_prefix, path)
    plot_title    = os.path.basename(path)
    plot_title   += '\n'
    plot_title   += f"2-pt pixel correlation with Nsigma = {string_nsigma}"    

    # perform the 2pt correlation computation
    result = two_point_correlation(mask_final, field2=mask_sky, r_max=100, dr=1.0)

    # make plots
    logging.info(f" write 2pt-cor plots to {png_file}")
    result.plot(png_file, title = plot_title)

    return

# ============================
def setup_logging():
    # RK: setup super-simple logger
    # [Lauren: hopefully you will thank me later for this]    
    logging.basicConfig(level=logging.INFO,
                        format="[%(levelname)6s] %(message)s")
    return

def parse_args():
    # Created by RK 
    parser = argparse.ArgumentParser()

    parser.add_argument('--include-sources', action='store_true',
                         help='If included, do not mask out background sources.')

    parser.add_argument('--nsigma-2ptcor', type=float, default=[], nargs='+',
                         help='nsigma outlier list to select pixels for 2pt corr')

    parser.add_argument('--cutoutsize', type=int, default=CUTOUTSIZE_DEFAULT,
                         help='reduce cut-out size for faster debug; ' \
                         f'otherwise use default = {CUTOUTSIZE_DEFAULT}')

    parser.add_argument('--fig-subdir', type=str, default=SUBDIR_FIGS_DEFAULT,
                         help=f'output subdir for figures (default={SUBDIR_FIGS_DEFAULT} ')
    
    parser.add_argument('paths', nargs='+',
                         help='Paths to the asdf files to test.')

    args = parser.parse_args()    
    return args


# ================================================
if __name__ == '__main__':

    setup_logging()
    args = parse_args()

    # create output subdir; do not clobber existing subdir
    os.makedirs(f'figs/{args.fig_subdir}/bkg_uniformity_test', exist_ok=True)
    os.makedirs(f'figs/{args.fig_subdir}/bkg_2ptcor', exist_ok=True)

    # loop over user-input asdf images
    for path in args.paths:

        # analyze sky background with Gaussian fit
        img, mask, result_gauss_fit = analyze_sky(args, path)

        # evaluate 2pt correlation function per nsigma outlier fraction
        for nsigma in args.nsigma_2ptcor:
            analyze_2ptcor(nsigma, path, img, mask, result_gauss_fit)

    logging.info("")
    logging.info("Done.")
    
    # === END: =====
