# Gaia WCS correction for Roman WFI L2 frames

**Purpose.** The `*_cal.asdf` gwcs delivered for several early commissioning
imaging programs (CAR-196, CAR-910) is offset from Gaia DR3 by about three arcminutes on
every detector and exposure, with per-detector scale errors of ~0.5
percent and rotations of ~0.2 degrees, although `meta.wcs_fit_results`
reports `status: SUCCESS` at sub-pixel rms.

**`gaia_wcs_correction.py` measures the error and writes a corrected WCS, as a
TAN-SIP FITS header and, optionally, as a corrected gwcs in ASDF**. It also has
options to plot the productsand what the correction did.

`scripts/affine_alignment_to_Gaia/match_roman_gaia.py` (D. Rubin) measures the
same offsets and has a more defensive matcher. This tool has three differences:
(1) it writes a WCS; (2) it fits the correction in the telescope (V2, V3)
frame; and (3) it offer a few visualizations to clarify the two-step lock and
the residuals across all 18 SCAs.

Writing a corrected WCS was a major requirement for MSOS photometry, which was
the origin of why I developed this routine.

**Contributors.** MSOS team (IPAC), L. Bouma.

**GAI Acknowledgement.** Drafted with Claude (IPAC license) under the direction
of L. Bouma.

![WFI04 cutout with the corrected WCS](wfi04_cutout_corrected_wcs.png)

*400 x 400 px of program 1054 F146, visit 18 exposure 2, WFI04, with the
brightest Gaia stars circled at their corrected positions. The inset
shows where the delivered WCS put this field: 174 arcsec away.*

## Method

1. **Reference stars.** Gaia DR3 (`gaiadr3.gaia_source`, G < 20, proper
   motions required) in a cone covering the frames, fetched from the
   ESA archive with the standard library (asynchronous TAP, CSV) and
   cached next to the products; a cached cone that contains the request
   is reused, so the dithers of a field share one download. Positions
   are propagated linearly to the exposure mid-time. Stars are ranked
   by RP (G where RP is missing). Alternatively `--ref-file` reads a
   local catalogue (default columns: the MSOS `rdpmx.out`, which is calculated
   elsewhere).

2. **Detection.** Local maxima above `--peak-floor` (20 DN/s) in a
   9 x 9 px window, brightest first. Integer pixels: no centroiding.

3. **Translation.** FFT cross-correlation, on a 4 px grid over +/-6000
   px, of the 4000 brightest peaks against the 2000 brightest reference
   stars the delivered gwcs puts within the search box; accepted above
   8 sigma. The peak is then refined on a histogram of nearest-neighbour
   residuals, because the correlation peak can land a few bins off on
   sparse detectors while the scale error spreads the true residuals
   over ~16 px.

4. **Affine in V2V3.** The 5000 brightest reference stars on the
   detector are matched to the 10000 brightest peaks with radii
   8, 4, 2, 1.5, 1 px; at each radius a 2 x 2 matrix plus translation is
   fitted by least squares with 3 x median clipping, *between the
   detected positions mapped through the delivered detector -> V2V3
   transform and the reference positions mapped through the inverse of
   V2V3 -> world*. The affine is inserted after the detector -> V2V3
   step of the gwcs pipeline, so the delivered distortion model is kept
   and evaluated where the stars really are.

5. **Export and checks.** `to_fits_sip` at degree 5, forward and inverse,
   1e-3 px; a 25 x 25 grid round trip through the header; the largest
   median residual over 3 x 3 detector cells (`--max-grid-resid`, 0.75
   px). The header carries `WCS*` cards (offset, scales, rotation,
   star count, rms, correlation significance, SIP and grid residuals,
   reference catalogue) so a fleet of frames can be censused.

**Why V2V3 and not pixel space.** With a truth gwcs built as the delivered gwcs
plus a pure V2V3 translation worth 1900 px, a six-parameter pixel-space affine
fitted to nominal-prediction vs observed positions over one SCA leaves a median
0.45 px, 95th percentile 1.7 px systematic field, because the distortion
polynomial is then evaluated 1900 px off the detector. For a 5 px pointing
error the same fit is exact to 0.005 px. `test_gaia_wcs_correction.py`
reproduces this on a synthetic gwcs.

## Results on commissioning frames

All 18 detectors of each exposure aligned with the default constants;
about 4 s per detector after the catalogue download.

| exposure | offset | scale error | rotation | stars | rms per axis | max cell median |
|---|---|---|---|---|---|---|
| 1054 F146, GC tile, v018 e2 | 165-181" | 0.07-0.23 % | to 0.15 deg | 460-1297 | 0.38-0.40 px | 0.23 px |
| 1054 F146, bulge tile 3, v015 e2 | 165-176" | 0.07-0.21 % | to 0.16 deg | 1391-3217 | 0.43-0.46 px | 0.19 px |
| 1047 F146, LMC, v010 e1 | 192-207" | 0.08-0.49 % | to 0.17 deg | 234-3553 | 0.45-0.49 px | 0.37 px |


## Usage

```sh
pip install -r requirements.txt
# one exposure, all detectors, Gaia from the archive (cached in the output dir)
python gaia_wcs_correction.py /path/to/r0105401002001001018_0002_wfi*_f146_cal.asdf \
    --output-dir gaia_wcs_v018e2 --jobs 6
# one detector, a local reference catalogue, the animation and the ASDF gwcs
python gaia_wcs_correction.py FRAME_cal.asdf --ref-file rdpmx.out \
    --ref-cols 2 3 34 5 6 --ref-epoch 2016.0 --animate --write-asdf
python gaia_wcs_correction.py --help          # every constant, with units and defaults
python -m unittest -v test_gaia_wcs_correction.py   # offline, ~2 s
```

Products per frame (`<stem>` = the input name without `_cal.asdf`):

| file | contents |
|---|---|
| `<stem>_gaiawcs.fits` | header-only FITS: TAN-SIP WCS (CD form, A/B and AP/BP degree 5) plus the `WCS*` provenance cards |
| `<stem>_gaiawcs.asdf` | the corrected gwcs object (`--write-asdf`); drop it into `roman.meta.wcs` |
| `<stem>_matches.ecsv` | matched stars: Gaia id, sky position at the exposure epoch, 0-based observed / nominal / corrected pixels, residuals |
| `<stem>_summary.json` | the solution, checks, settings, package versions |
| `<stem>_steps.png` | nominal offset, after the translation, after the affine |
| `<stem>_cutout.png` | image cutout with the brightest Gaia stars at their corrected positions (`--cutout-size/-x/-y`) |
| `<stem>_lock.gif`, `.mp4` | the two steps animated (`--animate`; MP4 needs ffmpeg) |
| `<exposure>_focalplane_translation.png`, `_affine.png` | residual arrows of every solved detector laid out on the focal plane |
| `<exposure>_summary.ecsv` | one row per detector |

Pixel positions in the tables are 0-based (gwcs convention); the FITS
header follows the FITS convention. To apply the header to a frame in
romancal terms, load `<stem>_gaiawcs.asdf` and assign its `wcs` to
`meta.wcs`; to use it with FITS tools, copy the cards of
`<stem>_gaiawcs.fits` into the image header.

## Input data

Program 1047 (CAR-166) and 1054 (CAR-910) F146 `*_cal.asdf` frames from
MAST, as delivered in 2026 September. Nothing here is specific to F146
or to those programs; the constants are counts of the brightest stars
and peaks rather than magnitude windows, so they adapt to the field.
No data are committed; the figure above is the only image.

## Caveats and possible improvements

- **Sub-pixel centroids** would take the per-star rms from ~0.45 to
  ~0.35 px (a ~20 percent gain) at the cost of a slower detection step;
  `match_roman_gaia.py` has such a centroid. The affine itself already
  averages the quantisation down, so the header is not limited by it.

- **The translation search** takes the single correlation peak and
  refines it; `match_roman_gaia.py`'s all-pairs voting with ranked
  candidates, an explicit ambiguity rejection and cross-detector
  seeding is more defensive. Here a failing detector fails alone (it is
  listed in `errors.json`) and the others are unaffected.

- **Parallax** is not modelled; proper motions are propagated linearly.

- **Reference band.** Gaia RP ranks the stars; in the reddened bulge
  Gaia is incomplete past F146 ~ 17, and the affine relies on the
  brighter half of the detected stars. Use `--mag-min/--mag-max` to
  restrict the window, or a local catalogue with predicted Roman
  magnitudes (`--ref-file`).

- **Frames only in ASDF.** The V2V3 insertion needs the gwcs pipeline,
  so FITS inputs are not read.

- The commissioning frames are embargoed; the numbers above and the
  figure are shared within this access-controlled repository only.
