#!/usr/bin/env python3
"""Correct the WCS of Roman WFI L2 frames by aligning them to Gaia.

The delivered ``*_cal.asdf`` gwcs of the early commissioning programs is
offset from Gaia by up to a few arcminutes, with per-detector scale and
rotation errors, although ``meta.wcs_fit_results`` reports success.  This
tool measures the error against Gaia DR3 and writes a corrected WCS:

  1. Gaia stars (cone query on the archive, cached; or a local reference
     file) are propagated to the exposure epoch and projected through the
     frame's gwcs to predicted pixel positions.
  2. Stars are detected on the image as local maxima and a large blind
     translation is recovered by FFT cross-correlation of the predicted
     and detected positions, then refined on a residual histogram.
  3. A 2x2 matrix plus translation is fitted between the detected stars
     and the reference stars with shrinking match radii and sigma
     clipping.  The fit is made in the telescope (V2, V3) frame and the
     affine is inserted after the detector -> V2V3 step of the gwcs
     pipeline, so the delivered distortion model is kept and evaluated
     where the stars really are.  A pixel-space affine cannot represent
     an attitude error of ~1900 px to better than ~0.5 px.
  4. The corrected gwcs is exported as a TAN-SIP FITS header (forward and
     inverse polynomials) and checked on a grid; residual structure is
     checked on 3x3 detector cells.

Products per frame (``<stem>`` is the input name without ``_cal.asdf``):
  <stem>_gaiawcs.fits     TAN-SIP header with WCS* provenance cards
  <stem>_gaiawcs.asdf     the corrected gwcs object (--write-asdf)
  <stem>_matches.ecsv     matched stars, 0-based pixel positions
  <stem>_summary.json     solution, checks, settings, provenance
  <stem>_steps.png        nominal offset / after translation / after affine
  <stem>_cutout.png       image cutout with the brightest Gaia stars
                          at their corrected positions
  <stem>_lock.gif/.mp4    the two steps animated (--animate)
Per exposure, when several detectors are solved:
  <exposure>_focalplane_translation.png, <exposure>_focalplane_affine.png
  <exposure>_summary.ecsv

Only numpy, scipy, astropy, asdf, gwcs and matplotlib are required; the
Gaia archive is reached with the standard library.  Pixel positions in
the products are 0-based (gwcs convention); the FITS header follows the
FITS convention.

Example:
  python gaia_wcs_correction.py /path/to/r0105401002001001018_0002_*_cal.asdf
      --output-dir gaia_wcs_v018e2
  python gaia_wcs_correction.py FRAME.asdf --ref-file rdpmx.out
      --ref-cols 2 3 34 5 6 --ref-epoch 2016.0
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import time
import urllib.parse
import urllib.request
import warnings
from dataclasses import asdict, dataclass, field, replace
from importlib.metadata import PackageNotFoundError, version
from multiprocessing import get_context
from pathlib import Path
from typing import Optional, get_type_hints

import numpy as np
import asdf
from astropy.io import fits
from astropy.table import Table
from astropy.time import Time
from astropy.wcs import WCS
from astropy.modeling.models import AffineTransformation2D
from gwcs import WCS as GWCS
from scipy.ndimage import maximum_filter
from scipy.signal import fftconvolve
from scipy.spatial import cKDTree

import matplotlib
matplotlib.use("Agg")
try:  # house style where available; the default style otherwise
    from aesthetic.plot import set_style
    set_style("science")
except ImportError:
    pass
import matplotlib.pyplot as plt  # noqa: E402

__version__ = "1.0"

GAIA_TAP = "https://gea.esac.esa.int/tap-server/tap"
GAIA_TABLE = "gaiadr3.gaia_source"
# The WFI focal-plane axes are rotated by this angle from (V2, V3); used
# only to lay out the per-detector panels of the focal-plane figure.
FPA_ANGLE_DEG = 60.0
DEPENDENCIES = ("numpy", "scipy", "astropy", "asdf", "gwcs", "matplotlib")


class AlignError(RuntimeError):
    """The alignment of one frame failed a check."""


# ---------------------------------------------------------------------------
# settings
# ---------------------------------------------------------------------------
def _opt(default, help_text: str):
    return field(default=default, metadata={"help": help_text})


@dataclass(frozen=True)
class Settings:
    """Every algorithm constant, exposed on the command line."""

    g_limit: float = _opt(20.0, "Gaia G faint limit of the archive query "
                                "(mag)")
    field_padding: float = _opt(0.16, "query cone padding beyond the "
                                      "detector centres (deg)")
    rank_band: str = _opt("rp", "Gaia band ranking the reference stars: "
                                "rp (falls back to G where RP is missing) "
                                "or g")
    mag_min: float = _opt(0.0, "bright limit on the ranking magnitude of "
                               "the reference stars used (mag)")
    mag_max: float = _opt(99.0, "faint limit on the ranking magnitude of "
                                "the reference stars used (mag)")
    peak_size: int = _opt(9, "side of the local-maximum window of the "
                             "star detection (px)")
    peak_floor: float = _opt(20.0, "minimum value of a detected peak "
                                   "(image units, DN/s)")
    n_xcorr_ref: int = _opt(2000, "brightest reference stars in the "
                                  "search box used in the "
                                  "cross-correlation")
    n_xcorr_peaks: int = _opt(4000, "brightest image peaks used in the "
                                    "cross-correlation")
    xcorr_bin: float = _opt(4.0, "cross-correlation grid step (px)")
    xcorr_half: float = _opt(6000.0, "half-width of the translation "
                                     "search (px)")
    xcorr_min_sigma: float = _opt(8.0, "minimum significance of the "
                                       "cross-correlation peak")
    refine_window: float = _opt(24.0, "half-width of the residual "
                                      "histogram refining the translation "
                                      "(px)")
    refine_bin: float = _opt(4.0, "bin of that histogram (px)")
    n_fit_ref: int = _opt(5000, "brightest on-detector reference stars "
                                "used in the affine fit")
    n_fit_peaks: int = _opt(10000, "brightest image peaks the reference "
                                   "stars are matched to")
    match_radii: str = _opt("8,4,2,1.5,1", "successive match radii of "
                                           "the affine fit (px, "
                                           "comma-separated)")
    clip_iterations: int = _opt(4, "sigma-clipping iterations per fit")
    edge: float = _opt(10.0, "detector border excluded from the fit (px)")
    min_matches: int = _opt(80, "minimum stars in the final fit")
    max_rms: float = _opt(1.5, "maximum per-axis rms of the final fit "
                               "(px)")
    max_grid_resid: float = _opt(0.75, "maximum |median residual| over "
                                       "3x3 detector cells (px)")
    sip_degree: int = _opt(5, "degree of the TAN-SIP forward and inverse "
                              "polynomials")
    sip_max_error: float = _opt(1e-3, "requested SIP fit accuracy (px)")
    grid_n: int = _opt(25, "side of the SIP round-trip check grid")
    cutout_size: int = _opt(600, "side of the cutout figure (px)")
    cutout_stars: int = _opt(20, "Gaia stars labelled in the cutout")
    cutout_x: float = _opt(-1.0, "cutout centre x (px; -1 = detector "
                                 "centre)")
    cutout_y: float = _opt(-1.0, "cutout centre y (px; -1 = detector "
                                 "centre)")

    def radii(self) -> tuple[float, ...]:
        """Return the match radii as floats, in the order given."""
        return tuple(float(v) for v in self.match_radii.split(","))

    def validate(self) -> None:
        """Raise ValueError on an inconsistent set of constants."""
        if self.rank_band not in ("rp", "g"):
            raise ValueError("rank-band must be rp or g")
        if self.peak_size < 3 or self.peak_size % 2 == 0:
            raise ValueError("peak-size must be odd and at least 3")
        if self.xcorr_bin <= 0 or self.xcorr_half <= self.xcorr_bin:
            raise ValueError("xcorr-half must exceed xcorr-bin > 0")
        r = self.radii()
        if not r or any(v <= 0 for v in r) or list(r) != sorted(
                r, reverse=True):
            raise ValueError("match-radii must be positive and decreasing")
        if self.min_matches < 6:
            raise ValueError("min-matches must be at least 6")
        if self.sip_degree < 1 or self.grid_n < 3:
            raise ValueError("sip-degree >= 1 and grid-n >= 3 required")


DEFAULTS = Settings()


# ---------------------------------------------------------------------------
# reference catalogue
# ---------------------------------------------------------------------------
@dataclass
class Reference:
    """Reference stars at a common epoch.

    Attributes:
        ra: Right ascension (deg) at ``epoch``.
        dec: Declination (deg) at ``epoch``.
        mag: Ranking magnitude (Gaia RP or G, or the file's column).
        pmra: Proper motion in RA*cos(Dec) (mas/yr), or None.
        pmdec: Proper motion in Dec (mas/yr), or None.
        epoch: Julian year of the positions.
        source_id: Gaia source identifiers, or None.
        label: Where the catalogue came from, for provenance.
    """

    ra: np.ndarray
    dec: np.ndarray
    mag: np.ndarray
    pmra: Optional[np.ndarray]
    pmdec: Optional[np.ndarray]
    epoch: float
    source_id: Optional[np.ndarray]
    label: str

    def at_epoch(self, jyear: float) -> tuple[np.ndarray, np.ndarray]:
        """Return (ra, dec) propagated linearly to ``jyear``.

        Linear propagation differs from the rigorous space motion by
        far less than a milliarcsecond over a decade for Galactic
        stars; parallax is not modelled.
        """
        if self.pmra is None or self.pmdec is None:
            return self.ra, self.dec
        dt = jyear - self.epoch
        pmra = np.nan_to_num(self.pmra)
        pmdec = np.nan_to_num(self.pmdec)
        ra = self.ra + pmra * dt / 3.6e6 / np.cos(np.radians(self.dec))
        return ra, self.dec + pmdec * dt / 3.6e6


def gaia_query(ra: float, dec: float, radius: float,
               g_limit: float) -> str:
    """Build the ADQL cone query of the Gaia archive."""
    return (
        "SELECT source_id, ra, dec, ref_epoch, pmra, pmdec, "
        "phot_g_mean_mag, phot_rp_mean_mag, ruwe "
        f"FROM {GAIA_TABLE} "
        f"WHERE DISTANCE(POINT({ra:.6f},{dec:.6f}),POINT(ra,dec)) "
        f"< {radius:.4f} "
        f"AND phot_g_mean_mag < {g_limit:g} "
        "AND pmra IS NOT NULL AND pmdec IS NOT NULL")


def tap_async(adql: str, out_path: str, url: str = GAIA_TAP,
              poll: float = 5.0, timeout: float = 3600.0) -> None:
    """Run a query on the asynchronous TAP endpoint, streaming to disk.

    The synchronous endpoint of the Gaia archive times out on bulge
    cones of a few hundred thousand rows, so everything goes async.

    Raises:
        RuntimeError: If the job ends in ERROR or ABORTED or times out.
    """
    data = urllib.parse.urlencode(
        {"REQUEST": "doQuery", "LANG": "ADQL", "FORMAT": "csv",
         "PHASE": "RUN", "QUERY": adql}).encode()
    req = urllib.request.Request(url + "/async", data=data)
    with urllib.request.urlopen(req, timeout=120) as r:
        job = r.geturl()
    print(f"  Gaia job {job.rsplit('/', 1)[-1]} submitted", flush=True)
    t0 = time.time()
    phase = "PENDING"
    while time.time() - t0 < timeout:
        with urllib.request.urlopen(job + "/phase", timeout=120) as r:
            phase = r.read().decode().strip()
        if phase == "COMPLETED":
            break
        if phase in ("ERROR", "ABORTED"):
            with urllib.request.urlopen(job, timeout=120) as r:
                raise RuntimeError(f"Gaia job {phase}: "
                                   f"{r.read().decode()[:2000]}")
        time.sleep(poll)
    else:
        raise RuntimeError(f"Gaia job still {phase} after {timeout:.0f} s")
    tmp = out_path + ".part"
    with urllib.request.urlopen(job + "/results/result",
                                timeout=1800) as r, open(tmp, "wb") as fh:
        shutil.copyfileobj(r, fh, length=1 << 20)
    os.replace(tmp, out_path)


def _cone_contains(entry: dict, ra: float, dec: float,
                   radius: float) -> bool:
    """True if a cached cone covers the requested one."""
    d = np.degrees(np.arccos(np.clip(
        np.sin(np.radians(dec)) * np.sin(np.radians(entry["dec"]))
        + np.cos(np.radians(dec)) * np.cos(np.radians(entry["dec"]))
        * np.cos(np.radians(ra - entry["ra"])), -1, 1)))
    return d + radius <= entry["radius"] + 1e-6


def fetch_gaia(cache_dir: str, ra: float, dec: float, radius: float,
               settings: Settings = DEFAULTS) -> Reference:
    """Return Gaia stars in a cone, from the cache when one covers it.

    The cache is ``<cache_dir>/gaia_<hash>.csv`` with a JSON sidecar
    recording the cone, the G limit and the exact ADQL; a cached cone
    is reused when it contains the requested one with the same limit,
    so the dithers of one field share a download.

    Args:
        cache_dir: Directory of the cache.
        ra: Cone centre right ascension (deg).
        dec: Cone centre declination (deg).
        radius: Cone radius (deg).
        settings: Only ``g_limit`` and ``rank_band`` are used.

    Returns:
        The reference stars, ranked by ``settings.rank_band``.
    """
    os.makedirs(cache_dir, exist_ok=True)
    path = None
    for side in sorted(Path(cache_dir).glob("gaia_*.json")):
        e = json.loads(side.read_text())
        csv = side.with_suffix(".csv")
        if (e.get("g_limit") == settings.g_limit and csv.is_file()
                and _cone_contains(e, ra, dec, radius)):
            path = str(csv)
            break
    if path is None:
        adql = gaia_query(ra, dec, radius, settings.g_limit)
        h = hashlib.sha256(adql.encode()).hexdigest()[:12]
        path = os.path.join(cache_dir, f"gaia_{h}.csv")
        print(f"  querying Gaia: cone ({ra:.4f}, {dec:.4f}) r={radius:.3f} "
              f"deg, G < {settings.g_limit:g}", flush=True)
        tap_async(adql, path)
        with open(path) as fh:
            n = sum(1 for _ in fh) - 1
        Path(path).with_suffix(".json").write_text(json.dumps(dict(
            ra=ra, dec=dec, radius=radius, g_limit=settings.g_limit,
            adql=adql, table=GAIA_TABLE, service=GAIA_TAP, rows=n,
            retrieved=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())),
            indent=1))
        print(f"  cached {n} rows in {path}", flush=True)
    t = Table.read(path, format="ascii.csv")
    g = np.asarray(t["phot_g_mean_mag"], float)
    rp = np.asarray(np.ma.filled(t["phot_rp_mean_mag"], np.nan), float)
    mag = np.where(np.isfinite(rp), rp, g) if settings.rank_band == "rp" \
        else g
    epoch = float(np.median(np.asarray(t["ref_epoch"], float)))
    return Reference(
        ra=np.asarray(t["ra"], float), dec=np.asarray(t["dec"], float),
        mag=mag, pmra=np.asarray(t["pmra"], float),
        pmdec=np.asarray(t["pmdec"], float), epoch=epoch,
        source_id=np.asarray(t["source_id"], np.int64),
        label=f"{GAIA_TABLE} cone {os.path.basename(path)}")


def load_reference_file(path: str, cols: tuple[int, ...],
                        epoch: float) -> Reference:
    """Read a whitespace-separated reference catalogue.

    Args:
        path: Text file; lines starting with ``#`` are skipped.
        cols: 1-based columns of RA (deg), Dec (deg), magnitude and,
            optionally, pmRA*cos(Dec) and pmDec (mas/yr).  The default
            ``(2, 3, 34, 5, 6)`` matches the MSOS fiducial catalogue
            ``rdpmx.out`` of ``gaia2msos``, whose column 34 is the
            predicted F146 magnitude.
        epoch: Julian year of the positions.

    Returns:
        The reference stars.
    """
    use = tuple(c - 1 for c in cols)
    a = np.loadtxt(path, usecols=use, ndmin=2)
    pm = a.shape[1] >= 5
    return Reference(
        ra=a[:, 0], dec=a[:, 1], mag=a[:, 2],
        pmra=a[:, 3] if pm else None, pmdec=a[:, 4] if pm else None,
        epoch=epoch, source_id=None, label=os.path.basename(path))


# ---------------------------------------------------------------------------
# the frame
# ---------------------------------------------------------------------------
# <exposure>_wfiNN_<filter>: the exposure part groups the detectors
_NAME = re.compile(r"^(?P<exp>.+)_wfi\d\d_[a-z0-9]+$")


@dataclass
class Frame:
    """One L2 frame: what the alignment and the figures need."""

    path: str
    stem: str
    exposure: str
    detector: str
    filt: str
    gwcs: GWCS
    data: Optional[np.ndarray]
    shape: tuple[int, int]
    epoch: float
    start: str
    program: str
    fit_results: dict


def read_frame(path: str) -> Frame:
    """Read the gwcs, the image and the metadata of a ``*_cal.asdf``."""
    stem = Path(path).name.removesuffix(".asdf").removesuffix("_cal")
    m = _NAME.match(stem)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        with asdf.open(path, lazy_load=True, memmap=False) as af:
            r = af["roman"]
            meta = r["meta"]
            data = np.array(r["data"], dtype=np.float32)
            t0 = Time(meta["exposure"]["start_time"])
            texp = float(meta["exposure"].get("exposure_time", 0.0) or 0.0)
            fit = {k: (v.tolist() if hasattr(v, "tolist") else v)
                   for k, v in dict(meta.get("wcs_fit_results") or {}
                                    ).items()}
            return Frame(
                path=str(path), stem=stem,
                exposure=m.group("exp") if m else stem,
                detector=str(meta["instrument"]["detector"]),
                filt=str(meta["instrument"]["optical_element"]),
                gwcs=meta["wcs"], data=data, shape=data.shape,
                epoch=float((t0 + texp / 2.0 / 86400.0).jyear),
                start=t0.utc.isot,
                program=str(meta["observation"]["program"]),
                fit_results=fit)


def pixel_scale(gw: GWCS, nx: int, ny: int) -> float:
    """Local pixel scale at the detector centre (arcsec/px)."""
    r0, d0 = gw(nx / 2, ny / 2, with_bounding_box=False)
    r1, d1 = gw(nx / 2 + 1, ny / 2, with_bounding_box=False)
    return float(np.hypot((r1 - r0) * np.cos(np.radians(d0)), d1 - d0)
                 * 3600)


# ---------------------------------------------------------------------------
# the alignment
# ---------------------------------------------------------------------------
def image_peaks(data: np.ndarray, size: int = DEFAULTS.peak_size,
                floor: float = DEFAULTS.peak_floor
                ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Local maxima above ``floor``, brightest first.

    Returns:
        (x, y, value) with integer pixel positions as floats, 0-based.
        Sub-pixel centroiding is not done: pixel quantisation adds
        1/sqrt(12) = 0.29 px per axis to the final scatter, which the
        affine averages down over hundreds of stars.
    """
    d = np.nan_to_num(data)
    pk = (d == maximum_filter(d, size)) & (d > floor)
    py, px = np.nonzero(pk)
    v = d[py, px]
    o = np.argsort(-v)
    return px[o].astype(float), py[o].astype(float), v[o]


def coarse_offset(px, py, gx, gy, nx: int, ny: int,
                  s: Settings = DEFAULTS) -> tuple[float, float, float]:
    """Translation by FFT cross-correlation of two point sets.

    Returns:
        (dx, dy, sigma): predicted minus observed position (px) and the
        significance of the correlation peak.  Shifting the predicted
        positions by (-dx, -dy) lands them on the observed ones.
    """
    b, half = s.xcorr_bin, s.xcorr_half
    ok = (gx > -half) & (gx < nx + half) & (gy > -half) & (gy < ny + half)
    gx, gy = gx[ok], gy[ok]
    n = int((max(nx, ny) + 2 * half) / b) + 1
    g = np.zeros((n, n), np.float32)
    np.add.at(g, (((gy + half) / b).astype(int),
                  ((gx + half) / b).astype(int)), 1)
    p = np.zeros((n, n), np.float32)
    np.add.at(p, (((py + half) / b).astype(int),
                  ((px + half) / b).astype(int)), 1)
    c = fftconvolve(g, p[::-1, ::-1], mode="same")
    k = np.unravel_index(c.argmax(), c.shape)
    c0 = n // 2
    sigma = (c.max() - np.median(c)) / c.std()
    return (k[1] - c0) * b, (k[0] - c0) * b, float(sigma)


def refine_offset(ox, oy, tree: cKDTree, px, py,
                  s: Settings = DEFAULTS) -> tuple[float, float, int]:
    """Refine a translation on the histogram of nearest-neighbour residuals.

    The correlation peak lands on a grid of ``xcorr_bin`` px and can sit
    several bins off on sparse detectors, while the scale error spreads
    the true residuals over ~16 px; the flux-weighted centroid of the
    3x3 cells around the histogram mode recovers the centre.

    Returns:
        (rdx, rdy, n): observed minus predicted refinement (px) and the
        number of pairs used; (0, 0, n) when too few pairs.
    """
    w, b = s.refine_window, s.refine_bin
    d, i = tree.query(np.column_stack([ox, oy]), distance_upper_bound=w)
    ok = np.isfinite(d)
    if ok.sum() < s.min_matches:
        return 0.0, 0.0, int(ok.sum())
    rx, ry = px[i[ok]] - ox[ok], py[i[ok]] - oy[ok]
    edges = np.arange(-w, w + b, b)
    h, _, _ = np.histogram2d(rx, ry, bins=[edges, edges])
    k = np.unravel_index(h.argmax(), h.shape)
    cen = edges[:-1] + b / 2
    sl = (slice(max(k[0] - 1, 0), k[0] + 2),
          slice(max(k[1] - 1, 0), k[1] + 2))
    ww = h[sl]
    rdx = float((ww.sum(axis=1) * cen[sl[0]]).sum() / ww.sum())
    rdy = float((ww.sum(axis=0) * cen[sl[1]]).sum() / ww.sum())
    return rdx, rdy, int(ok.sum())


def fit_affine(src: np.ndarray, dst: np.ndarray, niter: int = 4
               ) -> tuple[np.ndarray, np.ndarray, float, np.ndarray]:
    """Least squares dst = M src + t with sigma clipping.

    Returns:
        (M, t, rms, keep): the 2x2 matrix, the translation, the per-axis
        rms of the kept points and their mask.
    """
    a = np.column_stack([src, np.ones(len(src))])
    keep = np.ones(len(src), bool)
    for _ in range(niter):
        cx = np.linalg.lstsq(a[keep], dst[keep, 0], rcond=None)[0]
        cy = np.linalg.lstsq(a[keep], dst[keep, 1], rcond=None)[0]
        res = np.hypot(a @ cx - dst[:, 0], a @ cy - dst[:, 1])
        keep = res < max(3 * np.median(res[keep]), 0.3)
    m = np.array([[cx[0], cx[1]], [cy[0], cy[1]]])
    t = np.array([cx[2], cy[2]])
    r = np.column_stack([a @ cx - dst[:, 0], a @ cy - dst[:, 1]])[keep]
    return m, t, float(r.std()), keep


def insert_v2v3_affine(gw: GWCS, m: np.ndarray, t: np.ndarray) -> GWCS:
    """gwcs with V' = M V + t inserted after the detector -> V2V3 step."""
    affine = AffineTransformation2D(matrix=m, translation=t)
    steps = [(st.frame, st.transform) for st in gw.pipeline]
    steps[0] = (steps[0][0], steps[0][1] | affine)
    return GWCS(steps)


def export_sip(gw: GWCS, nx: int, ny: int, s: Settings = DEFAULTS
               ) -> tuple[WCS, float]:
    """Fit a TAN-SIP header to a gwcs and measure its round-trip error.

    Returns:
        (astropy WCS, max |SIP inverse(SIP forward) - grid| in px).
    """
    xg, yg = np.meshgrid(np.linspace(0, nx - 1, s.grid_n),
                         np.linspace(0, ny - 1, s.grid_n))
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        hdr = gw.to_fits_sip(
            bounding_box=((-0.5, nx - 0.5), (-0.5, ny - 0.5)),
            max_pix_error=s.sip_max_error, degree=s.sip_degree,
            max_inv_pix_error=s.sip_max_error, inv_degree=s.sip_degree)
        w = WCS(hdr)
        ra, dec = gw(xg.ravel(), yg.ravel(), with_bounding_box=False)
        rx, ry = w.all_world2pix(ra, dec, 0)
    return w, float(np.hypot(rx - xg.ravel(), ry - yg.ravel()).max())


def align(gw: GWCS, data: np.ndarray, ref: Reference, epoch: float,
          s: Settings = DEFAULTS) -> dict:
    """Align one frame to the reference stars.

    Args:
        gw: The frame's gwcs (detector -> v2v3 -> ... -> world).
        data: The image.
        ref: Reference stars.
        epoch: Julian year the reference positions are propagated to.
        s: Settings.

    Returns:
        A dict with the corrected ``gwcs`` and ``wcs`` (astropy, TAN-SIP),
        the solution numbers (``dx``, ``dy``, ``sx``, ``sy``, ``rot``,
        ``rms``, ``nmatch``, ``xcorr_sigma``, ``sip_resid``,
        ``grid_max``, ``shift_arcsec`` ...) and the arrays the figures
        need (peaks, predictions, residual fields, matches).

    Raises:
        AlignError: When a step fails its acceptance test.
    """
    ny, nx = data.shape
    px, py, _ = image_peaks(data, s.peak_size, s.peak_floor)
    if len(px) < s.min_matches:
        raise AlignError(f"only {len(px)} peaks above {s.peak_floor:g}")
    ra, dec = ref.at_epoch(epoch)
    fin = np.isfinite(ra) & np.isfinite(dec)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        gx, gy = gw.invert(ra, dec, with_bounding_box=False)
    gx = np.where(fin & np.isfinite(gx), gx, np.inf)
    gy = np.where(fin & np.isfinite(gy), gy, np.inf)
    half = s.xcorr_half
    win = (ref.mag >= s.mag_min) & (ref.mag <= s.mag_max)
    box = win & (gx > -half) & (gx < nx + half) & (gy > -half) \
        & (gy < ny + half)
    ix = np.flatnonzero(box)
    ix = ix[np.argsort(ref.mag[ix], kind="stable")][:s.n_xcorr_ref]
    if len(ix) < s.min_matches:
        raise AlignError(f"only {len(ix)} reference stars in the search "
                         "box")
    nxp = min(s.n_xcorr_peaks, len(px))
    dx, dy, sigma = coarse_offset(px[:nxp], py[:nxp], gx[ix], gy[ix],
                                  nx, ny, s)
    if sigma < s.xcorr_min_sigma:
        raise AlignError(f"cross-correlation peak only {sigma:.1f} sigma")
    nfp = min(s.n_fit_peaks, len(px))
    fpx, fpy = px[:nfp], py[:nfp]
    tree = cKDTree(np.column_stack([fpx, fpy]))
    ox, oy = gx - dx, gy - dy
    e = s.edge
    on = win & (ox > e) & (ox < nx - e) & (oy > e) & (oy < ny - e)
    sf = np.flatnonzero(on)
    sf = sf[np.argsort(ref.mag[sf], kind="stable")][:s.n_fit_ref]
    if len(sf) < s.min_matches:
        raise AlignError(f"only {len(sf)} reference stars on the detector")
    rdx, rdy, nref = refine_offset(ox[sf], oy[sf], tree, fpx, fpy, s)
    dx, dy = dx - rdx, dy - rdy
    ox, oy = ox + rdx, oy + rdy
    # the fit, in the V2V3 frame
    det2v = gw.get_transform("detector", "v2v3")
    sky2v = gw.get_transform("v2v3", "world").inverse
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        vref = np.column_stack(sky2v(ra[sf], dec[sf]))
    ra_f, dec_f = ra[sf], dec[sf]
    cur = np.column_stack([ox[sf], oy[sf]])
    radii = s.radii()
    d0, i0 = tree.query(cur, distance_upper_bound=radii[0])
    ok0 = np.isfinite(d0)
    before = dict(x=cur[ok0, 0], y=cur[ok0, 1],
                  u=fpx[i0[ok0]] - cur[ok0, 0], v=fpy[i0[ok0]] - cur[ok0, 1])
    m, t = np.eye(2), np.zeros(2)
    new, last = None, radii[0]
    for radius in radii:
        d, i = tree.query(cur, distance_upper_bound=radius)
        ok = np.isfinite(d)
        if ok.sum() < s.min_matches:
            if new is None:
                raise AlignError(f"only {ok.sum()} matches within "
                                 f"{radius:g} px")
            d, i = tree.query(cur, distance_upper_bound=last)
            ok = np.isfinite(d)
            break
        vobs = np.column_stack(det2v(fpx[i[ok]], fpy[i[ok]]))
        m, t, _, keep = fit_affine(vobs, vref[ok], s.clip_iterations)
        new = insert_v2v3_affine(gw, m, t)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            cur = np.column_stack(new.invert(ra_f, dec_f,
                                             with_bounding_box=False))
        last = radius
    obs = np.column_stack([fpx[i[ok]], fpy[i[ok]]])
    res = obs - cur[ok]
    rr = np.hypot(res[:, 0], res[:, 1])
    keep = rr < 3 * np.median(rr)
    rms = float(res[keep].std())
    nmatch = int(keep.sum())
    if nmatch < s.min_matches or rms > s.max_rms:
        raise AlignError(f"affine fit: {nmatch} stars, rms {rms:.2f} px")
    grid_max = 0.0
    for qx in range(3):
        for qy in range(3):
            c = ((obs[:, 0] >= qx * nx / 3) & (obs[:, 0] < (qx + 1) * nx / 3)
                 & (obs[:, 1] >= qy * ny / 3)
                 & (obs[:, 1] < (qy + 1) * ny / 3))
            if c.sum() >= 10:
                grid_max = max(grid_max, float(np.abs(
                    np.median(res[c], axis=0)).max()))
    if grid_max > s.max_grid_resid:
        raise AlignError(f"residual structure: 3x3-cell median up to "
                         f"{grid_max:.2f} px")
    w, sip_resid = export_sip(new, nx, ny, s)
    cx, cy = nx / 2, ny / 2
    ra0, dec0 = gw(cx, cy, with_bounding_box=False)
    ra1, dec1 = new(cx, cy, with_bounding_box=False)
    shift = (float((ra1 - ra0) * np.cos(np.radians(dec0)) * 3600),
             float((dec1 - dec0) * 3600))
    offset = float(np.hypot(*shift))
    rot = float(np.degrees(np.arctan2(m[1, 0] - m[0, 1],
                                      m[0, 0] + m[1, 1])))
    sel = sf[ok]
    return dict(
        gwcs=new, wcs=w, dx=float(dx), dy=float(dy),
        sx=float(np.hypot(m[0, 0], m[1, 0])),
        sy=float(np.hypot(m[0, 1], m[1, 1])), rot=rot, rms=rms,
        nmatch=nmatch, xcorr_sigma=sigma, sip_resid=sip_resid,
        grid_max=grid_max, v2v3_shift=(float(t[0]), float(t[1])),
        matrix=m.tolist(), shift_arcsec=shift, offset_arcsec=offset,
        last_radius=float(last), first_radius=float(radii[0]),
        pixscale=pixel_scale(gw, nx, ny), npeaks=int(len(px)),
        n_xcorr_ref=int(len(ix)), n_fit_ref=int(len(sf)), n_refine=nref,
        # arrays for the figures and the match table
        px=px, py=py, xcorr_gx=gx[ix], xcorr_gy=gy[ix], before=before,
        after=dict(x=cur[ok, 0], y=cur[ok, 1], u=res[:, 0], v=res[:, 1],
                   keep=keep),
        match_ref=sel, match_obs=obs, match_pred=cur[ok],
        match_nominal=np.column_stack([gx[sel], gy[sel]]),
        ref_ra=ra, ref_dec=dec, nom_x=gx, nom_y=gy)


# ---------------------------------------------------------------------------
# products
# ---------------------------------------------------------------------------
def wcs_header_cards(w: WCS) -> fits.Header:
    """CTYPE/CRPIX/CRVAL/CD + SIP cards of an astropy WCS (CD form)."""
    h = w.to_header(relax=True)
    out = fits.Header()
    out["WCSAXES"] = 2
    for k in ("CTYPE1", "CTYPE2", "CRPIX1", "CRPIX2", "CRVAL1", "CRVAL2"):
        out[k] = h[k]
    cd = w.wcs.cd if w.wcs.has_cd() else w.wcs.pc * w.wcs.cdelt[:, None]
    out["CD1_1"], out["CD1_2"] = float(cd[0, 0]), float(cd[0, 1])
    out["CD2_1"], out["CD2_2"] = float(cd[1, 0]), float(cd[1, 1])
    out["RADESYS"] = "ICRS"
    for k in h:
        if k in ("A_ORDER", "B_ORDER", "AP_ORDER", "BP_ORDER") or \
                k[:2] in ("A_", "B_") or k[:3] in ("AP_", "BP_"):
            out[k] = h[k]
    return out


def provenance_cards(sol: dict, fr: Frame, ref: Reference) -> fits.Header:
    """The WCS* cards recording the alignment, for a fleet-wide census."""
    h = fits.Header()
    h["WCSALIGN"] = (True, "WCS re-fit to a reference catalogue")
    h["WCSREF"] = (ref.label[:60], "reference catalogue")
    h["WCSEPOCH"] = (round(fr.epoch, 4), "epoch of the reference positions "
                                         "(Julian year)")
    h["WCSDX"] = (round(sol["dx"], 2), "nominal - observed x offset (px)")
    h["WCSDY"] = (round(sol["dy"], 2), "nominal - observed y offset (px)")
    h["WCSOFF"] = (round(sol["offset_arcsec"], 2),
                   "nominal - corrected centre offset (arcsec)")
    h["WCSSX"] = (round(sol["sx"], 6), "affine x scale in V2V3")
    h["WCSSY"] = (round(sol["sy"], 6), "affine y scale in V2V3")
    h["WCSROT"] = (round(sol["rot"], 5), "affine rotation in V2V3 (deg)")
    h["WCSV2SH"] = (round(sol["v2v3_shift"][0], 3),
                    "affine V2 shift (arcsec)")
    h["WCSV3SH"] = (round(sol["v2v3_shift"][1], 3),
                    "affine V3 shift (arcsec)")
    h["WCSNMAT"] = (sol["nmatch"], "stars in the affine fit")
    h["WCSRMS"] = (round(sol["rms"], 4), "per-axis rms of the fit (px)")
    h["WCSXCSIG"] = (round(sol["xcorr_sigma"], 1), "cross-correlation "
                                                   "peak significance")
    h["WCSSIPRS"] = (round(sol["sip_resid"], 5), "SIP round-trip max "
                                                 "residual (px)")
    h["WCSGRIDR"] = (round(sol["grid_max"], 4), "max |3x3-cell median "
                                                "residual| (px)")
    h["WCSSRC"] = (os.path.basename(fr.path)[:60], "input frame")
    h["WCSTOOL"] = (f"gaia_wcs_correction {__version__}", "")
    return h


def write_products(fr: Frame, sol: dict, ref: Reference, out: str,
                   s: Settings, write_asdf: bool) -> dict:
    """Write the header and the match table of one frame.

    Returns:
        The JSON-serialisable summary (written by the caller once the
        figures are known).
    """
    stem = os.path.join(out, fr.stem)
    hdr = wcs_header_cards(sol["wcs"])
    hdr.extend(provenance_cards(sol, fr, ref))
    hdr["COMMENT"] = (f"TAN-SIP WCS of {os.path.basename(fr.path)} re-fit "
                      "to the reference stars; replaces the delivered WCS.")
    fits.PrimaryHDU(header=hdr).writeto(stem + "_gaiawcs.fits",
                                        overwrite=True)
    if write_asdf:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            asdf.AsdfFile({"wcs": sol["gwcs"], "meta": dict(
                input=os.path.basename(fr.path), detector=fr.detector,
                reference=ref.label, tool=f"gaia_wcs_correction "
                f"{__version__}")}).write_to(stem + "_gaiawcs.asdf")
    sel, obs = sol["match_ref"], sol["match_obs"]
    cols = dict(ra=sol["ref_ra"][sel], dec=sol["ref_dec"][sel],
                mag=ref.mag[sel], x_obs=obs[:, 0], y_obs=obs[:, 1],
                x_nominal=sol["match_nominal"][:, 0],
                y_nominal=sol["match_nominal"][:, 1],
                x_corrected=sol["match_pred"][:, 0],
                y_corrected=sol["match_pred"][:, 1],
                dx=sol["after"]["u"], dy=sol["after"]["v"],
                kept=sol["after"]["keep"])
    if ref.source_id is not None:
        cols = dict(source_id=ref.source_id[sel], **cols)
    t = Table(cols)
    t.meta.update(dict(
        positions="0-based pixels; x_obs/y_obs are integer peak pixels",
        dx="x_obs - x_corrected (px)", epoch_jyear=fr.epoch,
        reference=ref.label, input=os.path.basename(fr.path)))
    t.write(stem + "_matches.ecsv", overwrite=True, format="ascii.ecsv")
    summary = dict(
        input=os.path.abspath(fr.path), exposure=fr.exposure,
        detector=fr.detector, filter=fr.filt, program=fr.program,
        start_utc=fr.start, epoch_jyear=fr.epoch, shape=list(fr.shape),
        reference=ref.label, delivered_fit_results=fr.fit_results,
        **{k: sol[k] for k in (
            "dx", "dy", "sx", "sy", "rot", "rms", "nmatch", "xcorr_sigma",
            "sip_resid", "grid_max", "v2v3_shift", "matrix",
            "shift_arcsec", "offset_arcsec", "last_radius", "pixscale",
            "npeaks", "n_xcorr_ref", "n_fit_ref", "n_refine")},
        products=[fr.stem + "_gaiawcs.fits", fr.stem + "_matches.ecsv"],
        settings=asdict(s),
        packages={n: _pkg_version(n) for n in DEPENDENCIES},
        tool=f"gaia_wcs_correction {__version__}")
    if write_asdf:
        summary["products"].append(fr.stem + "_gaiawcs.asdf")
    return summary


def _pkg_version(name: str) -> str:
    try:
        return version(name)
    except PackageNotFoundError:
        return "not installed"


# ---------------------------------------------------------------------------
# figures
# ---------------------------------------------------------------------------
def _binned(f: dict, n: int, nx: int, ny: int):
    ex, ey = np.linspace(0, nx, n + 1), np.linspace(0, ny, n + 1)
    ix = np.clip(np.digitize(f["x"], ex) - 1, 0, n - 1)
    iy = np.clip(np.digitize(f["y"], ey) - 1, 0, n - 1)
    u = np.full((n, n), np.nan)
    v = np.full((n, n), np.nan)
    for j in range(n):
        for i in range(n):
            k = (ix == i) & (iy == j)
            if k.sum() >= 5:
                u[j, i] = np.median(f["u"][k])
                v[j, i] = np.median(f["v"][k])
    return 0.5 * (ex[1:] + ex[:-1]), 0.5 * (ey[1:] + ey[:-1]), u, v


def quiver_panel(ax, f: dict, nx: int, ny: int, scale_px: float,
                 color: str = "C3", grid: int = 6) -> None:
    """Binned median residual arrows over the stars (grey dots), with a
    black reference bar of ``scale_px``."""
    cx, cy, u, v = _binned(f, grid, nx, ny)
    xg, yg = np.meshgrid(cx, cy)
    q = scale_px / (0.55 * nx / grid)
    ax.scatter(f["x"], f["y"], s=0.4, c="0.75", lw=0, zorder=0,
               rasterized=True)
    ax.quiver(xg, yg, u, v, angles="xy", scale_units="xy", scale=q,
              width=0.012, color=color)
    bx, by = 0.06 * nx, 0.92 * ny
    ax.quiver([bx], [by], [scale_px], [0], angles="xy", scale_units="xy",
              scale=q, width=0.012, color="k")
    ax.text(bx, by + 0.03 * ny, f"{scale_px:g} px", fontsize=6,
            va="bottom")
    ax.set_xlim(0, nx)
    ax.set_ylim(0, ny)
    ax.set_aspect("equal")


def _pct(v: float) -> str:
    return f"{(v - 1) * 100:+.2f}%"


def _label(fr: Frame) -> str:
    return f"{fr.exposure} {fr.detector} {fr.filt}"


def _band(ref: Reference, s: Settings) -> str:
    """Name of the ranking magnitude, for figure labels."""
    return ("Gaia " + s.rank_band.upper() if ref.source_id is not None
            else "catalogue")


def plot_steps(fr: Frame, sol: dict, out: str) -> str:
    """Three panels: nominal offset, after the translation, after the
    affine."""
    ny, nx = fr.shape
    fig, ax = plt.subplots(1, 3, figsize=(15, 5.6))
    off = sol["offset_arcsec"]
    a = ax[0]
    n_show = min(len(sol["px"]), 20000)
    a.scatter(sol["px"][:n_show], sol["py"][:n_show], s=0.5, c="0.6",
              lw=0, rasterized=True,
              label=f"image peaks ({sol['npeaks']}, brightest {n_show})")
    a.scatter(sol["xcorr_gx"], sol["xcorr_gy"], s=0.8, c="C3", lw=0,
              rasterized=True,
              label=f"reference stars through the delivered gwcs "
                    f"({sol['n_xcorr_ref']})")
    a.add_patch(plt.Rectangle((0, 0), nx, ny, fill=False, ec="k", lw=0.8))
    a.annotate("", xy=(nx / 2 + sol["dx"], ny / 2 + sol["dy"]),
               xytext=(nx / 2, ny / 2),
               arrowprops=dict(arrowstyle="->", color="k", lw=1.2))
    lim = max(2500, abs(sol["dx"]) + 600, abs(sol["dy"]) + 600)
    a.set_xlim(-lim, nx + lim)
    a.set_ylim(-lim, ny + lim)
    a.set_aspect("equal")
    a.legend(loc="upper left", fontsize=6, markerscale=6, frameon=True)
    a.set_title(f"(a) delivered gwcs: reference stars land "
                f"({sol['dx']:+.0f}, {sol['dy']:+.0f}) px = {off:.0f}$''$ "
                f"from the image (black box: detector)", fontsize=7.5)
    quiver_panel(ax[1], sol["before"], nx, ny, 4.0)
    b = sol["before"]
    ax[1].set_title(f"(b) after the translation ({sol['xcorr_sigma']:.0f}"
                    f"$\\sigma$ correlation peak): median residual "
                    f"({np.median(b['u']):+.1f}, {np.median(b['v']):+.1f}) "
                    f"px plus a gradient;\nn = {len(b['u'])} within "
                    f"{sol['first_radius']:g} px, bar 4 px", fontsize=7.5)
    quiver_panel(ax[2], sol["after"], nx, ny, 0.3, color="C0")
    ax[2].set_title(f"(c) after the affine in V2V3: scale "
                    f"({_pct(sol['sx'])}, {_pct(sol['sy'])}), rot "
                    f"{sol['rot']:+.3f}$^\\circ$, centre shift "
                    f"({sol['shift_arcsec'][0]:+.1f}, "
                    f"{sol['shift_arcsec'][1]:+.1f})$''$\nn = "
                    f"{sol['nmatch']} within {sol['last_radius']:g} px, "
                    f"rms {sol['rms']:.2f} px, max cell median "
                    f"{sol['grid_max']:.2f} px; bar 0.3 px", fontsize=7.5)
    for a in ax:
        a.set_xlabel("detector x [px]")
        a.set_ylabel("detector y [px]")
    fig.suptitle(f"{_label(fr)}: alignment of the delivered gwcs to the "
                 f"reference stars in two steps; the TAN-SIP export "
                 f"round-trips to {sol['sip_resid']:.4f} px",
                 fontsize=9, y=1.0)
    fig.tight_layout()
    path = os.path.join(out, fr.stem + "_steps.png")
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return path


def plot_cutout(fr: Frame, sol: dict, ref: Reference, out: str,
                s: Settings = DEFAULTS) -> str:
    """Image cutout with the brightest reference stars circled at their
    corrected positions, and an inset locating it on the detector."""
    ny, nx = fr.shape
    size = int(min(s.cutout_size, nx, ny))
    x0 = nx / 2 if s.cutout_x < 0 else s.cutout_x
    y0 = ny / 2 if s.cutout_y < 0 else s.cutout_y
    xlo = int(np.clip(round(x0 - size / 2), 0, nx - size))
    ylo = int(np.clip(round(y0 - size / 2), 0, ny - size))
    cut = np.nan_to_num(fr.data[ylo:ylo + size, xlo:xlo + size])
    lo, hi = np.percentile(cut, [5, 99.7])
    stretch = np.arcsinh((cut - lo) / max(hi - lo, 1e-3) * 30) \
        / np.arcsinh(30)
    # 48 grey levels: the noise compresses, the stars do not change
    stretch = np.round(np.clip(stretch, 0, 1) * 48) / 48
    # every reference star inside the cutout, at the corrected WCS: the
    # candidates come from the translated nominal positions, so only
    # stars near the cutout go through the inverse of the corrected gwcs
    tx, ty = sol["nom_x"] - sol["dx"], sol["nom_y"] - sol["dy"]
    cand = np.flatnonzero((np.abs(tx - (xlo + size / 2)) < size / 2 + 40)
                          & (np.abs(ty - (ylo + size / 2)) < size / 2 + 40)
                          & np.isfinite(ref.mag))
    cx = np.full(len(tx), np.nan)
    cy = np.full(len(tx), np.nan)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        cx[cand], cy[cand] = sol["gwcs"].invert(
            sol["ref_ra"][cand], sol["ref_dec"][cand],
            with_bounding_box=False)
    inside = ((cx > xlo + 8) & (cx < xlo + size - 8) & (cy > ylo + 8)
              & (cy < ylo + size - 8))
    idx = np.flatnonzero(inside)
    idx = idx[np.argsort(ref.mag[idx], kind="stable")]
    top = idx[:s.cutout_stars]
    matched = np.isin(idx, sol["match_ref"])
    fig = plt.figure(figsize=(8, 8.6))
    ax = fig.add_axes([0.08, 0.06, 0.9, 0.84])
    ax.imshow(stretch, origin="lower", cmap="gray", vmin=0, vmax=1,
              interpolation="nearest",
              extent=(xlo - 0.5, xlo + size - 0.5, ylo - 0.5,
                      ylo + size - 0.5))
    ax.scatter(cx[idx[matched]], cy[idx[matched]], s=60, marker="o",
               facecolors="none", edgecolors="#4cc9f0", lw=0.6,
               label=f"reference stars matched in the fit "
                     f"({matched.sum()} in the cutout)")
    ax.scatter(cx[idx[~matched]], cy[idx[~matched]], s=60, marker="s",
               facecolors="none", edgecolors="#b0b0b0", lw=0.5,
               label=f"other reference stars in the cutout "
                     f"({(~matched).sum()})")
    ax.scatter(cx[top], cy[top], s=260, facecolors="none",
               edgecolors="#ffe066", lw=1.0,
               label=f"the {len(top)} brightest, labelled by "
                     f"{_band(ref, s)} magnitude")
    for i in top:
        ax.annotate(f"{ref.mag[i]:.1f}", (cx[i], cy[i]), xytext=(9, 9),
                    textcoords="offset points", fontsize=8,
                    color="#ffe066",
                    bbox=dict(fc="black", alpha=0.55, ec="none", pad=1.2))
    ax.set_xlim(xlo - 0.5, xlo + size - 0.5)
    ax.set_ylim(ylo - 0.5, ylo + size - 0.5)
    ax.set_xlabel("detector x [px]")
    ax.set_ylabel("detector y [px]")
    ax.legend(loc="lower left", fontsize=7.5, frameon=True, framealpha=0.85)
    off = sol["offset_arcsec"]
    ax.set_title(
        f"{_label(fr)}: {size}$\\times${size} px cutout at "
        f"({xlo + size // 2}, {ylo + size // 2}) with the corrected WCS\n"
        f"delivered WCS off by ({sol['dx']:+.0f}, {sol['dy']:+.0f}) px = "
        f"{off:.0f}$''$; affine scale ({_pct(sol['sx'])}, "
        f"{_pct(sol['sy'])}), rotation {sol['rot']:+.3f}$^\\circ$; "
        f"{sol['nmatch']} stars, rms {sol['rms']:.2f} px per axis",
        fontsize=9)
    # inset: the detector, the cutout, and the nominal offset arrow
    ins = fig.add_axes([0.745, 0.10, 0.22, 0.19])
    ins.add_patch(plt.Rectangle((0, 0), nx, ny, fill=False, ec="k", lw=0.8))
    ins.add_patch(plt.Rectangle((xlo, ylo), size, size, fill=False,
                                ec="#ffe066", lw=1.0))
    ins.annotate("", xy=(nx / 2 + sol["dx"], ny / 2 + sol["dy"]),
                 xytext=(nx / 2, ny / 2),
                 arrowprops=dict(arrowstyle="->", color="C3", lw=1.2),
                 annotation_clip=False)
    ins.set_xlim(min(0, nx / 2 + sol["dx"]) - 300,
                 max(nx, nx / 2 + sol["dx"]) + 300)
    ins.set_ylim(min(0, ny / 2 + sol["dy"]) - 300,
                 max(ny, ny / 2 + sol["dy"]) + 300)
    ins.set_aspect("equal")
    ins.set_xticks([])
    ins.set_yticks([])
    ins.set_facecolor("white")
    ins.text(0.5, -0.04, "detector (black), cutout (yellow), and\nwhere "
             f"the delivered WCS put the field ({off:.0f}$''$ away)",
             transform=ins.transAxes, ha="center", va="top", fontsize=6.5,
             bbox=dict(fc="white", ec="none", alpha=0.85, pad=1.0))
    path = os.path.join(out, fr.stem + "_cutout.png")
    fig.savefig(path, dpi=100)
    plt.close(fig)
    return path


def _fpa_xy(gw: GWCS, nx: int, ny: int) -> tuple[float, float, float]:
    """Detector centre in focal-plane display coordinates (arcsec)."""
    v2, v3 = gw.get_transform("detector", "v2v3")(nx / 2, ny / 2)
    a = np.radians(FPA_ANGLE_DEG)
    u = v2 * np.cos(a) + v3 * np.sin(a)
    v = -v2 * np.sin(a) + v3 * np.cos(a)
    return float(-u), float(v), nx * pixel_scale(gw, nx, ny)


def plot_focal_plane(frames: list[Frame], sols: list[dict], out: str,
                     stage: str) -> str:
    """Residual arrows of every solved detector, laid out on the focal
    plane.  ``stage`` is 'translation' (bar 4 px) or 'affine' (0.3 px)."""
    pos = {f.detector: _fpa_xy(f.gwcs, *f.shape[::-1]) for f in frames}
    xs = [p[0] for p in pos.values()]
    ys = [p[1] for p in pos.values()]
    half = max(p[2] for p in pos.values()) / 2
    xmin, xmax = min(xs) - half, max(xs) + half
    ymin, ymax = min(ys) - half, max(ys) + half
    wid, hei = xmax - xmin, ymax - ymin
    fig = plt.figure(figsize=(16, 12.2))
    top, bottom, left, right = 0.85, 0.02, 0.02, 0.98
    fr0 = frames[0]
    if stage == "translation":
        offs = [s["offset_arcsec"] for s in sols]
        sig = [s["xcorr_sigma"] for s in sols]
        lines = [
            (f"{fr0.exposure} {fr0.filt}: delivered gwcs vs the reference "
             f"stars, step 1, the coarse translation", 11, True),
            (f"Every detector is {min(offs):.0f}-{max(offs):.0f}$''$ off "
             f"(correlation peaks {min(sig):.0f}-{max(sig):.0f}$\\sigma$). "
             f"Shown: image peak minus prediction after removing that "
             f"translation only, matched within 8 px, medians on a "
             f"6$\\times$6 grid (grey dots: the stars); the black bar is "
             f"4 px.", 8.5, False),
            ("What is left is a residual translation of a few px plus a "
             "scale gradient of several px across each detector, "
             "different per detector: the affine of step 2 removes it. "
             "Panels sit where the detectors sit on the focal plane; "
             "each spans the detector in pixels.", 8.5, False)]
    else:
        sxe = [abs(s["sx"] - 1) * 100 for s in sols]
        sye = [abs(s["sy"] - 1) * 100 for s in sols]
        rot = [abs(s["rot"]) for s in sols]
        rms = [s["rms"] for s in sols]
        gm = [s["grid_max"] for s in sols]
        nm = [s["nmatch"] for s in sols]
        lines = [
            (f"{fr0.exposure} {fr0.filt}: delivered gwcs vs the reference "
             f"stars, step 2, the affine in V2V3 (what the TAN-SIP "
             f"export carries)", 11, True),
            (f"Scale errors of {min(sxe + sye):.2f}-{max(sxe + sye):.2f}% "
             f"and rotations up to {max(rot):.3f}$^\\circ$ per detector; "
             f"{min(nm)}-{max(nm)} matched stars at "
             f"{min(rms):.2f}-{max(rms):.2f} px rms per axis; the "
             f"largest 3$\\times$3-cell median residual is "
             f"{max(gm):.2f} px.", 8.5, False),
            ("Shown: image peak minus corrected prediction for the final "
             "matches, medians on a 6$\\times$6 grid; the black bar is "
             "0.3 px. Coherent leftovers of 0.1-0.2 px are the limit of "
             "the delivered distortion model plus pixel quantisation "
             "of the peaks.", 8.5, False)]
    y = 0.985
    for txt, size, bold in lines:
        fig.text(0.02, y, txt, ha="left", va="top", fontsize=size,
                 weight="bold" if bold else None, wrap=True)
        y -= 0.024 if bold else 0.036
    top = y - 0.01
    for fr, sol in zip(frames, sols):
        x, yy, w = pos[fr.detector]
        ax = fig.add_axes([left + (x - w / 2 - xmin) / wid * (right - left),
                           bottom + (yy - w / 2 - ymin) / hei
                           * (top - bottom),
                           w / wid * (right - left),
                           w / hei * (top - bottom)])
        ny, nx = fr.shape
        if stage == "translation":
            quiver_panel(ax, sol["before"], nx, ny, 4.0)
            b = sol["before"]
            txt = (f"{fr.detector}\n({sol['dx']:+.0f}, {sol['dy']:+.0f}) px "
                   f"= {sol['offset_arcsec']:.0f}$''$, "
                   f"{sol['xcorr_sigma']:.0f}$\\sigma$\nleft: median "
                   f"({np.median(b['u']):+.1f}, {np.median(b['v']):+.1f}) "
                   f"px, n = {len(b['u'])}")
        else:
            quiver_panel(ax, sol["after"], nx, ny, 0.3, color="C0")
            txt = (f"{fr.detector}   n = {sol['nmatch']}, rms "
                   f"{sol['rms']:.2f} px\nscale {_pct(sol['sx'])}, "
                   f"{_pct(sol['sy'])}; rot {sol['rot']:+.3f}$^\\circ$\n"
                   f"shift ({sol['shift_arcsec'][0]:+.1f}, "
                   f"{sol['shift_arcsec'][1]:+.1f})$''$; cell max "
                   f"{sol['grid_max']:.2f} px")
        ax.text(0.03, 0.97, txt, transform=ax.transAxes, ha="left",
                va="top", fontsize=6,
                bbox=dict(fc="white", ec="none", alpha=0.85, pad=1.5))
        ax.set_xticks([0, nx // 2, nx])
        ax.set_yticks([0, ny // 2, ny])
        ax.tick_params(labelbottom=False, labelleft=False, length=2)
    path = os.path.join(out, f"{fr0.exposure}_focalplane_{stage}.png")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return path


def _ease_out(t: np.ndarray) -> np.ndarray:
    return 1.0 - (1.0 - np.clip(t, 0.0, 1.0)) ** 3


def animate_lock(fr: Frame, sol: dict, out: str, fps: int = 20,
                 zoom: int = 400) -> list[str]:
    """Animate the two steps: the reference stars (red) move from where
    the delivered gwcs puts them onto the image peaks (grey), first by
    the translation, then by the affine.  Upper left: the detector;
    the other panels: zooms at the centre and two corners.

    Returns:
        The files written (GIF; MP4 too when ffmpeg is available).
    """
    from matplotlib.animation import FFMpegWriter, FuncAnimation, \
        PillowWriter
    ny, nx = fr.shape
    px, py = sol["px"], sol["py"]
    g0 = np.column_stack([sol["xcorr_gx"], sol["xcorr_gy"]])
    g1 = g0 - np.array([sol["dx"], sol["dy"]])
    ix = np.flatnonzero((g1[:, 0] > -50) & (g1[:, 0] < nx + 50)
                        & (g1[:, 1] > -50) & (g1[:, 1] < ny + 50))
    # the stars of that set landing on the detector, at the corrected
    # positions: their sky positions come back through the delivered gwcs
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        ra, dec = fr.gwcs(g0[ix, 0], g0[ix, 1], with_bounding_box=False)
        g2 = np.column_stack(sol["gwcs"].invert(ra, dec,
                                                with_bounding_box=False))
    g0, g1 = g0[ix], g1[ix]
    tree = cKDTree(np.column_stack([px[:20000], py[:20000]]))
    n1, nh1, n2, nh2 = 3 * fps, fps, int(2.5 * fps), 2 * fps
    n_all = n1 + nh1 + n2 + nh2
    f_tr = np.ones(n_all)
    f_tr[:n1] = _ease_out(np.arange(n1) / (n1 - 1))
    f_af = np.zeros(n_all)
    f_af[n1 + nh1:n1 + nh1 + n2] = _ease_out(np.arange(n2) / (n2 - 1))
    f_af[n1 + nh1 + n2:] = 1.0
    fig, axes = plt.subplots(2, 2, figsize=(12, 12.4))
    ax = axes[0, 0]
    ax.scatter(px[:20000], py[:20000], s=0.5, c="0.6", lw=0,
               rasterized=True)
    sc = ax.scatter(g0[:, 0], g0[:, 1], s=1.0, c="C3", lw=0,
                    rasterized=True)
    ax.add_patch(plt.Rectangle((0, 0), nx, ny, fill=False, ec="k", lw=0.8,
                               zorder=3))
    lim = max(2500, abs(sol["dx"]) + 600, abs(sol["dy"]) + 600)
    ax.set_xlim(-lim, nx + lim)
    ax.set_ylim(-lim, ny + lim)
    ax.set_aspect("equal")
    ax.set_title("full detector (black box); blue boxes: the zooms",
                 fontsize=9)
    half = zoom / 2
    centres = [(nx / 2, ny / 2), (0.15 * nx, 0.85 * ny),
               (0.85 * nx, 0.15 * ny)]
    zsc, zsel = [], []
    for a, (x0, y0), lab in zip(axes.ravel()[1:], centres, "123"):
        ax.add_patch(plt.Rectangle((x0 - half, y0 - half), zoom, zoom,
                                   fill=False, ec="C0", lw=1.0, zorder=3))
        ax.text(x0 + half + 60, y0 + half, lab, color="C0", fontsize=11,
                weight="bold", ha="left", va="top")
        inz = (np.abs(px - x0) < half) & (np.abs(py - y0) < half)
        a.scatter(px[inz], py[inz], s=70, c="0.65", lw=0, zorder=1)
        s_ = np.zeros(len(g0), bool)
        for f in np.linspace(0, 1, 61):
            for g in (g0 + f * (g1 - g0), g1 + f * (g2 - g1)):
                s_ |= (np.abs(g[:, 0] - x0) < half + 60) \
                    & (np.abs(g[:, 1] - y0) < half + 60)
        zsel.append(s_)
        zsc.append(a.scatter(g0[s_, 0], g0[s_, 1], s=9, c="C3", lw=0,
                             zorder=2))
        a.set_xlim(x0 - half, x0 + half)
        a.set_ylim(y0 - half, y0 + half)
        a.set_aspect("equal")
        a.set_title(f"zoom {lab}: {zoom}$\\times${zoom} px around "
                    f"({x0:.0f}, {y0:.0f}), {inz.sum()} peaks", fontsize=9)
    for a in axes.ravel():
        a.set_xlabel("detector x [px]")
        a.set_ylabel("detector y [px]")
    off = sol["offset_arcsec"]
    fig.suptitle(
        f"{_label(fr)}: the alignment in two steps. Grey: image peaks "
        f"(fixed). Red: the {len(g0)} reference stars of the "
        f"cross-correlation set,\nmoving from where the delivered gwcs "
        f"puts them ({sol['dx']:+.0f}, {sol['dy']:+.0f}) px = {off:.0f}$''$"
        f" away, first by the translation, then by the affine fitted in "
        f"V2V3\n(scale {_pct(sol['sx'])}, {_pct(sol['sy'])}, rotation "
        f"{sol['rot']:+.3f}$^\\circ$; {sol['nmatch']} stars, rms "
        f"{sol['rms']:.2f} px).", fontsize=9.5, y=0.995)
    sub = fig.text(0.5, 0.925, "", ha="center", va="top", fontsize=10,
                   family="monospace")
    fig.subplots_adjust(top=0.875, bottom=0.05, left=0.06, right=0.98,
                        wspace=0.2, hspace=0.22)
    on = (g1[:, 0] > 0) & (g1[:, 0] < nx) & (g1[:, 1] > 0) & (g1[:, 1] < ny)
    phase = (["1: translation"] * n1 + ["hold"] * nh1 + ["2: affine"] * n2
             + ["hold (aligned)"] * nh2)

    def update(i: int):
        g = g0 + f_tr[i] * (g1 - g0) + f_af[i] * (g2 - g1)
        sc.set_offsets(g)
        for s_, sc_ in zip(zsel, zsc):
            sc_.set_offsets(g[s_])
        d, _ = tree.query(g[on], distance_upper_bound=2.0)
        sub.set_text(f"t = {i / fps:4.2f} s   phase {phase[i]:16s}"
                     f"   translation applied: {100 * f_tr[i]:3.0f}%   "
                     f"affine applied: {100 * f_af[i]:3.0f}%   "
                     f"stars within 2 px of a peak: "
                     f"{100 * np.isfinite(d).mean():4.1f}%")
        return sc,

    stem = os.path.join(out, fr.stem + "_lock")
    written = []
    if shutil.which("ffmpeg"):
        anim = FuncAnimation(fig, update, frames=n_all, blit=False)
        anim.save(stem + ".mp4", writer=FFMpegWriter(
            fps=fps, codec="libx264",
            extra_args=["-pix_fmt", "yuv420p", "-crf", "24", "-vf",
                        "scale=trunc(iw/2)*2:trunc(ih/2)*2"]), dpi=90)
        written.append(stem + ".mp4")
    sub_ = max(1, fps // 10)
    anim = FuncAnimation(fig, update, frames=range(0, n_all, sub_),
                         blit=False)
    anim.save(stem + ".gif", writer=PillowWriter(fps=fps // sub_), dpi=55)
    written.append(stem + ".gif")
    plt.close(fig)
    return written


# ---------------------------------------------------------------------------
# driver
# ---------------------------------------------------------------------------
def frame_cone(paths: list[str]) -> tuple[float, float, float]:
    """Centre and radius (deg) of the cone through the frames' delivered
    detector centres."""
    ra, dec = [], []
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for p in paths:
            with asdf.open(p, lazy_load=True, memmap=False) as af:
                r = af["roman"]
                ny, nx = r["data"].shape
                c = r["meta"]["wcs"](nx / 2, ny / 2, with_bounding_box=False)
                ra.append(np.radians(float(c[0])))
                dec.append(np.radians(float(c[1])))
    ra, dec = np.array(ra), np.array(dec)
    xyz = np.array([np.cos(dec) * np.cos(ra), np.cos(dec) * np.sin(ra),
                    np.sin(dec)]).mean(axis=1)
    xyz /= np.linalg.norm(xyz)
    c_ra = float(np.degrees(np.arctan2(xyz[1], xyz[0])) % 360)
    c_dec = float(np.degrees(np.arcsin(xyz[2])))
    sep = np.degrees(np.arccos(np.clip(
        np.sin(dec) * xyz[2] + np.cos(dec) * (
            np.cos(ra) * xyz[0] + np.sin(ra) * xyz[1]), -1, 1)))
    return c_ra, c_dec, float(sep.max())


# what plot_focal_plane reads from a solution
PANEL_KEYS = ("before", "after", "dx", "dy", "offset_arcsec", "xcorr_sigma",
              "sx", "sy", "rot", "shift_arcsec", "nmatch", "rms", "grid_max")


def process_frame(path: str, ref: Reference, out: str, s: Settings,
                  plots: bool = True, animate: bool = False,
                  write_asdf: bool = False) -> dict:
    """Align one frame and write its products.

    Returns:
        The summary dict, with the frame (without its image) and the
        part of the solution the focal-plane figure needs attached under
        ``_frame`` and ``_solution``; on failure a dict with ``error``.
    """
    fr = read_frame(path)
    t0 = time.time()
    try:
        sol = align(fr.gwcs, fr.data, ref, fr.epoch, s)
    except AlignError as e:
        print(f"{fr.stem}: FAILED: {e}", flush=True)
        return dict(input=path, stem=fr.stem, exposure=fr.exposure,
                    detector=fr.detector, error=str(e))
    summary = write_products(fr, sol, ref, out, s, write_asdf)
    if plots:
        summary["products"].append(os.path.basename(plot_steps(fr, sol,
                                                               out)))
        summary["products"].append(os.path.basename(
            plot_cutout(fr, sol, ref, out, s)))
    if animate:
        summary["products"] += [os.path.basename(p) for p in
                                animate_lock(fr, sol, out)]
    Path(os.path.join(out, fr.stem + "_summary.json")).write_text(
        json.dumps(summary, indent=1))
    print(f"{fr.stem}: offset ({sol['dx']:+.0f}, {sol['dy']:+.0f}) px = "
          f"{sol['offset_arcsec']:.1f} arcsec, {sol['xcorr_sigma']:.0f} "
          f"sigma; scale ({sol['sx']:.5f}, {sol['sy']:.5f}), rot "
          f"{sol['rot']:+.4f} deg; {sol['nmatch']} stars, rms "
          f"{sol['rms']:.2f} px, cell max {sol['grid_max']:.2f} px, SIP "
          f"{sol['sip_resid']:.4f} px  [{time.time() - t0:.0f} s]",
          flush=True)
    summary["_frame"] = replace(fr, data=None)
    summary["_solution"] = {k: sol[k] for k in PANEL_KEYS}
    return summary


def _worker(args):
    return process_frame(*args)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("inputs", nargs="+",
                   help="*_cal.asdf files or directories holding them")
    p.add_argument("--output-dir", default="gaia_wcs",
                   help="where the products go (default gaia_wcs)")
    p.add_argument("--detector", action="append", default=None,
                   help="process only this detector, e.g. WFI04 "
                        "(repeatable)")
    p.add_argument("--ref-file", default=None,
                   help="local reference catalogue instead of the Gaia "
                        "archive (whitespace text; see --ref-cols)")
    p.add_argument("--ref-cols", type=int, nargs="+",
                   default=[2, 3, 34, 5, 6],
                   help="1-based columns of RA, Dec, mag[, pmRA*, pmDec] "
                        "in --ref-file (default: gaia2msos rdpmx.out)")
    p.add_argument("--ref-epoch", type=float, default=2016.0,
                   help="Julian year of the --ref-file positions")
    p.add_argument("--gaia-cache", default=None,
                   help="directory of the Gaia cache (default: the "
                        "output directory)")
    p.add_argument("--no-plots", action="store_true",
                   help="skip the figures")
    p.add_argument("--animate", action="store_true",
                   help="also write the two-step animation per frame")
    p.add_argument("--write-asdf", action="store_true",
                   help="also write the corrected gwcs as ASDF")
    p.add_argument("--jobs", type=int, default=1,
                   help="frames processed in parallel")
    g = p.add_argument_group("algorithm constants")
    types = get_type_hints(Settings)
    for name, f in Settings.__dataclass_fields__.items():
        g.add_argument("--" + name.replace("_", "-"), type=types[name],
                       default=f.default,
                       help=f"{f.metadata['help']} (default %(default)s)")
    return p


def collect_inputs(inputs: list[str], detectors: Optional[list[str]]
                   ) -> list[str]:
    files = []
    for item in inputs:
        if os.path.isdir(item):
            files += sorted(str(p) for p in Path(item).glob("*_cal.asdf"))
        else:
            files.append(item)
    if detectors:
        want = {d.lower() for d in detectors}
        files = [f for f in files if any(
            f"_{d}_" in os.path.basename(f).lower() for d in want)]
    return files


def main(argv: Optional[list[str]] = None) -> int:
    p = build_parser()
    a = p.parse_args(argv)
    s = Settings(**{n: getattr(a, n) for n in Settings.__dataclass_fields__})
    try:
        s.validate()
    except ValueError as e:
        p.error(str(e))
    files = collect_inputs(a.inputs, a.detector)
    if not files:
        p.error("no *_cal.asdf inputs")
    out = a.output_dir
    os.makedirs(out, exist_ok=True)
    if a.ref_file:
        ref = load_reference_file(a.ref_file, tuple(a.ref_cols),
                                  a.ref_epoch)
        print(f"reference: {len(ref.ra)} stars from {a.ref_file}",
              flush=True)
    else:
        ra, dec, rmax = frame_cone(files)
        ref = fetch_gaia(a.gaia_cache or out, ra, dec,
                         rmax + s.field_padding, s)
        print(f"reference: {len(ref.ra)} Gaia stars (G < {s.g_limit:g}) "
              f"in a {rmax + s.field_padding:.3f} deg cone", flush=True)
    tasks = [(f, ref, out, s, not a.no_plots, a.animate, a.write_asdf)
             for f in files]
    if a.jobs > 1 and len(tasks) > 1:
        with get_context("fork").Pool(a.jobs) as pool:
            results = pool.map(_worker, tasks, chunksize=1)
    else:
        results = [_worker(t) for t in tasks]
    # per-exposure products
    by_exp: dict[str, list] = {}
    for r in results:
        by_exp.setdefault(r["exposure"], []).append(r)
    failed = [r for r in results if "error" in r]
    for exp, rs in by_exp.items():
        good = [r for r in rs if "error" not in r]
        rows = [{k: r[k] for k in (
            "detector", "dx", "dy", "offset_arcsec", "xcorr_sigma", "sx",
            "sy", "rot", "nmatch", "rms", "grid_max", "sip_resid")}
            for r in good]
        if rows:
            Table(rows=rows).write(os.path.join(out, f"{exp}_summary.ecsv"),
                                   overwrite=True, format="ascii.ecsv")
        if len(good) >= 2 and not a.no_plots:
            frs = [r["_frame"] for r in good]
            sols = [r["_solution"] for r in good]
            for stage in ("translation", "affine"):
                print("wrote", plot_focal_plane(frs, sols, out, stage),
                      flush=True)
    Path(os.path.join(out, "errors.json")).write_text(json.dumps(
        [{k: r[k] for k in ("input", "detector", "error")} for r in failed],
        indent=1))
    print(f"{len(results) - len(failed)} of {len(results)} frames aligned; "
          f"products in {os.path.abspath(out)}", flush=True)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
