"""Offline checks of gaia_wcs_correction.py.

A synthetic gwcs with a detector -> V2V3 -> world pipeline is built, a
"truth" copy gets a translation, scale and rotation inserted in V2V3 (as
an attitude error would), stars are rendered on an image at integer
pixels of the truth, and the alignment must recover the truth from the
nominal gwcs.  No data files and no network are needed.

    python -m unittest -v test_gaia_wcs_correction.py
"""
from __future__ import annotations

import json
import os
import tempfile
import unittest
import warnings
from unittest.mock import patch

import numpy as np
from astropy import units as u
from astropy.coordinates import ICRS
from astropy.io import fits
from astropy.modeling.fitting import LinearLSQFitter
from astropy.modeling.models import (AffineTransformation2D, Mapping,
                                     Pix2Sky_TAN, Polynomial2D,
                                     RotateNative2Celestial, Scale, Shift)
from astropy.wcs import WCS
from gwcs import WCS as GWCS
from gwcs import coordinate_frames as cf

import gaia_wcs_correction as m

NX, NY = 1200, 1000
RA0, DEC0 = 80.5, -69.7
PIXSCALE = 0.11          # arcsec / px


def distortion():
    """A cubic distortion of ~1 px at the corners with a fitted inverse,
    so that the synthetic gwcs inverts analytically like the real one."""
    fwd = Mapping((0, 1, 0, 1)) | (
        Polynomial2D(3, c1_0=1, c2_0=2e-6, c0_2=-1e-6, c1_1=1.5e-6,
                     c3_0=1e-9)
        & Polynomial2D(3, c0_1=1, c0_2=2.5e-6, c2_0=-1.5e-6, c1_1=1e-6,
                       c0_3=1e-9))
    g = np.linspace(-2200, 2200, 80)
    x, y = np.meshgrid(g, g)
    x, y = x.ravel(), y.ravel()
    ux, uy = fwd(x, y)
    n = 1000.0                      # conditioning of the inverse fit
    fit = LinearLSQFitter()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        inv_x = fit(Polynomial2D(9), ux / n, uy / n, x / n)
        inv_y = fit(Polynomial2D(9), ux / n, uy / n, y / n)
    fwd.inverse = (Mapping((0, 1, 0, 1))
                   | (Scale(1 / n) & Scale(1 / n) & Scale(1 / n)
                      & Scale(1 / n))
                   | (inv_x & inv_y) | (Scale(n) & Scale(n)))
    return fwd


def synthetic_gwcs() -> GWCS:
    """A WFI-like gwcs: detector -> v2v3 (arcsec) -> world."""
    rot = np.radians(25.0)
    det2v = (Shift(-(NX - 1) / 2) & Shift(-(NY - 1) / 2) | distortion()
             | AffineTransformation2D(
                 matrix=PIXSCALE * np.array([[np.cos(rot), -np.sin(rot)],
                                             [np.sin(rot), np.cos(rot)]]),
                 translation=[950.0, -1400.0]))
    v2sky = (Scale(1 / 3600) & Scale(1 / 3600) | Pix2Sky_TAN()
             | RotateNative2Celestial(RA0, DEC0, 180.0))
    det = cf.Frame2D(name="detector", axes_names=("x", "y"),
                     unit=(u.pix, u.pix))
    v2v3 = cf.Frame2D(name="v2v3", axes_names=("v2", "v3"),
                      unit=(u.arcsec, u.arcsec))
    world = cf.CelestialFrame(name="world", reference_frame=ICRS(),
                              unit=(u.deg, u.deg))
    return GWCS([(det, det2v), (v2v3, v2sky), (world, None)])


def make_scene(seed: int = 3):
    """Nominal gwcs, image, reference stars, truth pixels, on-detector
    mask."""
    rng = np.random.default_rng(seed)
    nominal = synthetic_gwcs()
    # the attitude error: ~600 px along v2, 100 px along v3, a 0.3
    # percent scale error and a 0.1 degree rotation
    ang = np.radians(0.1)
    mat = 1.003 * np.array([[np.cos(ang), -np.sin(ang)],
                            [np.sin(ang), np.cos(ang)]])
    truth = m.insert_v2v3_affine(
        nominal, mat, np.array([600 * PIXSCALE, 100 * PIXSCALE]))
    # reference stars on integer pixels of the truth frame: 1500 on the
    # detector (drawn on the image) and 2500 in the surroundings
    n = 4000
    xt = np.concatenate([rng.integers(20, NX - 20, 1500),
                         rng.integers(-2500, NX + 2500, 2500)]).astype(float)
    yt = np.concatenate([rng.integers(20, NY - 20, 1500),
                         rng.integers(-2500, NY + 2500, 2500)]).astype(float)
    mag = rng.uniform(12.0, 19.0, n)
    ra, dec = truth(xt, yt, with_bounding_box=False)
    on = (xt >= 20) & (xt < NX - 20) & (yt >= 20) & (yt < NY - 20)
    drawn = on & (rng.uniform(size=n) > 0.15)      # 15 percent missing
    img = rng.normal(0, 1.0, (NY, NX)).astype(np.float32)
    flux = 300.0 * 10 ** (-0.4 * (mag - 18.0))
    for x, y, f in zip(xt[drawn].astype(int), yt[drawn].astype(int),
                       flux[drawn]):
        img[y, x] += f
        img[y - 1:y + 2, x - 1:x + 2] += 0.25 * f
    # unrelated peaks not in the catalogue
    for _ in range(300):
        x, y = rng.integers(20, NX - 20), rng.integers(20, NY - 20)
        img[y, x] += rng.uniform(50, 500)
    ref = m.Reference(ra=ra, dec=dec, mag=mag, pmra=None, pmdec=None,
                      epoch=2016.0, source_id=np.arange(n), label="synth")
    return nominal, img, ref, xt, yt, on


SETTINGS = m.Settings(xcorr_half=1500.0, n_xcorr_ref=1500,
                      n_xcorr_peaks=1500, peak_floor=15.0, min_matches=50)


class AlignmentTests(unittest.TestCase):
    def test_recovers_v2v3_affine(self):
        nominal, img, ref, xt, yt, on = make_scene()
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            sol = m.align(nominal, img, ref, 2026.5, SETTINGS)
        self.assertGreater(sol["xcorr_sigma"], SETTINGS.xcorr_min_sigma)
        self.assertGreater(sol["nmatch"], 900)
        # the peaks sit on integer pixels, so the residual is set by the
        # fit and the inverse of the synthetic distortion alone
        self.assertLess(sol["rms"], 0.05)
        self.assertAlmostEqual(sol["sx"], 1.003, delta=2e-4)
        self.assertAlmostEqual(sol["sy"], 1.003, delta=2e-4)
        self.assertAlmostEqual(sol["rot"], 0.1, delta=0.005)
        # the corrected gwcs and the exported TAN-SIP header both put
        # every on-detector reference star back on its truth pixel
        gx, gy = sol["gwcs"].invert(ref.ra[on], ref.dec[on],
                                    with_bounding_box=False)
        self.assertLess(np.hypot(gx - xt[on], gy - yt[on]).max(), 0.1)
        hx, hy = sol["wcs"].all_world2pix(ref.ra[on], ref.dec[on], 0)
        self.assertLess(np.hypot(hx - xt[on], hy - yt[on]).max(), 0.1)
        self.assertLess(sol["sip_resid"], 0.01)
        # the header is self-contained
        hdr = m.wcs_header_cards(sol["wcs"])
        w = WCS(fits.Header(hdr))
        px, py = w.all_world2pix(ref.ra[on][:50], ref.dec[on][:50], 0)
        self.assertLess(np.hypot(px - xt[on][:50], py - yt[on][:50]).max(),
                        0.1)

    def test_pixel_space_affine_is_not_enough(self):
        """The reason the affine is composed in V2V3: with a large
        attitude error a pixel-space affine leaves a systematic field."""
        nominal, img, ref, xt, yt, on = make_scene()
        # a 1900 px offset and a rotated frame, as in the commissioning
        # data
        ang = np.radians(0.1)
        mat = 1.003 * np.array([[np.cos(ang), -np.sin(ang)],
                                [np.sin(ang), np.cos(ang)]])
        big = m.insert_v2v3_affine(nominal, mat,
                                   np.array([1900 * PIXSCALE, 300 * PIXSCALE]))
        xg, yg = np.meshgrid(np.linspace(20, NX - 20, 25),
                             np.linspace(20, NY - 20, 25))
        xg, yg = xg.ravel(), yg.ravel()
        ra, dec = big(xg, yg, with_bounding_box=False)
        px, py = nominal.invert(ra, dec, with_bounding_box=False)
        pred = np.column_stack([px, py])
        obs = np.column_stack([xg, yg])
        mtx, t, _, _ = m.fit_affine(pred, obs, niter=1)
        res = np.hypot(*((pred @ mtx.T + t) - obs).T)
        v2v3_fit = m.fit_affine(np.column_stack(
            nominal.get_transform("detector", "v2v3")(xg, yg)),
            np.column_stack(nominal.get_transform(
                "v2v3", "world").inverse(ra, dec)), niter=1)
        self.assertGreater(np.median(res), 0.1)
        self.assertLess(v2v3_fit[2], 1e-6)


class ReferenceTests(unittest.TestCase):
    def test_proper_motion_propagation(self):
        ref = m.Reference(ra=np.array([10.0]), dec=np.array([60.0]),
                          mag=np.array([15.0]), pmra=np.array([100.0]),
                          pmdec=np.array([-50.0]), epoch=2016.0,
                          source_id=None, label="t")
        ra, dec = ref.at_epoch(2026.0)
        # 100 mas/yr * 10 yr = 1 arcsec along RA*cos(Dec)
        self.assertAlmostEqual((ra[0] - 10.0) * np.cos(np.radians(60.0))
                               * 3600, 1.0, places=6)
        self.assertAlmostEqual((dec[0] - 60.0) * 3600, -0.5, places=6)

    def test_reference_file_columns(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "ref.out")
            with open(p, "w") as fh:
                fh.write("# comment\n")
                fh.write("1 80.0 -69.0 0.5 2.0 -3.0 " + "0 " * 27
                         + "16.5\n")
                fh.write("2 80.1 -69.1 0.5 0.0 0.0 " + "0 " * 27
                         + "17.5\n")
            ref = m.load_reference_file(p, (2, 3, 34, 5, 6), 2016.0)
            self.assertEqual(len(ref.ra), 2)
            self.assertEqual(ref.mag[1], 17.5)
            self.assertEqual(ref.pmra[0], 2.0)
            ref = m.load_reference_file(p, (2, 3, 34), 2016.0)
            self.assertIsNone(ref.pmra)

    def test_gaia_cache_reuse(self):
        """A cached cone covering the request is reused; a larger G
        limit or an uncovered cone triggers a query (mocked)."""
        calls = []

        def fake_tap(adql, out_path, **kw):
            calls.append(adql)
            with open(out_path, "w") as fh:
                fh.write("source_id,ra,dec,ref_epoch,pmra,pmdec,"
                         "phot_g_mean_mag,phot_rp_mean_mag,ruwe\n")
                fh.write("1,80.0,-69.0,2016.0,1.0,1.0,15.0,14.2,1.0\n")
                fh.write("2,80.1,-69.1,2016.0,1.0,1.0,16.0,,1.0\n")
        with patch.object(m, "tap_async", fake_tap), \
                tempfile.TemporaryDirectory() as d:
            s = m.Settings()
            ref = m.fetch_gaia(d, 80.0, -69.0, 0.5, s)
            self.assertEqual(len(calls), 1)
            self.assertEqual(len(ref.ra), 2)
            # RP ranking falls back to G where RP is missing
            np.testing.assert_allclose(ref.mag, [14.2, 16.0])
            m.fetch_gaia(d, 80.05, -69.02, 0.4, s)     # inside
            self.assertEqual(len(calls), 1)
            m.fetch_gaia(d, 81.5, -69.0, 0.4, s)       # outside
            self.assertEqual(len(calls), 2)
            m.fetch_gaia(d, 80.0, -69.0, 0.4,
                         m.Settings(g_limit=19.0))     # other limit
            self.assertEqual(len(calls), 3)
            name = sorted(f for f in os.listdir(d)
                          if f.endswith(".json"))[0]
            with open(os.path.join(d, name)) as fh:
                side = json.load(fh)
            self.assertIn("SELECT", side["adql"])


class SettingsTests(unittest.TestCase):
    def test_validation_and_cli(self):
        m.DEFAULTS.validate()
        for bad in (dict(rank_band="bp"), dict(peak_size=8),
                    dict(match_radii="1,2,4"), dict(min_matches=3)):
            with self.assertRaises(ValueError):
                m.Settings(**bad).validate()
        a = m.build_parser().parse_args(["x.asdf", "--peak-floor", "50",
                                         "--match-radii", "6,3,1.5"])
        self.assertEqual(a.peak_floor, 50.0)
        self.assertEqual(m.Settings(match_radii=a.match_radii).radii(),
                         (6.0, 3.0, 1.5))


if __name__ == "__main__":
    unittest.main()
