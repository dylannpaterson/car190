
"""Makes a quick look table from the solid-waffle outputs."""

import numpy as np
import os

print("# chip good  graw  gain   ipc   nl2*1E6 nl3*1E12 bfe*1E6 p2e[B1]")
prefix = "/data/chirata/sw-outputs/260912R/260912_three_YR_wfi"
order = 3
bad = 0
valid = 0
for sca in range(1, 19):
    fn = prefix + f"{sca:02d}_summary.txt"
    fvis = prefix + f"{sca:02d}_visinfo.txt"
    if os.path.exists(fn):
        valid += 1
        data = np.loadtxt(fn)
        nz = np.where(data[:, 2] > 0)
        bad += 1024 - len(nz[0])
        graw = np.mean(data[nz, 3])
        g = np.mean(data[nz, 5])
        ipc = np.mean(data[nz, 6:8])
        nl2 = np.mean(data[nz, 1 - order])
        nl3 = np.mean(data[nz, 2 - order])
        bfe = (np.mean(data[nz, 20]) + np.mean(data[nz, 24]) + np.mean(data[nz, 26]) + np.mean(data[nz, 30])) / 4.0
        line = f"   {sca:2d}  {len(nz[0]):4d} {graw:5.3f} {g:5.3f} {ipc:7.5f} {nl2 * 1.0e6:6.3f}  {nl3 * 1.0e12:7.3f}  {bfe * 1.0e6:6.3f}"
        omega = 0.0
        if os.path.exists(fvis):
            datavis = np.loadtxt(fvis)
            # op = np.sum(datavis[:,25:50].reshape((-1,5,5))[:,1:-1,1:-1].reshape((-1,9)), axis=1)  # <-- 3x3 kernel sum
            op = np.sum(datavis[:,25:50], axis=1)
            omega = np.nanmedian(op[datavis[:,-1]>1e-49])
        line += f"  {omega:6.4f}"
        print(line)
print(f"# {bad:d}/{1024*valid:d} bad superpixels")
