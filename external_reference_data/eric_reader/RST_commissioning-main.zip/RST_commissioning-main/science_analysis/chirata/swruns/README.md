# solid-waffle runs

## General notes

Use the `cdev` branch of `solid-waffle` for these (has a couple patches that allow it to run with the drop sequence).

Outputs go to `/data/chirata/sw-outputs` (I'm running thus on SMDC, US-East-1).
