Ice trending data and model files
#################################

Trending relative response files
================================

The trending data are in the files ``flat_ratio_cube_nl-*.fits``. They contain either 6 HDUs or 4 HDUs (legacy):

+------------+-----------------+-----------------------+-----------------------------------+
| Number     | Type            | Shape (example)       | Description                       |
+============+=================+=======================+===================================+
| 0/PRIMARY  | PrimaryHDU      | (3, 6, 4608, 92)      | Raw fits to the L1 data           |
+------------+-----------------+-----------------------+-----------------------------------+
| 1/TRDISP   | ImageHDU        | (3, 552, 4608)        | Raw fits to the L1 data           |
+------------+-----------------+-----------------------+-----------------------------------+
| 2/TIMESTMP | ImageHDU        | (92,)                 | Time stamps (MJD)                 |
+------------+-----------------+-----------------------+-----------------------------------+
| 3/TRNDCLN  | ImageHDU        | (552, 4608)           | Relative response, corrected      |
+------------+-----------------+-----------------------+-----------------------------------+
| 4/TEMP_MPA | ImageHDU        | (92,)                 | MPA temperature (K)               |
+------------+-----------------+-----------------------+-----------------------------------+
| 5/VOLTAGE  | ImageHDU        | (92, 7)               | MCT photodiode voltage (V)        |
+------------+-----------------+-----------------------+-----------------------------------+

The legacy files (4 HDUs) do not have the last 2 HDUs or the names.

The Primary HDU and HDU #1 (TRDISP)
-----------------------------------

HDU #1 contains the change in quadratic fit relative to the reference epoch:

- The first frame, ``data[0, :, :]``, is the change in reset-read --> starting level in DN.

- The second frame, ``data[1, :, :]``, is the relative response as defined by the linear coefficient (1 = same as reference).

- The third frame, ``data[2, :, :]``, is the change in the quadratic non-linearity coefficient in DN^-1.

Each frame has LED and epoch on the vertical axis (6x92=552 rows for 6 LEDs and 92 timestamps, LED increasing in the Outer for loop and epoch in the inner for loop); and super-pixel on the horizontal axis (here: 4608 columns).

The Primary HDU is a re-ordering as a 4D array so the LED is its own axis (axis 1) and the time slice is axis 3.

HDU #2 (TIMESTMP)
-----------------

This contains a vector of the time stamps as Modified Julian dates, including the reference epoch.

HDU #3 (TRNDCLN)
----------------

The corrected relative response for each:

- LED and epoch (vertical axis: 6x92=552, LED increasing in the Outer for loop and epoch in the inner for loop)

- super-pixel (horizontal axis: here 4608)

HDU #4 (TEMP_MPA)
-----------------

A vector of the mosaic plate temperatures at each epoch.

HDU #5 (VOLTAGE)
----------------

A table of the voltages on the mercury cadmium telluride photodiode (to monitor the RCS output) at each epoch. Each row has 7 values; in order for Dark, Band 1 ... Band 6.

Fit files
=========

The ice fit files, ``icefit-*.fits``, contain the following HDUs:

+----------+---------------+----------------------+------------------------+
| Name     | Type          | Example shape        | Description            |
+==========+===============+======================+========================+
| PRIMARY  | PrimaryHDU    | (98, 4608)           | Fit parameters         |
+----------+---------------+----------------------+------------------------+
| WATERFAL | ImageHDU      | (117, 4618)          | Display image of fit   |
+----------+---------------+----------------------+------------------------+
| RESID    | ImageHDU      | (18, 16, 16)         | RMS residuals          |
+----------+---------------+----------------------+------------------------+
| TIMESTMP | ImageHDU      | (91,)                | Times since initial    |
|          |               |                      | epoch                  |
+----------+---------------+----------------------+------------------------+
| FPAPLOT  | ImageHDU      | (6, 258, 416)        | FPA layout plots of the|
|          |               |                      | fit quantities         |
+----------+---------------+----------------------+------------------------+
| RELRSP   | ImageHDU      | (91, 91, 4608)       | Relative response vs.  |
|          |               |                      | time & wavelength      |
+----------+---------------+----------------------+------------------------+
| RELRSP2  | ImageHDU      | (39, 91, 4608)       | Relative response vs.  |
|          |               |                      | ice thickness &        |
|          |               |                      | wavelength             |
+----------+---------------+----------------------+------------------------+
| RESID_B  | ImageHDU      | (546, 4608)          | Detailed fit residuals |
+----------+---------------+----------------------+------------------------+

These are regularized least-squares fits to the trending data for each super-pixel. The degrees of freedom allowed are:

- A 6-parameter anti-reflection coating. (The median and interquartile range of the parameters are removed by a shift+rescaling before the file is written.)

- A gray offset after each decontamination.

- A thickness at each epoch.

The "regularized" part is that the 2nd derivative of the ice thickness within a decontamination cycle is included as a penalty term in the least-squares fit. This prevents spurious features around the extrema in Bands 1 and 2 if the model does not quite reach the correct maximum or minimum. The regularization parameter is in the ``REGPAR`` keyword in the Primary HDU.

The Primary HDU
---------------

The primary HDU shape is (98, 4608), which indicates 98 parameters and 4608 super-pixels. Here ``4608 = 18 * 16**2``, so there are 16x16 super-pixels per SCA. The supper-pixels are ordered in Science frame, starting with WFI01, then WFI02 ... and within each one the ordering is super-pixel row and then super-pixel column.

The parameters are the AR coating (6 parameters per super-pixel); the gray offsets after each decontamination (1 parameter per super-pixel); and the ice thicknesses at each epoch (91 parameters per super-pixel).

Gray offsets are such that, e.g., 0.005 indicates that a pixel is 0.5% more responsive after that decontamination than in the initial cycle. Thicknesses are in microns.

The dimensionality information is contained in the following keywords:

+--------------+---------+---------------------------------------------------+
| Keyword      | Example | Description                                       |
|              | value   |                                                   |
+==============+=========+===================================================+
| ``NSCA``     | 18      | Number of chips                                   |
+--------------+---------+---------------------------------------------------+
| ``NSPRPIX``  | 4608    | Total number of super-pixels                      |
+--------------+---------+---------------------------------------------------+
| ``NPERAXIS`` | 16      | Number of super-pixels on each axis               |
+--------------+---------+---------------------------------------------------+
| ``NTSTAMP``  | 91      | Number of epochs, excluding the initial reference |
+--------------+---------+---------------------------------------------------+
| ``NRESET``   | 1       | Number of decontaminations internal to the        |
|              |         | sequence (excluding initial cooldown)             |
+--------------+---------+---------------------------------------------------+
| ``MJDINIT``  | 61295.06| Modified Julian Date of the initial epoch         |
+--------------+---------+---------------------------------------------------+
| ``REGPAR``   | 0.2     | Regularization parameter: a 2nd derivative of 1   |
|              |         | micron/day^2 is penalized the same amount as this |
|              |         | fractional error in the fit.                      |
+--------------+---------+---------------------------------------------------+

The WATERFAL HDU
----------------

This is a displayable image of the results. It shows AR coating parameters (again, with medians and scale masked) along the bottom; time since decontamination in days on the left; the ice thicknesses (in tens of nm) in the main plot; the gray terms (in parts per thousand) above; and the RMS residuals (in parts per thousand) along the top.

The RESID HDU
-------------

This is a map of the RMS residuals, reordered into SCA, pixel y, pixel x (so in DS9 the 18 SCAs show as a movie).

The TIMESTMP HDU
----------------

This is a 1D vector of the time stamps excluding the initial cooldown (here: 91 epochs). They are in days since the initial epoch.

The FPAPLOT HDU
---------------

This is a 3D cube that can be displayed as a series of frames, i.e. ``hdlust["FPAPLOT"].data[a, :, :]`` is a 2D array of the ``a`` th quantity to be plotted arranged to show the focal plane. Values not in an SCA are set to 1e9 so that when displayed on most scales they show as a white background.

Decontamination cycles (labeled ``c`` below) are counted starting at ``c=0`` (initial cooldown), ``c=1`` (after first decontamination), etc., all the way through the last cycle (``c=NRESET``).

The ordering of quantities is:

+---------------+---------------------------------------------------+
| Number (``a``)| Description                                       |
+===============+===================================================+
|   0           | Deposition rate in cycle 0 (nm/day)               |
+---------------+---------------------------------------------------+
|   1           | Ice thickness at first epoch in cycle 0 (nm)      |
+---------------+---------------------------------------------------+
|   ``3*c-1``   | Gray correction in cycle ``c``                    |
+---------------+---------------------------------------------------+
|   ``3*c``     | Deposition rate in cycle ``c`` (nm/day)           |
+---------------+---------------------------------------------------+
|   ``3*c+1``   | Ice thickness at first epoch in cycle ``c`` (nm)  |
+---------------+---------------------------------------------------+
| ``3*NRESET+2``| RMS residual of the overall fit                   |
+---------------+---------------------------------------------------+

The total number of slices of the image is ``3*NRESET+3``.

The RELRSP HDU
--------------

The relative response (sensitivity of that super-pixel relative to zero ice thickness). Note this is just from the ice effect and does *not* include the gray term.

The image shape is 91 (number of epochs) x 91 (number of wavelengths) x 4608 (number of super-pixels). The wavelength grid is equally spaced in frequency, and is defined by the keywords ``IWLMIN``, ``IWLMAX``, and ``NIWL``:

.. code-block:: python

    hdr = hdulist["RELRSP"].header
    wl = 1./np.linspace(hdr["IWLMIN"], hdr["IWLMAX"], hdr["NIWL"])

Note that the wavelengths are in microns, and are ordered from bluest (displays at the bottom of the image in DS9) to reddest (displays at the top). In the example case, ``IWLMIN=2.2``, ``IWLMAX=0.4``, and ``NIWL=91``, so the wavelength grid ranges from ``wl[0]=0.455`` microns (bluest) to ``wl[45]=0.769`` microns (middle) to ``wl[90]=2.500`` microns (reddest).

The RELRSP2 HDU
---------------

This is similar to the RELRSP HDU, but the "frame" axis is the ice thickness. So in this case the image shape is 39 (number of thicknesses) x 91 (number of wavelengths) x 4608 (number of super-pixels).

The thickness grid is defined by the keywords ``TKMIN``, ``TKMAX``, and ``NTK``:

.. code-block:: python

    hdr = hdulist["RELRSP2"].header
    wl = 1./np.linspace(hdr["IWLMIN"], hdr["IWLMAX"], hdr["NIWL"])
    thicknesses = np.linspace(hdr["TKMIN"], hdr["TKMAX"], hdr["NTK"])

Again, thicknesses are in microns.

The RESID_B HDU
---------------

This is the full set of residuals from the fit. The shape is 546 x 4608: here the number of rows is 546 = 6 x 91 (6 LEDs x 91 time epochs) and there is one column for each of the 4608 super-pixels.

Scripts
=======

The above files are generated by several scripts.

RCS phtometric trending
-----------------------

The trending files are now generated using `science_analysis/chirata/trends/build_trend_file.py` (replacing the legacy `science_analysis/chirata/trends/trend_data_all.py`). The new workflow is driven by a YAML file:

.. code-block:: bash

   python build_trend_file.py icetrend.yaml --update

Here the ``--update`` flag tells the script that the trend file already exists and we just need to append more data. The trend configuration is in YAML:

.. code-block:: yaml

    ---
    # Ice trending configuration file
    PASSTABLE: /home/chirata/work/trends/passlist.txt  # the pass list
    TEMPDIR: /tmp/tempdata-chirata2  # temporary working location
    NSEGMENT: 16  # 16x16 super-pixels per SCA
    TRANGE:
      - "2026-09-12T00:00:00"  # start time
      - "2026-11-01T14:00:00"  # end time
    STEP:
      - [14]  # ACM deploy
      - [33, 55]  # ACM 3 mm defocus
      - [72]  # RCS side A-B swap
    OUT: /data/chirata/ice-trends/trend.fits  # output file
    NT: 100  # only do this many epochs
    ...

Here the PASSTABLE keyword points to a text-based table of programs/ execution plans/ passes to use::

  # data used for the ice trending
  # program, execution plan, pass
   1039  2   1
   1039  2   2
   1039  2   3
  ..
   1063  5  18
   1063  5  19


The TEMPDIR keyword indicates where to store temporary files.

The NSEGMENT keyword tells us the number of super-pixels to use.

The TRANGE keyword contains a list of which start and end time to pull engineering data (must span the range of observations).

The STEP keyword contains a list of steps to remove from the trend. Steps with one epoch remove a step at that epoch based on a quadratic fit to each side. Steps with two epochs remove a step that goes back at the latter epoch.

The OUT keyword is the file to write to.

The optional NT keyword truncates the PASSTABLE at the specified number of epochs.

Ice model fit
-------------

This workflow is driven by a YAML file:

.. code-block:: yaml

  ---
  TREND: trend.fits
  OUTPUT: icefit-261102.fits
  IWL: [2.2, 0.4, 91]  # inverse wavelength: blue, red, number
  ICE_T: [-0.02, 0.36, 39]  # thickness table: thinnest, thickest, number
  MAX_WORKERS: 84  # number of parallel workers
  T_RESET:
    - 12.90693  # after 1st decon (days after start)
    - 38.79791  # after 2nd decon (days after start)
  REGPAR: 0.2  # 1 nm/day^2 2nd deriv is equivalent to 0.2 parts per thousand   response error
  MODS:
    BAND1WT: 0.5  # weight Band 1 residuals with a factor of 0.5
  # STOP: 256  # stop at this super-pixel
  # DSKIP: 8  # do only every 8th super-pixel
  ...

YAML file ingredients
^^^^^^^^^^^^^^^^^^^^^

The key **required** elements are:

- ``TREND`` : The input trend file.

- ``OUTPUT`` : The output ice model file. (Must be ``*.fits``; a ``*_thickness.dat`` file will also be generated containing a summary of ice thicknesses in microns on each SCA with time stamps in days.)

- ``IWL`` : inverse wavelengths for the model grid (units: microns^-1) in ``numpy.linspace`` format.

- ``ICE_T`` : ice thicknesses for the model grid (units: microns) in ``numpy.linspace`` format.

- ``T_RESET`` : the reset times in days since the first epoch. Delineates different trending regions.

The **optional** elements are:

- ``MODS`` : a table of possible modifications to the fit; possible tags include:

  - ``BAND1WT`` through ``BAND6WT`` : weight residuals in each band by this factor.

- ``STOP`` : if un-commented, stop at that super-pixel (useful for testing).

- ``DSKIP`` : if un-commented, only do every nth super-pixel (useful for testing).

- ``REGPAR`` : regularize the fit by penalizing a 1 nm/day^2 2nd derivative of the ice accumulation with the same weight as REGPAR parts per thousand error in the response.

- ``MAX_WORKERS`` : the maximum number of workers to use.

Running the code
^^^^^^^^^^^^^^^^

You should include in your slurm script something like:

.. code-block:: bash

  export NUMBA_NUM_THREADS=1
  export OMP_NUM_THREADS=1
  export ICEFIT_ROTATION_KEY=42  # choose your favorite integer
  python icefit.py fit1.yaml  # give the YAML file

The ``NUMBA_NUM_THREADS`` and ``OMP_NUM_THREADS`` environment variables are necessary for efficient execution since the code is parallelized at a higher level. The ``ICEFIT_ROTATION_KEY`` integer chooses a way to transform the basis so that printouts used to diagnose convergence, etc. in the logfiles do not correspond to physical indices of refraction and layer thicknesses. The code does not save the ``ICEFIT_ROTATION_KEY`` value in the output file.
