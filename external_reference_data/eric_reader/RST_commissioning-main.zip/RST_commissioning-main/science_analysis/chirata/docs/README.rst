HLIS PIT flat/dark group fit outputs
####################################

This contains the documentation for:

- `CAR 216 gain & IPC analyses <car216.rst>`_.

- `Ice trending analyses <ice.rst>`_.

Accessing the data
==================

On SMDC, you can read this data from ``/mnt/smdc-rom-com-ops/rrn-ops/chirata/``.

On RRN, you can read from the S3 bucket, ``s3://smdc-rom-com-ops/rrn-ops/chirata``. For example (try this in a Jupyter notebook on RRN!):

.. code-block:: python

    import s3fs
    from astropy.io import fits
    import numpy as np

    # See what there is
    fs = s3fs.S3FileSystem()
    osu_data_dir = "s3://smdc-rom-com-ops/rrn-ops/chirata"
    print(fs.ls(osu_data_dir))
    print("---")
    print(fs.ls(f"{osu_data_dir}/car216-results"))
    print("---")
    print(fs.ls(f"{osu_data_dir}/ice-results"))

    # Open the IPC file
    with fits.open(f"{osu_data_dir}/car216-results/ipc_car216_261008.fits") as f:
        print(f.info())
        print("---")
        print(f[0].header)
        print("---")
        array_median_ipc_h = np.nanmedian(f["IPC_HORZ"].data, axis=0)
        # median alpha_h per epoch, remembering that failed values are NaNs

    # print the median IPC coefficient for each of the 126 passes
    with np.printoptions(threshold=np.inf), np.printoptions(formatter={'float': '{:5.3f}'.format}):
        print(np.round(array_median_ipc_h / 0.01, 3))

The following folders are available in the `chirata` directory:

- `car216-results` : gain & IPC results from decontamination #1 (2026/09/25+)
- `car216-sw-decon-261020` : solid-waffle outputs from decontamination #2 (2026/10/20+)
- `ice-results` : ice trending results
- `sw-64` : 64x64 solid-waffle runs from CAR 216, decontamination #1 (2026/09/25+)
