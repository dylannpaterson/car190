"""RCS trending scripts.

Usage:

python trend_data.py cfg # first time
python trend_data.py cfg --update # just add fields

"""

import os
import subprocess
import sys

import asdf
import numpy as np
import yaml
from astropy.io import fits
from astropy.time import Time

# Download command; shouldn't need to mess with this except for unit tests.
_dlcommand = [subprocess.run]


class MnemonicTable:
    """Builds a data table from a given filename.

    Parameters
    ----------
    filename : str
        The file name for the input file.

    Attributes
    ----------
    n : int
        Number of points in table.
    t : np.ndarray of float
        1D table of timestamps, length `n`, in MJD.
    data : np.ndarray of float
        1D table of that mnemonic.

    """

    def __init__(self, filename):
        with open(filename) as fn:
            data = fn.readlines()[1:]
            self.n = len(data)
            self.t = np.zeros(self.n)
            self.data = np.zeros((self.n,), dtype=np.float32)

        print("<<", filename, data[-1])
        if self.n <= 1:
            raise ValueError("trend file too short")
        for j in range(self.n):
            if j % 100000 == 0:
                print(f"{j}/{self.n}", flush=True)
            vals = data[j].rstrip().split(",")
            self.t[j] = Time(vals[0], format="isot", scale="utc").mjd
            self.data[j] = float(vals[1])

    def signal(self, t1, t2):
        """Gets the mean signal between two times.

        Parameters
        ----------
        t1, t2 : float or str
            Times in MJD or ISO timestring.

        Returns
        -------
        float
            Mean signal in that time window.
        """

        _t1 = t1 if isinstance(t1, float) else Time(t1, format="isot", scale="utc").mjd
        it1 = np.searchsorted(self.t, _t1)
        _t2 = t2 if isinstance(t1, float) else Time(t2, format="isot", scale="utc").mjd
        it2 = np.searchsorted(self.t, _t2)
        return np.mean(self.data[it1 + 1 : it2])

    def signal_from_exp(self, fn):
        """Gets the mean signal in an exposure.

        Parameters
        ----------
        fn : str
            File name.

        Returns
        -------
        float
            Mean signal in that time window.
        """

        with asdf.open(fn) as a:
            exposure = a["roman"]["meta"]["exposure"]
            s = self.signal(exposure["start_time"], exposure["end_time"])
        return s


def _squash(tree, order=2):
    """Compresses a tree into a 2D flux image via quadratic fit.

    Returns fits (order+1, ny, nx).
    """

    d = tree["roman"]["data"].astype(np.float32)
    t = np.array(tree["roman"]["meta"]["exposure"]["read_pattern"], dtype=np.float64).ravel()

    # squash back
    if t[-1] == 13 and tree["roman"]["meta"]["exposure"]["ma_table_name"] == "IM_DIAGNOSTIC":
        print("squashing -->", tree["roman"]["meta"]["exposure"]["start_time"])
        t = np.array([1, 4, 7, 10, 13])
        d = np.zeros((5, 4096, 4096), dtype=np.float32)
        for j in range(5):
            d[j] = tree["roman"]["data"][3 * j].astype(np.float32)

    # get weights in the time dimension
    n = order + 1
    m = np.zeros((n, n))
    b = np.zeros((n, len(t)))
    for i in range(n):
        for j in range(n):
            m[i, j] = np.sum(t ** (i + j))
        for j in range(len(t)):
            b[i, j] = t[j] ** i
    w = np.linalg.solve(m, b).astype(np.float32)
    return np.einsum("pt,tij->pij", w, d)


def stepquad(t, npost=2):
    """Gets the weights to fit a step on a quadratic background.

    Model fit is f(t) = at^2 + bt + c + d{1 if t>=t2, 0 if t<=t1};
    returns the weights in d = sum_j w_j f(t_j).

    If `npost` is given, changes the number of samples that are
    assumed to be after the step.

    Parameters
    ----------
    t : np.ndarray of float
        Length 4; times t0, t1, t2, t3.
    npost : int
        Number of samples after the step.

    Returns
    -------
    w : np.ndarray of float
        Weights for those times.

    """

    # first, get matrix m with f(t_j) = m[j, k] v[k] where v = {a, b, c, d}

    m = np.zeros((4, 4))
    m[:, 0] = np.array(t) ** 2
    m[:, 1] = np.array(t)
    m[:, 2] = 1.0
    m[-npost:, 3] = 1.0

    return (np.linalg.inv(m.T @ m) @ m.T)[-1]


def destep_image(arr, t, idx):
    """Removes steps in the last axis (time axis) of the array due to ACM deploy.

    `arr` is updated in place.

    Parameters
    ----------
    arr : np.ndarray of float
        The data array; last axis is time.
    t : np.ndarray of float
        The time stamps.
    idx : int
        Which index is right after the step.

    Returns
    -------
    None

    """

    logarr = np.log(arr)
    w = stepquad(t[idx - 2 : idx + 2])

    steps = np.einsum("...j,j->...", logarr[..., idx - 2 : idx + 2], w)
    logarr[..., idx:] -= steps[..., None]
    arr[...] = np.exp(logarr)


def destep_image2(arr, t, idx):
    """Removes steps in the last axis (time axis) of the array due to ACM move with
    only one sample after.

    `arr` is updated in place.

    Parameters
    ----------
    arr : np.ndarray of float
        The data array; last axis is time.
    t : np.ndarray of float
        The time stamps.
    idx : int
        Which index is right after the step.

    Returns
    -------
    None

    """

    logarr = np.log(arr)
    w = stepquad(t[idx - 3 : idx + 1], npost=1)

    steps = np.einsum("...j,j->...", logarr[..., idx - 3 : idx + 1], w)
    steps = np.mean(steps, axis=0)[None, ...]
    logarr[..., idx:] -= steps[..., None]
    arr[...] = np.exp(logarr)


def build_trend_file_main(cfg, nt=None, update=False):
    """Builds a trending file from a configuration.

    Parameters
    ----------
    cfg : dict
        The configuration for the trend.

        The required fields are:

        - ``PASSTABLE`` : numpy array of int, shape (number of epochs, 3) with columns:
          0 = program; 1 = execution plan, 2 = pass number

        - ``TEMPDIR`` : the temporary directory to work in

        - ``NSEGMENT`` : number of segments (integer, power of 2)

        - ``TRANGE`` : list of 2 ISO time strings, e.g., ``2026-09-12T00:00:00``,
          denoting the range of voltages and temperatures to pull from MAST.

        - ``OUT`` : the output FITS file

        Optional:

        - ``NT`` : int, override other specifications on the number of timestamps to use.

        - ``STEP`` : list of list of int

          Each item triggers a step correction. If the item has one number, implements
          a step starting at that value; if there are 2 numbers, implements a step starting
          at the first value and ending just before the 2nd.

    nt : int, optional
        What time stamp to update to? (Defaults to all.)
    update : bool, optional
        Whether to update instead of building from scratch.

    Returns
    -------
    None

    """

    passtable = np.loadtxt(cfg["PASSTABLE"], dtype=np.int32)
    if nt is None:
        nt = np.shape(passtable)[0]
    if "NT" in cfg:
        nt = cfg["NT"]

    nsca = 18
    nled = 6
    nseg = cfg["NSEGMENT"]  # number of segments, must be a power of 2
    norder = 2  # order of polynomial fit

    cube = np.zeros((norder + 1, nled, nsca, nseg, nseg, nt), dtype=np.float32)
    tm = np.zeros(nt)
    voltages = np.zeros((nt, 7))
    temp_trend_data = np.zeros(nt)

    if update:
        with fits.open(cfg["OUT"]) as f:
            nt_old = len(f["TIMESTMP"].data)
            tm[:nt_old] = f["TIMESTMP"].data[:nt_old]
            cube[:, :, :, :, :, :nt_old] = (
                f[0].data[..., :nt_old].reshape((norder + 1, nled, nsca, nseg, nseg, nt_old))
            )
            voltages[:nt_old, :] = f["VOLTAGE"].data
            temp_trend_data[:nt_old] = f["TEMP_MPA"].data

    # get voltage data
    proc = [
        "curl",
        "-X",
        "GET",
        (
            "https://mast.stsci.edu/edp/api/v0.1/mnemonics/spa/roman/data?mnemonic=WFI_MCE_SRCS_PD2_V"
            f"&s_time={cfg["TRANGE"][0]}&e_time={cfg["TRANGE"][1]}&result_format=csv"
        ),
        "-H",
        os.path.expandvars("Authorization: token $MAST_API_TOKEN"),
        "--compressed",
        "--output",
        f"{cfg["TEMPDIR"]}/voltage.csv",
    ]
    _dlcommand[0](proc, capture_output=True, text=True)
    voltage_table = MnemonicTable(f"{cfg["TEMPDIR"]}/voltage.csv")

    # get the temperature data
    proc = [
        "curl",
        "-X",
        "GET",
        (
            "https://mast.stsci.edu/edp/api/v0.1/mnemonics/spa/roman/data?mnemonic=WFI_MCE_ADC_WTSM00"
            f"&s_time={cfg["TRANGE"][0]}&e_time={cfg["TRANGE"][1]}&result_format=csv"
        ),
        "-H",
        os.path.expandvars("Authorization: token $MAST_API_TOKEN"),
        "--compressed",
        "--output",
        f"{cfg["TEMPDIR"]}/temperature.csv",
    ]
    _dlcommand[0](proc, capture_output=True, text=True)
    temp_table = MnemonicTable(f"{cfg["TEMPDIR"]}/temperature.csv")

    # need to check each SCA in each Band at each time
    usefiles = []
    for isca in range(nsca):
        # dark image
        dks = []

        for iled in range(-1, nled):
            leds = f"{iled+2:1d}"
            for it in range(nt):
                thisrow = passtable[it]
                _f = (
                    f"r{thisrow[0]:05d}{thisrow[1]:02d}{thisrow[2]:03d}00100{leds}001_0001"
                    f"_wfi{isca+1:02d}_dark"
                )
                fn1 = _f + "%2F"
                fn2 = _f + "_uncal.asdf"
                print(f"sca={isca}, led={iled} it={it}", flush=True)

                if isca == 0 and iled == 0:
                    usefiles.append(fn2)

                if update and it < nt_old and it != 0:
                    if iled == -1:
                        dks.append(None)  # won't need this value, but need to put in a spacer
                    continue

                fn2t = cfg["TEMPDIR"] + "/" + fn2
                print("fetching:", fn2, flush=True)

                # pull data and compress into 2D cube
                proc = [
                    "curl",
                    "-H",
                    os.path.expandvars("Authorization: token $MAST_API_TOKEN"),
                    "-L",
                    "-X",
                    "GET",
                    "https://mast.stsci.edu/search/roman/api/v0.1/retrieve_product?product_name="
                    + fn1
                    + fn2
                    + "",
                    "--output",
                    fn2t,
                    "--fail",
                    "--create-dirs",
                ]
                _dlcommand[0](proc, capture_output=True, text=True)

                # get the voltage
                if isca == 0:
                    voltages[it, iled + 1] = voltage_table.signal_from_exp(fn2t)

                # and the MPA temperature
                if iled == 3 and isca == 0:
                    temp_trend_data[it] = temp_table.signal_from_exp(fn2t)

                # dark
                if iled == -1:
                    with asdf.open(fn2t) as a:
                        dks.append(_squash(a, order=1)[1].astype(np.float16))
                    print(
                        f"time {it:3d} sca {isca+1:2d} dark = {np.nanmedian(dks[-1]):11.5E} DN/read",
                        flush=True,
                    )
                    # cleanup
                    os.remove(fn2t)
                    continue

                # now we've got a flat
                with asdf.open(fn2t) as a:
                    data = _squash(a)
                    if isca == 0 and iled == 0:
                        tm[it] = a["roman"]["meta"]["ephemeris"]["time"]
                data[1] -= dks[it]  # dark subtraction!

                if it == 0:
                    data0 = np.copy(data)

                    # force reference pixels to nan
                    data0[:, :, :4] = np.nan
                    data0[:, :, -4:] = np.nan
                    data0[:, :4, :] = np.nan
                    data0[:, -4:, :] = np.nan

                # 0 term is constant -- just in DN
                # so cube[0, ...] is the bias change from initial epoch
                cube[0, iled, isca, :, :, it] = np.nanmedian(
                    (data[0] - data0[0]).reshape((nseg, 4096 // nseg, nseg, 4096 // nseg)), axis=(1, 3)
                )
                print(": 0", np.nanmedian(cube[0, iled, isca, :, :, it]))

                for ip in range(1, norder + 1):
                    if ip == 1:
                        # cube[1, ...] is the linear flux ratio from initial epoch
                        medratio = np.nanmedian(
                            (data[1] / data0[1]).reshape((nseg, 4096 // nseg, nseg, 4096 // nseg)),
                            axis=(1, 3),
                        )
                    else:
                        # cube[2, ...] is the change in quadratic term in DN^-1 relative to the initial epoch
                        medratio = np.nanmedian(
                            (data[ip] / data[1] ** ip - data0[ip] / data0[1] ** ip).reshape(
                                (nseg, 4096 // nseg, nseg, 4096 // nseg)
                            ),
                            axis=(1, 3),
                        )
                    cube[ip, iled, isca, :, :, it] = medratio
                    print(
                        ":",
                        ip,
                        np.median(data[ip]),
                        np.median(data0[ip]),
                        np.nanmedian(medratio),
                        np.count_nonzero(np.isfinite(medratio)),
                    )
                # cleanup
                os.remove(fn2t)

    # photodiode trending
    trend = voltages[:, 1:] - voltages[:, 0][:, None]
    trend /= trend[0][None, :]

    # make image, 2D version, and time stamps
    im = fits.PrimaryHDU(cube.reshape((norder + 1, nled, nsca * nseg**2, nt)))
    im2d = fits.ImageHDU(
        np.transpose(cube.reshape((norder + 1, nled, nsca * nseg**2, nt)), axes=(0, 1, 3, 2)).reshape(
            (norder + 1, nled * nt, nsca * nseg**2)
        ),
        name="TRDISP",
    )
    tmi = fits.ImageHDU(tm, name="TIMESTMP")

    # destepped version
    arr = (cube[1] / trend.T[:, None, None, None, :]).astype(np.float32, copy=False)
    for s in cfg["STEP"]:
        if len(s) == 1 and nt >= s[0] + 2:
            destep_image(arr, tm, s[0])
        if len(s) == 2 and nt >= s[0] + 1:
            destep_image2(arr[..., : s[1]], tm, s[0])
    im_destep = fits.ImageHDU(
        np.transpose(arr.reshape((nled, nsca * nseg**2, nt)), axes=(0, 2, 1)).reshape(
            (nled * nt, nsca * nseg**2)
        ),
        name="TRNDCLN",
    )

    thdu = fits.ImageHDU(temp_trend_data, name="TEMP_MPA")
    vhdu = fits.ImageHDU(voltages, name="VOLTAGE")

    fits.HDUList([im, im2d, tmi, im_destep, thdu, vhdu]).writeto(cfg["OUT"], overwrite=True)


if __name__ == "__main__":
    with open(sys.argv[1]) as f:
        cfg = yaml.safe_load(f)
    update = sys.argv[-1] == "--update"
    build_trend_file_main(cfg, update=update)
