"""RCS trending scripts.

Usage:

python trend_data.py nt # first time
python trend_data.py nt --update # just add fields

"""

import asdf
from astropy.io import fits
import numpy as np
import os
import subprocess
import sys
import time

tdir = "tempimage2"

nsca = 18
nt = int(sys.argv[1])
nled = 6
nseg = 16  # number of segments, must be a power of 2

norder = 2  # order of polynomial fit

cube = np.zeros((norder+1, nled, nsca, nseg, nseg, nt), dtype=np.float32)


import os
import subprocess

import asdf
import numpy as np
from astropy.time import Time

class MnemonicTable():
    """Builds a data table from a given filename.

    Parameters
    ----------
    filename : str
        The file name for the input file.

    Attributes
    ----------
    n : int
        Number of points in table.
    t : np.ndarray of float
        1D table of timestamps, length `n`, in MJD.
    data : np.ndarray of float
        1D table of that mnemonic.

    """

    def __init__(self, filename):

        with open(filename) as fn:
            data = fn.readlines()[1:]
            self.n = len(data)
            self.t = np.zeros(self.n)
            self.data = np.zeros((self.n,), dtype=np.float32)

        for j in range(self.n):
            if j % 100000 == 0: print(f"{j}/{self.n}", flush=True)
            vals = data[j].rstrip().split(",")
            self.t[j] = Time(vals[0], format="isot", scale="utc").mjd
            self.data[j] = float(vals[1])

    def signal(self, t1, t2):
        """Gets the mean signal between two times.

        Parameters
        ----------
        t1, t2 : float or str
            Times in MJD or ISO timestring.

        Returns
        -------
        float
            Mean signal in that time window.
        """

        _t1 = t1 if isinstance(t1, float) else Time(t1, format="isot", scale="utc").mjd
        it1 = np.searchsorted(self.t, _t1)
        _t2 = t2 if isinstance(t1, float) else Time(t2, format="isot", scale="utc").mjd
        it2 = np.searchsorted(self.t, _t2)
        return np.mean(self.data[it1+1:it2])


    def signal_from_exp(self, fn):
        """Gets the mean signal in an exposure.

        Parameters
        ----------
        fn : str
            File name.

        Returns
        -------
        float
            Mean signal in that time window.
        """

        with asdf.open(fn) as a:
            exposure = a["roman"]["meta"]["exposure"]
            s = self.signal(exposure["start_time"], exposure["end_time"])
        return s


def get_trend(voltage_file, ice_trend_files):
    """Extracts the photodiode voltages for a bunch of passes of the ice trending.

    Parameters
    ----------
    voltage_file : str
        The voltage trending file from EDP.
    ice_trend_files : list of str
        The files used for ice trending (one entry per pass).

    Returns
    -------
    np.ndarray
        The ratios relative to initial. There is one row per epoch, and 6 columns (1 per band).

    """

    tab = MnemonicTable(voltage_file)

    # extract the exposures
    n = len(ice_trend_files)
    result = np.zeros((n, 6), dtype=np.float32)

    for j in range(n):
        vstem = ice_trend_files[j][:14]
        d = np.zeros(7)
        for i in range(7):
            fn1 = vstem + f"{i+1:03d}001_0001_wfi01_dark%2F"
            fn2 = vstem + f"{i+1:03d}001_0001_wfi01_dark_uncal.asdf"

            for k in range(3):

                # pull data and compress into 2D cube
                proc = ["curl", "-H", os.path.expandvars("Authorization: token $MAST_API_TOKEN"), "-L", "-X", "GET",
                    "https://mast.stsci.edu/search/roman/api/v0.1/retrieve_product?product_name=" + fn1 + fn2 + "",
                    "--output", fn2, "--fail", "--create-dirs"
                    ]
                subprocess.run(proc, capture_output=True, text=True)

                # extract header and clear
                try:
                    d[i] = tab.signal_from_exp(fn2)
                    break
                except FileNotFoundError:
                    print(f"FileNotFoundError: {fn2}, try {k}", flush=True)
                    if k == 2: raise ValueError("failed on k=2")
                    time.sleep(5)

            # print(f"{j:3d} {i} {fn2} {d[i]:8.5f}", flush=True)
            os.remove(fn2)
        result[j] = d[1:] - d[0]
        print(f"{vstem} {result[j, 0]:8.6f} {result[j, 1]:8.6f} {result[j, 2]:8.6f} {result[j, 3]:8.6f} {result[j, 4]:8.6f} {result[j, 5]:8.6f} ")

    return(result)


def _squash(tree, order=2):
    """Compresses a tree into a 2D flux image via quadratic fit.

    Returns fits (order+1, ny, nx).
    """

    d = tree["roman"]["data"].astype(np.float32)
    t = np.array(tree["roman"]["meta"]["exposure"]["read_pattern"], dtype=np.float64).ravel()

    # squash back
    if t[-1] == 13 and tree["roman"]["meta"]["exposure"]["ma_table_name"] == "IM_DIAGNOSTIC":
        print(f"squashing -->", tree["roman"]["meta"]["exposure"]["start_time"])
        t = np.array([1, 4, 7, 10, 13])
        d = np.zeros((5, 4096, 4096), dtype=np.float32)
        for j in range(5):
            d[j] = tree["roman"]["data"][3 * j].astype(np.float32)

    # get weights in the time dimension
    n = order + 1
    m = np.zeros((n, n))
    b = np.zeros((n, len(t)))
    for i in range(n):
        for j in range(n):
            m[i, j] = np.sum(t**(i+j))
        for j in range(len(t)):
            b[i, j] = t[j]**i
    w = np.linalg.solve(m, b).astype(np.float32)
    return np.einsum("pt,tij->pij", w, d)


tm = np.zeros(nt)

update = len(sys.argv)>1 and sys.argv[-1] == "--update"

if update:
    with fits.open(f"flat_ratio_cube_nl_{nseg:d}.fits") as f:
        nt_old = len(f[2].data)
        tm[:nt_old] = f[2].data[:nt_old]
        cube[:, :, :, :, :, :nt_old] = f[0].data[..., :nt_old].reshape((norder+1, nled, nsca, nseg, nseg, nt_old))

# need to check each SCA in each Band at each time
usefiles = []
for isca in range(nsca):

    # dark image
    dks = []

    for iled in range(-1, nled):
        leds = f"{iled+2:1d}"
        for it in range(nt):
            print(f"sca={isca}, led={iled} it={it}", flush=True)

            # 1st cycle
            psnum = it + 1
            if it >= 11: psnum += 1  # we skipped pass 12
            if psnum >= 25: psnum += 1  # partial coverage only of pass 25
            if psnum >= 32: psnum += 1  # pass 32 missed
            ps = f"{psnum:03d}"
            fn1 = f"r0103902{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark%2F"
            fn2 = f"r0103902{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark_uncal.asdf"

            # 2nd cycle
            if it >= 34:
                itd = it - 34
                psnum = 2 * itd + 1 if itd < 4 else 8 * (itd - 3) + 7
                cy = 2
                ps = f"{psnum:03d}"
                if psnum > 90:
                    cy = 3
                    ps = f"{psnum-90:03d}"
                fn1 = f"r010630{cy:1d}{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark%2F"
                fn2 = f"r010630{cy:1d}{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark_uncal.asdf"
            if it >= 52:
                psnum = it - 14
                ps = f"{psnum:03d}"
                fn1 = f"r0103902{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark%2F"
                fn2 = f"r0103902{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark_uncal.asdf"
            if it >= 61:
                psnum = it - 14
                ps = f"{psnum:03d}"
                fn1 = f"r0103903{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark%2F"
                fn2 = f"r0103903{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark_uncal.asdf"
            if it >= 72:
                psnum = it - 1
                ps = f"{psnum:03d}"
                fn1 = f"r0103903{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark%2F"
                fn2 = f"r0103903{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark_uncal.asdf"
            if it >= 77:
                psnum = it - 76
                ps = f"{psnum:03d}"
                fn1 = f"r0106304{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark%2F"
                fn2 = f"r0106304{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark_uncal.asdf"
            if it >= 87:
                psnum = it - 86
                if it >= 93: psnum -= 1
                ps = f"{psnum:03d}"
                fn1 = f"r0106305{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark%2F"
                fn2 = f"r0106305{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark_uncal.asdf"
            if it == 92:
                fn1 = f"r010630401100100{leds}001_0001_wfi{isca+1:02d}_dark%2F"
                fn2 = f"r010630401100100{leds}001_0001_wfi{isca+1:02d}_dark_uncal.asdf"
            if it >= 94:
                psnum = it - 18
                ps = f"{psnum:03d}"
                fn1 = f"r0103903{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark%2F"
                fn2 = f"r0103903{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark_uncal.asdf"
            if it >= 101:
                psnum = it - 94
                ps = f"{psnum:03d}"
                fn1 = f"r0106305{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark%2F"
                fn2 = f"r0106305{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark_uncal.asdf"
            if it >= 107:
                psnum = it - 106
                ps = f"{psnum:03d}"
                fn1 = f"r0106306{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark%2F"
                fn2 = f"r0106306{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark_uncal.asdf"
            if it >= 115:
                psnum = it - 32
                ps = f"{psnum:03d}"
                fn1 = f"r0103903{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark%2F"
                fn2 = f"r0103903{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark_uncal.asdf"
            if it >= 126:
                psnum = it - 113
                ps = f"{psnum:03d}"
                fn1 = f"r0106305{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark%2F"
                fn2 = f"r0106305{ps}00100{leds}001_0001_wfi{isca+1:02d}_dark_uncal.asdf"

            if isca == 0 and iled == 0:
                usefiles.append(fn2)

            if update and it<nt_old and it!=0:
                if iled == -1:
                    dks.append(None)  # won't need this value, but need to put in a spacer
                continue

            fn2t = tdir + "/" + fn2
            print("fetching:", fn2, flush=True)

            # pull data and compress into 2D cube
            proc = ["curl", "-H", os.path.expandvars("Authorization: token $MAST_API_TOKEN"), "-L", "-X", "GET",
                "https://mast.stsci.edu/search/roman/api/v0.1/retrieve_product?product_name=" + fn1 + fn2 + "",
                "--output", fn2t, "--fail", "--create-dirs"
                ]
            result = subprocess.run(proc, capture_output=True, text=True)

            # dark
            if iled == -1:
                with asdf.open(fn2t) as a:
                    dks.append(_squash(a, order=1)[1].astype(np.float16))
                print(f"time {it:3d} sca {isca+1:2d} dark = {np.nanmedian(dks[-1]):11.5E} DN/read", flush=True)
                # cleanup
                os.remove(fn2t)
                continue

            # now we've got a flat
            with asdf.open(fn2t) as a:
                data = _squash(a)
                if isca==0 and iled==0:
                    tm[it] = a["roman"]["meta"]["ephemeris"]["time"]
            data[1] -= dks[it]  # dark subtraction!

            if it == 0:
                data0 = np.copy(data)

                # force reference pixels to nan
                data0[:, :, :4] = np.nan
                data0[:, :, -4:] = np.nan
                data0[:, :4, :] = np.nan
                data0[:, -4:, :] = np.nan

            # 0 term is constant -- just in DN
            # so cube[0, ...] is the bias change from initial epoch
            cube[0, iled, isca, :, :, it] = np.nanmedian((data[0]-data0[0]).reshape((nseg, 4096//nseg, nseg, 4096//nseg)), axis=(1,3))
            print(": 0", np.nanmedian(cube[0, iled, isca, :, :, it]))

            for ip in range(1, norder+1):
                if ip == 1:
                    # cube[1, ...] is the linear flux ratio from initial epoch
                    medratio = np.nanmedian((data[1]/data0[1]).reshape((nseg, 4096//nseg, nseg, 4096//nseg)), axis=(1,3))
                else:
                    # cube[2, ...] is the change in quadratic term in DN^-1 relative to the initial epoch
                    medratio = np.nanmedian((data[ip]/data[1]**ip - data0[ip]/data0[1]**ip).reshape((nseg, 4096//nseg, nseg, 4096//nseg)), axis=(1,3))
                cube[ip, iled, isca, :, :, it] = medratio
                print(":", ip, np.median(data[ip]), np.median(data0[ip]), np.nanmedian(medratio), np.count_nonzero(np.isfinite(medratio)))
            # print(f"LED Band {iled+1:d} WFI{isca+1:02d} --> {fn2}")
            # print(np.round(cube[1, iled, isca, ::4, ::4, it], 5), flush=True)
            # cleanup
            os.remove(fn2t)

trend = get_trend("/data/chirata/photodiode/WFI_MCE_SRCS_PD2_V_20260912T000000_20261031T120000.csv", usefiles)
trend /= trend[0][None, :]


# Extract temperature data
temp_trend_data = np.zeros(len(usefiles))
temp_table = MnemonicTable("/data/chirata/eng/WFI_MCE_ADC_WTSM00_20260912T000000_20261031T120000.csv")
for j in range(len(temp_trend_data)):
    vstem = usefiles[j][:14]
    fn1 = vstem + f"004001_0001_wfi01_dark%2F"
    fn2 = vstem + f"004001_0001_wfi01_dark_uncal.asdf"

    # pull data and compress into 2D cube
    proc = ["curl", "-H", os.path.expandvars("Authorization: token $MAST_API_TOKEN"), "-L", "-X", "GET",
        "https://mast.stsci.edu/search/roman/api/v0.1/retrieve_product?product_name=" + fn1 + fn2 + "",
        "--output", fn2, "--fail", "--create-dirs"
    ]
    subprocess.run(proc, capture_output=True, text=True)
    temp_trend_data[j] = temp_table.signal_from_exp(fn2)  # this is the table
    print(f"{j:3d} {fn2} T = {temp_trend_data[j]:8.3f}", flush=True)
    os.remove(fn2)
del temp_table


def stepquad(t, npost=2):
    """Gets the weights to fit a step on a quadratic background.

    Model fit is f(t) = at^2 + bt + c + d{1 if t>=t2, 0 if t<=t1};
    returns the weights in d = sum_j w_j f(t_j).

    If `npost` is given, changes the number of samples that are
    assumed to be after the step.

    Parameters
    ----------
    t : np.ndarray of float
        Length 4; times t0, t1, t2, t3.
    npost : int
        Number of samples after the step.

    Returns
    -------
    w : np.ndarray of float
        Weights for those times.

    """

    # first, get matrix m with f(t_j) = m[j, k] v[k] where v = {a, b, c, d}

    m = np.zeros((4, 4))
    m[:, 0] = np.array(t)**2
    m[:, 1] = np.array(t)
    m[:, 2] = 1.0
    m[-npost:, 3] = 1.0

    return (np.linalg.inv(m.T@m)@m.T)[-1]


def destep_image(arr, t, idx):
    """Removes steps in the last axis (time axis) of the array due to ACM deploy.

    `arr` is updated in place.

    Parameters
    ----------
    arr : np.ndarray of float
        The data array; last axis is time.
    t : np.ndarray of float
        The time stamps.
    idx : int
        Which index is right after the step.

    Returns
    -------
    None

    """

    logarr = np.log(arr)
    w = stepquad(t[idx-2:idx+2])

    steps = np.einsum("...j,j->...", logarr[..., idx-2:idx+2], w)
    logarr[...,idx:] -= steps[...,None]
    arr[...] = np.exp(logarr)

def destep_image2(arr, t, idx):
    """Removes steps in the last axis (time axis) of the array due to ACM move with
    only one sample after.

    `arr` is updated in place.

    Parameters
    ----------
    arr : np.ndarray of float
        The data array; last axis is time.
    t : np.ndarray of float
        The time stamps.
    idx : int
        Which index is right after the step.

    Returns
    -------
    None

    """

    logarr = np.log(arr)
    w = stepquad(t[idx-3:idx+1], npost=1)

    steps = np.einsum("...j,j->...", logarr[..., idx-3:idx+1], w)
    steps = np.mean(steps, axis=0)[None,...]
    logarr[...,idx:] -= steps[...,None]
    arr[...] = np.exp(logarr)

# make image, 2D version, and time stamps
im = fits.PrimaryHDU(cube.reshape((norder+1, nled, nsca*nseg**2, nt)))
im2d = fits.ImageHDU(np.transpose(cube.reshape((norder+1, nled, nsca*nseg**2, nt)), axes=(0,1,3,2)).reshape((norder+1, nled*nt, nsca*nseg**2)))
tmi = fits.ImageHDU(tm)

# destepped version
arr = (cube[1] / trend.T[:, None, None, None, :]).astype(np.float32, copy=False)
# map into the temperature trending
index_4x4 = np.tile(np.array(range(288)).reshape((18, 4, 1, 4, 1)), (1, 1, nseg//4, 1, nseg//4)).ravel()
sensitivity_coefs = np.loadtxt("/data/chirata/ice-trends/tdgains/gainpars-4.txt")[:, 1][index_4x4]
arr *= np.exp(np.outer(sensitivity_coefs, temp_trend_data - temp_trend_data[0])).reshape((nsca, nseg, nseg, nt))[None, ...]

if nt >= 16: destep_image(arr, tm, 14)
if nt >= 34: destep_image2(arr[...,:55], tm, 33)
if nt >= 74: destep_image(arr, tm, 72)
im_destep = fits.ImageHDU(np.transpose(arr.reshape((nled, nsca*nseg**2, nt)), axes=(0,2,1)).reshape((nled*nt, nsca*nseg**2)))

thdu = fits.ImageHDU(temp_trend_data, name="TEMP_MPA")

fits.HDUList([im, im2d, tmi, im_destep, thdu]).writeto(f"flat_ratio_cube_nl_{nseg:d}.fits", overwrite=True)
