import math
import multiprocessing
import os
import sys
from concurrent.futures import ProcessPoolExecutor

import numpy as np
import yaml
from astropy.io import fits
from numba import njit
from psfsim.filter_detector_properties import FilterDetector

scapos = np.array(
    [
        [-22.1400, 12.1500],
        [-22.2900, -37.0300],
        [-22.4400, -82.0600],
        [-66.4200, 20.9000],
        [-66.9200, -28.2800],
        [-67.4200, -73.0600],
        [-110.7000, 42.2000],
        [-111.4800, -6.9800],
        [-112.6400, -51.0600],
        [22.1400, 12.1500],
        [22.2900, -37.0300],
        [22.4400, -82.0600],
        [66.4200, 20.9000],
        [66.9200, -28.2800],
        [67.4200, -73.0600],
        [110.7000, 42.2000],
        [111.4800, -6.9800],
        [112.6400, -51.0600],
    ],
    dtype=np.float64,
)

# number of fixed parameters
initgray = True
tempcoef = True

MOD_COMMENTS = {
    "BAND1WT": "Weight for Band 1",
    "BAND2WT": "Weight for Band 2",
    "BAND3WT": "Weight for Band 3",
    "BAND4WT": "Weight for Band 4",
    "BAND5WT": "Weight for Band 5",
    "BAND6WT": "Weight for Band 6",
}


@njit
def modsqrt(x):
    """Modified sqrt to not go negative."""

    c = 0.5
    y = x
    if x < c:
        y = c * np.exp(x / c - 1)
    return np.sqrt(y)


@njit
def _rot(c):
    """Rotation matrix by c cycles."""

    th = 2 * np.pi * c
    return np.array([[np.cos(th), np.sin(th)], [-np.sin(th), np.cos(th)]])


def modfilterdetector(pars, wl):
    """Makes a FilterDetector from a parameter table.

    The parameters are transformed so that the final fit parameters are not physical.

    Parameters
    ----------
    pars : np.ndarray of float
        Length 6.
    wl : float
        Wavelength in microns.

    Returns
    -------
    psfsim.filter_detector_properties.FilterDetector
        The FilterDetector object.
    """

    k = int(os.getenv("ICEFIT_ROTATION_KEY")) * 3 + 1000000000

    v = np.copy(pars[:3])
    v[1:3] = _rot((k % 73) / 73) @ v[1:3]
    v[:2] = _rot((k % 91) / 91) @ v[:2]
    v[1:3] = _rot((k % 137) / 137) @ v[1:3]
    v[0] += 1.25 + 0.2 * ((k % 29) / 29)
    v[1] += 1.72 + 0.2 * ((k % 47) / 47)
    v[2] += 2.35 + 0.2 * ((k % 61) / 61)
    w = np.copy(pars[3:6])
    w[1:3] = _rot((k % 167) / 167) @ w[1:3]
    w[:2] = _rot((k % 193) / 193) @ w[:2]
    w[1:3] = _rot((k % 251) / 251) @ w[1:3]

    return FilterDetector(
        np.array(
            [
                modsqrt(v[0] ** 2 + 0.00580 * (1 / wl**2 - 1) + 0.00259 * (1 - wl**2)),
                modsqrt(v[1] ** 2 + 0.01756 * (1 / wl**2 - 1) + 0.00989 * (1 - wl**2)),
                modsqrt(v[2] ** 2 + 0.19288 * (1 / wl**2 - 1) - 0.00998 * (1 - wl**2)),
            ]
        ),
        w + np.array([0.185, 0.137, 0.102]),
        1,
    )


def get_aoi(nb):
    """Flattened AOI array for the RCS."""

    x = np.zeros((18, nb, nb))
    y = np.zeros((18, nb, nb))

    _s = np.linspace(-20.44 * (1 - 1 / nb), 20.44 * (1 - 1 / nb), nb)
    _x, _y = np.meshgrid(_s, _s)
    _x *= -1.0

    for j in range(18):
        x[j, :, :] = scapos[j, 0] + _x
        y[j, :, :] = scapos[j, 1] + _y

    aoi = np.arctan(np.hypot(x, y - 155) / 660)
    return aoi


def reflection_power(pars, wl, theta=0.0, model="3-layer"):
    """
    Predicted transmission power.

    Parameters
    ----------
    pars : np.ndarray of float
        Length 6. Ordering is: n1, n2, n3, t1, t2, t3.
    wl : np.ndarray of float
        Wavelengths in microns.
    theta : float, optional
        The angle of incidence (in radians).
    model : str, optional
        The model. The only option right now is "3-layer".

    Returns
    -------
    np.ndarray of float
        The predicted reflection powers at the specified wavelengths, same size as `wl`.
    """

    nwl = len(wl)
    out = np.zeros(nwl)

    for j in range(nwl):
        arc = modfilterdetector(pars, wl[j])
        p0, p1 = arc.transmitted_power(wl[j], [theta])
        out[j] = 1 - ((p0 + p1) / 2).ravel()[0]

    return out


def predict_ratio(pars, wl, theta=0.0, model="3-layer", led=True):
    """
    Predicted ratio of flux (with ice) / flux (without ice) for a 3-layer model.

    Parameters
    ----------
    pars : np.ndarray of float
        Length 7. Ordering is: n1, n2, n3, t1, t2, t3, t_ice (all in microns).
    wl : np.ndarray of float
        Wavelengths in microns.
    theta : float, optional
        The angle of incidence (in radians).
    model : str, optional
        The model. The only option right now is "3-layer".
    led : bool, optional
        Whether this is an LED case.

    Returns
    -------
    np.ndarray of float
        The predicted ratios at the specified wavelengths, same size as `wl`.

    """

    nwl = len(wl)
    out = np.zeros(nwl)
    sigma = np.array([0.0143, 0.0186, 0.0271, 0.0385, 0.0515, 0.0550])
    if not led:
        sigma = np.zeros_like(wl)

    for j in range(nwl):
        arc = modfilterdetector(pars, wl[j])
        p0, p1 = arc.transmitted_power(wl[j] + sigma[j], [theta])
        if sigma[j] > 0:
            q0, q1 = arc.transmitted_power(wl[j] - sigma[j], [theta])
        else:
            q0, q1 = p0, p1
        arc.add_ice_layer(pars[-1])
        p2, p3 = arc.transmitted_power(wl[j] + sigma[j], [theta])
        if sigma[j] > 0:
            q2, q3 = arc.transmitted_power(wl[j] - sigma[j], [theta])
        else:
            q2, q3 = p2, p3
        out[j] = ((p2 + p3 + q2 + q3) / (p0 + p1 + q0 + q1)).ravel()[0]

    return out


def predict_ratio_ders(pars, wl, theta=0.0, model="3-layer"):
    """
    Derivatives of predicted ratio of flux (with ice) / flux (without ice) for a 3-layer model.

    Parameters
    ----------
    pars : np.ndarray of float
        Length 7. Ordering is: n1, n2, n3, t1, t2, t3, t_ice (all in microns).
    wl : np.ndarray of float
        Wavelengths in microns.
    theta : float, optional
        The angle of incidence (in radians).
    model : str, optional
        The model. The only option right now is "3-layer".

    Returns
    -------
    np.ndarray of float
        The matrix of ``A[i, j]`` = d(ratio at wavelength ``wl[i]``) / d(``pars[j]``)

    """

    npar = len(pars)
    nwl = len(wl)
    out = np.zeros((nwl, npar))
    for j in range(npar):
        d = 1e-4
        my_p = np.copy(pars)
        my_p[j] += d
        my_m = np.copy(pars)
        my_m[j] -= d
        out[:, j] = (predict_ratio(my_p, wl, theta, model) - predict_ratio(my_m, wl, theta, model)) / (2 * d)

    return out


def ratios_and_ders_multi(
    nt, pars, wl, theta=0.0, timestamps=None, model="3-layer", tempdata=None, tresets=None
):
    """
    Derivatives of predicted ratio of flux (with ice) / flux (without ice) for a 3-layer model.

    Parameters
    ----------
    nt : int
        Number of thicknesses used.
    pars : np.ndarray of float
        Length npfix + `nt`. Ordering is: n1, n2, n3, t1, t2, t3, [t_ice...] (all in microns).
    wl : np.ndarray of float
        Wavelengths in microns.
    theta : float, optional
        The angle of incidence (in radians).
    timestamps : np.npdarray of float, optional
        The time stamps corresponding to these observations.
    model : str, optional
        The model. The only option right now is "3-layer".
    tempdata : np.ndarray of float, optional
        The temperature data points.
    tresets : array-like of float, optional
        The reset times in days since the starting epoch.

    Returns
    -------
    ratios : np.ndarray of float
        The predicted ratios at the specified wavelengths: ``ratios[k, i]`` is the ratio
        at thickness k and wavelength ``wl[i]``.
    ders : np.ndarray of float
        The matrix of ``A[k, i, j]`` = d(ratio at wavelength ``wl[i]``) / d(``pars[j]``)
        at thickness k.

    """

    tresets = [] if tresets is None else tresets

    # set up arrays
    nwl = len(wl)
    npar = len(pars) - nt
    ratios = np.zeros((nt, nwl))
    ders = np.zeros((nt, nwl, len(pars)))

    # now loop over thicknesses
    for k in range(nt):
        bin_index = np.searchsorted(tresets, timestamps[k]) if timestamps is not None else -1
        rescaling = 1 if bin_index == -1 else pars[6 + bin_index] + 1
        rescaling2 = 1 if tempdata is None else np.exp(pars[7 + len(tresets)] * (tempdata[k] - 89.5))

        pars_clip = np.copy(pars[: npar + 1])
        pars_clip[-1] = pars[npar + k]
        ratios[k, :] = predict_ratio(pars_clip, wl, theta=theta, model=model) * rescaling * rescaling2
        jac = predict_ratio_ders(pars_clip, wl, theta=theta, model=model) * rescaling * rescaling2
        ders[k, :, :6] = jac[:, :6]
        ders[k, :, npar + k] = jac[:, -1]
        if bin_index >= 0:
            ders[k, :, 6 + bin_index] = ratios[k, :] / rescaling
        if tempdata is not None:
            ders[k, :, 7 + len(tresets)] = ratios[k, :] * (tempdata[k] - 89.5)

    return ratios, ders


def get_best_coating(
    ratio_target,
    pars,
    wl,
    theta=0.0,
    model="3-layer",
    rel=0.4,
    niter=100,
    timestamps=None,
    tempdata=None,
    nfix=False,
    tresets=None,
    regpar=0.0,
    mods=None,
    verbose=False,
):
    """
    Finds the "best fit" parameters, by comparison to the target.

    Parameters
    ----------
    ratio_target : np.ndarray of float
        The ratios relative to no ice, in the format: ``ratio_target[k, i]`` is the ratio
        at thickness k and wavelength ``wl[i]``.
    pars : np.ndarray of float
        Length 6+`nt`. Ordering is: n1, n2, n3, t1, t2, t3, [t_ice...] (all in microns).
    wl : np.ndarray of float
        Wavelengths in microns.
    theta : float, optional
        The angle of incidence (in radians).
    model : str, optional
        The model. The only option right now is "3-layer".
    rel : float, optional
        Relaxation parameter (1 for Newton-Raphson).
    niter : int, optional
        Max number of iterations.
    timestamps : np.npdarray of float, optional
        The time stamps corresponding to these observations.
    tempdata : np.ndarray of float, optional
        The temperature data points.
    nfix : bool, optional
        Whether to force the indices of refraction to be fixed.
    tresets : array-like of float, optional
        The reset times in days since the starting epoch.
    regpar : float, optional
        Trending regularization to penalize sharp changes in deposition rate.
    mods : dict, optional
        Dictionary of modifications to the fitting code (e.g., changes in weight).
    verbose : bool, optional
        Whether to talk a lot.

    Returns
    -------
    pars_out : np.ndarray
        The best-fit parameters.
    rmse_init, rmse_final : float
        The initial and final RMS errors.

    """

    # expand mods into a dictionary
    if mods is None:
        mods = {}

    npfix = 8 + (len(tresets) if tresets is not None else 0)  # number of fixed parameters

    sc = np.zeros_like(pars)
    sc[:6] = np.array([0.5, 0.5, 0.5, 0.06, 0.06, 0.06])
    sc[6 : npfix - 1] = 1.0e-3
    sc[npfix - 1] = 3.0e-4
    sc[npfix:] = 0.01

    pars_out = np.copy(pars)
    (nt, nwl) = np.shape(ratio_target)

    # regularizations
    nreg = 0
    if timestamps is not None:
        nreg = len(timestamps) - 3 - 2 * len(tresets)
    m_mat = np.zeros((nreg, len(pars)))
    if timestamps is not None:
        j = 0
        c = np.zeros(3)
        # this is where we regularize the 2nd derivative
        for it in range(1, len(timestamps) - 2):
            t = timestamps[it : it + 3]
            is_break = False
            for tr in tresets:
                if t[0] <= tr < t[2]:
                    is_break = True
            if is_break:
                continue
            # need the coefficients of (1/2) d^2[thickness]/dt^2 = c[0] * y[0] + c[1] * y[1] + c[2] * y[2]
            # [ 1 -t10  t10^2] [?]   [y0]
            # [ 1   0    0   ] [?] = [y1]
            # [ 1  t21  t21^2] [?]   [y2]   <-- we want that row
            #
            # det = t10 * t21 * (t10 + t21) = t10 * t21 * t20
            # c[0] = t21 / det = 1. / (t10 * t20)
            # c[1] = (-t21 - t10) / det = -1. / (t10 * t21)
            # c[2] = t10 / det = 1. / (t21 * t20)
            c[0] = 1.0 / ((t[1] - t[0]) * (t[2] - t[0]))
            c[1] = -1.0 / ((t[1] - t[0]) * (t[2] - t[1]))
            c[2] = 1.0 / ((t[2] - t[0]) * (t[2] - t[1]))
            # dt = (t[2] - t[0]) / 2.0
            if it == 0:
                c[0] = 0  # doesn't do anything if we don't force the intercept at t=0 (i.e., exclude it=0)
            m_mat[j, npfix + it - 1 : npfix + it + 2] = 2.0 * c * regpar
            j += 1

    rmse = np.zeros(niter)
    for a in range(niter):
        ratio, jac = ratios_and_ders_multi(
            nt,
            pars_out,
            wl,
            theta=theta,
            timestamps=timestamps,
            model=model,
            tempdata=tempdata,
            tresets=tresets,
        )
        rmse[a] = np.mean((ratio - ratio_target) ** 2) ** 0.5
        dratio = (ratio_target - ratio).ravel()
        jac = jac.reshape((-1, len(pars)))
        if verbose and a % 10 == 0:
            print("iter", a, "of", niter, rmse[a])
            print(">>", pars_out)

        if timestamps is not None:
            dratio = np.concatenate((dratio, -m_mat @ pars))
            jac = np.vstack((jac, m_mat))

        # setup that only has to be done once
        if a == 0:
            wt = np.ones_like(dratio)
            # weights for each band
            for b in range(1, 7):
                if f"BAND{b}WT" in mods:
                    wt[b - 1 : 6 * nt : 6] = mods[f"BAND{b}WT"]

        # full version
        if nfix:
            pars_out[3:] += rel * np.linalg.lstsq(jac[:, 3:] * sc[None, 3:], dratio)[0] * sc[3:]
        else:
            pars_out += rel * np.linalg.lstsq(wt[:, None] * jac * sc[None, :], wt * dratio)[0] * sc

    return pars_out, rmse[0], rmse[-1], dratio[: np.size(ratio_target)]


def extract_from_bands(
    vals,
    dt_init=1.0e-3,
    timestamps=None,
    theta=0.0,
    nfix=False,
    tempdata=None,
    tresets=None,
    regpar=0.0,
    mods=None,
    verbose=False,
):
    """Gets thickness data from a numpy array of flux ratios.

    Parameters
    ----------
    vals : np.array
        The sensitivity ratios.
    nspace : int, optional
        The spacing between wavelength samples (if we skip some).
    dt_init : float, optional
        The initial condition for the range of thicknesses.
    nfix : bool, optional
        Whether to force the indices of refraction to be fixed.
    timestamps : np.npdarray of float, optional
        The time stamps corresponding to these observations.
    theta : float, optional
        The angle of incidence (in radians).
    tempdata : np.ndarray of float, optional
        The temperature data points.
    tresets : array-like of float, optional
        The reset times in days since the starting epoch.
    regpar : float, optional
        Trending regularization to penalize sharp changes in deposition rate.
    mods : dict, optional
        Dictionary of modifications to the fitting code (e.g., changes in weight).
    verbose : bool, optional
        Whether to talk a lot.

    Returns
    -------
    pars_out : np.ndarray
        The best-fit parameters.
    rmse_init, rmse_final : float
        The initial and final RMS errors.
    dratio : np.ndarray of float
        The residuals, ordered by band first and then time.

    """

    npfix = 8 + (len(tresets) if tresets is not None else 0)  # number of fixed parameters

    nwl = 6
    ratio_target = vals.reshape((nwl, -1))[:, 1:].T
    nt = np.shape(ratio_target)[0]

    wl = np.array([0.622, 0.845, 1.034, 1.261, 1.488, 1.660])
    pars = np.zeros(npfix + nt)

    if timestamps is None:
        pars[npfix:] = np.linspace(0, (nt - 1) * dt_init, nt)
    else:
        pars[npfix:] = dt_init * timestamps[1:]
        for tr in tresets:
            _s = np.argwhere(timestamps[1:] >= tr).ravel()
            if len(_s) > 0:
                smin = _s[0]
                pars[npfix + smin :] = dt_init * (timestamps[1 + smin :] - tr)

    pars_out, rmsi, rmsf, _ = get_best_coating(
        ratio_target,
        pars,
        wl,
        rel=0.25,
        niter=24,
        theta=theta,
        timestamps=timestamps,
        nfix=nfix,
        tempdata=tempdata,
        tresets=tresets,
        regpar=regpar,
        mods=mods,
        verbose=verbose,
    )
    pars_out, _, rmsf, dratio = get_best_coating(
        ratio_target,
        pars_out,
        wl,
        rel=0.4,
        niter=50,
        theta=theta,
        timestamps=timestamps,
        nfix=nfix,
        tempdata=tempdata,
        tresets=tresets,
        regpar=regpar,
        mods=mods,
        verbose=verbose,
    )

    return pars_out, rmsi, rmsf, dratio.reshape((-1, nwl)).T.ravel()


def _process_single_column(
    j,
    col_vals,
    dt_init,
    timestamps,
    theta_j,
    nfix,
    verbose,
    nt,
    npfix,
    wlt,
    thicknesses,
    tempdata,
    tresets,
    regpar,
    mods,
):
    """Picklable version of processing one superpixel."""

    npfix = 8 + (len(tresets) if tresets is not None else 0)  # number of fixed parameters

    # Call the extraction function
    pars_j, _, rmsf_j, dratio_j = extract_from_bands(
        col_vals,
        dt_init=dt_init,
        timestamps=timestamps,
        theta=theta_j,
        nfix=nfix,
        tempdata=tempdata,
        tresets=tresets,
        regpar=regpar,
        mods=mods,
        verbose=verbose,
    )

    # Pre-allocate temporary containers for the loops inside this worker
    # Adjust shapes matching your 'box' and 'box2' dimensions (excluding the 'j' axis)
    # Assuming box shape structure is (nt, middle_dimension)
    box_j = np.zeros((nt, len(wlt)))
    box2_j = np.zeros((len(thicknesses), len(wlt)))

    for it in range(nt):
        cpars = np.copy(pars_j[:7])
        cpars[-1] = pars_j[npfix + it]
        box_j[it, :] = predict_ratio(cpars, wlt, theta=theta_j, led=False)

    for it in range(len(thicknesses)):
        cpars = np.copy(pars_j[:7])
        cpars[-1] = thicknesses[it]
        box2_j[it, :] = predict_ratio(cpars, wlt, theta=theta_j, led=False)

    return j, pars_j, rmsf_j, dratio_j, box_j, box2_j


def extract_from_2d(vals, nb, cfg, dt_init=1.0e-3, timestamps=None, tempdata=None):
    """Gets thickness data from a 2D array."""

    npfix = 8 + len(cfg["T_RESET"])  # number of 'fixed' parameters (not per epoch)

    nc = np.shape(vals)[1]
    nt = np.shape(vals)[0] // 6 - 1
    pars = np.zeros((npfix + nt, nc))
    rmsf = np.zeros((nc,))
    theta = get_aoi(nb).ravel()
    print(f"# theta {np.amin(theta)}, {np.amax(theta)}")

    # transmission image
    wlt = 1 / np.linspace(cfg["IWL"][0], cfg["IWL"][1], cfg["IWL"][2])
    box = np.ones((nt, len(wlt), nc), dtype=np.float32)
    thicknesses = np.linspace(cfg["ICE_T"][0], cfg["ICE_T"][1], cfg["ICE_T"][2])
    box2 = np.ones((len(thicknesses), len(wlt), nc), dtype=np.float32)

    dratio = np.zeros((6 * nt, nc), dtype=np.float32)

    with ProcessPoolExecutor(
        max_workers=cfg.get("MAX_WORKERS", 64), mp_context=multiprocessing.get_context("forkserver")
    ) as executor:
        # Prepare the arguments generator for executor.submit
        futures = [
            executor.submit(
                _process_single_column,
                j,
                vals[:, j],
                dt_init,
                timestamps,
                theta[j],
                False,
                False,
                nt,
                npfix,
                wlt,
                thicknesses,
                tempdata,
                cfg["T_RESET"],
                cfg.get("REGPAR", 0.0),
                cfg.get("MODS", None),
            )
            for j in range(0, cfg.get("STOP", nc), cfg.get("DSKIP", 1))
        ]

        # Gather results as they complete
        for _, future in enumerate(futures):
            j, pars_j, rmsf_j, dratio_j, box_j, box2_j = future.result()

            # Unpack results back into your primary arrays
            pars[:, j] = pars_j
            rmsf[j] = rmsf_j
            dratio[:, j] = dratio_j
            box[:, :, j] = box_j
            box2[:, :, j] = box2_j

            # Print progress tracking
            _twelve = min(12, len(timestamps))
            r1 = (pars_j[-5] - pars_j[-_twelve]) / (timestamps[-5] - timestamps[-_twelve]) * 1000
            r2 = (pars_j[-1] - pars_j[-5]) / (timestamps[-1] - timestamps[-5]) * 1000
            print(f"run {j:4d} {rmsf[j]:7.5f} {r1:7.4f} {r2:7.4f} {pars[-1, j] * 1000:6.2f}", flush=True)

    return pars, rmsf, box, box2, dratio


def icefit_main(cfg):
    """
    Main ice fitting routine.

    Parameters
    ----------
    cfg : dict
        Configuration parameters. Must include:

        - TREND : trend FITS file name.

        - OUTPUT : output FITS file.

        - IWL : inverse wavelength grid in inverse microns. Should be a list of:
          [1/lambda_blue, 1/lambda_red, number_of_lambda]

        - ICE_T : ice thickness grid in microns. Should be a list of:
          [thickness_min, thickness_max, number_of_thickness]

        - T_RESET : list of reset times in days after the start of trending

        Optional:

        - DSKIP : do only every few super-pixels (default=1; set to 4 to do every 4th)

        - MAX_WORKERS : number of parallel workers (default=64)

    """

    tresets = cfg["T_RESET"]  # reset epochs
    npfix = 8 + len(cfg["T_RESET"])  # number of 'fixed' parameters (not per epoch)

    with fits.open(cfg["TREND"]) as f:
        nb = math.isqrt(np.shape(f[1].data)[-1] // 18)
        print(f[2].data - f[2].data[0], flush=True)
        vals = f[3].data
        # nc = np.shape(vals)[1]
        nt = np.shape(vals)[0] // 6 - 1
        timestamps = f[2].data - f[2].data[0]

        # set timestamp after first reset to be "zero"
        # it = np.argmax(timestamps > tresets[0])
        # x = np.copy(vals).reshape((6, nt+1, nc))
        # x /= x[:, it, :][:, None, :]
        # vals = x.reshape(np.shape(vals))
        print("vals[:nt,0] =", vals[:nt, 0])

        pars, rmsf, box, box2, dratio = extract_from_2d(
            vals, nb, cfg, dt_init=0.008, timestamps=timestamps, tempdata=f["TEMP_MPA"].data[1:]
        )

    # scale out the median
    for k in range(6):
        print(
            "removing:",
            np.median(pars[k, :]),
            np.percentile(pars[k, :], 75) - np.percentile(pars[k, :], 25),
            np.percentile(pars[k, :], 95) - np.percentile(pars[k, :], 5),
        )
        pars[k, :] -= np.median(pars[k, :])

    # warterfall plot
    pic = np.zeros((nt + 27 + len(tresets), 18 * nb**2 + 10))
    pic[:, :] = 1e9
    with fits.open(cfg["TREND"]) as f:
        t_since_reset = np.copy(timestamps[1:])
        for b in range(len(tresets) + 1):
            t1 = ([0] + tresets + [1e16])[b]
            stamp1 = np.argwhere(timestamps[1:] >= t1).ravel()[0]
            t_since_reset[stamp1:] = timestamps[stamp1 + 1 :] - t1
        pic[12 : -15 - len(tresets), :5] = t_since_reset[:, None]
    pic[12 : -15 - len(tresets), 10:] = pars[npfix:, :] * 100.0
    pic[:3, 10:] = pars[:3, :] / (np.percentile(pars[:3, :], 75) - np.percentile(pars[:3, :], 25)) * 3
    pic[3:6, 10:] = pars[3:6, :] / (np.percentile(pars[3:6, :], 75) - np.percentile(pars[3:6, :], 25)) * 3
    pic[-5:, 10:] = 1000.0 * rmsf[None, :]
    pic[-9 - len(tresets) : -7, 10:] = 1000.0 * pars[6:npfix, :]

    # 2D plot
    # bounds
    nb0 = 64
    scapos_flip = np.copy(scapos)
    scapos_flip[:, 0] *= -1
    origin = np.round(scapos_flip / 40.88 * nb0).astype(np.int16)
    for j in range(2):
        origin[:, j] -= np.amin(origin[:, j])
    ny = np.amax(origin[:, 1]) + nb0
    nx = np.amax(origin[:, 0]) + nb0
    factor = nb0 // nb

    # thickness rate
    canvas = np.zeros((len(tresets) * 3 + 4, ny, nx), dtype=np.float32)
    canvas[:, :, :] = 1e9
    hdr = {}
    for b in range(len(tresets) + 1):
        t1 = ([0] + tresets + [1e16])[b]
        t2 = ([0] + tresets + [1e16])[b + 1]
        stamp1 = np.argwhere(timestamps[1:] >= t1).ravel()[0]
        stamp2 = np.argwhere(timestamps[1:] < t2).ravel()[-1]
        print(
            f"rate: bin {b:2d} {t1:8.3f}<=t<{t2:8.3f} stamps = {stamp1:4d} [{timestamps[stamp1+1]:8.3f}], "
            f"{stamp2:4d} [{timestamps[stamp2+1]:8.3f}]"
        )
        trate = pars[npfix + stamp2].reshape((18, nb, nb)) / (timestamps[stamp2 + 1] - ([0] + tresets)[b])
        tinit = pars[npfix + stamp1].reshape((18, nb, nb))

        for j in range(18):
            for ix in range(nb):
                for iy in range(nb):
                    canvas[
                        3 * b + 2,
                        origin[j, 1] + iy * factor : origin[j, 1] + (iy + 1) * factor,
                        origin[j, 0] + ix * factor : origin[j, 0] + (ix + 1) * factor,
                    ] = pars[5 + b].reshape((18, nb, nb))[j, iy, ix]
                    hdr[f"FR{3 * b + 3:04d}"] = f"Gray term cycle {b}"
                    canvas[
                        3 * b,
                        origin[j, 1] + iy * factor : origin[j, 1] + (iy + 1) * factor,
                        origin[j, 0] + ix * factor : origin[j, 0] + (ix + 1) * factor,
                    ] = trate[j, iy, ix]
                    hdr[f"FR{3 * b + 1:04d}"] = f"Rate cycle {b}"
                    canvas[
                        3 * b + 1,
                        origin[j, 1] + iy * factor : origin[j, 1] + (iy + 1) * factor,
                        origin[j, 0] + ix * factor : origin[j, 0] + (ix + 1) * factor,
                    ] = tinit[j, iy, ix]
                    hdr[f"FR{3 * b + 2:04d}"] = f"Initial thickness cycle {b}"
                    if b == 0:
                        # do the residual once
                        canvas[
                            -1,
                            origin[j, 1] + iy * factor : origin[j, 1] + (iy + 1) * factor,
                            origin[j, 0] + ix * factor : origin[j, 0] + (ix + 1) * factor,
                        ] = rmsf.reshape((18, nb, nb))[j, iy, ix]
                        hdr[f"FR{np.shape(canvas)[0]:04d}"] = "RMS residual overall"

    # write
    phdu = fits.PrimaryHDU(pars.astype(np.float32))
    phdu.header["NSCA"] = (18, "Number of chips")
    phdu.header["NSPRPIX"] = (18 * nb**2, "Number of super-pixels per axis")
    phdu.header["NPERAXIS"] = (nb, "Number of super-pixels per axis")
    phdu.header["NTSTAMP"] = (nt, "Number of epochs, excluding reference")
    phdu.header["NRESET"] = (len(tresets), "Number of decontaminations in the time baseline")
    for k in range(len(tresets)):
        phdu.header[f"RST{k+1:04d}"] = (tresets[k], f"Time of {k+1:d}th reset")
    with fits.open(cfg["TREND"]) as f:
        phdu.header["MJDINIT"] = (f[2].data[0], "MJD of first epoch")
    phdu.header["REGPAR"] = (cfg.get("REGPAR", 0.0), "2nd derivative regularization")
    if "MODS" in cfg:
        for k in cfg["MODS"]:
            phdu.header[k] = (cfg["MODS"][k], MOD_COMMENTS[k])
    phdu.header["INITGRAY"] = (initgray, "Included gray term in cycle 0 (T/F)")
    phdu.header["TEMPCOEF"] = (tempcoef, "Included temperature coefficient (T/F)")
    relrsp = fits.ImageHDU(box, name="RELRSP")
    relrsp.header["IWLMIN"] = (cfg["IWL"][0], "inverse wavelength of first slice in um**-1")
    relrsp.header["IWLMAX"] = (cfg["IWL"][1], "inverse wavelength of last slice in um**-1")
    relrsp.header["NIWL"] = (cfg["IWL"][2], "number of inverse wavelengths")
    relrsp2 = fits.ImageHDU(box2, name="RELRSP2")
    relrsp2.header["IWLMIN"] = (cfg["IWL"][0], "inverse wavelength of first slice in um**-1")
    relrsp2.header["IWLMAX"] = (cfg["IWL"][1], "inverse wavelength of last slice in um**-1")
    relrsp2.header["NIWL"] = (cfg["IWL"][2], "number of inverse wavelengths")
    relrsp2.header["TKMIN"] = (cfg["ICE_T"][0], "first ice thickness in um")
    relrsp2.header["TKMAX"] = (cfg["ICE_T"][1], "last ice thickness in um")
    relrsp2.header["NTK"] = (cfg["ICE_T"][2], "number of ice thicknesses")
    fits.HDUList(
        [
            phdu,
            fits.ImageHDU(pic.astype(np.float32), name="WATERFAL"),
            fits.ImageHDU(rmsf.reshape((18, nb, nb)).astype(np.float32), name="RESID"),
            fits.ImageHDU(timestamps[1:], name="TIMESTMP"),
            fits.ImageHDU(canvas * 1000, name="FPAPLOT", header=fits.Header(dict(sorted(hdr.items())))),
            relrsp,
            relrsp2,
            fits.ImageHDU(dratio, name="RESID_B"),
        ]
    ).writeto(cfg["OUTPUT"], overwrite=True)

    # make table of thicknesses
    with fits.open(cfg["TREND"]) as f:
        tt = f[2].data[1:] - f[2].data[0]
    thickness = np.zeros((len(tt), 19), dtype=np.float32)
    thickness[:, 0] = tt
    with fits.open(cfg["OUTPUT"]) as f:
        thickness[:, 1:] = np.median(f[0].data[npfix:, :].reshape((len(tt), 18, -1)), axis=-1)
    np.savetxt(cfg["OUTPUT"][:-5] + "_thickness.dat", thickness)


if __name__ == "__main__":
    with open(sys.argv[1]) as f:
        cfg = yaml.safe_load(f)
    icefit_main(cfg)
