"""This is a simple script to find the bottom of the Band 1 relative response.

The idea was to compare to the 13.17 day time lag between the decontaminations and
find out if we reach the minimum at the same point. This is hoped to be a model-
independent way of figuring out if the rate has changed.
"""

import numpy as np
from astropy.io import fits

# Some notes on temperatures
# T = 140 K at:
# 2026/09/11 16:23 (initial cooldown)
# 2026/09/24 20:25 (1st decon)

# Restart epochs
re = [34]

with fits.open("flat_ratio_cube_nl.fits") as f:
    tcshape = np.shape(f[3].data)
    nt = tcshape[0] // 6
    npx = tcshape[1] // 18
    print(f" {nt} time stamps, {npx} superpixels")
    data = f[3].data[:nt, :npx]
    time = f[2].data

tcross = np.zeros((npx, len(re) + 1))

for j in range(len(re) + 1):
    tbounds = ([0] + re + [nt])[j:j+2]
    tstart = tbounds[0]
    tend = tbounds[1]
    print("time period", j, tstart, tend)

    t = 0.5 * (time[tstart:tend-1] + time[tstart+1:tend])
    drdt = np.log(data[tstart+1:tend] / data[tstart:tend-1]) / (time[tstart+1:tend] - time[tstart:tend-1])[:, None]
    tmin = np.argmin(data[tstart:tend-1], axis=0)
    for k in range(npx):
        q = tmin[k]
        tcross[k, j] = t[q-1] + (t[q]-t[q-1]) * (- drdt[q-1,k]) / (drdt[q,k] - drdt[q-1,k])

delta_t = tcross[:, 1] - tcross[:, 0]
for c in range(10, 100, 10):
    print(f"{c:2d} {np.percentile(delta_t, c):6.3f}")
