Description of ice fit files
############################

The files contain the following HDUs::

   No.    Name      Ver    Type      Cards   Dimensions   Format
     0  PRIMARY       1 PrimaryHDU       6   (1152, 34)   float64   
     1  WATERFAL      1 ImageHDU         8   (1162, 49)   float64   
     2  RESID         1 ImageHDU         8   (8, 144)   float64   
     3  TIMESTMP      1 ImageHDU         7   (29,)   float64   
     4  FPAPLOT       1 ImageHDU         8   (416, 258)   float32   
     5  RELRSP        1 ImageHDU        12   (1152, 67, 28)   float32   

(dimensions are representative: in the case above, there are 28 epochs and each SCA is divided into an 8x8 grid of superpixels). Some information is repeated for ease of display in tools such as ds9. In the future some results may be changed to float32.

The superpixels are arranged in a "flattened" order, so in the case above there are ``18*8**2=1152`` superpixels. The SCA number is first (WFI01..WFI18); then the Science Y-axis; then the Science X-axis. So if you wanted the column number in the PRIMARY HDU containing the (819, 1550) physical pixel in WFI12, you would write:

.. code-block:: python

    import math
    import numpy as np
    from astropy.io import fits

    chip, x, y = 12, 819, 1550  # which location I want

    with fits.open("icefit-260922.fits") as f:
        n_superpix = np.shape(f[0].data)[-1]  # gives 1152
        nb = math.isqrt(n_superpix // 18)  # gives 8: number of superpixels on each axis
        superpix_size = 4096 // nb  # gives 512: size of each superpixel
        pix = (chip - 1) * nb**2 + y // superpix_size * nb + x // superpix_size  # in python order: WFI12 is [11]

    print(pix)  # gives 729

The PRIMARY HDU
===============

This is a 2D array of the coating parameters and ice thicknesses. The data array is organized so that the ice thickness in epoch ``it`` in superpixel ``pix`` is ``data[6 + it, pix]``. The number of rows in the image is 6 + the number of epochs; and the number of columns is the number of superpixels.

The bottom rows, ``data[:6, :]``, contain the coating fit parameters, with the median taken out and arbitrarily scaled.

The WATERFAL HDU
================

This is a 2D image mainly intended for display in ds9. The region ``data[11:-10, 10:]`` contains the same ice thicknesses as in the PRIMARY HDU. The coating parameters are displayed along the bottom (in ``data[:6, 10:]``); the time since reference epoch is displayed along the left in ``data[11:-10, :5]``; and the residuals are displayed along the top in ``data[-5:, 10:]``.

The RESID HDU
=============

This is the residual map. It is 2D for display, but can be loaded as a vector in the usual superpixel order with ``data.ravel()``.

The TIMESTMP HDU
================

This is a vector of the epochs in days since the reference epoch.

The FPAPLOT HDU
===============

This is a 2D map of the focal plane, in Science orientation (WFI18 in bottom left, WFI16 in top left, WFI09 in bottom right, WFI07 in top right). The values are deposition rates in nm/day. Values of 1.0e+12 are not in an SCA (this way you can display in ds9 on a white background).

The RELRSP HDU
==============

The relative response, i.e., sensitivity of each HDU relative to the reference epoch. This is 3D, so you can get response at epoch ``it``, wavenumber bin ``il``, and superpixel ``pix`` in ``data[it, il, pix]``.

The wavenumbers are equally spaced, with the bluest (highest wavenumber) in ``il=0``. The ordering is given by the keywords::

  IWLMIN  =                  2.1 / inverse wavelength of first slice in um**-1     
  IWLMAX  =                  0.4 / inverse wavelength of last slice in um**-1     
  NIWL    =                   67 / number of inverse wavelengths                  

so that the array of wavelengths (in microns) can be computed as:

.. code-block:: python

    import numpy as np
    from astropy.io import fits

    with fits.open("icefit-260922.fits") as f:
        h = f["RELRSP"].header
        wl = 1.0 / np.linspace(h["IWLMIN"], h["IWLMAX"], h["NIWL"])
