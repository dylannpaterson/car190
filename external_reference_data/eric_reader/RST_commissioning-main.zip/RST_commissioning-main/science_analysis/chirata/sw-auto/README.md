# Trending scripts

This script runs solid-waffle on the ice monitor data.

The pass numbers are set in the script itself, e.g. to do passes 1, 2, and 3:

```
    perl $SLURM_SUBMIT_DIR/sw_template.pl $WFI 1 2 3
```
