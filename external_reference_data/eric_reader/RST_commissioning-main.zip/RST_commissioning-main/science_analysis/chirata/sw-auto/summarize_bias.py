"""Makes combined images of the bias changes."""

import numpy as np
from astropy.io import fits

tdir = "/data/chirata/bias/2026-10-04"

# Waterfall plot
with fits.open(f"{tdir}/delta_bias-1.fits.gz") as f:
  n = np.shape(f[0].data)[0]
im = np.zeros((n, 18432), dtype=np.int16)
for j in range(18):
  print(j, flush=True)
  with fits.open(f"{tdir}/delta_bias-{j+1:d}.fits.gz") as f:
    for k in range(n):
      im[k, 1024*j:1024*(j+1)] = np.median(f[0].data[k].reshape((32, 128, 32, 128)), axis=(1, 3)).ravel()
fits.PrimaryHDU(im).writeto(f"{tdir}/delta_bias_allscas.fits", overwrite=True)


# Now the SCA mosaic video
scapos = np.array(
    [
        [-22.1400, 12.1500],
        [-22.2900, -37.0300],
        [-22.4400, -82.0600],
        [-66.4200, 20.9000],
        [-66.9200, -28.2800],
        [-67.4200, -73.0600],
        [-110.7000, 42.2000],
        [-111.4800, -6.9800],
        [-112.6400, -51.0600],
        [22.1400, 12.1500],
        [22.2900, -37.0300],
        [22.4400, -82.0600],
        [66.4200, 20.9000],
        [66.9200, -28.2800],
        [67.4200, -73.0600],
        [110.7000, 42.2000],
        [111.4800, -6.9800],
        [112.6400, -51.0600],
    ],
    dtype=np.float64,
)
nb = 32
nb0 = 64
scapos_flip = np.copy(scapos)
scapos_flip[:, 0] *= -1
origin = np.round(scapos_flip / 40.88 * nb0).astype(np.int16)
for j in range(2):
    origin[:, j] -= np.amin(origin[:, j])
ny = np.amax(origin[:, 1]) + nb0
nx = np.amax(origin[:, 0]) + nb0
factor = nb0 // nb


canvas = np.zeros((n, ny, nx), dtype=np.float32)
canvas[:, :, :] = 1e9
for b in range(n):
    dbias = im[b].reshape((18, nb, nb))
    for j in range(18):
       for ix in range(nb):
           for iy in range(nb):
               canvas[
                   b,
                   origin[j, 1] + iy * factor:origin[j, 1] + (iy+1) * factor,
                   origin[j, 0] + ix * factor:origin[j, 0] + (ix+1) * factor
               ] = dbias[j, iy, ix]
delta_bias = fits.PrimaryHDU(canvas)
delta_bias.header["NPASSES"] = n
delta_bias.header["PRGM"] = "CAR-216"
delta_bias.header["COMMENT"] = "Bias minus final in DN"
delta_bias.header["COMMENT"] = "Projected in science frame"
delta_bias.writeto(f"{tdir}/delta_bias_video.fits", overwrite=True)
