import numpy as np
import sys
from astropy.io import fits

# get the files
with open("infiles.txt") as f:
    files = f.readlines()
files = [fn.rstrip() for fn in files]

ne = 2
intercepts = np.zeros((len(files), 4096, 4096), dtype=np.float32)
j = 0
for fn in files:
    with fits.open(fn) as f:
        nt = np.shape(f[0].data)[0] - ne
        t = np.array(range(ne, nt + ne))
        im = f[0].data[ne:, :, :4096].astype(np.float32)
        sy = np.sum(im, axis=0)
        sty = np.sum(im * t[:, None, None], axis=0)
    del im
    print("<<", fn, flush=True)
    # slope: (nt * sty - np.sum(t) * sy) / (nt * np.sum(t**2) - np.sum(t)**2)
    intercepts[j, :, :] = (np.sum(t**2) * sy - np.sum(t) * sty) / (nt * np.sum(t**2) - np.sum(t)**2)
    j += 1

intercept = np.median(intercepts, axis=0)

# if we're asked to subtract something
if len(sys.argv) > 1:
    with fits.open("med.fits") as f:
        delta_bias = intercept - f[0].data
    delta_bias = np.clip(delta_bias, -37268, 32767).astype(np.int16)

    p = int(sys.argv[1])
    np.save(f"delta_bias_{p:d}.npy", delta_bias)

else:
    # the reference array
    hdu = fits.PrimaryHDU(intercept)
    j = 0
    for fn in files:
        hdu.header[f"INP{j:04d}"] = fn
        j += 1
    hdu.writeto("med.fits", overwrite=True)
