# setup for solid-waffle run

($sca, $passes) = @ARGV;

$v = '02';
$p = $passes;
if ($passes > 90) {
  $v = '03';
  $p = $passes - 90;
}

# write file
open(OUT, ">sw_auto.txt") or die;
print OUT (sprintf "DETECTOR: WFI%02d\n", $sca);
print OUT "LIGHT:\n";
for $j (1 .. 4) {
    print OUT (sprintf "  indata/r01063$v%03d001009001_%04d_wfi%02d_dark_uncal_asdf_to.fits\n", $p, $j, $sca);
}
print OUT "DARK:\n";
for $j (1 .. 4) {
    print OUT (sprintf "  indata/r01063$v%03d001008001_%04d_wfi%02d_dark_uncal_asdf_to.fits\n", $p, $j, $sca);
}
print OUT "FORMAT: 1\n";
print OUT "CHAR: Advanced 1 3 2 bfe\n";
print OUT "NLPOLY: 3 2 12\n";
print OUT "FULLNL: True True True\n";
print OUT "TIMEREF: 1\n";
print OUT "TIME:    2 6 7 11\n";
print OUT (sprintf "OUTPUT:         results/icemon-car216-pass$passes-wfi%02d\n", $sca);
close OUT;

# now download the data
@files = ();
for $j (1 .. 4) {
    for $c (8, 9) {
        $fnew = sprintf "r01063$v%03d00100%1d001_%04d_wfi%02d_dark_uncal_asdf_to.fits", $p, $c, $j, $sca;
        @files = (@files, $fnew);
    }
}

$ct = 0;
for $f (@files) {
    $fa = $f;
    $fa =~ s/_asdf_to\.fits$/\.asdf/;
    $ff = (split "\_uncal", $f)[0];
    print "fetching $fa <-- $ff\%2F$fa\n";

    $e = qq|curl -H "Authorization: token \$MAST_API_TOKEN" -L -X GET "https://mast.stsci.edu/search/roman/api/v0.1/retrieve_product?product_name=$ff\%2F$fa" --output "indata/$fa"|;
    system $e;

    $ct++;
}
