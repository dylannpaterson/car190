# setup for solid-waffle run

($sca, $pass) = @ARGV;

$p1 = $p2 = $pass;
if ($pass == 0) {
   $p1 = 117; $p2 = 126;
}

# now download the data
@files = ();
for $j (1 .. 4) {
    for $passes ($p1..$p2) {
        $v = 2; $p = $passes;
        if ($passes > 90) {$v=3; $p=$passes-90;}
        $fnew = sprintf "r01063%02d%03d00100%1d001_%04d_wfi%02d_dark_uncal_asdf_to.fits", $v, $p, 8, $j, $sca;
        @files = (@files, $fnew);
    }
}
$ct = 0;
open(IN, ">infiles.txt");
for $f (@files) {
    $fa = $f;
    $fa =~ s/_asdf_to\.fits$/\.asdf/;
    $ff = (split "\_uncal", $f)[0];
    print "fetching $fa <-- $ff\%2F$fa\n";

    $e = qq|curl -H "Authorization: token \$MAST_API_TOKEN" -L -X GET "https://mast.stsci.edu/search/roman/api/v0.1/retrieve_product?product_name=$ff\%2F$fa" --output "$fa"|;
    system $e;

    $ct++;
    print IN "$f\n";
}
close IN;
print "===\n";
system "cat infiles.txt";
print "===\n";

system "python \$SLURM_SUBMIT_DIR/convert.py .";
system "rm *.asdf";

$c = '';
if ($pass > 0) {$c=" $pass";}
system "python \$SLURM_SUBMIT_DIR/med.py$c";
