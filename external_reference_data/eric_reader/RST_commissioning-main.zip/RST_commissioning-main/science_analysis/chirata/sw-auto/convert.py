"""Converts ASDF files in the cwd to FITS, and saves header information in a text file."""

import asdf
import glob
import os
from solid_waffle.asdf_to_fits import main as a2f_main
import sys

asdf_files = glob.glob("*.asdf")
for fn in asdf_files:
    fo = sys.argv[1] + "/" + fn[:-5] + "_header.txt"
    with asdf.open(fn) as a, open(fo, "w") as f:
        old_stdout = sys.stdout
        sys.stdout = f
        try:
            a.info(max_rows=None)
        finally:
            sys.stdout = old_stdout
    print(fn)
a2f_main(output_dir=sys.argv[1], format="flight_eng")

