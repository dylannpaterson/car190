import asdf
import sys
import numpy as np

if __name__ == "__main__":
  with asdf.open(sys.argv[1]) as a:
    d = a["roman"]["data"].astype(np.float32)
    t = np.array(a["roman"]["meta"]["exposure"]["read_pattern"]).ravel()

    print(sys.argv[1])
    print(t)
    dframe = (d[-1] - d[0]) / (t[-1] - t[0])
    print(np.nanmedian(dframe))
    print(a["roman"]["meta"]["rcs"])
    print("")
