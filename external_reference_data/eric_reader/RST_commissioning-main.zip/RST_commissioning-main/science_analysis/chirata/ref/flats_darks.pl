# setup for solid-waffle run

($sca) = @ARGV;

# now download the data

@files = ();
@grps = ();

# first 60 are flats, then 10 darks
for $j (7..13) {
    @grps = (@grps, (scalar @files));
    $emax = 5;
    if ($j==13) {$emax=10;}
    for $e (1..$emax) {
        $fnew = sprintf "r0101101001001%03d001_%04d_wfi%02d_dark_uncal_asdf_to.fits", $j, $e, $sca;
        @files = (@files, $fnew);
    }
}

#for $j (1 .. 14) {
#    @grps = (@grps, (scalar @files));
#    for $e (1) {
#        $fnew = sprintf "r0102701011001%03d001_%04d_wfi%02d_dark_uncal_asdf_to.fits", $j, $e, $sca;
#        @files = (@files, $fnew);
#    }
#}

$ngrps = scalar @grps;
@grps = (@grps, (scalar @files));
for $j (0..$ngrps-1) {
    print (sprintf "%2d %4d %3d\n", $j, $grps[$j], $grps[$j+1] - $grps[$j]);
}

$ct = 0;
open(OUT, ">files.txt") or die;
for $f (@files) {
    $fa = $f;
    $fa =~ s/_asdf_to\.fits$/\.asdf/;
    $ff = (split "\_uncal", $f)[0];
    print "fetching $fa <-- $ff\%2F$fa\n";

    $ex = qq|curl -H "Authorization: token \$MAST_API_TOKEN" -L -X GET "https://mast.stsci.edu/search/roman/api/v0.1/retrieve_product?product_name=$ff\%2F$fa" --output "indata/$fa"|;
    if ($ct%8==0) {system $ex;}

    system "python -m basicinfo indata/$fa";
    print OUT "$fa\n";
    $ct++;
}
close OUT;
