"""IPC plot; based on the gain plot by Anthony Harbo Torres, with additions by Chris Hirata."""

import re
from pathlib import Path

import numpy as np
import pandas as pd
from astropy.io import fits

NUM_SCAS = 18
SUPERPIX_N = 32
STARTING_JOBID = 7656
ENDING_JOBID = 8848

nskip_start = 30  # how many to skip in the median

scapos = np.array(
    [
        [-22.1400, 12.1500],
        [-22.2900, -37.0300],
        [-22.4400, -82.0600],
        [-66.4200, 20.9000],
        [-66.9200, -28.2800],
        [-67.4200, -73.0600],
        [-110.7000, 42.2000],
        [-111.4800, -6.9800],
        [-112.6400, -51.0600],
        [22.1400, 12.1500],
        [22.2900, -37.0300],
        [22.4400, -82.0600],
        [66.4200, 20.9000],
        [66.9200, -28.2800],
        [67.4200, -73.0600],
        [110.7000, 42.2000],
        [111.4800, -6.9800],
        [112.6400, -51.0600],
    ],
    dtype=np.float64,
)


def build(ax):
    """Main function for axis ax = "h", "v", or "d"."""

    col_num = 6 if ax.lower() == "h" else 7
    if ax.lower() == "d":
        col_num = 10

    # Check working directory and path to data directory
    print("Current working directory:")
    print(Path.cwd())

    root_dir = Path("/").resolve()
    data_dir = Path(f"{root_dir}/data/chirata/sw-trending/").resolve()
    print(f"Data directory resolves to {data_dir}")

    # See which files are avialable in the data directory
    txt_files = list(data_dir.rglob("*.txt"))

    print("Number of txt files found:", len(txt_files))

    for file_path in txt_files[:20]:
        print(file_path)

    summary_files = list(data_dir.rglob("*wfi*_summary*.txt"))

    print("Summary files:", len(summary_files))
    for file_path in summary_files[:10]:
        print(file_path)

    # Extract SCA number from the filenames
    sca_pattern = re.compile(r"wfi(\d+)", re.IGNORECASE)
    file_lookup = {}

    for file_path in summary_files:

        match = sca_pattern.search(file_path.name)

        if not match:
            continue

        sca_num = int(match.group(1))
        pass_id = file_path.parent.name

        if pass_id not in file_lookup:
            file_lookup[pass_id] = {}

        file_lookup[pass_id][sca_num] = file_path

    # Get the passes from the files found
    pass_ids = sorted([pass_id for pass_id in file_lookup.keys() if int(pass_id) >= STARTING_JOBID and int(pass_id) <= ENDING_JOBID], key=int)
    num_passes = len(pass_ids)

    print(f"Starting job ID: {STARTING_JOBID}")
    print(f"Number of passes found: {num_passes}")
    print(f"Pass IDs: {pass_ids}")

    # Create the data array
    data = np.zeros((NUM_SCAS * SUPERPIX_N * SUPERPIX_N, num_passes), dtype=np.float32)

    # Populate it
    for pass_idx, pass_id in enumerate(pass_ids):

        for sca_num in range(1, NUM_SCAS + 1):
            file_path = file_lookup[pass_id].get(sca_num)

            if file_path is None:
                print(f"WARNING: No SCA {sca_num:02d} file found for pass {pass_id}")
                continue

            data_file = np.loadtxt(file_path)

            # Grab desired column
            sca_data = data_file[:, col_num]

            start = ((sca_num - 1)* SUPERPIX_N* SUPERPIX_N)
            stop = (sca_num* SUPERPIX_N* SUPERPIX_N)

            # Store this SCA for this pass
            data[start:stop,pass_idx] = sca_data

    print(f"Shape of the data array is: {data.shape}")

    # Check for non-finite values
    print("Total non-finite superpixels:", np.sum(~np.isfinite(data)))
    data[np.isinf(data)] = np.nan
    data[data==0] = np.nan

    hdus = [fits.PrimaryHDU(data)]

    nt = np.shape(data)[-1]

    fits.HDUList(hdus).writeto(f"ipc_{ax}_array.fits", overwrite=True)


def convert_to_plot():
    """Makes an IPC plot."""

    # 2D plot
    # bounds
    nb0 = 64
    scapos_flip = np.copy(scapos)
    scapos_flip[:, 0] *= -1
    origin = np.round(scapos_flip / 40.88 * nb0).astype(np.int16)
    for j in range(2):
        origin[:, j] -= np.amin(origin[:, j])
    ny = np.amax(origin[:, 1]) + nb0
    nx = np.amax(origin[:, 0]) + nb0
    factor = nb0 // SUPERPIX_N

    # IPC image -- H, V, D
    canvas = np.zeros((4, ny, nx), dtype=np.float32)
    canvas[:, :, :] = 1e9
    flist = ["ipc_h_array.fits", "ipc_v_array.fits", "ipc_d_array.fits"]
    full_im = np.zeros((3, 18 * SUPERPIX_N**2), dtype=np.float32)
    for b in range(3):
        with fits.open(flist[b]) as f:
            nt = np.shape(f[0].data)[-1]
            fmask = np.mean(np.isnan(f[0].data[:, nskip_start:]), axis=-1).reshape((18, SUPERPIX_N, SUPERPIX_N))
            data = np.nanmedian(f[0].data[:, nskip_start:], axis=-1).reshape((18, SUPERPIX_N, SUPERPIX_N))
            full_im[b] = data.ravel()

        for j in range(18):
           for ix in range(SUPERPIX_N):
               for iy in range(SUPERPIX_N):
                   canvas[
                       b,
                       origin[j, 1] + iy * factor:origin[j, 1] + (iy+1) * factor,
                       origin[j, 0] + ix * factor:origin[j, 0] + (ix+1) * factor
                   ] = data[j, iy, ix]

                   if b == 0:
                       canvas[
                           -1,
                           origin[j, 1] + iy * factor:origin[j, 1] + (iy+1) * factor,
                           origin[j, 0] + ix * factor:origin[j, 0] + (ix+1) * factor
                       ] = fmask[j, iy, ix]

    fits.PrimaryHDU(canvas).writeto("ipc_mosaic.fits", overwrite=True)

    # combined file
    hdus = [fits.PrimaryHDU(full_im)]
    hdus[0].header["COMMENT"] = "Flattened median IPC image in superpixels."
    hdus[0].header["SPIX_N"] = (SUPERPIX_N, "Number of superpixels on each side")
    hdus[0].header["ROW1"] = "IPC alpha horizontal"
    hdus[0].header["ROW2"] = "IPC alpha vertical"
    hdus[0].header["ROW3"] = "IPC alpha diagonal"
    labels = ["HORZ", "VERT", "DIAG"]
    for b in range(3):
        with fits.open(flist[b]) as f:
            nt = np.shape(f[0].data)[-1]
            new_hdu = fits.ImageHDU(f[0].data, name = "IPC_" + labels[b])
            hdus.append(new_hdu)
    fits.HDUList(hdus).writeto("ipc_car216.fits", overwrite=True)


if __name__ == "__main__":
    build("h")
    build("v")
    build("d")
    convert_to_plot()
