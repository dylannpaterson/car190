"""Tests for access_data.py. Network tests need MAST access (and MAST_API_TOKEN).

Test written to be run at SMDC because of the hardcoded paths and group name.

Tests written by Claude Sonnet 5.5 with prompting and review by Michael Wood-Vasey.
"""
import grp
import os

import pytest

import access_data

# Examples taken from progid 1049
F062_BASE = "r0104901001001001001"
F158_BASE = "r0104901001001002001"


@pytest.fixture(scope="module")
def missions():
    return access_data.get_mast_connection()


def test_parse_args_defaults():
    args = access_data.parse_args(["1049"])
    assert args.progid == 1049
    assert args.level == "L2"
    assert args.bands is None
    assert args.staging_dir == f"/mnt/smdc-rom-com-ops/rrn-ops/{os.environ['LOGNAME']}/data"
    assert args.output_dir == "/mnt/supernovae/internal/data/1049"
    assert access_data.parse_args(["62"]).output_dir == "/mnt/supernovae/internal/data/0062"


def test_ensure_dir_creates_group_dirs(tmp_path):
    target = tmp_path / "a" / "b"
    access_data.ensure_dir(str(target))
    for d in (tmp_path / "a", target):
        assert d.is_dir()
        assert d.stat().st_mode & 0o770 == 0o770
        assert d.stat().st_gid == grp.getgrnam("supernovae").gr_gid


def test_parse_args_options():
    args = access_data.parse_args(
        ["1049", "--staging-dir", "/tmp/s", "--output-dir", "/tmp/o", "--level", "L1", "--bands", "f158"]
    )
    assert (args.staging_dir, args.output_dir, args.level, args.bands) == ("/tmp/s", "/tmp/o", "L1", ["f158"])


def test_parse_args_band_lists():
    assert access_data.parse_args(["1049", "--bands", "F062,f158"]).bands == ["f062", "f158"]
    assert access_data.parse_args(["--bands", "F062", "1049"]).bands == ["f062"]
    assert access_data.parse_args(["1049", "--bands", "F062,f158,prism,F062"]).bands == ["f062", "f158", "prism"]
    with pytest.raises(SystemExit):
        access_data.parse_args(["1049", "--bands", "f062,bogus"])
    # Space-separated lists are not accepted
    with pytest.raises(SystemExit):
        access_data.parse_args(["1049", "--bands", "f062", "f158"])


def test_get_file_list_band(missions):
    files = access_data.get_file_list(missions, 1049, level="L2", bands=["f062"])
    assert f"{F062_BASE}_0001_wfi01_f062_cal.asdf" in files
    assert all(f.endswith("_f062_cal.asdf") for f in files)


def test_get_file_list_multiple_bands(missions):
    files = access_data.get_file_list(missions, 1049, level="L2", bands=["f062", "f158"])
    assert f"{F062_BASE}_0001_wfi01_f062_cal.asdf" in files
    assert f"{F158_BASE}_0001_wfi01_f158_cal.asdf" in files


def test_get_file_list_l1(missions):
    files = access_data.get_file_list(missions, 1049, level="L1", bands=["f158"])
    assert f"{F158_BASE}_0001_wfi01_f158_uncal.asdf" in files


def test_fetch_and_save_staging(missions, tmp_path):
    filename = f"{F062_BASE}_0001_wfi01_f062_cal.asdf"
    staging, out = tmp_path / "staging", tmp_path / "out"
    access_data.fetch_and_save(missions, filename, out_dir=str(out), staging_dir=str(staging))
    assert (out / filename).exists()
    assert not (staging / filename).exists()

    # Second call skips existing file
    mtime = (out / filename).stat().st_mtime
    access_data.fetch_and_save(missions, filename, out_dir=str(out), staging_dir=str(staging))
    assert (out / filename).stat().st_mtime == mtime


def test_band_case_insensitive(missions):
    assert access_data.get_file_list(missions, 1049, bands=["F062"]) == access_data.get_file_list(missions, 1049, bands=["f062"])


def test_copy_verified_success(tmp_path):
    src, dst = tmp_path / "src.asdf", tmp_path / "dst.asdf"
    src.write_bytes(b"x" * 1000)
    access_data.copy_verified(str(src), str(dst))
    assert dst.read_bytes() == src.read_bytes()
    assert src.exists()


def test_copy_verified_removes_partial_on_error(tmp_path, monkeypatch):
    src, dst = tmp_path / "src.asdf", tmp_path / "dst.asdf"
    src.write_bytes(b"x" * 1000)

    def failing_copy(s, d):
        with open(d, "wb") as f:
            f.write(b"x" * 10)
        raise OSError("disk went away")

    monkeypatch.setattr(access_data.shutil, "copyfile", failing_copy)
    with pytest.raises(OSError, match="disk went away"):
        access_data.copy_verified(str(src), str(dst))
    assert not dst.exists()
    assert src.exists()


def test_copy_verified_removes_truncated_copy(tmp_path, monkeypatch):
    src, dst = tmp_path / "src.asdf", tmp_path / "dst.asdf"
    src.write_bytes(b"x" * 1000)

    def truncating_copy(s, d):
        with open(d, "wb") as f:
            f.write(b"x" * 10)

    monkeypatch.setattr(access_data.shutil, "copyfile", truncating_copy)
    with pytest.raises(OSError, match="Incomplete copy"):
        access_data.copy_verified(str(src), str(dst))
    assert not dst.exists()
    assert src.exists()


def test_copy_verified_same_file_not_removed(tmp_path):
    src = tmp_path / "src.asdf"
    src.write_bytes(b"x" * 100)
    alias = tmp_path / "." / "src.asdf"
    with pytest.raises(access_data.shutil.SameFileError):
        access_data.copy_verified(str(src), str(alias))
    assert src.exists()
