#
# Match catalogs for a given program ID, prefix, and minimum number of matches.
# Doesn't restrict by WFI

progid=${1:-"01062"}  # Default to CAR 915, Prog ID 1062 (HLTDS observation).  Override with second argument.
prefix=${2:-cleaned_simple}  # Default.  Override with third argument
min_matches=${3:-5}  # Default.  Number of matches required.
out_dir=${4:-/rrn-ops/wmwv/subtractions}  # Default.  Override with fourth argument.

base_file=matched_${progid}_${prefix}_${min_matches}plus
catalog_file=${base_file}.ecsv
region_file=${base_file}.reg
nested_file=${base_file}_nested.parquet
candidate_file=${base_file}_candidates.ecsv
candidate_region_file=${base_file}_candidates.reg

cleaned_catalog_file=cleaned_${catalog_file}
cleaned_region_file=cleaned_${region_file}

python -m sidecar.match_catalogs \
    ${out_dir}/F*${progid}*_-_F*/${prefix}_*.ecsv \
    --min-matches ${min_matches} \
    --row-filter "science_flags_npix_bad,==,0" \
    --row-filter "template_flags_npix_bad,==,0" \
    --row-filter "science_flags_center,==,0" \
    --row-filter "template_flags_center,==,0" \
    --min-pixel-separation 10 \
    --nested-output $nested_file \
    --output $catalog_file

# Candidate cuts that need all of an object's detections (bands, z, sign consistency,
# science-template change, flux range, isolation); see sidecar/candidates.py.
python -m sidecar.candidates \
    $nested_file \
    --star-catalog /rrn-ops/wmwv/data/gaia_car915.ecsv \
    --star-match-radius 5 \
    --star-ref-mag 18 \
    --star-max-radius 60 \
    --output $candidate_file \
    --region-file $candidate_region_file

python -m sidecar.reject_stars \
    ${catalog_file} /rrn-ops/wmwv/data/gaia_car915.ecsv \
    --match-radius 5 \
    --ref-mag 18 \
    --max-radius 60 \
    -o ${cleaned_catalog_file}

python -m sidecar.catalog_to_ds9_region_file \
    $catalog_file \
    --peak-value-column none \
    --ds9-region-path $region_file

python -m sidecar.catalog_to_ds9_region_file \
    $cleaned_catalog_file \
    --peak-value-column none \
    --ds9-region-path $cleaned_region_file
