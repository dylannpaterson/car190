#!/bin/bash
#SBATCH --job-name=car915_per_wfi
#SBATCH --partition=mem-med
#SBATCH --nodes=1
#SBATCH --time=06:00:00
#SBATCH --output=car915_wfi_%A_%a_detect_only.out
#SBATCH --error=car915_wfi_%A_%a_detect_only.err

# Run with
#   sbatch --array=1-18 run_car915_wfi_array.sbatch 

WFI=$SLURM_ARRAY_TASK_ID

RUN_DIR=${HOME}/snpit
CONTAINER_RUN_DIR=/home

# The ${RUN_DIR} refers to locations outside of the container
# while the -r will run the script inside the container, 
# so we use /home/packages/... to locate the RST_commissioning directory inside the container
bash ${RUN_DIR}/launch_container.sh \
   -r "bash ${CONTAINER_RUN_DIR}/packages/RST_commissioning/science_analysis/wmwv/setup_env_and_run_car915_per_wfi_detect_only.sh ${WFI}"
