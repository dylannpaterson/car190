#!/bin/bash
# Run subtractions for one WFI detector over all supported bands and all science dates.
#
# Usage: run_car201_individual_manualrdm_per_wfi.sh [WFI] [template_date]
#   WFI            Detector number, 1-18 (default 15)
#   template_date  Template date (default 2026-09-29).  Science dates equal to this are skipped.

SNPIT_PIPELINE_BASE=${HOME}/snpit/packages

output_dir=/rrn-ops/wmwv/subtractions

base_path=/rrn-ops/wmwv/data

# We can break these names into four parts: the CAR prefix, the date code, the band code, and the exposure number.
# {car_prefix}{date_code}{band_code}_{exposure_number}

car_prefix=r01062
exposure_code=0002

WFI_INPUT=${1:-15}
if [[ ! ${WFI_INPUT} =~ ^[0-9]+$ ]] || (( 10#${WFI_INPUT} < 1 || 10#${WFI_INPUT} > 18 )); then
    echo "Unsupported WFI '${WFI_INPUT}'. Choose a number from 1 to 18." >&2
    exit 1
fi
printf -v WFI "%02d" "$((10#${WFI_INPUT}))"


# F146 is omitted because it is not supported by the snappl STPSF class.
declare -A band_codes=(
    [f184]=001006
    [f158]=001005
    [f129]=001003
    [f106]=001002
    [f087]=001007
    [f062]=001001
)
bands=(f062 f087 f106 f129 f158 f184)

# There are two pointings to make up the ~circle of the HLTDS deep
# 001 and 002
# pointing_code="001"
pointing_code="002"

# 01001 is 2026-09-29 roll 1
# 01002 is 2026-09-29 roll 2
# 02001 is 2026-10-11 roll 1
# 02002 is 2026-10-11 roll 2
# 2026-10-11 roll 1 overlaps most with 2026-09-29 roll 2 so we'll start with those
declare -A date_codes=(
    [2026-09-29]=01002
    [2026-10-11]=02002
)
dates=(2026-09-29 2026-10-11)

template_date=${2:-2026-09-29}  # Default.  Override with second argument
template_date_code=${date_codes[$template_date]:-}
if [[ -z ${template_date_code} ]]; then
    echo "Unsupported template date '${template_date}'. Choose one of: ${dates[*]}" >&2
    exit 1
fi

star_catalog_filename=${base_path}/gaia_car915_${pointing_code}_${WFI}.ecsv
# Would like to do this with just one file for HLTDS
# but yields to warnings due to not being able to calculate the inverse of the WCS
# Maybe that's fine?  Maybe look to see if the inverse is available some other way?
# star_catalog_filename=${base_path}/gaia_car915.ecsv


for band in "${bands[@]}"; do
    band_code=${band_codes[$band]}

    for science_date in "${dates[@]}"; do
        science_date_code=${date_codes[$science_date]}
        if [[ ${science_date_code} == "${template_date_code}" ]]; then
            continue
        fi

        echo "Running for WFI ${WFI}, band ${band}, science date ${science_date}, template date ${template_date}"

        template_base="${car_prefix}${template_date_code}${band_code}${pointing_code}_${exposure_code}_wfi${WFI}_${band}"
        science_base="${car_prefix}${science_date_code}${band_code}${pointing_code}_${exposure_code}_wfi${WFI}_${band}"

        template_filename=${template_base}_cal.asdf
        science_filename=${science_base}_cal.asdf

        # Pre-generate the Gaia catalog (once per WFI; the file is reused for every band and date)
        if [ ! -e ${star_catalog_filename} ]; then
            python -m sidecar.star_retrieval \
                ${base_path}/${science_filename} \
                --output ${star_catalog_filename}
        fi

        python -m sidecar.pipeline \
            --image-collection manual_rdm \
            --base-path ${base_path} \
            --template-path ${template_filename} \
            --science-path ${science_filename} \
            --star-catalog ${star_catalog_filename} \
            --reject-known-stars \
            --psf-type STPSF \
            --cross-convolve \
            --temp-dir ${HOME}/tmp \
            --output-dir ${output_dir} \
            --save-debug-products \
            --backend4subtract numpy \
	        --assume-subtraction-has-been-run
# I like the idea of saying FAILEd, but this construction hides the actual output of the failing.
#            || { echo "Subtraction FAILED for WFI ${WFI}, band ${band}, science date ${science_date}" >&2; continue; }

## Commented out because it's not specific enough and runs all WFIs
#        subtraction_dir=${output_dir}/*${science_base:1:18}*${template_base:1:18}*
#        for file in ${subtraction_dir}/*detection*.ecsv; do
#            echo ${file}
#            python -m sidecar.catalog_to_ds9_region_file \
#                --peak-value-threshold 0 ${file} || { echo "Catalog to DS9 region file FAILED for WFI ${WFI}, band ${band}, science date ${science_date}" >&2; continue; }
#        done
    done
done
