#!/usr/bin/env python
"""Make postage stamps of a sky position from a list of Roman images.

With --mast, no image list is needed: MAST is queried (token in MAST_API_TOKEN) for
Roman L2 cal images near RA, Dec, optionally limited by --prog-id and --band, and
each is streamed into memory rather than saved.

With --mast --local-data-dir DIR, MAST is only used to find the image names; the
files are read from DIR instead of streamed.  Adding --local-subtraction-dir SUBDIR
also finds the sidecar subtractions (SUBDIR/<sci>_-_<tmpl>/simple_diff_<sci>_-_<tmpl>.fits,
with names like F062_<obs><exp>_<det>) whose science image is one of the MAST images,
and shows each as a row of (subtraction, science, template), sorted by filter and MJD.

The image list file has one image path per line (read with astropy.table;
blank lines and '#' comments are ignored).  Roman ASDF files (.asdf) are read with
roman_datamodels; anything else is read as FITS (first image HDU with data,
or --ext) using astropy.

Output modes (--mode):
  single : one PNG per stamp            <prefix>_<imagename>.png
  triplet: one PNG per set of three     <prefix>_set001.png, ... (in list order)
  mosaic : one PNG, 3 columns, N rows   <prefix>_mosaic.png

With --north-up, stamps are resampled to North up / East left (pixel area
preserved), so all stamps share one orientation.

With --flags, pixels with nonzero DQ bits are overlaid in colour (one colour
per roman_datamodels.dqflags.pixel flag; a legend lists those present).
"""

import argparse
import math
import os
import re
import sys
import textwrap

import matplotlib
import matplotlib.pyplot as plt
from matplotlib.colors import to_rgba
from matplotlib.patches import Patch
import numpy as np

from astropy import units as u
from astropy.coordinates import SkyCoord
from astropy.io import fits
from astropy.table import Table
from astropy.time import Time
from astropy.visualization import ZScaleInterval
from astropy.wcs import WCS
from astroquery.mast import MastMissions

import roman_datamodels as rdm
from roman_datamodels.dqflags import pixel

NCOLS = 3


def short_label(path, width=26, max_lines=3):
    """Compact multi-line label identifying an image without a long filename.

    Recognises Roman cal files (rPPPP..._EEEE_wfiNN_fXXX_cal.asdf) and
    simple_diff_<filter>_<sci>_<det>_-_<filter>_<tmpl>_<det>.fits files;
    anything else is wrapped (and middle-truncated if still too long)."""

    name = os.path.basename(path)
    m = re.match(r"r(\d+)_(\d+)_(wfi\d+)_(\w+?)_\w+\.asdf$", name, re.IGNORECASE)
    if m:
        obs, exp, det, filt = m.groups()
        return f"{det} {filt}\n{obs}_{exp}"
    m = re.match(r"simple_diff_(\w+?)_(\d+)_(\d+)_-_\w+?_(\d+)_\d+\.", name, re.IGNORECASE)
    if m:
        filt, sci, det, tmpl = m.groups()
        return f"diff wfi{int(det):02d} {filt}\n{sci}\n- {tmpl}"
    base = os.path.splitext(name)[0]
    lines = textwrap.wrap(base, width, break_long_words=True, break_on_hyphens=False)
    if len(lines) > max_lines:
        keep = width * max_lines - 3
        base = base[: keep // 2] + "..." + base[-(keep - keep // 2) :]
        lines = textwrap.wrap(base, width, break_long_words=True, break_on_hyphens=False)
    return "\n".join(lines)


class Stamp:
    """Cutout data plus metadata for one image."""

    def __init__(self, path, data, dq, x, y, status):
        self.path = path
        self.data = data  # 2D float array (NaN where off-image) or None
        self.dq = dq  # 2D int array or None
        self.x = x
        self.y = y
        self.status = status  # "" if fine, else a short message
        self.compass = None  # ((nx, ny), (ex, ey)) unit vectors in display axes
        self.contains = False  # True if (RA, Dec) falls within the image
        self.mjd = None  # observation MJD (float) if found in the metadata

    @property
    def title(self):
        label = short_label(self.path)
        if self.mjd is not None:
            label = f"MJD {self.mjd:.4f}\n{label}"
        return label


def _cutout(arr, xc, yc, size, fill):
    """Return a size x size cutout centered on (xc, yc) (integer pixel), padded
    with `fill` where it extends past the array.  None if fully outside."""
    half = size // 2
    x0, y0 = xc - half, yc - half
    x1, y1 = x0 + size, y0 + size
    ny, nx = arr.shape
    if x1 <= 0 or y1 <= 0 or x0 >= nx or y0 >= ny:
        return None
    out = np.full((size, size), fill, dtype=float if fill != 0 or arr.dtype.kind == "f" else arr.dtype)
    sx0, sy0 = max(x0, 0), max(y0, 0)
    sx1, sy1 = min(x1, nx), min(y1, ny)
    out[sy0 - y0 : sy1 - y0, sx0 - x0 : sx1 - x0] = arr[sy0:sy1, sx0:sx1]
    return out


def _mjd_from_header(headers):
    """MJD from FITS header(s): MJD-AVG/MJD-OBS/MJD, else DATE-OBS/DATE-BEG."""

    for keys in (
        ("MJD-AVG", "MJD-OBS", "MJD_OBS", "MJD", "EXPSTART"),
        ("DATE-AVG", "DATE-OBS", "DATE-BEG", "DATE_OBS"),
    ):
        for key in keys:
            for h in headers:
                if key in h:
                    if key.startswith("DATE"):
                        return float(Time(h[key]).mjd)
                    return float(h[key])
    return None


def _mjd_from_roman(dm):
    """MJD of exposure mid-time (falling back to start time) from Roman meta."""
    exp = dm.meta.exposure
    for name in ("mid_time", "start_time"):
        t = getattr(exp, name, None)
        if t is not None:
            return float(t.mjd)
    return None


class MastImage(str):
    """A Roman L2 cal file at MAST, streamed on demand.  The str value is the
    filename (used for labels); open() returns the roman_datamodels model."""

    missions = None

    def open(self):

        return rdm.open(self.missions.read_product(str(self)))


def _login_mast():
    """MastMissions('roman') logged in with MAST_API_TOKEN from the environment."""

    token = os.getenv("MAST_API_TOKEN")
    if not token:
        raise SystemExit("MAST_API_TOKEN must be set in the environment to use MAST")
    missions = MastMissions(mission="roman")
    missions.login(token=token)
    return missions


# This tuple defines the sort order for bands as well as the known bands.
BANDS = ("F062", "F087", "F106", "F129", "F158", "F184", "F213")
# Filename convention for filter (note that we're not including "prism" here)
_BAND_RE = re.compile(r"_f(\d{3})_", re.IGNORECASE)


def _band_of(path):
    m = _BAND_RE.search(os.path.basename(str(path)))
    return f"F{m.group(1)}" if m else None


_MAST_NAME_RE = re.compile(r"r(\d+)_(\d{4})_wfi(\d{2})_(f\d{3})_cal\.asdf$", re.IGNORECASE)
_SIDECAR_KEY_RE = re.compile(r"(F\d{3})_(\d+)_(\d+)$", re.IGNORECASE)


def mast_to_sidecar_key(name):
    """rPPPPP..._EEEE_wfiNN_fXXX_cal.asdf -> FXXX_PPPPP...EEEE_N (sidecar naming), or None."""
    m = _MAST_NAME_RE.search(os.path.basename(str(name)))
    if not m:
        return None
    obs, exp, det, filt = m.groups()
    return f"{filt.upper()}_{obs}{exp}_{int(det)}"


def sidecar_key_to_mast(key):
    """Inverse of mast_to_sidecar_key: FXXX_PPPPP...EEEE_N -> rPPPPP..._EEEE_wfiNN_fxxx_cal.asdf."""
    m = _SIDECAR_KEY_RE.match(key)
    if not m:
        return None
    filt, obsexp, det = m.groups()
    return f"r{obsexp[:-4]}_{obsexp[-4:]}_wfi{int(det):02d}_{filt.lower()}_cal.asdf"


def find_local_triplets(mast_images, data_dir, subtraction_dir):
    """Flat list [sub, sci, tmpl, sub, sci, tmpl, ...] of local paths.

    Each MAST image is translated to its sidecar name and used as the science
    image; every subtraction <sci>_-_<tmpl> found in subtraction_dir yields a
    triplet.  Triplets with any file missing locally are skipped with a warning."""
    subs = {}
    for d in sorted(os.listdir(subtraction_dir)):
        sci, sep, tmpl = d.partition("_-_")
        if sep:
            subs.setdefault(sci, []).append((d, tmpl))
    out = []
    for name in mast_images:
        key = mast_to_sidecar_key(name)
        for d, tmpl_key in subs.get(key, []):
            tmpl_name = sidecar_key_to_mast(tmpl_key)
            paths = [
                os.path.join(subtraction_dir, d, f"simple_diff_{d}.fits"),
                os.path.join(data_dir, os.path.basename(str(name))),
                os.path.join(data_dir, tmpl_name) if tmpl_name else None,
            ]
            missing = [p for p in paths if p is None or not os.path.exists(p)]
            if missing:
                print(f"warning: skipping {d}: missing {missing}", file=sys.stderr)
                continue
            out.extend(paths)
    return out

def _sort_key(stamp):
    """Order by filter (BANDS order, unknown last), then MJD (unknown last)."""
    band = _band_of(stamp.path)
    b = BANDS.index(band) if band in BANDS else len(BANDS)
    return (b, stamp.mjd is None, stamp.mjd if stamp.mjd is not None else 0.0)


def query_mast_images(ra, dec, prog_id=None, band=None, radius=0.001, missions=None):
    """Find L2 calibrated images (_cal) at MAST near (ra, dec) [deg].

    Only detector-level WFI images are returned (exposure type WFI_IMAGE, files
    named like rPPP..._wfiNN_fXXX_cal.asdf), not mosaics or other products.
    Optionally restricted to program `prog_id` and optical element `band`.
    `radius` (deg) is the search radius.  Returns a list of MastImage."""

    if missions is None:
        missions = _login_mast()
    MastImage.missions = missions
    search = {"coordinates": SkyCoord(ra * u.deg, dec * u.deg), "radius": radius * u.deg,
              "exposure_type": "WFI_IMAGE"}
    if prog_id is not None:
        search["program"] = prog_id
    if band is not None:
        search["optical_element"] = band.upper()
    results = missions.query_criteria(**search)
    if len(results) == 0:
        return []
    products = missions.get_unique_product_list(results)
    filtered = missions.filter_products(products, file_suffix="_cal")
    detector_level = re.compile(r"_wfi\d{2}_.*_cal\.asdf$", re.IGNORECASE)
    return sorted({MastImage(f) for f in filtered["filename"] if detector_level.search(f)})


def _load_roman(dm):
    data = np.asarray(dm.data, dtype=float)
    dq = np.asarray(dm.dq) if "dq" in dm and dm.dq is not None else None
    wcs = dm.meta.wcs
    mjd = _mjd_from_roman(dm)

    # gwcs invert takes (ra, dec) in deg and returns (x, y)
    def w2p(ra, dec):
        x, y = wcs.invert(ra, dec)
        return np.asarray(x, dtype=float), np.asarray(y, dtype=float)

    return data, dq, w2p, mjd


def _load(path, ext=None):
    """Return (data, dq, world_to_pixel, mjd) for an image file (mjd may be None).

    world_to_pixel(ra, dec) -> (x, y), 0-indexed pixel coordinates."""
    if isinstance(path, MastImage):
        with path.open() as dm:
            return _load_roman(dm)

    if path.lower().endswith(".asdf"):
        with rdm.open(path) as dm:
            return _load_roman(dm)

    with fits.open(path) as hdul:
        if ext is not None:
            hdu = hdul[ext]
        else:
            hdu = next(h for h in hdul if h.data is not None and h.data.ndim == 2)
        data = np.asarray(hdu.data, dtype=float)
        wcs = WCS(hdu.header)
        mjd = _mjd_from_header([hdu.header, hdul[0].header])
        dq = None
        if "DQ" in hdul:
            dq = np.asarray(hdul["DQ"].data)

    def w2p(ra, dec):
        x, y = wcs.all_world2pix(ra, dec, 0)
        return np.asarray(x, dtype=float), np.asarray(y, dtype=float)

    return data, dq, w2p, mjd


def _sample(arr, x, y, order):
    """Sample arr at pixel coords (x, y); order 0 = nearest, 1 = bilinear.
    Positions outside the array (or touching NaNs for bilinear) give NaN."""
    ny, nx = arr.shape
    out = np.full(x.shape, np.nan)
    if order == 0:
        xi, yi = np.rint(x), np.rint(y)
        ok = np.isfinite(xi) & np.isfinite(yi) & (xi >= 0) & (xi < nx) & (yi >= 0) & (yi < ny)
        out[ok] = arr[yi[ok].astype(int), xi[ok].astype(int)]
        return out
    ok = np.isfinite(x) & np.isfinite(y) & (x >= -0.5) & (x <= nx - 0.5) & (y >= -0.5) & (y <= ny - 0.5)
    xc, yc = np.clip(x[ok], 0, nx - 1), np.clip(y[ok], 0, ny - 1)
    x0, y0 = np.minimum(np.floor(xc).astype(int), max(nx - 2, 0)), np.minimum(np.floor(yc).astype(int), max(ny - 2, 0))
    x1, y1 = np.minimum(x0 + 1, nx - 1), np.minimum(y0 + 1, ny - 1)
    fx, fy = xc - x0, yc - y0
    out[ok] = (
        arr[y0, x0] * (1 - fx) * (1 - fy)
        + arr[y0, x1] * fx * (1 - fy)
        + arr[y1, x0] * (1 - fx) * fy
        + arr[y1, x1] * fx * fy
    )
    return out


def _north_up_coords(w2p, ra, dec, size):
    """Pixel coordinates (x, y) in the input image of each pixel of a
    north-up / east-left size x size grid centered on (ra, dec).

    The output pixel scale is chosen so the pixel area equals that of the input
    pixels at the target position."""
    cosd = np.cos(np.radians(dec))
    h = 1.0 / 3600.0  # 1 arcsec probe step
    x0, y0 = w2p(ra, dec)
    xe, ye = w2p(ra + h / cosd, dec)
    xn, yn = w2p(ra, dec + h)
    det = abs((xe - x0) * (yn - y0) - (xn - x0) * (ye - y0))  # pix^2 per arcsec^2
    if not np.isfinite(det) or det == 0:
        raise ValueError("degenerate WCS")
    scale = np.radians(1.0 / np.sqrt(det) / 3600.0)  # radians per output pixel

    c = (size - 1) / 2.0
    j, i = np.mgrid[0:size, 0:size]
    xi = -(i - c) * scale  # east (increasing RA) to the left
    eta = (j - c) * scale  # north up
    # Inverse gnomonic projection about (ra, dec)
    r0, d0 = np.radians(ra), np.radians(dec)
    rho = np.hypot(xi, eta)
    cc = np.arctan(rho)
    with np.errstate(invalid="ignore", divide="ignore"):
        sinc_r = np.where(rho > 0, np.sin(cc) / rho, 1.0)
        d = np.arcsin(np.cos(cc) * np.sin(d0) + eta * sinc_r * np.cos(d0))
        r = r0 + np.arctan2(xi * sinc_r, np.cos(cc) * np.cos(d0) - eta * sinc_r * np.sin(d0))
    return w2p(np.degrees(r) % 360.0, np.degrees(d))


def _sky_directions(w2p, ra, dec):
    """Unit vectors of North and East in image (x right, y up) pixel axes."""
    h = 1.0 / 3600.0
    x0, y0 = w2p(ra, dec)
    xn, yn = w2p(ra, dec + h)
    xe, ye = w2p(ra + h / np.cos(np.radians(dec)), dec)
    out = []
    for dx, dy in ((xn - x0, yn - y0), (xe - x0, ye - y0)):
        n = np.hypot(dx, dy)
        if not np.isfinite(n) or n == 0:
            return None
        out.append((float(dx / n), float(dy / n)))
    return tuple(out)


def make_stamp(path, ra, dec, size=51, ext=None, north_up=False):
    """Extract a size x size cutout of `path` centered on (ra, dec) in degrees.

    If north_up, the image is resampled (bilinear; DQ nearest) onto a grid with
    North up and East left, instead of using the native pixel orientation.

    Returns a Stamp (with .mjd set when the metadata has it).  The cutout is NaN-padded where it extends off the image;
    if the position is entirely off the image (or the WCS fails) data is None
    and `status` says why."""
    meta = {}
    st = _make_stamp(path, ra, dec, size, ext, north_up, meta)
    st.mjd = meta.get("mjd")
    return st


def _make_stamp(path, ra, dec, size, ext, north_up, meta):
    try:
        data, dq, w2p, meta["mjd"] = _load(path, ext)
        x, y = (float(v) for v in w2p(ra, dec))
    except Exception as e:  # keep going on a bad file; report on the stamp  # noqa: BLE001
        if "converge" in type(e).__name__.lower() or "converge" in str(e).lower():
            # Iterative WCS inversion diverges far outside the detector.
            return Stamp(path, None, None, np.nan, np.nan, "off image (WCS inversion did not converge)")
        return Stamp(path, None, None, np.nan, np.nan, f"error: {e}")
    if not (np.isfinite(x) and np.isfinite(y)):
        return Stamp(path, None, None, x, y, "off image (no WCS solution)")
    contains = bool(-0.5 <= x < data.shape[1] - 0.5 and -0.5 <= y < data.shape[0] - 0.5)
    if north_up:
        try:
            gx, gy = _north_up_coords(w2p, ra, dec, size)
        except Exception as e:  # noqa: BLE001
            return Stamp(path, None, None, x, y, f"error: {e}")
        cut = _sample(data, gx, gy, 1)
        if not np.isfinite(cut).any():
            return Stamp(path, None, None, x, y, "off image")
        dqcut = None
        if dq is not None:
            dqcut = np.nan_to_num(_sample(dq.astype(float), gx, gy, 0)).astype(np.int64)
        st = Stamp(path, cut, dqcut, x, y, "")
        st.contains = contains
        st.compass = ((0.0, 1.0), (-1.0, 0.0))
        return st
    xc, yc = round(x), round(y)
    cut = _cutout(data, xc, yc, size, np.nan)
    if cut is None:
        return Stamp(path, None, None, x, y, "off image")
    dqcut = _cutout(dq, xc, yc, size, 0).astype(np.int64) if dq is not None else None
    st = Stamp(path, cut, dqcut, x, y, "")
    st.contains = contains
    st.compass = _sky_directions(w2p, ra, dec)

    return st


def _flag_table():
    """Ordered list of (name, bit value, colour) for roman dq flags."""

    cmap = __import__("matplotlib").colormaps["tab20"]
    items = sorted(((f.name, int(f.value)) for f in pixel if int(f.value) > 0), key=lambda t: t[1])
    return [(n, v, cmap(i % 20)[:3]) for i, (n, v) in enumerate(items)]


def _draw_compass(ax, compass, length=0.1, ox=0.19, oy=0.19):
    """Small N/E arrows in the lower-left corner (axes-fraction coordinates)."""
    for (dx, dy), label in zip(compass, "NE"):
        ax.annotate(
            "",
            xy=(ox + dx * length, oy + dy * length),
            xytext=(ox, oy),
            xycoords="axes fraction",
            textcoords="axes fraction",
            arrowprops={"arrowstyle": "-|>", "color": "yellow", "lw": 1.0, "mutation_scale": 7, "shrinkA": 0, "shrinkB": 0},
        )
        ax.text(
            ox + dx * (length + 0.045),
            oy + dy * (length + 0.045),
            label,
            color="yellow",
            fontsize=6,
            ha="center",
            va="center",
            transform=ax.transAxes,
        )


def _draw(ax, stamp, flags, flag_table, show_cbar, fig, zscale, compass=True):
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_title(stamp.title, fontsize=6, pad=5, linespacing=1.15)
    if stamp.data is None:
        ax.text(0.5, 0.5, stamp.status, ha="center", va="center", transform=ax.transAxes, fontsize=8)
        return set()

    d = stamp.data
    good = d[np.isfinite(d)]
    if good.size:
        vmin, vmax = zscale.get_limits(good)
    else:
        vmin, vmax = 0.0, 1.0
    im = ax.imshow(d, origin="lower", cmap="gray", vmin=vmin, vmax=vmax, interpolation="nearest")
    if show_cbar:
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.02).ax.tick_params(labelsize=6)

    if compass and stamp.compass:
        _draw_compass(ax, stamp.compass)

    present = set()
    if flags and stamp.dq is not None:
        overlay = np.zeros(d.shape + (4,))
        # Lowest bit drawn last so it wins; higher bits first.
        for name, val, col in reversed(flag_table):
            m = (stamp.dq & val) != 0
            if m.any():
                overlay[m] = to_rgba(col, 0.6)
                present.add((name, col))
        ax.imshow(overlay, origin="lower", interpolation="nearest")
    return present


def _legend(fig, present):
    if not present:
        return
    handles = [Patch(facecolor=c, alpha=0.6, label=n) for n, c in sorted(present)]
    fig.legend(handles=handles, loc="lower center", ncol=min(len(handles), 6), fontsize=6, frameon=False)


def _render(stamps, outfile, ncols, flags, flag_table, cell=2.6, dpi=150, suptitle=None, compass=True):

    matplotlib.use("Agg")

    nrows = math.ceil(len(stamps) / ncols)
    ncols = min(ncols, len(stamps))
    # Each row needs room for its (multi-line) title so it sits clearly
    # between the stamp above and the stamp it labels.
    nlines = max(st.title.count("\n") + 1 for st in stamps)
    row_h = cell + 0.14 * nlines + 0.25
    fig, axes = plt.subplots(
        nrows, ncols, squeeze=False, figsize=(cell * ncols * 1.15, row_h * nrows + (0.5 if flags else 0.2))
    )
    zs = ZScaleInterval()
    present = set()
    for ax in axes.flat:
        ax.axis("off")
    for ax, st in zip(axes.flat, stamps):
        ax.axis("on")
        present |= _draw(ax, st, flags, flag_table, True, fig, zs, compass)
    if suptitle:
        fig.suptitle(suptitle, fontsize=9, y=0.998)
    top = 1 - 0.1 / fig.get_figheight() if suptitle else 1
    fig.tight_layout(rect=(0, 0.06 if present else 0, 1, top), h_pad=1.8, w_pad=1.0)
    if flags:
        _legend(fig, present)
    fig.savefig(outfile, dpi=dpi)
    plt.close(fig)
    return outfile


def make_stamp_images(
    ra,
    dec,
    images,
    size=51,
    mode="mosaic",
    prefix="stamp",
    outdir=".",
    flags=False,
    ext=None,
    north_up=False,
    compass=True,
    target_id=None,
    ncols=NCOLS,
    only_containing=False,
    sort_by_band_mjd=False,
    triplets=False,
):
    """Make stamps for each path in `images` and write PNG(s).

    mode: 'single', 'triplet' or 'mosaic'.  If only_containing, stamps whose image
    does not contain (RA, Dec) (or failed) are dropped.  If triplets, `images` is a flat
    list of (subtraction, science, template) paths: groups are kept or dropped as a unit
    (based on the science stamp) and sorted by the science band and MJD, and ncols is 3.
    Returns list of output files."""
    if triplets:
        ncols = 3
        if len(images) % 3:
            raise ValueError("triplets requires a multiple of 3 images")
    if mode not in ("single", "triplet", "mosaic"):
        raise ValueError(f"unknown mode {mode!r}")
    if size < 1:
        raise ValueError("size must be >= 1")
    os.makedirs(outdir, exist_ok=True)
    flag_table = _flag_table() if flags else None
    stamps = [make_stamp(p, ra, dec, size, ext, north_up) for p in images]
    for s in stamps:
        if s.status:
            print(f"warning: {s.path}: {s.status}", file=sys.stderr)
    if triplets:
        groups = [stamps[k : k + 3] for k in range(0, len(stamps), 3)]
        if only_containing:
            groups = [g for g in groups if g[1].contains and not any(s.status for s in g)]
        if sort_by_band_mjd:
            groups.sort(key=lambda g: _sort_key(g[1]))
        stamps = [s for g in groups for s in g]
        if not stamps:
            print("no triplets contain the position", file=sys.stderr)
            return []
    else:
        if only_containing:
            stamps = [s for s in stamps if s.contains and not s.status]
            if not stamps:
                print("no images contain the position", file=sys.stderr)
                return []
        if sort_by_band_mjd:
            stamps.sort(key=_sort_key)
    title = f"RA={ra:.6f} Dec={dec:.6f}"
    if target_id:
        title = f"{target_id}  {title}"
    out = []
    path = lambda name: os.path.join(outdir, f"{prefix}_{name}.png")

    if mode == "single":
        for i, s in enumerate(stamps):
            base = os.path.splitext(os.path.basename(s.path))[0]
            out.append(_render([s], path(f"{i + 1:03d}_{base}"), 1, flags, flag_table, suptitle=title, compass=compass))
    elif mode == "triplet":
        for k in range(0, len(stamps), ncols):
            out.append(
                _render(
                    stamps[k : k + ncols],
                    path(f"set{k // ncols + 1:03d}"),
                    ncols,
                    flags,
                    flag_table,
                    suptitle=title,
                    compass=compass,
                )
            )
    else:
        out.append(_render(stamps, path("mosaic"), ncols, flags, flag_table, suptitle=title, compass=compass))
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("ra", type=float, help="RA in decimal degrees")
    ap.add_argument("dec", type=float, help="Dec in decimal degrees")
    ap.add_argument(
        "imagelist", nargs="?", default=None, help="Text file with one image path per line " "(omit when using --mast)"
    )
    ap.add_argument(
        "--mast",
        action="store_true",
        help="Instead of an imagelist, query MAST for L2 cal images covering "
        "RA, Dec and stream them (requires MAST_API_TOKEN in the environment)",
    )
    ap.add_argument("--prog-id", type=int, default=None, help="With --mast: only images from this program ID")
    ap.add_argument("--band", type=str.upper, choices=BANDS, default=None, help="With --mast: only images in this band")
    ap.add_argument(
        "--local-data-dir",
        default=None,
        help="With --mast: use MAST only to find image names; read those files from this directory",
    )
    ap.add_argument(
        "--local-subtraction-dir",
        default=None,
        help="With --local-data-dir: also find the subtractions (sidecar simple_diff files) for the "
        "images and show rows of (subtraction, science, template)",
    )
    ap.add_argument(
        "--search-radius", type=float, default=0.1, help="With --mast: MAST search radius in degrees (default 0.1)"
    )
    ap.add_argument("--size", type=int, default=51, help="Stamp side length in pixels (default 51)")
    ap.add_argument(
        "--mode", choices=["single", "triplet", "mosaic"], default="mosaic", help="Output layout (default mosaic)"
    )
    ap.add_argument("--ncols", type=int, default=NCOLS, help=f"Number of columns for triplet/mosaic (default {NCOLS})")
    ap.add_argument("--prefix", default="stamp", help="Output filename prefix")
    ap.add_argument("--outdir", default=".", help="Output directory")
    ap.add_argument("--flags", action="store_true", help="Color-code DQ flag bits (roman_datamodels.dqflags.pixel)")
    ap.add_argument(
        "--north-up", action="store_true", help="Resample stamps to a common orientation: North up, East left"
    )
    ap.add_argument(
        "--compass", action=argparse.BooleanOptionalAction, default=True, help="Draw the N/E arrows on each stamp"
    )
    ap.add_argument(
        "--id", dest="target_id", default=None, help="Object/candidate ID to show next to RA, Dec in the title"
    )
    ap.add_argument("--ext", default=None, help="FITS extension (name or number) for non-ASDF inputs")
    args = ap.parse_args()

    ext = args.ext
    if ext is not None and ext.isdigit():
        ext = int(ext)
    if args.mast == (args.imagelist is not None):
        ap.error("give exactly one of imagelist or --mast")
    if not args.mast and (args.prog_id is not None or args.band is not None):
        ap.error("--prog-id and --band require --mast")
    if args.local_data_dir and not args.mast:
        ap.error("--local-data-dir requires --mast")
    if args.local_subtraction_dir and not args.local_data_dir:
        ap.error("--local-subtraction-dir requires --local-data-dir")
    triplets = False

    if args.mast:
        images = query_mast_images(args.ra, args.dec, prog_id=args.prog_id, band=args.band, radius=args.search_radius)
        if not images:
            ap.error("no images found at MAST for the given criteria")
        print(f"Found {len(images)} images at MAST", file=sys.stderr)
        if args.local_subtraction_dir:
            images = find_local_triplets(images, args.local_data_dir, args.local_subtraction_dir)
            if not images:
                ap.error("no subtraction triplets found locally for the MAST images")
            triplets = True
        elif args.local_data_dir:
            local = [os.path.join(args.local_data_dir, str(f)) for f in images]
            for p in local:
                if not os.path.exists(p):
                    print(f"warning: not found locally: {p}", file=sys.stderr)
            images = [p for p in local if os.path.exists(p)]
            if not images:
                ap.error(f"none of the MAST images are in {args.local_data_dir}")
    else:
        # One path per line; '#' starts a comment.  A '|' delimiter (not
        # expected in paths) keeps paths containing spaces in a single column.
        images = Table.read(
            args.imagelist, format="ascii.no_header", delimiter="|", names=["path"], comment="#", guess=False
        )["path"]
        if len(images) < 1:
            ap.error(f"no images in {args.imagelist}")

    for f in make_stamp_images(
        ra=args.ra,
        dec=args.dec,
        images=images,
        size=args.size,
        mode=args.mode,
        prefix=args.prefix,
        outdir=args.outdir,
        flags=args.flags,
        ext=ext,
        north_up=args.north_up,
        compass=args.compass,
        target_id=args.target_id,
        ncols=args.ncols,
        only_containing=args.mast,
        sort_by_band_mjd=args.mast,
        triplets=triplets,
    ):
        print(f)


if __name__ == "__main__":
    main()
