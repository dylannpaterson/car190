#!/bin/bash
# Run subtractions for one WFI detector over all supported bands and all science dates.
#
# Usage: run_car201_individual_manualrdm_per_wfi.sh [WFI] [template_date]
#   WFI            Detector number, 1-18 (default 15)
#   template_date  Template date (default 2026-09-28).  Science dates equal to this are skipped.

SNPIT_PIPELINE_BASE=${HOME}/snpit/packages

output_dir=/rrn-ops/wmwv/subtractions

base_path=/rrn-ops/wmwv/data

# We can break these names into four parts: the CAR prefix, the date code, the band code, and the exposure number.
# {car_prefix}{date_code}{band_code}_{exposure_number}

car_prefix=r0104303
exposure_code=0002

WFI_INPUT=${1:-15}
if [[ ! ${WFI_INPUT} =~ ^[0-9]+$ ]] || (( 10#${WFI_INPUT} < 1 || 10#${WFI_INPUT} > 18 )); then
    echo "Unsupported WFI '${WFI_INPUT}'. Choose a number from 1 to 18." >&2
    exit 1
fi
printf -v WFI "%02d" "$((10#${WFI_INPUT}))"

# F146 is omitted because it is not supported by the snappl STPSF class.
declare -A band_codes=(
    [f213]=001008001
    [f184]=001005001
    [f158]=001004001
    [f129]=001003001
    [f106]=001002001
    [f087]=001007001
    [f062]=001001001
)
bands=(f062 f087 f106 f129 f158 f184 f213)

declare -A date_codes=(
    [2026-09-28]=001
    [2026-09-29a]=002
    [2026-09-29b]=003
    [2026-10-03]=004
    [2026-10-08]=005
)
dates=(2026-09-28 2026-09-29a 2026-09-29b 2026-10-03 2026-10-08)

template_date=${2:-2026-09-28}  # Default.  Override with second argument
template_date_code=${date_codes[$template_date]:-}
if [[ -z ${template_date_code} ]]; then
    echo "Unsupported template date '${template_date}'. Choose one of: ${dates[*]}" >&2
    exit 1
fi

star_catalog_filename=${base_path}/gaia_car201_${WFI}.ecsv

for band in "${bands[@]}"; do
    band_code=${band_codes[$band]}

    for science_date in "${dates[@]}"; do
        science_date_code=${date_codes[$science_date]}
        if [[ ${science_date_code} == "${template_date_code}" ]]; then
            continue
        fi

        echo "Running for WFI ${WFI}, band ${band}, science date ${science_date}, template date ${template_date}"

        template_base="${car_prefix}${template_date_code}${band_code}_${exposure_code}_wfi${WFI}_${band}"
        science_base="${car_prefix}${science_date_code}${band_code}_${exposure_code}_wfi${WFI}_${band}"

        template_filename=${template_base}_cal.asdf
        science_filename=${science_base}_cal.asdf

        # Pre-generate the Gaia catalog (once per WFI; the file is reused for every band and date)
        if [ ! -e ${star_catalog_filename} ]; then
            python -m sidecar.star_retrieval \
                ${base_path}/${science_filename} \
                --output ${star_catalog_filename}
        fi

        python -m sidecar.pipeline \
            --image-collection manual_rdm \
            --base-path ${base_path} \
            --template-path ${template_filename} \
            --science-path ${science_filename} \
            --star-catalog ${star_catalog_filename} \
            --reject-known-stars \
            --psf-type STPSF \
            --cross-convolve \
            --temp-dir ${HOME}/tmp \
            --output-dir ${output_dir} \
            --save-debug-products \
            --backend4subtract numpy \
            || { echo "Subtraction FAILED for WFI ${WFI}, band ${band}, science date ${science_date}" >&2; continue; }

        subtraction_dir=${output_dir}/*${science_base:1:18}*${template_base:1:18}*
        for file in ${subtraction_dir}/*detection*.ecsv; do
            python -m sidecar.catalog_to_ds9_region_file \
                --peak-value-threshold 25 ${file}
        done
    done
done
