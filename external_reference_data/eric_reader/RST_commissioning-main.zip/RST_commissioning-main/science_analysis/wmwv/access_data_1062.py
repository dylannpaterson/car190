import os

from dotenv import load_dotenv

from astroquery.mast import MastMissions

import roman_datamodels as rdm

from combine_asdf import combine_asdf

_ = load_dotenv(dotenv_path=os.path.join(os.getenv("HOME"), "variables.env"))

# Create MastMissions object and assign mission to 'roman'
missions = MastMissions(mission='roman')

# Login to search and retrieve Roman data
token = os.getenv("MAST_API_TOKEN")    
missions.login(token=token)
               
print(f'Mission: {missions.mission}')
print(f'Service: {missions.service}')


# progid = 1602
# two different offsets/rotations, 001 and 002 first tirplet
# two different pointings, 001 and 002 suffix

filename_bases = {}
filename_bases["f062"] = ["r0106201001001001001", "r0106201002001001001", "r0106202001001001001", "r0106202002001001001", "r0106201001001001002", "r0106201002001001002", "r0106202001001001002", "r0106202002001001002"]
filename_bases["f106"] = ["r0106201001001002001", "r0106201002001002001", "r0106202001001002001", "r0106202002001002001", "r0106201001001002002", "r0106201002001002002", "r0106202001001002002", "r0106202002001002002"]
filename_bases["f129"] = ["r0106201001001003001", "r0106201002001003001", "r0106202001001003001", "r0106202002001003001", "r0106201001001003002", "r0106201002001003002", "r0106202001001003002", "r0106202002001003002"]
filename_bases["f158"] = ["r0106201001001005001", "r0106201002001005001", "r0106202001001005001", "r0106202002001005001", "r0106201001001005002", "r0106201002001005002", "r0106202001001005002", "r0106202002001005002"]
filename_bases["f184"] = ["r0106201001001006001", "r0106201002001006001", "r0106202001001006001", "r0106202002001006001", "r0106201001001006002", "r0106201002001006002", "r0106202001001006002", "r0106202002001006002"]
filename_bases["f087"] = ["r0106201001001007001", "r0106201002001007001", "r0106202001001007001", "r0106202002001007001", "r0106201001001007002", "r0106201002001007002", "r0106202001001007002", "r0106202002001007002"]
# L2 files not available for PRISM
# filename_bases["prism"] = ["r0106201001001004001", "r0106201002001004001", "r0106202001001004001", "r0106202002001004001", "r0106201001001004002", "r0106201002001004002", "r0106202001001004002", "r0106202002001004002"]

exposures = ["0001", "0002"]

out_dir = "/mnt/smdc-rom-com-ops/rrn-ops/wmwv/data"
# Can't run this directly against the S3 bucket in /mnt/supernovae/internal
# Would have to write somewhere else and then move it because the asdf.write does something the S3 bucket mount doesn't support
# out_dir = "/mnt/supernovae/internal/data/1062"

def fetch_and_save_base_wfi_band(base, wfi, exposure, band, out_dir=None, overwrite=False, verbose=True, level="L2"):
    level_suffix = {"L1": "uncal", "L2": "cal"}
    filename = f"{base}_{exposure}_wfi{wfi:02d}_{band}_{level_suffix[level]}.asdf"

    if out_dir is not None:
        fullpath = os.path.join(out_dir, filename)
    else:
        fullpath = filename

    if os.path.exists(fullpath) and not overwrite:
        if verbose:
            print(f"File {filename} already exists, skipping...")
        return

    if verbose:
        print(f"Fetching {filename}...")
    uri = missions.read_product(filename)    
    dm = rdm.open(uri)

    dm.save(fullpath)


level="L1"
for band, bases in filename_bases.items():
    for base in bases:
        for wfi in range(1, 18+1):
            for exposure in exposures:
                fetch_and_save_base_wfi_band(base, wfi, exposure, band, out_dir=out_dir, level=level)
