#!/usr/bin/env python
"""Download Roman WFI L1/L2 files for a program id from MAST.

Files are written to a staging directory and moved to the output directory once complete.

Note:
Assumes a limit of no more than 100,000 files per program id, which is true for all Roman programs as of 2026.
If that limit is exceeded, MaxResultsWarning will be emitted to output.
"""
# Written by Claude Sonnet 5.5 based on example code, prompting, and review by Michael Wood-Vasey.

import argparse
import getpass
import os
import shutil

from astroquery.mast import MastMissions
from dotenv import load_dotenv

# Created directories are group-rwx (setgid so contents inherit the group)
GROUP = "supernovae"
DIR_MODE = 0o2775

LEVEL_SUFFIX = {"L1": "uncal", "L2": "cal"}
LEVEL_NUMBER = {"L1": "1", "L2": "2"}

# Allowed values of the MAST "optical_element" field, keyed by lowercase name
# https://roman-docs.stsci.edu/roman-instruments/the-wide-field-instrument/observing-with-the-wfi/wfi-optical-elements
BANDS = {
    b.lower(): b.upper()
    for b in ["Grism", "F213", "F062", "F106", "F129", "Prism", "F158", "F184", "F146", "F087", "Dark"]
}


def get_mast_connection():
    """Create a logged-in MastMissions object for Roman."""
    load_dotenv(dotenv_path=os.path.join(os.getenv("HOME"), "variables.env"))
    mission = MastMissions(mission="roman")
    token = os.getenv("MAST_API_TOKEN")
    if token:
        mission.login(token=token)
    return mission


def get_file_list(missions, progid, level="L2", bands=None):
    """Return sorted filenames for a program id at the given level from MAST.

    bands is an optional list of optical elements; None means all.
    """
    base_criteria = {
        "program": progid,
        "productLevel": LEVEL_NUMBER[level],
        # Detector-level exposures only (excludes e.g. mosaic/combined products); the match is case-sensitive
        "dataset_category": "detector",
        "limit": 100000,
        # Returning only the one column we need roughly halves the query time
        "select_cols": ["fileSetName"],
    }
    suffix = LEVEL_SUFFIX[level]

    # One query per group; a comma-separated value is an OR in the MAST query.
    # At L2, filter bands (Fxxx) are restricted to WFI_IMAGE exposures.
    if not bands:
        groups = [{}]
    else:
        names = [BANDS[b.lower()] for b in bands]
        filter_bands = [n for n in names if n.startswith("F")]
        other_bands = [n for n in names if not n.startswith("F")]
        groups = []
        if filter_bands:
            group = {"optical_element": ",".join(filter_bands)}
            if level == "L2":
                group["exposure_type"] = "WFI_IMAGE"
            groups.append(group)
        if other_bands:
            groups.append({"optical_element": ",".join(other_bands)})

    filenames = set()
    for group in groups:
        results = missions.query_criteria(**base_criteria, **group)
        filenames.update(f"{name}_{suffix}.asdf" for name in results["fileSetName"])
    return sorted(filenames)


def set_group_access(path, mode):
    """Set group based on GROUP ('supernovae') and the given mode on path; warn if not permitted."""
    try:
        shutil.chown(path, group=GROUP)
        os.chmod(path, mode)
    except (PermissionError, LookupError) as e:
        print(f"Warning: could not set group/permissions on {path}: {e}")


def ensure_dir(path):
    """Create path (and missing parents) as group-rwx directories owned by GROUP."""
    path = os.path.abspath(path)
    missing = []
    while not os.path.isdir(path):
        missing.append(path)
        path = os.path.dirname(path)
    for d in reversed(missing):
        os.makedirs(d, exist_ok=True)
        set_group_access(d, DIR_MODE)


def copy_verified(src, dst):
    """Copy src to dst and check the size matches.

    On any failure (including interruption) the partial dst is removed, so a later
    run doesn't mistake it for a complete file; src is left in place for a retry.
    A size check is used rather than a checksum to avoid re-reading the whole
    file back from the (possibly S3-backed) destination.
    """
    try:
        shutil.copyfile(src, dst)
        src_size, dst_size = os.path.getsize(src), os.path.getsize(dst)
        if src_size != dst_size:
            raise OSError(f"Incomplete copy of {src} to {dst}: {dst_size} of {src_size} bytes")
    except shutil.SameFileError:
        # dst is src; nothing was written and it must not be removed
        raise
    except BaseException:
        if os.path.lexists(dst):
            os.remove(dst)
        raise


def fetch_and_save(missions, filename, out_dir=None, staging_dir=None, overwrite=False, verbose=True):
    import roman_datamodels as rdm

    if out_dir is not None:
        ensure_dir(out_dir)
        fullpath = os.path.join(out_dir, filename)
    else:
        fullpath = filename

    if staging_dir is not None:
        ensure_dir(staging_dir)
        staging_fullpath = os.path.join(staging_dir, filename)
    else:
        staging_fullpath = fullpath

    if os.path.exists(fullpath) and not overwrite:
        if verbose:
            print(f"File {filename} already exists, skipping...")
        return

    if verbose:
        print(f"Fetching {filename}...")
    uri = missions.read_product(filename)
    dm = rdm.open(uri)

    dm.save(staging_fullpath)
    if not (os.path.exists(fullpath) and os.path.samefile(staging_fullpath, fullpath)):
        copy_verified(staging_fullpath, fullpath)
        os.remove(staging_fullpath)


def default_staging_dir():
    return os.path.join("/mnt/smdc-rom-com-ops/rrn-ops", os.getenv("LOGNAME") or getpass.getuser(), "data")


def default_output_dir(progid):
    return f"/mnt/supernovae/internal/data/{progid:04d}"


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("progid", type=int, help="Program id, e.g. 1049")
    parser.add_argument("--staging-dir", default=None,
                        help="Directory to write files to before moving to output dir "
                        "(default: /mnt/smdc-rom-com-ops/rrn-ops/$LOGNAME/data)")
    parser.add_argument("--output-dir", default=None,
                        help="Final directory for the files (default: /mnt/supernovae/internal/data/<progid:04d>)")
    parser.add_argument("--level", default="L2", choices=sorted(LEVEL_SUFFIX), help="Data level (default: L2)")
    parser.add_argument("--bands", default=None, metavar="BAND[,BAND...]",
                        help="Only fetch these optical elements, as a comma-separated list (no spaces), "
                        f"case-insensitive (choices: {', '.join(sorted(BANDS))}; default: all)")
    parser.add_argument("--overwrite", action="store_true", help="Overwrite existing files")
    args = parser.parse_args(argv)
    if args.bands is not None:
        bands = [b.lower() for b in args.bands.split(",") if b]
        invalid = [b for b in bands if b not in BANDS]
        if invalid or not bands:
            parser.error(f"invalid band(s): {invalid or args.bands}; choose from {', '.join(sorted(BANDS))}")
        args.bands = list(dict.fromkeys(bands))
    if args.staging_dir is None:
        args.staging_dir = default_staging_dir()
    if args.output_dir is None:
        args.output_dir = default_output_dir(args.progid)
    return args


def main(argv=None):
    args = parse_args(argv)

    mission = get_mast_connection()
    filenames = get_file_list(mission, args.progid, level=args.level, bands=args.bands)
    print(f"Found {len(filenames)} {args.level} files for program {args.progid}")
    for filename in filenames:
        fetch_and_save(mission, filename, out_dir=args.output_dir, staging_dir=args.staging_dir,
                       overwrite=args.overwrite)


if __name__ == "__main__":
    main()
