# Setup the environment and run the CAR915 per WFI script
# Meant for use in a SLURM job submission script

# If outside the container
RUN_DIR=${HOME}/snpit
# If inside the container
RUN_DIR=/home

SCRIPT_DIR=${RUN_DIR}/packages/RST_commissioning/science_analysis/wmwv

WFI=${1:-15}  # Default 15 if no argument is provided


pip install -e ${RUN_DIR}/packages/sidecar

echo "Running CAR915 per WFI script for WFI=${WFI}"
bash -c "${SCRIPT_DIR}/run_car915_individual_manualrdm_per_wfi_detect_only.sh ${WFI}"
