ra=58.8112764
dec=-49.3863355
python make_stamps.py --flags ${ra} ${dec} imagelist.txt -o ${ra}_${dec}

ra=58.9212928 
dec=-49.4400681
python make_stamps.py --flags ${ra} ${dec} imagelist.txt -o ${ra}_${dec}

ra=58.934561
dec=-49.444689
python make_stamps.py --flags ${ra} ${dec} imagelist.txt -o ${ra}_${dec}

wfi=01
ra=59.202912
dec=-49.149529
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}

wfi=02
ra=59.023822
dec=-49.206403
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}

wfi=03
ra=58.235291
dec=49.450079
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}

wfi=04
ra=
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}

wfi=05
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}

wfi=06
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}


wfi=07
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}
wfi=08
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}
wfi=09
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}

wfi=10
ra=59.260659
dec=-49.286015
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}

ra=59.244855
dec=-49.293327
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}

wfi=11
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}

wfi=12
ra=58.793316
dec=-49.371859 
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}

wfi=13
ra=59.381829
dec=49.431113
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}

wfi=14
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}
wfi=15
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}
wfi=16
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}
wfi=17
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}
wfi=18
python make_stamps.py --flags ${ra} ${dec} imagelist_${wfi}.txt -o ${ra}_${dec}

wfi=06
ra=58.119060
dec=-49.302980
python make_stamps.py ${ra} ${dec} imagelist_${wfi}_2_1.txt --flags -o ${ra}_${dec}

