SNPIT_PIPELINE_BASE=${HOME}/snpit/packages

# cd ${SNPIT_PIPELINE_BASE}/sidecar; pip install -e . --no-deps
# cd ${SNPIT_PIPELINE_BASE}

output_dir=/rrn-ops/wmwv/subtractions

base_path=${HOME}/snpit/packages/RST_commissioning/science_analysis/wmwv/data
base_path=/rrn-ops/wmwv/data

# 2026-09-28, 2026-09-29, 2026-10-03, 2026-10-08
# r0104303001001004001_0002", "r0104303003001004001_0002", "r0104303004001004001_0002", "r0104303005001004001_0002"

# We can break these names into four parts: the CAR prefix, the date code, the band code, and the exposure number.
# {car_prefix}{date_code}{band_code}_{exposure_number}

car_prefix=r0104303
exposure_code=0002

band=${1:-f087}  # Default.  Override with first argument
band=${band,,}  # standardize to lower case
declare -A band_codes=(
    [f213]=001008001
    [f184]=001005001
    [f158]=001004001
    [f146]=001006001
    [f129]=001003001
    [f106]=001002001
    [f087]=001007001
    [f062]=001001001
)
band_code=${band_codes[$band]:-}
if [[ -z ${band_code} ]]; then
    echo "Unsupported band '${band}'. Choose one of: ${!band_codes[*]}" >&2
    exit 1
fi

declare -A date_codes=(
    [2026-09-28]=001
    [2026-09-29a]=002
    [2026-09-29b]=003
    [2026-10-03]=004
    [2026-10-08]=005
)

science_date=${2:-2026-10-08}  # Default.  Override with second argument
science_date_code=${date_codes[$science_date]:-}
if [[ -z ${science_date_code} ]]; then
    echo "Unsupported science date '${science_date}'. Choose one of: ${!date_codes[*]}" >&2
    exit 1
fi

template_date=${3:-2026-09-28}  # Default.  Override with third argument
template_date_code=${date_codes[$template_date]:-}  # Template date is fixed to 2026-09-28
if [[ -z ${template_date_code} ]]; then
    echo "Unsupported template date '${template_date}'. Choose one of: ${!date_codes[*]}" >&2
    exit 1
fi

for WFI in {01..18}; do
    echo "Running for WFI ${WFI}, band ${band}, science date ${science_date}"

    template_base="${car_prefix}${template_date_code}${band_code}_${exposure_code}_wfi${WFI}_${band}"
    science_base="${car_prefix}${science_date_code}${band_code}_${exposure_code}_wfi${WFI}_${band}"

    template_filename=${template_base}_cal.asdf
    science_filename=${science_base}_cal.asdf

    star_catalog_filename=${base_path}/gaia_car201_${WFI}.ecsv

    # Pre-generate the Gaia catalog
    if [ ! -e ${star_catalog_filename} ]; then
        python -m sidecar.star_retrieval \
            ${base_path}/${science_filename} \
            --output /${star_catalog_filename}
    fi

    python -m sidecar.pipeline \
        --image-collection manual_rdm \
        --base-path ${base_path} \
        --template-path ${template_filename} \
        --science-path ${science_filename} \
        --star-catalog ${star_catalog_filename} \
        --reject-known-stars \
        --psf-type STPSF \
        --cross-convolve \
        --temp-dir ${HOME}/tmp \
        --output-dir ${output_dir} \
        --save-debug-products \
        --backend4subtract numpy

    subtraction_dir=${output_dir}/*${science_base:1:18}*${template_base:1:18}*
    for file in ${subtraction_dir}/*detection*.ecsv; do
        python -m sidecar.catalog_to_ds9_region_file \
            --peak-value-threshold 25 ${file}
    done    

done