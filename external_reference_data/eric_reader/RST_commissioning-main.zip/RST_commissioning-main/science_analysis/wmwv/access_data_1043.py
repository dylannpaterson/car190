import os

from dotenv import load_dotenv

from astroquery.mast import MastMissions

import roman_datamodels as rdm

from combine_asdf import combine_asdf

_ = load_dotenv(dotenv_path=os.path.join(os.getenv("HOME"), "variables.env"))

# Create MastMissions object and assign mission to 'roman'
missions = MastMissions(mission='roman')

# Login to search and retrieve Roman data
token = os.getenv("MAST_API_TOKEN")    
missions.login(token=token)
               
print(f'Mission: {missions.mission}')
print(f'Service: {missions.service}')

filename_bases = {}
# On 2026-10-18 observations, there was a leading r0104304001001001001_0001_wfi04_f062 observation which I am skipping as I take it as the settling epoch.
filename_bases["f062"] = ["r0104303001001001001", "r0104303002001001001", "r0104303003001001001", "r0104303004001001001", "r0104303005001001001", "r0104303006001001001", "r0104304001001002001", "r0104304002001002001"]
filename_bases["f106"] = ["r0104303001001002001", "r0104303002001002001", "r0104303003001002001", "r0104303004001002001", "r0104303005001002001", "r0104303006001002001", "r0104304001001003001", "r0104304002001003001"]
filename_bases["f129"] = ["r0104303001001003001", "r0104303002001003001", "r0104303003001003001", "r0104303004001003001", "r0104303005001003001", "r0104303006001003001", "r0104304001001004001", "r0104304002001004001"]
filename_bases["f158"] = ["r0104303001001004001", "r0104303002001004001", "r0104303003001004001", "r0104303004001004001", "r0104303005001004001", "r0104303006001004001", "r0104304001001005001", "r0104304002001005001"]
filename_bases["f184"] = ["r0104303001001005001", "r0104303002001005001", "r0104303003001005001", "r0104303004001005001", "r0104303005001005001", "r0104303006001005001", "r0104304001001006001", "r0104304002001006001"]
filename_bases["f146"] = ["r0104303001001006001", "r0104303002001006001", "r0104303003001006001", "r0104303004001006001", "r0104303005001006001", "r0104303006001006001", "r0104304001001007001", "r0104304002001007001"]
filename_bases["f087"] = ["r0104303001001007001", "r0104303002001007001", "r0104303003001007001", "r0104303004001007001", "r0104303005001007001", "r0104303006001007001", "r0104304001001008001", "r0104304002001008001"]
filename_bases["f213"] = ["r0104303001001008001", "r0104303002001008001", "r0104303003001008001", "r0104303004001008001", "r0104303005001008001", "r0104303006001008001", "r0104304001001009001", "r0104304002001009001"]

exposures = ["0001", "0002", "0003", "0004"]

out_dir = "/mnt/smdc-rom-com-ops/rrn-ops/wmwv/data"

def fetch_and_save_base_wfi_band(base, wfi, exposure, band, out_dir=None, overwrite=False, verbose=True):
    filename = f"{base}_{exposure}_wfi{wfi:02d}_{band}_cal.asdf"

    if out_dir is not None:
        fullpath = os.path.join(out_dir, filename)
    else:
        fullpath = filename

    if os.path.exists(fullpath) and not overwrite:
        if verbose:
            print(f"File {filename} already exists, skipping...")
        return

    if verbose:
        print(f"Fetching {filename}...")
    uri = missions.read_product(filename)    
    dm = rdm.open(uri)

    dm.save(fullpath)


for band, bases in filename_bases.items():
    for base in bases:
        for wfi in range(1, 18+1):
            for exposure in exposures:
                fetch_and_save_base_wfi_band(base, wfi, exposure, band, out_dir=out_dir)
