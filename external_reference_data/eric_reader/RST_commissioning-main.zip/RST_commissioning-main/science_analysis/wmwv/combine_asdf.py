#!/usr/bin/env python
"""Combine multiple aligned Roman ASDF images into one."""

import argparse
import os

import numpy as np

import roman_datamodels as rdm


def combine_asdf(input_filenames, outfile=None):
    """Combine Roman ASDF files that are already aligned.

    Metadata and .dq come from the first file.  The exposure time is the sum
    over all files, .data is the mean, and .err is the quadrature sum divided
    by N (the error on the mean, for independent errors).

    Parameters
    ----------
    input_filenames : list of str
        Input ASDF files to combine.
    outfile : str, optional
        Output ASDF file.

    Returns
    -------
    dm : roman_datamodels.DataModel
        The combined image.
    """
    if len(input_filenames) < 1:
        raise ValueError("Need at least one input file")

    dm = rdm.open(input_filenames[0])
    data = [dm.data[...]]
    err2 = [dm.err[...] ** 2]
    exptime = dm.meta.exposure.exposure_time
    effective = getattr(dm.meta.exposure, "effective_exposure_time", None)

    for f in input_filenames[1:]:
        with rdm.open(f) as other:
            if other.data.shape != dm.data.shape:
                raise ValueError(
                    f"{f}: shape {other.data.shape} != {dm.data.shape}"
                )
            data.append(other.data[...])
            err2.append(other.err[...] ** 2)
            exptime = exptime + other.meta.exposure.exposure_time
            if effective is not None:
                effective = effective + getattr(
                    other.meta.exposure, "effective_exposure_time", 0
                )

    n = len(data)
    dm.data = np.mean(np.stack(data), axis=0)
    dm.err = np.sqrt(np.sum(np.stack(err2), axis=0)) / n
    dm.meta.exposure.exposure_time = exptime
    if effective is not None:
        dm.meta.exposure.effective_exposure_time = effective

    if outfile is not None:
        dm.save(outfile)
    return dm


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("infiles", nargs="+", help="Input ASDF files")
    parser.add_argument("-o", "--output", required=True, help="Output ASDF file")
    args = parser.parse_args()
    combine_asdf(args.infiles, args.output)


def run():
    filename_bases = {}
    filename_bases["f062"] = ["r0104303001001001001", "r0104303002001001001", "r0104303003001001001", "r0104303004001001001", "r0104303005001001001", "r0104303006001001001", "r0104304001001002001", "r0104304002001002001"]
    filename_bases["f106"] = ["r0104303001001002001", "r0104303002001002001", "r0104303003001002001", "r0104303004001002001", "r0104303005001002001", "r0104303006001002001", "r0104304001001003001", "r0104304002001003001"]
    filename_bases["f129"] = ["r0104303001001003001", "r0104303002001003001", "r0104303003001003001", "r0104303004001003001", "r0104303005001003001", "r0104303006001003001", "r0104304001001004001", "r0104304002001004001"]
    filename_bases["f158"] = ["r0104303001001004001", "r0104303002001004001", "r0104303003001004001", "r0104303004001004001", "r0104303005001004001", "r0104303006001004001", "r0104304001001005001", "r0104304002001005001"]
    filename_bases["f184"] = ["r0104303001001005001", "r0104303002001005001", "r0104303003001005001", "r0104303004001005001", "r0104303005001005001", "r0104303006001005001", "r0104304001001006001", "r0104304002001006001"]
    filename_bases["f146"] = ["r0104303001001006001", "r0104303002001006001", "r0104303003001006001", "r0104303004001006001", "r0104303005001006001", "r0104303006001006001", "r0104304001001007001", "r0104304002001007001"]
    filename_bases["f087"] = ["r0104303001001007001", "r0104303002001007001", "r0104303003001007001", "r0104303004001007001", "r0104303005001007001", "r0104303006001007001", "r0104304001001008001", "r0104304002001008001"]
    filename_bases["f213"] = ["r0104303001001008001", "r0104303002001008001", "r0104303003001008001", "r0104303004001008001", "r0104303005001008001", "r0104303006001008001", "r0104304001001009001", "r0104304002001009001"]

    wfi_names = [f"wfi{wfi:02d}" for wfi in range(1, 18 + 1)]
    exposures = ["0001", "0002", "0003", "0004"]
    out_dir = "/mnt/smdc-rom-com-ops/rrn-ops/wmwv/data"
    
    for band, bases in filename_bases.items():
        for base in bases:
            for wfi in wfi_names:
                filenames = [f"{base}_{exposure}_{wfi}_{band}_cal.asdf" for exposure in exposures]
                full_filenames = [os.path.join(out_dir, f) for f in filenames]
                outfile = os.path.join(out_dir, f"{base}_combined_{wfi}_{band}_cal.asdf")
                if not os.path.exists(outfile):
                    combine_asdf(full_filenames, outfile=outfile)

if __name__ == "__main__":
    run()
