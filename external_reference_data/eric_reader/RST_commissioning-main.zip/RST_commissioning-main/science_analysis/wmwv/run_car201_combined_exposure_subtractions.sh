# SNPIT_PIPELINE_BASE=${HOME}/snpit/packages
SNPIT_PIPELINE_BASE=/home/packages

# cd ${SNPIT_PIPELINE_BASE}/sidecar; pip install -e . --no-deps
# cd ${SNPIT_PIPELINE_BASE}

output_dir=/rrn-ops/wmwv/subtractions

# base_path=${HOME}/snpit/packages/RST_commissioning/science_analysis/wmwv/data
base_path=/rrn-ops/wmwv/data
WFI=04
# 2026-09-28, 2026-09-29, 2026-10-03
# r0104303001001004001_0002", "r0104303003001004001_0002", "r0104303004001004001_0002

# template_base=r0104303001001008001_combined_wfi${WFI}_f213
# science_base=r0104303004001008001_combined_wfi${WFI}_f213

# template_base=r0104303001001005001_combined_wfi${WFI}_f184
# science_base=r0104303004001005001_combined_wfi${WFI}_f184

template_base=r0104303001001004001_combined_wfi${WFI}_f158
science_base=r0104303004001004001_combined_wfi${WFI}_f158

# template_base=r0104303001001006001_combined_wfi${WFI}_f146
# science_base=r0104303004001006001_combined_wfi${WFI}_f146

# template_base=r0104303001001003001_combined_wfi${WFI}_f129
# science_base=r0104303004001003001_combined_wfi${WFI}_f129

# template_base=r0104303001001002001_combined_wfi${WFI}_f106
# science_base=r0104303004001002001_combined_wfi${WFI}_f106

# template_base=r0104303001001007001_combined_wfi${WFI}_f087
# science_base=r0104303004001007001_combined_wfi${WFI}_f087

# template_base=r0104303001001001001_combined_wfi${WFI}_f062
# science_base=r0104303004001001001_combined_wfi${WFI}_f062

template_filename=${template_base}_cal.asdf
science_filename=${science_base}_cal.asdf

star_catalog_filename=${base_path}/gaia_${science_base}.ecsv

# Pre-generate the Gaia catalog
if [ ! -e ${star_catalog_filename} ]; then
    python \
        ${SNPIT_PIPELINE_BASE}/sidecar/sidecar/star_retrieval.py \
        ${base_path}/${science_filename} \
        --output /${star_catalog_filename}
fi

python \
    ${SNPIT_PIPELINE_BASE}/sidecar/sidecar/pipeline.py \
    --image-collection manual_rdm \
    --base-path ${base_path} \
    --template-path ${template_filename} \
    --science-path ${science_filename} \
    --star-catalog ${star_catalog_filename} \
    --reject-known-stars \
    --cross-convolve \
    --temp-dir ${HOME}/tmp \
    --output-dir ${output_dir} \
    --save-debug-products \
    --backend4subtract numpy

subtraction_dir=${output_dir}/*${science_base:1:18}*${template_base:1:18}*
for file in ${subtraction_dir}/*detection*.ecsv; do
    python \
        ${SNPIT_PIPELINE_BASE}/sidecar/sidecar/catalog_to_ds9_region_file.py --peak-value-threshold 25 ${file}
done    