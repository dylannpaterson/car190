# setup for solid-waffle run

($sca) = @ARGV;

# now download the data

@files = ();
@grps = ();

# observations 007-012 are flats (5 each), then 013 is 10 darks
# CAR 143!!! Needs changing for other CARs. CURRENTLY HARDCODED.
#for $j (7..13) {
#    @grps = (@grps, (scalar @files));
#    $emax = 5;
#    if ($j==13) {$emax=10;}
#    for $e (1..$emax) {
#       $fnew = sprintf "r0101101001001%03d001_%04d_wfi%02d_dark_uncal_asdf_to.fits", $j, $e, $sca;
#       @files = (@files, $fnew);
#    }
#}

#CAR173 hardcoded
# high flats: r0106306008001011001, observation 011, exposures 0001..0004
@grps = (@grps, (scalar @files));
for $e (1..4) {
    $fnew = sprintf "r0106306008001011001_%04d_wfi%02d_dark_uncal_asdf_to.fits", $e, $sca;
    @files = (@files, $fnew);
}

# darks: r0106306008001009001, observation 009, exposures 0001..0004
@grps = (@grps, (scalar @files));
for $e (1..8) {
    $fnew = sprintf "r0106306%03d001012001_0001_wfi%02d_dark_uncal_asdf_to.fits", $e, $sca;
    @files = (@files, $fnew);
}

$ngrps = scalar @grps;
@grps = (@grps, (scalar @files));
for $j (0..$ngrps-1) {
    print (sprintf "%2d %4d %3d\n", $j, $grps[$j], $grps[$j+1] - $grps[$j]);
}

open(OUT, ">files.txt") or die;
for $f (@files) {
    $fa = $f;
    $fa =~ s/_asdf_to\.fits$/\.asdf/;
    $ff = (split "\_uncal", $f)[0];
    print "fetching $fa <-- $ff\%2F$fa\n";

    $ex = qq|curl -H "Authorization: token \$MAST_API_TOKEN" -L -X GET "https://mast.stsci.edu/search/roman/api/v0.1/retrieve_product?product_name=$ff\%2F$fa" --output "indata/$fa"|;
    system $ex;

    system "python -m basicinfo indata/$fa";
    print OUT "$fa\n";
}
close OUT;

# low-intensity flats (used only in the linearity fit)
# these go in their own list, loflats.txt, so files.txt is unchanged
# Taken from CAR 173. CURRENTLY HARDCODED.
@lofiles = ();
for $e (1..5) {
    $fnew = sprintf "r0106306008001010001_%04d_wfi%02d_dark_uncal_asdf_to.fits", $e, $sca;
    @lofiles = (@lofiles, $fnew);
}

open(OUT, ">loflats.txt") or die;
for $f (@lofiles) {
    $fa = $f;
    $fa =~ s/_asdf_to\.fits$/\.asdf/;
    $ff = (split "\_uncal", $f)[0];
    print "fetching $fa <-- $ff\%2F$fa\n";

    $ex = qq|curl -H "Authorization: token \$MAST_API_TOKEN" -L -X GET "https://mast.stsci.edu/search/roman/api/v0.1/retrieve_product?product_name=$ff\%2F$fa" --output "indata/$fa"|;
    system $ex;

    system "python -m basicinfo indata/$fa";
    print OUT "$fa\n";
}
close OUT;