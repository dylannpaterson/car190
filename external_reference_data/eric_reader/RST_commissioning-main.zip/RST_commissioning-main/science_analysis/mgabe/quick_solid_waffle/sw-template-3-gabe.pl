# setup for solid-waffle run

($sca, @passes) = @ARGV;

$n = scalar @passes;

# write file
open(OUT, ">sw_auto.txt") or die;
print OUT "DETECTOR: WFI%%%\n";
print OUT "LIGHT:\n";
$str = "";
for $j (0 .. $n-1) {
    print OUT (sprintf "  indata/r0103902%03d001003001_0001_wfi%02d_dark_uncal_asdf_to.fits\n", $passes[$j], $sca);
    $str .= "$passes[$j]";
    if ($j != $n-1) {$str .= '-';}
}
print OUT "DARK:\n";
for $j (0 .. $n-1) {
    print OUT (sprintf "  indata/r0103902%03d001001001_0001_wfi%02d_dark_uncal_asdf_to.fits\n", $passes[$j], $sca);
}
print OUT "FORMAT: 1\n";
print OUT "CHAR: Advanced 1 3 2 bfe\n";
print OUT "NLPOLY: 3 2 6\n";
print OUT "FULLNL: True True True\n";
print OUT "TIMEREF: 1.66666667\n";
print OUT "TIME:    2 3 4 5\n";
print OUT (sprintf "OUTPUT:         results/icemon-$str-wfi%02d\n", $sca);
close OUT;

# now download the data
@files = ();
for $j (0 .. $n-1) {
    for $c (1,3) {
        $fnew = sprintf "r0103902%03d00100%1d001_0001_wfi%02d_dark_uncal_asdf_to.fits", $passes[$j], $c, $sca;
        @files = (@files, $fnew);    
    }
}

$ct = 0;
for $f (@files) {
    $fa = $f;
    $fa =~ s/_asdf_to\.fits$/\.asdf/;
    $ff = (split "\_uncal", $f)[0];
    print "fetching $fa <-- $ff\%2F$fa\n";

    $e = qq|curl -H "Authorization: token \$MAST_API_TOKEN" -L -X GET "https://mast.stsci.edu/search/roman/api/v0.1/retrieve_product?product_name=$ff\%2F$fa" --output "indata/$fa"|;
    system $e;

    $ct++;
}