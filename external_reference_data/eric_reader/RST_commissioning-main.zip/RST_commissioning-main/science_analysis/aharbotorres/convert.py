"""Converts a gain array into FITS files for the differences."""

import numpy as np
from astropy.io import fits

data = np.load("gain_array.npy")
nfinal = 4  # how many gains from the end to use for medians

hdus = [fits.PrimaryHDU(data)]

gfinal = np.nanmedian(data[:, -nfinal:], axis=-1)
dlngain = np.log(data / gfinal[:, None])
nt = np.shape(data)[-1]

for j in range(6):
    nb = 2**j
    dlngain_bin = np.nanmedian( dlngain.reshape((18, nb, 32//nb, nb, 32//nb, -1)), axis=(2, 4) )
    dlngain_bin_flat = dlngain_bin.reshape((-1, nt))
    hdu = fits.ImageHDU(dlngain_bin_flat.T, name=f"DLNG_{nb:d}")
    hdu.header["BINSIZE"] = nb
    hdu.header["NSPRPIX"] = 18 * nb**2
    hdu.header["NEPOCH"] = nt
    hdus.append(hdu)

fits.HDUList(hdus).writeto("gain_array.fits", overwrite=True)
