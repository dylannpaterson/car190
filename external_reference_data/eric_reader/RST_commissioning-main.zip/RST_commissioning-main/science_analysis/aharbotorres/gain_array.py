import re
from pathlib import Path

import numpy as np
import pandas as pd
from astropy.io import fits

NUM_SCAS = 18
SUPERPIX_N = 32
COL_NUM = 5
STARTING_JOBID = 7656

def main():
    # Check working directory and path to data directory
    print("Current working directory:")
    print(Path.cwd())

    root_dir = Path("/").resolve()
    data_dir = Path(f"{root_dir}/data/chirata/sw-trending/").resolve()
    print(f"Data directory resolves to {data_dir}")

    # See which files are avialable in the data directory
    txt_files = list(data_dir.rglob("*.txt"))

    print("Number of txt files found:", len(txt_files))

    for file_path in txt_files[:20]:
        print(file_path)

    summary_files = list(data_dir.rglob("*wfi*_summary*.txt"))

    print("Summary files:", len(summary_files))
    for file_path in summary_files[:10]:
        print(file_path)

    # Extract SCA number from the filenames
    sca_pattern = re.compile(r"wfi(\d+)", re.IGNORECASE)
    file_lookup = {}

    for file_path in summary_files:

        match = sca_pattern.search(file_path.name)

        if not match:
            continue

        sca_num = int(match.group(1))
        pass_id = file_path.parent.name

        if pass_id not in file_lookup:
            file_lookup[pass_id] = {}

        file_lookup[pass_id][sca_num] = file_path

    # Get the passes from the files found
    pass_ids = sorted([pass_id for pass_id in file_lookup.keys() if int(pass_id) >= STARTING_JOBID], key=int)
    num_passes = len(pass_ids)

    print(f"Starting job ID: {STARTING_JOBID}")
    print(f"Number of passes found: {num_passes}")
    print(f"Pass IDs: {pass_ids}")

    # Create the data array
    data = np.zeros((NUM_SCAS * SUPERPIX_N * SUPERPIX_N, num_passes), dtype=np.float32)

    # Populate it
    for pass_idx, pass_id in enumerate(pass_ids):

        for sca_num in range(1, NUM_SCAS + 1):
            file_path = file_lookup[pass_id].get(sca_num)

            if file_path is None:
                print(f"WARNING: No SCA {sca_num:02d} file found for pass {pass_id}")
                continue

            data_file = np.loadtxt(file_path)

            # Grab desired column
            sca_data = data_file[:, COL_NUM]

            start = ((sca_num - 1)* SUPERPIX_N* SUPERPIX_N)
            stop = (sca_num* SUPERPIX_N* SUPERPIX_N)

            # Store this SCA for this pass
            data[start:stop,pass_idx] = sca_data

    print(f"Shape of the data array is: {data.shape}")

    # Save the array
    output_path = Path("gain_array.npy")

    np.save(output_path, data)

    print(f"Saved gain array to {output_path.resolve()}")

    nfinal = 4  # how many gains from the end to use for medians

    # Check for non-finite values
    print("Total non-finite superpixels:", np.sum(~np.isfinite(data)))
    
    data[np.isinf(data)] = np.nan

    hdus = [fits.PrimaryHDU(data)]

    gfinal = np.nanmedian(data[:, -nfinal:], axis=-1)
    dlngain = np.log(data / gfinal[:, None])

    nt = np.shape(data)[-1]

    for j in range(6):
        nb = 2**j
        dlngain_bin = np.nanmedian( dlngain.reshape((18, nb, 32//nb, nb, 32//nb, -1)), axis=(2, 4) )
        dlngain_bin_flat = dlngain_bin.reshape((-1, nt))
        hdu = fits.ImageHDU(dlngain_bin_flat.T, name=f"DLNG_{nb:d}")
        hdu.header["BINSIZE"] = nb
        hdu.header["NSPRPIX"] = 18 * nb**2
        hdu.header["NEPOCH"] = nt
        hdus.append(hdu)

    fits.HDUList(hdus).writeto("gain_array.fits", overwrite=True)


if __name__ == "__main__":
    main()

