import os
import subprocess

import asdf
import numpy as np
from astropy.io import fits

n_template = 2

from astropy.time import Time

class MnemonicTable():
    """Builds a data table from a given filename.

    Parameters
    ----------
    filename : str
        The file name for the input file.

    Attributes
    ----------
    n : int
        Number of points in table.
    t : np.ndarray of float
        1D table of timestamps, length `n`, in MJD.
    data : np.ndarray of float
        1D table of that mnemonic.

    """

    def __init__(self, filename):

        with open(filename) as fn:
            data = fn.readlines()[1:]
            self.n = len(data)
            self.t = np.zeros(self.n)
            self.data = np.zeros((self.n,), dtype=np.float32)

        for j in range(self.n):
            if j % 100000 == 0: print(f"{j}/{self.n}", flush=True)
            vals = data[j].rstrip().split(",")
            self.t[j] = Time(vals[0], format="isot", scale="utc").mjd
            self.data[j] = float(vals[1])

    def signal(self, t1, t2):
        """Gets the mean signal between two times.

        Parameters
        ----------
        t1, t2 : float or str
            Times in MJD or ISO timestring.

        Returns
        -------
        float
            Mean signal in that time window.
        """

        _t1 = t1 if isinstance(t1, float) else Time(t1, format="isot", scale="utc").mjd
        it1 = np.searchsorted(self.t, _t1)
        _t2 = t2 if isinstance(t1, float) else Time(t2, format="isot", scale="utc").mjd
        it2 = np.searchsorted(self.t, _t2)
        return np.mean(self.data[it1+1:it2])


    def signal_from_exp(self, fn):
        """Gets the mean signal in an exposure.

        Parameters
        ----------
        fn : str
            File name.

        Returns
        -------
        float
            Mean signal in that time window.
        """

        with asdf.open(fn) as a:
            exposure = a["roman"]["meta"]["exposure"]
            s = self.signal(exposure["start_time"], exposure["end_time"])
        return s


def get_temp_trend(temp_file):
    """Extracts the temperature data for a bunch of passes of the ice trending.

    Parameters
    ----------
    temp_file : str
        The temperature data from EDP.

    Returns
    -------
    np.ndarray
        The vector of temperatures.

    """

    tab = MnemonicTable(temp_file)

    # extract the exposures
    n = 126
    result = np.zeros((n,), dtype=np.float32)

    for j in range(n):
        ps = j + 1; cy = 2
        if ps > 90:
            ps -= 90; cy = 3
        vstem = f"r010630{cy:1d}{ps:03d}001"
        fn1 = vstem + f"009001_0001_wfi01_dark%2F"
        fn2 = vstem + f"009001_0001_wfi01_dark_uncal.asdf"

        # pull data and compress into 2D cube
        proc = ["curl", "-H", os.path.expandvars("Authorization: token $MAST_API_TOKEN"), "-L", "-X", "GET",
            "https://mast.stsci.edu/search/roman/api/v0.1/retrieve_product?product_name=" + fn1 + fn2 + "",
            "--output", fn2, "--fail", "--create-dirs"
            ]
        subprocess.run(proc, capture_output=True, text=True)

        # extract header and clear
        result[j] = tab.signal_from_exp(fn2)
        os.remove(fn2)

    return(result)

# build temperature table
# mpa_temp = np.loadtxt("temp.dat")[:, 1]  # <-- testing only
mpa_temp = get_temp_trend("/data/chirata/eng/WFI_MCE_ADC_WTSM00_20260924T120000_20260927T120000.csv")
for j in range(len(mpa_temp)):
    print(f"{j+1:3d} {mpa_temp[j]:7.3f}", flush=True)

with fits.open("gain_array.fits") as f:
    d = np.log(f[0].data)
    (nc, nt) = np.shape(d)
    coefs = np.zeros((nc, n_template + 2))

    a = np.zeros((nt, n_template))
    a[:, 0] = 1.0
    a[:, 1] = mpa_temp - 89.5
    for j in range(nc):

        _use = np.isfinite(d[j])

        # outlier clipping iterations
        for k in range(5):

            # cut at 4 sigma
            if k > 0:
                _use = np.logical_and(np.isfinite(d[j]), np.abs(d[j] - a@coefs[j, :-2]) < 4.0 * coefs[j, -1])

            ng = np.count_nonzero(_use)
            aw = a * np.where(_use, 1.0, 0.0)[:, None]
            dw = np.where(_use, d[j], 0.0)
            coefs[j, :-2] = np.linalg.lstsq(aw, dw)[0]
            resid = dw - aw@coefs[j, :-2]
            coefs[j, -1] = np.sqrt(np.sum(resid**2) / ng)
            coefs[j, -2] = nt - ng

        if coefs[j, -2] > 3:
            print(f"Rejected col {j:5d}, {nt-ng:4d} of {nt:4d} samples.")
        if ng < n_template:
            coefs[j, :n_template] = 0
            coefs[j, -1] = np.inf

np.savetxt("gainpars.txt", coefs)

# make 16x16 bin version
coefs_16x16 = np.nanmedian(coefs.reshape((18, 16, 2, 16, 2, -1)), axis=(2, 4)).reshape((4608, -1))
np.savetxt("gainpars-16.txt", coefs_16x16)
# make 8x8 bin version
coefs_8x8 = np.nanmedian(coefs.reshape((18, 8, 4, 8, 4, -1)), axis=(2, 4)).reshape((1152, -1))
np.savetxt("gainpars-8.txt", coefs_8x8)
# make 4x4 bin version
coefs_4x4 = np.nanmedian(coefs.reshape((18, 4, 8, 4, 8, -1)), axis=(2, 4)).reshape((288, -1))
np.savetxt("gainpars-4.txt", coefs_4x4)
# make 2x2 bin version
coefs_2x2 = np.nanmedian(coefs.reshape((18, 2, 16, 2, 16, -1)), axis=(2, 4)).reshape((72, -1))
np.savetxt("gainpars-2.txt", coefs_2x2)
