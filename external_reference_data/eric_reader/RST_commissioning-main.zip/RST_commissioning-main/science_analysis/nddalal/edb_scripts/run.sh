#!/usr/bin/env bash
set -euo pipefail

# Dynamic variables
PREFIX="MPA_temperature"
PNEMONIC="WFI_MCE_ADC_WTSM00"

# Patterned filenames
ORIG_CSV="${PREFIX}_orig.csv"
DECON_CSV="${PREFIX}_decon.csv"
OUTPUT_PLOT="${PREFIX}_plot.png"

# Step 1: Download files
echo "Downloading CSVs..."
curl -X GET "https://mast.stsci.edu/edp/api/v0.1/mnemonics/spa/roman/data?mnemonic=$PNEMONIC&s_time=2026-09-10T12:00:00&e_time=2026-09-12T12:00:00&result_format=csv" -H "Authorization: token $MAST_API_TOKEN"  --compressed --output "$ORIG_CSV"
curl -X GET "https://mast.stsci.edu/edp/api/v0.1/mnemonics/spa/roman/data?mnemonic=$PNEMONIC&s_time=2026-09-24T16:00:00&e_time=2026-09-25T12:00:00&result_format=csv" -H "Authorization: token $MAST_API_TOKEN"  --compressed --output "$DECON_CSV"

# Step 2: Run Python script
echo "Generating plot..."
python3 plotter.py \
  --orig-file "$ORIG_CSV" \
  --decon-file "$DECON_CSV" \
  --output-img "$OUTPUT_PLOT"

echo "Done! Generated $OUTPUT_PLOT"