import argparse
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

def format_hms(x, pos):
    hours, remainder = divmod(x, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{int(hours):02d}:{int(minutes):02d}:{int(seconds):02d}"

def main():
    parser = argparse.ArgumentParser(description="Plot temperature data from downloaded CSVs.")
    parser.add_argument("--orig-file", required=True, help="Path to original CSV")
    parser.add_argument("--decon-file", required=True, help="Path to decon CSV")
    parser.add_argument("--output-img", required=True, help="Path to save the output plot")
    
    args = parser.parse_args()

    df_orig = pd.read_csv(args.orig_file, parse_dates=['ObsTime'])
    df_decon = pd.read_csv(args.decon_file, parse_dates=['ObsTime'])

    df_orig['Elapsed_Sec'] = (df_orig['ObsTime'] - df_orig['ObsTime'].iloc[0]).dt.total_seconds()
    df_decon['Elapsed_Sec'] = (df_decon['ObsTime'] - df_decon['ObsTime'].iloc[0]).dt.total_seconds()

    plt.figure(figsize=(10, 5))
    plt.plot(df_orig['Elapsed_Sec'], df_orig['EUValue'], marker='o', linestyle='-', linewidth=1.5, label="First Cooldown")
    plt.plot(df_decon['Elapsed_Sec'], df_decon['EUValue'], marker='s', linestyle='--', linewidth=1.5, label="Decontamination")

    plt.xlabel('Elapsed Time Since Presumed Start', fontsize=11)
    plt.ylabel('Temperature (K)', fontsize=11)

    plt.gca().xaxis.set_major_formatter(ticker.FuncFormatter(format_hms))
    plt.gcf().autofmt_xdate()

    plt.grid(True, linestyle='--', alpha=0.6)
    plt.legend()
    plt.tight_layout()

    plt.savefig(args.output_img, dpi=300)
    plt.close()

if __name__ == "__main__":
    main()