Confirm with the user before reviewing any files outside of this parent RST_commissioning repo path.
By default, unless specific user over-ride, do not use git except to compare older versions or monitor changes via status or similar.
Unless requested, do not use non-ascii characters in code or markdown; use suitable replacements like "lambda".
By default, unless specific user request, the human should handle git commit or PR processes. 
Do not read .env or mast_api_token.txt files. Note that venv is fine to help debug there.
