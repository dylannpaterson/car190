"""
Roman WFI pixel DQ flags — 32-bit categorical colormap, horizontal layout.

Paste straight into a notebook cell (or `%run` this file, or
`from roman_dq_cmap_horizontal import plot_dq_colormap_horizontal`).
Draws one colored box per bit, laid out left-to-right:
  - the bit number sits inside the box (no "bit" prefix, no hex)
  - the flag's meaning is printed small and rotated vertically below the box
so the whole 32-bit legend spans wide and stays short (good for a notebook
cell you don't want to scroll).

As before, the bit -> name mapping is pulled live from
`roman_datamodels.dqflags.pixel` when available, and only falls back to the
hardcoded table below if that import fails. Confirm against your installed
version before using this for anything beyond quick-look plots:

    from roman_datamodels.dqflags import pixel
    {f.name: int(f.value) for f in pixel}
"""

from __future__ import annotations

__author__ = "Henry C. Ferguson, STScI"
__version__ = "0.2.1"
__license__ = "BSD3"

# History
# 0.1   -- Initial version from claude.ai
# 0.2   -- Added imshow_dq and flagged_pixel_coords, tweaked elsewhere
# 0.2.1 -- Removed unnecessary if __name__ == __main__ at the end

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.colors as mcolors
from matplotlib.colors import ListedColormap, BoundaryNorm

# ---------------------------------------------------------------------------
# Fallback bit -> name table (used only if roman_datamodels isn't importable)
# ---------------------------------------------------------------------------
_FALLBACK_PIXEL_FLAGS = {
    "GOOD": 0,
    "DO_NOT_USE": 2**0,
    "SATURATED": 2**1,
    "JUMP_DET": 2**2,
    "DROPOUT": 2**3,
    "RESERVED_1": 2**4,
    "RESERVED_2": 2**5,
    "RESERVED_3": 2**6,
    "RESERVED_4": 2**7,
    "UNRELIABLE_ERROR": 2**8,
    "NON_SCIENCE": 2**9,
    "DEAD": 2**10,
    "HOT": 2**11,
    "WARM": 2**12,
    "LOW_QE": 2**13,
    "RC": 2**14,
    "TELEGRAPH": 2**15,
    "NONLINEAR": 2**16,
    "BAD_REF_PIXEL": 2**17,
    "NO_FLAT_FIELD": 2**18,
    "NO_GAIN_VALUE": 2**19,
    "NO_LIN_CORR": 2**20,
    "NO_SAT_CHECK": 2**21,
    "UNRELIABLE_BIAS": 2**22,
    "UNRELIABLE_DARK": 2**23,
    "UNRELIABLE_SLOPE": 2**24,
    "UNRELIABLE_FLAT": 2**25,
    "OPEN": 2**26,
    "ADJ_OPEN": 2**27,
    "UNRELIABLE_RESET": 2**28,
    "RESERVED_5": 2**29,
    "OTHER_BAD_PIXEL": 2**30,
    "REFERENCE_PIXEL": 2**31,
}


def get_dq_flags(use_installed: bool = True) -> dict[str, int]:
    """Return a {name: bit_value} dict, preferring the live roman_datamodels enum."""
    if use_installed:
        try:
            from roman_datamodels.dqflags import pixel

            return {f.name: int(f.value) for f in pixel}
        except Exception:
            pass
    return dict(_FALLBACK_PIXEL_FLAGS)


def build_dq_colormap(
    flags: dict[str, int] | None = None,
) -> tuple[ListedColormap, list[tuple[str, int]]]:
    """32-entry categorical colormap, one color per DQ bit (0-31)."""
    flags = flags or get_dq_flags()
    value_to_name = {v: n for n, v in flags.items() if v != 0}
    bit_names = [(value_to_name.get(2**bit, f"UNUSED_BIT_{bit}"), bit) for bit in range(32)]

    base = (
        list(plt.get_cmap("tab20").colors)
        + list(plt.get_cmap("tab20b").colors)
        + list(plt.get_cmap("tab20c").colors)
    )
    colors = [base[i % len(base)] for i in range(32)]
    cmap = ListedColormap(colors, name="roman_dq_bits")
    return cmap, bit_names


def plot_dq_colormap(
    flags: dict[str, int] | None = None,
    figsize: tuple[float, float] = (16, 2.1),
    ax: "plt.Axes | None" = None,
    fontsize: float = 10,
):
    """
    Plot the 32-bit DQ legend as a single horizontal row: bit number inside
    each color box, flag name above each box at a 45-degree angle (keeps the
    whole legend short vertically).

    Parameters
    ----------
    fontsize : float
        Font size used for both the in-box bit numbers and the diagonal
        flag-name labels.

    Returns
    -------
    fig, ax, cmap
    """
    cmap, bit_names = build_dq_colormap(flags)
    n = len(bit_names)

    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.figure

    for name, bit in bit_names:
        x = bit
        color = cmap.colors[bit]
        ax.add_patch(mpatches.Rectangle((x, 0), 0.9, 0.9, color=color, ec="black", lw=0.5))

        # pick readable text color for the bit number based on box luminance
        r, g, b = color[:3]
        lum = 0.299 * r + 0.587 * g + 0.114 * b
        txt_color = "black" if lum > 0.55 else "white"
        ax.text(
            x + 0.45, 0.45, str(bit),
            ha="center", va="center", fontsize=fontsize, color=txt_color, fontweight="bold",
        )
        ax.text(
            x + 0.45, 1.0, name,
            ha="left", va="bottom", fontsize=fontsize, rotation=45,
            rotation_mode="anchor", family="monospace",
        )

    ax.set_xlim(0, n)
    ax.set_ylim(0, 2.15)
    ax.axis("off")
    ax.set_title("Roman WFI pixel DQ flags", fontsize=11, loc="left", pad=2)
    fig.tight_layout(pad=0.2)
    return fig, ax, cmap


def dq_to_log2(dq: np.ndarray) -> np.ma.MaskedArray:
    """
    Convert a raw DQ bitmask array to floor(log2(dq)), for use with
    `imshow_dq_log2`.

    When several bits are set, floor(log2(dq)) always equals the index of
    the *highest-numbered* set bit (that's a standard bitmask identity), so
    each pixel gets colored by its most-significant flag rather than by an
    arbitrary/meaningless linear value. GOOD pixels (dq == 0) come back
    masked, since log2(0) is undefined.
    """
    dq = np.asarray(dq)
    with np.errstate(divide="ignore"):
        # avoid the divide-by-zero warning; those entries get masked below anyway
        log2 = np.floor(np.log2(np.where(dq == 0, 1, dq)))
    return np.ma.masked_where(dq == 0, log2)


def imshow_dq_log2(log2_dq: np.ndarray, cmap: ListedColormap, ax=None, **imshow_kwargs):
    """
    Display a precomputed floor(log2(dq)) array (e.g. from `dq_to_log2`)
    using the 32-color DQ colormap, with GOOD/masked pixels rendered fully
    transparent (so the axes background, or whatever's plotted underneath,
    shows through).

    A `BoundaryNorm` is used instead of the default linear `Normalize` so
    that integer log2 values 0-31 map to *exactly* the matching colormap
    entry — with a plain linear norm, rounding can put a value one bin off.

    Parameters
    ----------
    log2_dq : array
        Output of `dq_to_log2`, or any array of (possibly masked/NaN)
        integers 0-31.
    cmap : ListedColormap
        The 32-color map from `build_dq_colormap()`.
    ax : matplotlib Axes, optional
        Draw into an existing axes instead of `plt.imshow` on the current one.
    **imshow_kwargs
        Passed through to `imshow` (e.g. `origin`, `interpolation`).

    Returns
    -------
    The image (AxesImage) returned by imshow.
    """
    cmap = cmap.copy()
    cmap.set_bad(alpha=0)  # GOOD / masked pixels -> fully transparent
    norm = BoundaryNorm(np.arange(-0.5, 32.5, 1), cmap.N)
    target = ax if ax is not None else plt
    return target.imshow(log2_dq, cmap=cmap, norm=norm, **imshow_kwargs)


def imshow_dq(dq: np.ndarray, cmap: ListedColormap = None, ax=None, **imshow_kwargs):
    """
    Display a dq array
    using the 32-color DQ colormap, with GOOD/masked pixels rendered fully
    transparent (so the axes background, or whatever's plotted underneath,
    shows through).

    A `BoundaryNorm` is used instead of the default linear `Normalize` so
    that integer log2 values 0-31 map to *exactly* the matching colormap
    entry — with a plain linear norm, rounding can put a value one bin off.

    Parameters
    ----------
    dq : array
        Data quality array -- integers 0-31
    cmap : ListedColormap
        The 32-color map from `build_dq_colormap()`.
    ax : matplotlib Axes, optional
        Draw into an existing axes instead of `plt.imshow` on the current one.
    **imshow_kwargs
        Passed through to `imshow` (e.g. `origin`, `interpolation`).

    Returns
    -------
    The image (AxesImage) returned by imshow.
    """
    if cmap is None:
        cmap, bit_names = build_dq_colormap()
    log2_dq = dq_to_log2(dq)
    imshow_dq_log2(log2_dq, cmap, ax=ax, **imshow_kwargs)
    

def imshow_bit_overlay(
    dq: np.ndarray,
    bit: int = 0,
    ax=None,
    color: str = "magenta",
    alpha: float = 0.5,
    **imshow_kwargs,
):
    """
    Overlay a single DQ bit (default: bit 0, DO_NOT_USE) as a flat
    semi-transparent color layer on top of an existing plot (e.g. the
    `imshow_dq_log2` image). This is meant to solve the problem that
    `floor(log2(dq))` always hides low-numbered bits whenever a
    higher-numbered bit is also set — call this *after* `imshow_dq_log2`
    to put the flagged pixels back in view regardless of what color is
    underneath them.

    Pixels without the bit set are drawn fully transparent (alpha=0);
    pixels with it set are drawn at `alpha` in `color`. Per-pixel alpha is
    built directly into an RGBA array (rather than using a colormap), so
    this always composites cleanly no matter what's underneath.

    Parameters
    ----------
    dq : array
        Raw DQ bitmask array (not log2'd).
    bit : int
        Which bit to highlight (0 = DO_NOT_USE by default).
    ax : matplotlib Axes, optional
        Draw into an existing axes (typically the same one the base
        `imshow_dq_log2` call used) instead of `plt.imshow`.
    color : str
        Any matplotlib color spec for the highlight.
    alpha : float
        Opacity of the highlighted pixels; 0 = invisible, 1 = opaque.
    **imshow_kwargs
        Passed through to `imshow` (e.g. `origin`, `interpolation`,
        `extent` — worth matching whatever you passed to the base image).

    Returns
    -------
    The image (AxesImage) returned by imshow.
    """
    dq = np.asarray(dq)
    mask = (dq & (1 << bit)) != 0
    rgba = np.zeros(dq.shape + (4,))
    rgba[..., :3] = mcolors.to_rgb(color)
    rgba[..., 3] = np.where(mask, alpha, 0.0)
    target = ax if ax is not None else plt
    return target.imshow(rgba, **imshow_kwargs)


def decode_dq(values, flags: dict[str, int] | None = None) -> list[list[str]]:
    """
    Given a list/array of raw DQ bitmask values, return a list of lists of
    the flag names set on each pixel (e.g. [["DO_NOT_USE", "JUMP_DET"], [],
    ["SATURATED"]]). A pixel with value 0 (GOOD) gets an empty list.

    Parameters
    ----------
    values : sequence of int
        Raw DQ pixel values.
    flags : dict, optional
        {name: bit_value} mapping, e.g. from `get_dq_flags()`. If omitted,
        `get_dq_flags()` is called (tries the installed roman_datamodels
        first).
    """
    flags = flags or get_dq_flags()
    single_bit_flags = [(name, val) for name, val in flags.items() if val != 0]
    return [
        [name for name, val in single_bit_flags if int(v) & val]
        for v in values
    ]

def flagged_pixel_coords(dq_array,flag="DO_NOT_USE"):
    """
    Return the (row, col) coordinates of all pixels with the HOT flag set.

    Parameters
    ----------
    dq_array : np.ndarray
        2D data quality array (e.g. from a reference file's dq extension,
        or a science product's dq array).

    Returns
    -------
    coords : np.ndarray, shape (N, 2)
        Array of (row, col) index pairs for flagged pixels.
    """
    flagbits = get_dq_flags()
    flagged_bit = flagbits[flag]

    # bitwise AND to test whether the HOT bit is set at each pixel
    is_flagged = (dq_array & flagged_bit) != 0

    rows, cols = np.where(is_flagged)
    coords = np.column_stack((rows, cols))

    print(f"Row,col coords of {len(coords)} pixels flagged as {flagged_bit} -- {flag}")
    return coords
