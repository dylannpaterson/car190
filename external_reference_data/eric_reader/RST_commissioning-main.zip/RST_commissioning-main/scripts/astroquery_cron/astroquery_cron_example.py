"""
Astroquery Cron Script Example

This script connects to the MAST archive, performs searches for Roman mission data,
and saves the results to a CSV file.

An environment file is used to store sensitive information such as API tokens and email recipients.
The environment file must contain the following variable:

- MAST_API_TOKEN: The API token for accessing MAST OPS.

To run the script, update your environment with the requirements.txt file, create the environment file 
with the necessary information, then type:
>>> python -m astroquery_cron_example
"""

# Imports

## Logistics and setup
from dotenv import load_dotenv

# Setup
## Load environment variables from the .env file
load_dotenv(dotenv_path="./variables.env")

import os

## Query, data handling, and POST
from astroquery.mast import MastMissions
from astropy.table import Table, vstack, unique

## Connect to MAST
mast = MastMissions(mission='Roman')
mast.login(token=os.getenv('MAST_API_TOKEN')) 

# List of Program IDs to search on
PROGRAM_IDS = [1039, 1027]


def search_pid(pid: str) -> None:
    """
    Search for a given program ID (PID) in the MAST archive.

    Parameters:
        pid (str): The program ID to search for.
        
    Returns:
        None
    """
    
    columns = ['fileSetName', 'dataset_category', 'productLevel',
               'optical_element', 'program', 'pass', 'segment', 
               'exposure_type', 'detector', 'ArchiveFileID', 'filedate']
    
    # Check if a previous search was run and if so get the last file date
    if os.path.exists(f'./{pid}_search_results.csv'):
        old_tab = Table.read(f'./{pid}_search_results.csv')
        dates = old_tab['filedate'].value
        dates.sort()
        file_date = dates[-1]
    else:
        old_tab = None
        file_date='2026-08-30T07:26:04'
            
    # Perform the search for the given PID
    # This restricts the search to files with a filedate greater than or equal to the last 
    # file date found in the previous search results (if any). This ensures that only new files are returned.
    # Also only L1 and L2 products are returned in this case.
    search = {'program': pid, 'productLevel': [1, 2], 'filedate': f'>={file_date}'}
    results = mast.query_criteria(**search, select_cols=columns)
    
    # Combine old search results with new results if old results exist
    if old_tab is not None and len(old_tab) > 0:
        stack = vstack([old_tab, results])
        stack['filedate_time'] = Time(stack['filedate'], format='isot', scale='utc')
        stack.sort(['filename','filedate_time'])
        results = unique(stack, keys='ArchiveFileID', keep='last')
    
    # Save the combined search results to a CSV file
    if len(results) > 0:
        results.write(f'./{pid}_search_results.csv', format='csv', overwrite=True)


def main():
    """
    Main function to execute the script.
    
    Returns:
        None
    """
    
    # Create a file to indicate that the script is running
    with open('./cron_run.lock', 'w') as f:
        f.write(f"Job running")
    
    for pid in PROGRAM_IDS:
        search_pid(f"{pid:05d}")
        
    # Remove the lock file to indicate that the script has finished running
    os.remove('./cron_run.lock')


if __name__ == "__main__":
    if not os.path.exists('./cron_run.lock'):
        main()
    else:
        print("Lock file exists.")
