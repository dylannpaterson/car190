# Astroquery Cron Example for Regular MAST Checks

The astroquery_cron_example.py script queries MAST for commissioning data and stores the results (if any) in CSV files. The script checks the file creation date of the most recent file (which we are using as a proxy for MAST ingest time) to search for only new files since the last search.

## Manually Run the Script

To run the script manually, you can type at the command line:
> python -m astroquery_cron_example

## Setting up a Cron Job
To set up a cron job to run this, you need to use the Python executable specific to that environment.

1. In a terminal with the environment in which the script will run activated, type `which python` and note the full path to the Python executable.
2. Also in a terminal, type `crontab -e` to open an editor and update the crontab. If you do not have your $EDITOR and $VISUAL environment variables set, you may need to set these to an appropriate editor (e.g., vim, nano, emacs).
3. In the crontab, you need to set up the interval for how frequently the job will run. There are multiple websites for this such as [CronTab Guru](https://crontab.guru/) and AI agents can also help you. In the example below, we will show how to set it to run every 30 minutes.

The following crontab entry will run the script every 30 minutes:

> */30 * * * * /path/to/python /path/to/script/astroquery_cron_example.py >> /path/to/cron.log 2>&1

The portion `2>&1` redirects the stderr to stdout so it is all captured in the cron log.

4. Save the crontab file and it will begin to execute automatically. If you have sudo permissions, you may have additional options available to start or stop the cron daemon, but generally you can just remove the line from the crontab to stop the automation if necessary.