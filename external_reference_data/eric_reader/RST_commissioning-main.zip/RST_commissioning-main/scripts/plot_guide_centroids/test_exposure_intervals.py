import tempfile
import unittest
from pathlib import Path

import asdf
from astropy.time import Time
import matplotlib.pyplot as plt

from plot_guide_centroids import load_cal_intervals, matching_intervals, shade_intervals, main
import test_plot_guide_centroids as centroid_tests


class ExposureTests(unittest.TestCase):
    def fixture(self, path, start='2026-09-21T01:00:00.500', stop='2026-09-21T01:00:02.500'):
        with asdf.AsdfFile(dict(roman=dict(meta=dict(filename=path.name, exposure=dict(start_time=Time(start), end_time=Time(stop)))))) as f:
            f.write_to(path)

    def test_exact_times_association_and_artists(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp); cal=p/'r0102901001001002001_0002_wfi01_f129_cal.asdf'; self.fixture(cal)
            intervals=load_cal_intervals([cal]); summary=dict(first_signal_utc='2026-09-21T01:00:00.000',last_signal_utc='2026-09-21T01:00:03.000')
            selected=matching_intervals(p/'r0102901001001002001_9_wfi01_f129_gw.asdf',summary,intervals)
            self.assertEqual(len(selected),1)  # Acquisition number need not equal exposure number.
            self.assertEqual(selected[0]['start_utc'],'2026-09-21T01:00:00.500')
            self.assertFalse(matching_intervals(p/'r0102901001001002001_9_wfi02_f129_gw.asdf',summary,intervals))
            self.assertFalse(matching_intervals(p/'r0102901001001003001_9_wfi01_f129_gw.asdf',summary,intervals))
            late=dict(first_signal_utc='2026-09-21T02:00:00',last_signal_utc='2026-09-21T02:00:03')
            self.assertFalse(matching_intervals(p/'r0102901001001002001_9_wfi01_f129_gw.asdf',late,intervals))
            fig,ax=plt.subplots(); ax.set_xlim(0,3); shade_intervals(ax,summary,selected)
            self.assertEqual(len(ax.patches),1)
            self.assertEqual([float(line.get_xdata()[0]) for line in ax.lines],[.5,2.5])
            self.assertIn(cal.name,ax.texts[0].get_text());plt.close(fig)

    def test_cli_shades_and_records_two_intervals(self):
        with tempfile.TemporaryDirectory() as tmp:
            import json
            p=Path(tmp);gw=p/'r0102901001001002001_9_wfi01_f129_gw.asdf';centroid_tests.CentroidTests().make_file(gw)
            c1=p/'r0102901001001002001_0001_wfi01_f129_cal.asdf';c2=p/'r0102901001001002001_0002_wfi01_f129_cal.asdf'
            self.fixture(c1,stop='2026-09-21T01:00:01.000');self.fixture(c2,start='2026-09-21T01:00:02.000')
            self.assertEqual(main([str(gw),'--cal',str(c1),str(c2),'-o',str(p/'plot.png'),'--summary',str(p/'summary.json')]),0)
            self.assertEqual(len(json.loads((p/'summary.json').read_text())[0]['science_intervals']),2)

    def test_invalid_interval_and_output_protection(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);cal=p/'r0102901001001002001_0002_wfi01_f129_cal.asdf';self.fixture(cal,stop='2026-09-21T00:00:00')
            with self.assertRaises(ValueError):load_cal_intervals([cal])
            self.fixture(cal);gw=p/'r0102901001001002001_9_wfi01_f129_gw.asdf';centroid_tests.CentroidTests().make_file(gw)
            with self.assertRaises(SystemExit) as context:main([str(gw),'--cal',str(cal),'--summary',str(cal)])
            self.assertEqual(context.exception.code,2)
