# Plot Roman guide-window centroids

A standalone Python CLI that accepts Roman `*_gw.asdf` files and writes **one row per file**, with three panels:

1. Last acquisition pair not flagged as reset-impacted.
2. Median tracking image, excluding reset-impacted pairs. For acquisition-only files, use the acquisition sequence instead, with an explicit label.
3. Tracking centroid x/y in detector coordinates, relative to the median accepted position; acquisition centroids when no tracking sequence exists.

Filenames label each row. Time axes show seconds since the first selected-sequence signal timestamp, including its UTC date. Input order is retained; wildcard matches are sorted and duplicate paths are removed. No network access, MAST credentials, or calibrated science files are required.

## Installation

Python 3.10 or newer:

```sh
python -m pip install -r requirements.txt
```

Use an environment that can read your Roman ASDF files. `asdf-astropy` decodes ASDF time objects. A compatible `roman_datamodels`/`rad` installation can additionally interpret Roman-specific tags; this script accesses the underlying mappings and arrays without requiring Roman model classes. ASDF extension/version warnings are deliberately not suppressed: update your environment if an installed extension cannot decode an input file.

## Usage

```sh
python plot_guide_centroids.py /data/visit1_gw.asdf /data/visit2_gw.asdf -o centroids.png

python plot_guide_centroids.py '/data/*_gw.asdf' \
    -o centroids.pdf --summary centroids.json --measurements-dir measurements
```

Both shell-expanded and quoted globs are supported. PNG, PDF, and SVG output are supported. The default output is `guide_centroids.png` in the current directory. Existing output files are replaced; input files are never modified. Output parent directories are created as needed. Many files produce a tall figure; use PDF or split large batches to avoid raster image size limits.

Options:

- `--radius 4`: aperture radius in pixels.
- `--min-snr 10`: minimum approximate signal-to-noise selection statistic.
- `--skip-seconds 10`: omit initial tracking seconds from centroids and statistics (default: no initial exclusion). This does not change image panels.
- `--allow-pseudo-star`: explicitly attempt centroids even when metadata marks a pseudo-star; the row remains labeled with a warning.
- `--summary FILE`: JSON statistics, including usable/reset counts, timestamps, standard deviation and NMAD in x/y, and selection settings. Missing statistics are `null`.
- `--measurements-dir DIR`: CSV for every readable input, containing all pairs, acceptance/reset flags, window and detector coordinates, flux, and approximate S/N. Rejected centroid estimates are diagnostic only: always filter on `usable`.
- `--dpi 160`: raster resolution.

A malformed file gets an annotated error row; processing continues, saves the figure, and exits with status 1. Status 0 means the inputs were processed, **not** that guiding was good. An input with no usable centroids still gets an image row and explanatory text. Invalid arguments exit with status 2.

## Method and interpretation

Signal and pedestal arrays are converted to floating point before subtraction to avoid unsigned integer wraparound. For each pair in the selected sequence, the median of a two-pixel image border is subtracted. The brightest pixel initializes three iterations of a circular-aperture flux-weighted centroid. A pair is accepted only if it is not reset-impacted, has finite coordinates, passes the approximate S/N cut, and has its centroid inside the window away from the outer edge. The routine adds `lower_left_corners` in (x, y) order so window movements do not masquerade as detector motion.

The approximate S/N uses border-pixel NMAD and aperture area. It is not a full uncertainty estimate and does not include a propagated source Poisson term. NMAD is `1.4826 * median(abs(position - median(position)))`; plotted statistics include only accepted pairs after the optional initial time cut. No temporal sigma clipping is applied, so real large excursions are retained. Acquisition/tracking image stretches are independent. The median tracking image is in window coordinates and is not registered for moving windows.

These are measured image centroids, not onboard FGS telemetry or an absolute astrometric solution. Inspect the images: multiple stars, edge truncation, cosmic rays, weak sources, and detector artifacts can bias a flux-weighted centroid or cause it to jump to another source. S/N and reset cuts cannot rule out all such failures. Pseudo-star windows are not interpreted by default, because a noise peak must not be presented as a guide star. A large NMAD can also include commanded motion; this plot alone cannot identify the cause.

Science intervals are read from optional calibrated-image metadata; guide-window collection times are not treated as science-exposure times.

## Validation

```sh
python -m unittest discover -v
```

Tests cover detector-coordinate invariance under window relocation, reset exclusion, unsigned subtraction, pseudo-star handling, mixed valid/invalid inputs, multi-row plotting, and empty time selections. The release was also exercised on a two-row plot using a synthetic star and all 39,748 cached real WFI01 F158 tracking pairs reserialized into a minimal ASDF fixture with astropy timestamps. At initial packaging, the original downloaded ASDF files were no longer present at their previous locations. Direct checks on newly downloaded MAST files have since been completed; see the validation report below. No observation data or generated test figures are bundled.

### Recent MAST validation

See `validation/REPORT.md` for direct testing on newly downloaded September 22–23, 2026 MAST products, including acquisition-only files. Acquisition-only input is now handled explicitly; JSON `data_source` identifies the sequence measured.

Centroid panels use a fixed vertical range of −1 to +1 pixel relative to the median accepted detector position. Excursions outside this display range remain included in statistics and exported measurements.

## Science exposure shading

Supply optional calibrated images after `--cal` (paths or quoted globs):

```sh
python plot_guide_centroids.py '/data/*_gw.asdf' \
    --cal '/data/*_cal.asdf' -o centroids.png --summary centroids.json
```

Each right-hand panel shades matching science exposures in green, with dashed boundaries and labels giving the image filename and exact start/stop UTC times to millisecond precision. Intervals come from `roman.meta.exposure.start_time` and `end_time`. Only metadata is loaded; science pixel arrays and WCS models are not needed.

Association uses the Roman observation/visit prefix, detector, and filter from `meta.filename` (or the input basename if absent), plus overlap with the selected guide sequence. Acquisition and science exposure numbers need not be equal. Multiple exposures can be shaded in one row, and an exposure can appear in multiple overlapping guide rows. The x-axis expands when necessary to show full associated exposure intervals; the y-axis stays at ±1 pixel. Shading does not change centroid selection or statistics.

The inspected guide-window files provide guide collection `t_start`/`t_stop` and an `exposure_mapping` array, but no explicit science start/stop intervals. The script does not infer exact imaging boundaries from those fields. Without `--cal`, no science interval is shaded. Invalid calibrated metadata produces a CLI error; supplied images that match no overlapping guide row generate a warning. Standard Roman filenames are needed for association. JSON summaries include `science_intervals` with the source paths and timestamps.
