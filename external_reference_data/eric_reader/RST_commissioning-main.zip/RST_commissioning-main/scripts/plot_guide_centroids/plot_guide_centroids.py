#!/usr/bin/env python3
"""Plot one row of image and centroid diagnostics per Roman guide-window ASDF."""
from __future__ import annotations

import argparse
import glob
import json
import re
import sys
from pathlib import Path

import asdf
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def time_strings(values):
    """Accept ASDF-decoded astropy Times or ISO strings."""
    return np.asarray([getattr(v, "isot", str(v)) for v in values], dtype="datetime64[ms]")


def association_key(path):
    """Match Roman observation/visit, detector, and filter, not acquisition ID."""
    match = re.fullmatch(r"(r\d+)_\d+_(wfi\d+)_(\w+)_(?:cal|gw)\.asdf", Path(path).name, re.IGNORECASE)
    if match is None:
        raise ValueError(f"Cannot associate nonstandard Roman filename: {Path(path).name}")
    return tuple(value.lower() for value in match.groups())


def load_cal_intervals(paths):
    intervals = []
    for path in paths:
        # Only metadata is needed. Raw types avoid decoding unrelated WCS models
        # and permit metadata reads without Roman calibration extensions.
        with asdf.open(path, _force_raw_types=True) as handle:
            meta = handle["roman"]["meta"]
            exposure = meta["exposure"]
            start, stop = time_strings([exposure["start_time"], exposure["end_time"]])
            if np.isnat(start) or np.isnat(stop) or stop <= start:
                raise ValueError(f"Invalid science exposure interval: {path}")
            key = association_key(meta.get("filename", path.name))
        intervals.append(dict(file=str(path.resolve()), name=path.name, key=key,
                              start_utc=str(start), stop_utc=str(stop)))
    return intervals


def matching_intervals(guide_path, summary, intervals):
    if not intervals:
        return []
    key = association_key(summary.get("metadata_filename", guide_path.name))
    first = np.datetime64(summary["first_signal_utc"])
    last = np.datetime64(summary["last_signal_utc"])
    return [dict(item) for item in intervals
            if item["key"] == key and np.datetime64(item["start_utc"]) <= last
            and np.datetime64(item["stop_utc"]) >= first]


def shade_intervals(ax, summary, intervals):
    origin = np.datetime64(summary["first_signal_utc"])
    for index, interval in enumerate(intervals):
        start = float((np.datetime64(interval["start_utc"]) - origin) / np.timedelta64(1, "s"))
        stop = float((np.datetime64(interval["stop_utc"]) - origin) / np.timedelta64(1, "s"))
        ax.axvspan(start, stop, color="#22a884", alpha=.14, zorder=0)
        for boundary in [start, stop]:
            ax.axvline(boundary, color="#007d60", linestyle="--", linewidth=.8, zorder=1)
        left, right = ax.get_xlim()
        midpoint = (max(start, left) + min(stop, right)) / 2
        label = (interval["name"] + "\n" + interval["start_utc"].split("T")[-1]
                 + "–" + interval["stop_utc"].split("T")[-1] + " UTC")
        ax.text(midpoint, .03 + .12 * (index % 3), label, ha="center", va="bottom",
                transform=ax.get_xaxis_transform(), fontsize=6, color="#00634d",
                bbox=dict(facecolor="white", alpha=.8, edgecolor="none"), clip_on=True)


def measure_centroids(images, corners, reset, radius=4.0, min_snr=10.0):
    """Background-subtracted aperture centroids; coordinates are (x, y).

    S/N is a selection statistic based on border-pixel NMAD, not a propagated
    photometric uncertainty. Detector coordinates include the window origin.
    """
    n, height, width = images.shape
    yy, xx = np.indices((height, width))
    rim = (xx < 2) | (xx >= width - 2) | (yy < 2) | (yy >= height - 2)
    positions = np.full((n, 2), np.nan)
    flux = np.full(n, np.nan)
    snr = np.full(n, np.nan)
    for i, image in enumerate(images):
        if not np.isfinite(image).all():
            continue
        background = np.median(image[rim])
        signal = image - background
        py, px = np.unravel_index(np.argmax(signal), signal.shape)
        for _ in range(3):
            aperture = (xx - px)**2 + (yy - py)**2 < radius**2
            weights = np.where(aperture, signal, 0)
            total = weights.sum()
            if total <= 0 or not np.isfinite(total):
                break
            px = float((weights * xx).sum() / total)
            py = float((weights * yy).sum() / total)
        else:
            positions[i] = px, py
            flux[i] = total
            noise = 1.4826 * np.median(np.abs(signal[rim] - np.median(signal[rim])))
            snr[i] = total / max(noise * np.sqrt(aperture.sum()), 1.0)
    good = (~reset & np.isfinite(positions).all(axis=1) & (snr > min_snr)
            & (positions[:, 0] > 1) & (positions[:, 0] < width - 2)
            & (positions[:, 1] > 1) & (positions[:, 1] < height - 2))
    return positions, positions + corners, flux, snr, good


def load_file(path, radius, min_snr, allow_pseudo):
    with asdf.open(path) as handle:
        roman = handle["roman"]
        track = roman.get("track_data", {})
        source = "tracking"
        if "signal_resultants" not in track or len(track["signal_resultants"]) == 0:
            track = roman.get("acq_data", {})
            source = "acquisition"
        if "signal_resultants" not in track:
            raise ValueError("No tracking or acquisition images available")
        # Convert before subtracting: these arrays are normally unsigned integers.
        signal = np.asarray(track["signal_resultants"], dtype=float)
        pedestal = np.asarray(track["pedestal_resultants"], dtype=float)
        if signal.shape != pedestal.shape:
            raise ValueError("signal and pedestal shapes differ")
        images = signal - pedestal
        if images.ndim != 3 or not len(images) or min(images.shape[1:]) < 5:
            raise ValueError("tracking images must be a nonempty (N, height, width) cube")
        n = len(images)
        corners = np.asarray(track["lower_left_corners"], dtype=float)
        reset = np.asarray(track["reset_impacted_pairs"], dtype=bool)
        dates = time_strings(track["signal_times"])
        if corners.shape != (n, 2) or reset.shape != (n,) or dates.shape != (n,):
            raise ValueError("tracking images, times, corners, and reset flags have inconsistent shapes")
        if np.isnat(dates).any() or np.any(np.diff(dates) < np.timedelta64(0, "ms")):
            raise ValueError("tracking times are missing or not ordered")
        times = (dates - dates[0]) / np.timedelta64(1, "s")
        meta = roman.get("meta", {})
        guide = meta.get("guide_star", {})
        pseudo = str(guide.get("pseudo_star_flag", "")).upper() in {"Y", "YES", "TRUE", "1"}
        modes = str(meta.get("fgs_modes_used", "unspecified"))
        acq_image = None
        acq = roman.get("acq_data", {})
        if "signal_resultants" in acq and "pedestal_resultants" in acq:
            signal = np.asarray(acq["signal_resultants"])
            pedestal = np.asarray(acq["pedestal_resultants"])
            if signal.ndim == 3 and len(signal) and signal.shape == pedestal.shape:
                clean = ~np.asarray(acq.get("reset_impacted_pairs", np.ones(len(signal))), dtype=bool)
                if clean.shape == (len(signal),) and clean.any():
                    k = np.flatnonzero(clean)[-1]
                    acq_image = signal[k].astype(float) - pedestal[k].astype(float)
        pos, detector, flux, snr, good = measure_centroids(images, corners, reset, radius, min_snr)
        reason = ""
        if pseudo and not allow_pseudo:
            good[:] = False
            reason = "Pseudo-star: centroid interpretation disabled"
        elif not good.any():
            reason = "No reliable centroids pass the cuts"
        # Do not condition the displayed tracking image on passing centroid cuts.
        clean_images = images[~reset]
        median_image = np.nanmedian(clean_images, axis=0) if len(clean_images) else None
        offsets = np.full_like(detector, np.nan)
        std = nmad = None
        if good.any():
            offsets = detector - np.median(detector[good], axis=0)
            std = np.std(detector[good], axis=0).tolist()
            nmad = (1.4826 * np.median(np.abs(offsets[good]), axis=0)).tolist()
        summary = dict(file=str(path.resolve()), metadata_filename=str(meta.get("filename", path.name)), data_source=source, n_pairs=n, n_reset=int(reset.sum()),
                       n_usable=int(good.sum()), first_signal_utc=str(dates[0]),
                       last_signal_utc=str(dates[-1]), pseudo_star=pseudo, fgs_modes=modes,
                       std_xy_pixels=std, nmad_xy_pixels=nmad, status=reason or "ok")
        return dict(summary=summary, acquisition=acq_image, tracking=median_image,
                    times=times, positions=pos, detector=detector, flux=flux,
                    snr=snr, good=good, reset=reset, offsets=offsets)


def plot_image(ax, image, title):
    ax.set_title(title, fontsize=10)
    if image is None or not np.isfinite(image).any():
        ax.text(.5, .5, "No clean image available", ha="center", va="center", transform=ax.transAxes)
    else:
        lo, hi = np.nanpercentile(image, [5, 99.8])
        if hi <= lo:
            hi = lo + 1
        ax.imshow(image, origin="lower", cmap="magma", vmin=lo, vmax=hi)
    ax.set(xlabel="Window x (pixels)", ylabel="Window y (pixels)")


def expand_inputs(patterns):
    paths = []
    for pattern in patterns:
        pattern = str(Path(pattern).expanduser())
        matches = sorted(glob.glob(pattern)) if glob.has_magic(pattern) else [pattern]
        if not matches:
            raise ValueError(f"No files match: {pattern}")
        for match in matches:
            path = Path(match).expanduser()
            if not path.is_file():
                raise ValueError(f"Not a file: {path}")
            if path.resolve() not in [p.resolve() for p in paths]:
                paths.append(path)
    return paths


def build_parser():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("files", nargs="+", help="Guide-window ASDF paths or quoted glob patterns, in row order")
    parser.add_argument("-o", "--output", type=Path, default=Path("guide_centroids.png"), help="Output figure (.png, .pdf, or .svg)")
    parser.add_argument("--cal", nargs="+", action="extend", default=[], help="Optional calibrated ASDF images or globs for exact science-exposure shading")
    parser.add_argument("--radius", type=float, default=4.0, help="Centroid aperture radius in pixels")
    parser.add_argument("--min-snr", type=float, default=10.0, help="Minimum approximate aperture S/N")
    parser.add_argument("--skip-seconds", type=float, default=0.0, help="Exclude initial tracking seconds from plotted centroids and statistics")
    parser.add_argument("--allow-pseudo-star", action="store_true", help="Attempt centroids even if pseudo_star_flag is set; inspect images carefully")
    parser.add_argument("--summary", type=Path, help="Optional JSON statistics output")
    parser.add_argument("--measurements-dir", type=Path, help="Optional per-file CSV directory")
    parser.add_argument("--dpi", type=int, default=160, help="Raster output resolution")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if not np.isfinite(args.radius) or args.radius <= 0 or not np.isfinite(args.min_snr) or args.min_snr <= 0:
        parser.error("radius and min-snr must be finite and positive")
    if not np.isfinite(args.skip_seconds) or args.skip_seconds < 0 or args.dpi <= 0:
        parser.error("skip-seconds must be finite and nonnegative; dpi must be positive")
    if args.output.suffix.lower() not in {".png", ".pdf", ".svg"}:
        parser.error("output must have a .png, .pdf, or .svg extension")
    try:
        paths = expand_inputs(args.files)
        cal_paths = expand_inputs(args.cal)
        intervals = load_cal_intervals(cal_paths)
    except Exception as exc:
        parser.error(str(exc))
    outputs = [args.output] + ([args.summary] if args.summary else [])
    if args.measurements_dir:
        outputs += [args.measurements_dir / f"{i:03d}_{p.stem}.csv" for i, p in enumerate(paths, 1)]
    if len({p.resolve() for p in outputs}) != len(outputs) or any(p.resolve() in {q.resolve() for q in paths + cal_paths} for p in outputs):
        parser.error("output paths must be distinct and must not overwrite input files")
    fig, axes = plt.subplots(len(paths), 3, figsize=(15, 4.2 * len(paths)), squeeze=False,
                             gridspec_kw={"width_ratios": [1, 1, 2.3]}, layout="constrained")
    summaries = []
    failed = False
    matched_cal_files = set()
    for i, (path, row) in enumerate(zip(paths, axes), 1):
        print(f"[{i}/{len(paths)}] {path}", file=sys.stderr)
        try:
            data = load_file(path, args.radius, args.min_snr, args.allow_pseudo_star)
        except Exception as exc:
            failed = True
            message = f"{type(exc).__name__}: {exc}"
            print(f"ERROR: {path}: {message}", file=sys.stderr)
            summaries.append(dict(file=str(path.resolve()), status="error", error=message))
            for ax in row:
                ax.set_axis_off()
            row[1].text(.5, .5, f"{path.name}\nUnable to read guide window\n{message}", ha="center", va="center", wrap=True, transform=row[1].transAxes)
            continue
        summary = data["summary"]
        good = data["good"] & (data["times"] >= args.skip_seconds)
        data["good"] = good
        summary["n_usable"] = int(good.sum())
        summary["skip_seconds"] = args.skip_seconds
        summary["radius_pixels"] = args.radius
        summary["min_snr"] = args.min_snr
        if good.any():
            data["offsets"] = data["detector"] - np.median(data["detector"][good], axis=0)
            summary["std_xy_pixels"] = np.std(data["detector"][good], axis=0).tolist()
            summary["nmad_xy_pixels"] = (1.4826 * np.median(abs(data["offsets"][good]), axis=0)).tolist()
        else:
            summary["std_xy_pixels"] = summary["nmad_xy_pixels"] = None
            if summary["status"] == "ok":
                summary["status"] = "No usable centroids after time selection"
        summaries.append(summary)
        plot_image(row[0], data["acquisition"], "Last clean acquisition pair")
        plot_image(row[1], data["tracking"], f"Median {summary['data_source']} image (no reset pairs)")
        ax = row[2]
        ax.set_title(path.name + ("\nAcquisition only — no tracking data" if summary["data_source"] == "acquisition" else ""), fontsize=9, wrap=True)
        if good.any():
            for dim, label in enumerate(["x", "y"]):
                ax.plot(data["times"][good], data["offsets"][good, dim], ".", ms=2, label=label, rasterized=True)
            ax.legend(loc="upper right")
            sx, sy = summary["nmad_xy_pixels"]
            label = f"{good.sum():,}/{summary['n_pairs']:,} usable; NMAD x/y = {sx:.3f}/{sy:.3f} px"
            if summary["pseudo_star"]:
                label += "\nWARNING: pseudo-star override"
            ax.text(.02, .97, label, transform=ax.transAxes, va="top", fontsize=8)
        else:
            ax.text(.5, .5, summary["status"], ha="center", va="center", wrap=True, transform=ax.transAxes)
        ax.set(xlabel=f"Seconds after {summary['first_signal_utc']} UTC", ylabel="Detector position − median (pixels)")
        ax.set_xlim(0, max(float(data["times"][-1]), 1.0))
        ax.set_ylim(-1, 1)
        try:
            associated = matching_intervals(path, summary, intervals)
        except ValueError as exc:
            print(f"WARNING: {exc}; no exposure shading for this row", file=sys.stderr)
            associated = []
        summary["science_intervals"] = associated
        matched_cal_files.update(item["file"] for item in associated)
        if associated:
            origin = np.datetime64(summary["first_signal_utc"])
            starts = [float((np.datetime64(v["start_utc"]) - origin) / np.timedelta64(1, "s")) for v in associated]
            stops = [float((np.datetime64(v["stop_utc"]) - origin) / np.timedelta64(1, "s")) for v in associated]
            ax.set_xlim(min(0.0, *starts), max(float(data["times"][-1]), *stops, 1.0))
        shade_intervals(ax, summary, associated)
        ax.grid(alpha=.2)
        if args.measurements_dir:
            args.measurements_dir.mkdir(parents=True, exist_ok=True)
            table = np.column_stack([data["times"], good, data["reset"], data["positions"], data["detector"], data["flux"], data["snr"]])
            np.savetxt(args.measurements_dir / f"{i:03d}_{path.stem}.csv", table, delimiter=",",
                       header="time_s,usable,reset_impacted,window_x,window_y,detector_x,detector_y,aperture_dn,approx_snr", comments="")
    for item in intervals:
        if item["file"] not in matched_cal_files:
            print(f"WARNING: No matching guide-window row overlaps {item['name']}", file=sys.stderr)
    fig.suptitle("Roman guide-window diagnostics — signal minus pedestal; reset-impacted pairs excluded", fontsize=12)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output, dpi=args.dpi)
    plt.close(fig)
    if args.summary:
        args.summary.parent.mkdir(parents=True, exist_ok=True)
        args.summary.write_text(json.dumps(summaries, indent=2, allow_nan=False) + "\n")
    print(f"Saved {args.output}", file=sys.stderr)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
