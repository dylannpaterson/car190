"""Run with python -m unittest discover -v from this directory."""
import json
import tempfile
import unittest
from pathlib import Path

import asdf
import numpy as np
from plot_guide_centroids import load_file, main, measure_centroids


class CentroidTests(unittest.TestCase):
    def make_file(self, path, pseudo=False):
        yy, xx = np.indices((16, 16))
        image = 100 * np.exp(-((xx - 7.2)**2 + (yy - 8.1)**2) / 2)
        signal = np.stack([image + 990] * 4).astype('uint16')
        track = dict(signal_resultants=signal, pedestal_resultants=np.full_like(signal, 1000),
                     lower_left_corners=np.array([[100, 200]] * 4),
                     reset_impacted_pairs=np.array([False, True, False, False]),
                     signal_times=[f"2026-09-21T01:00:0{i}.000" for i in range(4)])
        with asdf.AsdfFile(dict(roman=dict(track_data=track, meta=dict(guide_star=dict(pseudo_star_flag='Y' if pseudo else 'N'))))) as f:
            f.write_to(path)

    def test_window_relocation_and_reset(self):
        yy, xx = np.indices((16, 16))
        images = np.array([100 * np.exp(-((xx-x)**2+(yy-7.3)**2)/2) - 5 for x in [8.2, 7.2, 8.2]])
        corners = np.array([[100, 200], [101, 200], [100, 200]])
        pos, det, flux, snr, good = measure_centroids(images, corners, np.array([False, False, True]))
        self.assertEqual(good.tolist(), [True, True, False])
        np.testing.assert_allclose(det[0], det[1], atol=.01)
        np.testing.assert_allclose(pos[0], [8.2, 7.3], atol=.02)

    def test_unsigned_subtraction_and_pseudo_star(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)/'guide.asdf'; self.make_file(p, pseudo=True)
            data = load_file(p, 4, 10, False)
            self.assertLess(data['tracking'][0, 0], 0)
            self.assertFalse(data['good'].any())
            self.assertEqual(data['summary']['n_reset'], 1)
            self.assertTrue(load_file(p, 4, 10, True)['good'].any())

    def test_multiple_rows_and_invalid_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp); self.make_file(p/'good.asdf'); (p/'bad.asdf').write_text('invalid')
            status = main([str(p/'good.asdf'), str(p/'bad.asdf'), '-o', str(p/'rows.png'), '--summary', str(p/'stats.json')])
            self.assertEqual(status, 1)
            summary = json.loads((p/'stats.json').read_text())
            self.assertEqual(len(summary), 2)
            self.assertEqual(summary[0]['n_usable'], 3)
            self.assertEqual(summary[1]['status'], 'error')
            self.assertGreater((p/'rows.png').stat().st_size, 1000)

    def test_acquisition_only_fallback(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)/"guide.asdf"; self.make_file(p)
            with asdf.open(p, mode="rw") as f:
                f["roman"]["acq_data"] = f["roman"]["track_data"]
                f["roman"]["track_data"] = {}
                f.update()
            data = load_file(p, 4, 10, False)
            self.assertEqual(data["summary"]["data_source"], "acquisition")
            self.assertEqual(data["summary"]["n_usable"], 3)
            self.assertIsNotNone(data["acquisition"])

    def test_skip_all_returns_null_statistics(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp); self.make_file(p/'guide.asdf')
            self.assertEqual(main([str(p/'guide.asdf'), '--skip-seconds', '10', '-o', str(p/'rows.png'), '--summary', str(p/'stats.json')]), 0)
            summary = json.loads((p/'stats.json').read_text())[0]
            self.assertEqual(summary['n_usable'], 0)
            self.assertIsNone(summary['std_xy_pixels'])


if __name__ == '__main__':
    unittest.main()
