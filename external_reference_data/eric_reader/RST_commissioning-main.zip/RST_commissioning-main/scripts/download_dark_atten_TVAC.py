"""
Download data from TVAC1 to demonstrate commissioning activity 
Run as RST_commissioning$ python -m scripts.download_dark_atten_TVAC
"""
from rst_commissioning import CASSI_query as cq
from rst_commissioning import parallel_CASSI_download as pcd

get_sca1_init = False
get_activity2_init = False
get_sca1_ramp = False
get_activity2_ramp = False
get_sca10_ramp = True
get_sca07_ramp = True

if get_sca1_init:
    conditions = {"test_script": "OTP00620_InitDarks*", "detector": "WFI01"}
    select_columns = []
    
    df = cq.query_cassi_api(select_columns, conditions, epoch="TVAC1")
    print(df)
    
    urls = df['url'].tolist()
    results_df, downloaded, failed = pcd.parallel_download_cassi_files(
        urls,
        output_dir='./data/TVAC1/NOM_OPS/OTP00620_InitDarks_TV1a_R1/',
        max_workers=10
    )

if get_activity2_init:
    conditions = {"test_script": "OTP00620_InitDarks*", "activity_number": "2"}
    select_columns = []
    
    df = cq.query_cassi_api(select_columns, conditions, epoch="TVAC1")
    print(df)
    
    urls = df['url'].tolist()
    results_df, downloaded, failed = pcd.parallel_download_cassi_files(
        urls,
        output_dir='./data/TVAC1/NOM_OPS/OTP00620_InitDarks_TV1a_R1/',
        max_workers=10
    )

if get_sca1_ramp:
    conditions = {"test_script": "OTP00620_Ramp*", "detector": "WFI01"}
    select_columns = []
    
    df = cq.query_cassi_api(select_columns, conditions, epoch="TVAC1")
    print(df)
    
    urls = df['url'].tolist()
    results_df, downloaded, failed = pcd.parallel_download_cassi_files(
        urls,
        output_dir='./data/TVAC1/NOM_OPS/OTP00620_Ramp_TV1a_R1/',
        max_workers=10
    )

if get_activity2_ramp:
    conditions = {"test_script": "OTP00620_Ramp*", "activity_number": "2"}
    select_columns = []
    
    df = cq.query_cassi_api(select_columns, conditions, epoch="TVAC1")
    print(df)
    
    urls = df['url'].tolist()
    results_df, downloaded, failed = pcd.parallel_download_cassi_files(
        urls,
        output_dir='./data/TVAC1/NOM_OPS/OTP00620_Ramp_TV1a_R1/',
        max_workers=10
    )

if get_sca10_ramp:
    conditions = {"test_script": "OTP00620_Ramp*", "detector": "WFI10"}
    select_columns = []
    
    df = cq.query_cassi_api(select_columns, conditions, epoch="TVAC1")
    print(df)
    
    urls = df['url'].tolist()
    results_df, downloaded, failed = pcd.parallel_download_cassi_files(
        urls,
        output_dir='./data/TVAC1/NOM_OPS/OTP00620_Ramp_TV1a_R1/',
        max_workers=10
    )

if get_sca07_ramp:
    conditions = {"test_script": "OTP00620_Ramp*", "detector": "WFI07"}
    select_columns = []
    
    df = cq.query_cassi_api(select_columns, conditions, epoch="TVAC1")
    print(df)
    
    urls = df['url'].tolist()
    results_df, downloaded, failed = pcd.parallel_download_cassi_files(
        urls,
        output_dir='./data/TVAC1/NOM_OPS/OTP00620_Ramp_TV1a_R1/',
        max_workers=10
    )