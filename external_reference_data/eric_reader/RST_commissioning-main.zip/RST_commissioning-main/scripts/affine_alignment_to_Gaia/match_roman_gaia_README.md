# Roman–Gaia detector matching

`match_roman_gaia.py` is a standalone script: it does not require the earlier
2MASS scripts. It detects compact stars, propagates Gaia DR3 proper motions to
the exposure start time, and matches the catalog to each detector using
translation voting and robust full affine fits. Output positions are 1-based;
offsets are measured positions minus nominal WCS predictions. Input images and
WCS objects are not modified on disk. Parallax is not modeled.

## Environment and usage

Use Python 3.10 or newer with NumPy, SciPy, Astropy, ASDF, GWCS, Photutils,
Matplotlib, Astroquery, and `roman_datamodels` (including compatible Roman/ASDF
schema extensions). The Roman schema packages must support the input files.
An existing STScI/Roman environment is appropriate. For a new environment:

```sh
python -m pip install numpy scipy astropy asdf gwcs photutils matplotlib astroquery roman_datamodels
python match_roman_gaia.py /path/to/Roman --output-dir gaia_results
python match_roman_gaia.py /path/to/Roman --output-dir gaia_results --resume
python match_roman_gaia.py --help
```

The CLI reads `*_cal.asdf` files. Supply **one image per detector**; duplicate
detector IDs are rejected before queries or output creation. Image dimensions
and affine centers come from each image, including rectangular images. Plot
panels adapt to the detector count. `--detector WFI01` processes one detector;
`--catalog-only` downloads or validates the shared catalog. Internet access is
needed when the catalog cache is absent or invalid. An offline run can reuse a
valid catalog cache. Matplotlib uses the noninteractive Agg backend and its
normal cache location; set `MPLCONFIGDIR` externally if needed.

## Adjustable assumptions

`--help` lists every option, its units, and its default. Defaults retain the
previous 4088-pixel detector matching settings. Common options include:

| Options | Purpose / defaults |
| --- | --- |
| `--g-limit`, `--ruwe-limit` | Gaia selection: G < 20, RUWE < 1.4; require proper motions |
| `--field-padding` | Catalog cone extends 0.16 degrees beyond the most distant detector center |
| `--detector-radius` | Select Gaia sources within 0.18 degrees of each nominal detector center |
| `--fwhm`, `--detection-sigma` | Detection FWHM 3.5 pixels; threshold 8 robust MAD noise units |
| `--background-sigma`, `--edge-margin`, `--max-stars` | Background smoothing 20 pixels; border 15 pixels; at most 5000 initial detections |
| `--translation-limit`, `--vote-bin`, `--coarse-vote-bin` | Blind shifts up to ±2500 pixels; voting bins 4 and 20 pixels |
| `--seed-window` | Search within ±400 pixels of a seed from earlier secure detectors |
| `--min-fit-matches`, `--min-matches` | At least 15 pairs to refine; at least 100 accepted matches |
| `--match-radius`, `--max-median-residual` | Final association radius 1.5 pixels; median residual at most 0.6 pixels |
| `--affine-loss-scale`, `--max-affine-deviation` | Robust loss scale 0.3 pixels; linear matrix elements within 0.02 of identity |
| `--clip-sigma`, `--clip-floor`, `--clip-iterations` | Clip at 4 MAD sigmas, with a 0.25-pixel floor, for 6 iterations |
| `--sip-error` | Requested forward/inverse GWCS-to-FITS-SIP accuracy: 0.01 pixels |
| `--vector-bins` | 8 spatial vector bins along each detector axis |

Voting subset sizes, candidate counts, nominal-pixel padding, and affine
conditioning scale are also configurable. Changing the translation range does
not automatically enlarge the sky query; adjust sky radii and nominal-pixel
padding together for larger pointing uncertainties. The sky query covers
nominal centers plus the explicit angular padding, not automatically every
possible shifted footprint. Default centroid refinement still uses a 5-pixel
positive-flux aperture, a 6–7.5-pixel local sky region in a 15×15 cutout, and
4-pixel duplicate suppression. The initial matching-radius schedule and
translation-peak smoothing remain fixed algorithm choices. This method is
intended for compact stars and modest affine departures from the nominal WCS.

## Cache provenance and outputs

- The Gaia manifest (`gaia_catalog_cache.json`) records the exact ADQL query,
  service, job ID, row count, and SHA-256 digest of the saved catalog. A changed
  sky region, magnitude/RUWE cut, missing file, or changed contents forces a
  new query. Async query completion is required before saving a catalog.
- Detection manifests (`WFIxx_stars_cache.json`) record the input's absolute
  path and content digest, all settings, script content digest, dependency
  versions, and detection-table digest.
- Detector summaries record that provenance plus the catalog identity and
  available cross-detector seed. `--resume` verifies the detection table,
  match table, and overlay image against their stored digests before reuse.
  A timestamp alone or an unchanged catalog row count is insufficient.
- Legacy caches without these manifests are rebuilt. This adds file-reading
  overhead on resume, because hashes cover complete inputs. Changing any
  setting or the script also invalidates detector caches conservatively.

Per-detector outputs include star and match ECSV tables, an overlay PNG, and a
JSON summary with residuals and affine coefficients. Aggregate outputs contain
detector-center offsets and spatial vector plots (PNG/PDF), plus `errors.json`.

The affine coefficient convention is
`observed = nominal + [(nominal - center) / normalization, 1] @ coefficients`
for row-vector pixel coordinates. Each summary records `affine_center_xy` and
`affine_normalization`; readers should use these rather than assume 2044.5 and
2000 for every image. `dx_center`/`dy_center` evaluate the offset at the observed
detector center; `offset_at_nominal_center` evaluates it at the nominal center.

## Checks

Run the offline regression checks with:

```sh
python -m unittest -v test_match_roman_gaia.py
```

They cover content-based cache invalidation, changed catalog queries, missing
products, duplicate detector rejection, option validation, and recovery of a
known affine transformation on a rectangular detector with missing sources and
unrelated detections. They do not require a live Gaia service.

## Bright-star image overlays

Each run also writes `WFIxx_bright_gaia.png` and `.pdf`: an `imshow` view with
up to 25 of the brightest available Gaia sources whose **affine-predicted
positions** fall within the detector, sorted by increasing G and labeled to
two decimals. Positions include Gaia proper-motion propagation and the fitted
full affine transform. Saturated stars and sources absent from the accepted
match list are eligible; no detection, image-DQ, or saturation cut is applied
to this selection. The input Gaia catalog's magnitude, RUWE, and proper-motion
requirements and the configured projection footprint still apply.

Change the count with `--label-stars` (default 25). Display pixels are 4×4
averages with an asinh stretch; axes retain original 1-based pixel coordinates.
`WFIxx_bright_gaia.ecsv` records the selected source IDs, magnitudes, and
`x_affine`/`y_affine` positions. These plots and tables are included in detector
cache product checks.

## Save an image with its aligned WCS

Add `--apply-alignment` to write `<input_stem>_gaia_aligned.asdf` in
`--output-dir` after a successful match. The positional input may also be a
single calibrated ASDF file:

```sh
python match_roman_gaia.py /path/to/image_cal.asdf --output-dir gaia_results --apply-alignment
```

The original file is preserved. Science, error, and DQ arrays are not shifted
or resampled. The inverse fitted affine map is composed before the native
GWCS, preserving the original distortion and correctly converting between
1-based fit coordinates and 0-based GWCS coordinates. The footprint
`meta.wcsinfo.s_region` and filename are updated; the ASDF history records the
correction. The original pointing/reference metadata remain the parameters
of the original transform within the composed WCS. Alignment accuracy remains
subject to the FITS-SIP approximation used for matching (`--sip-error`).
Use compatible Roman/ASDF schema packages when writing these products.

The corrected image is included in the detector summary and hashed for
`--resume`. Changing the flag invalidates the detector cache. Re-running can
replace the generated aligned copy, but cannot overwrite the input. A failed
fit does not produce a new aligned image.
