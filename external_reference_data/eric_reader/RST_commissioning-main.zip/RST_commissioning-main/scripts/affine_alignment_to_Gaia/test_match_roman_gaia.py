"""Offline regression checks for the public Roman/Gaia matching script."""
import copy
from dataclasses import replace
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import numpy as np
from astropy.table import Table
import astropy.units as u
from astropy.time import Time
import match_roman_gaia as m


class CacheTests(unittest.TestCase):
    def test_content_settings_and_missing_products(self):
        with tempfile.TemporaryDirectory() as folder:
            out=Path(folder);p=out/'source';p.write_text('aaaa')
            provenance={'input':m.file_hash(p),'settings':{'fwhm':3.5}}
            manifest={'provenance':copy.deepcopy(provenance),'products':{'source':m.file_hash(p)}}
            self.assertTrue(m.cache_valid(manifest,provenance,out,['source']))
            changed=copy.deepcopy(provenance);changed['settings']['fwhm']=4
            self.assertFalse(m.cache_valid(manifest,changed,out,['source']))
            p.write_text('bbbb')  # Same length, different content.
            self.assertFalse(m.cache_valid(manifest,provenance,out,['source']))
            p.unlink()
            self.assertFalse(m.cache_valid(manifest,provenance,out,['source']))
            self.assertFalse(m.cache_valid({},provenance,out,['source']))

    def test_query_cache_invalidation(self):
        calls=[]
        class Gaia:
            @staticmethod
            def launch_job_async(query):
                calls.append(query)
                return SimpleNamespace(get_phase=lambda:'COMPLETED',jobid='offline-test',
                                       get_results=lambda:Table({'source_id':[1,2]}))
        with tempfile.TemporaryDirectory() as folder,patch.dict('sys.modules',{'astroquery.gaia':SimpleNamespace(Gaia=Gaia)}):
            out=Path(folder);field={'ra':80.,'dec':-69.,'radius':.5}
            m.catalog(out,field);m.catalog(out,field)
            self.assertEqual(len(calls),1)
            field['ra']=81.;m.catalog(out,field)
            self.assertEqual(len(calls),2)
            changed=replace(m.DEFAULTS,g_limit=19.)
            m.catalog(out,field,changed)
            self.assertEqual(len(calls),3)
            changed=replace(changed,ruwe_limit=1.2)
            m.catalog(out,field,changed)
            self.assertEqual(len(calls),4)
            # Equal row counts must not hide altered catalog contents.
            Table({'source_id':[3,4]}).write(out/'gaia_dr3_complete.ecsv',overwrite=True)
            m.catalog(out,field,changed)
            self.assertEqual(len(calls),5)


class GeometryTests(unittest.TestCase):
    def test_rectangular_affine_match_with_incomplete_catalog(self):
        rng=np.random.default_rng(8);shape=(1000,1800)
        pred=rng.uniform([200,150],[1400,750],size=(260,2))
        center=(np.array(shape[::-1])+1)/2
        co=np.array([[6.,-4.],[3.,5.],[80.,-55.]])
        obs=m.transform(pred[:210],co,center)+rng.normal(0,.03,(210,2))
        obs=np.vstack([obs,rng.uniform([0,0],shape[::-1],size=(40,2))])
        settings=replace(m.DEFAULTS,translation_limit=200.,max_candidates=10)
        ci,di,fit,_=m.match(pred,obs,shape=shape,settings=settings)
        self.assertGreaterEqual(len(ci),205)
        self.assertTrue(np.all(ci==di))
        error=np.linalg.norm(m.transform(pred,fit,center)-m.transform(pred,co,center),axis=1)
        self.assertLess(np.max(error),.02)

    def test_duplicate_detectors_rejected(self):
        class FakeASDF:
            def __enter__(self):
                return {'roman':{'data':np.zeros((50,90)), 'meta':{
                    'wcs':lambda x,y:(80.,-69.),'instrument':{'detector':'WFI01'},
                    'exposure':{'start_time':Time('2026-09-15')}}}}
            def __exit__(self,*args):pass
        with patch.object(m.asdf,'open',return_value=FakeASDF()):
            with self.assertRaisesRegex(ValueError,'Multiple inputs'):
                m.field_metadata([Path('first.asdf'),Path('second.asdf')])
            field=m.field_metadata([Path('first.asdf')])
            self.assertEqual(field['detectors'][0]['shape'],[50,90])
            self.assertAlmostEqual(field['ra'],80.)

    def test_bright_labels_use_affine_positions_without_detections(self):
        # No measured x/y columns: even sources outside the nominal image
        # become eligible if their transformed positions are on the detector.
        catalog=Table({'source_id':np.arange(31),'phot_g_mean_mag':np.arange(31)+5.})
        nominal=np.column_stack([np.arange(31)-10.,np.full(31,40.)])
        nominal[0,0]=-100.  # Brightest source remains outside after transform.
        coefficients=np.array([[0.,0.],[0.,0.],[20.,10.]])
        with tempfile.TemporaryDirectory() as folder:
            out=Path(folder)
            selected=m.plot_bright_gaia(np.ones((100,100)),catalog,nominal,coefficients,'TEST',out)
            np.testing.assert_array_equal(selected,np.arange(1,26))
            labels=Table.read(out/'TEST_bright_gaia.ecsv')
            np.testing.assert_allclose(labels['x_affine'],nominal[selected,0]+20)
            np.testing.assert_allclose(labels['y_affine'],50)

    def test_options_and_validation(self):
        args=m.build_parser().parse_args(['images','--fwhm','4.5','--min-matches','50'])
        self.assertEqual(args.fwhm,4.5);self.assertEqual(args.min_matches,50)
        for kw in [{'fwhm':0},{'min_matches':2},{'edge_margin':3},{'vote_bin':np.nan}]:
            with self.assertRaises(ValueError):replace(m.DEFAULTS,**kw).validate()
        m.DEFAULTS.validate()


class AlignedWCSTests(unittest.TestCase):
    def test_affine_direction_origin_inverse_and_asdf_roundtrip(self):
        from gwcs import WCS
        from gwcs.coordinate_frames import Frame2D
        from astropy.modeling.models import AffineTransformation2D
        import asdf
        shape=(100,180)
        original=WCS(AffineTransformation2D(matrix=[[.01,.001],[-.002,.02]],
                     translation=[80.,-30.]),input_frame=Frame2D(name='detector'),
                     output_frame=Frame2D(name='world'))
        original.bounding_box=((-0.5,179.5),(-0.5,99.5))
        nominal=np.array([[1.,1.],[90.5,50.5],[160.,85.]])
        for co in (np.zeros((3,2)),np.array([[0.,0.],[0.,0.],[5.,-3.]]),
                   np.array([[6.,-4.],[3.,5.],[5.,-3.]])):
            settings=replace(m.DEFAULTS,affine_normalization=300.)
            observed=m.transform(nominal,co,(np.array(shape[::-1])+1)/2,settings)
            corrected=m.aligned_gwcs(original,co,shape,settings)
            expected=original(*(nominal-1).T,with_bounding_box=False)
            np.testing.assert_allclose(corrected(*(observed-1).T,with_bounding_box=False),expected,atol=1e-12)
            np.testing.assert_allclose(np.array(corrected.invert(*expected,with_bounding_box=False)).T,observed-1,atol=1e-10)
            with tempfile.TemporaryDirectory() as folder:
                source=Path(folder)/'input.asdf';dest=Path(folder)/'aligned.asdf'
                data=np.arange(18000,dtype='f4').reshape(shape)
                tree={'roman':{'data':data,'dq':np.zeros(shape,dtype='u4'),
                              'err':np.ones(shape,dtype='f4'),
                              'meta':{'wcs':original,'filename':source.name,'wcsinfo':{}}}}
                asdf.AsdfFile(tree).write_to(source)
                digest=m.file_hash(source)
                m.save_aligned_image(source,dest,co,settings)
                self.assertEqual(m.file_hash(source),digest)
                with asdf.open(dest) as f:
                    np.testing.assert_array_equal(f['roman']['data'],data)
                    np.testing.assert_array_equal(f['roman']['dq'],tree['roman']['dq'])
                    np.testing.assert_array_equal(f['roman']['err'],tree['roman']['err'])
                    self.assertEqual(f['roman']['meta']['filename'],dest.name)
                    np.testing.assert_allclose(f['roman']['meta']['wcs'](*(observed-1).T,with_bounding_box=False),expected,atol=1e-12)
                with self.assertRaisesRegex(ValueError,'overwrite'):
                    m.save_aligned_image(source,source,co,settings)
        self.assertFalse(m.build_parser().parse_args(['image.asdf']).apply_alignment)
        self.assertTrue(m.build_parser().parse_args(['image.asdf','--apply-alignment']).apply_alignment)
        self.assertIn('input_gaia_aligned.asdf',m.detector_products('WFI14',Path('input.asdf')))


if __name__=='__main__':unittest.main()
