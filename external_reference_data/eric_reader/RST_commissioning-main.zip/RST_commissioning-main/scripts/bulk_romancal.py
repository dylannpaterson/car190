#!/usr/bin/env python
"""
Command-line script to process exposure files.

Usage:
    python -m scripts.bulk_romancal /path/to/data --serial
    python -m scripts.bulk_romancal /path/to/data --parallel --workers 8
"""
import argparse
import sys
from pathlib import Path
from rst_commissioning import parallel_romancal as pr


def main():
    parser = argparse.ArgumentParser(
        description="Process uncalibrated ASDF exposure files to calibrated versions",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Process serially (for debugging)
  python process_exposures.py /path/to/data --serial
  
  # Process in parallel with default workers
  python process_exposures.py /path/to/data --parallel
  
  # Process in parallel with specific worker count
  python process_exposures.py /path/to/data --parallel --workers 8
  
  # Use custom pattern
  python process_exposures.py /path/to/data --pattern "*_uncal*.asdf"
        """
    )
    
    parser.add_argument(
        'input_dir',
        type=str,
        help='Directory containing *_uncal.asdf files to process'
    )
    
    parser.add_argument(
        '--serial',
        action='store_true',
        help='Run in serial mode (for debugging, default if --parallel not specified)'
    )
    
    parser.add_argument(
        '--parallel',
        action='store_true',
        help='Run in parallel mode'
    )
    
    parser.add_argument(
        '--workers',
        type=int,
        default=None,
        help='Number of parallel workers (default: CPU count). Only used with --parallel'
    )
    
    parser.add_argument(
        '--pattern',
        type=str,
        default='*_uncal.asdf',
        help='Glob pattern for finding files (default: *_uncal.asdf)'
    )
    
    parser.add_argument(
        '--save-results',
        action='store_true',
        default=True,
        help='Save results to disk'
    )
    
    args = parser.parse_args()
    
    # Validate input directory
    input_path = Path(args.input_dir)
    if not input_path.exists():
        print(f"ERROR: Directory does not exist: {args.input_dir}", file=sys.stderr)
        sys.exit(1)
    
    if not input_path.is_dir():
        print(f"ERROR: Path is not a directory: {args.input_dir}", file=sys.stderr)
        sys.exit(1)
    
    # Configure pipeline kwargs
    pipe_kwargs = {
        #"save_results": args.save_results,
        "steps": {
            "dark_current": {"skip": False},
            "linearity": {"skip": False},
            "rampfit": {"skip": False, "save_results": False},
            "assign_wcs": {"skip": False, "save_results": True},
            "flatfield": {"skip": True},
            "photom": {"skip": True},
            "source_catalog": {"skip": True},
            "tweakreg": {"skip": True},
        },
    }
    
    # Determine mode
    if args.parallel:
        mode = "PARALLEL"
    else:
        mode = "SERIAL"
    
    print("=" * 70)
    print(f"EXPOSURE PROCESSING - {mode} MODE")
    print("=" * 70)
    print(f"Input directory: {input_path.absolute()}")
    print(f"Pattern: {args.pattern}")
    print(f"Save results: {args.save_results}")
    if args.parallel:
        print(f"Workers: {args.workers or 'CPU count'}")
    print("=" * 70)
    print()
    
    # Run processing
    try:
        if args.parallel:
            results = pr.process_directory_parallel(
                args.input_dir,
                pipe_kwargs,
                pattern=args.pattern,
                max_workers=args.workers
            )
        else:
            results = pr.process_directory_serial(
                args.input_dir,
                pipe_kwargs,
                pattern=args.pattern
            )
        
        # Exit with error code if any files failed
        if results:
            failed_count = sum(1 for _, success, _ in results if not success)
            if failed_count > 0:
                print(f"\nExiting with error code due to {failed_count} failed file(s)")
                sys.exit(1)
        
    except KeyboardInterrupt:
        print("\n\nProcessing interrupted by user", file=sys.stderr)
        sys.exit(130)
    except Exception as e:
        print(f"\n\nFATAL ERROR: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()