"""Small scientific-regression checks; no downloaded data required."""
from pathlib import Path
import unittest
import numpy as np
from guide_centroid_animation import measure, product_key, synchronize


class CentroidChecks(unittest.TestCase):
    def test_window_origin_and_reset(self):
        yy, xx = np.indices((16,16))
        # Same full-detector star, with the second window shifted by one pixel.
        images = np.array([1000*np.exp(-((xx-x)**2+(yy-7.5)**2)/2)+100 for x in [7.5,6.5,7.5]])
        centers, _ = measure(images,np.array([[100,200],[101,200],[100,200]]),np.array([False,False,True]))
        np.testing.assert_allclose(centers[:2],[[107.5,207.5],[107.5,207.5]],atol=.01)
        self.assertTrue(np.isnan(centers[2]).all())

    def test_blank_rejected(self):
        centers, _ = measure(np.ones((1,16,16)),np.zeros((1,2)),np.array([False]))
        self.assertTrue(np.isnan(centers).all())

    def test_missing_and_invalid_samples_not_interpolated(self):
        actual = synchronize(np.array([0.,1.,2.,5.]),np.array([[1,2],[np.nan,np.nan],[3,4],[5,6]]),np.array([0.,1.,3.5,5.]),.75)
        np.testing.assert_allclose(actual[[0,3]],[[1,2],[5,6]])
        self.assertTrue(np.isnan(actual[1:3]).all())

    def test_product_pairing(self):
        self.assertEqual(product_key(Path('r0108303005001002006_3_wfi02_f062_gw.asdf')),product_key(Path('r0108303005001002006_0003_wfi02_f062_wcs.asdf')))
        with self.assertRaises(ValueError):
            product_key(Path('unknown.asdf'))


if __name__ == '__main__':
    unittest.main()
