#!/usr/bin/env python3
"""Animate median-subtracted Roman guide-star centroids. See README.md."""
import argparse
import glob
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

import asdf
from astropy.coordinates import SkyCoord
from astropy.time import Time
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

COLORS = ['#66c2ff', '#ff9666', '#7be09b', '#d19aff', '#ffde72', '#ff79a9',
          '#59ded2', '#b9bfef', '#d2d66b', '#c79b7d', '#ececec', '#719cff',
          '#f2b6db', '#a9e6bd', '#e9ba67', '#ab8cff', '#64b29f', '#de6e63']
MARKERS = ['o', 's', '^', 'D', 'v', 'P', 'X', '<', '>', 'h', '*', 'p', 'd', '8', 'H', 'o', 's', '^']


def paths(patterns):
    result = []
    for pattern in patterns:
        matches = sorted(glob.glob(pattern))
        if not matches:
            raise ValueError(f'No files match: {pattern}')
        result.extend(Path(p).resolve() for p in matches)
    return list(dict.fromkeys(result))


def product_key(path):
    """Normalize acquisition indices (GW 3 versus WCS 0003)."""
    match = re.fullmatch(r'(r\d+)_(\d+)_(wfi\d{2})_([^_]+)_(gw|wcs)\.asdf', path.name, re.I)
    if not match:
        raise ValueError(f'Unsupported Roman product name: {path.name}')
    visit, exposure, detector, band, _ = match.groups()
    if not 1 <= int(detector[3:]) <= 18:
        raise ValueError(f'Invalid WFI detector: {detector}')
    return visit.lower(), int(exposure), detector.upper(), band.upper()


def measure(images, corners, reset, radius=4., min_snr=10.):
    """Iterated signed-flux centroids, with per-frame border sky subtraction."""
    n, h, w = images.shape
    if min(h, w) < 6 or corners.shape != (n, 2) or reset.shape != (n,):
        raise ValueError('Invalid guide-window, corner, or reset array shape')
    yy, xx = np.indices((h, w))
    rim = (xx < 2) | (xx >= w-2) | (yy < 2) | (yy >= h-2)
    positions = np.full((n, 2), np.nan)
    snr = np.full(n, np.nan)
    for i, image in enumerate(images):
        if reset[i] or not np.isfinite(image).all() or not np.isfinite(corners[i]).all():
            continue
        image = image - np.median(image[rim])
        cy, cx = np.unravel_index(np.argmax(image), image.shape)
        for _ in range(3):
            aperture = (xx-cx)**2 + (yy-cy)**2 < radius**2
            flux = np.where(aperture, image, 0)
            total = flux.sum()
            if total <= 0:
                break
            cx, cy = (flux*xx).sum()/total, (flux*yy).sum()/total
        else:
            noise = 1.4826*np.median(abs(image[rim]-np.median(image[rim])))
            snr[i] = total/max(noise*np.sqrt(aperture.sum()), 1.)
            if snr[i] > min_snr and 1 < cx < w-2 and 1 < cy < h-2:
                positions[i] = cx, cy
    return positions + corners, snr


def synchronize(times, offsets, timeline, tolerance):
    """Nearest sample, with invalid samples preserved as gaps (no interpolation)."""
    k = np.searchsorted(times, timeline).clip(0, len(times)-1)
    previous = np.maximum(k-1, 0)
    k = np.where(abs(times[previous]-timeline) < abs(times[k]-timeline), previous, k)
    result = offsets[k].copy()
    result[abs(times[k]-timeline) > tolerance] = np.nan
    return result


def load_tracks(args):
    files = paths(args.gw)
    keys = [product_key(p) for p in files]
    if len({(k[0], k[1], k[3]) for k in keys}) != 1:
        raise ValueError('Guide files must belong to one observation, exposure index, and filter')
    if len({k[2] for k in keys}) != len(keys):
        raise ValueError('Provide only one guide file per detector')
    wcs_files = paths(args.wcs) if args.wcs else []
    wcs_map = {}
    for p in wcs_files:
        key = product_key(p)
        if key in wcs_map:
            raise ValueError(f'Duplicate WCS product for {key}')
        wcs_map[key] = p
    tracks, skipped, intervals = [], [], []
    for path, key in sorted(zip(files, keys), key=lambda item: item[1][2]):
        with asdf.open(path) as f:
            roman = f['roman']
            if str(roman['meta']['guide_star'].get('pseudo_star_flag', '')).upper() != 'N':
                skipped.append({'detector': key[2], 'reason': 'pseudo-star or unknown pseudo-star flag'})
                continue
            d = roman['track_data']
            images = np.asarray(d['signal_resultants'], dtype=float)-np.asarray(d['pedestal_resultants'], dtype=float)
            corners = np.asarray(d['lower_left_corners'], dtype=float)
            reset = np.asarray(d['reset_impacted_pairs'], dtype=bool)
            times = np.array([Time(t).unix for t in d['signal_times']])
            pos, snr = measure(images, corners, reset, args.radius, args.min_snr)
        if len(times) < 2 or not np.isfinite(times).all() or np.any(np.diff(times) <= 0):
            raise ValueError(f'{path.name}: timestamps must be finite and strictly increasing')
        track = dict(detector=key[2], source=str(path), times=times, positions=pos, snr=snr)
        if key in wcs_map:
            with asdf.open(wcs_map[key]) as f:
                roman = f['roman']
                exp = roman['meta']['exposure']
                intervals.append((float(Time(exp['start_time']).unix), float(Time(exp['end_time']).unix)))
                if args.axes == 'sky':
                    wcs = roman['wcs_l1']
                    local = np.median(corners, axis=0)+(np.array(images.shape[1:][::-1])-1)/2
                    track['nearby'] = wcs(np.array([local[0], local[0]+1, local[0]]), np.array([local[1], local[1], local[1]+1]))
                    track['center'] = wcs(2047.5, 2047.5)
        elif args.axes == 'sky':
            raise ValueError(f'Missing matching --wcs file for {path.name}; alternatively use --axes detector')
        tracks.append(track)
    if not tracks:
        raise ValueError('No real guide stars found')
    if args.axes == 'sky':
        # One shared tangent frame avoids detector-dependent choices of north.
        ra = np.deg2rad([t['center'][0] for t in tracks])
        mean_ra = np.rad2deg(np.arctan2(np.mean(np.sin(ra)), np.mean(np.cos(ra)))) % 360
        center = SkyCoord(mean_ra, np.mean([t['center'][1] for t in tracks]), unit='deg')
        frame = center.skyoffset_frame()
        for t in tracks:
            c = SkyCoord(*t.pop('nearby'), unit='deg').transform_to(frame)
            jac = np.array([[(c.lon[j]-c.lon[0]).arcsec for j in (1, 2)],
                            [(c.lat[j]-c.lat[0]).arcsec for j in (1, 2)]])
            if not np.isfinite(jac).all() or abs(np.linalg.det(jac)) < 1e-12:
                raise ValueError(f"Invalid WCS Jacobian for {t['detector']}")
            u, _, vh = np.linalg.svd(-jac)
            projected = t['positions'] @ (u @ vh).T
            projected[:, 1] *= -1
            t['positions'] = projected
    if intervals:
        start, stop = max(i[0] for i in intervals), min(i[1] for i in intervals)
        if max(i[0] for i in intervals)-min(i[0] for i in intervals) > .1 or max(i[1] for i in intervals)-min(i[1] for i in intervals) > .1:
            raise ValueError('WCS exposure intervals differ by more than 0.1 seconds')
        interval_source = 'science exposure from WCS metadata'
    else:
        start, stop = max(t['times'][0] for t in tracks), min(t['times'][-1] for t in tracks)
        interval_source = 'overlap of guide-track timestamp ranges'
    if stop <= start:
        raise ValueError('No common time interval')
    accepted = []
    for t in tracks:
        use = (t['times'] >= start) & (t['times'] <= stop) & np.isfinite(t['positions']).all(axis=1)
        if use.sum() < 2:
            skipped.append({'detector': t['detector'], 'reason': 'fewer than two valid centroids in interval'})
            continue
        t['median'] = np.median(t['positions'][use], axis=0)
        t['offsets'] = t['positions']-t['median']
        t['offsets'][~use] = np.nan
        t['times'] -= start
        t['n_valid'] = int(use.sum())
        accepted.append(t)
    if not accepted:
        raise ValueError('No usable centroids in selected interval')
    return accepted, skipped, start, stop-start, interval_source, keys[0]


def render(args, tracks, skipped, start, duration, interval_source, key):
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    step = args.speed/args.fps
    timeline = np.arange(0, duration+1e-8, step)
    for t in tracks:
        tolerance = .75*np.median(np.diff(t['times']))
        t['sampled'] = synchronize(t['times'], t['offsets'], timeline, tolerance)
    values = np.concatenate([t['offsets'][np.isfinite(t['offsets']).all(axis=1)] for t in tracks])
    lo, hi = values.min(axis=0), values.max(axis=0)
    span = max(float(np.max(hi-lo))*1.15, .2)
    middle = (lo+hi)/2
    plt.rcParams.update({'text.color':'#e0e8f2', 'axes.labelcolor':'#e0e8f2', 'xtick.color':'#b0bfce', 'ytick.color':'#b0bfce', 'font.size':12, 'axes.edgecolor':'#617084'})
    fig = plt.figure(figsize=(12,10), dpi=120, facecolor='#090f18')
    ax = fig.add_axes([.09,.13,.66,.76], facecolor='#111d2b')
    labels = ('west', 'north') if args.axes == 'sky' else ('detector x', 'detector y')
    ax.set(xlim=(middle[0]-span/2,middle[0]+span/2), ylim=(middle[1]-span/2,middle[1]+span/2), aspect='equal', xlabel=f'Δx from star median [pixels; positive {labels[0]}]', ylabel=f'Δy from star median [pixels; positive {labels[1]}]')
    ax.grid(color='#718296',alpha=.18)
    ax.axhline(0,color='#9badc1',lw=.9,alpha=.55)
    ax.axvline(0,color='#9badc1',lw=.9,alpha=.55)
    fig.text(.075,.955,'Guide-star centroid motion',size=24,weight='bold')
    fig.text(.075,.92,f'Roman WFI · {key[3]} · {key[0]}_{key[1]:04d}',size=12,color='#a5b5c8')
    fig.text(.78,.88,f'{len(tracks)} guide stars',size=15,weight='bold')
    fig.text(.78,.235,f'Trail: previous {args.trail:g} s\nPlayback: {args.speed:g}× real time\nExcluded detectors: {len(skipped)}',size=11,color='#a5b5c8',linespacing=1.6,va='top')
    fig.text(.075,.06,f'Medians removed over {interval_source}. Reset and invalid samples are omitted.',size=10,color='#a5b5c8')
    fig.text(.075,.037,'Sky mode removes local WCS scale/shear; detector mode does not align detector axes. Trails break at missing samples.',size=10,color='#a5b5c8')
    artists, handles = [], []
    for t, color, marker in zip(tracks,COLORS,MARKERS):
        trail, = ax.plot([],[],color=color,alpha=.32,lw=1.3,animated=True)
        point, = ax.plot([],[],linestyle='',marker=marker,ms=10,color=color,markeredgecolor='#090f18',markeredgewidth=.7,animated=True)
        handle, = ax.plot([],[],linestyle='',marker=marker,ms=9,color=color,label=t['detector'])
        handles.append(handle)
        artists.extend([trail,point])
    fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(.77,.86),frameon=False,labelspacing=.65,fontsize=11)
    clock = fig.text(.78,.285,'',size=12,animated=True,linespacing=1.6)
    fig.canvas.draw()
    background = fig.canvas.copy_from_bbox(fig.bbox)
    w,h = fig.canvas.get_width_height()
    cmd = [args.ffmpeg,'-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{w}x{h}','-r',str(args.fps),'-i','-','-an','-c:v','libx264','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',str(output)]
    history = int(args.trail/step)
    with output.with_suffix('.ffmpeg.log').open('w') as log:
        proc = subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=log)
        try:
            for i, elapsed in enumerate(timeline):
                fig.canvas.restore_region(background)
                for j,t in enumerate(tracks):
                    xy = t['sampled']
                    tail = xy[max(0,i-history):i+1]
                    artists[2*j].set_data(tail[:,0],tail[:,1])
                    artists[2*j+1].set_data(xy[i:i+1,0],xy[i:i+1,1])
                    ax.draw_artist(artists[2*j]); ax.draw_artist(artists[2*j+1])
                utc = Time(start+elapsed,format='unix').utc.isot
                clock.set_text(f'{utc[11:19]} UTC\nElapsed {elapsed:5.1f} s')
                fig.draw_artist(clock)
                rgb = np.asarray(fig.canvas.buffer_rgba())[:,:,:3].copy()
                proc.stdin.write(rgb.tobytes())
                if i == min(int(60/step),len(timeline)-1):
                    Image.fromarray(rgb).save(output.with_suffix('.png'))
                if i % 300 == 0:
                    print(f'Rendering {i+1}/{len(timeline)}',flush=True)
        finally:
            proc.stdin.close()
            code = proc.wait()
            plt.close(fig)
        if code:
            raise RuntimeError(f'FFmpeg failed; see {output.with_suffix(".ffmpeg.log")}')
    summary = dict(version='0.1.0',axes=args.axes,start_utc=Time(start,format='unix').utc.isot,duration_s=duration,interval_source=interval_source,frames=len(timeline),fps=args.fps,speed=args.speed,trail_s=args.trail,radius=args.radius,min_snr=args.min_snr,skipped=skipped,detectors=[])
    for t in tracks:
        name = output.with_name(output.stem+'_'+t['detector']+'.csv')
        np.savetxt(name,np.column_stack([t['times'],t['offsets'],t['snr']]),delimiter=',',header='time_s,dx_pixels,dy_pixels,approx_snr',comments='')
        summary['detectors'].append(dict(detector=t['detector'],source=t['source'],n_valid=t['n_valid'],median_xy=t['median'].tolist()))
    output.with_suffix('.json').write_text(json.dumps(summary,indent=2)+'\n')
    if args.gif_every:
        gif = output.with_suffix('.gif')
        last_delay = max(1,round(((len(timeline)-1)%args.gif_every+1)/args.fps*100))
        filt = f"select='not(mod(n,{args.gif_every}))',scale=960:-2:flags=lanczos,split[a][b];[a]palettegen=stats_mode=diff[p];[b][p]paletteuse=dither=sierra2_4a:diff_mode=rectangle"
        subprocess.run([args.ffmpeg,'-y','-v','error','-i',str(output),'-vf',filt,'-fps_mode','vfr','-final_delay',str(last_delay),'-loop','0',str(gif)],check=True)
    print(f'Saved {output}',flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__,formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('gw',nargs='+',help='GW ASDF paths or quoted globs; one exposure, one file per detector')
    parser.add_argument('--wcs',nargs='+',default=[],help='Matching WCS ASDF paths or quoted globs')
    parser.add_argument('--axes',choices=['sky','detector'],default='sky',help='Sky requires WCS for every real guide star')
    parser.add_argument('-o','--output',type=Path,default=Path('guide_centroids.mp4'))
    parser.add_argument('--fps',type=float,default=30.)
    parser.add_argument('--speed',type=float,default=6.,help='Playback speed relative to real time')
    parser.add_argument('--trail',type=float,default=2.,help='Trail duration in real seconds')
    parser.add_argument('--radius',type=float,default=4.,help='Centroid aperture radius in pixels')
    parser.add_argument('--min-snr',type=float,default=10.,help='Approximate S/N threshold')
    parser.add_argument('--gif-every',type=int,default=0,help='Also save GIF using every Nth movie frame; 0 disables')
    parser.add_argument('--ffmpeg',default='ffmpeg',help='FFmpeg executable or path')
    args = parser.parse_args()
    if any(not np.isfinite(v) or v <= 0 for v in [args.fps,args.speed,args.radius,args.min_snr]) or not np.isfinite(args.trail) or args.trail < 0 or args.gif_every < 0:
        parser.error('fps, speed, radius, min-snr must be positive; trail and gif-every nonnegative')
    if args.output.suffix.lower() != '.mp4':
        parser.error('--output must end in .mp4')
    if not shutil.which(args.ffmpeg):
        parser.error('FFmpeg not found; install it or pass --ffmpeg /path/to/ffmpeg')
    try:
        tracks, skipped, start, duration, source, key = load_tracks(args)
        print(f'{len(tracks)} usable stars; skipped: {skipped}',flush=True)
        render(args,tracks,skipped,start,duration,source,key)
    except (ValueError,KeyError,OSError,RuntimeError,subprocess.CalledProcessError) as exc:
        parser.exit(1,f'Error: {exc}\n')


if __name__ == '__main__':
    main()
