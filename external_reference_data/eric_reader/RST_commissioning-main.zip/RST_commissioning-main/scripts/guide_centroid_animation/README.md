# Roman guide-centroid animation

Basic release (0.1.0) of a standalone command-line tool that overlays up to 18
Roman WFI guide-star centroids on **one shared Δx–Δy plot**. Each star's median
is removed, and each detector has its own color/marker. A short trail shows
recent motion. This makes a centroid animation, not a movie of the guide-window
pixel images. It does not download data.

## Installation

Python 3.10+ and FFmpeg with the `libx264` encoder are required.

```sh
python -m pip install -r requirements.txt
# macOS, if FFmpeg is not already installed:
brew install ffmpeg
```

## Usage

Use files from one exposure, with at most one GW file per detector. Quoted globs
are expanded by the script; ordinary shell-expanded paths also work. WCS files
are associated by observation identifier, exposure index, detector, and filter
(the GW index `3` matches the WCS index `0003`). These are `_wcs.asdf` products,
not `_cal.asdf` images.

```sh
python guide_centroid_animation.py \
  'data/r0108303005001002006_3_*_f062_gw.asdf' \
  --wcs 'data/r0108303005001002006_0003_*_f062_wcs.asdf' \
  --output guide_centroids.mp4 --gif-every 25
```

The default plot uses sky-aligned axes: positive x is west and positive y is
north. Local WCS rotation/parity aligns the detectors; scale and shear are
removed, so offsets remain in native detector pixels. Matching WCS products
are required for every real guide star in sky mode. Their science-exposure
start/stop times define the median and animation interval. Exposure intervals
must agree within 0.1 seconds; their intersection is used.

Without WCS products, use detector coordinates explicitly:

```sh
python guide_centroid_animation.py 'data/*_gw.asdf' \
  --axes detector --output detector_centroids.mp4
```

Detector mode preserves each detector's native x/y orientation, so common sky
motion may point in different directions on different detectors. Without WCS
metadata, the time interval is the overlap of the guide-track timestamp ranges,
which can include guiding before/after the science exposure. Supplying `--wcs`
in detector mode uses those science-exposure times without rotating coordinates.

Useful options (`--help` lists all):

- `--speed 6`: six times real-time playback (default).
- `--fps 30`: output frames per second; default sampling is every 0.2 real seconds.
- `--trail 2`: trail length in real seconds; use 0 for points only.
- `--radius 4`: circular centroid aperture radius in pixels.
- `--min-snr 10`: approximate signal-to-noise threshold.
- `--gif-every 25`: also make a looping GIF from every 25th MP4 frame.
- `--ffmpeg /path/to/ffmpeg`: select an FFmpeg executable.

## Outputs

For `--output guide_centroids.mp4`, outputs are:

- MP4 with elapsed time and UTC clock; fixed, equal-scale axes include all valid offsets.
- `guide_centroids.png`: preview at 60 seconds, or the final frame for shorter observations.
- `guide_centroids.json`: parameters, selected interval, accepted/excluded detectors, and counts.
- `guide_centroids_WFIxx.csv`: original measurement timestamps relative to interval start,
  median-subtracted offsets, and approximate S/N. Invalid/out-of-interval offsets are NaN.
- `guide_centroids.ffmpeg.log`: encoder diagnostics.
- `guide_centroids.gif` when requested.

Existing outputs with these names are overwritten. Input ASDF files are read only.
The JSON records local input paths; review them before publishing results.

## Measurement and limitations

The script subtracts pedestal from signal resultants, then subtracts a median
sky measured in a two-pixel border. It measures a signed-flux-weighted centroid
in a circular aperture, starting at the brightest pixel and iterating three
times. Changing guide-window origins are added before median subtraction.

Only stars explicitly flagged `pseudo_star_flag = N` are accepted. Reset-impacted
pairs, non-finite images, nonpositive aperture flux, low approximate S/N, and
centroids within the outer edge cut are omitted. This is basic quality selection,
not a model of cosmic rays, saturation, blends, or centroid uncertainties; it does
not temporally clip outliers. Approximate S/N uses border NMAD and does not include
a full photon/read-noise model.

Each star's median uses its valid samples in the selected interval. Animation
frames select the nearest measurement within 0.75 times that detector's median
cadence. Invalid samples remain gaps; there is no interpolation. A trail breaks
at a missing sampled value. Data-quality gaps shorter than the animation sampling
interval can be skipped, especially at high playback speeds. CSVs retain the
original measurements. The tool expects the current Roman `roman.track_data`
layout (`signal_resultants`, `pedestal_resultants`, `signal_times`,
`lower_left_corners`, `reset_impacted_pairs`) and WCS `roman.wcs_l1` layout.

## Validation

```sh
python -m unittest -v test_guide_centroid_animation.py
```

Tests cover changing window origins, reset/blank rejection, timestamp gaps,
and Roman GW/WCS filename matching. The initial release was also exercised on
all 18 GW/WCS products for `r0108303005001002006_0003` (F062, 2026-10-08), selecting
15 real guide stars and excluding three pseudo-star windows.
