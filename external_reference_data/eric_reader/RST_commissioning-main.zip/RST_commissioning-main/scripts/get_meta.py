"""
Retrieve metadata for a given Roman product file. Without the S3 URI of the file, this downloads the full
file to a virtual file system with fsspec. If you have an S3 URI for a file, this can be modified to get
only the metadata section.

Example:
> from get_meta import get_meta
> meta = get_meta('filename_cal.asdf')
> print(meta)

You must have a MAST_API_TOKEN set in a file called variables.env in the same directory as this script. 
The file should contain:
    MAST_API_TOKEN='your_api_token_here'
"""

import os
from typing import cast
import re
import typing
import yaml
from urllib.parse import quote
from dotenv import load_dotenv
import requests
import fsspec


# MAST setup
MAST_URI = 'https://mast.stsci.edu/search/roman/api/v0.1/retrieve_product'
_ = load_dotenv(dotenv_path="./variables.env")
MAST_API_TOKEN = os.getenv("MAST_API_TOKEN")

# YAML parsing setup
YAML_END_PATTERN = re.compile(rb"\r?\n\.\.\.((\r?\n)|$)")
MAX_HEADER_READ_LEN = 4096 * 1024


class Dumper(yaml.SafeDumper):
    pass


class Loader(yaml.SafeLoader):
    pass


class Tagged(typing.NamedTuple):
    tag: str
    value: object
    def construct_undefined(self, node):
        if isinstance(node, yaml.nodes.ScalarNode):
            value = self.construct_scalar(node)
        elif isinstance(node, yaml.nodes.SequenceNode):
            value = self.construct_sequence(node)
        elif isinstance(node, yaml.nodes.MappingNode):
            value = self.construct_mapping(node)
        else:
            assert False, f"unexpected node: {node!r}"
        return Tagged(node.tag, value)

    Loader.add_constructor(None, construct_undefined)
    
    
def get_meta(filename, chunk_size=8192):
    """
    Retrieve metadata for a given Roman product file from MAST without downloading the entire file.

    Parameters
    ----------
    filename : str
        The name of the Roman product file.
    chunk_size : int, optional
        The size of chunks to read from the file, by default 8192.

    Returns
    -------
    dict
        The metadata of the Roman product file.
    """
    
    # Construct HTML redirect to S3 product URI
    url = f'{MAST_URI}?product_name={quote(filename, safe="")}'
    
    # Make a GET request to the MAST API to retrieve the S3 URI for the product file
    headers = {"Authorization": f"Bearer {MAST_API_TOKEN}"}
    resp = requests.get(
                url,
                headers=headers,
                allow_redirects=False,
                )
    
    resp.raise_for_status()

    # Get the S3 URI from the Location header of the response
    s3_uri = resp.headers['Location']
    
    # Open the S3 URI using fsspec and read the YAML header in chunks
    fs = fsspec.filesystem("https")
    buffer = b""
    yaml_content = None

    with fs.open(s3_uri, "rb") as f:
        while not yaml_content:
            chunk = f.read(chunk_size)

            if not chunk or len(buffer) > MAX_HEADER_READ_LEN:
                # EOF or exceeded 4MB without finding marker
                break

            buffer += chunk
            match = YAML_END_PATTERN.search(buffer)
            if match:
                yaml_content = buffer[: match.end()]

    meta = yaml.load(yaml_content, Loader=Loader).value['roman'].value['meta']

    return meta
