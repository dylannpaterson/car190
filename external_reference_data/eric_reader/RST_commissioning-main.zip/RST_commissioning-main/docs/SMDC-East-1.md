# Using SMDC East-1 HPC for Science Commissioning Analyses

## Logging in

```shell
ssh -i <rsa private key path> <user>@hpc-east-1.roman.sciencecloud.nasa.gov
```

## Initial Setup

You should have python 3.12 by default.

Do your commissioning work in `/mnt/roman-science-internal/`. 
```shell
mkdir /mnt/roman-science-internal/"$USER"
cd /mnt/roman-science-internal/"$USER"
```
Alternatively `/mnt/smdc-rom-com-ops/rrn-ops/` is SMDC writable, and RRN readable while `/mnt/roman-s3-romcom` is RNN writable, and SMDC readable. Use these for cross system interoperability.

Please save your work in https://github.com/RomanSpaceTelescope/RST_commissioning. Specifically make your own folder in /science_analysis. 

>[!note]
> You will need a personal access token or some other way to authenticate to GitHub since this repo is private.

```shell
git clone https://github.com/RomanSpaceTelescope/RST_commissioning.git
mkdir RST_commissioning/science_analysis/"$USER"
cd RST_commissioning/science_analysis/"$USER"
```

> [!warning]
> **MUST READ: `RST_commissioning` Repository Policies**
> - Do not commit binary or data files to the git repo. Small data tables or configurations are OK: max file size target 100k, xlsx files acceptable but discouraged in favor of ecsv or similar. Data should go in romcom S3 bucket areas using the docs/DATASET guidelines for describing those data.
> - Do not use this area for any data or code which are export controlled.
> - Commissioning analysis requires agreement to dataset confidentiality, which is coordinated through the PIT PIs. Follow https://outerspace.stsci.edu/spaces/RSC/pages/428050352/Roman+Space+Telescope+Commissioning+and+First+Look+Observations+Confidentiality+and+Embargo+Policy
> 
> In addition to data files, do not commit:  
>
> - Credentials
> - API tokens
> - Personal secrets
> - Local environment directories
> - Temporary scratch files
> - Cache files
> - Files that can be regenerated easily
>
> If you accidentally commit a large file, stop and ask for help. Do not keep making more commits on top of it. Large files can remain in Git history even after deletion, so they may need special cleanup.

### Getting python packages

For this example I am using venv for a virtual environment and store it in `venv/`. You can also setup and use conda. For that, follow the general SMDC instructions in `RST_commissioning/docs` [on managing software packages](https://github.com/RomanSpaceTelescope/RST_commissioning/blob/main/docs/Roman-SMDC-FAQ.md#how-do-i-load-software-packages).

```shell
python -m venv venv
activate venv/bin/activate
```

Now you can pip install like normal.

You might want to start with photutils, astroquery, and a few other packages you need to work with the Roman data.

```shell
pip install photutils git+https://github.com/snbianco/astroquery.git@2026.2 boto3 botocore fsspec asdf-astropy requests aiohttp lz4 roman-datamodels
```

## Normal usage

The next time you log in, you just need to move to your folder, and start your venv.

```shell
cd /mnt/roman-science-internal/"$USER"/RST_commissioning/science_analysis/"$USER"
source venv/bin/activate
```

Remember to git commit and push your scripts regularly so everyone can see them. Also remember the policies and best practices of the git repository listed above. 


>[!note]
> Please report **any and all** data discrepancies on [Outerspace](https://outerspace.stsci.edu/pages/viewpage.action?pageId=415108418&spaceKey=RSC&title=Science%2BData%2BDiscrepancy%2BReports).

## Accessing data

### Obtain & Using a MAST Token

[This section is from `RST_commissioning/docs/obtaining-data.md`](https://github.com/RomanSpaceTelescope/RST_commissioning/blob/main/docs/obtaining-data.md#1-obtain-token)

Go to [https://auth.mast.stsci.edu/info](https://auth.mast.stsci.edu/info) to get your API Token set up and follow the instructions. You will need to regenerate your API Token every 60 days.

Once you have your Token, you need to set it to an environment variable in your machine. On SMDC this is in `~/.bashrc`. Add the following line to your profile. One way of doing this is

```
echo "export MAST_API_TOKEN='<your_alpha_numeric_API_token_goes_here>'" >> ~/.bashrc
```

Replace `<your_alpha_numeric_API_token_goes_here>` with your API Token.

To access the TOKEN inside of python you can use

```python
import os
os.getenv("MAST_API_TOKEN")
```

>[!warning]
> Make sure you don't share any files with this key as it will give anyone access to the data.

Below we set up a MAST query object, and ensure that it will use datasets from the cloud.

```python
import os
from astroquery.mast import MastMissions, Observations
mast = MastMissions(mission='Roman')
mast.login(token=os.getenv('MAST_API_TOKEN')) 
Observations.enable_cloud_dataset()
```

For more examples, check out https://github.com/RomanSpaceTelescope/RST_commissioning/blob/main/docs/obtaining-data.md.

### What Data Is available

The Outerspace page [Commissioning Program Data Status](https://outerspace.stsci.edu/spaces/RSC/pages/428053784/Commissioning+Program+Data+Status) is updated every 15 mins. More examples are in a pinned message by Tyler Desjardins in the `#commissioning-data-access` channel of the Roman slack.


## Example usage

```python
import os
from astroquery.mast import MastMissions, Observations
from photutils.detection import find_peaks
from photutils.segmentation import detect_threshold

# setup access
mast = MastMissions(mission='Roman')
mast.login(token=os.getenv('MAST_API_TOKEN')) 
Observations.enable_cloud_dataset()

# find files
search = {'productLevel': 2, "program": 1022}
col_list = ['program', 'execution_plan', 'pass', 'segment', 'visit', 'observation',
            'optical_element', 'exposure_type', 'instrument_name', 'detector', 'productLevel',
            'product_type', 'exposure_time', 'exposure_start_time', 'exposure_end_time',
            'fileSetName', 'program']
query_results = mast.query_criteria(**search, select_cols=col_list)
query_results.sort('exposure_start_time') #acts inplace and returns None
print(f'{query_results[:5]=}')
#filter on calibrated prodcuts and get their file names.
products = mast.filter_products(mast.get_unique_product_list(query_results), file_suffix='_cal')

# access files
#products["product_key"] is of type numpy.str_ and I just want a string.
fname = str(products['filename'][-1]) #at the time, the first item was a prism image
af = mast.read_product(fname)

# do science
find_peaks(af['roman'].data, detect_threshold(af['roman'].data, 5))
print(f'{peaks[:5]=}')
```

>[!note]
> Remember to report **any and all** data discrepancies on [Outerspace](https://outerspace.stsci.edu/pages/viewpage.action?pageId=415108418&spaceKey=RSC&title=Science%2BData%2BDiscrepancy%2BReports).
