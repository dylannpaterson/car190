# Available Data

There are currently several types of WFI imaging and spectroscopic products available for use with the Roman Research Nexus (RRN). These include:
- **WFI Ground test data** from both the second WFI thermal vacuum test campaign (TVAC2) and the SpaceCraft Integrated Payload Assembly (SCIPA) TVAC test. 
- **Small Roman I-Sim simulated exposures** of a globular star cluster, which include simulated detector-level calibration features;
- **Simulated Core Community Survey (CCS) exposures** of the [High-Latitude Wide-Area Survey (HLWAS)](https://roman-docs.stsci.edu/roman-community-defined-surveys/high-latitude-wide-area-survey) and [Galactic Bulge Time-Domain Survey (GBTDS)](https://roman-docs.stsci.edu/roman-community-defined-surveys/galactic-bulge-time-domain-survey) also made with Roman I-Sim;
- **The** [**OpenUniverse**](https://ui.adsabs.harvard.edu/abs/2024ipac.data.I569O/abstract) **Roman simulated preview data**, converted to the [Advanced Scientific Data Format (ASDF)](https://roman-docs.stsci.edu/data-handbook/wfi-data-levels-and-products/asdf-format-information), including single exposures and, when available, truth catalogs for mock Roman High-Latitude Wide-Area Survey (HLWAS) and High-Latitude Time-Domain Survey (HLTDS) data;
- **Bright Star Ground Test Images** from the WFI thermal vacuum (TVAC) campaign;
- **Simulated grism images** developed for the spectroscopic component of the HLWAS.

An overview of these data products can be found below. All files are stored in the **Open Data Bucket**. See the [Cloud Data Access Notebook](../notebooks/data_discovery_and_access/data_discovery_and_access.ipynb) for details on accessing these products.

## WFI Ground Test Data

High-priority datasets from ground testing have been uploaded to the ROMCOM S3 bucket to compare with on-orbit data during commissioning. Not all data from ground testing has been uploaded, and additional data from WFI TVAC1 and TVAC2 can be found in the [Roman Integration & Test Archive (RITA)](https://mast.stsci.edu/cassi/#/roman).

### SCIPA Non-MRT Data

These data were taken outside of the nominal Mission Readiness Tests (MRTs) during SCIPA TVAC. APT programs are available for these programs and can be retrieved from the APT menu. These data were received by the SOC DMS as L0 files through the ground system and processed into flight-like L1 files. 


ROMCOM S3 Bucket Location: `s3://roman-s3-romcom/SCIPA/{program_ID}/`

Filename format: `{programmatic_identifier}_{detector}_{element}_uncal.asdf`

Example URI:
```
s3://roman-s3-romcom/SCIPA/730/r0073001001001027001_0009_wfi18_dark_uncal.asdf
```

The available data include:

- Program ID 730 (Science Monitor)
    - Description: Combination of RCS flats with all LED bands and dark exposures with DIAGNOSTIC MA table and DARK element useful for trending tests. Also included are LOLO exposures.
- Program ID 771 (RCS CFA)
    - Description: A combination of flats with the RCS turned on and corresponding darks. Observing sequences begin and end with darks, with flats in the middle. Included are bands 2, 5, and 6 taken with the DIAGNOSTIC MA table using a range of total resultants of 5 - 171 (13 - 538 seconds). The following passes were taken:
        - 0077101001: B2 high flux on B side
        - 0077101002: B6 high flux on B side
        - 0077101003: B5 special on B side
        - 0077101004: B6 special on B side
        - 0077101005: B2 high flux on A side
        - 0077101006: B6 high flux on A side

### SCIPA MRT Data

These data were obtained during SCIPA TVAC as part of the regular MRT plans.

ROMCOM S3 Bucket Location: TBD

Filename format: TBD

Example URI:
```
TBD
```

Accompanying notebook: TBD

**OTP00775 (Daily Ice Monitor)**:
- *Description:* TBD

Also included is the full RCS telemetry, which mimics what will be available during Operations and provides the detailed RCS engineering data required to do any measurements needing the absolute flux levels from RCS.

### WFI TVAC2 Data

These data are a subset of test observations taken as part of the [WFI TVAC2](https://roman-docs.stsci.edu/roman-instruments/the-wide-field-instrument/wfi-characterization-activities/wfi-ground-testing-campaigns#WFIGroundTestingCampaigns-SecondWFIThermalVacuumIntegrationandTesting(TVAC2)TVAC2) test campaign.

ROMCOM S3 Bucket Location: `s3://roman-s3-romcom/RITA/TVAC2/{plateau}/{otp_script}/`

Filename format: `{campaign}_{plateau}_{test_name}_{date}_{detector}_uncal.asdf`

Example URI:
```
s3://roman-s3-romcom/RITA/TVAC2/NOM_OPS/OTP00614_CFABand6_TV2a_R1/TVAC2_NOMOPS_WFIRCS_20240429161512_WFI02_uncal.asdf
```

The following Operational Test Plans/Procedures (OTPs) have been included:

**OTP00611 (Edge Sweep):**
- *Plateau:* NOMOPS
- *Description:* Flat fields and darks using the laser line tunable filter (LLTF) and different optical elements. These are used to characterize the filter edges and other parameters.

**OTP00614 (CFA):**
- *Plateau:* NOMOPS
- *Description:* RCS flats of different exposure times with 1 read / resultant using bands 1, 2, 3, 5, and 6. Dark exposures with exposure times matching the corresponding flat. 

**OTP00634 (Out of Band / Blackbody):**
- *Plateau:* COLDQUAL
- *Description:* Images illuminated by the Stimulus of Ray Cones (SORC) blackbody, increasing the temperature (6.25 Kelvin / hour) and rotating optical elements in the element wheel.

**OTP00636 (Science Monitor):**
- *Plateau:* NOMOPS
- *Description:* Combination of RCS flats with all LED bands and dark exposures with DIAGNOSTIC MA table and DARK element useful for trending tests. Also included are LOLO exposures. The flat, gain, and linearity reference files use data from this test.

**OTP00638 (Thermal Background):**
- *Plateau:* NOMOPS
- *Description:* Dark images with the DIAGNOSTIC MA table (55 resultants, 1 read /resultant) sweeping through the different optical elements.

**OTP00639 (Total Noise):**
- *Plateau:* NOMOPS
- *Description:* Exposures with diagnostic MA table (55 resultants, 1 read / resultant) with the DARK element. These data are used to create the reference pixel correction reference file, and can be used for read noise and dark reference files.

**OTP00644 (Long Darks):**
- *Plateau:* NOMOPS
- *Description:* Long exposures (up to >300 resultants) with DIAGNOSTIC MA table and DARK element. Used to create dark reference files, and to check the stability of the dark current with time.

### MRT Guide Window Data

A copy of all MRT guide window data received by the SOC has been included. These are L1 files that have been processed by the SOC DMS from L0 files. The guide window (GW) files include the guide window pixel data and associated telemetry information. The fine attitude correction estimate (FACE) files include telemetry information from the Attitude Control System (ACS) in response to the observed positions of guide stars in the guide windows.

ROMCOM S3 Bucket Location: `s3://roman-s3-romcom/MRT/guide_window/`

Filename format:
- Guide window data: `{programmatic_identifier}_{acq}_{detector}_{element}_gw.asdf`
- FACE file: `{programmatic_identifier}_{acq}_{element}_face.asdf`

Example URI:
```
s3://roman-s3-romcom/MRT/guide_window/r0013301119142001004_1_wfi12_f129_gw.asdf
```

## Roman I-Sim Simulated Images

[Roman I-Sim](https://github.com/spacetelescope/romanisim) generates Roman WFI imaging products by combining an input source catalog with simulated instrument and detector effects.

The Roman I-Sim products have metadata and an organizational structure identical to what is expected for actual Roman data taken during operations. The products are stored in ASDF files and adhere to the released version of the [WFI science data product schema](https://roman-docs.stsci.edu/data-handbook-home/wfi-data-format/data-levels-and-products) installed on the RRN. In the example [Science Workflows](workflows.md) and [Tutorials](tutorials.md), the input catalogs are provided as Enhanced Character-Separated Value (ECSV) files and combine stars from the Gaia source catalog with galaxies generated using the parametric source generation offered within the tool. The brightnesses of the Gaia stars are set to the Gaia r-band magnitude in all Roman filters (i.e., a flat spectral energy distribution), and the parametric source generation process does not use SED information to produce sources with realistic colors.

Roman I-Sim products are created using reference files from the [Calibration Reference Data System](https://roman-docs.stsci.edu/data-handbook-home/accessing-wfi-data/crds-for-reference-files) (CRDS). Therefore, the accuracy of the instrumental effects in the simulations is only as good as the reference files used to create them. The current suite contains preliminary versions of reference files based on ground testing, and it is expected to improve as characterization of the ground test data continues. Questions regarding calibration reference files should be sent to the [Roman Helpdesk at STScI](https://stsci.service-now.com/roman).

The Roman I-Sim simulated products include four full-focal-plane exposures (18 detectors each) in a four-point box dither pattern near the globular cluster NGC 6535, centered at (RA, Dec) = (270.94, –0.2) deg, using the F106 optical element. The offset in the dither pattern is approximately half a detector in both X and Y directions to ensure complete filling of the gaps between detectors. The table below shows the dither pattern used for the simulation, where each offset represents the offset from the previous position. So, the zeroth position starts with offsets of 0.00 in both X and Y, and the first position is relative to the zeroth one, the second position is relative to the first, etc. Here is the pattern:


| Dither Step | Offset X (arcsec) | Offset Y (arcsec) |
| --- | --- | --- |
| 0 | 0.00 | 0.00 |
| 1 | 0.55 | 200.55 |
| 2 | 200.55 | 0.55 |
| 3 | 0.55 | -200.55 |

From these four full-focal-plane exposures, a mosaic for detector 11 (WFI11) is also generated using each of the dither positions that cover the full extent of NGC 6535.

## Roman I-Sim CCS Simulations

The Roman I-Sim CCS simulations provide a suite of downscaled Roman WFI imaging data products designed to support workflow development, pipeline validation, and user exploration in the RRN. These simulated products were generated by creating uncalibrated L1 ramps with [Roman I-Sim](https://romanisim.readthedocs.io/en/latest/) and then processing those products through the Roman science calibration pipeline ([RomanCal](https://roman-pipeline.readthedocs.io/en/stable/)) to produce calibrated L2 images. In selected cases, later-stage products such as mosaics and catalog/segmentation outputs are also available. See [WFI Data Levels and Products](https://roman-docs.stsci.edu/data-handbook/wfi-data-levels-and-products) for definitions of the product levels.

The CCS simulation set includes two primary survey programs:
- **Galactic Bulge Time-Domain Survey (GBTDS)**, designed to represent the scale and cadence of a high-volume time-domain observing program;
- **High-Latitude Wide-Area Survey (HLWAS)**, designed to represent the tiered survey design, depth, and dither patterns expected for Roman wide-area imaging.

The [CCS Simulations tutorial](../notebooks/ccs_simulations/ccs_simulations.ipynb) provides detailed information about these simulations.

### Galactic Bulge Time-Domain Survey (GBTDS)

The GBTDS simulation was designed primarily to test Science Operations Center (SOC) data-processing performance at the scale expected for Galactic Bulge survey operations. The simulation includes a cadence with:
- frequent **F146** observations,
- less frequent **F087** and **F213** observations,
- and snapshot observations in **F062, F106, F129, F158, and F184**.

The simulation footprint uses the GBTDS fall-season mosaic pattern with multiple fields and realistic stellar populations generated using [Synthpop](https://synthpop.readthedocs.io/en/latest/). The input catalog was partitioned into HEALPixels to support efficient simulation and data organization.

The GBTDS products include:
- uncalibrated **L1** ramp cubes (`*_uncal.asdf`)
- calibrated **L2** rate images (`*_cal.asdf`)
- preview and thumbnail images of L2 products (`*_preview.png` and `*_thumb.png`)
- updated WCS products aligned to Gaia (`*_wcs.asdf`)

The Gaia alignment was unreliable for these simulated GBTDS data, so their L2 WCS may be offset. This simulation-specific issue is not expected in real observations. Apply the [correction in the CCS Simulations notebook](../notebooks/ccs_simulations/ccs_simulations.ipynb#correcting_gbtds) before position-dependent analysis.

### High-Latitude Wide-Area Survey (HLWAS)

The HLWAS simulation is intended to represent the tiered survey design, dither pattern, and depth expected for Roman’s HLWAS imaging component. To simplify the simulation relative to on-orbit execution:
- all tiers were co-located on the sky to reduce slew time;
- exposures were run consecutively without pauses for calibration or other science observations.

The HLWAS simulation includes imaging data only and does not include grism observations. Its input catalog combines:
- **OpenUniverse galaxies**
- **OpenUniverse Milky Way faint stars**
- [**Gaia DR2**](https://ui.adsabs.harvard.edu/abs/2018A%26A...616A...1G/abstract) **stars**

The HLWAS products include:
- uncalibrated **L1** ramp cubes (`*_uncal.asdf`)
- calibrated **L2** rate images (`*_cal.asdf`)
- preview and thumbnail images for L2 and L3 products (`*_preview.png` and `*_thumb.png`)
- updated WCS products (`*_wcs.asdf`)
- co-added **L3** mosaic images (`*_coadd.asdf`)
- **L4** source catalogs (`*_cat.parquet`)
- **L4** segmentation maps (`*_segm.asdf`)

### Data Access and Search

All CCS simulation data are available via the STScI AWS Open Data Bucket and can be streamed directly into memory without copying files to local storage. Use the [GBTDS manifest](../notebooks/ccs_simulations/gbtds_manifest.ecsv), [HLWAS exposure manifest](../notebooks/ccs_simulations/hlwas_manifest.ecsv), or [HLWAS coadd manifest](../notebooks/ccs_simulations/hlwas_coadd_manifest.ecsv) to locate data products. These manifests support common searches, including:
- cone searches by sky position,
- time-range selection,
- detector and filter filtering,
- and compound searches combining multiple criteria.

The [CCS Simulations tutorial](../notebooks/ccs_simulations/ccs_simulations.ipynb) demonstrates how to search these manifests and stream selected files. It also shows how to:
- identify preview images and auxiliary files;
- locate and open FITS input catalogs;
- read Parquet source catalogs with `pandas` or `pyarrow`; and
- visualize images with associated catalog information.

### Caveats and Limitations

These simulations are intended for workflow development and demonstration purposes. Their fidelity depends on the calibration reference files and software versions available at the time they were generated. In addition:
- time-variable sources are not included;
- the HLWAS simulation is limited to imaging mode;
- and the available catalog and segmentation products reflect the simulation configuration used when the datasets were produced.

## OpenUniverse Roman Simulation

The OpenUniverse 2024 project aims to simulate overlapping images from surveys mimicking those that will be carried out by the Nancy Grace Roman Space Telescope and the Vera C. Rubin Observatory. These [data are publicly available](https://irsa.ipac.caltech.edu/data/theory/openuniverse2024/overview.html) as FITS images and Parquet catalogs. As a demonstration of ASDF and the Nexus, Roman-specific images from this project are available on the RRN.

Two main datasets are currently converted:
- Roman High-Latitude Wide-Area Survey (HLWAS) single exposures in six photometric bands (F184, F158, F129, F213, F146, F106)
- Roman High-Latitude Time-Domain Survey (HLTDS) single exposures in seven photometric bands (F184, F158, F129, F213, F062, F106, and F087)

The data in the RRN consist of Roman images overlapping the LSST ELAIS-S1 Deep Drilling Field (DDF), simulating the [High-Latitude Time-Domain Survey (HLTDS)](https://roman-docs.stsci.edu/roman-community-defined-surveys/high-latitude-time-domain-survey), the [High-Latitude Wide-Area Survey (HLWAS)](https://roman-docs.stsci.edu/roman-community-defined-surveys/high-latitude-wide-area-survey), and an HLWAS calibration deep field.

All data have been converted to ASDF format and include, when available, truth catalogs of simulated sources overlapping the exposures. For simplicity, the ASDF files containing the simulated data follow a custom schema.

The dataset is contained in the `roman` block, which includes the following sub-blocks:

| Data block name | Description |
| --- | --- |
| DATA | 4096 × 4096 pixel images containing the accumulated total counts after the exposure |
| DQ | 4096 × 4096 pixel images with the data quality flags |
| META | Metadata block |
| CATALOGS | Block containing the truth catalogs of the sources whose positions lie in the image of interest |

## Bright Star Ground Test Images

The Bright Star Saturation test was conducted as part of the Wide Field Instrument (WFI) [thermal vacuum (TVAC) campaign](https://roman-docs.stsci.edu/roman-instruments/the-wide-field-instrument/wfi-characterization-activities/wfi-ground-testing-campaigns#WFIGroundTestingCampaigns-WideFieldInstrument(WFI)TVACTestingWFI_Testing) to evaluate how the flight detectors behave when exposed to saturating light conditions. Nine in-focus point sources, with magnitudes spanning approximately 4 to 18 mag, were projected using a telescope simulator through the F146 filter onto grid positions across detectors 4 (WFI04) and 11 (WFI11).

The test sequence begins with an initial 4-frame exposure to verify that the commanded flux and position match expectations. This is followed by a series of interleaved exposures: single point-source exposures with 55 read frames alternating with single exposures taken without illumination (but with the F146 filter remaining in place). The sequence concludes with 18 dark exposures of 55 frames each, taken with the dark element in place.

These products have been converted to Level 1 (L1) format and are available in the Open Data Bucket to provide an example of ground test data suitable for detector characterization prior to actual flight observations. [The WFI TVAC Test Data Notebook](../notebooks/ground_test_analysis/wfi_tvac_brightstar.ipynb) demonstrates how to extract a subset of the data, process it using romancal, and analyze saturation effects and per-frame slope variations in the vicinity of bright sources. Note that these test data will differ from in-flight observations because the telescope simulator and experimental setup do not reproduce the true observatory optics.

Additional reference material is available on the [Roman WFI TVAC2 Bright Star Saturation Test Data Mini-Release page](https://asd.gsfc.nasa.gov/roman/WFI_Bright_Star/) and in Dana Louie et al. (in prep.).

## Spectroscopy Data

Simulated grism images from Wang et al. (2022, ApJ, 928, 1), developed as part of the Roman High Latitude Spectroscopic Survey (HLSS) Grism Simulation Products, are also available. For detailed information, please refer to the [documentation on IRSA](https://irsa.ipac.caltech.edu/data/theory/Roman/Wang2022a/). These simulations cover a total area of 4 square degrees and a redshift range of 0 < z < 3. The simulation products were designed to closely replicate future observations, incorporating survey parameters such as detection limits, exposure times, roll angles, and dithering strategies.

For the [spectroscopic extraction tutorial](../notebooks/grism_spectral_extraction/grism_spectral_extraction.ipynb), one grism file and one direct imaging file generated from these simulations are provided.

---
*Last Updated: August 2026*
