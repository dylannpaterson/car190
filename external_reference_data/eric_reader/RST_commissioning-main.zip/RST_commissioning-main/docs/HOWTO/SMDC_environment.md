# SMDC quick-start 

## Working interactively with compute nodes
Add entries to your `.ssh/config` to tell ssh how to forward to the compute nodes directly:
```
Host *p4d* *p5* *g5* *r6i* *c7i* *c5n*
  ProxyJump your_userID@hpc-east-1.roman.sciencecloud.nasa.gov
  User your_userID
  IdentityFile /path/to/ssh/private/key
  StrictHostKeyChecking no
  UserKnownHostsFile /dev/null

Host hpc6* hpc7* p4* p5* g6* g5* c7* r6*
    ProxyJump your_userID@hpc.roman.sciencecloud.nasa.gov
    User your_userID
    IdentityFile /path/to/ssh/private/key
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
```

Run `salloc --partition=mem-int --time=02:00:00 --no-shell` where time is HH:MM:SS and here 2 hours and `sinfo` lists the partitions. See [SMDC primer](https://outerspace.stsci.edu/spaces/IWG/pages/413204740/RST+Science+Infrastructure+Primer) for a table. This allocates the node but does not drop to shell; that is more robust for the vs code tunnel. It will give you the computer name and process as:
```
salloc: Granted job allocation 7205
salloc: Waiting for resource configuration
salloc: Nodes mem-int-dy-r6i-xlarge-1 are ready for job
```
You can then `ssh username@mem-int-dy-r6i-xlarge-1`. 

To use `vscode` click Press Ctrl+Shift+P (or Cmd+Shift+P on macOS) to open the command palette Type/Select "Remote-SSH: Connect to Host" or hit the right/left arrow in the very bottom left corner to go into remote mode. Then enter the computer name into the ssh field. You may also give your username if it differs from the host computer. It will take a while to load the server side. You can then install extensions: jupyter, python (including any like Pylance, Pylint), claude code etc. Only install Microsoft managed extensions, not third party.

When done `scancel <identified slurm job ID>`

## How to Use Miniforge on SMDC AWS HPC system

### Installing a miniforge conda environment

* Log in to SMDC
* Run `source /shared/spack/share/spack/setup-env.sh` to get the spack package manager
* Run `spack load miniforge3` then `conda init bash`. This will add a block to your `.bashrc` to initialize.
* If that now shows `(base)` at your prompt, add `source /shared/spack/share/spack/setup-env.sh` and `spack load miniconda3` prior to the new `conda initialize` block in `.bashrc`
* Log out and log back in; it should show `(base)`. 

### Making a target environment
