# Commissioning science analysis meeting organization

## Overview 
* **The meeting format and organization are not fixed: please speak up with ideas to improve the effectiveness and efficiency** and we will update [this](https://github.com/RomanSpaceTelescope/RST_commissioning/edit/main/docs/ANALYSIS_MEETING.md) document.
* Held 1-2 PM Eastern daily with meetings cancelled if there are not sufficient topics, and not weekends unless there is high urgency.
* Analysts: please block your calendar 1-2 PM Eastern. If the meeting is not held, the block of time can be used for coordination.
* [Outerspace page](https://outerspace.stsci.edu/spaces/RSC/pages/428052022/RSC+Data+Analysis+Meeting) for minutes, one page per week. **All results here will be assumed to be provisional** rather than final analysis deliveries. Lean toward posting results for discussion even if they do not make complete sense or have converged. Commissioning exit criteria pages can be used for the next level up, where conclusions have converged further. This meeting can include any analysis; not just CAR/CAPs.
* Flow: 1) this meeting used for provisional results or status, any results and areas where people are interested to discuss, 2) aggregate findings to [CAOs](https://outerspace.stsci.edu/spaces/RSC/pages/428052994/CAOs+-+Commissioning+Analysis+Outcomes) at the level of the CAR/CAP, 3) these flow to deliverable analysis reporting (technical reports, ISRs), 4) final findings summarized in Exit Criteria and links to key documents.
* Summary bullets/plots from the meeting are reported at the 2 PM Eastern Roman Commissioning Daily Briefing.
* `#commissioning-analysis` is the primary channel for discussions, scheduling, coordination, urgent questions, and links. Substantive status updates, results, decisions, plots, and action items must be recorded on the weekly OuterSpace page. Slack should not be treated as the durable/authoritative record. 
* `https://github.com/RomanSpaceTelescope/RST_commissioning` is the git repo for analysis code. See [CONTRIBUTING.md](https://github.com/RomanSpaceTelescope/RST_commissioning/blob/main/CONTRIBUTING.md) for guidance on contributing and [README.md](https://github.com/RomanSpaceTelescope/RST_commissioning/blob/main/README.md) for an overview.
* CGI: The analysis meeting will focus on WFI and could include some areas of overlap with CGI. For CGI, analysis will be discussed in the CPP calibration meeting, CTC, or smaller ad hoc meetings as needed.

## Meeting policy
* **All venues described here are for discussion which is not export controlled.** Export controlled or other sensitive topics should be discussed through other meeting contexts. Please notify Eric Switzer if you have a topic which will need export-controlled discussion and we will coordinate on an appropriate venue.
* **All participants must agree to the [Commissioning Confidentiality and Embargo Policy](https://outerspace.stsci.edu/spaces/RSC/pages/428050352/Roman+Space+Telescope+Commissioning+and+First+Look+Observations+Confidentiality+and+Embargo+Policy)**
* Do not forward the invitation to the meeting without authorization from Eric Switzer.
* Use only the outerspace meeting minutes page for updates. Do not contribute updates for the daily analysis meeting over email, Slack, Box, or shared slides etc. The goal here is to keep overheads low and all the information in one place. (baseline is Confluence/OuterSpace because Box has concurrency challenges. Also flat wiki text is easier to process than powerpoints.)
* Only reporting analysts and stakeholders/SMEs need to attend a given meeting; aim to identify before the start of the meeting.

## Roles
* Organizer: decides whether to meet, orders agenda, manages time
* Analyst: updates status and results
* Presenter: reports for analyst if the analyst is off shift
* SME/stakeholder: provides interpretation or decisions
* Notetaker: records interpretations, decisions, rationale, blockers, and actions
* Briefing liaison: transfers approved content to the 2 PM briefing; may be analyst or organizer
* Action: **Need backup organizers, rotating note-takers**

## Pre-meeting
* Meeting minutes identify: analyst and SME names to focus attendance. If analyst is on a different shift, designate a presenter.
* Keep overhead low. **Attendees: review the topics for the meeting, and if not contributing as presenter/SME/stakeholder, no need to attend.** We will aim to take detailed notes, and the outerspace page will be the place to track for awareness.
* Each analyst updates the Confluence page with fields below, as relevant. Please include the path in the `RST_commissioning` repo or links to other repositories that are relevant to the analysis.
* Meeting organizer or backup(s) sorts and organizes the updates for the meeting and digests shift reports for recently run tests.
* The organizer decides by 12:30 PM Eastern whether to hold the meeting, based on submitted topics, active blockers, recent test results, or time-critical decisions. Cancellation is announced in `#commissioning-analysis` and through the calendar invitation.

## Format/contents for updates
* Topic/activity:
* Analyst/Presenter:
* SME/stakeholders: (analyst identifies people/groups that should review the result)
* Status: Green / Yellow / Red
* Progress since last report:
* Key result:
* Evidence/plot: (example: screencap from jupyter and paste into Confluence.)
* Interpretation:
* Decision needed: (as relevant)
* Blocker:
* Next step, owner, and due date: (may be recorded by the notetaker based on discussion)
* Code/repository path:
* Data/product identifier:
* Briefing recommendation:

## During meeting
* The OuterSpace page is screen-shared during the analysis meeting; analysts should not prepare separate presentation slides. Selected content may subsequently be incorporated into the 2 PM briefing slides.
* Analysts give ~2 minute verbal summaries
* Discussion across group (analysts, SMEs) for each summary
* Please use the Teams chat to drop any links other relevant information without interrupting the flow; notetaker will sweep those up into the meeting notes. Current recommendation is to use the Teams chat. This will not be accessible outside the meeting context, but having all of this information on Slack may lose context and congest the channel. Please notify if you would prefer Slack here. 
* Designated notetaker annotates the Confluence with all discussion points including bold for key areas. Records observations, interpretations, decisions, blockers, and action items, including an owner and due time for each action. Items intended for the 2 PM briefing are clearly marked.
* The meeting normally ends technical discussion by 1:50 PM. The final ten minutes are used to confirm decisions, action items, and the bullets and plots for the 2 PM briefing. 
* Send Slack message with link to outerspace page when notes are complete. Notes are complete when each agenda item has a status, key result, decisions, action owners and deadlines, relevant links, and an indication of whether it should be reported at the 2 PM briefing.

## Recording/Reporting out
* Briefing liaison compiles bullets and images for commissioning meeting slides at 2 PM.
* The analyst or designated documentation owner updates persistent documentation in the `RST_commissioning` repository. Activity-specific documentation belongs under `activities/` by CAR. Broadly applicable material belongs under `docs/`.
* The weekly notes will be rolled up into a summary for status for each Activity/CAR: Findings, Decision/Rationale, Owner, Follow-up needs, as relevant: Link to weekly notes and repository documentation.
