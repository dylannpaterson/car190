# Obtaining Commissioning Data

WFI Data is available quickly after downlink once it has been processed. Data is available up to at least Level 1 and Level 2.


## Data Discovery

To obtain data you need to learn what data is currently available. The purpose of this step is to locate the exact file names of data that you need. 

You do this with a MAST API query. You must use `astroquery` to search for data. The MAST search portal is not available during commissioning but will be available afterwards. 

### Setting API Token

You can search for commissioning data using `astroquery`. Because commissioning data has limited access you first have to set your API Token so that MAST knows you have permission to access the files. 

#### 1. Obtain Token

Go to [https://auth.mast.stsci.edu/info](https://auth.mast.stsci.edu/info) to get your API Token set up and follow the instructions. You will need to regenerate your API Token every 60 days. 

#### 2. Set API Token to an environment variable.

Once you have your Token, you need to set it to an environment variable in your machine. If you are using your local machine you should set this in your user profile. This might be `~/.bash_profile`, `~/.bashrc`, `~/zshrc` depending on your Operating System. Add the following line to your profile

`export MAST_API_TOKEN='your_alpha_numeric_API_token_goes_here'`

Replace `your_alpha_numeric_API_token_goes_here` with your API Token.

To access the TOKEN inside of a notebook you can use 

```python
import os
os.getenv("MAST_API_TOKEN")
```

Make sure you don't share any files with this key exposed as it will give anyone access to the data. 

If you are using the Roman Research Nexus, you should update your token differently. In a terminal create a `.env` file in your home directory, add in the API key as above. 

`echo "export MAST_API_TOKEN='your_alpha_numeric_API_token_goes_here'" >> ~/.env`

From the terminal execute 

`chmod 600 ~/.env`

to ensure that only you can read your `.env` file. To use the token from your notebook you can use

```python
from dotenv import load_dotenv

load_dotenv(os.path.join(os.getenv("HOME"), ".env"))
os.getenv("MAST_API_TOKEN")
```
### Set up your MAST query

Below we set up a MAST query object, and ensure that it will use datasets from the cloud. 

```python
# If using RRN execute next two lines, otherwise you can comment them out
from dotenv import load_dotenv
load_dotenv(os.path.join(os.getenv("HOME"), ".env"))

import os
from astroquery.mast import MastMissions, Observations
mast = MastMissions(mission='Roman')
mast.login(token=os.getenv('MAST_API_TOKEN')) 
Observations.enable_cloud_dataset()
```

### Searching MAST for groups of files

Now you can discover the data. There are lots of astroquery tutorials available on RRN and online, but here is a brief example

```python
search = {'productLevel': 2, 'detector': 'WFI06', "program":1020}
col_list = ['program', 'execution_plan', 'pass', 'segment', 'visit', 'observation', 
            'optical_element', 'exposure_type', 'instrument_name', 'detector', 'productLevel', 
            'product_type', 'exposure_time', 'exposure_start_time', 'exposure_end_time',
            'fileSetName', 'program']
results = mast.query_criteria(**search, select_cols=col_list)
results.sort('exposure_start_time')
```

`results` is now an `astropy.table.Table` object which has all of the filenames of the groups of data products that met your criteria.

### Finding associated files

For each line in the `results` table there may be several files associated. Here is an example of the number of files associated with each dataset.


|    | dataset                              | filename                                         | file_suffix   |      size |
|---:|:-------------------------------------|:-------------------------------------------------|:--------------|----------:|
|  0 | r0102001002001001001_0001_wfi06_f062 | r0102001002001001001_0001_wfi06_f062_segm.asdf   | _segm         |  67466540 |
|  1 | r0102001002001001001_0001_wfi06_f062 | r0102001002001001001_0001_wfi06_f062_cat.parquet | _cat          |    285101 |
|  2 | r0102001002001001001_0001_wfi06_f062 | r0102001002001001001_0001_wfi06_f062_uncal.asdf  | _uncal        | 530906185 |
|  3 | r0102001002001001001_0001_wfi06_f062 | r0102001002001001001_0001_wfi06_f062_cal.asdf    | _cal          | 214103833 |
|  4 | r0102001002001001001_0001_wfi06_f062 | r0102001002001001001_0001_wfi06_f062_wcs.asdf    | _wcs          |     49598 |
|  5 | r0102001002001001001_0001_wfi06_f062 | r0102001002001001001_0001_wfi06_f062_preview.png | _preview      |   2134775 |
|  6 | r0102001002001001001_0001_wfi06_f062 | r0102001002001001001_0001_wfi06_f062_thumb.png   | _thumb        |    105135 |
|  7 | r0102001002001001001_0001_wfi06_f062 | r0102001002001001001_1_wfi06_f062_gw.asdf        |               |   4111520 |
|  8 | r0102001002001001001_0001_wfi06_f062 | r0102001002001001001_1_f062_face.asdf            |               |      6644 |
|  9 | r0102001002001001001_0001_wfi06_f062 | roman_wfi_apcorr_0034.asdf                       |               |     46854 |
| 10 | r0102001002001001001_0001_wfi06_f062 | roman_wfi_dark_0613.asdf                         |               | 201330648 |
| 11 | r0102001002001001001_0001_wfi06_f062 | roman_wfi_darkdecaysignal_0001.asdf              |               |      2769 |
| 12 | r0102001002001001001_0001_wfi06_f062 | roman_wfi_distortion_0017.asdf                   |               |     11332 |
| 13 | r0102001002001001001_0001_wfi06_f062 | roman_wfi_epsf_0168.asdf                         |               | 178223714 |
| 14 | r0102001002001001001_0001_wfi06_f062 | roman_wfi_flat_0140.asdf                         |               | 200543053 |
| 15 | r0102001002001001001_0001_wfi06_f062 | roman_wfi_gain_0037.asdf                         |               |  67125006 |
| 16 | r0102001002001001001_0001_wfi06_f062 | roman_wfi_integralnonlinearity_0008.asdf         |               |  16917298 |
| 17 | r0102001002001001001_0001_wfi06_f062 | roman_wfi_inverselinearity_0051.asdf             |               | 469765020 |
| 18 | r0102001002001001001_0001_wfi06_f062 | roman_wfi_linearity_0045.asdf                    |               | 469765006 |
| 19 | r0102001002001001001_0001_wfi06_f062 | roman_wfi_mask_0024.asdf                         |               |  67110702 |
| 20 | r0102001002001001001_0001_wfi06_f062 | roman_wfi_photom_0044.asdf                       |               |      3473 |
| 21 | r0102001002001001001_0001_wfi06_f062 | roman_wfi_readnoise_0040.asdf                    |               |  67166406 |
| 22 | r0102001002001001001_0001_wfi06_f062 | roman_wfi_refpix_0027.asdf                       |               | 440420820 |
| 23 | r0102001002001001001_0001_wfi06_f062 | roman_wfi_saturation_0020.asdf                   |               | 134219929 |

To get the file names at the same time as reducing the table use the following, where I subset to just the calibrated products.

`products = mast.filter_products(mast.get_unique_product_list(results), file_suffix='_cal')`

`products` is an astropy table which contains all the files you may need for your analysis. The filenames will look similar to

`r0102001002001001001_0001_wfi06_f062_cal.asdf`

You should now have a list of filenames you want to access

## Accessing Data

You have now obtained a list of the exact files you want to access. If you want to download the data to your local machine you can simple search the MAST API for the data using a link, e.g. 

[https://mast.stsci.edu/search/roman/api/v0.1/retrieve_product?product_name=r0102001002001001001_0001_wfi06_f062_cal.asdf](https://mast.stsci.edu/search/roman/api/v0.1/retrieve_product?product_name=r0102001002001001001_0001_wfi06_f062_cal.asdf)

For this to work from a browser, you must be signed into MAST, because that is how it ensures you have access rights to the data.

If you want to download the data to your local machine using Python, you could do a request and sign it with your MAST_API_TOKEN

```python
import requests
import os
resp = requests.get("https://mast.stsci.edu/search/roman/api/v0.1/retrieve_product?product_name=r0102001002001001001_0001_wfi06_f062_cal.asdf", headers={'Authorization':f"token {os.getenv('MAST_API_TOKEN')}"})
```

but this will redownload the file every time you open it. If you do this, you can open the file using

```python
import asdf
af = asdf.open(io.BytesIO(resp.content))
```

If you want to use the data inside the Roman Research Nexus, things are more complicated. 

The data lives in the cloud inside an **S3 Bucket**, which is an AWS location to store data. **Commissioning data lives in a private bucket** and so you can not access the bucket, or list what is inside it, even if you have the API token discussed above. Science data will live in a public bucket, after commissioning. 

To grant anyone access to the data within the RRN without having credentials for the S3 bucket itself, MAST is providing us with signed URLs. This access method does not download data, and instead lets you have access to bytes within the data from the RRN. 

#### What is a signed URL?

Normally to access data in the cloud you must have credentials to show AWS you have file permissions, this includes an access token and key. We do not have those. Instead, MAST provide us for any given file name a "signed" URL, which is a long URL with a hugh hash key in it which tells AWS you have permission to access the file. Once you have a signed URL, you can access that particular file, meaning you can download it, or you can open it and access the bytes inside, but you can not move or destroy it.

Signed URLs give anyone access to that file, so if you share it, anyone anywhere in the world could obtain the data.

Because of this, it is crucial to security that signed URLs **expire**. Currently they expire in a low number of minutes.

#### How do we get a signed URL?

Signed URLs are provided by DAAPI, which is the MAST Roman Data Access API. To get a signed URL you must show DAAPI that you have the API token we set up above, DAAPI checks you're part of the team that can access commissioning data, and will then return you a signed URL. You then 

#### How do we use a signed URL?

You use the signed URL in place of the file location in AWS, but you have to use it before the URL expires.

### 1. Obtaining a Signed URL using requests

Obtaining the signed URL requires going to DAAPI, and here we'll do that with the `requests` library. Below we visit the MAST search API, request to retrieve the product by its file name, and then get the response back.

```python
fname = 'r0102001002001001001_0001_wfi06_f062_cal.asdf'
headers = {}
headers["Authorization"] = f"token {os.getenv('MAST_API_TOKEN')}"
resp = requests.get(f'https://mast.stsci.edu/search/roman/api/v0.1/retrieve_product?product_name={fname}',
                    headers=headers,
                    allow_redirects=False)
```

The signed URL is in `resp['Location]`. Remember this URL will work for anyone, so you shouldn't share the returned URL with anyone. 

### 2. Reading the data from the bucket

To read the data, ensure you import `fsspec` and `asdf` at the top of your notebook

```python
import fsspec
import asdf
fs = fsspec.filesystem("https")
```

Then you can get the data via the signed URL using

```python
with fs.open(resp.headers['Location'], "rb") as f:
    with asdf.open(resp.headers['Location']) as af:
        print(af.info())
```

If this gives you an access error, your URL may have expired.

This method lets you access the bytes without copying the file to your local machine or home area in RRN. This method is still fairly slow in RRN, but we're working with MAST to see if we can speed it up. 

### 3. Using MAST updated `astroquery` for rolling these steps up together. 

From the RRN, if you install this version of `astroquery`

```
pip install git+https://github.com/snbianco/astroquery.git@2026.2
```

You will have access to the `read_product` method which will let you do the above steps in one line. Using your mast search from above you can run

```python
fname = 'r0102001002001001001_0001_wfi06_f062_cal.asdf'
af = mast.read_product(fname)
```

which will return the `asdf` file object.


# Known Data Inconsistencies [try to keep changelog up to date!]

- [2026-09-16] WFI Level 2 WCS are currently **incorrect** and will be 
