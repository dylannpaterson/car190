## Cost-Aware Workflow Design on Roman SMDC Clusters

**Last reviewed: October 26, 2026**  
**Scope:** This guide gives practical recommendations for reducing storage, data-transfer, and workflow-related compute costs when working on the Roman SMDC AWS environment.

This guide is intended for SMDC users who run analysis, development, or pipeline workflows on the SMDC clusters.

Some common workflows on SMDC can generate unnecessary AWS charges, especially when they:

- move data across regions
- repeatedly scan or edit many files through mounted S3-backed paths under `/mnt/`
- leave VS Code sessions open against mounted directories
- run Slurm jobs directly against mounted S3-backed storage rather than staging data locally when local staging would be more efficient

The goal of this guide is to help you choose workflows that are both efficient and cost-aware.

### Keep compute and data in the same region

When possible:

- run your compute in the same AWS region as the S3 bucket you are reading from or writing to
- avoid repeated cross-region transfers for large datasets
- if you regularly need data from another region, ask whether the data should be replicated closer to your compute

### Prefer direct S3 tools for data transfer

If your task is mainly:
- uploading
- downloading
- syncing
- staging data for a job

Prefer direct S3 tools such as the AWS CLI, `boto3`, `s5cmd`, and `rclone`. These are generally more explicit and more cost-efficient than treating mounted S3-backed paths as if they were ordinary local storage.

### Be careful with mounted S3-backed paths under `/mnt/`

The `/mnt/<bucket-name>` paths are convenient, but they should not always be treated like ordinary local storage.

In particular, avoid using mounted S3-backed paths for:

- recursive scans such as `find` or `ls -R`
- repeated metadata-heavy operations over large directory trees
- workflows that read or rewrite very large numbers of small files
- long-running interactive editing sessions over large mounted workspaces

Mounted S3-backed paths are best used when:

- you need convenient file-style access
- you are browsing or inspecting a limited number of files
- you are sharing data in a way that benefits from a mounted interface

### For many small files, copy local first

If your workflow needs to process many small files — for example, files on the order of a few KB to a few hundred KB each — especially in large numbers:

- copy the data to node-local storage first
- run the workflow locally on the compute node
- sync the final results back to S3

This is usually more efficient and more cost-aware than processing many small files directly through `/mnt/`.

### Stage Slurm job data to local scratch

For large or repeated job I/O:

- stage input data to local scratch such as `/tmp` or `/scratch` at the start of the job
- run the pipeline locally on the compute node
- sync results back to S3 at the end of the job

### Avoid putting Slurm logs on mounted S3-backed paths

For long-running or verbose jobs:

- keep `--output` and `--error` logs on your home directory, other NFS-backed storage, or local scratch.
- avoid frequently writing new or updated log files directly to mounted S3-backed paths such as `/mnt/<bucket-name>`.

See the [**Roman SMDC FAQ**](https://github.com/RomanSpaceTelescope/RST_commissioning/blob/main/docs/Roman-SMDC-FAQ.md) for examples of how to set `--output` and `--error` in your Slurm scripts.

### Use VS Code carefully with `/mnt/`

VS Code Remote can generate a lot of background file activity:

- file watching
- indexing
- search
- Git scanning
- explorer tree traversal

If your workspace is rooted in `/mnt/<bucket>`, or if your workspace includes symlinks that point into directories under `/mnt/`, this background activity can become expensive.

### Recommended practice

- do not open `/mnt/` or `/mnt/<bucket>` as your main VS Code workspace root unless necessary
- work in a local or home-directory workspace when possible
- pull only the files you need
- push results back with direct S3 tools

Also check for symlinks. If your home directory contains symlinks into `/mnt/`, opening your home directory in VS Code can still trigger background activity against mounted S3-backed paths.

If needed, exclude `/mnt/` and any symlinked paths from:

- file watching
- search
- explorer visibility

Example VS Code settings:
```json
{
    "files.watcherExclude": {
      "/mnt/**": true,
      "${userHome}/<pathNamePattern1>": true,
      "${userHome}/<pathNamePattern2>": true
    },
    "files.exclude": {
      "/mnt/**": true,
      "${userHome}/<pathNamePattern1>": true,
      "${userHome}/<pathNamePattern2>": true
    },
    "search.exclude": {
      "/mnt/**": true,
      "${userHome}/<pathNamePattern1>": true,
      "${userHome}/<pathNamePattern2>": true
    }
}
```

### Use `tmux` to preserve sessions instead of holding idle compute allocations
If your goal is only to survive disconnects:  
- use `tmux` on the login node
- reconnect and reattach later

Do not hold a compute allocation open just to preserve a terminal session unless you actually need the compute resources.

### Use compute nodes, not login nodes, for heavy transfers when the transfer is large or long-running

For large file-transfer or data-staging operations:

- use a compute node rather than a login node
- avoid running heavy transfer workflows on shared login infrastructure
- when appropriate, reuse an already allocated compute node for related transfer or staging tasks instead of starting additional nodes unnecessarily.

### Use `rsync` selectively

`rsync` is a good option for:  
- source code
- scripts
- notebooks
- configuration files
- ordinary home-directory content

For very large datasets, many-small-file trees, or large software environments, other approaches such as direct S3 tools, shared environments, or packaged environments may be more efficient.

### Ask when a workflow is going to be large or repetitive

If your workflow does any of the following:  
- moves large datasets repeatedly
- runs across regions
- scans large mounted directory trees
- uses VS Code heavily against `/mnt/`
- launches many jobs against the same shared data

ask the infrastructure team whether there is a more cost-efficient pattern.

## If you only remember a few rules, remember these:

- **Same region:** Keep compute and data in the same region.
- **Direct Transfers:** Prioritize direct S3 tools for file transfers.
- **Minimize Metadata Overhead:** Avoid metadata-heavy workflows on `/mnt/`.
- **Scratch Staging:** Stage job data to local scratch space.
- **Cleanup Regularly:** Delete no longer needed files, including Slurm logs.
- **Workspace Considerations:** Do not use `/mnt/` as a large VS Code workspace.
- **Compute Nodes:** Run heavy transfers on compute nodes, not login nodes.

*If you are uncertain about the costs, please reach out to the system administrators for help.*
