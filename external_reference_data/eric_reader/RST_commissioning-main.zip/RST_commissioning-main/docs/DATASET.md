# Creating and Uploading `DATASET.yaml` Manifests

Each dataset or working-data area in S3 should include a small `DATASET.yaml` file describing what the data are, who owns them, the current status, and a short summary of findings.

The goal is that someone browsing S3 later can answer:

- What is this?
- Why does it exist?
- Who owns it?
- Is it current / usable?
- What are the files or subdirectories?

These yaml files can also be aggregated and rendered onto a static webpage which could also compile information such as the directory listing and total size.

This workflow assumes:

- You are working in a JupyterHub environment.
- The environment has the AWS CLI configured.
- S3 is **not** mounted as a filesystem.
- Your code and `DATASET.yaml` live in a git repository.
- You want to upload outputs and a copy of `DATASET.yaml` to an S3 prefix.

Recommended S3 layout for commissioning work:

```text
s3://roman-s3-romcom/activities/car-174-dark-attenuation/car-174-dark-attenuation-mosaics/
```

Note that a single CAR can have multiple dataset IDs under it, here `car-174-dark-attenuation-mosaics` but there could be `car-174-dark-attenuation-mosaics_run1` or other products. The dataset ID should have the CAR number and short descriptor (car-174-dark-attenuation) and the specific tag for that dataset (mosaics).

There are two example DATASET.yaml files in `docs/`: `DATASET_commissioning_minimal.yaml` (required data) and `DATASET_commissioning_maximal.yaml` (examples of additional structure if you want to include that or find it useful)


Only `points_of_contact.owner` is required. Other contacts can be added if useful:
* Owner: the team or role responsible for the dataset's existence, lifecycle, retention, and deletion.
* POC: the person/role/channel most likely to answer "what is this, can I use it, is it current?"
* Technical contact: knows how the files were generated.
* Archive/contact: handles MAST or SOC reference file or delivery mechanics, as relevant
* Backup contact: useful during commissioning when people rotate.


## Suggested local repo layout

For example:

```text
activities/car-174-dark-attenuation/
  DATASET.yaml
  README.md
  mosaic.asdf
```

## Method 1: Adding the DATASET.yaml to your analysis through the terminal

Check that you can see the bucket:

```bash
aws s3 ls s3://roman-s3-romcom/
```
Can also query your identity if there are issues with `aws s3`: 
```bash
aws sts get-caller-identity
```

S3 does not have real directories. The "directory" is created when objects are uploaded under that prefix.

```bash
aws s3 cp DATASET.yaml "s3://roman-s3-romcom/activities/CAR-174-dark-attenuation/car-174-dark-attenuation-mosaics/" 
```

If you want to copy a directory like `outputs/` from your local disk to the S3 repo:
```bash
aws s3 sync outputs/ "s3://roman-s3-romcom/activities/CAR-174-dark-attenuation/car-174-dark-attenuation-mosaics/" 
```

Note that you can do `--dry-run` if you want to see `aws` execute without actually copying the file.

Check the result:

```bash
aws s3 ls "s3://roman-s3-romcom/activities/CAR-174-dark-attenuation/car-174-dark-attenuation-mosaics/" --recursive
```

You could define `s3://roman-s3-romcom/activities/CAR-174-dark-attenuation/car-174-dark-attenuation-mosaics/` or similar as environment variables if that facilitates the command line.

## Method 2: Adding the DATASET.yaml to your output files procedurally 

See `notebooks/s3_dataset.ipynb`
