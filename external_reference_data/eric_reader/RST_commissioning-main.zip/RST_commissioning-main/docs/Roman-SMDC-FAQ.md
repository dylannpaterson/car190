## Roman SMDC FAQ

**Last reviewed: October 26, 2026**  
**Validity notice:** This document reflects the SMDC Roman environment and procedures as understood on the review date above. The information is believed to be accurate at that time, but SMDC systems, policies, software availability, access methods, and costs may change without notice. Accuracy after the review date is not guaranteed, and users should confirm critical details with current SMDC documentation or administrators before relying on them.


### Table of Contents

1. [**Getting Started**](#getting-started)
   - [General workflow](#what-is-the-general-workflow-for-processing-data-on-the-smdc)
   - [Logging in](#how-do-i-log-in-to-a-cluster)
   - [Choosing a region](#which-aws-region-should-i-use)
   - [Identifying your shell](#how-do-i-know-which-shell-i-am-in)
   - [Preserving sessions with `tmux` or `screen`](#i-lost-my-shell-because-of-a-vpn-or-network-interruption-how-can-i-recover-it)
   - [Using VS Code](#i-am-using-vs-code-to-access-a-compute-node-but-the-connection-drops-when-i-step-away-what-can-i-do)
2. [**Batch Computing with Slurm**](#batch-computing-with-slurm)
   - [Choosing between `salloc`, `srun`, and `sbatch`](#when-should-i-use-salloc-srun-or-sbatch)
   - [Using `salloc`](#how-do-i-use-salloc)
   - [Using `srun`](#how-do-i-use-srun)
   - [Using `sbatch`](#how-do-i-use-sbatch)
   - [Managing Slurm log files](#how-do-i-manage-slurm-log-files)
   - [Troubleshooting node provisioning](#i-have-not-been-able-to-get-a-node-with-salloc-what-can-i-do)
   - [Memory limits and out-of-memory termination](#will-ubuntu-terminate-a-job-before-it-exhausts-memory-and-destabilizes-a-node)
3. [**Data Volumes and Directories**](#data-volumes-and-directories)
   - [Important data volumes](#what-are-the-important-data-volumes-and-what-are-they-used-for)
   - [Where to place analysis results](#where-can-i-place-my-analysis-results)
   - [Where to store shared scripts](#where-should-shared-scripts-or-software-be-placed)
4. [**Managing Software Packages**](#managing-software-packages)
   - [Load software packages](#how-do-i-load-software-packages)
   - [Python package and environment management](#how-do-i-manage-python-packages-and-python-environments-on-smdc)
   - [Conda setup](#how-do-i-set-up-a-conda-environment)
   - [Package-import performance](#my-python-package-loading-is-too-slow-how-can-i-speed-it-up)
5. [**Setting Up Analysis and Development Environments**](#setting-up-analysis-and-development-environments)
   - [VS Code and Jupyter](#how-can-i-set-up-analysis-or-development-environments)
   - [VS Code fails to connect](#my-native-terminal-ssh-works-perfectly-but-vs-code-fails-to-connect-and-shows-an-error-like-warn-platform-is-undefined-or-failed-to-parse-remote-port-how-do-i-fix-it)
   - [Containers](#how-do-i-run-containers-on-smdc-clusters)
   - [Engineering database access](#can-i-access-engineering-database-data-from-smdc)
6. [**Research and Engineering Studio (RES)**](#research-and-engineering-studio-res)
   - [What RES is](#what-is-the-research-and-engineering-studio-and-how-does-it-work-with-the-smdc)
   - [Instance creation](#is-it-possible-to-create-my-own-res-instances)
   - [SSH/SFTP access](#can-i-ssh-or-sftp-directly-to-the-res-machines)
   - [Storage and S3 availability](#are-the-s3-mounts-accessible-from-res)
7. [**Working with S3 Buckets**](#working-with-s3-buckets)
   - [Organization and access control](#how-should-an-smdc-s3-bucket-be-organized)
   - [Mounted S3-backed paths](#how-do-mounted-s3-backed-paths-behave-on-smdc)
   - [Bucket names, S3 URIs, prefixes, and mounted paths](#what-is-the-bucket-url-or-name-i-need-to-use-to-connect)
   - [Direct access versus mounts](#should-i-use-the-mounted-path-or-access-s3-directly)
   - [Read and write S3 objects from Python](#how-do-i-read-and-write-s3-objects-from-python)
   - [What happens if I upload the same file again?](#what-will-happen-if-i-upload-the-same-file-again)
   - [Small-file batching](#do-i-still-need-to-batch-small-image-and-log-files)
   - [Visibility, overwrite, versioning, and deletion](#if-i-upload-a-file-via-the-aws-cli-or-cyberduck-will-it-instantly-appear-on-the-cluster-mount)
   - [ROMCOM access](#how-do-i-write-to-the-romcom-s3-bucket)
   - [High-throughput transfers](#how-do-i-maximize-file-transfer-speed-for-large-volumes-of-data)
8. [**Working with Shared Network Drives**](#working-with-shared-network-drives-nfs-mounts)
   - [NFS vs. S3](#what-should-i-use-the-nfs-drives-for-vs-s3-buckets)
   - [Performance issue](#why-are-my-pipeline-jobs-running-slowly-on-the-nfs-drive)
9. [**How can I help reduce costs?**](#how-can-i-help-reduce-costs)
10. [**Miscellaneous and Support**](#miscellaneous-and-support)
   - [Image visualization](#how-do-i-visualize-images-without-res)
   - [File sync between clusters](#how-do-i-sync-my-files-between-the-us-east-1-and-us-east-2-clusters)
   - [AWS console access](#do-i-need-aws-console-access)
   - [Finding more info](#where-can-i-find-more-information-about-working-on-the-smdc)
   - [Getting support](#where-can-i-get-help)


---

# Getting Started

## What is the general workflow for processing data on the SMDC?

The general workflow is:

1. Log in to the appropriate regional cluster.
2. Keep source code, configuration files, and lightweight environment setup on an appropriate shared file system.
3. Submit computational work to Slurm rather than running it on the login node.
4. Read large inputs from S3, preferably using an AWS-native interface for production workflows.
5. Use node-local storage such as `/tmp` or `/scratch` for temporary, performance-sensitive work when appropriate.
6. Write final results and other durable products to an SMDC S3 bucket, preferably through an AWS-native interface.

Choose the Slurm command according to the type of work:

- Use `salloc` when you need an interactive compute node for exploration, debugging, development, or manual testing.
- Use `srun` for a short synchronous command or to open an interactive shell without first creating a separate allocation.
- Use `sbatch` for unattended, long-running, repeatable, or production work. It is generally the preferred approach for pipelines and jobs that should continue after you disconnect.

**Warning:** Do not run computationally intensive software on login nodes. Login nodes have limited shared resources, and heavy work can affect other users or make the node unstable.

See [**Batch Computing with Slurm**](#batch-computing-with-slurm) for command examples.

## How do I log in to a cluster?

Send the public SSH key from your local machine to an SMDC administrator. Once access has been provisioned, use `ssh` to connect to a login node.

- Roman SMDC `us-east-1`: `hpc-east-1.roman.sciencecloud.nasa.gov`
- Roman SMDC `us-east-2`: `hpc-east-2.roman.sciencecloud.nasa.gov`

Login procedures may change. Confirm current access requirements with the SMDC administrators if these instructions no longer work.

## Which AWS region should I use?

Choose the region by considering data locality, compute-node availability, node type, provisioning time, and cost.

Use `us-east-1` when:

- Your program needs to stream a large amount of data from the SOC or the `roman-science` S3 bucket.
- The compute-node types required by your workflow are available there.
- Avoiding cross-region data transfer is important.

Consider `us-east-2` when:

- Your primary data is already hosted in `us-east-2`.
- You cannot provision a suitable compute node in `us-east-1`.
- You need a node type that is unavailable or less prevalent in `us-east-1`.
- Provisioning is faster for the resources you need.

*The RST Science Infrastructure Primer* contains current or planned node-type information for each region [5](https://outerspace.stsci.edu/spaces/IWG/pages/413204740/RST+Science+Infrastructure+Primer).

Cross-region charges may apply when, for example:

- Software running in `us-east-2` reads data from the SOC or `roman-science`.
- Software running in `us-east-1` reads data from `roman-science-east-2` or `roman-science-internal`.

Uploading data to an S3 bucket does not normally incur data-egress charges, although other AWS storage or request charges may apply.

For large workloads, estimate both compute and data-transfer costs before selecting a region. Refer to **Roman SMDC Cost-Aware Workflow Design** [12](https://github.com/RomanSpaceTelescope/RST_commissioning/blob/main/docs/Roman-SMDC-cost-aware-workflow-design.md) for cost considerations.

## How do I know which shell I am in?

Look at your terminal prompt.

- A prompt containing a hostname such as `ip-xx-xx-xx-xx` is likely a login node.
- A prompt beginning with a node-type name such as `mem-int-dy-r6i-xx-x` is likely a compute node.

If uncertain, you can inspect the hostname.

The following command displays the current hostname:

```bash
# Print the hostname of the current login or compute node.
hostname
```

## I am using VS Code to access a compute node, but the connection drops when I step away. What can I do?

Create the allocation with the `salloc --no-shell` option so the allocation remains active independently of an interactive allocation shell.

The following example creates a one-hour background allocation:

```bash
# Request a compute node without attaching the allocation to an interactive shell.
salloc --time=01:00:00 --no-shell
```

After the node is provisioned, connect VS Code to the allocated node as described in the SMDC VS Code and Jupyter setup documentation [2](https://github.com/RomanSpaceTelescope/RST_SMDC_users/blob/main/documentation/run-jupyter-notebook.md).

The allocation continues until its time limit expires or you cancel it. Remember to release it when finished.

The following commands locate and cancel the allocation:

```bash
# Display your active Slurm jobs and allocations.
squeue --me

# Replace <job_id> with the allocation's Slurm job ID.
scancel <job_id>
```
## My native terminal SSH works perfectly, but VS Code fails to connect and shows an error like WARN: $PLATFORM is undefined or Failed to parse remote port. How do I fix it?

This happens when local network rules, firewalls, or security profiles block VS Code's internal background communication helper. Follow the steps below for the fix:
1. Change the VS Code Setting:
- Open the VS Code Setting (Cmd+, on Mac or Ctrl+, on Windows).
- Search for `Remote.SSH: Use Local Server`.
- Uncheck the box next to it.
2. Close VS Code completely.
3. Restart your computer to flush any frozen background connection processes.
4. Reconnect: Open VS Code and connect to the server normally.

## I lost my shell because of a VPN or network interruption. How can I recover it?

Start a `tmux` or `screen` session immediately after logging in, and perform your terminal work inside that session. After reconnecting to the same host, reattach to the session.

This is especially useful for preserving the login-node shell and terminal-based workflows. It can also preserve a compute-node shell when you connect directly to that node by SSH.

See the `tmux` guide [7](https://github.com/tmux/tmux/wiki) and `screen` documentation [8](https://www.gnu.org/software/screen/).

A terminal multiplexer does not preserve a compute allocation after the allocation expires or is cancelled.

---

# Batch Computing with Slurm

## When should I use `salloc`, `srun`, or `sbatch`?

| Command | Best suited for | Interaction model | Typical example |
|---|---|---|---|
| `salloc` | Interactive development, debugging, and exploratory analysis | Reserves resources, after which you connect to or work on the allocated node | Testing commands manually |
| `srun` | Short synchronous commands or quickly opening a compute-node shell | Waits for the command and displays its output in the current terminal | Running a short test script |
| `sbatch` | Long-running, repeatable, unattended, or production jobs | Submits a script and returns a job ID | Pipelines, arrays, and scheduled processing |

In general:

- Use `salloc` while developing or diagnosing a workflow.
- Use `srun` for a short operation when you want immediate output.
- Use `sbatch` once the workflow is stable or needs to continue without an active terminal.

Slurm behavior and available options are documented by the Slurm Workload Manager [6](https://slurm.schedmd.com/documentation.html).

## How do I use `salloc`?

The following command requests a compute node from the default partition for one hour:

```bash
# Request an interactive allocation with a one-hour time limit.
salloc --time=01:00:00
```

Always specify a reasonable time limit to avoid leaving compute resources allocated unnecessarily.

`salloc` normally places you directly in an interactive compute-node shell. Typing `exit` inside the interactive shell normally releases the compute node.

You can `ssh` directly to the provisioned compute node from your laptop. Use the following command after replacing the placeholder with the allocated hostname:

```bash
# Connect from the login node to the provisioned compute node.
ssh <provisioned-node-name>
```

Another way to release the compute node: use `squeue` to find the allocation and `scancel` to release it explicitly:

```bash
# Display your current jobs and allocations.
squeue --me

# Explicitly release the selected allocation.
scancel <job_id>
```

## How do I use `srun`?

Use `srun` for a short synchronous operation or to open an interactive compute-node shell.

The following example runs a Python test script on a compute node:

```bash
# Run one Python process with two CPUs and a 15-minute limit.
srun \
    --ntasks=1 \
    --cpus-per-task=2 \
    --time=00:15:00 \
    --partition=mem-int \
    python3 your_test_script.py
```

The following example opens an interactive Bash shell:

```bash
# Allocate resources and attach an interactive Bash shell.
srun \
    --ntasks=1 \
    --cpus-per-task=2 \
    --time=00:30:00 \
    --partition=mem-int \
    --pty bash
```

For longer work, production pipelines, or jobs that should survive a terminal disconnection, use `sbatch` instead.

## How do I use `sbatch`?

`sbatch` submits a shell script to Slurm. Slurm schedules the job on a suitable compute node and writes standard output and error messages to files.

The following script requests one task, four CPUs, 64 GB of memory, and one GPU. Remove the GPU directive when a GPU is not required:

```bash
#!/bin/bash

# Give the job a recognizable name.
#SBATCH --job-name=your_job_name

# Include the Slurm job ID in output and error filenames.
#SBATCH --output=your_job_name_output_%j.log
#SBATCH --error=your_job_name_error_%j.log

# Set an explicit runtime and select an available partition.
#SBATCH --time=HH:MM:SS
#SBATCH --partition=your_partition_name

# Request one task with four CPU cores and 64 GB of memory.
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=64G

# Request one GPU. Remove this directive for CPU-only work.
#SBATCH --gres=gpu:1

# Load or activate the environment required by the program.
conda activate your_conda_env_name

# Run Python without buffered standard output.
python -u your_program.py
```

Submit and monitor the job with these commands:

```bash
# Submit the batch script and obtain a Slurm job ID.
sbatch your_script_name.sh

# Display the current user's queued and running jobs.
squeue --me

# Inspect resource efficiency after the job completes.
seff <job_id>
```

> Useful `sbatch` tips:
- Use absolute paths.
- Record the software or container version.
- Set the working directory explicitly.
- Stage temporary files under `$SLURM_TMPDIR`, `$TMPDIR`, `/tmp`, or `/scratch` only after confirming availability.
- Copy durable outputs to S3 before the job exits.

## Where should I run scripts from?   
Submitting jobs with `sbatch` or `srun` from a login node is recommended. You can also allocate a compute node using `salloc` and run your script from the compute node terminal. 

## I have not been able to get a node with `salloc`. What can I do?

Try another partition.

The following command requests a node from the `mem-int` partition:

```bash
# Request an allocation from a specific partition.
salloc --time=01:00:00 --partition=mem-int
```

Partition names and availability can differ by region and may change. Confirm the current options with `sinfo`.

List available partitions and their state with:

```bash
# Show the partitions and nodes visible to Slurm.
sinfo
```

You can also:

- Request a different node type.
- Reduce excessive CPU, memory, or GPU requests.
- Try the other regional cluster.
- Use `sbatch` and allow the request to remain queued rather than repeatedly cancelling it.
- Review the regional node-type list in the *RST Science Infrastructure Primer* [5](https://outerspace.stsci.edu/spaces/IWG/pages/413204740/RST+Science+Infrastructure+Primer).

## How do I manage Slurm log files?

By default, Slurm generates log files for each job under your current working directory (i.e., where you submit the `sbatch` command). You can explicitly specify the log file path and name using the `--output` and `--error` flags in your sbatch script. Because the number of log files grows with each job execution, accumulating these files over time can significantly increase storage and, depending on where the logs are written, may also increase cost.

To help reduce costs and optimize performance, please consider the following:
- **Disable log files:** If your workflow allows, disable log output entirely by specifying `--output=/dev/null` and/or `--error=/dev/null`.
- **Periodically clean up:** If you need to keep log files for a short period, remember to delete old logs regularly when they are no longer needed.
- **Standardize log names with prefixes:** Use a clear prefix like `slurm-` in your log filenames (e.g., slurm-<your_job_name>-%j.out). This makes it much easier to search for, delete, or archive old logs later.
- **Monitor home directory storage:** Writing runtime Slurm logs directly to S3-mounted paths like `/mnt/<bucket>` is strongly discouraged due to performance degradation and high API costs. Instead, direct your log files to your home directory or local scratch space. If you use your home directory, keep a close eye on your storage quota and delete old logs before space runs out.

You can specify your home directory path in your sbatch script like this:
```bash
#SBATCH --output=/home/<your-username>/slurm-<your-job-name>-%j.out
#SBATCH --error=/home/<your-username>/slurm-<your-job-name>-%j.err
```

- **Archive to S3 properly:** If you need to archive important log files, compress them into a single archive file (e.g., .tar.gz) before uploading them to an S3 bucket.

## Will Ubuntu terminate a job before it exhausts memory and destabilizes a node?

Possibly, but this should not be treated as a guarantee.

Two mechanisms may be involved:

1. **Slurm enforcement:** If Slurm cgroup-based memory enforcement is enabled, a job that exceeds its requested memory may be terminated as an out-of-memory job.
2. **Linux out-of-memory handling:** If the node itself runs out of memory, the Linux kernel may invoke the OOM killer and terminate one or more processes.

The Linux OOM killer is reactive. It does not guarantee that the node or other jobs will remain unaffected. Slurm memory enforcement is the preferable protection, but its exact configuration must be confirmed with SMDC administrators.

Users should:

- Set a realistic `--mem` or `--mem-per-cpu` value.
- Test memory-intensive workflows at small scale.
- Inspect completed jobs with `seff`.
- Avoid unnecessary in-memory copies of large datasets.
- Use job arrays or smaller batches when processing independent files.
- Contact administrators if jobs are causing node instability or are not being terminated cleanly.


---

# Data Volumes and Directories

## What are the important data volumes, and what are they used for?

| Path | Storage role | Recommended use | Important considerations |
|---|---|---|---|
| `/home/$USER` | User home directory, currently NFS-backed | Source code, configuration, shell files, and lightweight user files | Not ideal for large-scale parallel I/O or Conda environments containing many small files |
| `/data` | Shared storage with limited capacity | Short-lived intermediate products | Clear products when no longer needed |
| `/shared` | Shared storage for packages and tools | Shared software, tools, and environment support files | Limited capacity; avoid heavy pipeline data |
| `/efs` | Team collaboration storage | Shared code, collaborative environments, and team resources | Currently network-backed; avoid high-volume concurrent I/O |
| `/mnt/<bucket-name>` | Mounted interfaces to various S3 buckets | See [What should I use the NFS drives for vs. S3 buckets?](#what-should-i-use-the-nfs-drives-for-vs-s3-buckets) for recommended use | Mount behavior may differ from a traditional POSIX file system. Do not assume a user-named prefix is private. Consider regional data-transfer costs |
| `/tmp` | Node-local temporary storage when used on a compute node | Temporary files and staged environments | Data may disappear when the node or job ends |
| `/scratch` | Node-local scratch where available | High-performance temporary job data | Availability and cleanup behavior may vary by node |

*   The mounted `/mnt/...` paths are interfaces to S3-backed storage. Their implementation may vary by region and change over time. Validate file locking, append behavior, metadata visibility, cross-interface consistency, and small-file performance before depending on those behaviors in production.
*   Do not assume that `/tmp` on a login node is appropriate for job staging, shared with a compute node, or retained across node termination.

## Where can I place my analysis results?  
The recommended locations for analysis results are the SMDC S3 buckets:  
- `s3://roman-science`
- `s3://roman-science-east-2`
- `s3://roman-science-internal`

They can be accessed using the S3 API or the directories under `/mnt`.  
Additionally, we recommend that all inputs and outputs flow through S3 buckets, and use shared file-system areas such as `/data` and `/shared` only for intermediate products, and clear them when no longer needed. 

Please see the [**Working with S3 Buckets**](#working-with-s3-buckets) section for more details.

## Where should shared scripts or software be placed?  
For shared scripts or software, `/efs` or `/mnt/roman-science-internal` may be good locations, depending on your team’s access and workflow.

---

# Managing Software Packages

## How do I load software packages?
Some software is installed natively. Check for a native package first.

The following example checks whether *Apptainer* was installed through the operating system package manager:

```bash
# Search installed Debian or Ubuntu packages for Apptainer.
dpkg -l | grep apptainer
```

Other packages are managed by Spack.

For example, use these commands to initialize *Spack* and search for *Conda* distributions:

```bash
# Initialize the shared Spack environment.
source /shared/spack/share/spack/setup-env.sh

# List available Miniforge and Miniconda installations.
spack find miniforge3
spack find miniconda3
```

If only one matching installation exists, an unversioned load may be sufficient:

```bash
# Load Miniforge when Spack finds one unambiguous installation.
spack load miniforge3
```

If multiple versions or builds are installed, Spack may report an ambiguity. In that case, select an installed version shown by `spack find`:

```bash
# Replace the version with one currently reported by Spack.
spack load miniforge3@<installed-version>
```

**Note:** In general, users should select a specific version only when required for reproducibility or to resolve an ambiguous Spack specification.

## How do I manage Python packages and Python environments on SMDC?  
`pip` is installed natively. You can use it immediately to install baseline packages that you use frequently, such as `ipykernel` if you need to run Jupyter notebooks or `boto3` if you stream data from S3 buckets. Make sure to use the `--user` flag so that packages are installed safely in your home directory.  
Python virtual environments (venv) are another option instead of using `pip install --user`.  
For more sophisticated package management, we recommend Conda. 

Installing native and Spack packages requires root privileges, so please contact the system administrators if you need to install packages this way. It is the user's responsibility to manage their own baseline pip packages and Conda environments.  

Additionally, `conda install` isn't limited to Python packages; it can also manage other types of packages available in Conda repositories.  

## How do I set up a conda environment?  
After loading the Miniforge or Miniconda package and saving the Spack setup lines in your `.bashrc` file, run:
```bash
conda init
```
This command automatically appends conda initialization code to your `.bashrc` file. Then log out and log back in. You should see `(base)` in your terminal prompt.

From there, you can create and manage conda environments as usual.

For Miniforge or Miniconda installation and usage instructions, please refer to the *Miniforge documentation* [1](https://github.com/RomanSpaceTelescope/RST_SMDC_users/blob/main/documentation/miniforge.md)

SMDC is not an isolated cluster, so you can access many public repositories on the internet. However, please be aware of Anaconda licensing restrictions and avoid Anaconda channels if you do not have an appropriate license.

Creating shared conda environments is also encouraged to save storage space and make collaboration easier. For example, if shared environments are stored in `/efs/roman_shared/conda_envs/`, you can add that location with:
```bash
conda config --append envs_dirs /efs/roman_shared/conda_envs
```

## My Python package loading is too slow. How can I speed it up?  
It's most likely caused by the type of file system you are using to store the conda environment. By default, Conda installs packages into your home directory, which is mounted as an NFSv4 file system. When Python executes an `import` statement, it scans directories and opens thousands of small package source files. Over a network mount, this creates severe metadata latency that stalls execution — especially as compute jobs scale.

Currently, there may not be a dedicated local drive available to host the environment permanently. To fix this, we recommend wrapping your environment in a container or utilizing local ephemeral storage.

**Solution 1:**  
Use Apptainer Containers (Recommended)  
Containers compress thousands of individual Conda files into a single, optimized image file (.sif). Because the system only opens one file descriptor instead of thousands, network latency is completely bypassed.

See [How do I run containers on SMDC clusters?](#how-do-i-run-containers-on-smdc-clusters) for the workflow.

**Solution 2:**  
Unpack Conda to Local Scratch Space (/tmp or /scratch)  
If you must use an existing Conda environment, pack it into a tarball and unpack it directly onto the fast, local solid-state drives (SSDs) attached to the individual compute node assigned to your job.  

**Workflow:**  
Pack your environment on the login node:
```bash
conda install -c conda-forge conda-pack
conda-pack -n your_env -o /home/your_user_name/your_env.tar.gz
```
Stage and run on a compute node:  
Add these staging steps to your Slurm sbatch script to dynamically copy the environment to the node's local storage:
```bash
#!/bin/bash
#SBATCH --nodes=1

# Create local directory on the assigned node
NODE_TMP="$TMPDIR/$USER/your_local_env"
mkdir -p $NODE_TMP

# Unpack archive from shared storage to local storage
tar -xzf /home/your_user_name/your_env.tar.gz -C $NODE_TMP

# Activate and run your application
source $NODE_TMP/bin/activate
conda-unpack

python your_script.py

# Clean up the node's local storage before exiting
rm -rf $NODE_TMP
```
Please verify that `$TMPDIR` exists on your nodes. If not, use `/tmp/$USER/...` or another node-local scratch path.  

---

# Setting Up Analysis and Development Environments

## How can I set up analysis or development environments?  
Because SMDC clusters are headless, there is no traditional desktop environment by default.

VS Code has been used successfully as a development environment, including for running Jupyter notebooks. See the **VS Code and Jupyter notebook setup documentation** [2](https://github.com/RomanSpaceTelescope/RST_SMDC_users/blob/main/documentation/run-jupyter-notebook.md)

>**Note**: When using VS Code, take care to exclude unnecessary directories — especially mounted S3-backed paths under /mnt/ and any symlinks that point there — from indexing, file watching, and search. This can improve performance and help reduce unnecessary storage-access costs. See **Roman SMDC Cost-Aware Workflow Design** [12](https://github.com/RomanSpaceTelescope/RST_commissioning/blob/main/docs/Roman-SMDC-cost-aware-workflow-design.md) for more details.

Alternatively, a Research and Engineering Studio on AWS (RES) instance can be used as a desktop environment. See [**Research and Engineering Studio on AWS (RES)**](#research-and-engineering-studio-res) for more details.

If you use containers, `apptainer` is available on both the `us-east-1` and `us-east-2` clusters. Because `singularity` is configured as an alias to `apptainer`, you can use either command interchangeably.

You can also consider registering your container in the SMDC Roman Elastic Container Registry (ECR) to streamline container updates and deployment.

## How do I run containers on SMDC clusters?
Use `apptainer`.  
**Workflow:**  
1. Pull and build the image on the login node:
- Log into the cluster and use Apptainer to convert an authorized container image into a local single-file SIF image. For access to the private SMDC Roman ECR registry, contact the SMDC system administrators for the current registry URL and authentication procedure.

The following example pulls an image from a private ECR and creates a local SIF file:
```bash
unset AWS_PROFILE
export AWS_SHARED_CREDENTIALS_FILE=/dev/null
export AWS_CONFIG_FILE=/dev/null
 
export APPTAINER_TMPDIR=/shared/tmp/containers
export APPTAINER_DOCKER_USERNAME=AWS
export APPTAINER_DOCKER_PASSWORD=$(aws ecr get-login-password --region us-east-2)

apptainer pull docker://<authorized-registry>/<repository>/<image>:<tag>
```
- If you transfer a Docker image tarball to the cluster:
```bash
apptainer build your_image.sif docker-archive://your_image.tar
```
**Note:** Once the conversion is complete, you no longer need the bulky tarball. You can delete it to save storage.

2. Execute via Slurm on the Compute Nodes:  
Submit your job to the queue. Apptainer runs entirely in user-space and does not require root/sudo privileges.
```bash
# Inside your sbatch submission script:
srun apptainer exec --cleanenv your_image.sif python your_script.py
```

## Can I access engineering database data from SMDC?

Yes. The CaSSI supplementary telemetry retrieval tutorial in the Roman commissioning repository provides an example [3](https://github.com/RomanSpaceTelescope/RST_commissioning/tree/main/notebooks/CaSSI_supplementary_telemetry_retrieval).

---

# Research and Engineering Studio (RES)

## What is the Research and Engineering Studio, and how does it work with the SMDC?  
Research and Engineering Studio on AWS (RES) is an open-source, web-based portal that administrators can use to create and manage secure cloud-based research and engineering environments.

On SMDC, RES is hosted as an independent EC2 instance. At this time, user management and file systems are configured independently from the SMDC clusters. This may evolve over time.

## Is it possible to create my own RES instances?  
Possibly, if funding is available. This likely depends on administrative policy and available resources.

## Can I SSH or SFTP directly to the RES machines?  
This likely depends on the RES configuration and local policy. You should confirm with the SMDC administrators.

## Are the S3 mounts accessible from RES?  
Not automatically. The mounts on the clusters are not shared with the RES instance by default. An administrator would need to mount them explicitly on the RES system.

---

# Working with S3 Buckets

## How should an SMDC S3 bucket be organized?

S3 uses object-key prefixes rather than real directories. Prefixes can nevertheless be organized in a directory-like structure.

For example:

    s3://roman-science-internal/
    ├── SNe_PIT/
    │   ├── projects/
    │   │   └── source-code/
    │   ├── datasets/
    │   │   └── some-images-v1/
    │   └── logs/
    │       └── year=2026/
    │           └── month=08/
    ├── another_project/
    │   ├── campaigns/
    │   └── assets/
    └── users/
        ├── user-a/
        │   ├── projects/
        │   └── logs/
        └── user-b/

Names such as `SNe_PIT` should reflect recognizable groups, projects, or programs.

The `users/<username>/` convention is for organization and collision avoidance. It must **not** be presented as a privacy or access-control boundary. Unless an applicable bucket policy explicitly guarantees otherwise, users should assume that other authorized users or systems may be able to read objects in these prefixes.

Do not store credentials, secrets, export-controlled information, or otherwise sensitive content solely on the assumption that a user-named prefix is private.

## Where should I put my files?

Store files under an established project, group, or user prefix. Do not place loose objects at the bucket root.

Examples include:

- Project or group work: `/mnt/roman-science-internal/SNe_PIT/`
- User-organized work: `/mnt/roman-science-internal/users/$USER/`

A user-organized prefix is not necessarily private. Access is determined by the S3 bucket and IAM policies, not by the directory-like name.

## How should I organize my files?

Group files according to project and purpose:

- Datasets: `.../datasets/some-images-v1/`
- Source code: `.../projects/source-code/`
- Logs: `.../logs/year=2026/month=08/`
- Job outputs: `.../outputs/job_id=<job-id>/`

Use stable, descriptive names. For logs and generated products, timestamps, job IDs, software versions, or processing versions can simplify provenance and cleanup.

## Should I use the mounted path or access S3 directly?

For production workflows, AWS-native access methods should generally be preferred over ordinary file operations on the mounted path.

Recommended direct-access options include:

- `boto3` or another AWS SDK for application code.
- `s3fs` and `fsspec` when a file-like Python interface is useful.
- `aws s3` for command-line transfers.
- `s5cmd` or `rclone` for large-scale or concurrent transfers.

Direct access is more explicit about buckets and object keys, exposes S3 errors directly, is generally easier to migrate to AWS-native orchestration services, and is often less expensive than mounted file-system access.

Mounted paths remain useful for:

- interactive browsing
- lightweight analysis
- compatibility with software that expects a path
- convenient collaboration and inspection

S3 is an object store, not a traditional file system. Do not assume that mounted S3 storage provides all local or NFS file-system semantics. Validate behavior if your workflow depends on locking, append operations, atomic renames, immediate metadata visibility, or many-small-file performance.

## Can I access SMDC S3 buckets directly, without using the mounted path?
Yes. Direct S3 access is encouraged for robust production workflows and cost-aware data movement.

Available options include:

- Command-line tools: `aws s3`, `s5cmd`, and `rclone`
- Python and other SDKs: `boto3`, `s3fs`, `fsspec`, and other AWS SDKs
- Graphical clients: tools such as Cyberduck, or the AWS Management Console where permitted

Direct access is often preferable when you need:

- explicit control over buckets and object keys
- better performance for large transfers
- more predictable behavior than mounted file-system access
- easier migration to AWS-native orchestration workflows

Mounted paths under `/mnt/...` remain useful for lightweight browsing, inspection, and workflows that benefit from convenient file-style access.

For high-throughput transfer patterns, see the **S3 Data Transfer guide** [10](https://github.com/RomanSpaceTelescope/RST_SMDC_users/blob/main/documentation/S3%20Data%20Transfer.md).


## How do I read and write S3 objects from Python?

Several Python packages can be used to access S3 directly. The most common are `boto3`, `s3fs`, and `fsspec`.  

- Use `boto3` when you want direct, explicit AWS API control.
- Use `s3fs` when you want a file-like interface for S3.
- Use `fsspec` when you want storage-agnostic code that can work across multiple backends.


**Quick Comparison**

| Tool        | Best For                   | Notes                                                                    |
| :---        | :---                    | :---                                                                   |
| `boto3`       | Direct AWS API operations   | Official AWS SDK for Python                                            |
| `s3fs`       | File-like access to S3     | Convenient for data-analysis workflows                                       |
| `fsspec`      | Storage-agnostic workflows | Often used together with s3fs                                          | 

For most data-analysis workflows, `s3fs` is often the most convenient choice. For explicit object management or AWS-specific operations, prefer `boto3`.

## What will happen if I upload the same file again?
If you upload a file using the same S3 key — the same bucket, folder/prefix, and filename — the new upload normally replaces the existing object.

- If bucket versioning is disabled, the previous contents are no longer accessible.
- If versioning is enabled, S3 retains the previous object as an older version [11](https://docs.aws.amazon.com/AmazonS3/latest/userguide/Versioning.html).
- The same filename in a different folder/prefix is a separate object and causes no conflict.
- The mounted `/mnt/...` path may not show the replacement immediately because synchronization and metadata visibility can vary.  

Avoid concurrent uploads to the same key. When multiple successful writes target the same key, one becomes the current object, and applications should not rely on client-observed completion order to resolve the race.

For important data, use unique names, timestamps, or job IDs, or confirm that versioning is enabled before overwriting.

## How do I write to the ROMCOM S3 bucket?  
Currently you can write to the bucket from within RRN, but not directly from SMDC at this time. Writing from SMDC requires MFA support, which is expected to be implemented later.

However, data can be pulled in either direction:  
- systems in SMDC can pull data from the ROMCOM S3 bucket  
- systems in ROMCOM can pull data from SMDC  

Also note that the `roman-science` bucket has broader RRN access, not just ROMCOM access.

## How do mounted S3-backed paths behave on SMDC?
The `/mnt/...` paths provide mounted access to SMDC-managed S3-backed storage. The underlying implementation may vary by region and may change over time as the storage system evolves. In practice, users should expect behavior that is convenient for file-style access but not necessarily identical to a traditional local Linux or HPC file system. Workflow-critical behaviors such as file locking, append support, metadata visibility, and performance under heavy small-file workloads should be validated before production use.

**Recommendation:**  
- Use mounted S3-backed paths for shared data access and collaboration, especially when convenient file-style access is helpful.
- For large-scale data movement, bulk ingest/egress, or high-throughput workflows, direct S3 access through tools such as `aws s3`, `s5cmd`, `rclone`, or SDKs may be more predictable and performant.
- For metadata-heavy workloads, many-small-file workflows, or performance-sensitive pipelines, test carefully before relying on mounted S3-backed paths as if they were local or traditional HPC file systems.
- For temporary job-local scratch work, prefer node-local storage such as `/tmp` or `/scratch` when appropriate.
- If your workflow depends on strict POSIX-like behavior such as file locking, append semantics, or immediate cross-interface visibility, validate that behavior on the target cluster and region before production use.

## Do I still need to batch small image and log files?
**Yes,** batching is still recommended for many workflows. Large numbers of very small files can create significant metadata and synchronization overhead on shared or mounted storage systems. Compressing logs or image outputs into larger archives is often more efficient.

## What is the bucket URL or name I need to use to connect?
You do not use a standard web URL (like `https://...`). You only need the **Bucket Name**, for example:
*   **Bucket Name:** `roman-science-internal`

## What format do I use for accessing a specific folder?
The format depends on whether you are using graphical desktop software or the command line interface:
*   **For AWS CLI or other terminal tools:** Always prefix the name with the S3 protocol URI scheme.
    *   *S3 Path:* `s3://<your-shared-bucket-name>/users/your-username/`
*   **For Cyberduck (Laptop GUI):** Use the plain text name without any prefix.
    *   *Bucket Name:* `<your-shared-bucket-name>/users/your-username/`

## If I upload a file via the AWS CLI or Cyberduck, will it instantly appear on the cluster mount?
Not necessarily. Files uploaded through direct S3 tools such as the AWS CLI or Cyberduck may not appear immediately on the mounted path. Synchronization timing can vary by cluster region and mount implementation. If immediate visibility is important, validate the behavior on the target cluster.  

## If I delete a file on the cluster mount, is it deleted from the S3 bucket?
In normal operation, **yes.** Deleting a file from the mounted path is expected to remove the corresponding object from the S3 bucket. If this behavior is workflow-critical, validate it on the target cluster and region before relying on it.

## How do I maximize file transfer speed for large volumes of data?
Command-line tools such as `aws s3`, `s5cmd`, and `rclone` are recommended. Please see the **S3 Data Transfer Guide** [10](https://github.com/RomanSpaceTelescope/RST_SMDC_users/blob/main/documentation/S3%20Data%20Transfer.md) for more details.

---

# Working with Shared Network Drives (NFS Mounts)

## What should I use the NFS drives for vs. S3 buckets?
NFS (Network File System) and S3 are designed for different workloads. Using the wrong storage location can significantly degrade job performance.

*   **Use NFS for:** active source code, small configuration files, code compilation such as `make`, and small scripts. NFS is generally better suited for random file edits and file-locking workflows. The following directories are currently provided through NFS-mounted file systems, although this may evolve over time:
    - `/data`
    - `/shared`
    - `/efs`
    - `/home/`

*   **Use S3 for:** large, read-only input datasets such as image libraries, large training datasets, and final heavy output or checkpoint files. The currently available SMDC buckets are:
    - `roman-science`: for data shared with the wider Roman community
    - `roman-science-internal`: for in-progress datasets and data that should remain within the SMDC
    - `roman-science-east-2`: (us-east-2 only) for `roman-science` data that should be migrated from US-East-2 to US-East-1
    - `roman-s3-romcom`: Commissioning-only bucket hosted in SOC and writable in RRN. Read-only in SMDC
    - `smdc-rom-com-ops`: (us-east-1 only) Commissioning-only bucket hosted in SMDC and writable. Read-only in RRN.
    - `roman-smdc-gdps-com-dev`: (us-east-1 only) Commissioning-only bucket hosted in SSC's GDPS Commissioning Dev environment. Currently read-only in SMDC and mounted as `/mnt/ssc/com-dev`, but writable in the future.

    - `openuniverse2024`: Open universe is an **IPAC open-data bucket** [13](https://irsa.ipac.caltech.edu/data/theory/openuniverse2024/overview.html) with no egress, based in AWS West.
 
    - `ssc`: Supports interoperability with IPAC for spectroscopy workflows
    - `supernovae`: Reserved for Supernovae Infrastructure Team

    These buckets are all available as file-system mounts in SMDC environments under the path `/mnt/<bucket-name>`, except where otherwise noted.


## Why are my pipeline jobs running slowly on the NFS drive?
While NFS is excellent for standard file operations, it is **not a parallel file system**. If your job forces dozens of compute nodes to read or write massive datasets to the same NFS mount at the exact same time, you will create a network bottleneck that slows down the entire cluster.
*   **The Fix:** Move your heavy inputs and outputs to the S3 bucket. Let NFS strictly handle your orchestration code and environment scripts. 

---

## How can I help reduce costs?

See **Roman SMDC Cost-Aware Workflow Design** [12](https://github.com/RomanSpaceTelescope/RST_commissioning/blob/main/docs/Roman-SMDC-cost-aware-workflow-design.md)

---

# Miscellaneous and Support

## How do I visualize images without RES?

`JS9` is recommended if you prefer an interface similar to DS9. You can also use `Jdaviz` for the SOC products. Please refer to *Image Visualization Tools Setup* [9](https://github.com/RomanSpaceTelescope/RST_SMDC_users/blob/main/documentation/image-visualization-tools-setup.md) for more details.

If you use VS Code, a new extension named `Pixel Clarity` is highly recommended. It works for many image formats, such as FITS, ASDF, HDF5, NPY, and TIF, as well as tabular file formats like Parquet, EcSV, and CSV.

Standalone Python package, `pixel-clarity`, is also available via:
```bash
pip install pixel-clarity
```
Example use:
```bash
import pixel_clarity as pc

pc.show("image.fits")                                       # a file on the server
pc.show("s3://bucket/path/image.asdf")                      # read where it is, no download
pc.show(array, cmap="magma", scale="asinh", limits="99.5")  # an array in the kernel
pc.rgb("red.fits", "green.fits", "blue.fits")               # three filters as color
pc.mosaic("exposure/")                                      # images placed on the sky
pc.table("catalog.parquet")                                 # sorted, filtered and plotted on the server
```


## How do I sync my files between the us-east-1 and us-east-2 clusters?  

For home-directory content such as source code, scripts, notebooks, and configuration files, `rsync` is a good option. It is efficient for incremental synchronization and works well for keeping directories aligned across systems.

For very large datasets, many-small-file trees, or large software environments, other approaches such as S3-native tools, shared environments, or packaged environments may be more efficient.

If you use `rsync` between clusters, prefer private IP addresses when possible to reduce the chance of sending traffic over the public internet.

Please perform `rsync` transfers from a compute node rather than a login node. 

Note: your home directory is not automatically synced at this time. You will need to sync them if you want them to remain consistent between the two clusters.  

## Do I need AWS Console access?  
Possibly.

If you use `aws sso` credentials, then yes, you may need console access to set up or renew tokens.
Otherwise, it depends on the tasks you need to perform.

## Where can I find more information about working on the SMDC?  
See the SMDC users repository [4](https://github.com/RomanSpaceTelescope/RST_SMDC_users).   
See RST Science Infrastructure Primer [5](https://outerspace.stsci.edu/spaces/IWG/pages/413204740/RST+Science+Infrastructure+Primer).

## Where can I get help?  
Reach out in the following channels on Roman Slack:  
* `#infrastructure-wg`
* `#smdc_users`
* Contact SMDC system administrators directly 

---

### References

1. [Roman Space Telescope SMDC Users, Miniforge documentation](https://github.com/RomanSpaceTelescope/RST_SMDC_users/blob/main/documentation/miniforge.md)  
2. [Roman Space Telescope SMDC Users, Jupyter notebook setup documentation](https://github.com/RomanSpaceTelescope/RST_SMDC_users/blob/main/documentation/run-jupyter-notebook.md)  
3. [Roman Space Telescope commissioning repository, CaSSI supplementary telemetry retrieval tutorial](https://github.com/RomanSpaceTelescope/RST_commissioning/tree/main/notebooks/CaSSI_supplementary_telemetry_retrieval) 
4. [Roman Space Telescope SMDC Users repository](https://github.com/RomanSpaceTelescope/RST_SMDC_users)  
5. [RST Science Infrastructure Primer](https://outerspace.stsci.edu/spaces/IWG/pages/413204740/RST+Science+Infrastructure+Primer)  
6. [Slurm Workload Manager Documentation](https://slurm.schedmd.com/documentation.html)   
7. [tmux getting started guide](https://github.com/tmux/tmux/wiki)  
8. [GNU Screen documentation](https://www.gnu.org/software/screen/)    
9. [Image Visualization Tools Setup](https://github.com/RomanSpaceTelescope/RST_SMDC_users/blob/main/documentation/image-visualization-tools-setup.md)  
10. [S3 Data Transfer Guide](https://github.com/RomanSpaceTelescope/RST_SMDC_users/blob/main/documentation/S3%20Data%20Transfer.md)  
11. [Amazon Web Services, “Using versioning in S3 buckets,” Amazon S3 User Guide](https://docs.aws.amazon.com/AmazonS3/latest/userguide/Versioning.html)
12. [Roman SMDC Cost-Aware Workflow Design](https://github.com/RomanSpaceTelescope/RST_commissioning/blob/main/docs/Roman-SMDC-cost-aware-workflow-design.md)
13. [OpenUniverse 2024 Simulated Roman & Rubin Images](https://irsa.ipac.caltech.edu/data/theory/openuniverse2024/overview.html) 

