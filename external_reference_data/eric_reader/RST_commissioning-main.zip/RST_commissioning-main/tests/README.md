Path can be used for tests of the shared utilities
