"""Tests for shared/apt_survey_check.py, shared/apt_time_estimate.py and shared/opup_visit_timing.py.

Run with: python -m pytest tests/test_apt_checks.py
The APT and OPUP inputs are small synthetic files written to a temporary directory.
"""

import io
import json
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
import pysiaf
import pytest

SHARED = Path(__file__).resolve().parents[1] / "shared"
sys.path.insert(0, str(SHARED))

from apt_survey_check import (find_irregularities, get_scope, opup_execution_plans, plan_scopes,  # noqa: E402
                              survey_plan_differences, survey_steps)
from apt_time_estimate import (T_EWA_PER_SLOT, T_EXTRA_EXPOSURE, T_FRAME_IMAGING, T_FRAME_SPECTRO,  # noqa: E402
                               T_POINTING, T_SLEW_PER_DEG, T_SPEC_EXPOSURE, WFI_FIELD_DEG, estimate_visit_times,
                               exposure_time)
from opup_visit_timing import collect_visit_timing  # noqa: E402

SCAS = [f"WFI{i:02d}_FULL" for i in range(1, 19)]
TARGETS_XML = ("<Targets><FixedTarget><Number>1</Number><TargetName>STAR-A</TargetName></FixedTarget>"
               "<FixedTarget><Number>2</Number><TargetName>STAR-B</TargetName></FixedTarget></Targets>")


def plan_xml(pass_plans, step_order):
    """XML for the Targets, PassPlans and SurveyPlan of one plan (see write_apt)."""
    blocks = []
    for number, (label, target, observations) in pass_plans.items():
        obs_xml = "".join(
            f"<Observation><Target></Target><Repeat>1</Repeat><OpticalElement>{f}</OpticalElement>"
            f"<NumberOfExposures>1</NumberOfExposures><MultiAccumTable>{ma}</MultiAccumTable>"
            f"<Resultant>{res}</Resultant><Dither>NONE</Dither><SubpixelDither>SUB4</SubpixelDither>"
            f"<SpecialRequirements><FiducialPointOverride><FiducialPointOverrideAperture>{ap}"
            f"</FiducialPointOverrideAperture></FiducialPointOverride></SpecialRequirements></Observation>"
            for f, ma, res, ap in observations)
        blocks.append(f'<PassPlan Number="{number}"><Label>{label}</Label>'
                      f"<TargetSelection>Fixed: {target}</TargetSelection>{obs_xml}<ToolData/></PassPlan>")
    steps = "".join(f"<SurveyPlanStep><PassPlan>{n}</PassPlan><Repeat>1</Repeat></SurveyPlanStep>" for n in step_order)
    return f"{TARGETS_XML}<PassPlans>{''.join(blocks)}</PassPlans><SurveyPlan>{steps}</SurveyPlan>"


def write_apt(path, pass_plans, step_order, execution_plans=()):
    """Write a minimal APT file.

    Args:
        path (Path): Output file.
        pass_plans (dict): PassPlan Number -> (label, target number, list of
            observations as (filter, MA table, resultants, aperture) tuples).
        step_order (list of str): PassPlan Numbers in survey-plan order.
        execution_plans (list of tuple): (number, pass_plans, step_order,
            segment statuses) per execution plan. A status "WITHDRAWN" writes a
            FLIGHT_READY segment with Withdraw="true".
    """
    plans = []
    for number, ep_pass_plans, ep_steps, statuses in execution_plans:
        segments = "".join(
            f'<Segment ID="09999{number:02d}{i:03d}001" Status="{"FLIGHT_READY" if s == "WITHDRAWN" else s}" '
            f'Withdraw="{"true" if s == "WITHDRAWN" else "false"}"/>' for i, s in enumerate(statuses, 1))
        plans.append(f'<ExecutionPlan ProgramId="9999" Number="{number}">{plan_xml(ep_pass_plans, ep_steps)}'
                     f"<Activities>{segments}</Activities></ExecutionPlan>")
    path.write_text(
        '<?xml version="1.0" encoding="UTF-8"?><RomanProgram xmlns="http://www.stsci.edu/Roman/APT">'
        "<ProgramInformation><Title>Test program</Title><ProgramID>9999</ProgramID></ProgramInformation>"
        f"{plan_xml(pass_plans, step_order)}<ExecutionPlans>{''.join(plans)}</ExecutionPlans></RomanProgram>")


def uniform_pass(filt, ma="IM_DIAGNOSTIC", resultants=5):
    return [(filt, ma, resultants, ap) for ap in SCAS]


@pytest.fixture
def apt_file(tmp_path):
    bad = uniform_pass("F146")
    bad[3] = ("F129", "IM_DIAGNOSTIC", 5, SCAS[3])  # off-filter observation
    bad[17] = ("F146", "IM_DIAGNOSTIC", 5, SCAS[8])  # WFI09 duplicated, WFI18 missing
    bad[5] = ("F146", "IM_DIAGNOSTIC", 6, SCAS[5])  # odd resultant count
    pass_plans = {
        "1": ("STAR-A_F062", 1, uniform_pass("F062")),
        "2": ("STAR-A_F146", 1, bad),
        "3": ("STAR-B_F106", 2, uniform_pass("F106", "IM_171_10", 10)),
        "4": ("STAR-B_F087", 2, uniform_pass("F087")),
    }
    path = tmp_path / "test.apt"
    write_apt(path, pass_plans, ["2", "1", "3"])
    return path


def test_survey_steps_follow_survey_plan_order(apt_file):
    steps = survey_steps(apt_file)
    assert steps["pass_plan"].tolist() == ["2", "1", "3"]
    assert steps["step"].tolist() == [1, 2, 3]
    assert steps["target"].tolist() == ["STAR-A", "STAR-A", "STAR-B"]
    assert steps.loc[0, "filters"] == "F129,F146"
    assert steps.loc[2, "ma_tables"] == "IM_171_10 (10)"
    assert (steps["n_obs"] == 18).all()


def test_find_irregularities(apt_file):
    issues = find_irregularities(apt_file)
    by_plan = {}
    for issue in issues:
        by_plan.setdefault(issue["pass_plan"], []).append(issue["issue"])

    assert by_plan["4"] == ["not used in survey plan"]
    assert "1" not in by_plan and "3" not in by_plan
    found = " | ".join(by_plan["2"])
    assert "filter differs from majority F146: WFI04_FULL=F129" in found
    assert "duplicated apertures: WFI09_FULL" in found
    assert "missing apertures: WFI18_FULL" in found
    assert "mixed Resultant (majority 5): WFI06_FULL=6" in found


def test_find_irregularities_include_unused(tmp_path):
    bad = uniform_pass("F087")
    bad[0] = ("F213", "IM_DIAGNOSTIC", 5, SCAS[0])
    path = tmp_path / "unused.apt"
    write_apt(path, {"1": ("STAR-A_F062", 1, uniform_pass("F062")), "2": ("STAR-B_F087", 2, bad)}, ["1"])
    assert all(i["issue"] == "not used in survey plan" for i in find_irregularities(path))
    assert any("filter differs" in i["issue"] for i in find_irregularities(path, include_unused=True))


def test_exposure_time():
    # Diagnostic tables read resultants - 1 frames; named tables use their nominal exposure time
    assert exposure_time("IM_DIAGNOSTIC", "7") == (6, pytest.approx(6 * T_FRAME_IMAGING))
    assert exposure_time("IM_171_10", 10)[0] == 54
    assert exposure_time("IM_60_6_S_V2", 6)[0] == 19
    assert exposure_time("SP_300_16", 16) == (58, pytest.approx(58 * T_FRAME_SPECTRO))
    assert exposure_time("SP_DIAGNOSTIC", 60)[0] == 59
    with pytest.raises(ValueError):
        exposure_time("XX_100_6", 6)


def test_estimate_visit_times(tmp_path):
    pass_plans = {
        "1": ("STAR-A_F062", 1, uniform_pass("F062")),
        "2": ("STAR-A_F158", 1, uniform_pass("F158")),
        "3": ("STAR-B_F106", 2, uniform_pass("F106", "IM_171_10", 10)),
    }
    path = tmp_path / "time.apt"
    write_apt(path, pass_plans, ["1", "2", "3"])
    siaf = pysiaf.Siaf("Roman")
    visits = estimate_visit_times(path, siaf=siaf)

    assert len(visits) == 54
    assert visits["target"].unique().tolist() == ["STAR-A", "STAR-B"]
    # SUB4: one pointing, four exposures per visit
    assert (visits["exposures"] == 4).all()
    assert visits["t_overhead"].sum() == pytest.approx(54 * (T_POINTING + 3 * T_EXTRA_EXPOSURE))
    assert visits.loc[visits["step"] == 3, "t_exposure"].sum() == pytest.approx(18 * 4 * 54 * T_FRAME_IMAGING)

    # Slews: none onto each new target; a WFI18 -> WFI01 return between passes on the same target
    v2v3 = np.array([[siaf[ap].V2Ref, siaf[ap].V3Ref] for ap in SCAS])
    path_deg = np.hypot(*np.diff(v2v3, axis=0).T).sum() / 3600
    return_deg = np.hypot(*(v2v3[0] - v2v3[-1])) / 3600
    assert visits.loc[[0, 36], "t_slew"].tolist() == [0.0, 0.0]
    assert visits["t_slew"].sum() == pytest.approx(T_SLEW_PER_DEG * (3 * path_deg + return_deg))

    # Filter wheel: F062 -> F158 is 4 slots (3 charged); F158 -> F106 is 3 slots (2 charged)
    assert visits.loc[18, "t_ewa"] == pytest.approx(3 * T_EWA_PER_SLOT)
    assert visits.loc[36, "t_ewa"] == pytest.approx(2 * T_EWA_PER_SLOT)
    assert visits["t_ewa"].sum() == pytest.approx(5 * T_EWA_PER_SLOT)
    assert visits["t_total"].sum() == pytest.approx(
        visits[["t_exposure", "t_overhead", "t_slew", "t_ewa"]].to_numpy().sum())


def write_mosaic_apt(path, pass_plans):
    """Write an APT file with the two mosaic patterns of CAR-144 (PID 1012).

    Args:
        path (Path): Output file.
        pass_plans (list of str): Observation XML of each pass plan, in survey-plan order.
    """
    blocks = "".join(f'<PassPlan Number="{n}"><Label>Pass{n}</Label><TargetSelection>Fixed: 1</TargetSelection>'
                     f"{obs}</PassPlan>" for n, obs in enumerate(pass_plans, 1))
    steps = "".join(f"<SurveyPlanStep><PassPlan>{n}</PassPlan><Repeat>1</Repeat></SurveyPlanStep>"
                    for n in range(1, len(pass_plans) + 1))
    path.write_text(
        '<?xml version="1.0" encoding="UTF-8"?><RomanProgram xmlns="http://www.stsci.edu/Roman/APT">'
        f"{TARGETS_XML}<MosaicPatterns>"
        '<MosaicPattern Number="1"><NumRows>2</NumRows><NumCols>2</NumCols><MosaicType>Grid</MosaicType>'
        "<RowOverlap>15.0</RowOverlap><ColOverlap>15.0</ColOverlap></MosaicPattern>"
        '<MosaicPattern Number="2"><MosaicType>Custom</MosaicType><Offset X="1.875" Y="1.875"/>'
        '<Offset X="-1.875" Y="1.875"/><Offset X="1.875" Y="-1.875"/><Offset X="-1.875" Y="-1.875"/></MosaicPattern>'
        f"</MosaicPatterns><PassPlans>{blocks}</PassPlans><SurveyPlan>{steps}</SurveyPlan></RomanProgram>")


def mosaic_obs(filt, ma, resultants, sector="NONE", dither="NONE", subpixel="NONE", n_exp=1, repeat=1, aperture=None):
    override = (f"<SpecialRequirements><FiducialPointOverride><FiducialPointOverrideAperture>{aperture}"
                "</FiducialPointOverrideAperture></FiducialPointOverride></SpecialRequirements>" if aperture else "")
    return (f"<Observation><Target>1</Target><Sector>{sector}</Sector><Repeat>{repeat}</Repeat>"
            f"<OpticalElement>{filt}</OpticalElement><NumberOfExposures>{n_exp}</NumberOfExposures>"
            f"<MultiAccumTable>{ma}</MultiAccumTable><Resultant>{resultants}</Resultant><Dither>{dither}</Dither>"
            f"<SubpixelDither>{subpixel}</SubpixelDither>{override}</Observation>")


def test_estimate_mosaics_and_dithers(tmp_path):
    imaging = mosaic_obs("F106", "IM_66_6_V2", 6, sector="1") + mosaic_obs("F158", "IM_66_6_V2", 6, sector="1")
    grism = mosaic_obs("GRISM", "SP_300_16", 16, sector="2", subpixel="SUB3", aperture="WFI02_FULL")
    boxgap = mosaic_obs("F158", "IM_DIAGNOSTIC", 5, dither="BOXGAP6", n_exp=2, repeat=2, aperture="WFI02_FULL")
    path = tmp_path / "mosaic.apt"
    write_mosaic_apt(path, [imaging, grism, boxgap])
    visits = estimate_visit_times(path, siaf=pysiaf.Siaf("Roman"))
    assert len(visits) == 8 + 4 + 2

    # Imaging: no aperture override -> WFI_CEN; 2x2 grid, tiles reversed for the second filter
    img = visits[visits["step"] == 1]
    assert (img["aperture"] == "WFI_CEN").all()
    assert img["mosaic_position"].tolist() == [1, 2, 3, 4, 4, 3, 2, 1]
    assert img["frames"].tolist() == [21] * 8
    assert img["t_overhead"].tolist() == pytest.approx([T_POINTING] * 8)
    # Tile steps: field minus 15% overlap along the ideal Y (rows) and X (columns) axes; no slew for the filter change
    slew_deg = img["t_slew"].to_numpy() / T_SLEW_PER_DEG
    step_x, step_y = 0.85 * WFI_FIELD_DEG[0], 0.85 * WFI_FIELD_DEG[1]
    assert slew_deg[:5] == pytest.approx([0, step_y, step_x, step_y, 0], abs=1e-4)

    # Grism: Custom offsets in arcmin, SUB3 -> 3 exposures per visit, plus the spectroscopic overhead
    spec = visits[visits["step"] == 2]
    assert spec["mosaic_position"].tolist() == [1, 2, 3, 4]
    assert (spec["exposures"] == 3).all()
    assert spec["t_overhead"].iloc[0] == pytest.approx(T_POINTING + 2 * T_EXTRA_EXPOSURE + 3 * T_SPEC_EXPOSURE)
    assert spec["t_exposure"].iloc[0] == pytest.approx(3 * 58 * T_FRAME_SPECTRO)
    assert spec["t_slew"].iloc[1] / T_SLEW_PER_DEG == pytest.approx(3.75 / 60, abs=1e-4)

    # BOXGAP6 with 2 exposures, repeated: 2 visits of 6 pointings and 12 exposures each
    box = visits[visits["step"] == 3]
    assert box["pointings"].tolist() == [6, 6]
    assert box["exposures"].tolist() == [12, 12]
    assert box["t_overhead"].iloc[0] == pytest.approx(6 * T_POINTING + 6 * T_EXTRA_EXPOSURE)
    assert box["t_slew"].iloc[1] == 0.0


def test_estimate_rejects_unsupported_observations(tmp_path):
    path = tmp_path / "bad.apt"
    write_mosaic_apt(path, [mosaic_obs("F106", "IM_66_6_V2", 6, sector="9")])
    with pytest.raises(ValueError, match="Sector 9"):
        estimate_visit_times(path, siaf=pysiaf.Siaf("Roman"))
    write_mosaic_apt(path, [mosaic_obs("F106", "IM_66_6_V2", 6, dither="CUSTOM")])
    with pytest.raises(ValueError, match="dither 'CUSTOM'"):
        estimate_visit_times(path, siaf=pysiaf.Siaf("Roman"))


def add_bytes(tar, name, data):
    info = tarfile.TarInfo(name)
    info.size = len(data)
    tar.addfile(info, io.BytesIO(data))


def visit_text(visit_id, quat, ewa, frames, n_offsets):
    q = ",".join(f"{x:.15f}" for x in quat)
    lines = [f"VISIT, V{visit_id}, EARLY=2026-300-00:00:00;",
             f'  ACT, 03, SCF_AM_SLEW_MAIN_F({q},"SETTLE"); TAR_Q1_ECI2BCS,TAR_Q2_ECI2BCS,TAR_Q3_ECI2BCS,TAR_Q4_ECI2BCS,ACS_MODE_NEXT',
             f'  ACT, 01, WFI_MCE_EWA_MOVE_ABS_F("{ewa}"); FILTER',
             f'  ACT, 01, WFI_LOAD_SCI_MA_SETREADFRMS_F(0,"010_IM_66_6_V2",{frames}); WFI_DET,WFI_SCI_TABLE,READFRAMES',
             "  ACT, 01, WFI_EXPOSURE_START_F;"]
    for i in range(n_offsets):
        lines.append(f'  ACT, 0{2 + 2 * i}, SCF_AC_TARG_OFFSET_F("IH","EXT",0.0,1E-07,1E-07,"TLM_CHK_TRUE");')
        lines.append(f'  ACT, 0{3 + 2 * i}, WFI_SET_USER_ID_SCI_EXPOSE_F(0,"x");')
    return "\n".join(lines) + "\n"


def test_collect_visit_timing(tmp_path):
    q1 = np.array([0.0, 0.0, 0.0, 1.0])
    half = np.radians(1.5) / 2
    q2 = np.array([0.0, 0.0, np.sin(half), np.cos(half)])  # 1.5 deg rotation
    visits = [
        {"Visit_ID": "0999901001001002001", "Visit_File_Name": "V0999901001001002001.vst", "Start": "2026-300-01:00:00 UTC",
         "Duration": "340", "Intended_Purpose": "COM / WFI - CAR-999: Test", "Science_Instrument_Mode": "WFI_IMAGING",
         "WFI_Optical_Element": "F106", "FGS_Guidance": "true"},
        {"Visit_ID": "0999901001001001001", "Visit_File_Name": "V0999901001001001001.vst", "Start": "2026-300-00:00:00 UTC",
         "Duration": "98", "Intended_Purpose": "COM / WFI - CAR-999: Test", "Science_Instrument_Mode": "WFI_IMAGING",
         "WFI_Optical_Element": "F062", "FGS_Guidance": "true"},
        {"Visit_ID": "0999901001001003001", "Visit_File_Name": "V0999901001001003001.vst", "Start": "2026-300-02:00:00 UTC",
         "Duration": "50", "Intended_Purpose": "missing visit file"},
    ]
    scf_buffer = io.BytesIO()
    with tarfile.open(fileobj=scf_buffer, mode="w:gz") as scf:
        add_bytes(scf, "V0999901001001001001.vst", visit_text("0999901001001001001", q1, "POS_3_F062", 21, 0).encode())
        add_bytes(scf, "V0999901001001002001.vst", visit_text("0999901001001002001", q2, "POS_4_F106", 21, 3).encode())
    opup_path = tmp_path / "2026300000000_2026299000000_opup.tgz"
    with tarfile.open(opup_path, mode="w:gz") as opup:
        add_bytes(opup, "2026300000000_2026299000000_odf.json", json.dumps({"visits": visits}).encode())
        add_bytes(opup, "SCF_2026300000000_1.tgz", scf_buffer.getvalue())

    df = collect_visit_timing([opup_path])
    assert df["visit"].tolist() == ["0999901001001001001", "0999901001001002001"]
    assert df["opup"].unique().tolist() == ["2026300000000_2026299000000_opup"]
    assert df["purpose"].tolist() == ["CAR-999: Test", "CAR-999: Test"]
    assert df["duration"].tolist() == [98, 340]
    assert df["nexp"].tolist() == [1, 4]
    assert df["noff"].tolist() == [0, 3]
    assert df["ma"].tolist() == ["010_IM_66_6_V2", "010_IM_66_6_V2"]
    assert df["frames"].tolist() == ["21", "21"]
    assert df["ewa"].tolist() == ["POS_3_F062", "POS_4_F106"]
    assert np.isnan(df.loc[0, "slew_deg"])
    assert df.loc[1, "slew_deg"] == pytest.approx(1.5, abs=1e-4)


def test_collect_visit_timing_rejects_bad_tarball(tmp_path):
    path = tmp_path / "bad_opup.tgz"
    with tarfile.open(path, mode="w:gz") as opup:
        add_bytes(opup, "readme.txt", b"no odf here")
    with pytest.raises(ValueError, match="odf.json"):
        collect_visit_timing([path])


@pytest.fixture
def multi_plan_apt(tmp_path):
    """Clean top level; Execution Plan 1 has a bad pass plan 2; Execution Plan 2 matches the top level."""
    bad = uniform_pass("F146")
    bad[3] = ("F129", "IM_DIAGNOSTIC", 5, SCAS[3])
    clean = {
        "1": ("STAR-A_F062", 1, uniform_pass("F062")),
        "2": ("STAR-A_F146", 1, uniform_pass("F146")),
        "3": ("STAR-B_F106", 2, uniform_pass("F106", "IM_171_10", 10)),
    }
    old = dict(clean, **{"2": ("STAR-A_F146", 1, bad)})
    order = ["2", "1", "3"]
    path = tmp_path / "multi.apt"
    write_apt(path, clean, order, execution_plans=[
        (1, old, order, ["FLIGHT_READY"] * 3),
        (2, clean, order, ["SCHEDULED", "SCHEDULED", "WITHDRAWN"]),
    ])
    return path


def test_plan_scopes(multi_plan_apt, apt_file):
    scopes = plan_scopes(multi_plan_apt)
    assert [s["execution_plan"] for s in scopes] == [None, 1, 2]
    assert scopes[0]["name"] == "Top level (working copy)"
    assert scopes[0]["segment_status"] == "no segments"
    assert scopes[1]["segment_status"] == "FLIGHT_READY (3)"
    assert scopes[2]["segment_status"] == "SCHEDULED (2), WITHDRAWN (1)"
    # A file without execution plans has only the top level
    assert [s["execution_plan"] for s in plan_scopes(apt_file)] == [None]


def test_execution_plans_checked_separately(multi_plan_apt):
    assert find_irregularities(multi_plan_apt) == []
    assert find_irregularities(multi_plan_apt, execution_plan=2) == []
    issues = find_irregularities(multi_plan_apt, execution_plan=1)
    assert [(i["pass_plan"], i["issue"]) for i in issues] == [
        ("2", "filter differs from majority F146: WFI04_FULL=F129")]
    assert survey_steps(multi_plan_apt, execution_plan=1).loc[0, "filters"] == "F129,F146"
    assert survey_steps(multi_plan_apt).loc[0, "filters"] == "F146"


def test_survey_plan_differences(multi_plan_apt, tmp_path):
    assert survey_plan_differences(multi_plan_apt, 1) == ["step 1 (STAR-A_F146)"]
    assert survey_plan_differences(multi_plan_apt, 2) == []

    plans = {"1": ("STAR-A_F062", 1, uniform_pass("F062")), "2": ("STAR-A_F146", 1, uniform_pass("F146"))}
    path = tmp_path / "shorter.apt"
    write_apt(path, plans, ["1", "2"], execution_plans=[(1, plans, ["1"], ["FLIGHT_READY"])])
    assert survey_plan_differences(path, 1) == ["top level has 2 survey steps, execution plan has 1"]


def test_missing_execution_plan(multi_plan_apt, apt_file):
    with pytest.raises(ValueError, match="No execution plan 3"):
        get_scope(ET.parse(multi_plan_apt).getroot(), 3)
    # A file without execution plans
    with pytest.raises(ValueError, match="No execution plan 1"):
        survey_steps(apt_file, execution_plan=1)


def test_estimate_execution_plans(multi_plan_apt):
    siaf = pysiaf.Siaf("Roman")
    top = estimate_visit_times(multi_plan_apt, siaf=siaf)
    ep1 = estimate_visit_times(multi_plan_apt, siaf=siaf, execution_plan=1)
    ep2 = estimate_visit_times(multi_plan_apt, siaf=siaf, execution_plan=2)
    assert len(top) == len(ep1) == len(ep2) == 54
    assert ep2["t_total"].sum() == pytest.approx(top["t_total"].sum())
    # The off-filter observation in Execution Plan 1 adds two filter-wheel moves
    assert ep1["t_ewa"].sum() > top["t_ewa"].sum()


def write_opup_odf(path, visit_ids):
    with tarfile.open(path, mode="w:gz") as opup:
        visits = [{"Visit_ID": v, "Visit_File_Name": f"V{v}.vst", "Start": "2026-300-00:00:00 UTC", "Duration": "100"}
                  for v in visit_ids]
        add_bytes(opup, "x_odf.json", json.dumps({"visits": visits}).encode())


def test_opup_execution_plans(tmp_path):
    a, b = tmp_path / "A_opup.tgz", tmp_path / "B_opup.tgz"
    write_opup_odf(a, ["0999902001001001001", "0999902002001001001", "0103902006001001001"])
    write_opup_odf(b, ["0103902006001001001"])
    found = opup_execution_plans([a, b], "9999")
    assert found.to_dict("records") == [{"opup": "A_opup", "execution_plan": 2, "n_visits": 2}]
    assert opup_execution_plans([b], 9999).empty


def test_survey_check_command_line(multi_plan_apt, tmp_path):
    opup = tmp_path / "C_opup.tgz"
    write_opup_odf(opup, ["0999901001001001001", "0999901002001001001"])
    csv_path = tmp_path / "steps.csv"
    result = subprocess.run([sys.executable, str(SHARED / "apt_survey_check.py"), str(multi_plan_apt),
                             "--opup", str(opup), "--csv", str(csv_path)], capture_output=True, text=True, check=True)
    out = result.stderr + result.stdout
    assert "Execution Plan 1  [segments: FLIGHT_READY (3)]" in out
    assert "WARNING: survey plan differs from the top level: step 1 (STAR-A_F146)" in out
    assert "Execution Plan 2  [segments: SCHEDULED (2), WITHDRAWN (1)]" in out
    assert "Survey plan identical to the top level." in out
    assert "C_opup: Execution Plan 1, 2 visits  <-- WARNING: Execution Plan 1 has irregularities" in out
    assert csv_path.read_text().splitlines()[0].startswith("execution_plan,step,pass_plan")


def test_time_estimate_command_line(multi_plan_apt):
    # -I (isolated mode) drops the script directory from sys.path; the sibling import must still work
    result = subprocess.run([sys.executable, "-I", str(SHARED / "apt_time_estimate.py"), str(multi_plan_apt)],
                            capture_output=True, text=True, check=True)
    out = result.stderr + result.stdout
    assert "WARNING: survey plan differs from the top level: step 1 (STAR-A_F146)" in out
    assert "Survey plan identical to the top level: 54 visits" in out
    # No --siaf given, so the pre-flight SIAF bundled with pysiaf is used and flagged
    assert "WARNING: using a pre-flight Roman SIAF" in out
