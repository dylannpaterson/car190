import numpy as np
from dataclasses import dataclass

@dataclass
class SCAConfig:
    """Configuration for a single SCA"""
    sca_id: int
    center_mpa: tuple  # (x, y) in MPA coordinates
    is_flipped: bool  # True for 180° rotation
    
class MPAProjector:
    def __init__(self, 
                 sca_x,  # 1D array of SCA x-coordinates
                 sca_y,  # 1D array of SCA y-coordinates
                 mpa_x,  # 2D meshgrid of MPA x-coords
                 mpa_y,  # 2D meshgrid of MPA y-coords
                 sca_indexing='xy'):  # How to match sca_data array layout
        """
        Initialize the MPA projector with coordinate grids.
        
        Parameters
        ----------
        sca_indexing : str, either 'xy' or 'ij'
            How to create the SCA coordinate meshgrid to match your data:
            - 'ij': sca_data.shape = (len(sca_x), len(sca_y))
                   First index corresponds to sca_x, second to sca_y
            - 'xy': sca_data.shape = (len(sca_y), len(sca_x))
                   First index corresponds to sca_y (rows), second to sca_x (cols)
        """
        self.sca_x = sca_x
        self.sca_y = sca_y
        self.mpa_x = mpa_x
        self.mpa_y = mpa_y
        self.mpa_shape = mpa_x.shape
        self.sca_indexing = sca_indexing
        
        # Auto-detect MPA meshgrid indexing style
        x_varies_axis1 = np.ptp(mpa_x[0, :]) > np.ptp(mpa_x[:, 0])
        
        if x_varies_axis1:
            self.mpa_x_1d = mpa_x[0, :]
            self.mpa_y_1d = mpa_y[:, 0]
            self.mpa_indexing = 'xy'
        else:
            self.mpa_x_1d = mpa_x[:, 0]
            self.mpa_y_1d = mpa_y[0, :]
            self.mpa_indexing = 'ij'
        
        print(f"MPA meshgrid indexing: '{self.mpa_indexing}'")
        print(f"SCA meshgrid indexing: '{self.sca_indexing}'")
        print(f"  -> Your sca_data arrays should have shape: {(len(sca_x), len(sca_y)) if sca_indexing=='ij' else (len(sca_y), len(sca_x))}")
        print(f"MPA grid shape: {self.mpa_shape}")
        print(f"MPA coordinate ranges:")
        print(f"  X: [{self.mpa_x_1d.min():.1f}, {self.mpa_x_1d.max():.1f}]")
        print(f"  Y: [{self.mpa_y_1d.min():.1f}, {self.mpa_y_1d.max():.1f}]")
        
        # Determine if coordinates are monotonic and get direction
        self.x_increasing = self.mpa_x_1d[-1] > self.mpa_x_1d[0]
        self.y_increasing = self.mpa_y_1d[-1] > self.mpa_y_1d[0]
        
        # For searchsorted, we need increasing arrays
        self.mpa_x_sorted = self.mpa_x_1d if self.x_increasing else self.mpa_x_1d[::-1]
        self.mpa_y_sorted = self.mpa_y_1d if self.y_increasing else self.mpa_y_1d[::-1]
        
        # Compute bin edges
        self.x_edges = self._compute_bin_edges(self.mpa_x_sorted)
        self.y_edges = self._compute_bin_edges(self.mpa_y_sorted)
        
        self.sca_xx, self.sca_yy = np.meshgrid(sca_x, sca_y, indexing=sca_indexing)
        
        print(f"SCA coordinate meshgrid shape: {self.sca_xx.shape}")
        
        # Initialize output grids
        self.count_grid = np.zeros(self.mpa_shape, dtype=int)
        self.mean_grid = np.full(self.mpa_shape, np.nan, dtype=float)
        self.stdev_grid = np.full(self.mpa_shape, np.nan, dtype=float)
    
    def _compute_bin_edges(self, centers):
        """Compute bin edges from bin centers."""
        if len(centers) == 1:
            dx = 1.0
            return np.array([centers[0] - dx/2, centers[0] + dx/2])
        
        edges = np.zeros(len(centers) + 1)
        edges[1:-1] = (centers[:-1] + centers[1:]) / 2
        edges[0] = centers[0] - (edges[1] - centers[0])
        edges[-1] = centers[-1] + (centers[-1] - edges[-2])
        
        return edges
        
    def _transform_sca_to_mpa(self, sca_config):
        """
        Transform SCA coordinates to MPA coordinates.
        This operates on coordinate VALUES, independent of array layout.
        """
        # Work with coordinate values (not affected by indexing)
        xx, yy = self.sca_xx.copy(), self.sca_yy.copy()
        
        # Apply 180 deg rotation if needed (around SCA origin)
        # This flips the COORDINATE VALUES
        if sca_config.is_flipped:
            xx = -xx
            yy = -yy
        
        # Translate to MPA position
        # center_mpa is in MPA coordinate system, independent of indexing
        mpa_xx = xx + sca_config.center_mpa[0]
        mpa_yy = yy + sca_config.center_mpa[1]
        
        return mpa_xx, mpa_yy
    
    def _compute_mpa_indices(self, mpa_xx, mpa_yy):
        """
        Compute MPA grid indices for each SCA pixel.
        """
        # Use searchsorted to find bins (works on coordinate values)
        x_bins = np.searchsorted(self.x_edges, mpa_xx.ravel(), side='right') - 1
        y_bins = np.searchsorted(self.y_edges, mpa_yy.ravel(), side='right') - 1
        
        # Reshape back to match SCA shape
        x_bins = x_bins.reshape(mpa_xx.shape)
        y_bins = y_bins.reshape(mpa_yy.shape)
        
        # If original arrays were decreasing, flip the indices
        if not self.x_increasing:
            x_bins = len(self.mpa_x_1d) - 1 - x_bins
        if not self.y_increasing:
            y_bins = len(self.mpa_y_1d) - 1 - y_bins
        
        # Map to grid indices based on MPA indexing convention
        if self.mpa_indexing == 'xy':
            # For MPA 'xy': rows are y, columns are x
            i_mpa = y_bins
            j_mpa = x_bins
            valid = ((y_bins >= 0) & (y_bins < self.mpa_shape[0]) &
                    (x_bins >= 0) & (x_bins < self.mpa_shape[1]))
        else:
            # For MPA 'ij': rows are x, columns are y
            i_mpa = x_bins
            j_mpa = y_bins
            valid = ((x_bins >= 0) & (x_bins < self.mpa_shape[0]) &
                    (y_bins >= 0) & (y_bins < self.mpa_shape[1]))
        
        return i_mpa, j_mpa, valid
    
    def project_one_sca(self, sca_data, sca_config):
        """
        Project a single SCA onto the MPA grid.
        
        Parameters
        ----------
        sca_data : 2D array with NaN mask
            Shape must match the SCA coordinate meshgrid shape
        sca_config : SCAConfig object
        """
        # Verify shape matches
        if sca_data.shape != self.sca_xx.shape:
            raise ValueError(f"sca_data shape {sca_data.shape} doesn't match "
                           f"SCA coordinate meshgrid shape {self.sca_xx.shape}. "
                           f"Check sca_indexing parameter (currently '{self.sca_indexing}').")
        
        # Transform coordinates (operates on coordinate values)
        mpa_xx, mpa_yy = self._transform_sca_to_mpa(sca_config)
        
        # Get MPA indices
        i_mpa, j_mpa, in_bounds = self._compute_mpa_indices(mpa_xx, mpa_yy)
        
        # Valid pixels: not NaN and within MPA bounds
        valid = (~np.isnan(sca_data)) & in_bounds
        
        if not np.any(valid):
            return
        
        # Extract valid data and indices
        data_flat = sca_data[valid]
        i_flat = i_mpa[valid]
        j_flat = j_mpa[valid]
        
        # Create flat index for fast binning
        flat_idx = i_flat * self.mpa_shape[1] + j_flat
        unique_idx, inverse = np.unique(flat_idx, return_inverse=True)
        
        n_bins = len(unique_idx)
        
        # Fast binning using bincount
        counts = np.bincount(inverse, minlength=n_bins)
        sums = np.bincount(inverse, weights=data_flat, minlength=n_bins)
        sum_sq = np.bincount(inverse, weights=data_flat**2, minlength=n_bins)
        
        # Compute statistics
        means = sums / counts
        
        # Variance with Bessel's correction
        variances = (sum_sq / counts) - means**2
        variances = variances * counts / np.maximum(counts - 1, 1)
        variances[counts <= 1] = np.nan
        stdevs = np.sqrt(np.maximum(variances, 0))
        
        # Convert flat indices back to 2D
        i_indices = unique_idx // self.mpa_shape[1]
        j_indices = unique_idx % self.mpa_shape[1]
        
        # Place into MPA grids
        self.count_grid[i_indices, j_indices] = counts
        self.mean_grid[i_indices, j_indices] = means
        self.stdev_grid[i_indices, j_indices] = stdevs
    
    def get_results(self):
        """Return the accumulated results"""
        return {
            'count': self.count_grid,
            'mean': self.mean_grid,
            'stdev': self.stdev_grid
        }
    
    def reset(self):
        """Reset the grids for a new projection"""
        self.count_grid = np.zeros(self.mpa_shape, dtype=int)
        self.mean_grid = np.full(self.mpa_shape, np.nan, dtype=float)
        self.stdev_grid = np.full(self.mpa_shape, np.nan, dtype=float)


# Example with your actual setup:
def main():
    # Your actual MPA grid setup
    mpa_grid_shape = (225, 350)
    mpa_extent = [140.0, -140.0, -110.0, 70.0]
    
    xmin, xmax, ymin, ymax = mpa_extent
    x = np.linspace(xmin, xmax, mpa_grid_shape[1])  # 350 points
    y = np.linspace(ymin, ymax, mpa_grid_shape[0])  # 225 points
    mpa_x, mpa_y = np.meshgrid(x, y)  # default indexing='xy'
    
    # Define SCA coordinate grid
    sca_x = np.linspace(-20.4, 20.4, 4096)
    sca_y = np.linspace(-20.4, 20.4, 4096)
    
    # Example SCA config
    sca_config = SCAConfig(sca_id=7, center_mpa=(-110.7, 42.2), is_flipped=True)
    
    # Create projector
    projector = MPAProjector(sca_x, sca_y, mpa_x, mpa_y)
    
    # Create test data
    sca_data = np.random.randn(len(sca_x), len(sca_y))
    sca_data[np.random.rand(*sca_data.shape) < 0.1] = np.nan
    
    # Project
    projector.project_one_sca(sca_data, sca_config)
    
    results = projector.get_results()
    print(f"\nResults:")
    print(f"  Non-zero pixels: {np.sum(results['count'] > 0)}")
    print(f"  Mean range: {np.nanmin(results['mean']):.2f} to {np.nanmax(results['mean']):.2f}")
    
    return results

if __name__ == '__main__':
    results = main()
