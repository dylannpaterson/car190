import requests
import os
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
import pandas as pd

# Thread-safe counter for progress tracking
class DownloadTracker:
    def __init__(self, total_files):
        self.total_files = total_files
        self.completed = 0
        self.failed = 0
        self.lock = Lock()
        self.start_time = time.time()
    
    def increment_completed(self):
        with self.lock:
            self.completed += 1
            self._print_status()
    
    def increment_failed(self):
        with self.lock:
            self.failed += 1
            self._print_status()
    
    def _print_status(self):
        elapsed = time.time() - self.start_time
        rate = self.completed / elapsed if elapsed > 0 else 0
        print(f"Progress: {self.completed}/{self.total_files} completed, "
              f"{self.failed} failed | {rate:.2f} files/sec | "
              f"Elapsed: {elapsed:.1f}s")


def download_cassi_file_parallel(product_url, output_filename=None, token=None, 
                                  endpoint_url=None, output_dir=None, 
                                  archive="roman", datagroup="rita",
                                  tracker=None, thread_id=None):
    """
    Download a file from CASSI API with data rate tracking for parallel execution.
    
    Args:
        product_url: URL of the product to download
        output_filename: Name for the downloaded file
        token: API token
        endpoint_url: Download endpoint
        output_dir: Directory to save file
        archive: archive name
        datagroup: data group
        tracker: DownloadTracker instance for progress tracking
        thread_id: Optional thread identifier for logging
    
    Returns:
        Dict with download results and statistics
    """
    start_time = time.time()
    thread_label = f"[Thread {thread_id}]" if thread_id else ""
    
    try:
        # Get token
        if token is None:
            token = os.environ.get('MAST_API_TOKEN')
            if not token:
                raise ValueError("No token provided.")
        
        # Default endpoint
        if endpoint_url is None:
            endpoint_url = f"https://mast.stsci.edu/cassi/api/v0.1/download/{archive}/{datagroup}"
        
        # Extract filename from URL if not provided
        if output_filename is None:
            output_filename = product_url.split('/')[-1]
        
        # Set output directory
        if output_dir is not None:
            output_path = Path(output_dir) / output_filename
            output_path.parent.mkdir(parents=True, exist_ok=True)
        else:
            output_path = Path(output_filename)
        
        # Build payload
        payload = {"product_url": product_url}
        
        # Set headers
        headers = {
            "Authorization": f"token {token}",
            "Content-Type": "application/json"
        }

        print(f"{thread_label} Downloading {output_filename}...")
        
        # Make request
        response = requests.post(
            endpoint_url, 
            json=payload, 
            headers=headers,
            stream=True
        )
        
        # Check for errors
        if response.status_code != 200:
            raise Exception(f"HTTP {response.status_code}: {response.text}")
        
        # Get file size
        total_size = int(response.headers.get('content-length', 0))
        downloaded_size = 0
        
        # Write file in chunks and track progress
        chunk_start = time.time()
        with open(output_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded_size += len(chunk)
        
        # Calculate statistics
        elapsed_time = time.time() - start_time
        download_rate = downloaded_size / elapsed_time if elapsed_time > 0 else 0
        download_rate_mb = download_rate / (1024 * 1024)  # MB/s
        
        print(f"{thread_label} - {output_filename} - "
              f"{downloaded_size/(1024*1024):.2f} MB in {elapsed_time:.1f}s - "
              f"{download_rate_mb:.2f} MB/s")
        
        if tracker:
            tracker.increment_completed()
        
        return {
            'success': True,
            'url': product_url,
            'filename': output_filename,
            'filepath': str(output_path),
            'size_bytes': downloaded_size,
            'elapsed_seconds': elapsed_time,
            'rate_mbps': download_rate_mb,
            'error': None
        }
        
    except Exception as e:
        elapsed_time = time.time() - start_time
        print(f"{thread_label} ✗ Failed to download {output_filename}: {e}")
        
        if tracker:
            tracker.increment_failed()
        
        return {
            'success': False,
            'url': product_url,
            'filename': output_filename,
            'filepath': None,
            'size_bytes': 0,
            'elapsed_seconds': elapsed_time,
            'rate_mbps': 0,
            'error': str(e)
        }


def parallel_download_cassi_files(product_urls, output_dir=None, token=None, 
                                   archive="roman", datagroup="rita",
                                   max_workers=4, filenames=None):
    """
    Download multiple files from CASSI in parallel.
    
    Args:
        product_urls: List of product URLs
        output_dir: Directory to save files
        token: API token
        archive: archive name
        datagroup: data group
        max_workers: Number of parallel download threads (default: 4)
        filenames: Optional list of filenames (same length as product_urls)
    
    Returns:
        Tuple of (results_df, downloaded_files, failed_downloads)
    """
    if token is None:
        token = os.environ.get('MAST_API_TOKEN')
        if not token:
            raise ValueError("No token provided.")
    
    # Prepare URL-filename pairs
    if filenames is None:
        items = [(url, None) for url in product_urls]
    else:
        if len(filenames) != len(product_urls):
            raise ValueError("filenames must be same length as product_urls")
        items = list(zip(product_urls, filenames))
    
    # Create tracker
    tracker = DownloadTracker(len(items))
    
    print(f"\nStarting parallel download of {len(items)} files with {max_workers} workers...")
    print("=" * 80)
    
    results = []
    
    # Use ThreadPoolExecutor for parallel downloads
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all download tasks
        future_to_url = {
            executor.submit(
                download_cassi_file_parallel,
                url,
                filename,
                token,
                None,  # endpoint_url
                output_dir,
                archive,
                datagroup,
                tracker,
                i
            ): (url, filename) for i, (url, filename) in enumerate(items)
        }
        
        # Collect results as they complete
        for future in as_completed(future_to_url):
            result = future.result()
            results.append(result)
    
    print("=" * 80)
    
    # Create results DataFrame
    results_df = pd.DataFrame(results)
    
    # Separate successful and failed downloads
    successful = results_df[results_df['success'] == True]
    failed = results_df[results_df['success'] == False]
    
    # Print summary
    print(f"\n{'='*80}")
    print(f"DOWNLOAD SUMMARY")
    print(f"{'='*80}")
    print(f"Total files: {len(results)}")
    print(f"Successful: {len(successful)}")
    print(f"Failed: {len(failed)}")
    
    if len(successful) > 0:
        total_size_gb = successful['size_bytes'].sum() / (1024**3)
        total_time = tracker.start_time and (time.time() - tracker.start_time) or 0
        avg_rate = successful['rate_mbps'].mean()
        max_rate = successful['rate_mbps'].max()
        min_rate = successful['rate_mbps'].min()
        
        print(f"\nDownload Statistics:")
        print(f"  Total size: {total_size_gb:.2f} GB")
        print(f"  Total time: {total_time:.1f} seconds")
        print(f"  Overall rate: {(total_size_gb * 1024) / total_time:.2f} MB/s")
        print(f"  Average rate per thread: {avg_rate:.2f} MB/s")
        print(f"  Max rate: {max_rate:.2f} MB/s")
        print(f"  Min rate: {min_rate:.2f} MB/s")
    
    if len(failed) > 0:
        print(f"\nFailed downloads:")
        for _, row in failed.iterrows():
            print(f"  - {row['filename']}: {row['error']}")
    
    return results_df, successful['filepath'].tolist(), failed['url'].tolist()


# Convenience function for DataFrame input
def download_from_dataframe(df, url_column='url', filename_column='filename',
                            output_dir=None, max_workers=4, token=None,
                            archive="roman", datagroup="rita"):
    """
    Download files from a DataFrame containing URLs and filenames.
    
    Args:
        df: pandas DataFrame
        url_column: name of column containing URLs
        filename_column: name of column containing filenames
        output_dir: directory to save files
        max_workers: number of parallel download threads
        token: API token
        archive: archive name
        datagroup: data group
    
    Returns:
        Tuple of (results_df, downloaded_files, failed_downloads)
    """
    urls = df[url_column].tolist()
    
    # Get filenames if column exists
    if filename_column in df.columns:
        filenames = df[filename_column].tolist()
    else:
        filenames = None
    
    return parallel_download_cassi_files(
        urls,
        output_dir=output_dir,
        token=token,
        archive=archive,
        datagroup=datagroup,
        max_workers=max_workers,
        filenames=filenames
    )