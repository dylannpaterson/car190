import re
import numpy as np
import s3fs
import asdf
import roman_datamodels as rdm
from roman_datamodels import dqflags
from pathlib import Path
import pandas as pd
from astropy.table import Table


# Utility function to open a given asdf file
def open_asdf_datamodel(asdf_uri: str, anon: bool = True):
    """
    Open an ASDF file from S3 or locally and return a Roman datamodel
    """
    if asdf_uri.startswith("s3://"):
        fs = s3fs.S3FileSystem(anon=anon)
        with fs.open(asdf_uri, "rb") as fb:
            with asdf.open(fb) as af:
                return rdm.open(af).copy()
    else:
        with open(asdf_uri, "rb") as fb:
            with asdf.open(fb) as af:
                return rdm.open(af).copy()


def list_all_keys(tree, path="", max_depth=10, current_depth=0):
    """List all keys in the tree with their paths

    Example fields of interest for telemetry:
    data = asdf.open(filename)
    data["roman"]['meta']['hdf5_telemetry'])
    data["roman"]['meta']['hdf5_meta'].keys()
    """
    if current_depth > max_depth:
        return
    
    if isinstance(tree, dict):
        for key, value in tree.items():
            current_path = f"{path}.{key}" if path else key
            print(f"{current_path}: {type(value).__name__}")
            list_all_keys(value, current_path, max_depth, current_depth + 1)


def extract_otp_data(directory, save_csv=False, glob_wildcard='*.asdf'):
    """
    Go through each asdf file and extract some information to a pandas table
    Currently just gets the OTP info

    if save_csv, save a csv digest of the files in the path.
    """
    data = []
    
    asdf_files = sorted(Path(directory).glob(glob_wildcard))

    #print("Evaluating files: ", asdf_files)
    for filepath in asdf_files:
        try:
            with asdf.open(filepath) as af:
                row = {'filename': filepath.name}
                orig_path = af['roman']['meta']['hdf5_meta']['Frames_attrs']['filepath_level_pnt5']
                row["OTP"] = orig_path.split("/")[-3]
                row["Activity"], row["Exposure"] = activity, exp_num = orig_path.split("/")[-2].split("_")

                print(row)
                data.append(row)
                
        except Exception as e:
            print(f"Error processing {filepath.name}: {e}")

    if save_csv:
        df = pd.DataFrame(data)
        filename = directory.split("/")[-1] + ".csv"
        csv_path = f"{directory}/{filename}"
        df.to_csv(csv_path)

    return df


def extract_sca_info(filename):
    """Return both SCA name and number"""
    match = re.search(r'WFI(\d+)', filename)
    if match:
        number = int(match.group(1))
        return pd.Series({'SCA': f'SCA{number}', 'SCA_num': number})
    return pd.Series({'SCA': None, 'SCA_num': None})


def read_sca_center_spec(sca_center_spec):
    sca_centers_tab = Table.read(sca_center_spec, format='ascii.ecsv')

    # These are either 0 or 180, choose a threshold for "flipped"
    sca_centers_tab['flip'] = sca_centers_tab['rotation'] >= 90

    sca_centers = {}
    sca_flips = {}
    for row in sca_centers_tab:
        sca_name = row['label']
        sca_centers[sca_name] = np.array([row['x_center'], row['y_center']])
        sca_flips[sca_name] = row['flip']

    return sca_centers, sca_flips

    
def process_otp_df(df, otp_name=None, activity=None, exposure=None,
                   sca_center_spec=None, change_suffix=None):
    """Filter dataframe based on provided parameters
    Populate the SCA names, indices and positions (if given a position ecsv)
    The change suffix can be used to change to different romancal outputs
    For example: change uncal to "assignwcs" as an output of that step.
    """
    filtered_df = df.copy()
    
    if otp_name is not None:
        filtered_df = filtered_df[filtered_df['OTP'] == otp_name]
    
    if activity is not None:
        filtered_df = filtered_df[filtered_df['Activity'] == activity]
    
    if exposure is not None:
        filtered_df = filtered_df[filtered_df['Exposure'] == exposure]

    filtered_df.loc[:,['SCA', 'SCA_num']] = filtered_df['filename'].apply(extract_sca_info)

    if change_suffix is not None:
        filtered_df['filename'] = df['filename'].str.replace(f'_{change_suffix[0]}',
                                                             f'_{change_suffix[1]}')
    
    if sca_center_spec is not None:
        sca_centers, sca_flips = read_sca_center_spec(sca_center_spec)
        
        filtered_df.loc[:, 'flip'] = filtered_df['SCA'].map(sca_flips)
        #filtered_df.loc['center'] = filtered_df['SCA'].map(sca_centers)
        filtered_df.loc[:, 'x_center'] = filtered_df['SCA'].map(lambda sca: sca_centers.get(sca, [np.nan, np.nan])[0])
        filtered_df.loc[:, 'y_center'] = filtered_df['SCA'].map(lambda sca: sca_centers.get(sca, [np.nan, np.nan])[1])
    
    return filtered_df


def dq_mask_select(dq_array, names="any", kind="pixel"):
    """
    Build a Boolean mask from a DQ bitfield using enum names

    dq_array is the input .dq
    names: list[str] or str of all names to cut, "any" "ALL" use all masks
    king: "pixel" or "group"
    """
    if isinstance(names, str):
        if names.lower() in ("any", "all"):
            return dq_array > 0

    if isinstance(names, str):
        names = [names]

    bits = 0
    table = getattr(dqflags, kind)
    for name in names:
        bits |= table[name]

    return (dq_array & bits) != 0


def dq_mask_hist(dq_array, kind="pixel", exclude_empty=True):
    """
    Count the number of masked pixels by type

    if `exclude_empty` then do not report empty mask types.
    """
    dq_flat = np.asarray(dq_array).ravel()
    n = dq_flat.size
    table = getattr(dqflags, kind)
    
    out = {}
    for table_entry in table:
        bit = table_entry.value
        name = table_entry.name
        counts = np.count_nonzero((dq_flat & bit) != 0)
        if counts == 0:
            if not exclude_empty:
                out[name] = counts
        else:
            out[name] = counts
    
    return out