#!/usr/bin/env python3
"""
Estimate the execution time of each survey target in a Roman WFI APT program.

APT files store no time estimates, so this applies a visit-duration model
calibrated on ODF visit durations from commissioning OPUPs (CAR-192, CAR-201,
CAR-917, CAR-169.1). Visits are built from the APT fields as follows:
  - each observation becomes one visit per mosaic position (Sector ->
    MosaicPattern) and per Repeat. Grid tiles are spaced by the effective
    WFI field (0.821 x 0.420 deg) minus the overlap, taken column by column;
    Custom offsets are arcmin. Both are in the WFI ideal frame. This matches
    the executed CAR-147 mosaic and interchip-dither visits.
  - within a visit, a large dither (e.g. BOXGAP6) gives 6 guided pointings
  - each pointing takes SubpixelDither (NONE=1, SUB2, SUB3, SUB4, ...) times
    NumberOfExposures exposures
  - the pointing is the FiducialPointOverrideAperture, or WFI_CEN without one
Per visit:

    time = 28.9 s per pointing (guide star acquisition, settle)
         + 15.2 s per additional exposure at a pointing (sub-pixel offset or repeat)
         + 3 s per spectroscopic exposure
         + exposures x read frames x frame time
         + 41.5 s per degree of slew from the previous visit
         + 10 s per extra filter-wheel slot moved (a 1-slot move is free)

For a SUB4 visit this gives the 74.5 s overhead measured for CAR-201. Frame
time is 3.16 s for imaging (IM_) and 5.17 s for spectroscopic (SP_) tables.
Named tables use their nominal exposure time (IM_171_10 -> 54 frames,
SP_300_16 -> 58 frames); *_DIAGNOSTIC tables read resultants - 1 frames, as
commanded in the CAR-141.1 and CAR-915 visit files. Slews between large
dither positions within a visit are not modeled (a few seconds each).
Consecutive observations on the same mosaic take the tiles in reverse order,
so a filter change needs no slew. The model is 1-4 s per visit shorter than
the ODF for CAR-147 (mosaic tiles, prism visits) and CAR-141.1 (named and
diagnostic tables); actual execution took about 13-29 s per visit longer
than the ODF.

The slew onto each new target is not included (the ODF includes it in the
first visit on the target, often 0.5-1 h).

The top-level working copy and every execution plan in the file are estimated
separately (see apt_survey_check.py). Execution plans whose survey plan is
identical to the top level get the same estimate and are summarized in one
line; those that differ are flagged and shown in full.

Aperture positions: the Roman SIAF bundled with pysiaf is pre-flight (WFI_CEN
V2/V3 = 1546.385/-892.792 arcsec vs 1686.548/-1014.664 in-flight). The detectors
shift nearly together, so slews and totals change by <0.1%, but pass --siaf with
an in-flight SIAF file when one is available. A warning is printed if the
loaded SIAF has the pre-flight WFI_CEN.

To run (needs pysiaf, e.g. the opup-review conda env):
    python shared/apt_time_estimate.py program.apt [--siaf roman_siaf_inflight.xml] [--csv visits.csv] [--log out.log]

Can also be imported (apt_survey_check.py must be importable from the same directory):
    from apt_time_estimate import estimate_visit_times
"""

import argparse
import logging
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
import pandas as pd
import pysiaf

# shared/ is not a package; make the sibling module importable even under "python -I"
sys.path.insert(0, str(Path(__file__).resolve().parent))
from apt_survey_check import APT_NS, get_scope, plan_scopes, survey_plan_differences  # noqa: E402

# Visit-model constants, in seconds
T_POINTING = 28.9
T_EXTRA_EXPOSURE = 15.2
T_SPEC_EXPOSURE = 3.0      # extra per spectroscopic exposure (CAR-147, CAR-192, CAR-915 ODFs: 1.5-4 s)
T_FRAME_IMAGING = 3.16
T_FRAME_SPECTRO = 5.17
T_SLEW_PER_DEG = 41.5
T_EWA_PER_SLOT = 10.0
DEFAULT_APERTURE = "WFI_CEN"
# Effective WFI field (deg) along the ideal X (long) and Y axes for mosaic tiling, from the
# 0.698 x 0.357 deg tile steps of the CAR-147 2x2 grid with 15% overlap (OPUP 2026295172947)
WFI_FIELD_DEG = (0.821, 0.420)
# Element wheel positions in order around the wheel
EWA_SLOTS = ["GRISM", "F213", "F062", "F106", "F129", "PRISM", "F158", "F184", "F146", "F087", "DARK"]
# WFI_CEN V2 (arcsec) in the pre-flight SIAF bundled with pysiaf; in-flight is 1686.548
PREFLIGHT_WFI_CEN_V2 = 1546.385

logger = logging.getLogger(__name__)


def exposure_time(ma_table, resultants):
    """Read frames and duration of one exposure with an APT MA table.

    Args:
        ma_table (str): APT MultiAccumTable name, e.g. "IM_DIAGNOSTIC", "IM_171_10" or "SP_300_16".
        resultants (int or str): APT Resultant count.

    Returns:
        tuple: (read frames, exposure time in seconds).

    Raises:
        ValueError: If the table is not an IM_ or SP_ DIAGNOSTIC or <seconds>_<resultants> table.
    """
    match = re.match(r"(IM|SP)_(DIAGNOSTIC|\d+)", ma_table or "")
    if match is None:
        raise ValueError(f"Cannot infer read frames for MA table {ma_table!r}; "
                         "only IM_ and SP_ tables are supported")
    t_frame = T_FRAME_IMAGING if match.group(1) == "IM" else T_FRAME_SPECTRO
    if match.group(2) == "DIAGNOSTIC":
        frames = int(resultants) - 1
    else:
        frames = round(int(match.group(2)) / t_frame)
    return frames, frames * t_frame


def estimate_visit_times(apt_path, siaf=None, execution_plan=None):
    """Estimate the duration of every visit in the survey plan of an APT program.

    Args:
        apt_path (str or Path): Path to the .apt file.
        siaf (pysiaf.Siaf, optional): Roman SIAF used for aperture positions.
            Defaults to the (pre-flight) Roman SIAF bundled with pysiaf.
        execution_plan (int, optional): Execution plan to estimate. None uses
            the top-level working copy.

    Returns:
        pandas.DataFrame: One row per visit in execution order, with columns
        step, pass_plan, target, label, filter, aperture, mosaic_position,
        pointings, exposures, frames, and the time components t_exposure,
        t_overhead, t_slew, t_ewa, t_total (seconds).

    Raises:
        ValueError: If an observation uses an unsupported MA table, dither or
            mosaic pattern, or a Sector that is not defined in MosaicPatterns.
    """
    if siaf is None:
        siaf = pysiaf.Siaf("Roman")
    root = ET.parse(apt_path).getroot()
    scope, targets = get_scope(root, execution_plan)
    pass_plans = {pp.get("Number"): pp for pp in scope.find("a:PassPlans", APT_NS)}

    # ---------- Mosaic patterns: offsets (V2, V3 arcsec) of each mosaic position ----------
    # Offsets are laid out in the WFI_CEN ideal frame (X = long axis of the field), then rotated to V2/V3
    patterns_elem = scope.find("a:MosaicPatterns", APT_NS)
    if patterns_elem is None:
        patterns_elem = root.find("a:MosaicPatterns", APT_NS)
    cen = siaf[DEFAULT_APERTURE]
    mosaics = {}
    for pattern in (patterns_elem if patterns_elem is not None else []):
        kind = pattern.findtext("a:MosaicType", namespaces=APT_NS)
        if kind == "Grid":
            n_rows = int(pattern.findtext("a:NumRows", namespaces=APT_NS))
            n_cols = int(pattern.findtext("a:NumCols", namespaces=APT_NS))
            step_x = WFI_FIELD_DEG[0] * 3600 * (1 - float(pattern.findtext("a:ColOverlap", namespaces=APT_NS) or 0) / 100)
            step_y = WFI_FIELD_DEG[1] * 3600 * (1 - float(pattern.findtext("a:RowOverlap", namespaces=APT_NS) or 0) / 100)
            ideal = []
            for c in range(n_cols):
                rows = range(n_rows) if c % 2 == 0 else reversed(range(n_rows))   # column by column, serpentine
                ideal += [((c - (n_cols - 1) / 2) * step_x, (r - (n_rows - 1) / 2) * step_y) for r in rows]
        elif kind == "Custom":
            ideal = [(float(o.get("X")) * 60, float(o.get("Y")) * 60) for o in pattern.findall("a:Offset", APT_NS)]
        else:
            raise ValueError(f"Mosaic pattern {pattern.get('Number')} has unsupported MosaicType {kind!r}")
        offsets = []
        for x, y in ideal:
            v2, v3 = cen.idl_to_tel(x, y)
            offsets.append((float(v2) - cen.V2Ref, float(v3) - cen.V3Ref))
        mosaics[pattern.get("Number")] = offsets

    rows = []
    prev_target = prev_filter = prev_v2v3 = None
    prev_mosaic = None   # (sector, aperture, ordered offsets) of the previous observation's visits
    steps = scope.find("a:SurveyPlan", APT_NS).findall("a:SurveyPlanStep", APT_NS)
    for i, step in enumerate(steps, 1):
        pp = pass_plans[step.findtext("a:PassPlan", namespaces=APT_NS)]
        # TargetSelection looks like "Fixed: 3"
        selection = pp.findtext("a:TargetSelection", namespaces=APT_NS) or ""
        target = targets.get(selection.split(":")[-1].strip(), selection)
        if target != prev_target:
            prev_v2v3 = None  # the slew onto a new target is not included
        label = pp.findtext("a:Label", namespaces=APT_NS)

        for _ in range(int(step.findtext("a:Repeat", namespaces=APT_NS) or 1)):
            for obs in pp.findall("a:Observation", APT_NS):
                aperture = obs.findtext(".//a:FiducialPointOverrideAperture", namespaces=APT_NS) or DEFAULT_APERTURE
                filt = obs.findtext("a:OpticalElement", namespaces=APT_NS)
                frames, t_one = exposure_time(obs.findtext("a:MultiAccumTable", namespaces=APT_NS),
                                              obs.findtext("a:Resultant", namespaces=APT_NS))

                # Pointings per visit (large dither) and exposures per pointing (sub-pixel dither x exposures)
                dither = obs.findtext("a:Dither", namespaces=APT_NS) or "NONE"
                match = re.search(r"(\d+)$", dither)
                if dither != "NONE" and match is None:
                    raise ValueError(f"Pass plan {pp.get('Number')} ({label}): cannot count positions of dither {dither!r}")
                n_pointings = int(match.group(1)) if match else 1
                subpixel = re.search(r"(\d+)", obs.findtext("a:SubpixelDither", namespaces=APT_NS) or "")
                n_per_pointing = (int(subpixel.group(1)) if subpixel else 1) * \
                    int(obs.findtext("a:NumberOfExposures", namespaces=APT_NS) or 1)
                n_exposures = n_pointings * n_per_pointing

                sector = obs.findtext("a:Sector", namespaces=APT_NS) or "NONE"
                if sector != "NONE" and sector not in mosaics:
                    raise ValueError(f"Pass plan {pp.get('Number')} ({label}): Sector {sector} is not a defined mosaic pattern")
                positions = list(enumerate(mosaics.get(sector, [(0.0, 0.0)]), 1))
                # Consecutive observations on the same mosaic take the tiles in reverse order,
                # so the next one starts where the previous one ended (as in CAR-147)
                if sector != "NONE" and prev_mosaic is not None and prev_mosaic[:2] == (sector, aperture):
                    positions = prev_mosaic[2][::-1]

                for _ in range(int(obs.findtext("a:Repeat", namespaces=APT_NS) or 1)):
                    for k, (d_v2, d_v3) in positions:
                        # Slew from the previous visit, between V2/V3 reference points (arcsec)
                        v2v3 = np.array([siaf[aperture].V2Ref + d_v2, siaf[aperture].V3Ref + d_v3])
                        slew_deg = 0.0 if prev_v2v3 is None else np.hypot(*(v2v3 - prev_v2v3)) / 3600

                        # Filter-wheel move, counted the short way around the wheel
                        t_ewa = 0.0
                        if prev_filter is not None and filt != prev_filter:
                            distance = abs(EWA_SLOTS.index(filt) - EWA_SLOTS.index(prev_filter))
                            slots = min(distance, len(EWA_SLOTS) - distance)
                            t_ewa = T_EWA_PER_SLOT * max(0, slots - 1)

                        t_exposure = n_exposures * t_one
                        t_overhead = T_POINTING * n_pointings + T_EXTRA_EXPOSURE * (n_exposures - n_pointings)
                        if obs.findtext("a:MultiAccumTable", namespaces=APT_NS).startswith("SP_"):
                            t_overhead += T_SPEC_EXPOSURE * n_exposures
                        t_slew = T_SLEW_PER_DEG * slew_deg
                        rows.append({
                            "step": i, "pass_plan": pp.get("Number"), "target": target, "label": label,
                            "filter": filt, "aperture": aperture, "mosaic_position": k if sector != "NONE" else 0,
                            "pointings": n_pointings, "exposures": n_exposures, "frames": frames,
                            "t_exposure": t_exposure, "t_overhead": t_overhead, "t_slew": t_slew, "t_ewa": t_ewa,
                            "t_total": t_exposure + t_overhead + t_slew + t_ewa,
                        })
                        prev_target, prev_filter, prev_v2v3 = target, filt, v2v3
                prev_mosaic = (sector, aperture, positions) if sector != "NONE" else None
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser(description="Estimate execution time per survey target of a Roman WFI APT program.")
    parser.add_argument("apt_file", type=Path, help="APT program file (.apt)")
    parser.add_argument("--siaf", type=Path,
                        help="in-flight Roman SIAF XML file (default: the pre-flight SIAF bundled with pysiaf)")
    parser.add_argument("--csv", type=Path, help="write the per-visit estimates to this CSV file")
    parser.add_argument("--log", type=Path, help="also write the report to this log file")
    args = parser.parse_args()

    # --------- Setup logging to terminal (and optional file) --------
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    if args.log:
        logging.getLogger().addHandler(logging.FileHandler(args.log, mode="w"))

    if args.siaf:
        # basepath is required: with filename alone, pysiaf silently loads its bundled SIAF
        siaf = pysiaf.Siaf("Roman", basepath=str(args.siaf.resolve().parent), filename=args.siaf.name)
    else:
        siaf = pysiaf.Siaf("Roman")
    if abs(siaf["WFI_CEN"].V2Ref - PREFLIGHT_WFI_CEN_V2) < 0.01:
        logger.info(f"WARNING: using a pre-flight Roman SIAF (WFI_CEN V2 = {siaf['WFI_CEN'].V2Ref:.3f} arcsec). "
                    "Pass --siaf with an in-flight SIAF file for current aperture positions.")

    all_visits = []
    top_total = None
    for scope in plan_scopes(args.apt_file):
        ep = scope["execution_plan"]
        visits = estimate_visit_times(args.apt_file, siaf=siaf, execution_plan=ep)
        all_visits.append(visits.assign(execution_plan="top" if ep is None else ep))
        total_h = visits["t_total"].sum() / 3600
        logger.info(f"\n{'=' * 70}\n{scope['name']}  [segments: {scope['segment_status']}]\n{'=' * 70}")

        # ---------- Execution plans identical to the top level: one line ----------
        if ep is None:
            top_total = total_h
        else:
            differences = survey_plan_differences(args.apt_file, ep)
            if not differences:
                logger.info(f"Survey plan identical to the top level: {len(visits)} visits, {total_h:.2f} h")
                continue
            logger.info(f"WARNING: survey plan differs from the top level: {', '.join(differences)}")
            logger.info(f"Total {total_h:.2f} h vs {top_total:.2f} h for the top level")

        # ---------- Per-target summary, in execution order ----------
        by_target = visits.groupby("target", sort=False).agg(
            steps=("step", lambda s: f"{s.min()}-{s.max()}"), visits=("step", "size"), exposures=("exposures", "sum"),
            exposure_min=("t_exposure", "sum"), overhead_min=("t_overhead", "sum"),
            slew_min=("t_slew", "sum"), ewa_min=("t_ewa", "sum"), total_h=("t_total", "sum"))
        by_target[["exposure_min", "overhead_min", "slew_min", "ewa_min"]] /= 60
        by_target["total_h"] /= 3600
        logger.info("\nEstimated time per target (slews between targets not included):\n")
        logger.info(by_target.round(2).to_string())
        logger.info(f"\nTotal: {len(visits)} visits, {visits['exposures'].sum()} exposures, {total_h:.2f} h")

        # ---------- Per-step breakdown ----------
        by_step = visits.groupby("step").agg(
            pass_plan=("pass_plan", "first"), target=("target", "first"), label=("label", "first"),
            filters=("filter", lambda s: ",".join(sorted(set(s)))), visits=("filter", "size"),
            exposures=("exposures", "sum"), frames=("frames", lambda s: ",".join(map(str, sorted(set(s))))),
            total_min=("t_total", "sum"))
        by_step["total_min"] /= 60
        logger.info("\nEstimated time per survey step:\n")
        logger.info(by_step.round(1).to_string())

    if args.csv:
        table = pd.concat(all_visits, ignore_index=True)
        table.insert(0, "execution_plan", table.pop("execution_plan"))
        table.to_csv(args.csv, index=False)
        logger.info(f"\nPer-visit estimates for all plans written to: {args.csv}")


if __name__ == "__main__":
    main()
