from pathlib import Path
import os
import requests
import pandas as pd
from tqdm import tqdm

def load_env_file(filepath='~/.env'):
    filepath = Path(filepath).expanduser()  # Expands ~ to /home/user
    if not filepath.exists():
        raise FileNotFoundError(f"Environment file not found: {filepath}")

    print(f"Loading environment variable file: {filepath}")
    with open(filepath, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                key, value = line.split('=', 1)
                # Remove quotes if present
                value = value.strip().strip('"').strip("'")
                os.environ[key.strip()] = value


load_env_file()

def download_cassi_file(product_url, output_filename=None, token=None, 
                        endpoint_url=None, output_dir=None, archive="roman", datagroup="rita"):
    """
    Download a file from CASSI API.
    
    Args:
        product_url: URL of the product to download
        output_filename: Name for the downloaded file (if None, extracts from URL)
        token: API token (if None, will try MAST_API_TOKEN env var)
        endpoint_url: Download endpoint (defaults to Roman RITA)
        output_dir: Directory to save file (defaults to current directory)
        archive: archive name (default: "roman")
        datagroup: data group (default: "rita")
    
    Returns:
        Path to downloaded file
    """
    # Get token
    if token is None:
        token = os.environ.get('MAST_API_TOKEN')
        if not token:
            raise ValueError(
                "No token provided. Set MAST_API_TOKEN environment variable or pass token parameter."
            )
    
    # Default endpoint
    if endpoint_url is None:
        endpoint_url = f"https://mast.stsci.edu/cassi/api/v0.1/download/{archive}/{datagroup}"
    
    # Extract filename from URL if not provided
    if output_filename is None:
        output_filename = product_url.split('/')[-1]
    
    # Set output directory
    if output_dir is not None:
        output_path = Path(output_dir) / output_filename
        output_path.parent.mkdir(parents=True, exist_ok=True)
    else:
        output_path = Path(output_filename)
    
    # Build payload
    payload = {
        "product_url": product_url
    }
    
    # Set headers
    headers = {
        "Authorization": f"token {token}",
        "Content-Type": "application/json"
    }
    
    # Make request (stream=True for large files)
    print(f"Downloading {product_url}...")
    print(f"Using endpoint: {endpoint_url}")
    response = requests.post(
        endpoint_url, 
        json=payload, 
        headers=headers,
        stream=True  # Important for large files
    )
    
    # Check for errors
    if response.status_code != 200:
        print(f"Error: {response.status_code}")
        print(f"Response: {response.text}")
        response.raise_for_status()
    
    # Write file in chunks
    with open(output_path, 'wb') as f:
        for chunk in response.iter_content(chunk_size=8192):
            if chunk:
                f.write(chunk)
    
    print(f"Successfully downloaded to: {output_path}")
    return output_path


def batch_download_cassi_files(product_urls, output_dir=None, token=None, 
                                archive="roman", datagroup="rita"):
    """
    Download multiple files from CASSI.
    
    Args:
        product_urls: List of product URLs or dict of {url: filename}
        output_dir: Directory to save files
        token: API token
        archive: archive name (default: "roman")
        datagroup: data group (default: "rita")
    
    Returns:
        Tuple of (downloaded_files, failed_downloads)
    """
    if token is None:
        token = os.environ.get('MAST_API_TOKEN')
        if not token:
            raise ValueError(
                "No token provided. Set MAST_API_TOKEN environment variable or pass token parameter."
            )
    
    downloaded_files = []
    failed_downloads = []
    
    # Handle both list and dict inputs
    if isinstance(product_urls, dict):
        items = product_urls.items()
    else:
        items = [(url, None) for url in product_urls]
    
    for url, filename in items:
        try:
            filepath = download_cassi_file(
                url, 
                output_filename=filename,
                token=token,
                output_dir=output_dir,
                archive=archive,
                datagroup=datagroup
            )
            downloaded_files.append(filepath)
        except Exception as e:
            print(f"Failed to download {url}: {e}")
            failed_downloads.append(url)
    
    print(f"\nDownload complete: {len(downloaded_files)} succeeded, {len(failed_downloads)} failed")
    return downloaded_files, failed_downloads


def download_cassi_file_with_progress(product_url, output_filename=None, 
                                       token=None, endpoint_url=None, 
                                       output_dir=None, archive="roman", datagroup="rita"):
    """
    Download a file from CASSI API with progress bar.
    """    
    if token is None:
        token = os.environ.get('MAST_API_TOKEN')
        if not token:
            raise ValueError("No token provided.")
    
    if endpoint_url is None:
        endpoint_url = f"https://mast.stsci.edu/cassi/api/v0.1/download/{archive}/{datagroup}"
    
    if output_filename is None:
        output_filename = product_url.split('/')[-1]
    
    if output_dir is not None:
        output_path = Path(output_dir) / output_filename
        output_path.parent.mkdir(parents=True, exist_ok=True)
    else:
        output_path = Path(output_filename)
    
    payload = {"product_url": product_url}
    headers = {
        "Authorization": f"token {token}",
        "Content-Type": "application/json"
    }
    
    response = requests.post(endpoint_url, json=payload, headers=headers, stream=True)
    
    if response.status_code != 200:
        print(f"Error: {response.status_code} - {response.text}")
        response.raise_for_status()
    
    # Get file size if available
    total_size = int(response.headers.get('content-length', 0))
    
    # Download with progress bar
    with open(output_path, 'wb') as f, tqdm(
        desc=output_filename,
        total=total_size,
        unit='iB',
        unit_scale=True,
        unit_divisor=1024,
    ) as pbar:
        for chunk in response.iter_content(chunk_size=8192):
            size = f.write(chunk)
            pbar.update(size)
    
    return output_path


def build_cassi_query(select_cols, conditions_dict, limit=100, offset=0):
    """
    Build CASSI API query payload.
    
    Args:
        select_cols: list of column names
        conditions_dict: dict where values can be strings or lists
        limit: max results
        offset: pagination offset
    """
    payload = {
        "select_cols": select_cols,
        "conditions": [
            {key: value} for key, value in conditions_dict.items()
        ],
        "limit": limit,
        "offset": offset
    }
    return payload


def flatten_cassi_dataframe(df):
    """
    Flatten nested dictionaries in CASSI results DataFrame.
    """
    # Handle 'asset' nested structure
    if 'asset' in df.columns:
        # Extract URL
        df['url'] = df['asset'].apply(
            lambda x: x.get('distribution', {}).get('url', {}).get('mast', None) 
            if isinstance(x, dict) else None
        )
        # Extract size
        df['file_size'] = df['asset'].apply(
            lambda x: x.get('distribution', {}).get('size', None) 
            if isinstance(x, dict) else None
        )
        # Drop original asset column
        df = df.drop('asset', axis=1)
    
    # Handle 'fileset' nested structure
    if 'fileset' in df.columns:
        df['fileSetSize'] = df['fileset'].apply(
            lambda x: x.get('fileSetSize', None) 
            if isinstance(x, dict) else None
        )
        df = df.drop('fileset', axis=1)
    
    return df


def query_cassi_api(select_cols, conditions_dict, limit=100, offset=0,
                    archive="rita", epoch="TVAC1", flatten=True, verbose=True,
                    token=None, endpoint_url=None):
    """
    Query the CASSI API with authentication.
    
    Args:
        select_cols: list of column names
        conditions_dict: dict of search conditions
        limit: max results to return
        offset: pagination offset
        archive: archive name (default: "rita")
        epoch: epoch name (default: "TVAC1")
        token: API token (if None, will try to get from CASSI_TOKEN env var)
        endpoint_url: API endpoint URL (defaults to Roman SSC endpoint)
        flatten: if True, flatten nested asset/fileset structures
        verbose: if True, print summary information
    
    Returns:
        pandas DataFrame with results
    """
    # Get token from environment if not provided
    if token is None:
        token = os.environ.get('MAST_API_TOKEN')
        if not token:
            raise ValueError(
                "No token provided. Set $MAST_API_TOKEN environment variable or pass token parameter."
            )
    
    # Default endpoint
    if endpoint_url is None:
        endpoint_url = f"https://mast.stsci.edu/cassi/api/v0.1/{archive}/search/{epoch}"

    # Build payload
    payload = build_cassi_query(select_cols, conditions_dict, limit, offset)
    
    # Set headers with authentication
    headers = {
        "Authorization": f"token {token}",
        "Content-Type": "application/json"
    }
    
    # Make request
    response = requests.post(endpoint_url, json=payload, headers=headers)
    
    # Check for errors
    if response.status_code != 200:
        print(f"Error: {response.status_code}")
        print(f"Response: {response.text}")
        response.raise_for_status()

    data = response.json()
    if 'results' not in data or len(data['results']) == 0:
        if verbose:
            print("No results found")

        return pd.DataFrame()

    df = pd.DataFrame(data['results'])
    if flatten:
        df = flatten_cassi_dataframe(df)

    if verbose:
        total = data.get('totalResults', len(df))
        print(f"Retrieved {len(df)} of {total} total results")
        if len(df) < total:
            print(f"Use offset={offset + limit} to get next batch")

    return df