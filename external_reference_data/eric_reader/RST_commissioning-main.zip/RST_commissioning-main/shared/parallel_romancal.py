"""
Library for processing exposure files serially or in parallel.
"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import traceback
from rst_commissioning import file_utils as futil
from romancal.pipeline import ExposurePipeline


def process_single_file(uncal_path, pipe_kwargs):
    """
    Process a single uncal.asdf file.
    
    Returns:
        tuple of (filename, success, error_message)
    """
    filename = uncal_path.name
    try:
        print(f"STARTING: {filename}")
        
        # Open the file using futil
        f = futil.open_asdf_datamodel(str(uncal_path))
        
        try:
            # Create output filename and directory
            output_filename = uncal_path.name.replace('_uncal.asdf', '_cal.asdf')
            output_dir = str(uncal_path.parent.absolute())
            output_file_rel = str(uncal_path.parent / output_filename)
            
            # Update pipe_kwargs with output info
            local_kwargs = pipe_kwargs.copy()
            #local_kwargs['output_file'] = output_file_rel
            local_kwargs['output_dir'] = output_dir
            
            # Run the pipeline
            print("KWARGS", local_kwargs)
            res = ExposurePipeline.call(f, **local_kwargs)
        finally:
            f.close()
        
        print(f"COMPLETED: {filename}")
        return (filename, True, None)
        
    except Exception as e:
        error_msg = f"{filename} failed: {e}\n{traceback.format_exc()}"
        print(f"ERROR: {error_msg}")
        return (filename, False, error_msg)


def process_directory_serial(input_dir, pipe_kwargs, pattern="*_uncal.asdf"):
    """
    Process all matching files serially (for debugging).
    
    Args:
        input_dir: Directory to search for files
        pipe_kwargs: Keyword arguments to pass to ExposurePipeline.call()
        pattern: Glob pattern for finding files
    """
    input_path = Path(input_dir)
    uncal_files = sorted(input_path.glob(pattern))
    
    if not uncal_files:
        print(f"No files matching '{pattern}' found in {input_dir}")
        return []
    
    print(f"Found {len(uncal_files)} files to process")
    print("-" * 60)
    
    results = []
    for uncal_file in uncal_files:
        filename, success, error = process_single_file(uncal_file, pipe_kwargs)
        results.append((filename, success, error))
        
        # Optional: break on first error for debugging
        # if not success:
        #     print(f"Stopping due to error in {filename}")
        #     break
    
    # Print summary
    print("-" * 60)
    print(f"\nProcessing complete:")
    successes = sum(1 for _, success, _ in results if success)
    print(f"  Successful: {successes}/{len(results)}")
    print(f"  Failed: {len(results) - successes}/{len(results)}")
    
    # Print failed files
    failed = [(name, err) for name, success, err in results if not success]
    if failed:
        print("\nFailed files:")
        for name, err in failed:
            print(f"  - {name}")
    
    return results


def process_directory_parallel(input_dir, pipe_kwargs, pattern="*_uncal.asdf", max_workers=None):
    """
    Process all matching files in parallel.
    
    Args:
        input_dir: Directory to search for files
        pipe_kwargs: Keyword arguments to pass to ExposurePipeline.call()
        pattern: Glob pattern for finding files
        max_workers: Maximum number of parallel processes (None = CPU count)
    """
    input_path = Path(input_dir)
    uncal_files = sorted(input_path.glob(pattern))
    
    if not uncal_files:
        print(f"No files matching '{pattern}' found in {input_dir}")
        return []
    
    print(f"Found {len(uncal_files)} files to process")
    print(f"Processing with max_workers={max_workers or 'CPU count'}")
    print("-" * 60)
    
    results = []
    
    # Use ProcessPoolExecutor for parallel processing
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        # Submit all tasks
        future_to_file = {
            executor.submit(process_single_file, uncal_file, pipe_kwargs): uncal_file
            for uncal_file in uncal_files
        }
        
        # Process as they complete
        for future in as_completed(future_to_file):
            uncal_file = future_to_file[future]
            try:
                filename, success, error = future.result()
                results.append((filename, success, error))
                
                # Show progress
                print(f"Progress: {len(results)}/{len(uncal_files)} complete")
                
            except Exception as e:
                error_msg = f"Unexpected error processing {uncal_file.name}: {e}"
                print(f"ERROR: {error_msg}")
                results.append((uncal_file.name, False, error_msg))
    
    # Print summary
    print("-" * 60)
    print(f"\nProcessing complete:")
    successes = sum(1 for _, success, _ in results if success)
    print(f"  Successful: {successes}/{len(results)}")
    print(f"  Failed: {len(results) - successes}/{len(results)}")
    
    # Print failed files
    failed = [(name, err) for name, success, err in results if not success]
    if failed:
        print("\nFailed files:")
        for name, err in failed:
            print(f"  - {name}")
    
    return results