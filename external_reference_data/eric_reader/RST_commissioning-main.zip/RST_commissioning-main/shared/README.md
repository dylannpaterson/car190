# Shared Code

This directory contains reusable code and configuration files intended to support multiple activities.

Shared code should be treated more carefully than activity-local code because changes here may affect other users.

## When to add code here

Add code to `shared/` when:

- It is used by more than one activity.
- It replaces copied/pasted code.
- It implements a stable utility.
- Other users have agreed it is broadly useful.

If you are unsure, start with an activity-local helper file and promote it later.

## Expectations for shared code

Shared code should have:

- Clear names.
- Docstrings.
- Explicit inputs and outputs.
- Minimal hardcoded paths.
- Examples where helpful.
- Tests where practical.

## Pull requests

Changes to `shared/` should generally be made through a pull request.

This helps prevent accidental breakage and gives other users a chance to comment before shared behavior changes.
