#!/usr/bin/env python3
"""
Collect per-visit timing information from Roman OPUP tarballs into one CSV.

For each visit in each OPUP, combine the ODF entry (duration, mode, element,
guiding) with what the STOL visit file commands: MA tables and read frames,
number of exposures and sub-pixel offsets (SCF_AC_TARG_OFFSET_F), filter-wheel
moves, and the slew angle from the previous visit's commanded attitude.
The ODF Duration includes the slew at the start of the visit.

This table is what the visit-model constants in apt_time_estimate.py were
fitted to; rerun it on newer OPUPs to refine them.

To run:
    python shared/opup_visit_timing.py OPUP1_opup.tgz [OPUP2_opup.tgz ...] --csv visit_timing.csv

Each argument is an OPUP tarball as delivered (containing *_odf.json and a
nested SCF_*.tgz with the .vst visit files). Nothing is extracted to disk.
Can also be imported:
    from opup_visit_timing import collect_visit_timing
"""

import argparse
import io
import json
import logging
import re
import tarfile
from pathlib import Path

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


def collect_visit_timing(opup_paths):
    """Tabulate visit durations and commanded activities from OPUP tarballs.

    Args:
        opup_paths (list of str or Path): OPUP .tgz files.

    Returns:
        pandas.DataFrame: One row per visit, sorted by start time within each
        OPUP, with columns opup, visit, purpose, mode, element, guided,
        duration (s), nexp, ma, frames, noff, slewed, slew_deg, ewa.
        Multiple MA tables, frame counts, or EWA moves in one visit are joined
        with ";". slew_deg is NaN when the visit does not slew or the previous
        visit's attitude is unknown.

    Raises:
        ValueError: If an OPUP tarball has no ODF JSON or no SCF tarball.
    """
    rows = []
    for opup_path in map(Path, opup_paths):
        with tarfile.open(opup_path) as opup:
            names = opup.getnames()
            odf_name = next((n for n in names if n.endswith("_odf.json")), None)
            scf_name = next((n for n in names if Path(n).name.startswith("SCF_") and n.endswith(".tgz")), None)
            if odf_name is None or scf_name is None:
                raise ValueError(f"{opup_path} does not contain an *_odf.json and an SCF_*.tgz")
            visits = json.load(opup.extractfile(odf_name))["visits"]
            scf_bytes = opup.extractfile(scf_name).read()

        # ---------- Read all visit files from the nested SCF tarball ----------
        with tarfile.open(fileobj=io.BytesIO(scf_bytes)) as scf:
            vst_text = {Path(m.name).name: scf.extractfile(m).read().decode()
                        for m in scf.getmembers() if m.name.endswith(".vst")}

        prev_q = None
        for visit in sorted(visits, key=lambda v: v["Start"]):
            txt = vst_text.get(visit["Visit_File_Name"])
            if txt is None:
                prev_q = None
                continue

            # Slew angle from the previous visit's commanded attitude (ECI->BCS quaternion)
            slew = re.search(r"SCF_AM_SLEW_MAIN_F\(([-\d.eE]+),([-\d.eE]+),([-\d.eE]+),([-\d.eE]+)", txt)
            q = np.array([float(x) for x in slew.groups()]) if slew else None
            slew_deg = np.nan
            if q is not None and prev_q is not None:
                slew_deg = np.degrees(2 * np.arccos(min(1.0, abs(np.dot(q, prev_q)))))
            if q is not None:
                prev_q = q

            ma = re.findall(r'SETREADFRMS_F\(\d+,"([^"]+)",(\d+)\)', txt)
            rows.append({
                "opup": opup_path.name.removesuffix(".tgz"),
                "visit": visit["Visit_ID"],
                "purpose": visit.get("Intended_Purpose", "").split(" - ")[-1],
                "mode": visit.get("Science_Instrument_Mode", ""),
                "element": visit.get("WFI_Optical_Element", ""),
                "guided": visit.get("FGS_Guidance", ""),
                "duration": int(visit["Duration"]),
                "nexp": len(re.findall(r"WFI_EXPOSURE_START_F|WFI_SET_USER_ID_SCI_EXPOSE_F", txt)),
                "ma": ";".join(m[0] for m in ma),
                "frames": ";".join(m[1] for m in ma),
                "noff": len(re.findall(r"SCF_AC_TARG_OFFSET_F", txt)),
                "slewed": q is not None,
                "slew_deg": round(slew_deg, 4),
                "ewa": ";".join(re.findall(r'EWA_MOVE_ABS_F\("([^"]+)"\)', txt)),
            })
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser(description="Collect per-visit timing information from Roman OPUP tarballs.")
    parser.add_argument("opup_files", nargs="+", type=Path, help="OPUP .tgz files")
    parser.add_argument("--csv", type=Path, required=True, help="output CSV file")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(message)s")
    df = collect_visit_timing(args.opup_files)
    df.to_csv(args.csv, index=False)
    logger.info(f"CSV written to: {args.csv}  ({len(df)} visits from {len(args.opup_files)} OPUPs)")


if __name__ == "__main__":
    main()
