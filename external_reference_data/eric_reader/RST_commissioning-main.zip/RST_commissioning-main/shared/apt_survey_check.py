#!/usr/bin/env python3
"""
List the survey plan of a Roman APT program and flag irregular pass plans.

APT files (*.apt) are plain XML. Each pass plan holds observations, and each
observation sets a filter, MA table, resultant count, dither, and usually a
FiducialPointOverrideAperture (e.g. WFI07_FULL) that places the target on one
detector. The survey plan lists the pass plans in execution order.

A program can hold several copies of its plan:
  - the top level: the editable working copy shown in the APT GUI
  - <ExecutionPlans>: one numbered snapshot per processed submission, each with
    its own targets, pass plans, survey plan, and segment statuses (e.g.
    FLIGHT_READY, SCHEDULED). New submissions add a plan; old ones remain.
The top level can differ from what will execute, so every plan is checked.
Execution plans whose survey plan differs from the top level are flagged.

Each pass plan is checked for:
  - observations whose filter differs from the pass plan's majority filter,
    or from the filter named in its label
  - duplicated or missing apertures, relative to WFI01_FULL..WFI18_FULL
  - mixed MA tables, resultants, dithers, exposure counts, or repeats
Pass plans that are not used in the survey plan are listed, and checked too
with --all.

With --opup, the visit IDs in OPUP tarballs show which execution plan of this
program was uplinked: digits 1-5 of a visit ID are the program number and
digits 6-7 the execution plan.

Note that "pass N" in a CAR description usually means survey-step N, not the
PassPlan Number attribute. The output lists both.

To run:
    python shared/apt_survey_check.py program.apt [--all] [--opup OPUP1_opup.tgz ...] [--csv steps.csv] [--log out.log]

Only the Python standard library and pandas are needed. Can also be imported:
    from apt_survey_check import plan_scopes, survey_steps, find_irregularities
"""

import argparse
import collections
import json
import logging
import re
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

import pandas as pd

APT_NS = {"a": "http://www.stsci.edu/Roman/APT"}
ALL_SCA_APERTURES = [f"WFI{i:02d}_FULL" for i in range(1, 19)]
CHECKED_TAGS = ["MultiAccumTable", "Resultant", "Dither", "SubpixelDither", "NumberOfExposures", "Repeat"]

logger = logging.getLogger(__name__)


def get_scope(root, execution_plan=None):
    """Find the XML element that holds one copy of the program's plan.

    Args:
        root (xml.etree.ElementTree.Element): RomanProgram root element.
        execution_plan (int, optional): Execution plan number. None selects
            the top-level working copy.

    Returns:
        tuple: (scope, targets), where scope holds the PassPlans, SurveyPlan
        and Activities elements and targets maps target number to name.

    Raises:
        ValueError: If the execution plan does not exist in the file.
    """
    scope = root
    if execution_plan is not None:
        plans = root.find("a:ExecutionPlans", APT_NS)
        matches = [ep for ep in (plans if plans is not None else [])
                   if int(ep.get("Number")) == int(execution_plan)]
        if not matches:
            raise ValueError(f"No execution plan {execution_plan} in this APT file")
        scope = matches[0]
    # Execution plans carry their own Targets; fall back to the top level if not
    targets_elem = scope.find("a:Targets", APT_NS)
    if targets_elem is None:
        targets_elem = root.find("a:Targets", APT_NS)
    targets = {t.findtext("a:Number", namespaces=APT_NS): t.findtext("a:TargetName", namespaces=APT_NS)
               for t in targets_elem}
    return scope, targets


def plan_scopes(apt_path):
    """List the top-level plan and every execution plan, with segment statuses.

    Args:
        apt_path (str or Path): Path to the .apt file.

    Returns:
        list of dict: Top level first, then execution plans in file order.
        Keys: execution_plan (None for the top level, else int), name, and
        segment_status, e.g. "SCHEDULED (34)". Withdrawn segments are counted
        as WITHDRAWN.
    """
    root = ET.parse(apt_path).getroot()
    plans = root.find("a:ExecutionPlans", APT_NS)
    elements = [(None, root)] + [(int(ep.get("Number")), ep) for ep in (plans if plans is not None else [])]

    scopes = []
    for number, elem in elements:
        activities = elem.find("a:Activities", APT_NS)
        segments = [] if activities is None else activities.findall("a:Segment", APT_NS)
        counts = collections.Counter("WITHDRAWN" if s.get("Withdraw") == "true" else s.get("Status")
                                     for s in segments)
        scopes.append({
            "execution_plan": number,
            "name": "Top level (working copy)" if number is None else f"Execution Plan {number}",
            "segment_status": ", ".join(f"{status} ({n})" for status, n in counts.most_common()) or "no segments",
        })
    return scopes


def survey_steps(apt_path, execution_plan=None):
    """Tabulate the survey plan of an APT program, one row per survey step.

    Args:
        apt_path (str or Path): Path to the .apt file.
        execution_plan (int, optional): Execution plan to read. None reads the
            top-level working copy.

    Returns:
        pandas.DataFrame: Columns step (1-based execution order), pass_plan
        (PassPlan Number attribute), repeat, target, label, filters, ma_tables
        ("table (resultants)" combinations), and n_obs.
    """
    scope, targets = get_scope(ET.parse(apt_path).getroot(), execution_plan)
    pass_plans = {pp.get("Number"): pp for pp in scope.find("a:PassPlans", APT_NS)}

    rows = []
    steps = scope.find("a:SurveyPlan", APT_NS).findall("a:SurveyPlanStep", APT_NS)
    for i, step in enumerate(steps, 1):
        pp = pass_plans[step.findtext("a:PassPlan", namespaces=APT_NS)]
        obs = pp.findall("a:Observation", APT_NS)
        # TargetSelection looks like "Fixed: 3"
        selection = pp.findtext("a:TargetSelection", namespaces=APT_NS) or ""
        rows.append({
            "step": i,
            "pass_plan": pp.get("Number"),
            "repeat": step.findtext("a:Repeat", namespaces=APT_NS),
            "target": targets.get(selection.split(":")[-1].strip(), selection),
            "label": pp.findtext("a:Label", namespaces=APT_NS),
            "filters": ",".join(sorted({o.findtext("a:OpticalElement", namespaces=APT_NS) for o in obs})),
            "ma_tables": "; ".join(sorted({f"{o.findtext('a:MultiAccumTable', namespaces=APT_NS)} "
                                           f"({o.findtext('a:Resultant', namespaces=APT_NS)})" for o in obs})),
            "n_obs": len(obs),
        })
    return pd.DataFrame(rows)


def survey_plan_differences(apt_path, execution_plan):
    """Compare an execution plan's survey plan with the top-level working copy.

    Steps are compared in order by target, label, repeat, and every
    observation's filter, MA table, resultants, dithers, exposures, repeat and
    aperture. Pass plan numbers are not compared.

    Args:
        apt_path (str or Path): Path to the .apt file.
        execution_plan (int): Execution plan number.

    Returns:
        list of str: One description per difference, e.g.
        "step 7 (NGC2506_F146)". Empty if the survey plans match.
    """
    root = ET.parse(apt_path).getroot()
    signatures = []
    for number in (None, execution_plan):
        scope, targets = get_scope(root, number)
        pass_plans = {pp.get("Number"): pp for pp in scope.find("a:PassPlans", APT_NS)}
        steps = []
        for step in scope.find("a:SurveyPlan", APT_NS).findall("a:SurveyPlanStep", APT_NS):
            pp = pass_plans[step.findtext("a:PassPlan", namespaces=APT_NS)]
            selection = pp.findtext("a:TargetSelection", namespaces=APT_NS) or ""
            observations = tuple(
                tuple(o.findtext(f"a:{tag}", namespaces=APT_NS) for tag in ["OpticalElement"] + CHECKED_TAGS)
                + (o.findtext(".//a:FiducialPointOverrideAperture", namespaces=APT_NS),)
                for o in pp.findall("a:Observation", APT_NS))
            steps.append((pp.findtext("a:Label", namespaces=APT_NS), targets.get(selection.split(":")[-1].strip()),
                          step.findtext("a:Repeat", namespaces=APT_NS), observations))
        signatures.append(steps)

    top, plan = signatures
    differences = [f"step {i} ({p[0]})" for i, (t, p) in enumerate(zip(top, plan), 1) if t != p]
    if len(top) != len(plan):
        differences.append(f"top level has {len(top)} survey steps, execution plan has {len(plan)}")
    return differences


def find_irregularities(apt_path, include_unused=False, execution_plan=None):
    """Check the pass plans of an APT program for inconsistent observations.

    Args:
        apt_path (str or Path): Path to the .apt file.
        include_unused (bool): Also check pass plans that are not used in the
            survey plan.
        execution_plan (int, optional): Execution plan to check. None checks
            the top-level working copy.

    Returns:
        list of dict: One entry per issue, with keys pass_plan, label, and issue.
        Pass plans that are not in the survey plan get one entry each with the
        issue "not used in survey plan".
    """
    scope, _ = get_scope(ET.parse(apt_path).getroot(), execution_plan)
    pass_plans = {pp.get("Number"): pp for pp in scope.find("a:PassPlans", APT_NS)}
    used = [s.findtext("a:PassPlan", namespaces=APT_NS)
            for s in scope.find("a:SurveyPlan", APT_NS).findall("a:SurveyPlanStep", APT_NS)]

    issues = []
    for number, pp in pass_plans.items():
        if number not in used:
            issues.append({"pass_plan": number, "label": pp.findtext("a:Label", namespaces=APT_NS),
                           "issue": "not used in survey plan"})

    to_check = pass_plans if include_unused else dict.fromkeys(used)
    for number in to_check:
        pp = pass_plans[number]
        label = pp.findtext("a:Label", namespaces=APT_NS) or ""
        obs = pp.findall("a:Observation", APT_NS)
        if not obs:
            continue
        apertures = [o.findtext(".//a:FiducialPointOverrideAperture", namespaces=APT_NS) for o in obs]
        found = []

        # --- Filters ---
        filters = [o.findtext("a:OpticalElement", namespaces=APT_NS) for o in obs]
        main_filter = collections.Counter(filters).most_common(1)[0][0]
        odd = [f"{ap}={f}" for ap, f in zip(apertures, filters) if f != main_filter]
        if odd:
            found.append(f"filter differs from majority {main_filter}: {', '.join(odd)}")
        label_filter = re.search(r"(F\d{3}|PRISM|GRISM)", label)
        if label_filter and label_filter.group(1) != main_filter:
            found.append(f"label says {label_filter.group(1)} but majority filter is {main_filter}")

        # --- Apertures (only for pass plans that step through the 18 detectors) ---
        if all(ap in ALL_SCA_APERTURES for ap in apertures):
            duplicated = sorted(ap for ap, n in collections.Counter(apertures).items() if n > 1)
            missing = sorted(set(ALL_SCA_APERTURES) - set(apertures))
            if duplicated:
                found.append(f"duplicated apertures: {', '.join(duplicated)}")
            if missing and len(apertures) >= len(ALL_SCA_APERTURES):
                found.append(f"missing apertures: {', '.join(missing)}")

        # --- Exposure settings that should be uniform within a pass plan ---
        for tag in CHECKED_TAGS:
            values = [o.findtext(f"a:{tag}", namespaces=APT_NS) for o in obs]
            counts = collections.Counter(values)
            if len(counts) > 1:
                main_value = counts.most_common(1)[0][0]
                odd = [f"{ap}={v}" for ap, v in zip(apertures, values) if v != main_value]
                found.append(f"mixed {tag} (majority {main_value}): {', '.join(odd)}")

        issues.extend({"pass_plan": number, "label": label, "issue": text} for text in found)
    return issues


def opup_execution_plans(opup_paths, program_id):
    """Count a program's visits per execution plan in OPUP tarballs.

    Visit IDs start with the 5-digit program number followed by the 2-digit
    execution plan number, e.g. 0100902... is program 1009, execution plan 2.

    Args:
        opup_paths (list of str or Path): OPUP .tgz files.
        program_id (int or str): APT program ID, e.g. 1009.

    Returns:
        pandas.DataFrame: Columns opup, execution_plan, n_visits; one row per
        OPUP and execution plan that has visits of this program.

    Raises:
        ValueError: If an OPUP tarball has no *_odf.json.
    """
    prefix = f"{int(program_id):05d}"
    rows = []
    for opup_path in map(Path, opup_paths):
        with tarfile.open(opup_path) as opup:
            odf_name = next((n for n in opup.getnames() if n.endswith("_odf.json")), None)
            if odf_name is None:
                raise ValueError(f"{opup_path} does not contain an *_odf.json")
            visits = json.load(opup.extractfile(odf_name))["visits"]
        plans = collections.Counter(int(v["Visit_ID"][5:7]) for v in visits if v["Visit_ID"].startswith(prefix))
        rows.extend({"opup": opup_path.name.removesuffix(".tgz"), "execution_plan": ep, "n_visits": n}
                    for ep, n in sorted(plans.items()))
    return pd.DataFrame(rows, columns=["opup", "execution_plan", "n_visits"])


def main():
    parser = argparse.ArgumentParser(description="List the survey plan of a Roman APT program and flag irregular pass plans.")
    parser.add_argument("apt_file", type=Path, help="APT program file (.apt)")
    parser.add_argument("--all", action="store_true", help="also check pass plans not used in the survey plan")
    parser.add_argument("--opup", nargs="+", type=Path, default=[],
                        help="OPUP .tgz files; report which execution plan of this program they contain")
    parser.add_argument("--csv", type=Path, help="write the survey-step tables of all plans to this CSV file")
    parser.add_argument("--log", type=Path, help="also write the report to this log file")
    args = parser.parse_args()

    # --------- Setup logging to terminal (and optional file) --------
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    if args.log:
        logging.getLogger().addHandler(logging.FileHandler(args.log, mode="w"))

    root = ET.parse(args.apt_file).getroot()
    program = root.findtext("a:ProgramInformation/a:ProgramID", namespaces=APT_NS)
    title = root.findtext("a:ProgramInformation/a:Title", namespaces=APT_NS)
    scopes = plan_scopes(args.apt_file)
    logger.info(f"Program {program}: {title}")
    logger.info(f"{len(scopes) - 1} execution plan(s) in file")

    tables = []
    problem_plans = {}
    for scope in scopes:
        ep = scope["execution_plan"]
        logger.info(f"\n{'=' * 70}\n{scope['name']}  [segments: {scope['segment_status']}]\n{'=' * 70}")

        # ---------- Comparison with the top level ----------
        differences = [] if ep is None else survey_plan_differences(args.apt_file, ep)
        if ep is not None:
            if differences:
                logger.info(f"WARNING: survey plan differs from the top level: {', '.join(differences)}")
            else:
                logger.info("Survey plan identical to the top level.")

        # ---------- Survey plan (top level, and execution plans that differ) ----------
        steps = survey_steps(args.apt_file, ep)
        tables.append(steps.assign(execution_plan="top" if ep is None else ep))
        logger.info(f"{len(steps)} survey steps, {steps['target'].nunique()} targets")
        if ep is None or differences:
            logger.info("\n" + steps.to_string(index=False))

        # ---------- Irregularities ----------
        all_issues = find_irregularities(args.apt_file, include_unused=args.all, execution_plan=ep)
        unused = [i for i in all_issues if i["issue"] == "not used in survey plan"]
        issues = [i for i in all_issues if i["issue"] != "not used in survey plan"]
        if unused:
            unused_list = ", ".join(f"{i['pass_plan']} ({i['label']})" for i in unused)
            logger.info(f"\nPass plans not in survey plan ({len(unused)}): {unused_list}")
        step_of = steps.groupby("pass_plan")["step"].apply(lambda s: ",".join(map(str, s))).to_dict()
        logger.info(f"\nIrregularities in {scope['name']}:")
        for issue in issues:
            where = f"step {step_of[issue['pass_plan']]}, " if issue["pass_plan"] in step_of else ""
            logger.info(f"  Pass plan {issue['pass_plan']} ({where}{issue['label']}): {issue['issue']}")
        if not issues:
            logger.info("  none found")
        if ep is not None and (issues or differences):
            problem_plans[ep] = "has irregularities" if issues else "differs from the top level"

    if args.csv:
        table = pd.concat(tables, ignore_index=True)
        table.insert(0, "execution_plan", table.pop("execution_plan"))
        table.to_csv(args.csv, index=False)
        logger.info(f"\nSurvey steps written to: {args.csv}")

    # ---------- Which execution plan was uplinked ----------
    if args.opup:
        found = opup_execution_plans(args.opup, program)
        logger.info(f"\n{'=' * 70}\nProgram {program} visits in {len(args.opup)} OPUP(s)\n{'=' * 70}")
        if found.empty:
            logger.info("  none found")
        known_plans = {s["execution_plan"] for s in scopes}
        for row in found.itertuples():
            note = ""
            if row.execution_plan not in known_plans:
                note = "  <-- WARNING: this execution plan is not in the APT file"
            elif row.execution_plan in problem_plans:
                note = f"  <-- WARNING: Execution Plan {row.execution_plan} {problem_plans[row.execution_plan]}"
            logger.info(f"  {row.opup}: Execution Plan {row.execution_plan}, {row.n_visits} visits{note}")


if __name__ == "__main__":
    main()
