#!/usr/bin/env python3
"""
Extract visit data from Roman ODF JSON files into a single CSV,
then print/output summary statistics.

To run: 
- Download the OPUP tar ball which is linked from the JIRA issue to outerspace
untar it by double clicking, which puts it in a directory with the name (e.g. 2026338052719_2026140212742_opup). Make sure it's in it's own directory, otherwise it'll grab all the json files in your working directory
- cd into that directory
- run the script pointing to wherever it is, e.g. "python ../../extract_odf_to_csv.py"
It outputs the summary to your terminal and to a file called "*_opup.log". It also makes a skymap "odf_visits_sky_map.png", though if the visits are all near each other, it's not the most illuminating. You can also examine the combined visit file "*_odf.json" to dig into the summary.
"""

import json
import os
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import logging

WORKSPACE = Path.cwd() #(__file__).parent

json_files = sorted(WORKSPACE.glob("*_odf.json"))
# --------- Setup logging to output file and terminal --------
logger = logging.getLogger()
logger.setLevel(logging.INFO)
logfile=WORKSPACE.name+".log"
file_handler = logging.FileHandler(logfile, mode='w')
console_handler = logging.StreamHandler()
logger.addHandler(file_handler)
logger.addHandler(console_handler)

logger.info(f"Found {len(json_files)} ODF JSON files:\n")
for jf in json_files:
    logger.info(f"  {jf.name}")

# ---------- Load all visits into DataFrame ----------
records = []
for jf in json_files:
    with open(jf) as f:
        data = json.load(f)
    for visit in data["visits"]:
        # Normalize start key so input can use Start/start (or other case variants).
        start_value = next((v for k, v in visit.items() if k.lower() == "start"), None)
        if start_value is not None:
            visit.setdefault("start", start_value)
            visit.setdefault("Start", start_value)
        visit["Source_File"] = jf.name
        records.append(visit)

df = pd.DataFrame(records)
logger.info(f"\nTotal visits loaded: {len(df)}")

# ---------- Sort chronologically by Start time ----------
df = df.sort_values("start").reset_index(drop=True)

# ---------- Build filename from time range ----------
first_start = df.iloc[0]["start"]
last_start = df.iloc[-1]["start"]
first_day = first_start.split("-")[0] + "d" + first_start.split("-")[1]
last_day = last_start.split("-")[0] + "d" + last_start.split("-")[1]
csv_name = f"odf_visits_{first_day}_to_{last_day}.csv"

# ---------- Set column order as requested ----------
desired_columns = [
    "Visit_ID",
    "RA",
    "DEC",
    "Start",
    "Duration",
    "Program_Number",
    "Exec_Plan_Number",
    "Pass_Number",
    "Segment_Number",
    "Observation_Number",
    "Visit_Number",
    "WFI_Optical_Element",
    "Science_Instrument",
    "Science_Instrument_Mode",
    "Intended_Purpose",
    "Earliest_Start_Time",
    "Latest_Start_Time",
    "Latest_End_Time",
    "Number_GSACQs",
    "Guide_Window_ID",
    "Science_Data_Volume",
    "Dither",
    "Position_Angle",
    "Off-Normal_Roll",
    "Source_File",
    "Visit_File_Name",
    "Realtime_Visit",
]
# Add any extra columns at the end
extra_cols = [c for c in df.columns if c not in desired_columns]
final_columns = desired_columns + extra_cols
df = df.reindex(columns=final_columns)

csv_path = WORKSPACE / csv_name
df.to_csv(csv_path, index=False)
logger.info(f"\nCSV written to: {csv_path.name}  ({len(df)} rows, {len(df.columns)} columns)")
logger.info(f"Source files: {', '.join(jf.name for jf in json_files)}")

# ================================================================
#  Summary Statistics
# ================================================================
logger.info("\n" + "=" * 70)
logger.info("  SUMMARY STATISTICS")
logger.info("=" * 70)

# --- Visits per source file ---
logger.info("\n--- Visits per source file ---")
for fname, count in df["Source_File"].value_counts().items():
    logger.info(f"  {fname}: {count}")

# --- Duration statistics (in seconds) ---
df["Duration"] = pd.to_numeric(df["Duration"], errors="coerce")
durations = df["Duration"].dropna()
durations_min = durations / 60
logger.info("\n--- Duration (seconds) ---")
logger.info(f"  Min:    {durations.min():.0f} s  ({durations_min.min():.1f} min)")
logger.info(f"  Max:    {durations.max():.0f} s  ({durations_min.max():.1f} min)")
logger.info(f"  Mean:   {durations.mean():.1f} s  ({durations_min.mean():.1f} min)")
logger.info(f"  Median: {durations.median():.0f} s")
logger.info(f"  Total:  {durations.sum():.0f} s  ({durations.sum()/3600:.1f} hr)")

# --- Science Instrument Mode breakdown ---
logger.info("\n--- Science Instrument Mode ---")
mode_counts = df["Science_Instrument_Mode"].fillna("N/A").value_counts()
for mode, count in mode_counts.items():
    pct = 100 * count / len(df)
    logger.info(f"  {mode}: {count}  ({pct:.1f}%)")

# --- WFI Optical Element breakdown ---
logger.info("\n--- WFI Optical Element ---")
elem_counts = df["WFI_Optical_Element"].fillna("N/A").value_counts()
for elem, count in elem_counts.items():
    pct = 100 * count / len(df)
    logger.info(f"  {elem}: {count}  ({pct:.1f}%)")

# --- Program Number breakdown ---
logger.info("\n--- Program Number ---")
prog_counts = df["Program_Number"].fillna("N/A").value_counts()
for prog, count in prog_counts.items():
    pct = 100 * count / len(df)
    logger.info(f"  {prog}: {count}  ({pct:.1f}%)")

# --- Intended Purpose breakdown ---
logger.info("\n--- Intended Purpose ---")
purpose_counts = df["Intended_Purpose"].fillna("N/A").value_counts()
for purpose, count in purpose_counts.items():
    pct = 100 * count / len(df)
    logger.info(f"  {purpose}: {count}  ({pct:.1f}%)")

# --- Science Data Volume ---
df["Science_Data_Volume"] = pd.to_numeric(df["Science_Data_Volume"], errors="coerce")
volumes_gb = df["Science_Data_Volume"].dropna() / 1e9
logger.info("\n--- Science Data Volume (GB) ---")
logger.info(f"  Min:   {volumes_gb.min():.2f} GB")
logger.info(f"  Max:   {volumes_gb.max():.2f} GB")
logger.info(f"  Mean:  {volumes_gb.mean():.2f} GB")
logger.info(f"  Total: {volumes_gb.sum():.2f} GB  ({volumes_gb.sum()/1000:.2f} TB)")

# --- Science Data Volume per day ---
df["Day"] = df["start"].str.extract(r"(\d{4}-\d{3})")
vol_per_day = volumes_gb.groupby(df["Day"]).sum()
logger.info("\n--- Science Data Volume per Day (GB) ---")
for day, gb in vol_per_day.items():
    logger.info(f"  {day}: {gb:.2f} GB")
logger.info(f"  ---")
logger.info(f"  Min:  {vol_per_day.min():.2f} GB/day")
logger.info(f"  Max:  {vol_per_day.max():.2f} GB/day")
logger.info(f"  Mean: {vol_per_day.mean():.2f} GB/day")

# --- RA / DEC range ---
df["RA"] = pd.to_numeric(df["RA"], errors="coerce")
df["DEC"] = pd.to_numeric(df["DEC"], errors="coerce")
ras = df["RA"].dropna()
decs = df["DEC"].dropna()
logger.info("\n--- Pointing (RA / DEC) ---")
logger.info(f"  RA  range: {ras.min():.4f} to {ras.max():.4f} deg")
logger.info(f"  DEC range: {decs.min():.4f} to {decs.max():.4f} deg")

# --- Number of guide star acquisitions ---
df["Number_GSACQs"] = pd.to_numeric(df["Number_GSACQs"], errors="coerce")
gsacqs = df["Number_GSACQs"].dropna()
logger.info("\n--- Guide Star Acquisitions per visit ---")
for n, count in gsacqs.value_counts().sort_index().items():
    logger.info(f"  {int(n)} GSACQ(s): {count} visits")

# --- Realtime visits ---
rt_counts = df["Realtime_Visit"].fillna("N/A").value_counts()
logger.info("\n--- Realtime Visits ---")
for rt, count in rt_counts.items():
    logger.info(f"  {rt}: {count}")

# --- Dither breakdown ---
dither_counts = df["Dither"].fillna("N/A").value_counts()
logger.info("\n--- Dither ---")
for d, count in dither_counts.items():
    logger.info(f"  {d}: {count}")

logger.info("\n" + "=" * 70)

# ================================================================
#  Sky Map Figure
# ================================================================
fig = plt.figure(figsize=(12, 6))
ax = fig.add_subplot(111, projection="aitoff")

# Only plot rows with valid RA/DEC
plot_df = df.dropna(subset=["RA", "DEC"])
ra_rad = np.deg2rad(plot_df["RA"].values)
dec_rad = np.deg2rad(plot_df["DEC"].values)
ra_plot = np.where(ra_rad > np.pi, ra_rad - 2 * np.pi, ra_rad)

# Color by Program_Number
programs = plot_df["Program_Number"].fillna("unknown").unique()
color_cycle = plt.rcParams["axes.prop_cycle"].by_key()["color"]
prog_color_map = {prog: color_cycle[i % len(color_cycle)] for i, prog in enumerate(programs)}

for prog in programs:
    mask = plot_df["Program_Number"].fillna("unknown") == prog
    purpose = plot_df.loc[mask, "Intended_Purpose"].dropna().unique()
    label = f"{prog} — {purpose[0]}" if len(purpose) else prog
    ax.scatter(ra_plot[mask], dec_rad[mask], s=8, alpha=0.6,
               color=prog_color_map[prog], label=label)

ax.set_xlabel("RA")
ax.set_ylabel("Dec")
ax.set_title(f"Roman ODF Visit Pointings ({first_day} to {last_day})", y=1.08)
ax.legend(loc="lower right", fontsize=7, markerscale=2)
ax.grid(True, alpha=0.3)

fig_path = WORKSPACE / "odf_visits_sky_map.png"
fig.savefig(fig_path, dpi=150, bbox_inches="tight")
logger.info(f"\nFigure saved to: {fig_path.name}")
plt.close(fig)

logger.info(f"Output saved to: {logfile}")
logger.info("Done.")
