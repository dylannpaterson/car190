
      program q
      implicit none

      character*300 string,infile,outfile,polyfile
      double precision xr,yr,xc,yc,dx,dy
      double precision a(20),b(20),aa(20),bb(20),cx(20),cy(20)
      integer i,ii
      real m,qfit,c
      
      call getarg(1,infile)
      call getarg(2,polyfile)
      call getarg(3,outfile)

      i=0
      open(10,file=polyfile,status='old')
 11   continue
      read(10,'(300a)',end=12) string
      if (string(1:1).eq.'#') goto 11
      i=i+1
      read(string,*,end=13) ii,a(i),b(i),aa(i),bb(i)
 13   goto 11
 12   close(10)

      cx=a+0.5d0*aa
      cy=b+0.5d0*bb
c      do i=1,20
c         print*, i,a(i),aa(i),cx(i),b(i),bb(i),cy(i)
c      enddo
      

      open(20,file=infile,status='old')
      open(30,file=outfile,status='replace')
      write(30,'(a)') "# xc yc mr qr cr xr yr"
      write(30,'(a)') "#  1  2  3  4  5  6  7"
 21   continue
      read(20,'(300a)',end=22) string
      if (string(1:1).eq.'#') goto 21
      read(string,*,end=23) xr,yr,m,qfit,c

      call cc(20,xr,yr,xc,yc,cx,cy)
      write(30,'(10(f12.5,1x))') xc,yc,m,qfit,c,xr,yr

 23   goto 21
 22   close(30)
      close(20)

      end
      



      subroutine cc(n,xr,yr,xc,yc,cx,cy)
      implicit none

      integer n
      double precision xr,yr,xc,yc,x,y,dx,dy
      double precision cx(n),cy(n)
      double precision xo,yo

      xo=2044.0d0
      yo=2044.0d0
      
      x=(xr-xo)/xo
      y=(yr-yo)/yo

      dx = cx(01)*x+
     .     cx(02)*y+
     .     cx(03)*x*x+
     .     cx(04)*x*y+
     .     cx(05)*y*y+
     .     cx(06)*x*x*x+
     .     cx(07)*x*x*y+
     .     cx(08)*x*y*y+
     .     cx(09)*y*y*y+
     .     cx(10)*x*x*x*x+
     .     cx(11)*x*x*x*y+
     .     cx(12)*x*x*y*y+
     .     cx(13)*x*y*y*y+
     .     cx(14)*y*y*y*y+
     .     cx(15)*x*x*x*x*x+
     .     cx(16)*x*x*x*x*y+
     .     cx(17)*x*x*x*y*y+
     .     cx(18)*x*x*y*y*y+
     .     cx(19)*x*y*y*y*y+
     .     cx(20)*y*y*y*y*y


      dy = cy(01)*x+
     .     cy(02)*y+
     .     cy(03)*x*x+
     .     cy(04)*x*y+
     .     cy(05)*y*y+
     .     cy(06)*x*x*x+
     .     cy(07)*x*x*y+
     .     cy(08)*x*y*y+
     .     cy(09)*y*y*y+
     .     cy(10)*x*x*x*x+
     .     cy(11)*x*x*x*y+
     .     cy(12)*x*x*y*y+
     .     cy(13)*x*y*y*y+
     .     cy(14)*y*y*y*y+
     .     cy(15)*x*x*x*x*x+
     .     cy(16)*x*x*x*x*y+
     .     cy(17)*x*x*x*y*y+
     .     cy(18)*x*x*y*y*y+
     .     cy(19)*x*y*y*y*y+
     .     cy(20)*y*y*y*y*y

      xc=xr+0.5d0*dx
      yc=yr+0.5d0*dy


      
      return
      end
