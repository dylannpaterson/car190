#define _NMATMAX_    20000

      program xym2master
      implicit none
      
      integer i,NMATs,j
      character*300 STRING,IMGNAME,MATFILE,OUTNAME,STRING2,chip
      integer NIMTOT,nargs

      real*8 xin1, yin1
      real*8 xin2, yin2,DELTA
      real*8 AG, BG, CG, DG
      real*8 GA, GB, GC, GD
      real*8 Xo, Yo, Wo, Zo

      real*8 x1c(_NMATMAX_),y1c(_NMATMAX_)
      real*8 x2c(_NMATMAX_),y2c(_NMATMAX_)

      real*8 xc,yc,m,q,xr,yr,xt,yt,cr

      nargs=iargc()
      if (nargs.ne.4) then
         print*, 'I need 3 args, check source'
         stop
      endif
      call getarg(1,IMGNAME)
      call getarg(2,MATFILE)
      call getarg(3,chip)
      call getarg(4,OUTNAME)

      NMATs=0
      open(12,FILE=MATFILE,status='old')
 4    continue
      read(12,'(300a)',end=55) string2
      if (string2(1:1).eq.'#') goto 4
      read(string2,*,end=5) xin1,yin1,xin2,yin2
 5    NMATs=NMATs+1
      x1c(NMATs)=xin1
      y1c(NMATs)=yin1
      x2c(NMATs)=xin2
      y2c(NMATs)=yin2
      goto 4
 55   continue
      close(12)


      call glob_fit6nrDP(x2c,y2c,x1c,y1c,NMATs,
     .           AG,BG,CG,DG,Xo,Yo,Wo,Zo)

      j=0
      open(21,FILE=IMGNAME,status='old')
      open(22,FILE=OUTNAME,status='replace')
 11   continue
      read(21,'(300a)',end=12) STRING2
      if (STRING2(1:1).eq.'#') goto 11
      j=j+1
      read(STRING2,*,end=13) xc,yc,m,q,cr,xr,yr
 13   continue

      xt = (AG*(xc-Xo)+BG*(yc-Yo)+Wo)
      yt = (CG*(xc-Xo)+DG*(yc-Yo)+Zo)

      write(22,100) xt,yt,m,q,cr,xc,yc,xr,yr,trim(chip)
      goto 11
 12   continue

      close(21)
      close(22)




 100  format(9f13.5,1x,a)

      end




c------------------------------------------------------
c             GLOB_FIT6nrDP
c this routine does a least squares solution (with no
c data rejection or weighting) for the 6-param linear
c fit for: 
c   
c    x2 = A*(x1-x1o) + B*(y1-y1o) + x2o  
c    y2 = C*(x1-x1o) + D*(y1-y1o) + y2o  
c
c it may look like there are 8 params, but two of the
c offsets are arbitrary and are just set to the centroid
c of the distribution.
      subroutine glob_fit6nrDP(x1,y1,x2,y2,NUSE,
     .                         A,B,C,D,x1o,y1o,x2o,y2o)
      implicit none
      real*8 x1(1), y1(1)
      real*8 x2(1), y2(1)
      integer NUSE
      real*8 A, B, C, D
      real*8 x1o, y1o, x2o, y2o
      real*8 sxx, sx, swx, szx
      real*8 syy, sy, swy, szy
      real*8 sw,  sz, sxy
      real*8 dlta
      real*8 dsxx, dsyy, dsxy
      real*8 dswx, dswy, dszx, dszy
      integer n
      if (NUSE.le.3) goto 999
      x1o = 0.0d0
      y1o = 0.0d0
      x2o = 0.0d0
      y2o = 0.0d0
      do n = 1, NUSE
         x1o = x1o + x1(n)
         y1o = y1o + y1(n)
         x2o = x2o + x2(n)
         y2o = y2o + y2(n)
      enddo

      x1o = x1o/NUSE
      y1o = y1o/NUSE
      x2o = x2o/NUSE
      y2o = y2o/NUSE

      sxx = 0.0d0
      sx  = 0.0d0
      syy = 0.0d0
      sy  = 0.0d0
      swx = 0.0d0
      swy = 0.0d0
      szx = 0.0d0
      szy = 0.0d0
      sw  = 0.0d0
      sz  = 0.0d0
      sxy = 0.0d0
      do n = 1, NUSE
         sxy = sxy + (x1(n)-x1o)*(y1(n)-y1o)
         sxx = sxx + (x1(n)-x1o)*(x1(n)-x1o)
         sx  = sx  + (x1(n)-x1o)
         syy = syy + (y1(n)-y1o)*(y1(n)-y1o)
         sy  = sy  + (y1(n)-y1o)
         swx = swx + (x2(n)-x2o)*(x1(n)-x1o)
         swy = swy + (x2(n)-x2o)*(y1(n)-y1o)
         sw  = sw  + (x2(n)-x2o)
         szx = szx + (y2(n)-y2o)*(x1(n)-x1o)
         szy = szy + (y2(n)-y2o)*(y1(n)-y1o)
         sz  = sz  + (y2(n)-y2o)
      enddo


      dsxx = sx*sx - NUSE*sxx
      dsyy = sy*sy - NUSE*syy
      dsxy = sx*sy - NUSE*sxy

      dlta = dsxx*dsyy - dsxy*dsxy
      if (dlta.eq.0) goto 999

      dswx = sw*sx - NUSE*swx
      dswy = sw*sy - NUSE*swy
      dszx = sz*sx - NUSE*szx
      dszy = sz*sy - NUSE*szy
      A =   (dswx*dsyy-dswy*dsxy)/dlta
      B =   (dswy*dsxx-dswx*dsxy)/dlta
      C =   (dszx*dsyy-dszy*dsxy)/dlta
      D =   (dszy*dsxx-dszx*dsxy)/dlta

      return
 999  continue
      A  = 1
      B  = 0
      C  = 0
      D  = 1
      x1o = 0  
      y1o = 0
      x2o = 0
      y2o = 0
      return
      end





