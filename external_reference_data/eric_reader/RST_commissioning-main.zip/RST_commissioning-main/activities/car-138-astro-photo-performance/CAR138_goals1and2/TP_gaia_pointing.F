      program tp_gaia_pointing
      implicit none

      real*8 rdither,ddither,rin,din,x,y
      real*8 rd2x,rd2y,pig,scalefactor1,scalefactor2
      character*300 string,outname
      real m

      integer nargs,imgn,counter


      nargs=iargc()

      if (nargs.ne.3) then
         print*, 'arg err'
         stop
      endif

      pig=4.0d0*datan(1.0d0)

      scalefactor1=1.0d0/3600.0d0
      scalefactor2=1.0d0/0.11d0
      
      call getarg(1,string)
      read(string,*) imgn
      call getarg(2,string)
      read(string,*) rdither
      call getarg(3,string)
      read(string,*) ddither

      rdither=rdither*scalefactor1
      ddither=ddither*scalefactor1
      
      write(outname,'("gaia_local_img",i2.2,".cat")') imgn

c      print*, trim(outname)

      counter=0
      open(10,file='../00.MODEL/LMC_GAIA_MODEL.rdgmag',status='old')
      open(11,file=outname,status='replace')
 1    continue
      read(10,'(300a)',end=2) string
      if (string(1:1).eq.'#') goto 1
      counter=counter+1
      read(string,*,end=3) rin,din,m
 3    x=rd2x(rin,din,rdither,ddither,pig)
      y=rd2y(rin,din,rdither,ddither,pig)
      x=-x*3600.0d0*scalefactor2+13315.0d0
      y=y*3600.0d0*scalefactor2+10255.0d0
c      if (x.gt.-5000.0d0.and.x.lt.31650.0d0.and.y.gt.-4000.0d0.and.
c     .     y.lt.21540.0d0)
c     .    write(11,'(3(f13.5,1x),2(f16.11,1x))') x,y,m,rin,din
      if (m.gt.14.0.and.m.lt.17.5)
     .     write(11,'(3(f13.5,1x),2(f16.11,1x))') x,y,m,rin,din
c      write(11,'(3(f13.5,1x),2(f16.11,1x))') x,y,m,rin,din            
      goto 1
 2    close(10)
      

      end
      


!---------------------------------------------------------------------
c This routine will take an (ra,dec) and a tangent-point (ra0,dec0) and
c will compute the x coordinate in the tangent plane.  The units for x
c will be degrees, just like those for RA and DEC.
c
c adapted from Jay's routine
c
      DOUBLE PRECISION function rd2x(r,d,r0,d0,pig)
      implicit none

      DOUBLE PRECISION r, d
      DOUBLE PRECISION r0,d0

      DOUBLE PRECISION cosra, sinra
      DOUBLE PRECISION cosde, sinde
      DOUBLE PRECISION cosd0, sind0
      DOUBLE PRECISION rrrr
      DOUBLE PRECISION xrad
      DOUBLE PRECISION x, y, z
      DOUBLE PRECISION xx,yy,zz

      DOUBLE PRECISION pig

      cosra = cos((r-r0)*pig/180.0d0)
      sinra = dsin((r-r0)*pig/180.0d0)

      cosde = dcos(d *pig/180.0d0)
      sinde = dsin(d *pig/180.0d0)
      cosd0 = dcos(d0*pig/180.0d0)
      sind0 = dsin(d0*pig/180.0d0)
  
      rrrr = sind0*sinde + cosd0*cosde*cosra

      xrad = cosde*sinra/rrrr
      rd2x = xrad*180.0d0/pig
  
      x  = cosde*dcos(r *pig/180.)
      y  = cosde*dsin(r *pig/180.)
      z  = sinde
      xx = cosd0*dcos(r0*pig/180.)
      yy = cosd0*dsin(r0*pig/180.)
      zz = sind0

      if (x*xx + y*yy + z*zz.lt.0.0d0) rd2x = 90.0d0

      return

      end

      
!---------------------------------------------------------------------
c This routine will take an (ra,dec) and a tangent-point (ra0,dec0) and
c will compute the y coordinate in the tangent plane.  The tangent-plane
c y-axis is directed along +DEC.  The units for y will be degrees, just
c lilke those for RA and DEC.
c
c adapted from Jay's routine
c
      DOUBLE PRECISION function rd2y(r,d,r0,d0,pig)
      implicit none

      DOUBLE PRECISION r, d
      DOUBLE PRECISION r0,d0

      DOUBLE PRECISION cosra, sinra
      DOUBLE PRECISION cosde, sinde
      DOUBLE PRECISION cosd0, sind0
      DOUBLE PRECISION rrrr
      DOUBLE PRECISION yrad
      DOUBLE PRECISION x, y, z
      DOUBLE PRECISION xx,yy,zz

      DOUBLE PRECISION pig

      cosra = dcos((r-r0)*pig/180.0d0)
      sinra = dsin((r-r0)*pig/180.0d0)
      cosde = dcos(d *pig/180.0d0)
      sinde = dsin(d *pig/180.0d0)
      cosd0 = dcos(d0*pig/180.0d0)
      sind0 = dsin(d0*pig/180.0d0)

      rrrr = sind0*sinde + cosd0*cosde*cosra

      yrad = (cosd0*sinde-sind0*cosde*cosra)/rrrr
      rd2y = yrad*180.0d0/pig

      x  = cosde*dcos(r *pig/180.)
      y  = cosde*dsin(r *pig/180.)
      z  = sinde
      xx = cosd0*dcos(r0*pig/180.)
      yy = cosd0*dsin(r0*pig/180.)
      zz = sind0

      if (x*xx + y*yy + z*zz.lt.0.0d0) rd2y = 90.0d0

      return
      end

