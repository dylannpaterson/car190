      program q
      implicit none

      integer sca,img
      character*300 master,catalog,string,cmd
      character*10 gmin,gmax,mmin,mmax
      character*300 xmin,xmax,ymin,ymax

      call getarg(1,string)
      read(string,*) sca
      call getarg(2,string)
      read(string,*) img
      call getarg(3,xmin)
      call getarg(4,xmax)
      call getarg(5,ymin)
      call getarg(6,ymax)
      call getarg(7,gmin)
      call getarg(8,gmax)
      call getarg(9,mmin)
      call getarg(10,mmax)
      
      cmd="rm -fr IN.xym2mat"
      call system(cmd)

      cmd='echo "CONF" >> IN.xym2mat'
      call system(cmd)


      
c      write(cmd,'(a,i2.2,a,a,a,a,a,a,a,a,
c     .a,a,a,a,a)')
c     .     'echo 000 "\""master_local_img',img,
c     .     '.cat"\"" c0 f0 "\""x',trim(xmin),
c     .     ',',trim(xmax),'"\"" "\""y',trim(ymin),
c     .     ',',trim(ymax),
c     .     '"\"" "\""m',trim(gmin),',',
c     .     trim(gmax),'"\"" >> IN.xym2mat'
c      call system(cmd)

      write(cmd,'(a,i2.2,a,a,a,a,a,a,a,a,
     .a,a,a,a,a)')
     .     'echo 000 "\""../initial_chipmaster/SCA',sca,
     .     '/MATCHUP.XYMEEE"\"" c0 f0 "\""x',trim(xmin),
     .     ',',trim(xmax),'"\"" "\""y',trim(ymin),
     .     ',',trim(ymax),
     .     '"\"" "\""m',trim(gmin),',',
     .     trim(gmax),'"\"" >> IN.xym2mat'
      call system(cmd)
      
      cmd='echo "QCOL 4" >> IN.xym2mat'
      call system(cmd)
      
         write(cmd,'(a,i2.2,a,i2.2,a,i2.2,a,a,
     .a,a,a,a)')
     .        'echo 0',img,' "\""img',
     .        img,'_sca',sca,
     .        '.iter.xymq"\"" c0 f0 "\""m',trim(mmin),
     .        ',',trim(mmax),'"\""',
     .        ' "\""q0.00001,.1"\"" >> IN.xym2mat'

         
         call system(cmd)
         

      
      write(cmd,'(a,i2.2,a,i2.2,a)') 'cp IN.xym2mat IN.xym2mat_img',
     .     img,'_sca',sca,'.iter'
      call system(cmd)
      



 999  continue
      end
      
