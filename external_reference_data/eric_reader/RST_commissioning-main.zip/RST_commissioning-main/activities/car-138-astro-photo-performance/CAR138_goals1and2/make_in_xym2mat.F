      program q
      implicit none

      character*300 xmin,xmax,ymin,ymax
      integer sca,img
      character*300 master,catalog,string,cmd
      character*10 gmin,gmax,mmin,mmax

      call getarg(1,string)
      read(string,*) sca
      call getarg(2,string)
      read(string,*) img
      call getarg(3,xmin)
      call getarg(4,xmax)
      call getarg(5,ymin)
      call getarg(6,ymax)
      call getarg(7,gmin)
      call getarg(8,gmax)
      call getarg(9,mmin)
      call getarg(10,mmax)
      
      cmd="rm -fr IN.xym2mat"
      call system(cmd)

      cmd='echo "CONF" >> IN.xym2mat'
      call system(cmd)


      
      write(cmd,'(a,i2.2,a,a,a,a,a,a,a,a,
     .a,a,a,a,a)')
     .     'echo 000 "\""../gaia_local_img',img,
     .     '.cat"\"" c0 f0 "\""x',trim(xmin),
     .     ',',trim(xmax),'"\"" "\""y',
     .     trim(ymin),',',trim(ymax),
     .     '"\"" "\""m',trim(gmin),',',
     .     trim(gmax),'"\"" >> IN.xym2mat'
      call system(cmd)
      
      cmd='echo "QCOL 4" >> IN.xym2mat'
      call system(cmd)

      if (img.le.49) then
      
         write(cmd,'(a,i2.2,a,a,i2.2,a,i2.2,a,a,
     .a,a,a,a)')
     .        'echo 0',img,' "\""../../02.SMALL_DITHERS/',
     .        'SMALL_DITHERS_IMG',img,'_L2_SCA',sca,
     .        '.xymqc"\"" c0 f0 "\""m',trim(mmin),
     .        ',',trim(mmax),'"\""',
     .        ' "\""q0.00001,.1"\"" >> IN.xym2mat'

      else

         write(cmd,'(a,i2.2,a,a,i2.2,a,i2.2,a,a,
     .a,a,a,a)')
     .        'echo 0',img,' "\""../../03.LARGE_DITHERS/',
     .        'LARGE_DITHERS_IMG',(img-49),'_L2_SCA',sca,
     .        '.xymqc"\"" c0 f0 "\""m',trim(mmin),
     .        ',',trim(mmax),'"\""',
     .        ' "\""q0.00001,.1"\"" >> IN.xym2mat'
      endif
         
      call system(cmd)
         

      
      write(cmd,'(a,i2.2,a,i2.2)') 'cp IN.xym2mat IN.xym2mat_img',
     .     img,'_sca',sca
      call system(cmd)
      



 999  continue
      end
      
