      program tp_gaia_pointing
      implicit none

      real*8 rdither,ddither,rin,din,x,y,ra,de,x0,y0
      real*8 rd2x,rd2y,pig,scalefactor1,scalefactor2,xy2r,xy2d
      character*300 string0,outname,inname,string
      real m

      integer nargs,imgn,counter


      nargs=iargc()
      
      if (nargs.ne.6) then
         print*, 'arg err:', nargs
         print*, 'inname x0 y0 r0 d0 outname'
         stop
      endif

      pig=4.0d0*datan(1.0d0)

      scalefactor1=1.0d0/3600.0d0
      scalefactor2=0.11d0


      call getarg(1,inname)
      call getarg(2,string)
      read(string,*) x0
      call getarg(3,string)
      read(string,*) y0
      call getarg(4,string)
      read(string,*) rdither
      call getarg(5,string)
      read(string,*) ddither
      call getarg(6,outname)

      rdither=rdither*scalefactor1
      ddither=ddither*scalefactor1
      

      counter=0
      open(10,file=inname,status='old')
      open(11,file=outname,status='replace')
 1    continue
      read(10,'(300a)',end=2) string0
      if (string0(1:1).eq.'#') goto 1
      counter=counter+1 
      read(string0,*,end=3) x,y
      x=-(x-x0)*0.11d0/3600.0d0
      y=(y-y0)*0.11d0/3600.0d0
 3    ra=xy2r(x,y,-rdither,ddither,pig)
      de=xy2d(x,y,-rdither,ddither,pig)
c      if (m.gt.14.0.and.m.lt.17.5)
c     .     write(11,'(2(f16.11,1x),1x,a)')
c     .     sngl(ra),sngl(de),trim(string0)
      write(11,'(2(f16.11,1x),1x,a)')
     .     sngl(ra),sngl(de),trim(string0)

      goto 1
 2    close(10)
      close(11)

      end
      





c-----------------------------------------------
c 
c This routine will take a point (x,y) in the
c tangent plane, and the coordinate of the
c tangent-point (ra0,dec0), and will compute
c the ra coordinate that corresponds to (x,y).
c
      real*8 function xy2r(x,y,r0,d0,pig)
      implicit none

      real*8 x, y
      real*8 r0,d0

      real*8 cosde, sinde
      real*8 cosd0, sind0
      real*8 tandr, dr
      real*8 xrad, yrad

      real*8 pig

      xrad = x/180.0d0*pig
      yrad = y/180.0d0*pig

      cosd0 = dcos(d0*pig/180.0d0)
      sind0 = dsin(d0*pig/180.0d0)

      tandr = xrad/(cosd0-yrad*sind0)
      dr    = datan(tandr)
      xy2r  = r0 + dr*180.0d0/pig

      return
      end



c-----------------------------------------------
c 
c This routine will take a point (x,y) in the
c tangent plane, and the coordinate of the
c tangent-point (ra0,dec0), and will compute
c the ra coordinate that corresponds to (x,y).
c
      real*8 function xy2d(x,y,r0,d0,pig)
      implicit none

      real*8 x, y
      real*8 r0,d0

      real*8 cosd0, sind0
      real*8 tandr, dr
      real*8 cosdr
      real*8 tande
      real*8 xrad, yrad

      real*8 pig


      xrad = x/180.0d0*pig
      yrad = y/180.0d0*pig

      cosd0 = dcos(d0*pig/180.0d0)
      sind0 = dsin(d0*pig/180.0d0)

      tandr = xrad/(cosd0-yrad*sind0)
      dr    = datan(tandr)

      cosdr = dcos(dr)

      tande = cosdr*(sind0+yrad*cosd0)/
     .              (cosd0-yrad*sind0)

      !print*,'---> tande: ',tande 
      xy2d = datan(tande)*180.0d0/pig

      return
      end





      
!---------------------------------------------------------------------
c This routine will take an (ra,dec) and a tangent-point (ra0,dec0) and
c will compute the x coordinate in the tangent plane.  The units for x
c will be degrees, just like those for RA and DEC.
c
c adapted from Jay's routine
c
      DOUBLE PRECISION function rd2x(r,d,r0,d0,pig)
      implicit none

      DOUBLE PRECISION r, d
      DOUBLE PRECISION r0,d0

      DOUBLE PRECISION cosra, sinra
      DOUBLE PRECISION cosde, sinde
      DOUBLE PRECISION cosd0, sind0
      DOUBLE PRECISION rrrr
      DOUBLE PRECISION xrad
      DOUBLE PRECISION x, y, z
      DOUBLE PRECISION xx,yy,zz

      DOUBLE PRECISION pig

      cosra = dcos((r-r0)*pig/180.0d0)
      sinra = dsin((r-r0)*pig/180.0d0)

      cosde = dcos(d *pig/180.0d0)
      sinde = dsin(d *pig/180.0d0)
      cosd0 = dcos(d0*pig/180.0d0)
      sind0 = dsin(d0*pig/180.0d0)
  
      rrrr = sind0*sinde + cosd0*cosde*cosra

      xrad = cosde*sinra/rrrr
      rd2x = xrad*180.0d0/pig
  
      x  = cosde*dcos(r *pig/180.)
      y  = cosde*dsin(r *pig/180.)
      z  = sinde
      xx = cosd0*dcos(r0*pig/180.)
      yy = cosd0*dsin(r0*pig/180.)
      zz = sind0

      if (x*xx + y*yy + z*zz.lt.0.0d0) rd2x = 90.0d0

      return

      end

      
!---------------------------------------------------------------------
c This routine will take an (ra,dec) and a tangent-point (ra0,dec0) and
c will compute the y coordinate in the tangent plane.  The tangent-plane
c y-axis is directed along +DEC.  The units for y will be degrees, just
c lilke those for RA and DEC.
c
c adapted from Jay's routine
c
      DOUBLE PRECISION function rd2y(r,d,r0,d0,pig)
      implicit none

      DOUBLE PRECISION r, d
      DOUBLE PRECISION r0,d0

      DOUBLE PRECISION cosra, sinra
      DOUBLE PRECISION cosde, sinde
      DOUBLE PRECISION cosd0, sind0
      DOUBLE PRECISION rrrr
      DOUBLE PRECISION yrad
      DOUBLE PRECISION x, y, z
      DOUBLE PRECISION xx,yy,zz

      DOUBLE PRECISION pig

      cosra = dcos((r-r0)*pig/180.0d0)
      sinra = dsin((r-r0)*pig/180.0d0)
      cosde = dcos(d *pig/180.0d0)
      sinde = dsin(d *pig/180.0d0)
      cosd0 = dcos(d0*pig/180.0d0)
      sind0 = dsin(d0*pig/180.0d0)

      rrrr = sind0*sinde + cosd0*cosde*cosra

      yrad = (cosd0*sinde-sind0*cosde*cosra)/rrrr
      rd2y = yrad*180.0d0/pig

      x  = cosde*dcos(r *pig/180.)
      y  = cosde*dsin(r *pig/180.)
      z  = sinde
      xx = cosd0*dcos(r0*pig/180.)
      yy = cosd0*dsin(r0*pig/180.)
      zz = sind0

      if (x*xx + y*yy + z*zz.lt.0.0d0) rd2y = 90.0d0

      return
      end





      
