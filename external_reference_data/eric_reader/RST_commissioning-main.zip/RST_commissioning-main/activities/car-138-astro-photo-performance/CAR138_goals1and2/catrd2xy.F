      program catrd2xy
      implicit none

      character*300 string,infile,outfile,string1,string2,string3
      character*300 ll,ll2,string4,string5
      real*8 r0,d0
      real*8 x0,y0
      real*8 x,y,r,d
      real m
      integer p
      real*8 xy2r,xy2d,rd2x,rd2y
      integer iu,iu2,iu3,iu4,iu5,i,block
      real*8 pig


      p=iargc()

      if (p.ne.6) then
         print*, 'argument error!'
         print*, ''
         print*, 'the program catxy2rd requires'
         print*, 'six command-line arguments:'
         print*, ''
         print*, '1) input catalog name (Ra,Dec,strings)'
         print*, '2) x0'
         print*, '3) y0'
         print*, '4) r0'
         print*, '5) d0'
         print*, '6) output catalog name'
         print*, ''
         stop
      endif

      pig=4.0D0*atan(1.0D0)

      call getarg(1,infile)
      call getarg(2,string)
      read(string,*) x0
      call getarg(3,string)
      read(string,*) y0
      call getarg(4,string)
      read(string,*) r0
      call getarg(5,string)
      read(string,*) d0
      call getarg(6,outfile)

      open(10,file=infile,status='old')
      open(11,file=outfile,status='unknown')
 1    continue
      read(10,'(a300)',end=2) string
      if (string(1:1).eq.'#') goto 1
      iu2=len(trim(string))

      iu=0
      block=0
      do i=2,iu2
         if (string(i:i).eq.' '.and.string(i-1:i-1).ne.' ') 
     .        block=block+1
         if (block.eq.2) then
            iu=i
            exit
         endif
      enddo

      read (string,*,end=3) r,d
 3    continue
      string1=string(1:iu-1)
      string2=string(iu:iu2)
      string3=string2(1:iu2-iu+1) // string1(1:iu-1)
      iu3=len(trim(string3))
c      x=-(x-x0)*.11/3600.
c      y=(y-y0)*.11/3600.

c      r=xy2r(x,y,r0,d0)
c     d=xy2d(x,y,r0,d0)

      x=-sngl(rd2x(r,d,r0,d0,pig)*3600/.11)+x0
      y=sngl(rd2y(r,d,r0,d0,pig)*3600/.11)+y0
      

      write(string4,'(f13.5,1x,f13.5,1x)') x,y
      iu4=len(trim(string4))
      string5=string4(1:iu4) // ' ' // string3(1:iu3)
      iu5=len(trim(string5))
      write(11,*) string5(1:iu5)

      goto 1
 2    close(10)
      close(11)


      end










c-----------------------------------------------
c 
c This routine will take a point (x,y) in the
c tangent plane, and the coordinate of the
c tangent-point (ra0,dec0), and will compute
c the ra coordinate that corresponds to (x,y).
c
      real*8 function xy2r(x,y,r0,d0,pig)
      implicit none

      real*8 x, y
      real*8 r0,d0

      real*8 cosde, sinde
      real*8 cosd0, sind0
      real*8 tandr, dr
      real*8 xrad, yrad

      real*8 pig


      xrad = x/180.0d0*pig
      yrad = y/180.0d0*pig

      cosd0 = cos(d0*pig/180.0d0)
      sind0 = sin(d0*pig/180.0d0)

      tandr = xrad/(cosd0-yrad*sind0)
      dr    = atan(tandr)
      xy2r  = r0 + dr*180.0d0/pig

      return
      end



c-----------------------------------------------
c 
c This routine will take a point (x,y) in the
c tangent plane, and the coordinate of the
c tangent-point (ra0,dec0), and will compute
c the ra coordinate that corresponds to (x,y).
c
      real*8 function xy2d(x,y,r0,d0,pig)
      implicit none

      real*8 x, y
      real*8 r0,d0

      real*8 cosd0, sind0
      real*8 tandr, dr
      real*8 cosdr
      real*8 tande
      real*8 xrad, yrad

      real*8 pig


      xrad = x/180.0d0*pig
      yrad = y/180.0d0*pig

      cosd0 = cos(d0*pig/180.0d0)
      sind0 = sin(d0*pig/180.0d0)

      tandr = xrad/(cosd0-yrad*sind0)
      dr    = atan(tandr)

      cosdr = cos(dr)

      tande = cosdr*(sind0+yrad*cosd0)/
     .              (cosd0-yrad*sind0)

      !print*,'---> tande: ',tande 
      xy2d = atan(tande)*180.0d0/pig

      return
      end




!---------------------------------------------------------------------
c This routine will take an (ra,dec) and a tangent-point (ra0,dec0) and
c will compute the x coordinate in the tangent plane.  The units for x
c will be degrees, just like those for RA and DEC.
c
c adapted from Jay's routine
c
      DOUBLE PRECISION function rd2x(r,d,r0,d0,pig)
      implicit none

      DOUBLE PRECISION r, d
      DOUBLE PRECISION r0,d0

      DOUBLE PRECISION cosra, sinra
      DOUBLE PRECISION cosde, sinde
      DOUBLE PRECISION cosd0, sind0
      DOUBLE PRECISION rrrr
      DOUBLE PRECISION xrad
      DOUBLE PRECISION x, y, z
      DOUBLE PRECISION xx,yy,zz

      DOUBLE PRECISION pig

      cosra = cos((r-r0)*pig/180.0d0)
      sinra = dsin((r-r0)*pig/180.0d0)

      cosde = dcos(d *pig/180.0d0)
      sinde = dsin(d *pig/180.0d0)
      cosd0 = dcos(d0*pig/180.0d0)
      sind0 = dsin(d0*pig/180.0d0)
  
      rrrr = sind0*sinde + cosd0*cosde*cosra

      xrad = cosde*sinra/rrrr
      rd2x = xrad*180.0d0/pig
  
      x  = cosde*dcos(r *pig/180.)
      y  = cosde*dsin(r *pig/180.)
      z  = sinde
      xx = cosd0*dcos(r0*pig/180.)
      yy = cosd0*dsin(r0*pig/180.)
      zz = sind0

      if (x*xx + y*yy + z*zz.lt.0.0d0) rd2x = 90.0d0

      return

      end

      
!---------------------------------------------------------------------
c This routine will take an (ra,dec) and a tangent-point (ra0,dec0) and
c will compute the y coordinate in the tangent plane.  The tangent-plane
c y-axis is directed along +DEC.  The units for y will be degrees, just
c lilke those for RA and DEC.
c
c adapted from Jay's routine
c
      DOUBLE PRECISION function rd2y(r,d,r0,d0,pig)
      implicit none

      DOUBLE PRECISION r, d
      DOUBLE PRECISION r0,d0

      DOUBLE PRECISION cosra, sinra
      DOUBLE PRECISION cosde, sinde
      DOUBLE PRECISION cosd0, sind0
      DOUBLE PRECISION rrrr
      DOUBLE PRECISION yrad
      DOUBLE PRECISION x, y, z
      DOUBLE PRECISION xx,yy,zz

      DOUBLE PRECISION pig

      cosra = dcos((r-r0)*pig/180.0d0)
      sinra = dsin((r-r0)*pig/180.0d0)
      cosde = dcos(d *pig/180.0d0)
      sinde = dsin(d *pig/180.0d0)
      cosd0 = dcos(d0*pig/180.0d0)
      sind0 = dsin(d0*pig/180.0d0)

      rrrr = sind0*sinde + cosd0*cosde*cosra

      yrad = (cosd0*sinde-sind0*cosde*cosra)/rrrr
      rd2y = yrad*180.0d0/pig

      x  = cosde*dcos(r *pig/180.)
      y  = cosde*dsin(r *pig/180.)
      z  = sinde
      xx = cosd0*dcos(r0*pig/180.)
      yy = cosd0*dsin(r0*pig/180.)
      zz = sind0

      if (x*xx + y*yy + z*zz.lt.0.0d0) rd2y = 90.0d0

      return
      end

