#define _LINUX_   .true.
#define _PXDIMX_    4088
#define _PXDIMY_    4088
#define _LOFLAG_     -50
#define _HIFLAG_  999999
#define _RADFIT_     2.5
#define _NPSFsX_       5
#define _NPSFsY_       5
#define _NHSHMX_  999999
#define _PSFFAC_     4.0
#define _DOCOEF_ .true.
#define _isky_ 15
#define _osky_ 25
#define _radnorm_ 10

#include "psx_writ.f"
#include "savefits_stdpsf.f"
#include "psx_writ101.f"
#include "writfits_r4_psf.f"
#include "pix2buff_r4.f"
#include "savefits_stdpsf101.f"
#include "model_psf_ML.f"
#include "psx_report2.f"
#include "psx_avrg.f"
#include "psf_prof2.f"
#include "umode_psfdisperse_09x05.f"
#include "rcen_psf.f"
#include "strobe_norm_psf.f"
#include "psf_smoq_iter.f"
#include "sm_plan9e0.f"
#include "sm5plan.f"
#include "sm7plan.f"      
#include "sm3plan.f"
#include "sm3quad.f"     
#include "sm5quad.f"
#include "sm7quad.f"
#include "sm9quad.f"
#include "sm11quad.f"
#include "sm5quar.f"
#include "sm7quar.f"
#include "barsigw.f"
#include "sort_nr.f"
#include "locpsfij.f"      
#include "umode_output.f"
#include "umode_psfsolve.f"
#include "barsig4.f"
#include "find_xyzXX_NAXIS.f"
#include "readfits_r4.f"
#include "buff2pix_r4.f"
#include "readin_input_file.f"
#include "rclip.f"
#include "rpsf_phot.f"      
#include "norm_psf.f"
#include "psf_volu.f"      
#include "psf_rint.f"
#include "mbar_sky_i2e.f"
#include "barsigg2.f"
#include "z_xyopt.f"
#include "inimage.f"






      
      
      
      
! Module with all PSF array sizes
      module array_size
      implicit none
      
      integer :: PSFSIZ, PSFMID, UMODEMAX
      integer :: PSXIMX, PSXIMY, BOXFIT
      integer :: STPSIZ, STPMID
      real    :: MCORE, RCORE, RADFIT, RECENRAD, QWINGS
      logical :: DOSAMP
      
      end module array_size



!adapted from MIRI code, which is itself adapted from MPG/ESO code
      program img2psf_roman_MR
      use array_size
      implicit none

      character*600 STRING,stringtmp
      character*300 INPUT, STRING2, MASTER, PSFFILE, STDPSFFILE
      character*200 STRING3
      character*200, allocatable, dimension(:) :: IMAGE, XYM
      character*200, dimension(3) :: test_array

      integer, allocatable, dimension(:,:) :: auximgi, auximgq
      real*4, allocatable, dimension(:,:) :: auximg, pixs, pixspecial
      real*4, allocatable, dimension(:,:) :: tmp
      real*4, allocatable, dimension(:,:,:) :: imgfits, errfits

      real*8, allocatable, dimension(:) :: xmast, ymast
      real*4, allocatable, dimension(:) :: mmast, SKYBAR, SKYSIG, qmed
      real*8, allocatable, dimension(:) :: xorig, yorig
      real*8, allocatable, dimension(:) :: xcorig, ycorig
      real*4, allocatable, dimension(:) :: morig, zorig, qorig, sorig
      integer, allocatable, dimension(:) :: uorig, nimorig
      real*8, allocatable, dimension(:) :: xl, yl

      integer, allocatable, dimension(:) :: idgood
      integer NGOOD

      real*8 DELTA, bar, sig, xx, yy, nouse, sigx, sigy, dclip
      real*8 xbar, ybar, xr, yr
      real*4 dsig, mbar_sky_i2e, mm, zz, za, zb, ss, qq, bar4, sig4
      real*4 barq, sigq, fnd_hloc_NAXIS, fout, fr, qr, mbar_sky_NAXIS
      real*4 minsky, mr, FEST, FESTR, FMIN, fxout, fyout, sr, rxs, cen
      integer iit, jjt, hobs, HMIN, neq, ITERRAW

      integer stat2
      integer LINEs, NIM, NIMs, stat, NST, NSTs, REFINE, N, NN, Nu
      integer ii, jj, ITER, i, j, k, NOK, ITERSUB, Ndr, NSTi, NUSE
      integer, allocatable, dimension(:) :: id

      logical EXIST, inimage, DOPHOT, SATD, SUBIMG, TESTMODE, DOPSF

      real*4, allocatable, dimension(:,:,:,:) :: psxold, psxadj
      real*4, allocatable, dimension(:,:,:,:) :: psxchg, psxuse
      real*4, allocatable, dimension(:,:,:,:) :: psxuse101
      real*4, allocatable, dimension(:,:) :: psfouter, psfbar, psfloc

      integer, allocatable, dimension(:) :: x0, y0

      integer UMODE, ir, tn, ts, ido, jdo
      real tp, pu, rr, rpsf_phot

      integer u, ipsf, jpsf, Us, Vs, HX, HY, NAVG
      integer XMIN, XMAX, YMIN, YMAX
      real*4 qmedn, rpsf, xpsf, ypsf, ffe, ff, ffu, dbar, dx, dy
      real*4 psfrbar, z10, dxcen, dycen, norm, prem, volu
      real*4 rpsx_phot_miri, rclip, wtot, ww, sky_array, QCUT, NOSUBR
      real*4 psf_prem, psf_norm, psf_volu, MMAX, MMIN, sky_array_r4
      real*4 sky_array_r4_new, histmode_NAXIS, mbar_skyopt_NAXIS, NOSUBQ
      real*4, allocatable, dimension(:) :: psfrprof
      real*8 NOSUBX, NOSUBY, xxo, yyo
      real*4 z_xyopt, chsq

      logical PSFVAR, GOPRINT, SUBSPECIAL, STROBEFLAG, FIRSTIMAGE
      logical SKYSUB, MINIT

      integer ITMAT, ITMATMAX, NCPU, CHANNEL_NUMBER, ITERTOT
      integer LOCAL, NOSUBI, ITERRF

      integer NIT, NSAT, NSATx


      if (iargc().ne.1) then
         print*,''
         print*,' ePSF.e INPUTLIST'
         print*,''
         print*,' The program needs 1 input:'
         print*,''
         print*,'      (1) - Input file'
         print*,''
         print*,' The input file can contain the following elements.'
         print*,' Each line must start with one of the keywords below.'
         print*,''
         print*,'      (NIM) - List with FITS and XYM location'
         print*,'              (Add as many lines as the images to use)'
         print*,''
         print*,'      (ITER) - Iter from which it starts to '
         print*,'               subtract stellar neighbors prior'
         print*,'               to estimating PSF samplings.'
         print*,'               If positive, the program stops'
         print*,'               after 2*ITERSUB iter with the'
         print*,'               subtraction stage starting at'
         print*,'               ITERSUB iter.'
         print*,'               If negative, the program stops'
         print*,'               after ITERSUB iter without the'
         print*,'               subtraction stage.'
         print*,''
         print*,'      (NCPU) - Number of CPUs to use'
         print*,''
         print*,'      (NAME) - Output name'
         print*,'               (To be added to "ePSF_MIRI_*_LIB.fits")'
         print*,''
         print*,'      (PSFSIZE) - Size of the PSF'
         print*,''
         print*,'      (PSFCENT) - Center of the PSF'
         print*,''
         print*,'      (BOXFIT) - Side of the box for the PSF fit'
         print*,'                 (i.e., 5 pixels -- better if even)'
         print*,''
         print*,'      (RADFIT) - Fitting radius (i.e., 2.5 pixels)'
         print*,''
         print*,'      (NUSE) - Number of stars to use to compute'
         print*,'               local transformations (only used if'
         print*,'               LOCAL is True)'
         print*,''
         print*,'      (MMAX) - Max magnitude of stars (it works with'
         print*,'               instrumental magnitudes, so it is the'
         print*,'               the most negative magnitude) for the'
         print*,'               PSF modeling'
         print*,''
         print*,'      (MMIN) - Min magnitude of stars (it works with'
         print*,'               instrumental magnitudes, so it is the'
         print*,'               the least negative magnitude) for the'
         print*,'               PSF modeling'
         print*,''
         print*,'      (QCUT) - Max QFIT of stars for PSF modeling'
         print*,''
         print*,'      (MCORE) - Max magnitude of stars (it works with'
         print*,'                instrumental magnitude, so it is the'
         print*,'                the most negative magnitudes) for the'
         print*,'                modeling of the core'
         print*,''
         print*,'      (RCORE) - Max radius for the modeling of the'
         print*,'                core with stars of MCORE magnitude'
         print*,''
         print*,'      (RECENRAD) - Radius for the ePSF recentering'
         print*,'                   (default 1.5 pixels)'
         print*,''
         print*,'      (DOSAMP) - Do you want to save log files? T/F'
         print*,''
         print*,'      (DOPSF) - Do you want to model the PSF or use'
         print*,'                the PSF already in the folder? T/F'
         print*,''
         print*,'      (DOPHOT) - Do you want to do a final PSF-fit'
         print*,'                 photometry on each input image? T/F'
         print*,''
         print*,'      (FMIN) - Minimum flux of a source to be found'
         print*,'               in the final PSF-fit photometry'
         print*,''
         print*,'      (HMIN) - Minimum distance between a source and'
         print*,'               its neighbors to be considered in the'
         print*,'               final PSF-fit photometry'
         print*,''
         print*,'      (DOSUB) - Do you want to do save final image'
         print*,'                with all sources found subtracted? T/F'
         print*,''
         print*,'      (SKYSUB) - Do you want to subtract the sky from'
         print*,'                 the image first? T/F'
         print*,''
         print*,'      (STROBE) - Do you want to model the subpixel'
         print*,'                 normalization ("strobe")? T/F'
         print*,''
         print*,'      (MINIT) - Do you want to reject stars from the'
         print*,'                aperture-based catalogs in input using'
         print*,'                MMIN/MMAX? T/F'
         print*,''
         print*,'      (TESTMODE) - Override checks on ITER'
         print*,''
         print*,'      (UMODEMAX) - Maximum spatial variability:'
         print*,'                   1 (1 PSF)'
         print*,'                   2 (2x2 PSFs)'
         print*,'                   3 (3x3 PSFs)'
         print*,'                   4 (5x5 PSFs)'
         print*,''
         stop
      endif

      
!---------------------------------------------------------------------
! AA INIT STUFF
!---------------------------------------------------------------------

      PSFSIZ = 301
      PSFMID = 151
      PSXIMX = (PSFSIZ-1)*_NPSFsX_+1
      PSXIMY = (PSFSIZ-1)*_NPSFsY_+1
      STPSIZ = 151
      STPMID = 76
      RADFIT = 2.5
      BOXFIT = 5
      RECENRAD = 1.5

      UMODE = 1

      PSFVAR = .false.
      TESTMODE = .false.
      STROBEFLAG = .true.
      MINIT = .true.

      ITERSUB = 10
      ITERTOT = 2*ITERSUB
      NCPU = 10

      MMAX = -16.
      MMIN = -4.
      QCUT = 0.2
      MCORE  = -99.
      RCORE = 20.0
      
      FMIN = 10
      HMIN =  5

      NOSUBI = 0
      NOSUBX = 0.0d0

      DOPSF = .true.
      DOSAMP = .false.
      DOPHOT = .false.
      SUBIMG = .false.
      SKYSUB = .false.

      UMODEMAX = 1
      FIRSTIMAGE = .true.

      write(PSFFILE,'(''F000_SCA00_LIB.fits'')')
      write(STDPSFFILE,'(''F000_SCA00_STD.fits'')')

!     evenly spaced 5x5
      if (.not.allocated(x0)) allocate(x0(_NPSFsX_),y0(_NPSFsY_))
      x0(1) = 0
      x0(2) = 1022
      x0(3) = 2044
      x0(4) = 3066
      x0(5) = 4089
      y0(1) = 0
      y0(2) = 1022
      y0(3) = 2044
      y0(4) = 3066
      y0(5) = 4089



      
!---------------------------------------------------------------------
! AA READING INPUT FILE
!---------------------------------------------------------------------

      
      call getarg(1,INPUT)

      inquire(FILE=INPUT,exist=EXIST)
      if (EXIST.eqv..false.) then
         print*,''
         write(*,'('' '',a10,'' FILE DOES NOT EXIST. STOP! '')')
     .        INPUT(1:10)
         print*,''
         stop
      endif

!     INPUT FILE
      LINEs = 0
      open(10,FILE=INPUT,status='old')
      do
         read(10,'(a600)',IOSTAT=stat) STRING
         if (IS_IOSTAT_END(stat)) exit
         if (STRING(1:1).ne.'#'.and.STRING(1:3).eq.'NIM') 
     .        LINEs = LINEs + 1
      enddo
      close(10)
      NIMs = LINEs
      if (.not.allocated(IMAGE)) allocate(IMAGE(NIMs))
      if (.not.allocated(XYM)) allocate(XYM(NIMs))

      call readin_input_file(INPUT,NIMs,ITERSUB,ITERTOT,NCPU,
     .     BOXFIT,RADFIT,RECENRAD,PSFMID,
     .     PSFFILE,
     .     MMAX,MMIN,QCUT,MCORE,
     .     DOPSF,DOSAMP,DOPHOT,
     .     FMIN,HMIN,SUBIMG,SKYSUB,UMODEMAX,TESTMODE,STROBEFLAG,
     .     MINIT,FIRSTIMAGE,NSTs,STDPSFFILE,IMAGE,XYM)

      print*,''
      write(*,'(i6.6,'' NSTARS WILL BE USED TO MAKE THE ePSF'',
     .''MODELS...'')') NSTs
      print*,''


      
!---------------------------------------------------------------------
! AA READING IMAGES AND CATALOGS
!---------------------------------------------------------------------

      if (NOSUBI.lt.0.or.NOSUBI.gt.LINEs) then
         print*,''
         print*,'STOP! SUBI NOT IN THE IMAGE LIST...'
         print*,''
         stop
      endif

      if (NOSUBX.ne.0.d0.and.NOSUBY.ne.0.d0.and.NOSUBI.ne.0)
     .     SUBSPECIAL = .true.

      PSXIMX = (PSFSIZ-1)*_NPSFsX_+1
      PSXIMY = (PSFSIZ-1)*_NPSFsY_+1

      if (PSFSIZ.gt.500) then
         STPSIZ = 251
         STPMID = 126
      endif
      
      allocate(psfrprof(PSFSIZ))
      do i = 1, PSFSIZ
         rpsf = i
         psfrprof(i) = 0.15*(1e-2**(rpsf/30))
      enddo

      print*,''
      print*,'OUTPUT PSF: ',PSFFILE(1:75)
      print*,''


      if (.not.allocated(psxuse)) then
         allocate(psxold(PSFSIZ,PSFSIZ,_NPSFsX_,_NPSFsY_))
         allocate(psxadj(PSFSIZ,PSFSIZ,_NPSFsX_,_NPSFsY_))
         allocate(psxchg(PSFSIZ,PSFSIZ,_NPSFsX_,_NPSFsY_))
         allocate(psxuse(PSFSIZ,PSFSIZ,_NPSFsX_,_NPSFsY_))
         allocate(psxuse101(101,101,_NPSFsX_,_NPSFsY_))
         allocate(psfouter(PSFSIZ,PSFSIZ),psfbar(PSFSIZ,PSFSIZ))
         allocate(psfloc(PSFSIZ,PSFSIZ))
      endif

      psxold = 0.0
      psxadj = 0.0
      psxchg = 0.0
      psxuse = 0.0
      psfouter = 0.0
      psfbar = 0.0
      psfloc = 0.0
      
      print*,''
      write(*,'('' READING '',i5.5,'' IMAGES AND XYM FILES... '')') NIMs
      print*,''

      if (.not.allocated(imgfits)) 
     .     allocate(imgfits(_PXDIMX_,_PXDIMY_,NIMs))
      if (.not.allocated(errfits)) 
     .     allocate(errfits(_PXDIMX_,_PXDIMY_,NIMs))      
      if (.not.allocated(xorig)) allocate(xorig(NSTs))
      if (.not.allocated(yorig)) allocate(yorig(NSTs))
      if (.not.allocated(morig)) allocate(morig(NSTs))
      if (.not.allocated(uorig)) allocate(uorig(NSTs))
      if (.not.allocated(sorig)) allocate(sorig(NSTs))
      if (.not.allocated(zorig)) allocate(zorig(NSTs))
      if (.not.allocated(qorig)) allocate(qorig(NSTs))
      if (.not.allocated(SKYBAR)) allocate(SKYBAR(NIMs))
      if (.not.allocated(SKYSIG)) allocate(SKYSIG(NIMs))
      if (.not.allocated(nimorig)) allocate(nimorig(NSTs))
      imgfits = 0.0
      errfits = 0.0
      xorig = 0.d0
      yorig = 0.d0
      morig = 0.d0
      uorig = 1
      sorig = 0.0
      zorig = 0.0
      qorig = 0.5
      SKYBAR = 0.0
      SKYSIG = 0.0
      nimorig = 0
      if (.not.allocated(auximg)) allocate(auximg(_PXDIMX_,_PXDIMY_))
      if (.not.allocated(auximgi)) allocate(auximgi(_PXDIMX_,_PXDIMY_))
      if (.not.allocated(auximgq)) allocate(auximgq(_PXDIMX_,_PXDIMY_))

      
      NST = 0
      do NIM = 1, NIMs

         auximg = 0.0
         call readfits_r4(IMAGE(NIM),auximg,_PXDIMX_,_PXDIMY_)

         skybar=0.
         skysig=0.
         
         print*,NIM,trim(IMAGE(NIM)),SKYBAR(NIM)
         imgfits(:,:,NIM) = auximg(:,:)
         errfits(:,:,NIM) = sqrt(abs(imgfits(:,:,NIM)))
         
         if (DOPSF) then
            open(20, file=XYM(NIM), status='old')
            do
               read(20,'(a300)',IOSTAT=stat2) STRING
               if (IS_IOSTAT_END(stat2)) exit
               if (STRING(1:1).ne.'#') then
                  read(STRING,*) xr, yr, mr
                  if (MINIT) then
                     if (mr.le.MMIN.and.mr.ge.MMAX) then
                        NST = NST + 1
                        ii = nint(xr)
                        jj = nint(yr)
                        xorig(NST) = xr
                        yorig(NST) = yr
                        morig(NST) = mr
                        zorig(NST) = 10**(-0.4*mr)
                        nimorig(NST) = NIM
                        sorig(NST) = mbar_sky_i2e(ii,jj,_isky_,_osky_,
     .                       imgfits(:,:,NIM),_PXDIMX_,_PXDIMY_)
                     endif
                  else
                     NST = NST + 1
                     ii = nint(xr)
                     jj = nint(yr)
                     xorig(NST) = xr
                     yorig(NST) = yr
                     morig(NST) = mr
                     zorig(NST) = 10**(-0.4*mr)
                     nimorig(NST) = NIM
                     sorig(NST) = mbar_sky_i2e(ii,jj,_isky_,_osky_,
     .                    imgfits(:,:,NIM),_PXDIMX_,_PXDIMY_)
                  endif
               endif
            enddo
            close(20)
         endif

      enddo ! NIM
     
      if (allocated(auximg)) deallocate(auximg)
      if (allocated(auximgi)) deallocate(auximgi)
      if (allocated(auximgq)) deallocate(auximgq)

      if (.not.DOPSF) goto 543

      
      print*,''
      print*,''
      print*,'   UMODEMAX = ', UMODEMAX
      print*,'   ITERTOT  = ', ITERTOT
      print*,'   ITERSUB  = ', ITERSUB
      


      
!---------------------------------------------------------------------
! AA ITERATION START
!---------------------------------------------------------------------

!     ITERATION TO MODEL THE ePSF
      do ITER = 1, ITERTOT
 
         print*,''
         print*,''
         write(*,'('' --------------------- '')')
         write(*,'(''| BEGIN ITERATION: '',i2.2,'' |'')') ITER
         write(*,'('' --------------------- '')')
         print*,''

!---------------------------------------------------------------------
! AA REFIT POSITIONS AND FLUXES IF ITER>1
!---------------------------------------------------------------------
! 1 - RE-MEASURE STELLAR POSITIONS AND FLUXES IN EACH IMAGE

         if (ITER.gt.1) then
            print*,''
           write(*,'("1 : RE-MEASURE ",i6," STARS IN EACH IMAGE")') NSTs
           
!$omp parallel NUM_THREADS(NCPU)
!$omp& default(private)
!$omp& shared(NSTs,uorig,xorig,yorig,morig,zorig,sorig,qorig)
!$omp& shared(imgfits,psxuse,x0,y0,SKYBAR,SKYSIG,qmed,NOK)
!$omp& shared(ITER,ITERSUB,MMAX,MMIN,RADFIT)
!$omp& shared(nimorig,errfits)
!$omp do schedule(dynamic)
            do NST = 1, NSTs

               uorig(NST) = 1
               if (NST.eq.NSTs) then
               endif

               if (xorig(NST).lt.1.0d0.or.
     .             yorig(NST).lt.1.0d0.or.
     .             xorig(NST).gt._PXDIMX_-1.0d0.or.
     .             yorig(NST).gt._PXDIMY_-1.0d0) uorig(NST) = 0

               if (uorig(NST).eq.1.and.
     .              imgfits(nint(xorig(NST)),nint(yorig(NST)),
     .                nimorig(NST)).le._LOFLAG_) uorig(NST) = 0

               if (uorig(NST).eq.1) then
                  call locpsfij(
     .                 nint(xorig(NST)),nint(yorig(NST)),
     .                 psfloc,psxuse,x0,y0,PSFSIZ)
                  
                  xx = xorig(NST)
                  yy = yorig(NST)
                  mm = morig(NST)
                  zz = zorig(NST)
                  ss = sorig(NST)
                  qq = qorig(NST)

                     call find_xyzXX_NAXIS(xx,yy,zz,ss,qq,chsq,
     .                 imgfits(:,:,nimorig(NST)),
     .                 psfloc,_PXDIMX_,_PXDIMY_,1,0)

                     zz = z_xyopt(xx,yy,ss,imgfits(:,:,nimorig(NST)),
     .                    psfloc,_PXDIMX_,_PXDIMY_,1)

                  mm = -2.5*log10(max(zz,1.0))
                  xorig(NST) = xx
                  yorig(NST) = yy
                  morig(NST) = mm
                  zorig(NST) = zz
                  qorig(NST) = qq

                  if (mm.gt.-0.001.or.qq.le.0.or.qq.ge.9.99)
     .                 uorig(NST) = 0                 
                  if (xx.le.0.d0.or.yy.le.0.d0) uorig(NST) = 0
                  if (morig(NST).lt.MMAX.or.
     .                morig(NST).gt.MMIN) uorig(NST) = 0
               endif            ! uorig
            enddo               ! NST
!$omp enddo
!$omp end parallel


            
            qmed = pack(qorig,(uorig.eq.1.and.morig.ge.MMAX
     .           .and.morig.le.MMIN))
            NOK = size(qmed)            
            call barsig4(qmed,NOK,bar4,sig4,NN)
            write(*,'(''              QFIT = '',
     .f6.4,'' +/- '',f6.4)') bar4, sig4
            if (allocated(qmed)) deallocate(qmed)

            
            do NST = 1, NSTs
               if (ITER.ge.3.and.qorig(NST).gt.QCUT)
     .              uorig(NST) = 0
            enddo

            write(*,'(''              STARS TO USE: '',i6.6)')
     .           sum(uorig)

         endif ! ITER>1

         
         write(STRING,'(''catalog.'',i2.2)') ITER
         open(50,file=STRING,status='unknown')
         do NST = 1, NSTs
            write(50,*) xorig(NST),yorig(NST),morig(NST),
     .           qorig(NST),uorig(NST),sorig(NST), nimorig(NST)
         enddo
         close(50)

         
         if (ITER.ge.0.and.ITER.le.4) UMODE = 1
         if (ITER.gt.4.and.ITER.le.7) UMODE = 2
         if (ITER.gt.7.and.ITER.lt.10) UMODE = 3         
         if (ITER.ge.10) UMODE = 4
         

         if (UMODE.gt.1) PSFVAR = .true.

         print*,'                   '
         write(*,'("   UMODE         : ",i1)') UMODE
         write(*,*) '  PSFVAR        :',       PSFVAR

         
!---------------------------------------------------------------------
! AA START PSF MODELING
!---------------------------------------------------------------------
!     3 - PSF

         if (ITER.lt.ITERSUB) then
            print*,''
            print*,'   NEIGHBOR SUBTRACTION: OFF'
            print*,''
         else
            print*,''
            print*,'   NEIGHBOR SUBTRACTION: ON'
            print*,''
         endif

         call model_psf_ML(NCPU,imgfits,errfits,
     .        xorig,yorig,morig,qorig,uorig,sorig,zorig,
     .        nimorig,NIMs,NSTs,
     .        UMODE,x0,y0,PSFVAR,psfouter,
     .        psxadj,psxuse,psxchg,psfrprof,SKYBAR,SKYSIG,ITER,ITERSUB,
     .        STROBEFLAG)

!---------------------------------------------------------------------
! AA SAVING PSF ITER & DIAGS
!---------------------------------------------------------------------
         
         write(string,'(a,"_iter",i2.2,".fits")')
     .        PSFFILE(1:len(trim(PSFFILE))-5),ITER         
         call psx_writ(psxuse,string)
         
         write(string,'(a,"_iter",i2.2,".fits")')
     .        STDPSFFILE(1:len(trim(STDPSFFILE))-5),ITER
         call savefits_stdpsf(string,psxuse,x0,y0)
        
         write(STRING,'("DIFF_AVG_PSF_iter",i2.2,".fits")') ITER
         call psx_writ(psxchg,STRING)

         if (PSFSIZ.ne.101) then
            psxuse101 = 0.0
            do HX = 1, _NPSFsX_
               do HY = 1, _NPSFsY_
                  do ipsf = PSFMID-50, PSFMID+50
                     do jpsf = PSFMID-50, PSFMID+50
                        psxuse101(ipsf-(PSFMID-50-1),jpsf-(PSFMID-50-1),
     .                       HX,HY) = psxuse(ipsf,jpsf,HX,HY)
                     enddo
                  enddo
               enddo
            enddo

            write(STRING,'(a,"_iter",i2.2,a)')
     .           PSFFILE(1:len(trim(PSFFILE))-5),ITER,"_101.fits"
            call psx_writ101(psxuse101,STRING)

            write(STRING,'(a,"_iter_",i2.2,a)')
     .           STDPSFFILE(1:len(trim(STDPSFFILE))-5),ITER,
     .           "_101.fits"
            call savefits_stdpsf101(STRING,psxuse101)

            psxuse101 = 0.0
            do HX = 1, _NPSFsX_
               do HY = 1, _NPSFsY_
                  do ipsf = PSFMID-50, PSFMID+50
                     do jpsf = PSFMID-50, PSFMID+50
                        psxuse101(ipsf-(PSFMID-50-1),jpsf-(PSFMID-50-1),
     .                       HX,HY) = psxchg(ipsf,jpsf,HX,HY)
                     enddo
                  enddo
               enddo
            enddo
            write(STRING,'("DIFF_AVG_PSF_iter",i2.2,"_101.fits")') ITER
            call psx_writ101(psxuse101,STRING)
         endif

         print*,''
         write(*,'('' ------------------- '')')
         write(*,'(''| END ITERATION: '',i2.2,'' |'')') ITER
         write(*,'('' ------------------- '')')
         print*,''

      enddo ! ITER

!---------------------------------------------------------------------
! AA ITERATION END
!---------------------------------------------------------------------

      call psx_writ(psxuse,PSFFILE)
      call savefits_stdpsf(STDPSFFILE,psxuse,x0,y0)

! check for weird peaks
      print*,''
      do HX = 1, _NPSFsX_
         do HY = 1, _NPSFsY_
            if (psxuse(PSFMID,PSFMID,HX,HY).ne.
     .           maxval(psxuse(:,:,HX,HY))) then
               write(*,'('' WARNING! ePSF ('',i1,'','',i1,
     .'') DOES NOT PEAK AT ('',i3.3,'','',i3.3,'')'')')
     .              HX, HY, PSFMID, PSFMID
            endif
         enddo
      enddo
      print*,''

     

 543  continue


      if (allocated(IMAGE)) deallocate(IMAGE)
      if (allocated(imgfits)) deallocate(imgfits)
      if (allocated(XYM)) deallocate(XYM)
      if (allocated(xorig)) deallocate(xorig)
      if (allocated(yorig)) deallocate(yorig)
      if (allocated(morig)) deallocate(morig)
      if (allocated(uorig)) deallocate(uorig)
      if (allocated(zorig)) deallocate(zorig)
      if (allocated(sorig)) deallocate(sorig)
      if (allocated(qorig)) deallocate(qorig)
      if (allocated(SKYBAR)) deallocate(SKYBAR)
      if (allocated(SKYSIG)) deallocate(SKYSIG)
      if (allocated(psxuse)) then
         deallocate(psxuse,psxold,psxchg,psxadj,psfouter)
         deallocate(x0,y0,psxuse101)
      endif
      
      return

      end program img2psf_roman_MR


