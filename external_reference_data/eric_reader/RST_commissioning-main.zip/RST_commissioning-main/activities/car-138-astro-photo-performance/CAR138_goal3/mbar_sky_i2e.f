
c---------------------------------------------------
c
c This routine will find a clipped mean sky from an
c annulis about a point.  The point is (ixc,iyc).  It
c will take the pixels between r=inr and r=ior and will
c analyze them for a robust average.
c
      real function mbar_sky_i2e(ixc,iyc,inr,ior,pixarr,PXDIMX,PXDIMY)
      use array_size
      implicit none
 
      integer PXDIMX, PXDIMY
      integer ixc, iyc
      integer inr, ior
      real*4 pixarr(PXDIMX,PXDIMY)
 
      integer i  , j
      integer ixh, iyh
      real    rij
      integer nuse
 
      logical inimage
      !real sklist(99999)
      real*4, allocatable, dimension(:) :: sklist
      integer nsk
      real modelist
      real bar, sig

      if (.not.allocated(sklist)) allocate(sklist(99999))
      sklist = 0.0
  
      nsk = 0
      do i = -ior+1, ior-1
      do j = -ior+1, ior-1
         rij = i**2+j**2
         if (rij.ge.ior**2) goto 333
         if (rij.lt.inr**2) goto 333
         ixh = ixc + i
         iyh = iyc + j
         if (ixh.lt.1.or.ixh.gt.(PXDIMX)) goto 333
         if (iyh.lt.1.or.iyh.gt.(PXDIMY)) goto 333
         if (.not.inimage(ixh,iyh)) goto 333
         if (pixarr(ixh,iyh).le._LOFLAG_) goto 333
         if (pixarr(ixh,iyh).ge._HIFLAG_) goto 333
         nsk = nsk + 1
         if (nsk.gt.99999) goto 333
         sklist(nsk) = pixarr(ixh,iyh)
 333     continue
         enddo
         enddo
 
      call barsigg2(sklist,nsk,bar,sig,nuse)

      if (allocated(sklist)) deallocate(sklist)
 
      mbar_sky_i2e = bar
 
      return
      end
 
