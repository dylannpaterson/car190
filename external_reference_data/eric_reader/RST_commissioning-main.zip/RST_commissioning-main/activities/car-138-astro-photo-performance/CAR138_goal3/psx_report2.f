 
c---------------------------------------------------
c
c
c
      subroutine psx_report2(psx)
      use array_size
      implicit none
 
      real psx(PSFSIZ,PSFSIZ,_NPSFsX_,_NPSFsY_)
      character*300 FILEU
 
      integer ipsf,jpsf
      integer HX, HY
      real    b
      real    psf_rint
      real    r
      real    by
      real    bx(12)
      integer rr
 
      real*4, allocatable, dimension(:,:) :: psfbar
      
      if (.not.allocated(psfbar)) allocate(psfbar(PSFSIZ,PSFSIZ))
      psfbar = 0.0

      call psx_avrg(psx,psfbar)

 
      do rr = 5, 95, 5
         r = rr/10.0
         b = psf_rint(psfbar,r)
        do HY = _NPSFsY_,01,-1
            by = 0.
            do HX = 1, _NPSFsX_
               by = by + psf_rint(psx(1,1,HX,HY),r)
               enddo
 
            by = by/_NPSFsX_
 
            enddo
    1    format(7x,i2,1x,5(3x,f6.3),6x,f6.3)
    3    format(7x,2x,1x,5(3x,f6.3),6x,f6.3)
         do HX = 1, _NPSFsX_
            by = 0.
            do HY = 1, _NPSFsY_
               by = by + psf_rint(psx(1,1,HX,HY),r)
               enddo
            by = by/_NPSFsY_
            bx(HX) = by
            enddo

    2    format('*************************************************')
         enddo
      if (allocated(psfbar)) deallocate(psfbar)

      return
      end
 
 
