
 
c------------------------------
c
c output a PSX to a fits file
c
      subroutine psx_writ(psx,FILEI)
      use array_size
      implicit none
      real psx(PSFSIZ,PSFSIZ,_NPSFsX_,_NPSFsY_)
      character*300 FILEI
      real*4, allocatable, dimension(:,:) :: psfimg
      integer HX, HY
      integer ipsf, jpsf
      character*300 FILE
      integer i, j
 
      if (.not.allocated(psfimg)) allocate(psfimg(PSXIMX,PSXIMY))
      psfimg = 0.0

      FILE = FILEI
 
      do HX = 1, _NPSFsX_
      do HY = 1, _NPSFsY_
         do ipsf = 1, PSFSIZ
         do jpsf = 1, PSFSIZ
            psfimg((HX-1)*(PSFSIZ-1)+ipsf,(HY-1)*(PSFSIZ-1)+jpsf) =
     .      psx(ipsf,jpsf,HX,HY)
            enddo
            enddo
         enddo
         enddo
 
         do i = 1, PSXIMX
            do j = PSFSIZ, PSFSIZ*(_NPSFsX_-1), (PSFSIZ-1)
               psfimg(i,j) = -0.0001
            enddo
         enddo
         do j = 1,PSXIMY
            do i = PSFSIZ, PSFSIZ*(_NPSFsY_-1), (PSFSIZ-1)
               psfimg(i,j) = -0.0001
            enddo
         enddo
      call writfits_r4_psf(FILE,psfimg,PSXIMX,PSXIMY)

      if (allocated(psfimg)) deallocate(psfimg)
 
      return
      end
 
 
