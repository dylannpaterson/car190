
c------------------------------------
c
c this routine determines the entire
c volume of the PSF (including beyond
c the normalization radius)
c
      real function psf_volu(psf)
      use array_size
      implicit none
      real psf(PSFSIZ,PSFSIZ)
 
      real*8  psftot
      integer ipsf,jpsf
 
      psftot = 0.
      do ipsf = 1, PSFSIZ
      do jpsf = 1, PSFSIZ
         psftot = psftot + psf(ipsf,jpsf)
         enddo
         enddo
      psf_volu = psftot/_PSFFAC_/_PSFFAC_
      return
      end
 
