
      subroutine psf_smoq_iter(mi,mo,iter,PSFSIZ,PSFMID)
      implicit none 

      integer(kind=4) iter,PSFSIZ,PSFMID

      real mi(PSFSIZ,PSFSIZ) 
      real mo(PSFSIZ,PSFSIZ) 

      real ms(PSFSIZ,PSFSIZ)

      real m0(PSFSIZ,PSFSIZ) 
      real m1(PSFSIZ,PSFSIZ) 
      real m2(PSFSIZ,PSFSIZ) 
      real m3(PSFSIZ,PSFSIZ) 
      real m4(PSFSIZ,PSFSIZ)


c-----------------------------------------------
c
c allow for 4 different smoothing prescriptions...
c
c-----------------------------------------------

      integer(kind=4) i, j
      real    rij ! distance from center in r-point units

      call sm_plan9e0(mi,m0,PSFSIZ,PSFSIZ)
      ms = mi-m0

      if (iter.le.5) then
         call sm7quad(ms,m1,PSFSIZ,PSFSIZ)
         call sm5quad(ms,m2,PSFSIZ,PSFSIZ)
         call sm5plan(ms,m3,PSFSIZ,PSFSIZ)
         call sm3plan(ms,m4,PSFSIZ,PSFSIZ)
      endif
      if (iter.gt.5.and.iter.le.10)
     .     then
         call sm5quar(ms,m1,PSFSIZ,PSFSIZ)
         call sm7quad(ms,m2,PSFSIZ,PSFSIZ)
         call sm7plan(ms,m3,PSFSIZ,PSFSIZ)
         call sm5plan(ms,m4,PSFSIZ,PSFSIZ)
      endif

       if (iter.gt.10)
     .     then
          call sm5quar(ms,m1,PSFSIZ,PSFSIZ)
          call sm7quad(ms,m2,PSFSIZ,PSFSIZ)
          call sm7plan(ms,m3,PSFSIZ,PSFSIZ)
          call sm5plan(ms,m4,PSFSIZ,PSFSIZ)
       endif

      !plan9
      mo = m0 + m4



      do i = 1, PSFSIZ
         do j = 1, PSFSIZ
            rij = sqrt(1.0*(i-PSFMID)**2+(j-PSFMID)**2)/_PSFFAC_
            if (iter.le.10) then
               if (rij.lt.18.0) mo(i,j)=m0(i,j) + (m3(i,j)+m4(i,j))/2.0
               if (rij.lt.13.0) mo(i,j)=m0(i,j) + m3(i,j)
               if (rij.lt.9.0)  mo(i,j)=m0(i,j) + (m2(i,j)+m3(i,j))/2.0
               if (rij.lt.5.0)  mo(i,j)=m0(i,j) + m2(i,j)
               if (rij.lt.3.5)  mo(i,j)=m0(i,j) + (m1(i,j)+m2(i,j))/2.0
               if (rij.lt.2.5)  mo(i,j)=m0(i,j) + m1(i,j)
            else
               if (rij.lt.30.0) mo(i,j)=m0(i,j) + (m3(i,j)+m4(i,j))/2.0
               if (rij.lt.18.0) mo(i,j)=m0(i,j) + m3(i,j)
               if (rij.lt.9.0)  mo(i,j)=m0(i,j) + (m2(i,j)+m3(i,j))/2.0
               if (rij.lt.5.0)  mo(i,j)=m0(i,j) + m2(i,j)
               if (rij.lt.3.5)  mo(i,j)=m0(i,j) + (m1(i,j)+m2(i,j))/2.0
               if (rij.lt.2.5)  mo(i,j)=m0(i,j) + m1(i,j)
            endif
         enddo
      enddo

      do i = 1, PSFSIZ
         do j = 1, PSFSIZ
            mo(i,j) = max(mo(i,j),0.0)
         enddo
      enddo

      return

      end

