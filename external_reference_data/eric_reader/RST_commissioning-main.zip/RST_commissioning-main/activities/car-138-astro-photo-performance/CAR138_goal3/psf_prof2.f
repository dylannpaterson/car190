
 
c--------------------------------------------------
c
c compute and output the radial profile for the PSF
c
      subroutine psf_prof2(psf,psfrprof,NIT)
      use array_size
      implicit none
      real psf(PSFSIZ,PSFSIZ)
      real psfrprof(PSFSIZ)
      integer NIT
 
      integer ipsf,jpsf
      real    rpsf
      integer ir
      real*8  psum
      integer nsum
      character*300 FILENAME
      real rr
      real ruse(PSFSIZ)
      real psfcum(PSFSIZ)
      real psfrprofh(PSFSIZ)
      logical FIRST
      data FIRST/.true./
 
         FIRST = .false.

 
      do ir = 1, PSFSIZ
         rr = ir-1
         ruse(ir) = rr
         psfrprofh(ir) = psfrprof(ir)
         psum = 0.
         nsum = 0
         psfcum(ir)  = 0
         do ipsf = 1, PSFSIZ
         do jpsf = 1, PSFSIZ
            rpsf = sqrt(((ipsf-PSFMID)**2+(jpsf-PSFMID)**2)/_PSFFAC_
     .           /_PSFFAC_*1.0)!4./4.)
            if (abs(rpsf-ruse(ir)).le.0.5) then
               psum = psum + psf(ipsf,jpsf)
               nsum = nsum + 1
               endif
            if (rpsf.le.ruse(ir)+0.0) then
               psfcum(ir)  = psfcum(ir) + psf(ipsf,jpsf)/_PSFFAC_
     .           /_PSFFAC_!16.0
               endif
            enddo
            enddo
         psfrprof(ir) = psum/nsum
         if (ir.gt.1) then
            if (psfrprof(ir).lt.psfrprof(ir-1)*0.40)
     .           psfrprof(ir) = psfrprof(ir-1)*0.40
         endif
         enddo
  110    format(1x,i3,3x,i3,   3x,f5.1,   3x,f10.7,
     .          5x,f10.7,
     .          5x,f10.7,
     .          5x,f10.5,
     .          5x,f10.5)
  111    format('#','---',3x,'---',3x,'-----',3x,'----------',
     .          5x,'----------',5x,'----------',
     .          5x,'----------',
     .          5x,'----------')
  112    format('#','NIT',3x,' N ',3x,' RAD ',3x,'  PSFBAR  ',
     .          5x,' (PREV)   ',5x,' dPSFBAR  ',
     .          5x,' PSFNRM(%)',
     .          5x,' PSFCUM(%)')
 
      return
      end
 
 
 
