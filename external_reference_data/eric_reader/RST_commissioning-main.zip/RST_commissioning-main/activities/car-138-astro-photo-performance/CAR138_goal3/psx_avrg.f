
 
 
c-----------------------------------
c
c find an average PSF from a PSX
c
      subroutine psx_avrg(psx,psf)
      use array_size
      implicit none
      real psx(PSFSIZ,PSFSIZ,_NPSFsX_,_NPSFsY_)
      real psf(PSFSIZ,PSFSIZ)
 
      integer HX,HY
      integer ii,jj, nsum
      real*8 ssum
 
      do ii = 1, PSFSIZ
      do jj = 1, PSFSIZ
         ssum = 0.
         nsum = 0.
         do HX = 1, _NPSFsX_
            do HY = 1, _NPSFsY_
               ssum = ssum + psx(ii,jj,HX,HY)
               nsum = nsum+1
            enddo
            enddo
         psf(ii,jj) = ssum/nsum
         enddo
         enddo
 
 
      return
      end

