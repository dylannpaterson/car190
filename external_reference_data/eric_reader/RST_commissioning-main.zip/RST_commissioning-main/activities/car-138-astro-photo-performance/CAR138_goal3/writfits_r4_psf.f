      
      subroutine writfits_r4_psf(FILE,pix,PXDIMX,PXDIMY)
      use array_size
      implicit none
 
      character*(*) FILE
      integer PXDIMX,PXDIMY
      real    pix(PXDIMX,PXDIMY)
 
      integer nbyte0
      integer nbyteE
      integer nbyte1
      integer nbyte2
      integer nbper
      integer i,ios
 
      character*2880 buffc
      byte buffb(2880)
      equivalence (buffb,buffc)
 
      integer ifirst, i1, i2
 
      integer np1, np2, npt
 
      character*80 FILEU
      character*70 HDR(25)
      common/HDR/HDR
 
      FILEU = FILE
      do i = 75,2,-1
         if (FILE(i:i+4).eq.'.fits') FILEU = FILE(1:i+4)
         enddo
 
!$omp critical(writfits_r4)
      open(23,file=FILEU,status='unknown',
     .     err=900,recl=2880,form='UNFORMATTED',
     .     access='DIRECT')
 
      i = 1
      write(buffc( 0*80+1: 1*80),'(''SIMPLE  = T      '')')
      write(buffc( 1*80+1: 2*80),'(''BITPIX  = -32    '')')
      write(buffc( 2*80+1: 3*80),'(''NAXIS   ='',i12)') 2
      write(buffc( 3*80+1: 4*80),'(''NAXIS1  ='',i12)') PXDIMX
      write(buffc( 4*80+1: 5*80),'(''NAXIS2  ='',i12)') PXDIMY
      write(buffc( 5*80+1: 6*80),'(''DATATYPE='',9a)')
     .                          ' ''REAL*4'''
      write(buffc( 6*80+1: 7*80),'(''DATE    ='',11a)')
     .                          ' ''28/01/00'''
      write(buffc(07*80+1:08*80),'(''COMMENT  '',a05)') '     '
      write(buffc(08*80+1:09*80),'(''COMMENT  '',a05)') '     '
      write(buffc(09*80+1:10*80),'(''PSFSIZE ='',i12)') PSFSIZ
      write(buffc(10*80+1:11*80),'(''PSFMID  ='',i12)') PSFMID
      write(buffc(11*80+1:12*80),'(''NPSFsX  ='',i12)') _NPSFsX_
      write(buffc(12*80+1:13*80),'(''NPSFsY  ='',i12)') _NPSFsY_
      write(buffc(13*80+1:14*80),'(''COMMENT  '',a05)') '     '
      write(buffc(14*80+1:15*80),'(''COMMENT  '',a05)') '     '
      write(buffc(15*80+1:16*80),'(''END      '')')
 
      write(23,rec=i,iostat=ios) buffc
 
 
      ifirst = i+1
      i1 = i
      i2 = i
 
      nbper  = 4*PXDIMX*PXDIMY
      npt    =   PXDIMX*PXDIMY
      nbyte1 = 1
      nbyte2 = nbper
      i1 = i+1 + nbyte1/2880
      i2 = i+1 + nbyte2/2880
 
      do i = i1, i2, 1
         nbyte0 = (i-ifirst)*2880+   1
         nbyteE = (i-ifirst)*2880+2880
         np1 = (nbyte0-nbyte1)/4 + 1
         np2 = (nbyteE-nbyte1)/4 + 1
         call pix2buff_r4(buffb,pix,np1,npt)
         write(23,rec=i,iostat=ios) buffc
         enddo
 
      goto 901
  900 continue
      print*,'writfits_r4.f ERROR'
      print*,'   FILEU: ',FILEU
      stop
  901 continue
      close(23)
!$omp end critical(writfits_r4)
      return
 
 
      end
 
