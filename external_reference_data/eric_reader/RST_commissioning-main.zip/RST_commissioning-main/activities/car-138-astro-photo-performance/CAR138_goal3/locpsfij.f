
c-----------------------------------------------------------
c
c
c
      subroutine locpsfij(ix,iy,psfloc,psx,x0,y0,PSFSIZ)
      implicit none

      integer PSFSIZ
      real    dx, dy
      integer(kind=4) ix, iy, ipsf, jpsf
      real    psfloc(PSFSIZ,PSFSIZ)
 
      real    psx(PSFSIZ,PSFSIZ,_NPSFsX_,_NPSFsY_)
 
      integer(kind=4) x0(_NPSFsX_)
      integer(kind=4) y0(_NPSFsY_)
 
      real r
 
      integer(kind=4) iclip
      real    fhx,fhy
      integer(kind=4) HX, HY
  
 
      if (ix.le.x0(1)) ix = x0(1)
      if (iy.le.y0(1)) iy = y0(1)
      if (ix.ge.x0(_NPSFsX_)) ix = x0(_NPSFsX_)
      if (iy.ge.y0(_NPSFsY_)) iy = y0(_NPSFsY_)
 
      HX = 0
  1   continue
      HX = HX + 1
      if (ix.gt.x0(HX+1).and.HX.lt._NPSFsX_-1) goto 1
 
      HY = 0
  2   continue
      HY = HY + 1
      if (iy.gt.y0(HY+1).and.HY.lt._NPSFsY_-1) goto 2

      fhx = (ix-x0(HX))*1.0/(x0(HX+1)-x0(HX))
      fhy = (iy-y0(HY))*1.0/(y0(HY+1)-y0(HY))
 
      do ipsf = 001, PSFSIZ
         do jpsf = 001, PSFSIZ
            psfloc(ipsf,jpsf)
     .           = (1-fhx)*(1-fhy)*psx(ipsf,jpsf,HX  ,HY  )
     .           + (1-fhx)*( fhy )*psx(ipsf,jpsf,HX  ,HY+1)
     .           + ( fhx )*(1-fhy)*psx(ipsf,jpsf,HX+1,HY  )
     .           + ( fhx )*( fhy )*psx(ipsf,jpsf,HX+1,HY+1)
            if (psfloc(ipsf,jpsf).lt.0.00) psfloc(ipsf,jpsf) = 0.00
         enddo
      enddo
   
      return
      
      end

                     
