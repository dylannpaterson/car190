 
      logical function inimage(i,j)
      use array_size
      implicit none
 
      integer i, j
 
      inimage = .true.
 
      if (i.lt.       1) inimage = .false.
      if (i.gt._PXDIMX_) inimage = .false.
      if (j.lt.       1) inimage = .false.
      if (j.gt._PXDIMY_) inimage = .false.
 
      return
      end

 
