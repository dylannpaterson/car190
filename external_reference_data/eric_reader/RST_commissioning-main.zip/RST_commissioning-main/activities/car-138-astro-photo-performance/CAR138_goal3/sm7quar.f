
c------------------------------------
c
c
      subroutine sm7quar(r,s,NX,NY)
      use array_size
      implicit none
 
      integer NX, NY
      real r(NX,NY)
      real s(NX,NY)
 
      integer i, j
      integer iu, ju
      integer im, jm
 
      real dx, dy
      real A
 
      real AA( 7, 7)
      data AA / !     1.0
     .  2.0808,-1.7576,-0.2424, 0.8990,-0.2424,-1.7576, 2.0808,
     . -1.7576,-2.8182, 0.3636, 2.0606, 0.3636,-2.8182,-1.7576,
     . -0.2424, 0.3636, 4.5455, 6.5758, 4.5455, 0.3636,-0.2424,
     .  0.8990, 2.0606, 6.5758, 8.7172, 6.5758, 2.0606, 0.8990,
     . -0.2424, 0.3636, 4.5455, 6.5758, 4.5455, 0.3636,-0.2424,
     . -1.7576,-2.8182, 0.3636, 2.0606, 0.3636,-2.8182,-1.7576,
     .  2.0808,-1.7576,-0.2424, 0.8990,-0.2424,-1.7576, 2.0808/
 
      do i = 1, NX
      do j = 1, NY
         A = 0
         if (i.ge.4.and.i.le.NX-3.and.j.ge.4.and.j.le.NX-3) then
            do im = 1, 7
            do jm = 1, 7
               A = A + AA(im,jm)*r(i-4+im,j-4+jm)/49
               enddo
               enddo
            endif
         s(i,j) = A
         enddo
         enddo
 
      return
      end
 
  
