
c-----------------------------------------------
c
c
c
      subroutine sm_plan9e0(r,s,NX,NY)
      use array_size
      implicit none

      integer NX, NY
      real r(NX,NY)
      real s(NX,NY)

      integer i, j
      integer iu, ju
      integer im, jm

      real dx, dy
      real A, B, C

      do i = 1, NX
      do j = 1, NY
         A = 0.
         B = 0.
         C = 0.
         do im = 1, 9
         do jm = 1, 9
            iu = i+(im-5)
            ju = j+(jm-5)
            if (iu.ge.1.and.iu.le.NX.and.
     .          ju.ge.1.and.ju.le.NY) then
                   A = A + 1.0000*r(iu-5+im,ju-5+jm)/081
                   endif
            enddo 
            enddo 
         s(i,j) = A
         enddo 
         enddo 

      return
      end

