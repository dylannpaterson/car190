
c------------------------------------------------------
c
c this routine will determine which PSFs get solved for
c
c
      subroutine umode_psfsolve(UMODE,uhxhy,
     .                          xminhxhy,xmaxhxhy,
     .                          yminhxhy,ymaxhxhy,x0,y0)
      implicit none
 
      integer(kind=4) UMODE
      integer(kind=4)    uhxhy(_NPSFsX_,_NPSFsY_)
      integer(kind=4) xminhxhy(_NPSFsX_,_NPSFsY_)
      integer(kind=4) xmaxhxhy(_NPSFsX_,_NPSFsY_)
      integer(kind=4) yminhxhy(_NPSFsX_,_NPSFsY_)
      integer(kind=4) ymaxhxhy(_NPSFsX_,_NPSFsY_)
 
      integer(kind=4) x0(_NPSFsX_)
      integer(kind=4) y0(_NPSFsY_)
 
      integer(kind=4) HX, HY
 
       
c----------------------------------
c
c set everything to zero, so that we
c can turn on below what is useful
c
      uhxhy  = 0
      xminhxhy = 0
      xmaxhxhy = 0
      yminhxhy = 0
      ymaxhxhy = 0


c----------------------------------
c
c UMODE = 0 or 1
c
c one single PSF from the central meta
c region
c
      if (UMODE.eq.0.or.UMODE.eq.1) then  
         uhxhy(1,1) = 1
         xminhxhy(1,1) = x0(1)
         xmaxhxhy(1,1) = x0(_NPSFsX_)
         yminhxhy(1,1) = y0(1)
         ymaxhxhy(1,1) = y0(_NPSFsY_)
         goto 1
         endif




c----------------------------------
c
c UMODE = 2
c
c four PSFs 
c
      if (UMODE.eq.2) then  
            HX = 3
            HY = 3
            uhxhy(HX-2,HY-2) = 1           ! lower left
            xminhxhy(HX-2,HY-2) = x0(HX-2)
            xmaxhxhy(HX-2,HY-2) = x0(HX  )
            yminhxhy(HX-2,HY-2) = y0(HY-2)
            ymaxhxhy(HX-2,HY-2) = y0(HY  )
            uhxhy(HX+2,HY-2) = 1           ! lower right
            xminhxhy(HX+2,HY-2) = x0(HX  )
            xmaxhxhy(HX+2,HY-2) = x0(HX+2)
            yminhxhy(HX+2,HY-2) = y0(HY-2)
            ymaxhxhy(HX+2,HY-2) = y0(HY  )
            uhxhy(HX-2,HY+2) = 1           ! upper left
            xminhxhy(HX-2,HY+2) = x0(HX-2)
            xmaxhxhy(HX-2,HY+2) = x0(HX  )
            yminhxhy(HX-2,HY+2) = y0(HY  )
            ymaxhxhy(HX-2,HY+2) = y0(HY+2)
            uhxhy(HX+2,HY+2) = 1           ! upper right
            xminhxhy(HX+2,HY+2) = x0(HX  )
            xmaxhxhy(HX+2,HY+2) = x0(HX+2)
            yminhxhy(HX+2,HY+2) = y0(HY  )
            ymaxhxhy(HX+2,HY+2) = y0(HY+2)
            goto 1
      endif






c----------------------------------
c
c UMODE = 3
c
c nine PSFs 
c
      if (UMODE.eq.3) then  
            HX = 3
            HY = 3
            uhxhy(HX-2,HY-2) = 1           ! lower left
            xminhxhy(HX-2,HY-2) = x0(HX-2)
            xmaxhxhy(HX-2,HY-2) = x0(HX-2)+
     .           int( (x0(5)-x0(1))/3+.5)-1
            yminhxhy(HX-2,HY-2) = y0(HY-2)
            ymaxhxhy(HX-2,HY-2) = y0(HY-2)+
     .           int( (y0(5)-y0(1))/3+.5)

            uhxhy(HX  ,HY-2) = 1           ! lower center
            xminhxhy(HX  ,HY-2) = x0(HX-2)+
     .           int( (x0(5)-x0(1))/3+.5)
            xmaxhxhy(HX  ,HY-2) = x0(HX+2)-
     .           int( (x0(5)-x0(1))/3+.5)
            yminhxhy(HX  ,HY-2) = y0(HY-2)
            ymaxhxhy(HX  ,HY-2) = y0(HY-2)+
     .           int( (y0(5)-y0(1))/3+.5)           


            uhxhy(HX+2,HY-2) = 1           ! lower right
            xminhxhy(HX+2,HY-2) = x0(HX+2)-
     .           int( (x0(5)-x0(1))/3+.5)+1
            xmaxhxhy(HX+2,HY-2) = x0(HX+2)
            yminhxhy(HX+2,HY-2) = y0(HY-2)
            ymaxhxhy(HX+2,HY-2) = y0(HY-2)+
     .           int( (y0(5)-y0(1))/3+.5)-1


            uhxhy(HX-2,HY ) = 1           ! middle left
            xminhxhy(HX-2,HY  ) = x0(HX-2)
            xmaxhxhy(HX-2,HY  ) = x0(HX-2)+
     .           int( (x0(5)-x0(1))/3+.5)-1
            yminhxhy(HX-2,HY  ) = y0(HY-2)+
     .           int( (y0(5)-y0(1))/3+.5)

            ymaxhxhy(HX-2,HY  ) = y0(HY+2)-
     .           int( (y0(5)-y0(1))/3+.5)


            uhxhy(HX  ,HY ) = 1           ! middle center
            xminhxhy(HX  ,HY  ) = x0(HX-2)+
     .           int( (x0(5)-x0(1))/3+.5)
            xmaxhxhy(HX  ,HY  ) = x0(HX+2)-
     .           int( (x0(5)-x0(1))/3+.5)

            yminhxhy(HX  ,HY  ) = y0(HY-2)+
     .           int( (y0(5)-y0(1))/3+.5)

            ymaxhxhy(HX  ,HY  ) = y0(HY+2)-
     .           int( (y0(5)-y0(1))/3+.5)



            uhxhy(HX+2,HY ) = 1           ! middle right
            xminhxhy(HX+2,HY  ) = x0(HX+2)-
     .           int( (x0(5)-x0(1))/3+.5)+1
            xmaxhxhy(HX+2,HY  ) = x0(HX+2)
            yminhxhy(HX+2,HY  ) = y0(HY-2)+
     .           int( (y0(5)-y0(1))/3+.5)
            ymaxhxhy(HX+2,HY  ) = y0(HY+2)-
     .           int( (y0(5)-y0(1))/3+.5)

            uhxhy(HX-2,HY+2) = 1           ! upper left
            xminhxhy(HX-2,HY+2) = x0(HX-2)
            xmaxhxhy(HX-2,HY+2) = x0(HX-2)+
     .           int( (x0(5)-x0(1))/3+.5)-1
            yminhxhy(HX-2,HY+2) = y0(HY+2)-
     .           int( (y0(5)-y0(1))/3+.5)+1
            ymaxhxhy(HX-2,HY+2) = y0(HY+2)

            uhxhy(HX  ,HY+2) = 1           ! upper center
            xminhxhy(HX  ,HY+2) = x0(HX-2)+
     .           int( (x0(5)-x0(1))/3+.5)
            xmaxhxhy(HX  ,HY+2) = x0(HX+2)-
     .           int( (x0(5)-x0(1))/3+.5)
            yminhxhy(HX  ,HY+2) = y0(HY+2)-
     .           int( (y0(5)-y0(1))/3+.5)+1
            ymaxhxhy(HX  ,HY+2) = y0(HY+2)

            uhxhy(HX+2,HY+2) = 1           ! upper right
            xminhxhy(HX+2,HY+2) = x0(HX+2)-
     .           int( (x0(5)-x0(1))/3+.5)+1
            xmaxhxhy(HX+2,HY+2) = x0(HX+2)
            yminhxhy(HX+2,HY+2) = y0(HY+2)-
     .           int( (y0(5)-y0(1))/3+.5)+1
            ymaxhxhy(HX+2,HY+2) = y0(HY+2)
            goto 1
      endif







c----------------------------------
c
c UMODE = 4
c
c 25 PSFs 
c
      if (UMODE.eq.4) then  
            HX = 3
            HY = 3
               uhxhy(HX-2,HY-2) = 1           ! lower left (1-1)
            xminhxhy(HX-2,HY-2) = x0(HX-2)
            xmaxhxhy(HX-2,HY-2) = x0(HX-2)+int( (x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX-2,HY-2) = y0(HY-2)
            ymaxhxhy(HX-2,HY-2) = y0(HY-2)+int( (y0(5)-y0(1))/5+.5)-1

               uhxhy(HX-1,HY-2) = 1           ! lower (2-1)
            xminhxhy(HX-1,HY-2) = x0(HX-2)+int( (x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX-1,HY-2) = x0(HX-2)+int( 2*(x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX-1,HY-2) = y0(HY-2)
            ymaxhxhy(HX-1,HY-2) = y0(HY-2)+int( (y0(5)-y0(1))/5+.5)-1

               uhxhy(HX  ,HY-2) = 1           ! lower (3-1)
            xminhxhy(HX  ,HY-2) = x0(HX-2)+int( 2*(x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX  ,HY-2) = x0(HX-2)+int( 3*(x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX  ,HY-2) = y0(HY-2)
            ymaxhxhy(HX  ,HY-2) = y0(HY-2)+int( (y0(5)-y0(1))/5+.5)-1

               uhxhy(HX+1,HY-2) = 1           ! lower (4-1)
            xminhxhy(HX+1,HY-2) = x0(HX-2)+int( 3*(x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX+1,HY-2) = x0(HX-2)+int( 4*(x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX+1,HY-2) = y0(HY-2)
            ymaxhxhy(HX+1,HY-2) = y0(HY-2)+int( (y0(5)-y0(1))/5+.5)-1

               uhxhy(HX+2,HY-2) = 1           ! lower (5-1)
            xminhxhy(HX+2,HY-2) = x0(HX-2)+int( 4*(x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX+2,HY-2) = x0(HX+2)
            yminhxhy(HX+2,HY-2) = y0(HY-2)
            ymaxhxhy(HX+2,HY-2) = y0(HY-2)+int( (y0(5)-y0(1))/5+.5)-1


               uhxhy(HX-2,HY-1) = 1           !  (1-2)
            xminhxhy(HX-2,HY-1) = x0(HX-2)
            xmaxhxhy(HX-2,HY-1) = x0(HX-2)+int( (x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX-2,HY-1) = y0(HY-2)+int( (y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX-2,HY-1) = y0(HY-2)+int( 2*(y0(5)-y0(1))/5+.5)-1

               uhxhy(HX-1,HY-1) = 1           !  (2-2)
            xminhxhy(HX-1,HY-1) = x0(HX-2)+int( (x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX-1,HY-1) = x0(HX-2)+int( 2*(x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX-1,HY-1) = y0(HY-2)+int( (y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX-1,HY-1) = y0(HY-2)+int( 2*(y0(5)-y0(1))/5+.5)-1

               uhxhy(HX  ,HY-1) = 1           !  (3-2)
            xminhxhy(HX  ,HY-1) = x0(HX-2)+int( 2*(x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX  ,HY-1) = x0(HX-2)+int( 3*(x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX  ,HY-1) = y0(HY-2)+int( (y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX  ,HY-1) = y0(HY-2)+int( 2*(y0(5)-y0(1))/5+.5)-1

               uhxhy(HX+1,HY-1) = 1           ! (4-2)
            xminhxhy(HX+1,HY-1) = x0(HX-2)+int( 3*(x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX+1,HY-1) = x0(HX-2)+int( 4*(x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX+1,HY-1) = y0(HY-2)+int( (y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX+1,HY-1) = y0(HY-2)+int( 2*(y0(5)-y0(1))/5+.5)-1

               uhxhy(HX+2,HY-1) = 1           !  (5-2)
            xminhxhy(HX+2,HY-1) = x0(HX-2)+int( 4*(x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX+2,HY-1) = x0(HX+2)
            yminhxhy(HX+2,HY-1) = y0(HY-2)+int( (y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX+2,HY-1) = y0(HY-2)+int( 2*(y0(5)-y0(1))/5+.5)-1



               uhxhy(HX-2,HY  ) = 1           !  (1-3)
            xminhxhy(HX-2,HY  ) = x0(HX-2)
            xmaxhxhy(HX-2,HY  ) = x0(HX-2)+int( (x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX-2,HY  ) = y0(HY-2)+int( 2*(y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX-2,HY  ) = y0(HY-2)+int( 3*(y0(5)-y0(1))/5+.5)-1

               uhxhy(HX-1,HY  ) = 1           !  (2-3)
            xminhxhy(HX-1,HY  ) = x0(HX-2)+int( (x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX-1,HY  ) = x0(HX-2)+int( 2*(x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX-1,HY  ) = y0(HY-2)+int( 2*(y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX-1,HY  ) = y0(HY-2)+int( 3*(y0(5)-y0(1))/5+.5)-1

               uhxhy(HX  ,HY  ) = 1           !  (3-3)
            xminhxhy(HX  ,HY  ) = x0(HX-2)+int( 2*(x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX  ,HY  ) = x0(HX-2)+int( 3*(x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX  ,HY  ) = y0(HY-2)+int( 2*(y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX  ,HY  ) = y0(HY-2)+int( 3*(y0(5)-y0(1))/5+.5)-1

               uhxhy(HX+1,HY  ) = 1           ! (4-3)
            xminhxhy(HX+1,HY  ) = x0(HX-2)+int( 3*(x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX+1,HY  ) = x0(HX-2)+int( 4*(x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX+1,HY  ) = y0(HY-2)+int( 2*(y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX+1,HY  ) = y0(HY-2)+int( 3*(y0(5)-y0(1))/5+.5)-1

               uhxhy(HX+2,HY  ) = 1           !  (5-3)
            xminhxhy(HX+2,HY  ) = x0(HX-2)+int( 4*(x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX+2,HY  ) = x0(HX+2)
            yminhxhy(HX+2,HY  ) = y0(HY-2)+int( 2*(y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX+2,HY  ) = y0(HY-2)+int( 3*(y0(5)-y0(1))/5+.5)-1



               uhxhy(HX-2,HY+1) = 1           !  (1-4)
            xminhxhy(HX-2,HY+1) = x0(HX-2)
            xmaxhxhy(HX-2,HY+1) = x0(HX-2)+int( (x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX-2,HY+1) = y0(HY-2)+int( 3*(y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX-2,HY+1) = y0(HY-2)+int( 4*(y0(5)-y0(1))/5+.5)-1

               uhxhy(HX-1,HY+1) = 1           !  (2-4)
            xminhxhy(HX-1,HY+1) = x0(HX-2)+int( (x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX-1,HY+1) = x0(HX-2)+int( 2*(x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX-1,HY+1) = y0(HY-2)+int( 3*(y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX-1,HY+1) = y0(HY-2)+int( 4*(y0(5)-y0(1))/5+.5)-1

               uhxhy(HX  ,HY+1) = 1           !  (3-4)
            xminhxhy(HX  ,HY+1) = x0(HX-2)+int( 2*(x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX  ,HY+1) = x0(HX-2)+int( 3*(x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX  ,HY+1) = y0(HY-2)+int( 3*(y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX  ,HY+1) = y0(HY-2)+int( 4*(y0(5)-y0(1))/5+.5)-1

                uhxhy(HX+1,HY+1) = 1           ! (4-4)
            xminhxhy(HX+1,HY+1) = x0(HX-2)+int( 3*(x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX+1,HY+1) = x0(HX-2)+int( 4*(x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX+1,HY+1) = y0(HY-2)+int( 3*(y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX+1,HY+1) = y0(HY-2)+int( 4*(y0(5)-y0(1))/5+.5)-1

               uhxhy(HX+2,HY+1) = 1           !  (5-4)
            xminhxhy(HX+2,HY+1) = x0(HX-2)+int( 4*(x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX+2,HY+1) = x0(HX+2)
            yminhxhy(HX+2,HY+1) = y0(HY-2)+int( 3*(y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX+2,HY+1) = y0(HY-2)+int( 4*(y0(5)-y0(1))/5+.5)-1



               uhxhy(HX-2,HY+2) = 1           !  (1-5)
            xminhxhy(HX-2,HY+2) = x0(HX-2)
            xmaxhxhy(HX-2,HY+2) = x0(HX-2)+int( (x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX-2,HY+2) = y0(HY-2)+int( 4*(y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX-2,HY+2) = y0(HY+2)


               uhxhy(HX-1,HY+2) = 1           !  (2-5)
            xminhxhy(HX-1,HY+2) = x0(HX-2)+int( (x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX-1,HY+2) = x0(HX-2)+int( 2*(x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX-1,HY+2) = y0(HY-2)+int( 4*(y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX-1,HY+2) = y0(HY+2)


               uhxhy(HX  ,HY+2) = 1           !  (3-5)
            xminhxhy(HX  ,HY+2) = x0(HX-2)+int( 2*(x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX  ,HY+2) = x0(HX-2)+int( 3*(x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX  ,HY+2) = y0(HY-2)+int( 4*(y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX  ,HY+2) = y0(HY+2)


               uhxhy(HX+1,HY+2) = 1           ! (4-5)
            xminhxhy(HX+1,HY+2) = x0(HX-2)+int( 3*(x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX+1,HY+2) = x0(HX-2)+int( 4*(x0(5)-x0(1))/5+.5)-1
            yminhxhy(HX+1,HY+2) = y0(HY-2)+int( 4*(y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX+1,HY+2) = y0(HY+2)

               uhxhy(HX+2,HY+2) = 1           !  (5-5)
            xminhxhy(HX+2,HY+2) = x0(HX-2)+int( 4*(x0(5)-x0(1))/5+.5)
            xmaxhxhy(HX+2,HY+2) = x0(HX+2)
            yminhxhy(HX+2,HY+2) = y0(HY-2)+int( 4*(y0(5)-y0(1))/5+.5)
            ymaxhxhy(HX+2,HY+2) = y0(HY+2)
            goto 1
         endif
 
      
      print*,'ILLEGAL UMODE (a): ',UMODE
      stop
    1 continue
      return
      end
 

      
