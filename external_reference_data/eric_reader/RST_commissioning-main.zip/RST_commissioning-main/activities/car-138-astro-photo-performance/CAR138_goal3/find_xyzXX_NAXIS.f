c----------------------------------------------
c
c uses a chisq minimization technique to find the optimal
c values for (x,y,z) using the inner 5x5 pixels; it
c takes the sky value (SKIN) as a given.  It does a very
c crude grid search to find the chisq minimim.
c
c HOWWT = 0  flat wgt
c HOWWT = 1  S/N wtg
c
c
      subroutine find_xyzXX_NAXIS(x,y,z,SKIN,qfit,chsq,
     .                    pix,psfloc,
     .                    NAXIS1,NAXIS2,HOWWT,scrivi)
      use array_size
      implicit none
 
      real*8 x,y
      real*4 z
 
      real*4 SKIN
      real    qfit
      real    chsq
 
      integer     NAXIS1,NAXIS2
      real    pix(NAXIS1,NAXIS2)
      real    psfloc(PSFSIZ,PSFSIZ)
      integer HOWWT, RFIT,scrivi
 
      real psfx(BOXFIT,BOXFIT)
      real pixx(BOXFIT,BOXFIT)
      real sig2(BOXFIT,BOXFIT)
      real psfx_(BOXFIT,BOXFIT)
 
      integer mmeth
      common / mmeth / mmeth
 
      integer NIT
      integer ii, jj, i, j,i0,j0
 
      real rpsf_phot
      real ftot
      real ptot
      real ftotw
      real ptotw
 
      real fxu, fx0, fxout
      real fyu, fy0, fyout
      real  zu,  zout
      real  dx, dy
 
      real  dd(11)
      data dd /0.300,0.200,0.100,0.050,0.030,
     .         0.020,0.010,0.005,0.003,0.002,
     .         0.001/
 
      real dxn(9)
      real dyn(9)
      data dxn/0.000,+1.000,-1.000,+0.000,+0.000,
     .               +0.707,+0.707,-0.707,-0.707/
      data dyn/0.000,+0.000,+0.000,+1.000,-1.000,
     .               +0.707,-0.707,-0.707,+0.707/
 
      integer nnn
 
      real err, chimin, chitot
      real abstot, absmin
      real pixtot
      real pixval
 
      integer NDONE
      data NDONE/0/
 
      mmeth = 5
 
      ii = int(x+0.5)
      jj = int(y+0.5)
 
      z = 0.
      zout = 0.
      qfit   = 0.99
      absmin = 0.99
 
      if (ii.lt. 0001 +2) return
      if (jj.lt. 0001 +2) return
      if (ii.gt.NAXIS1-2) return
      if (jj.gt.NAXIS2-2) return
 
      if (HOWWT.ne.0.and.HOWWT.ne.1) then
         print*,' '
         print*,'find_xymXX_chisq_NAXIS illegal param: '
         print*,'   HOWWT = ',HOWWT
         print*,' '
         stop
         endif
 
      pixtot = 0.
      do i = 1, 5
         do j = 1, 5
            pixval    = pix(ii+i-3,jj+j-3)
            pixx(i,j) = SNGL(pixval - SKIN)
            pixtot = pixtot + pixx(i,j)
            sig2(i,j) = max(pixval,0.00) + BOXFIT*BOXFIT*1.0
         enddo
      enddo
 
      fxout = SNGL(x-ii)
      fyout = SNGL(y-jj)
      do NIT = 01, 11
         fx0 = fxout
         fy0 = fyout
         chimin = 9e30
         do nnn = 01, 09
            fxu = fx0 + dd(NIT)*dxn(nnn)
            fyu = fy0 + dd(NIT)*dyn(nnn)
            ftot  = 0.
            ptot  = 0.
            ftotw = 0.
            ptotw = 0.
            do i = 1, 5
            do j = 1, 5
               dx = (i-3) - fxu
               dy = (j-3) - fyu
               psfx(i,j) = rpsf_phot(dx,dy,psfloc)
               ftot  = ftot  + psfx(i,j)
               ptot  = ptot  + pixx(i,j)
               ftotw = ftotw + psfx(i,j)*psfx(i,j)/sig2(i,j)
               ptotw = ptotw + pixx(i,j)*psfx(i,j)/sig2(i,j)
               enddo
               enddo
            zu = ptot/ftot
            chitot = 0.
            abstot = 0.
            do i = 1, 5
            do j = 1, 5
               err  = abs(pixx(i,j)-zu*psfx(i,j))
               if (HOWWT.eq.0) chitot = chitot + err**2
               if (HOWWT.eq.1) chitot = chitot + err**2/sig2(i,j)
               abstot = abstot + err
               enddo
               enddo
            if (chitot.lt.chimin) then
               chimin = chitot
               fxout = fxu
               fyout = fyu
               zout  =  zu
               absmin = abstot/pixtot
               do i = 1, 5
               do j = 1, 5
                  psfx_(i,j) = psfx(i,j)
                  enddo
                  enddo
               endif
            enddo!nnn
         enddo!NIT
 
      x = ii + fxout
      y = jj + fyout
      z = zout

      chsq = sqrt(chitot/(BOXFIT*BOXFIT-3))
      qfit = absmin
      if (qfit.gt.9.99) qfit = 9.99
      if (.not.(qfit.gt.0.00)) qfit = 9.99


      if (.false.) then
         ii = int(x+0.5)
         jj = int(y+0.5)
         i0=-3
         j0=-3
         do i = ii-2,ii+2       !int(RADFITU+2), ii+int(RADFITU+2) 
            i0=i0+1
            do j = jj-2,jj+2    !int(RADFITU+2), jj+int(RADFITU+2) 
               j0=j0+1
               dx = i-x
               dy = j-y
               write(35,3535) i0,j0,x,y,dx,dy,
     .              rpsf_phot(dx,dy,psfloc),
     .              pix(int(x+dx+.5),int(y+dy+.5)),
     .              skin,z
         enddo
      enddo
      endif

 3535 format(2(i3,1x),2(f9.4,1x),2(f9.5,1x),f10.7,1x,
     .     f8.2,1x,f9.4,1x,f14.4)

      return
      end
