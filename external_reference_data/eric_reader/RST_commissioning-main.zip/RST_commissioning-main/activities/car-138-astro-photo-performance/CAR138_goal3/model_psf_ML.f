      
      subroutine model_psf_ML(NCPU,imgfits,errfits,
     .        xorig,yorig,morig,qorig,uorig,sorig,zorig,
     .        nimorig,NIMs,NSTs,
     .        UMODE,x0,y0,PSFVAR,psfcon,
     .        psxadj,psxuse,psxchg,psfrprof,SKYBAR,SKYSIG,ITER,ITERSUB,
     .        STROBEFLAG)
      use array_size
      implicit none

      logical STROBEFLAG

      integer NCPU, LOCAL

      integer LINEs, NIM, NIMs, stat, NST, NSTs, REFINE, N, NN, Nu
      integer ii, jj, ITER, i, j, k, NOK, UMODE, ITERSUB

      integer, allocatable, dimension(:,:) :: HXHY2CHIP
      integer, allocatable, dimension(:,:) :: uhxhy
      integer, allocatable, dimension(:,:) :: xminhxhy
      integer, allocatable, dimension(:,:) :: xmaxhxhy
      integer, allocatable, dimension(:,:) :: yminhxhy
      integer, allocatable, dimension(:,:) :: ymaxhxhy
      real*4, allocatable, dimension(:,:) :: psfuse, psfold, psfadj
      real*4, allocatable, dimension(:,:) :: psfadk, psfsmu, psfnrm
      real*4, allocatable, dimension(:,:) :: psftmp, psfnew
      real*4, allocatable, dimension(:,:) :: psfbar, psfchg, subimg
      real*4, allocatable, dimension(:,:) :: psfdif
      real*4, allocatable, dimension(:,:,:) :: psflocarr
      real*4  strobo(5,5), psfcon(PSFSIZ,PSFSIZ), strobe(5,5)
      real*4  psfloc(PSFSIZ,PSFSIZ)

      integer, allocatable, dimension(:) :: niml, nstl, nimu, nstu
      real*8, allocatable, dimension(:) :: xl, yl
      real*4, allocatable, dimension(:) :: xu, yu, su, zu, qu, zw, qs
      real*4, allocatable, dimension(:) :: pu, dv, wv, fluxsum, xou, you
      real*4, allocatable, dimension(:) :: dvtot, wvtot, randtot
      integer, allocatable, dimension(:) :: usetot

      integer u, ipsf, jpsf, Us, Vs, HX, HY, NAVG
      integer XMIN, XMAX, YMIN, YMAX
      real*4 qmedn, rpsf, xpsf, ypsf, ffe, ff, ffu, dbar, dx, dy, ffnei
      real*4 psfrbar, z10, dxcen, dycen, norm, prem, volu, fluxnei
      real*4 psfrprof(PSFSIZ), rpsx_phot_miri, rclip, wtot, ww, sky_array
      real*4 psf_prem, psf_norm, psf_volu

      logical PSFVAR, GOPRINT
      
      real*4  psxold(PSFSIZ,PSFSIZ,_NPSFsX_,_NPSFsY_)
      real*4  psxadj(PSFSIZ,PSFSIZ,_NPSFsX_,_NPSFsY_)
      real*4  psxchg(PSFSIZ,PSFSIZ,_NPSFsX_,_NPSFsY_)
      real*4  psxuse(PSFSIZ,PSFSIZ,_NPSFsX_,_NPSFsY_)
      real*4 imgfits(_PXDIMX_,_PXDIMY_,NIMs)
      real*4 errfits(_PXDIMX_,_PXDIMY_,NIMs)
      real*4 SKYBAR(NSTs), SKYSIG(NSTs)
      real*8 xorig(NSTs), yorig(NSTs), xstamp(NSTs), ystamp(NSTs)
      real*4 morig(NSTs), zorig(NSTs), qorig(NSTs)
      real*4 sorig(NSTs), norm_psf
      integer uorig(NSTs), nimorig(NSTs)
      integer x0(_NPSFsX_)
      integer y0(_NPSFsY_)
      real*8 DELTA, bar, sig, xx, yy, nouse, sigx, sigy, dclip
      real*4 dsig, mbar_sky_i2e, mm, zz, za, zb, ss, qq, bar4, sig4

      real*4 dxnei, dynei, rpsf_phot
      integer iinei, jjnei, nei, ido, jdo, istar, jstar
      character*300 SUBIMGF, STRING

      integer, allocatable, dimension(:,:) :: NASHHXHY
      integer, allocatable, dimension(:,:,:) :: HASHHXHY

      real*4 somma
      integer iipsf, jjpsf, isomma, repeat


      
      if (.not.allocated(psfuse)) then
         allocate(NASHHXHY(_NPSFsX_,_NPSFsY_))
         allocate(HASHHXHY(_NHSHMX_,_NPSFsX_,_NPSFsY_))
         allocate(HXHY2CHIP(_NPSFsX_,_NPSFsY_))
         allocate(uhxhy(_NPSFsX_,_NPSFsY_))
         allocate(xminhxhy(_NPSFsX_,_NPSFsY_))
         allocate(xmaxhxhy(_NPSFsX_,_NPSFsY_))
         allocate(yminhxhy(_NPSFsX_,_NPSFsY_))
         allocate(ymaxhxhy(_NPSFsX_,_NPSFsY_))
         allocate(psfuse(PSFSIZ,PSFSIZ))
         allocate(psfold(PSFSIZ,PSFSIZ))
         allocate(psfadj(PSFSIZ,PSFSIZ))
         allocate(psfadk(PSFSIZ,PSFSIZ))
         allocate(psfsmu(PSFSIZ,PSFSIZ))
         allocate(psfnrm(PSFSIZ,PSFSIZ))
         allocate(psftmp(PSFSIZ,PSFSIZ))
         allocate(psfnew(PSFSIZ,PSFSIZ))
         allocate(psfbar(PSFSIZ,PSFSIZ))
         allocate(psfchg(PSFSIZ,PSFSIZ))
         allocate(psfdif(PSFSIZ,PSFSIZ))
      endif

      HXHY2CHIP = 1
      uhxhy = 0
      xminhxhy = 0
      xmaxhxhy = 0
      yminhxhy = 0
      ymaxhxhy = 0
      psfuse = 0.0
      psfold = 0.0
      psfadj = 0.0
      psfadk = 0.0
      psfsmu = 0.0
      psfnrm = 0.0
      psftmp = 0.0
      psfnew = 0.0
      psfbar = 0.0
      psfchg = 0.0
      psfdif = 0.0


      call umode_psfsolve(UMODE,
     .     uhxhy,
     .     xminhxhy,xmaxhxhy,
     .     yminhxhy,ymaxhxhy,x0,y0)
      call umode_output(UMODE,uhxhy)


      print*,''
      write(*,'('' STARS USED FOR THE ePSF MODELING AT ITER '',i2,
     . '' -> '',i8)') ITER, NSTs
      print*,''


      if (DOSAMP) then
         if (ITER.le.2.or.ITER.eq.ITERSUB-1.or.
     .        ITER.eq.ITERSUB.or.
     .        ITER.eq.ITERSUB*2) then
            write(STRING,'(''SAMPLING.INFO.'',i2.2)') ITER
            open(87,FILE=STRING,status='unknown')
         endif
      endif
      
      NAVG = 0
      do HX = 1, _NPSFsX_, 1
         do HY = 1, _NPSFsY_, 1
            psxadj(:,:,HX,HY) = 0.0
! Model the PSF in a given cell of the PSF grid
            if (uhxhy(hx,hy).eq.1) then

               k = HXHY2CHIP(HX,HY)
!
!     Define the location w/in the image
!     that will contribute to this PSF
!     
               XMIN = xminhxhy(HX,HY)
               XMAX = xmaxhxhy(HX,HY)
               YMIN = yminhxhy(HX,HY)
               YMAX = ymaxhxhy(HX,HY)


!     Make a list of the stars that can contribute to
!     the PSF for this region
               Us = 0
               do N = 1, NSTs
                  xx = xorig(N)
                  yy = yorig(N)
                  if (xx.gt.XMIN.and.xx.le.XMAX.and.
     .                yy.gt.YMIN.and.yy.le.YMAX.and.
     .                uorig(N).eq.1) Us = Us + 1
               enddo            ! N
                
               if (.not.allocated(xu)) allocate(xu(Us))
               if (.not.allocated(yu)) allocate(yu(Us))
               if (.not.allocated(su)) allocate(su(Us))
               if (.not.allocated(zu)) allocate(zu(Us))
               if (.not.allocated(zw)) allocate(zw(Us))
               if (.not.allocated(qu)) allocate(qu(Us))
               if (.not.allocated(qs)) allocate(qs(Us))
               if (.not.allocated(pu)) allocate(pu(Us))
               if (.not.allocated(nimu)) allocate(nimu(Us))
               if (.not.allocated(nstu)) allocate(nstu(Us))
               if (.not.allocated(psflocarr)) 
     .              allocate(psflocarr(PSFSIZ,PSFSIZ,Us))
               xu = 0.0
               yu = 0.0
               su = 0.0
               zu = 0.0
               zw = 0.0
               qu = 0.0
               qs = 0.0
               pu = 0.0
               nimu = 0
               nstu = 0
               psflocarr = 0.0
               
               Us = 0
               do N = 1, NSTs
                  xx = xorig(N)
                  yy = yorig(N)
                  if (xx.gt.XMIN.and.xx.le.XMAX.and.
     .                yy.gt.YMIN.and.yy.le.YMAX.and.
     .                uorig(N).eq.1) then
                     Us = Us + 1
                     xu(Us) = xorig(N)
                     yu(Us) = yorig(N)
                     su(Us) = sorig(N)
                     zu(Us) = zorig(N)
                     zw(Us) = zorig(N)
                     qu(Us) = qorig(N)
                     qs(Us) = qorig(N)
                     ii = nint(xu(Us))
                     jj = nint(yu(Us))
                     pu(Us) = imgfits(ii,jj,nimorig(N))
                     nimu(Us) = nimorig(N)
                     nstu(Us) = N
                     if (ITER.gt.1) then
                        psfloc = 0.0
                        call locpsfij(
     .                       nint(xu(Us)),nint(yu(Us)),
     .                       psfloc,psxuse,x0,y0,PSFSIZ)
                        psflocarr(:,:,Us) = psfloc(:,:)
                     endif
                  endif         ! w/in boundaries
               enddo            ! N

               call sort_nr(Us,qs)
               qmedn = qs(nint(Us/2.0))
               if (Us.gt.10) then
                  call sort_nr(Us,zw)
                  z10 = zw(Us-10)
                  do N = 1, Us
                     zw(N) = min(zu(N),z10)
                  enddo
               endif
             
               if(HY.eq.1.and.HX.eq.1) then
                  print*, Us
                  write(*,113)
                  write(*,112)
                  write(*,113)
               endif
!     
!     Solve for the ePSF
!
               psfadj = 0.0
               psfuse(:,:) = psxuse(:,:,HX,HY)

               if (.not.allocated(dvtot)) allocate(dvtot(Us))
               if (.not.allocated(wvtot)) allocate(wvtot(Us))
               if (.not.allocated(usetot)) allocate(usetot(Us))
               if (.not.allocated(randtot)) allocate(randtot(Us))

               
               do ipsf = 001, PSFSIZ
                  do jpsf = 001, PSFSIZ
                     xpsf = (ipsf-PSFMID)/_PSFFAC_
                     ypsf = (jpsf-PSFMID)/_PSFFAC_
                     rpsf = sqrt(xpsf**2+ypsf**2)
                     i = nint(rclip(rpsf,1.0,PSFSIZ*1.0-1.))
                     psfrbar = psfrprof(i) + (rpsf-i)*
     .                    (psfrprof(i+1)-psfrprof(i))
                     if (psfrbar.lt.0) psfrbar = 0.
                     dbar = 0.0
                     dsig = 0.0
                     wtot = 0.0
                     Vs = 0


                     dvtot = 0.0
                     wvtot = 0.0
                     usetot = 0
                     call random_number(randtot)

!$omp parallel NUM_THREADS(NCPU)
!$omp& default(private)
!$omp& shared(Us,xu,yu,xpsf,ypsf,rpsf,ITER,pu,qu,su,zu,nimu)
!$omp& shared(psfrbar,x0,y0,psxuse,NSTs,nstu,qmedn,imgfits,RCORE)
!$omp& shared(dvtot,zw,SKYSIG,wvtot,usetot,ITERSUB,MCORE)
!$omp& shared(STPSIZ,STPMID,randtot,errfits,psflocarr)
!$omp do schedule(dynamic)
                     do u = 1, Us

                        ii = nint(xu(u)+xpsf)
                        jj = nint(yu(u)+ypsf)
                        if (.not.(ii.gt.1.and.ii.lt._PXDIMX_.and.
     .                            jj.gt.1.and.jj.lt._PXDIMY_)) cycle
                        
                        if ((!rpsf.le.PSFWINGS/_PSFFAC_.and.
     .                      pu(u).lt._HIFLAG_.and.qu(u).le.qmedn*5.and.
     .                      imgfits(ii,jj,nimu(u)).gt._LOFLAG_.and.
     .                      imgfits(ii,jj,nimu(u)).lt._HIFLAG_)
     .                       ) then

                           ffe = (imgfits(ii,jj,nimu(u))-su(u))/zu(u)

                           if (abs(ffe).le.100.*psfrbar) then

                              dx = ii-xu(u)
                              dy = jj-yu(u)
                              ff = rpsf_phot(dx,dy,psflocarr(:,:,u))

                              dvtot(u) = ffe-ff
                              usetot(u) = 1

                              ffu = max(psfrbar,ff)
                              ffu = psfrbar
                              ww = (ffu*zw(u))/
     .                             (ffu*zw(u)+100+SKYSIG(nimu(u)))

                              if (ITER.eq.1) ww = 1.0
                              if (rpsf.lt.3.0) ww = 1.0
                              wvtot(u) = ww
                              wtot = wtot + ww

                           endif ! ffe

                        endif
                     enddo      ! u
!$omp enddo
!$omp end parallel

                     if (sum(usetot).le.0) cycle

                     dv = pack(dvtot,usetot.eq.1)
                     wv = pack(wvtot,usetot.eq.1)
                     Vs = size(dv)

                     if (DOSAMP) then
                     do u = 1, Us
                        if (usetot(u).eq.1) then

!$omp critical (scrivi)
                           if ((ITER.le.2.or.ITER.eq.ITERSUB-1.or.
     .                          ITER.eq.ITERSUB.or.
     .                          ITER.eq.ITERSUB*2).and.
     .                          (abs(ipsf-PSFMID).le.40.or.
     .                          abs(jpsf-PSFMID).le.40).and.
     .                          randtot(u)<0.01)
     .                          write(87,*) ITER, u, xu(u), yu(u),
     .                          ipsf, jpsf, xpsf, ypsf,
     .                          (nint(xu(u)+xpsf))-xu(u),
     .                          (nint(yu(u)+ypsf))-yu(u),
     .                          nint(xu(u)+xpsf),
     .                          nint(yu(u)+ypsf),
     .                          ((imgfits(nint(xu(u)+xpsf),
     .                          nint(yu(u)+ypsf),nimu(u))-
     .                          su(u))/zu(u)),
     .                          dvtot(u),
     .                          imgfits(nint(xu(u)+xpsf),
     .                          nint(yu(u)+ypsf),nimu(u)),
     .                          su(u), zu(u), wvtot(u), HX, HY
!$omp end critical (scrivi)


                        endif
                     enddo
                     endif

                     call barsigw(dv,wv,Vs,dbar,dsig)

                     GOPRINT = jpsf.eq.PSFMID.and.ipsf.eq.PSFMID
                     if (GOPRINT)
     .                    write( *,111) HX,HY,XMIN,XMAX,YMIN,YMAX,
     .                    ipsf,jpsf,xpsf,ypsf,
     .                    psfuse(ipsf,jpsf),
     .                    rclip(dbar,-0.999,0.999),
     .                    rclip(dsig,-0.999,0.999),
     .                    psfbar(ipsf,jpsf),psfrbar,Us,Vs,
     .                    wtot,k,ITER,qmedn
 11                  continue
                     psfadj(ipsf,jpsf) = dbar
                     psxadj(ipsf,jpsf,HX,HY) = dbar

                     if (allocated(dv)) deallocate(dv)
                     if (allocated(wv)) deallocate(wv)

                  enddo         ! jpsf
               enddo            ! ipsf

               if (allocated(dvtot)) deallocate(dvtot)
               if (allocated(wvtot)) deallocate(wvtot)
               if (allocated(usetot)) deallocate(usetot)
               if (allocated(randtot)) deallocate(randtot)
               
               NAVG = NAVG + 1

 10            continue
               if (allocated(xu)) deallocate(xu)
               if (allocated(yu)) deallocate(yu)
               if (allocated(su)) deallocate(su)
               if (allocated(zu)) deallocate(zu)
               if (allocated(zw)) deallocate(zw)
               if (allocated(qu)) deallocate(qu)
               if (allocated(qs)) deallocate(qs)
               if (allocated(pu)) deallocate(pu)
               if (allocated(nimu)) deallocate(nimu)
               if (allocated(nstu)) deallocate(nstu)
               if (allocated(psflocarr)) deallocate(psflocarr)

            endif               ! uhxhy

         enddo                  ! HY
      enddo                     ! HX


      if (DOSAMP) then
         if (ITER.le.2.or.ITER.eq.ITERSUB-1.or.
     .       ITER.eq.ITERSUB.or.
     .       ITER.eq.ITERSUB*2) close(87)
      endif
               
      write(*,113)
      write(*,112)
      write(*,113)


      if (allocated(niml)) deallocate(niml)
      if (allocated(nstl)) deallocate(nstl)

      write(*,'(   ''                     '')')
      write(*,'(   ''                     '')')
      write(*,'(   ''*********************'')') 
      write(*,'(i2.2,''.3 SMOOTH PSF'')') ITER
      write(*,'(   ''*********************'')') 
      write(*,'(   ''                     '')')
      write(*,'(   ''                     '')')

      write(*,411)
      write(*,412)
      write(*,411)

      
      psxchg = 0.0
      do HX = 1, _NPSFsX_
         do HY = 1, _NPSFsY_
            if (uhxhy(hx,hy).eq.0) cycle
            psfuse(:,:) = psxuse(:,:,HX,HY)
            psfadj(:,:) = psxadj(:,:,HX,HY)
            psfnew(:,:) = psxuse(:,:,HX,HY) + psxadj(:,:,HX,HY)

            call psf_smoq_iter(psfnew,psfsmu,ITER,PSFSIZ,PSFMID)

            where (psfsmu(:,:).lt.0.0)
               psfsmu(:,:)=0.0
            end where

            norm = norm_psf(psfsmu,psfnrm,(_radnorm_*1.0))
            
            psfsmu = psfnrm
            call rcen_psf(psfsmu,psfnrm,1.5,dxcen,dycen,
     .           PSFSIZ,PSFMID)
       

            volu = psf_volu(psfnrm)

            if (STROBEFLAG) then
               psfsmu = 0.0
               call strobe_norm_psf(psfnrm,psfsmu,strobe,PSFSIZ,PSFMID)
               norm = norm_psf(psfsmu,psfnrm,10.0)
               psfsmu = psfnrm
               call rcen_psf(psfsmu,psfnrm,1.5,
     .          dxcen,dycen,PSFSIZ,PSFMID)
            endif

            psfuse(:,:)=psfnrm(:,:)
            psxuse(:,:,HX,HY)=psfuse(:,:)
            psxchg(:,:,HX,HY)=psxuse(:,:,HX,HY)-psxold(:,:,HX,HY)

            write( *,410) HX,HY,0.0,norm,volu,            
     .           psfadj(PSFMID,PSFMID),psfnew(PSFMID,PSFMID),
     .           psfnew(PSFMID,PSFMID)-psfsmu(PSFMID,PSFMID),
     .           psfnrm(PSFMID,PSFMID),
     .           psxold(PSFMID,PSFMID,HX,HY),
     .           psxadj(PSFMID,PSFMID,HX,HY),
     .           psxchg(PSFMID,PSFMID,HX,HY),
     .           psxuse(PSFMID,PSFMID,HX,HY),
     .           (strobo(3,3)-1)*100,
     .           (strobo(1,3)-1)*100,
     .           (strobo(1,1)-1)*100,
     .           dxcen,dycen
 410        format(1x,i2.2,
     .           1x,i2.2,
     .           3x,f10.6,1x,f10.6,1x,f10.6,
     .           5x,f10.6,1x,f10.6,1x,f10.6,1x,f10.6,
     .           5x,f10.6,1x,f10.6,1x,f10.6,1x,f10.6,
     .           3x,f7.2,1x,f7.2,1x,f7.2,
     .           2x,f7.4,1x,f7.4)
 411        format('#','--',
     .           1x,'--',
     .           3x,'----------',1x,'----------',1x,'----------',
     .           5x,'----------',1x,'----------',1x,'----------', 
     .           1x,'----------',
     .           5x,'----------',1x,'----------',1x,'----------',
     .           1x,'----------',
     .           3x,'-------',   1x,'-------',   1x,'-------',
     .           2x,'-------',   1x,'-------')
 412        format('#','HX',
     .           1x,'HY',
     .           3x,' PSF_REM  ',1x,' PSFNORM  ',1x,' PSFVOLTOT',
     .           5x,' PSFADJ(C)',1x,' PSFNEW(C)',1x,'PSFSMOO(C)',
     .           1x,' PSFNRM(C)',
     .           5x,' PSXADJ(C)',1x,' PSXNEW(C)',1x,'PSXSMOO(C)',
     .           1x,' PSXNRM(C)',
     .           3x,'PRFSAM1',   1x,'PRFSAM2',   1x,'PRFSAM3',
     .           2x,'  XCEN ',   1x,'  YCEN ')
            if (.not.(norm.gt.0)) then
               print*,'  NORM NaN: ',norm
               stop
            endif            
         enddo
      enddo
        
            
      call umode_psfdisperse_09x05(UMODE,psxuse,x0,y0,PSFSIZ)


      write(*,*)
      write(*,*)
      write(*,'(   ''***********************************'')') 
      write(*,'(i2.2,''.4 FIND NEW AVERAGE PROPERTIES'')') 
     .     ITER
      write(*,'(   ''***********************************'')') 
      write(*,*)
      write(*,*)
      call psx_avrg(psxold,psfold)
      call psx_avrg(psxadj,psfadj)
      call psx_avrg(psxuse,psfbar)


!     Compute and document how much the PSF varies spatially
      if (PSFVAR) then
         do HX = 1, _NPSFsX_
            do HY = 1, _NPSFsY_
                  psxchg(:,:,HX,HY) = 
     .                 psxuse(:,:,HX,HY) - psfbar(:,:)
            enddo
         enddo
         print*,' '
         print*,'PSXUSE: at gridpoints '
         do HY = _NPSFsY_, 1, -1
            write(*,'(i4,1x,5f10.6)') 
     .           HY,(psxuse(PSFMID,PSFMID,HX,HY),HX=1,_NPSFsX_)
         enddo
         print*,' '
      endif

      if (.not.PSFVAR) then     ! preserve the outer part
         psfcon = psfbar
      endif
      
      call psf_prof2(psfbar,psfrprof,ITER)
      call psx_report2(psxuse)
      
      
      if (allocated(HXHY2CHIP)) deallocate(HXHY2CHIP)
      if (allocated(NASHHXHY)) deallocate (NASHHXHY)
      if (allocated(HASHHXHY)) deallocate(HASHHXHY)
      if (allocated(uhxhy)) deallocate(uhxhy)
      if (allocated(xminhxhy)) deallocate(xminhxhy)
      if (allocated(xmaxhxhy)) deallocate(xmaxhxhy)
      if (allocated(yminhxhy)) deallocate(yminhxhy)
      if (allocated(ymaxhxhy)) deallocate(ymaxhxhy)
      if (allocated(psfuse)) deallocate(psfuse)
      if (allocated(psfold)) deallocate(psfold)
      if (allocated(psfadj)) deallocate(psfadj)
      if (allocated(psfadk)) deallocate(psfadk)
      if (allocated(psfsmu)) deallocate(psfsmu)
      if (allocated(psfdif)) deallocate(psfdif)
      if (allocated(psfnrm)) deallocate(psfnrm)
      if (allocated(psftmp)) deallocate(psftmp)
      if (allocated(psfnew)) deallocate(psfnew)
      if (allocated(psfbar)) deallocate(psfbar)
      if (allocated(psfchg)) deallocate(psfchg)



 111  format(' ',i2.2,1x,i2.2,
     .     3x,i5,1x,i5,1x,i5,1x,i5,
     .     3x,i3,1x,i3,
     .     3x,f5.1,1x,f5.1,
     .     3x,f9.6,1x,f9.6,
     .     1x,f9.6,1x,f9.6,1x,f9.6,
     .     2x,i9,2x,i9,
     .     1x,f7.1,4x,i2,4x,i2,1x,f8.4)
 112  format('#','HX',1x,'HY',
     .     3x,'XMIN ',1x,'XMAX ',1x,'YMIN ',1x,'YMAX ',
     .     3x,'IPF',1x,'JPF',
     .     3x,'  DX ',1x,'  DY ',
     .     3x,' PSFUSE  ',1x,'  DBAR   ',
     .     1x,'  DSIG   ',1x,' PSFBAR  ',1x,' PSFRBAR ',
     .     3x,'  Us ',7x,'  Vs ',
     .     1x,'  WTU  ',2x,' K',1x,' ITER',2x,' QFmed')
 113  format('#','--',1x,'--',
     .     3x,'-----',1x,'-----',1x,'-----',1x,'-----',
     .     3x,'---',1x,'---',
     .     3x,'-----',1x,'-----',
     .     3x,'---------',
     .     1x,'---------',
     .     1x,'---------',
     .     1x,'---------',
     .     1x,'---------',
     .     1x,'----------',1x,'----------',
     .     1x,'-------',2x,'---',1x,'------',3x,'------')

      return

      end




 
