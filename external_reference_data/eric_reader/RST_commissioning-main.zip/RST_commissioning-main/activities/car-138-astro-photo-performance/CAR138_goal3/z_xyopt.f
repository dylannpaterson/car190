
c-----------------------------------------------
c
 
      real function z_xyopt(xin,yin,skin,pix,
     .                      psfloc,
     .                      NAXIS1,NAXIS2,DOSNWT)
      use array_size
      implicit none
      real*8 xin
      real*8 yin
      real*4 skin
      integer NAXIS1
      integer NAXIS2
      real    pix(NAXIS1,NAXIS2)
      real    psfloc(PSFSIZ,PSFSIZ)
      integer DOSNWT
 
      real   rpsf_phot
 
      real    dx, dy
      integer ix, iy
      integer i,  j
 
      integer NL, NLs
      real dl(500)
      real pl(500)
      real fl(500)
      real sl(500)
      real wl(500)
 
      real*8 sumpf
      real*8 sumff
      real*8 sumpfw
      real*8 sumffw
      real*8 zuse
 
      integer NARG
      common /NARG_/NARG
      integer mmeth
      common /mmeth/ mmeth
 
 
      ix = int(xin+0.5)
      iy = int(yin+0.5)
 
      z_xyopt = 0.
 
      if (ix.le. 0001 +RADFIT) return
      if (iy.le. 0001 +RADFIT) return
      if (ix.ge.NAXIS1+RADFIT) return
      if (iy.ge.NAXIS2+RADFIT) return
 
      NLs = 0
      do i = ix-int(RADFIT+1),ix+int(RADFIT+1)
      do j = iy-int(RADFIT+1),iy+int(RADFIT+1)
         dx = SNGL(i-xin)
         dy = SNGL(j-yin)
         if (sqrt(dx**2+dy**2).lt.RADFIT) then
            NLs = NLs + 1
            if (NLs.gt.500) then
               print*,'z_opt: NLs.gt.500'
               stop
               endif
            pl(NLs) = SNGL(pix(i,j)-skin)
            fl(NLs) = rpsf_phot(dx,dy,psfloc)
            dl(NLs) = sqrt(dx**2+dy**2)
            endif
         enddo
         enddo
 
      sumpf = 0.
      sumff = 0.
      do NL = 01, NLs
         sumpf = sumpf + fl(NL)*pl(NL)
         sumff = sumff + fl(NL)*fl(NL)
         enddo
      zuse = sumpf/sumff
      if (zuse.lt.0) zuse = 0.
 
      do NL = 1, NLs
         sl(NL) = SNGL(sqrt(zuse*fl(NL)+skin+15))
         wl(NL) = 1.00/sl(NL)**2
         if (DOSNWT.eq.0) wl(NL) = 1.0
         enddo
 
      sumpfw = 0.
      sumffw = 0.
      do NL = 01, NLs
         sumpfw = sumpfw + fl(NL)*pl(NL)*wl(NL)
         sumffw = sumffw + fl(NL)*fl(NL)*wl(NL)
         enddo
      zuse = sumpfw/sumffw
      if (zuse.lt.0) zuse = 0.
 
      z_xyopt = SNGL(zuse)



      
      return
      end
 
 
