

      subroutine umode_psfdisperse_09x05(UMODE,psx,x0,y0,PSFSIZ)
      implicit none

      integer PSFSIZ
      integer(kind=4) UMODE
      real    psx(PSFSIZ,PSFSIZ,_NPSFsX_,_NPSFsY_)
 
      integer(kind=4) x0(_NPSFsX_)
      integer(kind=4) y0(_NPSFsY_)


      integer(kind=4) HX, HY
      integer(kind=4) ipsf,jpsf
 
 
c----------------------------------
c
c UMODE = 0 or UMODE = 1
c
c one single PSF, stored in (1,1)
c
      if (UMODE.eq.0.or.UMODE.eq.1) then  
         do HX = 1, _NPSFsX_ 
         do HY = 1, _NPSFsY_
            if (HX.ne.1.or.HY.ne.1)
     .           psx(:,:,HX,HY) = psx(:,:,1,1)
            enddo
            enddo
         return
         endif



c----------------------------------
c
c UMODE = 2
c
c four PSFs 
c
      if (UMODE.eq.2) then  
         print*,'  FOUR PSFs '
         HX=3
         HY=3
            do ipsf = 001, PSFSIZ
            do jpsf = 001, PSFSIZ

               psx(ipsf,jpsf,HX-2,HY-1) = (3*psx(ipsf,jpsf,HX-2,HY-2)+
     .                                     1*psx(ipsf,jpsf,HX-2,HY+2))/4
               psx(ipsf,jpsf,HX-2,HY  ) = (2*psx(ipsf,jpsf,HX-2,HY-2)+
     .                                     2*psx(ipsf,jpsf,HX-2,HY+2))/4
               psx(ipsf,jpsf,HX-2,HY+1) = (1*psx(ipsf,jpsf,HX-2,HY-2)+
     .                                     3*psx(ipsf,jpsf,HX-2,HY+2))/4

               psx(ipsf,jpsf,HX+2,HY-1) = (3*psx(ipsf,jpsf,HX+2,HY-2)+
     .                                     1*psx(ipsf,jpsf,HX+2,HY+2))/4
               psx(ipsf,jpsf,HX+2,HY  ) = (2*psx(ipsf,jpsf,HX+2,HY-2)+
     .                                     2*psx(ipsf,jpsf,HX+2,HY+2))/4
               psx(ipsf,jpsf,HX+2,HY+1) = (1*psx(ipsf,jpsf,HX+2,HY-2)+
     .                                     3*psx(ipsf,jpsf,HX+2,HY+2))/4


               psx(ipsf,jpsf,HX  ,HY-2) = (2*psx(ipsf,jpsf,HX-2,HY-2)+
     .                                     2*psx(ipsf,jpsf,HX+2,HY-2))/4
               psx(ipsf,jpsf,HX  ,HY-1) = (2*psx(ipsf,jpsf,HX-2,HY-1)+
     .                                     2*psx(ipsf,jpsf,HX+2,HY-1))/4
               psx(ipsf,jpsf,HX  ,HY  ) = (2*psx(ipsf,jpsf,HX-2,HY  )+
     .                                     2*psx(ipsf,jpsf,HX+2,HY  ))/4
               psx(ipsf,jpsf,HX  ,HY+1) = (2*psx(ipsf,jpsf,HX-2,HY+1)+
     .                                     2*psx(ipsf,jpsf,HX+2,HY+1))/4
               psx(ipsf,jpsf,HX  ,HY+2) = (2*psx(ipsf,jpsf,HX-2,HY+2)+
     .                                     2*psx(ipsf,jpsf,HX+2,HY+2))/4

               psx(ipsf,jpsf,HX-1,HY-2) = (2*psx(ipsf,jpsf,HX-2,HY-2)+
     .                                     2*psx(ipsf,jpsf,HX  ,HY-2))/4
               psx(ipsf,jpsf,HX-1,HY-1) = (2*psx(ipsf,jpsf,HX-2,HY-1)+
     .                                     2*psx(ipsf,jpsf,HX  ,HY-1))/4
               psx(ipsf,jpsf,HX-1,HY  ) = (2*psx(ipsf,jpsf,HX-2,HY  )+
     .                                     2*psx(ipsf,jpsf,HX  ,HY  ))/4
               psx(ipsf,jpsf,HX-1,HY+1) = (2*psx(ipsf,jpsf,HX-2,HY+1)+
     .                                     2*psx(ipsf,jpsf,HX  ,HY+1))/4
               psx(ipsf,jpsf,HX-1,HY+2) = (2*psx(ipsf,jpsf,HX-2,HY+2)+
     .                                     2*psx(ipsf,jpsf,HX  ,HY+2))/4

               psx(ipsf,jpsf,HX+1,HY-2) = (2*psx(ipsf,jpsf,HX  ,HY-2)+
     .                                     2*psx(ipsf,jpsf,HX+2,HY-2))/4
               psx(ipsf,jpsf,HX+1,HY-1) = (2*psx(ipsf,jpsf,HX  ,HY-1)+
     .                                     2*psx(ipsf,jpsf,HX+2,HY-1))/4
               psx(ipsf,jpsf,HX+1,HY  ) = (2*psx(ipsf,jpsf,HX  ,HY  )+
     .                                     2*psx(ipsf,jpsf,HX+2,HY  ))/4
               psx(ipsf,jpsf,HX+1,HY+1) = (2*psx(ipsf,jpsf,HX  ,HY+1)+
     .                                     2*psx(ipsf,jpsf,HX+2,HY+1))/4
               psx(ipsf,jpsf,HX+1,HY+2) = (2*psx(ipsf,jpsf,HX  ,HY+2)+
     .                                     2*psx(ipsf,jpsf,HX+2,HY+2))/4
               enddo
             enddo
         return
         endif




c----------------------------------
c
c UMODE = 3
c
c nine PSFs
c
      if (UMODE.eq.3) then 
         print*,'  NINE PSFs'
            HX=3
            HY=3
            do ipsf = 001, PSFSIZ
            do jpsf = 001, PSFSIZ


              psx(ipsf,jpsf,HX-2,HY-1) = (2*psx(ipsf,jpsf,HX-2,HY-2)+
     .                                     2*psx(ipsf,jpsf,HX-2,HY  ))/4
              psx(ipsf,jpsf,HX-2,HY+1) = (2*psx(ipsf,jpsf,HX-2,HY  )+
     .                                     2*psx(ipsf,jpsf,HX-2,HY+2))/4

              psx(ipsf,jpsf,HX  ,HY-1) = (2*psx(ipsf,jpsf,HX  ,HY-2)+
     .                                     2*psx(ipsf,jpsf,HX  ,HY  ))/4
              psx(ipsf,jpsf,HX  ,HY+1) = (2*psx(ipsf,jpsf,HX  ,HY  )+
     .                                     2*psx(ipsf,jpsf,HX  ,HY+2))/4

              psx(ipsf,jpsf,HX+2,HY-1) = (2*psx(ipsf,jpsf,HX+2,HY-2)+
     .                                     2*psx(ipsf,jpsf,HX+2,HY  ))/4
              psx(ipsf,jpsf,HX+2,HY+1) = (2*psx(ipsf,jpsf,HX+2,HY  )+
     .                                     2*psx(ipsf,jpsf,HX+2,HY+2))/4

               psx(ipsf,jpsf,HX-1,HY-2) = (2*psx(ipsf,jpsf,HX-2,HY-2)+
     .                                     2*psx(ipsf,jpsf,HX  ,HY-2))/4
               psx(ipsf,jpsf,HX-1,HY-1) = (2*psx(ipsf,jpsf,HX-2,HY-1)+
     .                                     2*psx(ipsf,jpsf,HX  ,HY-1))/4
               psx(ipsf,jpsf,HX-1,HY  ) = (2*psx(ipsf,jpsf,HX-2,HY  )+
     .                                     2*psx(ipsf,jpsf,HX  ,HY  ))/4
               psx(ipsf,jpsf,HX-1,HY+1) = (2*psx(ipsf,jpsf,HX-2,HY+1)+
     .                                     2*psx(ipsf,jpsf,HX  ,HY+1))/4
               psx(ipsf,jpsf,HX-1,HY+2) = (2*psx(ipsf,jpsf,HX-2,HY+2)+
     .                                     2*psx(ipsf,jpsf,HX  ,HY+2))/4


               psx(ipsf,jpsf,HX+1,HY-2) = (2*psx(ipsf,jpsf,HX  ,HY-2)+
     .                                     2*psx(ipsf,jpsf,HX+2,HY-2))/4
               psx(ipsf,jpsf,HX+1,HY-1) = (2*psx(ipsf,jpsf,HX  ,HY-1)+
     .                                     2*psx(ipsf,jpsf,HX+2,HY-1))/4
               psx(ipsf,jpsf,HX+1,HY  ) = (2*psx(ipsf,jpsf,HX  ,HY  )+
     .                                     2*psx(ipsf,jpsf,HX+2,HY  ))/4
               psx(ipsf,jpsf,HX+1,HY+1) = (2*psx(ipsf,jpsf,HX  ,HY+1)+
     .                                     2*psx(ipsf,jpsf,HX+2,HY+1))/4
               psx(ipsf,jpsf,HX+1,HY+2) = (2*psx(ipsf,jpsf,HX  ,HY+2)+
     .                                     2*psx(ipsf,jpsf,HX+2,HY+2))/4

               enddo
            enddo
         return
         endif

      if (UMODE.eq.4) then 
         print*,'  ALL TWENTYFIVE PSFs'
         print*,'  ---> ALREADY DISPERSED! '
         return
      endif
 
      print*,'ILLEGAL UMODE (b): ',UMODE
      stop
      end
 
 
