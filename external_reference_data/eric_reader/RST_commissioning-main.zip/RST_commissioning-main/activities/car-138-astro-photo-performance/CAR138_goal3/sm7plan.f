
 
c------------------------------------
c
c
      subroutine sm7plan(r,s,NX,NY)
      use array_size
      implicit none
 
      integer NX, NY
      real r(NX,NY)
      real s(NX,NY)
 
      integer i, j
      integer iu, ju
      integer im, jm
 
      real dx, dy
      real A, B, C
 
      real AR,BR,CR
      real AA,BB,CC
 
      do i = 1, NX
      do j = 1, NY
         iu = max(min(i,NX-3),1+3)
         ju = max(min(j,NY-3),1+3)
         AR = 0.
         BR = 0.
         CR = 0.
         AA = 0.
         BB = 0.
         CC = 0.
         do im = 1, 7
         do jm = 1, 7
            AR = AR + r(iu-4+im,ju-4+jm)
            BR = BR + r(iu-4+im,ju-4+jm)*(im-4)
            CR = CR + r(iu-4+im,ju-4+jm)*(jm-4)
            AA = AA + 1
            BB = BB + (im-4)*(im-4)
            CC = CC + (jm-4)*(jm-4)
            enddo
            enddo
         A = AR/AA
         B = BR/BB
         C = CR/CC
         dx = i-iu
         dy = j-ju
         s(i,j) = A + B*dx + C*dy
         enddo
         enddo
 
      return
      end
 
