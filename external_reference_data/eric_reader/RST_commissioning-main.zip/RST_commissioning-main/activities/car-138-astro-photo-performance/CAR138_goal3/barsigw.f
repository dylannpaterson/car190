
      subroutine barsigw(xl,wl,NTOT,bar,sig)
      use array_size
      implicit none
 
      integer NTOT
      real xl(NTOT)
      real wl(NTOT)
      real bar
      real sig
      integer NUSE
 
      integer n
      real*8  bsum, ssum
      real*8  wsum
      integer NIT
      real sig0
      real wtot
      real wmax
      real wmux
 
 
 
      if (NTOT.lt.10) then
         do n = 1, NTOT
            wl(n) = 1.0
            enddo
         goto 5
         endif
 
  5   continue
      bar = 0.e0
      sig = 9e9
      NIT = 0
  1   continue
      NIT = NIT + 1
      sig0 = sig
      bsum = 0.
      ssum = 0.
      wsum = 0.
      do n = 1, NTOT
         if (abs(xl(n)-bar).le.2.50*sig) then
            bsum = bsum + wl(n)*xl(n)
            ssum = ssum + wl(n)*abs(xl(n)-bar)
            wsum = wsum + wl(n)
            endif
         enddo
      if (wsum.gt.0) then
         bar = bsum/wsum
         sig = ssum/wsum
         endif
      if (abs(sig-sig0).gt.0.10*sig0.and.NIT.lt.20) goto 1
 
      return
      end
 
