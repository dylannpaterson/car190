      subroutine strobe_norm_psf(psf_i,psf_o,strobe_i,PSFSIZ,PSFMID)
      implicit none

      integer PSFSIZ,PSFMID
      real psf_i(PSFSIZ,PSFSIZ)
      real psf_o(PSFSIZ,PSFSIZ)

      real strobe_i(5,5)

      real psf_c(PSFSIZ,PSFSIZ)
      real strobe(5,5)

      integer(kind=4) ipsf, ipsfu, i, ii
      integer(kind=4) jpsf, jpsfu, j, jj

      DOUBLE PRECISION  f, ptot, ftot
      real    strobe_bar

      do ipsf = 001, PSFSIZ
      do jpsf = 001, PSFSIZ
         ptot = 0.
         ftot = 0.
         do ii = -2, 2
         do jj = -2, 2
            f = 1.00
            if (abs(ii).eq.2) f = f/2.0
            if (abs(jj).eq.2) f = f/2.0
            ipsfu = ipsf + ii
            jpsfu = jpsf + jj
            if (ipsfu.lt.001) ipsfu = 001 
            if (ipsfu.gt.PSFSIZ) ipsfu = PSFSIZ 
            if (jpsfu.lt.001) jpsfu = 001 
            if (jpsfu.gt.PSFSIZ) jpsfu = PSFSIZ
            ptot = ptot + f*psf_i(ipsfu,jpsfu)
            ftot = ftot + f
            enddo
            enddo
         psf_c(ipsf,jpsf) = ptot/ftot
         enddo
         enddo

      do ii = -2, 2
      do jj = -2, 2
         ptot = 0.
         ftot = 0.
         do i = -12, +12, 4
         do j = -12, +12, 4
            if (i**2+j**2.le.14**2) then
                ptot = ptot + psf_i(PSFMID+i+ii,PSFMID+j+jj)
                ftot = ftot + psf_c(PSFMID+i+ii,PSFMID+j+jj)
                endif
            enddo 
            enddo
         strobe(3+ii,3+jj) = ptot/ftot 
         enddo
         enddo

      ptot = 0.
      ftot = 0.
      do ii = -2, 2
      do jj = -2, 2
         f = 1.00
         if (abs(ii).eq.2) f = f/2.0
         if (abs(jj).eq.2) f = f/2.0
         ptot = ptot + f*strobe(3+ii,3+jj)
         ftot = ftot + f
         enddo
         enddo
      strobe_bar = ptot/ftot

      strobe(1,1) = (strobe(1,1)+strobe(5,1)+strobe(1,5)+strobe(5,5))/4.
      strobe(1,5) =  strobe(1,1)
      strobe(5,1) =  strobe(1,1)
      strobe(5,5) =  strobe(1,1)
      strobe(1,2) = (strobe(1,2)+strobe(5,2))/2.0
      strobe(5,2) =  strobe(1,2)
      strobe(1,3) = (strobe(1,3)+strobe(5,3))/2.0
      strobe(5,3) =  strobe(1,3)
      strobe(1,4) = (strobe(1,4)+strobe(5,4))/2.0
      strobe(5,4) =  strobe(1,4)
      strobe(2,1) = (strobe(2,1)+strobe(2,5))/2.0
      strobe(2,5) =  strobe(2,1)
      strobe(3,1) = (strobe(3,1)+strobe(3,5))/2.0
      strobe(3,5) =  strobe(3,1)
      strobe(4,1) = (strobe(4,1)+strobe(4,5))/2.0
      strobe(4,5) =  strobe(4,1)

      do ipsf = 001, PSFSIZ
      do jpsf = 001, PSFSIZ
         ii = (ipsf)-(ipsf)/4*4
         jj = (jpsf)-(jpsf)/4*4
         if (ii.eq.0) ii = 4
         if (jj.eq.0) jj = 4
         psf_o(ipsf,jpsf) = psf_i(ipsf,jpsf)/(strobe(ii,jj)/strobe_bar)
         enddo
         enddo

      do ii = 1, 5
      do jj = 1, 5
         strobe_i(ii,jj) = strobe(ii,jj)/strobe_bar
         enddo
         enddo

      return
      end 


