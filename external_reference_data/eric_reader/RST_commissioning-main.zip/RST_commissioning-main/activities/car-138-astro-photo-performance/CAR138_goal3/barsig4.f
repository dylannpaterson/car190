
      subroutine barsig4(xlist,NTOT,bar,sig,NUSE)
      use array_size
      implicit none
 
      integer NTOT
      real*4  xlist(NTOT)
      real*4  bar
      real*4  sig
      integer NUSE
 
      integer n
      real*8  bsum, ssum
      integer nsum
      integer NIT
 
 
      bar = 0.0
      sig = 99999.99
      do NIT = 1, 8
         bsum = 0.
         ssum = 0.
         nsum = 0.
         do n = 1, NTOT
            if (abs(xlist(n)-bar).le.3*sig) then
               bsum = bsum + xlist(n)
               ssum = ssum + abs(xlist(n)-bar)
               nsum = nsum + 1
               endif
            enddo
         if (nsum.gt.0) bar = bsum / nsum
         if (nsum.gt.1) sig = ssum/(nsum-1)
         enddo
      NUSE = nsum
      if (nsum.le.1) sig = 9.999
 
      return
      end
 
