

      real function norm_psf(psf,psf_norm,RADIUS)
      use array_size
      implicit none

      real psf(PSFSIZ,PSFSIZ)
      real psf_norm(PSFSIZ,PSFSIZ)
      real RADIUS
      real*8 bar
      real   rpsf
      integer i, j
      real   norm
 
      real*8 strobe(5,5), strobbar, f
      real*8 strobf(5,5)
      integer ii,jj
 
      integer NIT
 
      bar = 0
      do i = 001, PSFSIZ
      do j = 001, PSFSIZ
         rpsf = sqrt((i-PSFMID*1.0)**2+(j-PSFMID*1.0)**2)/_PSFFAC_
         if (rpsf.lt.RADIUS) bar = bar + psf(i,j)
         enddo
         enddo
 
      norm = bar/_PSFFAC_/_PSFFAC_
 
      norm_psf = norm
 
      do i = 001, PSFSIZ
      do j = 001, PSFSIZ
         psf_norm(i,j) = psf(i,j)/norm
      enddo
      enddo
      
      return

      end
