
c------------------------------
c
c output a PSX to a fits file
c
      subroutine psx_writ101(psx,FILEI)
      use array_size
      implicit none
      real psx(101,101,_NPSFsX_,_NPSFsY_)
      character*300 FILEI
      real*4, allocatable, dimension(:,:) :: psfimg
      integer HX, HY
      integer ipsf, jpsf
      character*300 FILE
      integer i, j
 
      if (.not.allocated(psfimg))
     .     allocate(psfimg((_NPSFsX_*100+1),(_NPSFsY_*100+1)))
      psfimg = 0.0

      FILE = FILEI
 
      do HX = 1, _NPSFsX_
      do HY = 1, _NPSFsY_
         do ipsf = 1, 101
         do jpsf = 1, 101
            psfimg((HX-1)*(101-1)+ipsf,(HY-1)*(101-1)+jpsf) =
     .      psx(ipsf,jpsf,HX,HY)
            enddo
            enddo
         enddo
         enddo
 
         do i = 1, (_NPSFsX_*100+1)
            do j = 101, 101*(_NPSFsY_-1), (101-1)
               psfimg(i,j) = -0.0001
            enddo
         enddo
         do j = 1, (_NPSFsX_*100+1)
            do i = 101, 101*(_NPSFsY_-1), (101-1)
               psfimg(i,j) = -0.0001
            enddo
         enddo
         call writfits_r4_psf(FILE,psfimg,
     .        (_NPSFsX_*100+1),(_NPSFsY_*100+1))

      if (allocated(psfimg)) deallocate(psfimg)
 
      return
      end
