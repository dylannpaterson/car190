

c-----------------------------------------------
c
c this function will return the PSF intergerated
c out to a radius RMAX
c
c
      real function psf_rint(psf,RMAX)
      use array_size
      implicit none
 
      real psf(PSFSIZ,PSFSIZ)
      real RMAX
 
      integer ipsf, jpsf
      real    xpsf, ypsf, rpsf
      real*8  psum
 
      psum = 0.
      do ipsf = max(1,int(PSFMID-_PSFFAC_*int(RMAX+0.5))),
     .     min(PSFSIZ,int(PSFMID+_PSFFAC_*int(RMAX+0.5)))
      do jpsf = max(1,int(PSFMID-_PSFFAC_*int(RMAX+0.5))),
     .     min(PSFSIZ,int(PSFMID+_PSFFAC_*int(RMAX+0.5)))
         xpsf = (ipsf-PSFMID)/_PSFFAC_
         ypsf = (jpsf-PSFMID)/_PSFFAC_
         rpsf = sqrt(xpsf**2+ypsf**2)
         if (rpsf.lt.RMAX) psum = psum + psf(ipsf,jpsf)
         enddo
         enddo
 
      psf_rint = psum/_PSFFAC_/_PSFFAC_
      end
 
