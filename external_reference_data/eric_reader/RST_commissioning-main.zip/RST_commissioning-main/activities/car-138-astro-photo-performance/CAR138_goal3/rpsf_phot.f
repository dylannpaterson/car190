 
c---------------------------------------------
c
c this routine will return the fraction of
c light that should fall within a pixel offset
c by (dx,dy) with respect to a star which is
c represented by psf
c
      real function rpsf_phot(x,y,psf)
      use array_size
      implicit none
      real x, y
      real p
      real plin
      real psf(PSFSIZ,PSFSIZ)
 
 
      real    rx, ry
      integer ix, iy   !     3   4
      real    fx, fy   !    *1*  2
 
      real    dd
 
      real A1, B1, C1, D1, E1, F1, V1
      real A2, B2, C2, D2, E2, F2, V2
      real A3, B3, C3, D3, E3, F3, V3
      real A4, B4, C4, D4, E4, F4, V4
       
      rx = PSFMID + x*_PSFFAC_
      ry = PSFMID + y*_PSFFAC_
      ix = int(rx)
      iy = int(ry)
      fx = rx-ix
      fy = ry-iy
 
      dd = sqrt(x**2+y**2)
      rpsf_phot = 0.
      if (dd.gt.PSFSIZ/_PSFFAC_) return
 
! ML: Added 2018/05/24
      if (ix.lt.1.or.iy.lt.1) return
      if (ix.gt.PSFSIZ.or.iy.gt.PSFSIZ) return


      if (dd.gt.4.0.and.ix.lt.PSFSIZ.and.iy.lt.PSFSIZ) then
         rpsf_phot = (1-fx)*(1-fy)*psf(ix  ,iy  )
     .             + ( fx )*(1-fy)*psf(ix+1,iy  )
     .             + (1-fx)*( fy )*psf(ix  ,iy+1)
     .             + ( fx )*( fy )*psf(ix+1,iy+1)
 
         if (.not.(rpsf_phot.lt.1)) then
            print*,'rpsf NAN: ',rpsf_phot
            print*,'    dxdy: ',x,y
            print*,'      dd: ',dd
            print*,'    rxry: ',rx,ry
            print*,'    ixiy: ',ix,iy
            print*,'    fxfy: ',fx,fy
            print*,'          ',ix  ,iy  ,psf(ix  ,iy  )
            print*,'          ',ix+1,iy  ,psf(ix+1,iy  )
            print*,'          ',ix  ,iy+1,psf(ix  ,iy+1)
            print*,'          ',ix+1,iy+1,psf(ix+1,iy+1)
            stop
            endif
 
         return
         endif

       if (dd.gt.4.0.and.(ix.ge.PSFSIZ.or.iy.ge.PSFSIZ)) then



          
         rpsf_phot = (1-fx)*(1-fy)*psf(ix  ,iy  )
         if (ix.ge.PSFSIZ)
     .        rpsf_phot = rpsf_phot + ( fx )*(1-fy)*psf(ix  ,iy  )  ! Instead of (ix+1,iy)
         if (iy.ge.PSFSIZ)
     .        rpsf_phot = rpsf_phot + (1-fx)*( fy )*psf(ix  ,iy  )  ! Instead of (ix,iy+1)
         if (ix.ge.PSFSIZ.and.iy.lt.PSFSIZ) then                ! Instead of (ix+1,iy+1)
            rpsf_phot = rpsf_phot + ( fx )*( fy )*psf(ix  ,iy+1)
         else
            if (ix.lt.PSFSIZ.and.iy.ge.PSFSIZ) then                ! Instead of (ix+1,iy+1)
               rpsf_phot = rpsf_phot + ( fx )*( fy )*psf(ix+1,iy  )
            else
               rpsf_phot = rpsf_phot + ( fx )*( fy )*psf(ix  ,iy  )
            endif
         endif

         if (.not.(rpsf_phot.lt.1)) then
            print*,'rpsf NAN: ',rpsf_phot
            print*,'    dxdy: ',x,y
            print*,'      dd: ',dd
            print*,'    rxry: ',rx,ry
            print*,'    ixiy: ',ix,iy
            print*,'    fxfy: ',fx,fy
            print*,'          ',ix  ,iy  ,psf(ix  ,iy  )
            print*,'          ',ix+1,iy  ,psf(ix+1,iy  )
            print*,'          ',ix  ,iy+1,psf(ix  ,iy+1)
            print*,'          ',ix+1,iy+1,psf(ix+1,iy+1)
            stop
            endif
 
         return
         endif

 
      A1 =  psf(ix  ,iy  )
      B1 = (psf(ix+1,iy  )-psf(ix-1,iy  ))/2
      C1 = (psf(ix  ,iy+1)-psf(ix  ,iy-1))/2
      D1 = (psf(ix+1,iy  )+psf(ix-1,iy  )-2*A1)/2
      F1 = (psf(ix  ,iy+1)+psf(ix  ,iy-1)-2*A1)/2
      E1 = (psf(ix+1,iy+1)-A1)
 
      A2 =  psf(ix+1,iy  )
      B2 = (psf(ix+2,iy  )-psf(ix  ,iy  ))/2
      C2 = (psf(ix+1,iy+1)-psf(ix+1,iy-1))/2
      D2 = (psf(ix+2,iy  )+psf(ix  ,iy  )-2*A2)/2
      F2 = (psf(ix+1,iy+1)+psf(ix+1,iy-1)-2*A2)/2
      E2 =-(psf(ix  ,iy+1)-A2)
 
      A3 =  psf(ix  ,iy+1)
      B3 = (psf(ix+1,iy+1)-psf(ix-1,iy+1))/2
      C3 = (psf(ix  ,iy+2)-psf(ix  ,iy  ))/2
      D3 = (psf(ix+1,iy+1)+psf(ix-1,iy+1)-2*A3)/2
      F3 = (psf(ix  ,iy+2)+psf(ix  ,iy  )-2*A3)/2
      E3 =-(psf(ix+1,iy  )-A3)
 
      A4 =  psf(ix+1,iy+1)
      B4 = (psf(ix+2,iy+1)-psf(ix  ,iy+1))/2
      C4 = (psf(ix+1,iy+2)-psf(ix+1,iy  ))/2
      D4 = (psf(ix+2,iy+1)+psf(ix  ,iy+1)-2*A4)/2
      F4 = (psf(ix+1,iy+2)+psf(ix+1,iy  )-2*A4)/2
      E4 = (psf(ix  ,iy  )-A4)
 
 
      V1 = A1
     .   + B1*( fx )
     .   + C1*( fy )
     .   + D1*( fx )**2
     .   + E1*( fx )*( fy )
     .   + F1*( fy )**2
 
      V2 = A2
     .   + B2*(fx-1)
     .   + C2*( fy )
     .   + D2*(fx-1)**2
     .   + E2*(fx-1)*( fy )
     .   + F2*( fy )**2
 
      V3 = A3
     .   + B3*( fx )
     .   + C3*(fy-1)
     .   + D3*( fx )**2
     .   + E3*( fx )*(fy-1)
     .   + F3*(fy-1)**2
 
      V4 = A4
     .   + B4*(fx-1)
     .   + C4*(fy-1)
     .   + D4*(fx-1)**2
     .   + E4*(fx-1)*(fy-1)
     .   + F4*(fy-1)**2
 
 
 
      rpsf_phot = (1-fx)*(1-fy)*V1
     .          + ( fx )*(1-fy)*V2
     .          + (1-fx)*( fy )*V3
     .          + ( fx )*( fy )*V4
 
         if (.not.(rpsf_phot.gt.-1)) then
            print*,'rpsf NAN: ',rpsf_phot
            print*,'      dd: ',dd
            print*,'    dxdy: ',x,y
            print*,'    rxry: ',rx,ry
            print*,'    ixiy: ',ix,iy
            print*,'    fxfy: ',fx,fy
            print*,'          ',ix  ,iy  ,psf(ix  ,iy  )
            print*,'          ',ix+1,iy  ,psf(ix+1,iy  )
            print*,'          ',ix  ,iy+1,psf(ix  ,iy+1)
            print*,'          ',ix+1,iy+1,psf(ix+1,iy+1)
            stop
            endif
 
      return
      end

