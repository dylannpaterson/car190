 
c-----------------------------------------------------------------
c
c
c
      subroutine savefits_stdpsf101(FILEO,psfij_stdpsf)
      use array_size
      implicit none
 
      character*(*) FILEO
 
 
      integer nbyte0
      integer nbyteE
      integer nbyte1
      integer nbyte2
      integer nbper
      integer i,ios
 
      integer c1, c2, c3
 
      character*2880 buffc
      byte buffb(2880)
      equivalence (buffb,buffc)
 
      integer ii
      integer ifirst, i1, i2
      integer np1, np2, npt
 
      integer n, k
      character*80 FILEU
 
      integer today(3)
      integer now(3)
 
      byte b(4)
      real*4 r
      equivalence(r,b)
 
      integer q, npu, nbu
      integer NX, NY, NN
      integer ipsf, jpsf
 
      logical islinux
c
c----------------------------------------------
c
      character*80 FILEI_stdpsf
      integer      NNPSFs_stdpsf
      integer      NXPSFs_stdpsf
      integer      NYPSFs_stdpsf
      integer      ilist_stdpsf(10)
      integer      jlist_stdpsf(10)
      character*72 COMMENT1_stdpsf
      character*72 COMMENT2_stdpsf
      character*72 COMMENT3_stdpsf
      character*20 DATESTRING_stdpsf
      character*20 TIMESTRING_stdpsf
      real*4       psfij_stdpsf(101,101,_NPSFsX_,_NPSFsY_)
 
c
c----------------------------------------------
c
 
      FILEI_stdpsf = FILEO
 
      FILEU = FILEO
      do i = 75,2,-1
         if (FILEO(i:i+4).eq.'.fits') FILEU = FILEO(1:i+4)
         enddo
 
      open(10,file=FILEU,
     .     status='unknown',
     .     err   =900,
     .     recl  =2880,
     .     form  ='UNFORMATTED',
     .     access='DIRECT')
 
      do ii = 0001, 2880
         buffc(ii:ii) = ' '
         enddo

      NXPSFs_stdpsf = _NPSFsX_
      NYPSFs_stdpsf = _NPSFsY_
      NNPSFs_stdpsf = NXPSFs_stdpsf*NYPSFs_stdpsf

      ilist_stdpsf(1) = 1
      ilist_stdpsf(2) = 358
      ilist_stdpsf(3) = 1032
      jlist_stdpsf(1) = 1
      jlist_stdpsf(2) = 512
      jlist_stdpsf(3) = 1024
      
c
c we'll only use ONE header record, for simplicity ; it still
c conforms to the FITS standard, but I know to read only one
c
      call idate(today)
      call itime(now)
 
      write(DATESTRING_stdpsf,'(a1,i4.4,''-'',i2.2,''-'',i2.2,a1)')
     .                       '''',today(3), today(2), today(1),''''
      write(TIMESTRING_stdpsf,'(a1,i2.2,'':'',i2.2,'':'',i2.2,a1)')
     .                       '''',now(1),   now(2),   now(3),  ''''
 
      NNPSFs_stdpsf = NXPSFs_stdpsf*NYPSFs_stdpsf
 
      write(buffc( 0*80+1: 1*80),'(''SIMPLE  =                    T'')')
      write(buffc( 1*80+1: 2*80),'(''BITPIX  =                  -32'')')
      write(buffc( 2*80+1: 3*80),'(''NAXIS   = '',i20)') 3
      write(buffc( 3*80+1: 4*80),'(''NAXIS1  = '',i20)') 101
      write(buffc( 4*80+1: 5*80),'(''NAXIS2  = '',i20)') 101
      write(buffc( 5*80+1: 6*80),'(''NAXIS3  = '',i20)') NNPSFs_stdpsf
      write(buffc( 6*80+1: 7*80),'(''DATE    = '',a20)')
     .                               DATESTRING_stdpsf
      write(buffc( 7*80+1: 8*80),'(''TIME    = '',a20)')
     .                               TIMESTRING_stdpsf
      write(buffc( 8*80+1:09*80),'(''BSCALE  = '',f20.4)') 00001.00
      write(buffc( 9*80+1:10*80),'(''BZERO   = '',f20.4)') 00000.00
      write(buffc(10*80+1:11*80),'(''NXPSFs  = '',i20)') NXPSFs_stdpsf
      write(buffc(11*80+1:12*80),'(''NYPSFs  = '',i20)') NYPSFs_stdpsf

      k = 11+1
      write(buffc(k*80+1:k*80+80),'(''IPSFX'',i2.2,'' = '',i20)')
     .                                          1, 0
      k = 11+2
      write(buffc(k*80+1:k*80+80),'(''IPSFX'',i2.2,'' = '',i20)')
     .                                          2, 358
      k = 11+3
      write(buffc(k*80+1:k*80+80),'(''IPSFX'',i2.2,'' = '',i20)')
     .                                          3, 1032
      k = 11+4
      write(buffc(k*80+1:k*80+80),'(''JPSFY'',i2.2,'' = '',i20)')
     .                                          1, 0
      k = 11+5
      write(buffc(k*80+1:k*80+80),'(''JPSFY'',i2.2,'' = '',i20)')
     .                                          2, 512
      k = 11+6
      write(buffc(k*80+1:k*80+80),'(''JPSFY'',i2.2,'' = '',i20)')
     .                                          3, 1024


      k = 11+18
      write(buffc(k*80+1:k*80+80),'(''END                          '')')
      write(10,rec=1,iostat=ios) buffc
 
      ifirst = 2
      i = ifirst
 
      nbper  = 4*101*101*NNPSFs_stdpsf
      npt    =   101*101*NNPSFs_stdpsf
      nbyte1 = 1
      nbyte2 = nbper
      i1 = i + nbyte1/2880
      i2 = i + nbyte2/2880
 
      do i = i1, i2, 1
         nbyte0 = (i-ifirst)*2880+   1
         nbyteE = (i-ifirst)*2880+2880
         np1 = (nbyte0-nbyte1)/4 + 1
         np2 = (nbyteE-nbyte1)/4 + 1
         do q = 001, 720
            npu = np1+q-1
            nbu = (q-1)*4
            NN   = 1 + (npu-1)/101/101
            NY   = 1 + (NN-1)/NXPSFs_stdpsf
            NX   = NN - (NY-1)*NXPSFs_stdpsf
            jpsf = 1 +  (npu-1-(NN-1)*101*101)/101
c           ipsf = npu -     jpsf*101 - (NN-1)*101*101    ! old
            ipsf = npu - (jpsf-1)*101 - (NN-1)*101*101    ! fixed
            if (npu.ge.1.and.npu.le.npt)
     .          r = psfij_stdpsf(ipsf,jpsf,NX,NY)
            if (.not._LINUX_) stop 'must be LINUX now...'
            buffb(nbu+1) = b(4)
            buffb(nbu+2) = b(3)
            buffb(nbu+3) = b(2)
            buffb(nbu+4) = b(1)
            enddo
         write(10,rec=i,iostat=ios) buffc
         enddo
 
      close(10)
 
      return
 
  900 continue
      print*,' '
      print*,'ERROR ACCESSING FITS FILE IN savefits_stdpsf101(): '
      write(*,'('' FILEO: '',a80)') FILEO
      write(*,'('' FILEU: '',a80)') FILEU
      print*,' '
      stop
      end
 


