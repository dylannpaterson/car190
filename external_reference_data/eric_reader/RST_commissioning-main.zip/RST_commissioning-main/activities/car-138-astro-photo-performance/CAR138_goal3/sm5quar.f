
 
c------------------------------------
c
c
      subroutine sm5quar(r,s,NX,NY)
      use array_size
      implicit none
 
      integer NX, NY
      real r(NX,NY)
      real s(NX,NY)
 
      integer i, j
      integer iu, ju
      integer im, jm
 
      real dx, dy
      real A
 
      real AA_old( 5, 5)
      data AA_old / ! SUM:     1.0
     .      1.0408,  -2.0204,   1.9592,  -2.0204,   1.0408,
     .     -2.0204,  -0.4898,   5.0204,  -0.4898,  -2.0204,
     .      1.9592,   5.0204,  11.0408,   5.0204,   1.9592,
     .     -2.0204,  -0.4898,   5.0204,  -0.4898,  -2.0204,
     .      1.0408,  -2.0204,   1.9592,  -2.0204,   1.0408/
 
      real AA( 5, 5)
      data AA / ! SUM:     1.0
     .     0.000000,  0.307317,  -0.614634,   0.307317,   0.000000,
     .     0.307317, -2.458537,   4.302439,  -2.458537,   0.307317,
     .    -0.614634,  4.302439,  13.624390,   4.302439,  -0.614634,
     .     0.307317, -2.458537,   4.302439,  -2.458537,   0.307317,
     .     0.000000,  0.307317,  -0.614634,   0.307317,   0.000000/
 
 
      do i = 1, NX
      do j = 1, NY
         iu = max(min(i,NX-2),3)
         ju = max(min(j,NY-2),3)
         A = 0.
         do im = 1, 5
         do jm = 1, 5
           !A = A + AA(im,jm)*r(iu-3+im,ju-3+jm)/25
            A = A + AA(im,jm)*r(iu-3+im,ju-3+jm)/21
            enddo
            enddo
         dx = i-iu
         dy = j-ju
         s(i,j) = A
         enddo
         enddo
 
      return
      end
  
 
