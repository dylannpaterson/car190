 
c------------------------------------
c
c
      subroutine sm7quad(r,s,NX,NY)
      use array_size
      implicit none
 
      integer NX, NY
      real r(NX,NY)
      real s(NX,NY)
 
      integer i, j
      integer iu, ju
      integer im, jm
 
      real*8 A
      real AA(7,7)
 
      data AA / ! SUM:     49.0
     .-2.3333,-0.6667, 0.3333, 0.6667, 0.3333,-0.6667,-2.3333,
     .-0.6667, 1.0000, 2.0000, 2.3333, 2.0000, 1.0000,-0.6667,
     . 0.3333, 2.0000, 3.0000, 3.3333, 3.0000, 2.0000, 0.3333,
     . 0.6667, 2.3333, 3.3333, 3.6667, 3.3333, 2.3333, 0.6667,
     . 0.3333, 2.0000, 3.0000, 3.3333, 3.0000, 2.0000, 0.3333,
     .-0.6667, 1.0000, 2.0000, 2.3333, 2.0000, 1.0000,-0.6667,
     .-2.3333,-0.6667, 0.3333, 0.6667, 0.3333,-0.6667,-2.3333/
 
      do i = 1, NX
      do j = 1, NY
         A = 0.
         do im = 1, 7
         do jm = 1, 7
            iu = i + (im-4)
            ju = j + (jm-4)
            if (iu.ge.001.and.iu.le.NX.and.
     .          ju.ge.001.and.ju.le.NY) then
                A = A + AA(im,jm)*r(iu,ju)/49
                endif
            enddo
            enddo
         s(i,j) = A
         enddo
         enddo
 
      return
      end
 
