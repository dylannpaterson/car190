

      subroutine umode_output(UMODE,uhxhy)
      implicit none
 
      integer(kind=4) UMODE
      integer(kind=4) uhxhy(_NPSFsX_,_NPSFsY_)
      integer(kind=4) HX, HY
 
      if (UMODE.eq.1) then
         print*,'   ONE PSF:'
         print*,'+------------+'         
         print*,'| ---------- |'
         print*,'| ---------- |'
         print*,'| ----<>---- |'
         print*,'| ---------- |'
         print*,'| ---------- |'
         print*,'+------------+'         
      endif
      if (UMODE.eq.2) then
         print*,'  FOUR PSFs:'
         print*,'+------------+'         
         print*,'| <>------<> |'
         print*,'| ---------- |'
         print*,'| ---------- |'
         print*,'| ---------- |'
         print*,'| <>------<> |'
         print*,'+------------+'         
      endif
      if (UMODE.eq.3) then
         print*,'  NINE PSFs:'
         print*,'+------------+'         
         print*,'| <>--<>--<> |'
         print*,'| ---------- |'
         print*,'| <>--<>--<> |'
         print*,'| ---------- |'
         print*,'| <>--<>--<> |'
         print*,'+------------+'         
      endif
      if (UMODE.eq.4) then
         print*,'   25 PSFs:'
         print*,'+------------+'
         print*,'| <><><><><> |'
         print*,'| <><><><><> |'
         print*,'| <><><><><> |'
         print*,'| <><><><><> |'
         print*,'| <><><><><> |'
         print*,'+------------+'
      endif

      return
      end

