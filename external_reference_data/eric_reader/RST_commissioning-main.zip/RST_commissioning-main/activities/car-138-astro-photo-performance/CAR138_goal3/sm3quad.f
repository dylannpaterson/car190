
 
c-----------------------------------
c
c
      subroutine sm3quad(r,s,NX,NY)
      use array_size
      implicit none
 
      integer NX, NY
      real r(NX,NY)
      real s(NX,NY)
 
      integer i, j
      integer iu, ju
      integer im, jm
 
      real dx, dy
      real A, B, C, D, E, F
 
      real AA( 3, 3)
      data AA / ! SUM:     1.0
     .     -1.0000,   2.0000,  -1.0000,
     .      2.0000,   5.0000,   2.0000,
     .     -1.0000,   2.0000,  -1.0000/
 
      real BB( 3, 3)
      data BB / ! SUM:     0.0
     .     -1.5000,   0.0000,   1.5000,
     .     -1.5000,   0.0000,   1.5000,
     .     -1.5000,   0.0000,   1.5000/
 
      real CC( 3, 3)
      data CC / ! SUM:     0.0
     .     -1.5000,  -1.5000,  -1.5000,
     .      0.0000,   0.0000,   0.0000,
     .      1.5000,   1.5000,   1.5000/
 
      real DD( 3, 3)
      data DD / ! SUM:     0.0
     .      1.5000,  -3.0000,   1.5000,
     .      1.5000,  -3.0000,   1.5000,
     .      1.5000,  -3.0000,   1.5000/
 
      real EE( 3, 3)
      data EE / ! SUM:     0.0
     .      2.2500,   0.0000,  -2.2500,
     .      0.0000,   0.0000,   0.0000,
     .     -2.2500,   0.0000,   2.2500/
 
      real FF( 3, 3)
      data FF / ! SUM:     0.0
     .      1.5000,   1.5000,   1.5000,
     .     -3.0000,  -3.0000,  -3.0000,
     .      1.5000,   1.5000,   1.5000/
 
 
      do i = 1, NX
      do j = 1, NY
         iu = max(min(i,NX-1),2)
         ju = max(min(j,NY-1),2)
         A = 0.
         B = 0.
         C = 0.
         D = 0.
         E = 0.
         F = 0.
         do im = 1, 3
         do jm = 1, 3
            A = A + AA(im,jm)*r(iu-2+im,ju-2+jm)/09
            B = B + BB(im,jm)*r(iu-2+im,ju-2+jm)/09
            C = C + CC(im,jm)*r(iu-2+im,ju-2+jm)/09
            D = D + DD(im,jm)*r(iu-2+im,ju-2+jm)/09
            E = E + EE(im,jm)*r(iu-2+im,ju-2+jm)/09
            F = F + FF(im,jm)*r(iu-2+im,ju-2+jm)/09
            enddo
            enddo
         dx = i-iu
         dy = j-ju
         s(i,j) = A +
     .            B*dx    + C*dy    +
     .            D*dx**2 + E*dx*dy + F*dy**2
         enddo
         enddo
 
      return
      end
 



