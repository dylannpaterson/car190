
 
c--------------------------------------------------
c
c
      subroutine rcen_psf(psfn,psfc,rmax,
     .     rcnx_val,rcny_val,PSFSIZ,PSFMID)
      implicit none


      integer PSFSIZ,PSFMID
      real psfn(PSFSIZ,PSFSIZ)
      real psfc(PSFSIZ,PSFSIZ)
      real rmax
 
      real rcnx_val
      real rcny_val
 
      real psfu(PSFSIZ,PSFSIZ)
      real psfd(PSFSIZ,PSFSIZ)
 
      real dx, dy
      real xpsf,ypsf, rpsf
      real ddx,ddy
 
      DOUBLE PRECISION etot
      DOUBLE PRECISION emin
      real   xmin, ymin
 
      integer(kind=4) idx, idy
      integer(kind=4) ipsf,jpsf
      real    rpsf_phot
      integer(kind=4) ii,jj
 
      emin = 9e9
      do idx = -100, 100, 001
      do idy = -100, 100, 001
         dx = idx*0.001
         dy = idy*0.001
         do ipsf = PSFMID-10, PSFMID+10
         do jpsf = PSFMID-10, PSFMID+10
            xpsf = (ipsf-PSFMID)/_PSFFAC_
            ypsf = (jpsf-PSFMID)/_PSFFAC_
            ddx = xpsf+dx
            ddy = ypsf+dy
            psfu(ipsf,jpsf) = rpsf_phot(ddx,ddy,psfn)
            enddo
            enddo
         etot = 0.
         do ii = -10, 10
         do jj = -10, 10
            xpsf = ii/_PSFFAC_
            ypsf = jj/_PSFFAC_
            rpsf = sqrt(xpsf**2+ypsf**2)
            if (rpsf.le.rmax) then
               etot = etot + abs(psfu(PSFMID+ii,PSFMID+jj)
     .                          -psfu(PSFMID-ii,PSFMID-jj))
               endif
            enddo
            enddo
         if (etot.lt.emin) then
            emin = etot
            xmin = dx
            ymin = dy
            endif
         enddo
         enddo
 
 
      rcnx_val = xmin
      rcny_val = ymin
      do ipsf = 001, PSFSIZ
      do jpsf = 001, PSFSIZ
         xpsf = (ipsf-PSFMID)/_PSFFAC_
         ypsf = (jpsf-PSFMID)/_PSFFAC_
         ddx = xpsf+xmin
         ddy = ypsf+ymin
         psfc(ipsf,jpsf) = rpsf_phot(ddx,ddy,psfn)
         psfd(ipsf,jpsf) = psfc(ipsf,jpsf)-psfn(ipsf,jpsf)
         enddo
         enddo
 
      if (.true.) return
 
      print*,' xmin: ',xmin
      print*,' ymin: ',ymin
 
      return
      end
 


