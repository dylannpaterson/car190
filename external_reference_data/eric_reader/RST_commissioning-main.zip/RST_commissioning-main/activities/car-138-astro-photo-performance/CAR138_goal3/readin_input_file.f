


      subroutine readin_input_file(INPUT,NIMs,ITERSUB,ITERTOT,NCPU,
     .     BOXFIT,RADFIT,RECENRAD,PSFMID,
     .     PSFFILE,
     .     MMAX,MMIN,QCUT,MCORE,
     .     DOPSF,DOSAMP,DOPHOT,
     .     FMIN,HMIN,SUBIMG,SKYSUB,UMODEMAX,TESTMODE,STROBEFLAG,
     .     MINIT,FIRSTIMAGE,NSTs,STDPSFFILE,IMAGE,XYM)
      implicit none
      character(len=300) INPUT,PSFFILE,STDPSFFILE
      character(len=600) STRING,STRING2
      integer(kind=4) NIMs,LINES,NSTs,ITERSUB,ITERTOT,NCPU
      integer(kind=4) PSFSIZ,BOXFIT,PSFMID,HMIN,UMODEMAX
      character(len=200) IMAGE(NIMs),XYM(NIMs)
      real(kind=4) RADFIT,RECENRAD,MMAX,MMIN,QCUT,MCORE
      real(kind=4) FMIN,xr,yr,mr      
      logical DOPSF,DOSAMP,DOPHOT,SUBIMG,SKYSUB,TESTMODE
      logical STROBEFLAG,MINIT,FIRSTIMAGE
      integer(kind=4) i,j,stat2,stat

      print*,' '
      write(*,'(i4.4,'' LINES FOUND'')') NIMs
      print*,''
      LINEs = 0
      NSTs = 0

      open(10,file=INPUT,status='old')
      do
         read(10,'(a600)',IOSTAT=stat) STRING
         if (IS_IOSTAT_END(stat)) exit
         if (STRING(1:1).ne.'#') then

            if (STRING(1:5).eq.'ITER ') then
               read(STRING(5:300),*) ITERSUB
               if (ITERSUB.lt.0) then
                  ITERSUB = -ITERSUB
                  ITERTOT = abs(ITERSUB)
               else if (ITERSUB.gt.0) then
                  ITERTOT = 2*ITERSUB
               else
                  print*,''
                  print*,'STOP! NO ITERATIONS...???'
                  print*,''
                  stop
               endif
            endif
            if (STRING(1:4).eq.'NCPU') then
               read(STRING(5:300),*) NCPU
            endif
            if (STRING(1:7).eq.'PSFSIZE') then
               read(STRING(8:300),*) PSFSIZ               
               if (PSFSIZ.lt.50.or.PSFSIZ.gt.1001) then
                  print*,''
                  print*,'STOP! PSF SIZE TOO SMALL OR LARGE'
                  print*,''
                  stop
               endif
            endif
            if (STRING(1:6).eq.'BOXFIT') then
               read(STRING(7:300),*) BOXFIT
               if (BOXFIT.lt.3.or.BOXFIT.gt.15) then
                  print*,''
                  print*,'STOP! BOXFIT TOO SMALL OR LARGE'
                  print*,''
                  stop
               endif
            endif
            if (STRING(1:6).eq.'RADFIT') then
               read(STRING(7:300),*) RADFIT
               if (RADFIT.lt.1.0.or.RADFIT.gt.10.0) then
                  print*,''
                  print*,'STOP! RADFIT TOO SMALL OR LARGE'
                  print*,''
                  stop
               endif
            endif
            if (STRING(1:8).eq.'RECENRAD') then
               read(STRING(9:300),*) RECENRAD
               if (RECENRAD.lt.0.0.or.RECENRAD.gt.20.0) then
                  print*,''
                  print*,'STOP! RECENRAD TOO SMALL OR LARGE'
                  print*,''
                  stop
               endif
            endif
            if (STRING(1:7).eq.'PSFCENT') then
               read(STRING(8:300),*) PSFMID
            endif
            if (STRING(1:4).eq.'NAME') then
               read(STRING(5:300),*) PSFFILE
               STRING = PSFFILE
               j = 1
               do i = 1, 300
                  if (STRING(i:i).eq.' ') then
                     j = i-1
                     exit
                  endif
               enddo
               write(PSFFILE,'(a,''_LIB.fits'')')
     .              STRING(1:j)
               write(STDPSFFILE,'(a,''_STD.fits'')')
     .              STRING(1:j)
            endif
            if (STRING(1:4).eq.'MMAX') then
               read(STRING(5:300),*) MMAX
            endif
            if (STRING(1:4).eq.'MMIN') then
               read(STRING(5:300),*) MMIN
            endif
            if (STRING(1:4).eq.'QCUT') then
               read(STRING(5:300),*) QCUT
            endif
            if (STRING(1:5).eq.'MCORE') then
               read(STRING(6:300),*) MCORE
            endif
            if (STRING(1:5).eq.'DOPSF') then
               read(STRING(6:300),*) STRING2
               DOPSF = .false.
               if (STRING2(1:1).eq.'T'.or.STRING2(1:1).eq.'t') 
     .              DOPSF = .true.
            endif
            if (STRING(1:6).eq.'DOSAMP') then
               read(STRING(7:300),*) STRING2
               DOSAMP = .false.
               if (STRING2(1:1).eq.'T'.or.STRING2(1:1).eq.'t') 
     .              DOSAMP = .true.
            endif
            if (STRING(1:6).eq.'DOPHOT') then
               read(STRING(7:300),*) STRING2
               DOPHOT = .false.
               if (STRING2(1:1).eq.'T'.or.STRING2(1:1).eq.'t') 
     .              DOPHOT = .true.
            endif
            if (STRING(1:4).eq.'FMIN') then
               read(STRING(5:300),*) FMIN
               if (FMIN.le.0.) then
                  print*,''
                  print*,'STOP! FMIN MUST BE A POSITIVE VALUE'
                  print*,''
                  stop
               endif
            endif
            if (STRING(1:4).eq.'HMIN') then
               read(STRING(5:300),*) HMIN
               if (HMIN.le.0.) then
                  print*,''
                  print*,'STOP! HMIN MUST BE A POSITIVE VALUE'
                  print*,''
                  stop
               endif
            endif
            if (STRING(1:5).eq.'DOSUB') then
               read(STRING(6:300),*) STRING2
               SUBIMG = .false.
               if (STRING2(1:1).eq.'T'.or.STRING2(1:1).eq.'t') 
     .              SUBIMG = .true.
            endif
            if (STRING(1:6).eq.'SKYSUB') then
               read(STRING(7:300),*) STRING2
               SKYSUB = .false.
               if (STRING2(1:1).eq.'T'.or.STRING2(1:1).eq.'t') 
     .              SKYSUB = .true.
            endif
            if (STRING(1:8).eq.'UMODEMAX') then
               read(STRING(9:300),*) UMODEMAX
               if (UMODEMAX.lt.1.or.UMODEMAX.gt.4) then
                  print*,''
                  print*,'STOP! UMODE MUST BE BETWEEN 1 and 4'
                  print*,'UMODEMAX INPUT:',UMODEMAX
                  stop
               endif
            endif
            if (STRING(1:8).eq.'TESTMODE') then
               read(STRING(9:300),*) STRING2
               if (STRING2(1:1).eq.'T'.or.STRING2(1:1).eq.'t'.or.
     .             STRING2(1:4).eq.'true'.or.
     .             STRING2(1:4).eq.'TRUE'.or.
     .             STRING2(1:4).eq.'True') TESTMODE = .true.
            endif
            if (STRING(1:6).eq.'STROBE') then
               read(STRING(7:300),*) STRING2
               if (STRING2(1:1).eq.'T'.or.STRING2(1:1).eq.'t'.or.
     .             STRING2(1:4).eq.'true'.or.
     .             STRING2(1:4).eq.'TRUE'.or.
     .             STRING2(1:4).eq.'True') STROBEFLAG = .true.
               if (STRING2(1:1).eq.'F'.or.STRING2(1:1).eq.'f'.or.
     .             STRING2(1:5).eq.'false'.or.
     .             STRING2(1:5).eq.'FALSE'.or.
     .             STRING2(1:5).eq.'False') STROBEFLAG = .false.
            endif
            if (STRING(1:5).eq.'MINIT') then
               read(STRING(6:300),*) STRING2
               if (STRING2(1:1).eq.'T'.or.STRING2(1:1).eq.'t'.or.
     .             STRING2(1:4).eq.'true'.or.
     .             STRING2(1:4).eq.'TRUE'.or.
     .             STRING2(1:4).eq.'True') MINIT = .true.
               if (STRING2(1:1).eq.'F'.or.STRING2(1:1).eq.'f'.or.
     .             STRING2(1:5).eq.'false'.or.
     .             STRING2(1:5).eq.'FALSE'.or.
     .             STRING2(1:5).eq.'False') MINIT = .false.
            endif



            if (STRING(1:3).eq.'NIM') then
               if (FIRSTIMAGE) then

!     We should have already read everything... Check this before
!     starting to open/close files...
                  if (abs(nint(PSFSIZ/2.)-PSFMID).gt.10) then
                     print*,''
                     print*,'STOP! THE CENTER OF THE PSF IS TOO FAR ',
     .                    'FROM THE EXPECTED CENTER OF THE PSF'
                     print*,''
                     stop
                  endif
                  
                  if (MMAX.ge.MMIN) then
                     print*,''
                     print*,'STOP! MMAX MUST BE GREATER THAN MMIN'
                     print*,''
                     stop
                  endif

                  FIRSTIMAGE = .false.
               endif !firstimage
               
               LINEs = LINEs + 1
               read(STRING(4:600),*) IMAGE(LINEs), XYM(LINEs)
               if (DOPSF) then
                  print*, 'reading ',XYM(LINEs)
                  open(20, file=XYM(LINEs), status='old')
                  do
                     read(20,'(a300)',IOSTAT=stat2) STRING
                     if (IS_IOSTAT_END(stat2)) exit
                     if (STRING(1:1).ne.'#') then
                        read(STRING,*) xr, yr, mr
                        if (MINIT) then
                           if (mr.le.MMIN.and.mr.ge.MMAX)
     .                          NSTs = NSTs + 1
                        else
                           NSTs = NSTs + 1
                        endif
                     endif
                  enddo
                  close(20)
               endif
            endif
         endif
      enddo
      close(10)

      return
      end

      
                                  
 
