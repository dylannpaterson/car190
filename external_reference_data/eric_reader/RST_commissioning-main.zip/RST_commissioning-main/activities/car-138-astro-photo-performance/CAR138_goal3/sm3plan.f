
c-----------------------------------
c
c
      subroutine sm3plan(r,s,NX,NY)
      use array_size
      implicit none
 
      integer NX, NY
      real r(NX,NY)
      real s(NX,NY)
 
      integer i, j
      integer im, jm
 
      real A
 
      do i = 1, NX
      do j = 1, NY
         A = 0.
         do im = max(i-1,1), min(i+1,NX)
         do jm = max(j-1,1), min(j+1,NX)
            A = A + r(im,jm)/09
            enddo
            enddo
         s(i,j) = A
         enddo
         enddo
 
      return
      end
 
