import os
import argparse
import pickle
import sys
import time
import glob
import traceback
import s3fs
from functools import partial
from concurrent.futures import ProcessPoolExecutor, as_completed

# Set environment variables before heavy imports if possible
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["CRDS_PATH"]       = os.path.expanduser("~/.crds_cache")
os.environ["CRDS_SERVER_URL"] = "https://roman-crds.stsci.edu"

import numpy as np
import galsim 
from astropy.coordinates import SkyCoord
from astropy import units as u
from astropy.wcs import WCS
from astropy.io import ascii
from romanisim.models import wcs
from romanisim.ris_make_utils import set_metadata

import touchstone_sim

def parse_args():
    parser = argparse.ArgumentParser(description="Generate ISIM catalogs for Roman Space Telescope simulations.")
    
    # Required Core Arguments
    parser.add_argument("--sed-path", type=str, required=True, help="Path to the SED data directory.")
    parser.add_argument("--ra", type=float, required=True, help="Right Ascension of the target field center in degrees.")
    parser.add_argument("--dec", type=float, required=True, help="Declination of the target field center in degrees.")
    
    # Response Function Arguments
    parser.add_argument("--response-type", type=str, choices=["flat", "tapered", "custom"], default="flat", 
                        help="Choose 'flat' (all ones), 'tapered' (the default interpolation), or 'custom'.")
    parser.add_argument("--response-file", type=str, default=None, 
                        help="Path to a custom response .npy file if --response-type is 'custom'.")
    parser.add_argument("--run-type", type=str, default=None, 
                        help="Output filename tag. Defaults to 'nominal' if response is flat, else 'model'.")
    
    # Paths and Directories
    parser.add_argument("--cache-dir", type=str, default="Kepler_gaia_cache", help="Directory to save/load Gaia cache.")
    parser.add_argument("--out-dir", type=str, default="kepler_sca_cats", help="Directory to save ISIM catalogs.")
    parser.add_argument("--throughputs-dir", type=str, default="throughputs", help="Directory containing throughput curves.")
    
    # Physics and Math Constants
    parser.add_argument("--max-sep", type=float, default=1.0, help="Maximum separation for catalog matching in degrees.")
    parser.add_argument("--lam-blue", type=float, default=8270.0, help="Blue wavelength cutoff for response interpolation.")
    parser.add_argument("--lam-red", type=float, default=12920.0, help="Red wavelength cutoff for response interpolation.")
    
    # Execution parameters
    parser.add_argument("--workers", type=int, default=2, help="Number of parallel workers for phase 2.")
    
    return parser.parse_args()


def get_bounds_wcs(detector, coord):
    meta = set_metadata(date='2026-01-01T00:00:00', bandpass='F106', sca=detector)
    wcs.fill_in_parameters(meta, coord, pa_aper=0, boresight=False)
    blank_wcs = wcs.get_wcs(meta, usecrds=True)
    pixel_corners = np.array([[   0,    0],
                              [4087,    0],
                              [4087, 4087],
                              [   0, 4087]])
    ra_corners, dec_corners = blank_wcs.xyToradec(pixel_corners[:, 0], pixel_corners[:, 1], units=galsim.degrees)
    ra_min, ra_max = np.min(ra_corners), np.max(ra_corners)
    dec_min, dec_max = np.min(dec_corners), np.max(dec_corners)
    return ra_min, ra_max, dec_min, dec_max, blank_wcs

def get_sed_coords(sed_path):
    # added 8/6/26: adds ability for user to pass s3 bucket in
    if sed_path.startswith("s3://"):
        # Use s3fs to list files if user passes in S3 URI
        fs = s3fs.S3FileSystem()
        full_paths = fs.ls(sed_path)
        filename_list = np.array([os.path.basename(f) for f in full_paths if f.endswith('.h5')])
    else:
        # Normal OS logic for local directories
        filename_list = np.array([f for f in os.listdir(sed_path) if os.path.isfile(os.path.join(sed_path, f))])
    
    sed_radec = []
    for filename in filename_list:
        ra = float(filename.split('_')[-2][2:])
        dec = float(filename.split('_')[-1][3:-3])
        sed_radec.append([ra,dec])

    sed_radec = np.array(sed_radec)
    sed_coords = SkyCoord(ra=sed_radec[:,0] * u.deg, dec=sed_radec[:,1] * u.deg)
    return sed_coords, filename_list

def generate_response(wavelengths, args):
    """Factory function to handle different response configurations."""
    if args.response_type == "flat":
        return np.ones_like(wavelengths, dtype=float)
        
    elif args.response_type == "tapered":
        response = np.ones_like(wavelengths, dtype=float)
        m_mid = (wavelengths >= args.lam_blue) & (wavelengths <= args.lam_red)
        response[m_mid] = np.interp(
            wavelengths[m_mid],
            [args.lam_blue, args.lam_red],
            [0.97, 1.03]
        )
        return response
        
    elif args.response_type == "custom":
        if args.response_file is None or not os.path.exists(args.response_file):
            raise FileNotFoundError("You must provide a valid --response-file path when using 'custom' response type.")
        
        # Adjust this loading logic based on how custom files are structured
        custom_data = np.load(args.response_file)
        
        # Example of applying an external array via interpolation:
        custom_wl = np.load("measured_response_wl_um.npy") * 10000.0
        return np.interp(wavelengths, custom_wl, custom_data, left=1.0, right=1.0)
        
        #return custom_data

    else:
        raise ValueError(f"Unknown response type: {args.response_type}")

def phase1(ra, dec, cache_dir):
    os.makedirs(cache_dir, exist_ok=True)
    coord = SkyCoord(ra * u.deg, dec * u.deg)
    
    #for detector in range(1,19):
    for detector in [10]:
        cache_path = os.path.join(cache_dir, f'cache_SCA{detector:02d}.ecsv')
        if os.path.exists(cache_path):
            print(f"[Gaia] SCA{detector:02d}: cache exists, skipping.", flush=True)
            continue
        
        ra_min, ra_max, dec_min, dec_max, blank_wcs = get_bounds_wcs(detector, coord)
        result = touchstone_sim.get_gaia_cat(ra_min, ra_max, dec_min, dec_max)
        result.write(cache_path, overwrite=True)
        print(f"[Gaia] SCA{detector:02d}: cache updated.", flush=True)

def build_isim_cat(detector, sed_coords, filename_list, args):
    cache_path = os.path.join(args.cache_dir, f'cache_SCA{detector:02d}.ecsv')
    result = ascii.read(cache_path)
    print(f"SCA{detector:02d} columns:", result.keys())
    
    coord = SkyCoord(args.ra * u.deg, args.dec * u.deg)
    blank_wcs = get_bounds_wcs(detector, coord)[4]
    
    gaia_coords = SkyCoord(ra=result['ra'], dec=result['dec'])
    idx, d2d, d3d = gaia_coords.match_to_catalog_sky(sed_coords)
    
    sep_constraint = d2d < (args.max_sep * u.deg)
    matched_sample = result[sep_constraint]
    matched_catalog_data = sed_coords[idx[sep_constraint]]
    
    # Apply modular response function
    wavelengths = np.linspace(4500, 25000, 15000)
    response = generate_response(wavelengths, args)
    dummy_model = np.column_stack((wavelengths, response))

    # added 8/6/26: adds if else statement to handle s3 paths
    if args.sed_path.startswith("s3://"):
        base_path = args.sed_path if args.sed_path.endswith('/') else args.sed_path + '/'
        matched_sed_paths = np.array([f"{base_path}{f}" for f in filename_list[idx[sep_constraint]]])
    else:
        matched_sed_paths = np.array([os.path.join(args.sed_path, f) for f in filename_list[idx[sep_constraint]]])
    
    throughput_curve_paths = glob.glob(os.path.join(args.throughputs_dir, "*"))
    path = next((i for i in throughput_curve_paths if f"SCA{detector:02d}" in i), None)
    
    throughput_curve = ascii.read(path, format='basic', delimiter=',', comment='#')
    throughput_wave = throughput_curve['Wave'] * u.um    
    abmag_sens = ascii.read('AB_mag_limiting_sensitivity.ecsv', format='basic', delimiter=',', comment='#')
    
    cat = touchstone_sim.generate_isim_cat(result, sep_constraint, gaia_coords, blank_wcs, matched_sed_paths, dummy_model, throughput_curve, abmag_sens)
    
    # Determine filename tag
    if args.run_type is None:
        run_tag = "nominal" if args.response_type == "flat" else "model"
    else:
        run_tag = args.run_type
        
    out_path = os.path.join(args.out_dir, f'SCA{detector:02d}cat_{run_tag}.ecsv')
    cat.write(out_path, overwrite=True)

    return detector, len(matched_sample), out_path

def phase2(args):
    os.makedirs(args.out_dir, exist_ok=True)
    sed_coords, filename_list = get_sed_coords(args.sed_path)
    
    worker = partial(build_isim_cat, 
                     sed_coords=sed_coords, 
                     filename_list=filename_list,
                     args=args)
                     
    results, failures = [], []
    with ProcessPoolExecutor(max_workers=args.workers) as ex:
        #futures = {ex.submit(worker, det): det for det in range(1,19)}
        futures = {ex.submit(worker, det): det for det in [10]}
        for fut in as_completed(futures):
            det = futures[fut]
            try:
                d, n, path = fut.result()
                results.append(d)
            except Exception as e:
                failures.append(det)
                print(f"SCA{det:02d} failed: {e}")
                
    print(f"{len(results)} successful, {len(failures)} failed")

def main():
    args = parse_args()
    phase1(args.ra, args.dec, args.cache_dir)
    phase2(args)

if __name__ == "__main__":
    main()
