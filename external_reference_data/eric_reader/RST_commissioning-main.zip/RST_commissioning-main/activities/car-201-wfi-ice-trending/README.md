# Python notebooks and scripts for CAR 201 Photometry Pipeline

**Notes**:
- Run in environment with Roman I-Sim and roman_disperser installed
- Ensure your `ROMAN_DISPERSER_DATA` environment variable is set and the reference data has been hydrated (via `roman-disperser-hydrate`).
- Change specific mentions of SED paths, configuration files, and save filenames as needed for your specific run (e.g., changing filters or epochs).

**General usage: Flight Data Workflow**  \
To process real L2 commissioning data from MAST, subsequent degraded epochs, photometry, and color anomaly analysis:

1. **Download Data from MAST** \
    Use `astroquery.mast` in Jupyter enviornment to query specific CAR Program ID (e.g., 1043) for specific dithers and `WFI_IMAGE` exposures. Download the files locally (e.g., to `car201_pass1_dither3_full_data`)
    
2. **Generate Astrometric Alignment** \
    To correct pointing offsets, isolate one filter (e.g., F087) for all SCAs and run David Rubin's `match_roman_gaia.py` script to generate sub-pixel affine transformation matricies. Run the following in the terminal:

`mkdir car201_pass1_dither3_alignment_images`

`find car201_pass1_dither3_full_data -name "*_f087_cal.asdf" -exec cp {} car201_pass1_dither3_alignment_images/ \;`

`python match_roman_gaia.py car201_pass1_dither3_alignment_images --output-dir car201_pass1_dither3_aligned`


3. **Perform Forced Photometry** \
   Run the `run_photometry_pipeline()` function in `car201_photometry_pipelineV3.ipynb` on the full dataset. Pass the alignment directory (`affine_dir="car201_pass1_dither3_aligned"`) and master Gaia cache. The pipeline will align the catalogs, extract official L2 DQ flags (dropping saturated cores), and calculate true propagated photometric errors (Poisson + Read Noise).

- **Output**: A master catalog (`car201_master_epoch0.parquet`) containing the photometry for all SCAs and filters.

4. **Color Anomaly Analysis** \
   Run `Color_anomalyV3.ipynb` setting `has_truth_catalog=False`. This script will filter for valid stars using empirical error cuts (SNR > 10) and DQ flags, then run Bayesian MCMC and Orthogonal Distance Regression (ODR) to fit ice degradation across epochs.
   
**General Usage: Simulated Data Workflow** : \
(For testing theoretical optical physics and pipeline robustness)

1. **Generate Input Catalogs** \
    Run `generate_isim_cats.py` pointed at Kepler field SEDs in the S3 bucket to create nominal `.ecsv` catalogs.
   
2. **Generate Simulated Images** \
    Run `kepler_sim.ipynb` using `touchstone_sim` to generate standard noisy L2 `.asdf` images or Level 0 idealized (noiseless) images.
   
3. **Apply Degraded Models** \
   Run `apply_ice_model.py` to map target ice transmission curves (e.g., 60nm) onto clean SEDs to simulate future epochs.
   
4. Process through the Photometry and Anomaly pipeline steps above (setting `has_truth_catalog=True` to overlay the pure SED physics as a green baseline).

**File descriptions**:
- `generate_isim_cats.py`: Command line operated script for generating object catalogs (one for each SCA) given a path of SEDs and pointing coordinates. Cross-matches with Gaia sources to obtain stellar parameters and caches the Gaia catalog locally.
- `kepler_sim.ipynb`: Notebook for executing `romanisim` to generate the simulated images of all 18 SCAs with the detector pointing at the Kepler field.
- `car201_photometry_pipelineV3.ipynb`:  Notebook for performing forced aperture photometry across simulated or real MAST image datasets. It applies affine transformations and compiles multi-band Parquet catalogs with propagated L2 DQ flags and true photometric errors.
- `Color_anomalyV3.ipynb`: Notebook for calculating color anomalies between epochs, performing ODR and Bayesian MCMC fits with true photometric errors, and generating statistical corner plots and binned residual plots to evaluate model selection (Linear vs. Parabolic) via BIC scores.
