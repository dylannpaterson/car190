import os
import sys
import importlib.util
import s3fs

import asdf
from astroquery.gaia import Gaia

# when gaia is down:
# from astroquery.utils.tap.core import TapPlus

# vizier_tap = TapPlus(url="https://tapvizier.cds.unistra.fr/TAPVizieR/tap")

from astropy.coordinates import SkyCoord
from astropy.time import Time
from astropy.table import Table, vstack
from astropy import units as u
from astropy.visualization import simple_norm
from astropy.wcs import WCS
from astropy.io import ascii
import copy
import galsim
import importlib
import matplotlib.pyplot as plt
import numpy as np
import os
import roman_datamodels as rdm
from romanisim import gaia, catalog, log, persistence, ris_make_utils as ris, image as risim
from romanisim import bandpass
from romanisim.models import wcs as rwcs
import romanisim.models.parameters as parameters
from romanisim.image import inject_sources_into_l2
import stpsf
import pysiaf
from dataclasses import dataclass
from typing import Union
import pandas as pd
import h5py
import glob

def run_romanisim(catalog, ra=80.0, dec=30.0, obs_date='2026-6-2T00:00:00',
                  sca=1, expnum=1, optical_element='F106',
                  ma_table_number=1006, level=2, filename='test', seed=5346):

    cal_level = 'cal' if level == 2 else 'uncal'
    filename = f'{filename}_{expnum:04d}_wfi{sca:02d}_{optical_element.lower()}_{cal_level}.asdf'

    # Set reference files to None for CRDS
    for k in parameters.reference_data:
        parameters.reference_data[k] = None

    # Set Galsim RNG object
    rng = galsim.UniformDeviate(seed)

    # Set default persistance information
    persist = persistence.Persistence()

    # Set metadata
    metadata = ris.set_metadata(date=obs_date, bandpass=optical_element, sca=sca,
                                ma_table_number=ma_table_number, usecrds=True)

    # Update the WCS info
    rwcs.fill_in_parameters(metadata, SkyCoord(ra, dec, unit='deg', frame='icrs'),
                           boresight=False, pa_aper=0.0)

    # Run the simulation using metadata value without saving any files
    im, extras = risim.simulate(metadata, catalog, usecrds=True,
                                psftype='stpsf', level=level,
                                persistence=persist, rng=rng
                                )

    # Since we are using this function to generate several files,
    # we will save the files to disk.
    im.meta.filename = filename
    af = asdf.AsdfFile()
    af.tree = {'roman': im}
    af.write_to(filename)

    # Clean up the memory
    del im, extras


def get_gaia_cat(ra_min,ra_max,dec_min,dec_max):
    #Get GAIA data in the bounds
    query = f"""
        SELECT designation, ra, dec, teff_gspphot, logg_gspphot, mh_gspphot, bp_rp, ag_gspphot, parallax,ebpminrp_gspphot
        FROM gaiadr3.gaia_source 
        WHERE ra BETWEEN {ra_min} AND {ra_max}
            AND dec BETWEEN {dec_min} AND {dec_max} 
        """
    
    #query = f"""
    #    SELECT DR3Name, RA_ICRS, DE_ICRS, Teff, logg, "[Fe/H]", "BP-RP", AG, E(BP-RP), Plx
    #    FROM "I/355/gaiadr3"
    #    WHERE RA_ICRS BETWEEN {ra_min} AND {ra_max}
    #        AND DE_ICRS BETWEEN {dec_min} AND {dec_max} 
    #   """
    
    #print("Launching async VizieR Gaia query...")
    print("Launching async Gaia query...")
    #job = vizier_tap.launch_job_async(query)
    job = Gaia.launch_job_async(query)

    result = job.get_results()
    print(f"Query successful! Retrieved {len(result)} sources.")
    
    
    return result


def sed_to_mag(wave, flux, throughput_curve, abmag_sens, filter_name):
    abmag_limit = abmag_sens[abmag_sens['filter'] == filter_name]['fifty_seven_sec_point'][0]
    throughput_transmission = throughput_curve[filter_name]
    throughput_wave = throughput_curve['Wave'] * u.um
    eff_area = np.interp(wave.to(u.Angstrom), 
                     throughput_wave.to(u.Angstrom), throughput_transmission, left=0.0, right=0.0)
    #calculating magnitude
    c_light = 2.99792458e18 * (u.Angstrom / u.s)
    m = np.isfinite(wave) & np.isfinite(flux) & (eff_area > 0)
    num = np.trapezoid(flux[m] * eff_area[m] * wave[m], wave[m])
    den = np.trapezoid(eff_area[m] / wave[m], wave[m])
    fnu_avg = num / (c_light * den)
    #mag_ab = fnu_avg.to(u.ABmag).value
    mag_ab = -2.5 * np.log10(fnu_avg.value) - 48.6
    if mag_ab > abmag_limit: 
        mag_ab = np.nan
        maggies = np.nan
    else:
        maggies = 10**(-0.4*mag_ab)
        
    return mag_ab, maggies


def generate_isim_cat(result,sep_constraint,gaia_coords, blank_wcs, matched_sed_paths, dummy_model, throughput_curve, abmag_sens):
    filters = ['F062', 'F087', 'F106', 'F129', 'F158', 'F184', 'F213', 'F146']
    maggies_dict = {filt: [] for filt in filters}

    model_wave = dummy_model[:, 0] * u.Angstrom
    model_scaling = dummy_model[:, 1]

    cut_idxs = set()

    for i in range(len(matched_sed_paths)):
        #read SED file

        # added if else statement 8/6/26
        path = matched_sed_paths[i]
        if path.startswith("s3://"):
            fs = s3fs.S3FileSystem()
            with fs.open(path, 'rb') as s3_file:
                with h5py.File(s3_file, mode="r") as h5_file:
                    sed_df = pd.DataFrame(h5_file['sed']['block0_values'])
        else:
            with h5py.File(matched_sed_paths[i], mode="r") as h5_file:
                sed_df = pd.DataFrame(h5_file['sed']['block0_values'])
    
        sed_wave = sed_df[0].values * u.Angstrom
        sed_flux = sed_df[1].values * u.mJy
        
        flux_interp = np.interp(model_wave, sed_wave.to(u.Angstrom), 
                                sed_flux.to(u.erg / (u.s * u.cm**2 * u.Angstrom), 
                                            equivalencies=u.spectral_density(sed_wave)), left=0.0, right=0.0)
        #applying model
        flux_mod = (flux_interp * dummy_model[:,1])
        for opt_element in filters:
            
            
            #turn mag convert into function of filter name then can go through filters
            
            
                
            mag_ab, maggies = sed_to_mag(model_wave, flux_mod, throughput_curve, abmag_sens, opt_element)
            #print('done')
            maggies_dict[opt_element].append(maggies)
    
    
    cat = Table({
        'ra': result[sep_constraint]['ra'].value,
        'dec': result[sep_constraint]['dec'].value,
        'type': np.full(len(result[sep_constraint]['ra']), 'PSF', dtype='U3'),
        'F062': maggies_dict['F062'],
        'F087': maggies_dict['F087'],
        'F106': maggies_dict['F106'],
        'F129': maggies_dict['F129'],
        'F146': maggies_dict['F146'],
        'F158': maggies_dict['F158'],
        'F184': maggies_dict['F184'],
        'F213': maggies_dict['F213'],
        'x': blank_wcs.radecToxy(gaia_coords[sep_constraint].ra.value,gaia_coords[sep_constraint].dec.value,units=galsim.degrees)[0],
        'y': blank_wcs.radecToxy(gaia_coords[sep_constraint].ra.value,gaia_coords[sep_constraint].dec.value,units=galsim.degrees)[1],
        'id': result[sep_constraint]['designation'].value,
        'bp_rp': result[sep_constraint]['bp_rp'].value,
        'teff': result[sep_constraint]['teff_gspphot'].value,
        'logg': result[sep_constraint]['logg_gspphot'].value,
        'mh': result[sep_constraint]['mh_gspphot'].value,
        'filename': matched_sed_paths

    })

    return cat

