#!/usr/bin/env python3
"""Detect compact stars on Roman detectors, match Gaia DR3 and plot offsets.

Example: python match_roman_gaia.py INPUT_DIRECTORY --output-dir gaia_j129
Catalog download is cached; --catalog-only only obtains it. --resume skips
completed detectors only when inputs, settings, code and products still match.
Standalone script; see match_roman_gaia_README.md for dependencies and usage.
Positions/offsets are in 1-based detector pixels. Offsets = measured star minus
Gaia projected through the supplied WCS (NOT a shift to apply to the image).
Gaia proper motions are propagated to exposure time; parallax is not modeled.
Robust affine fitting identifies matches and detector-center offsets; no image
or input WCS is modified. Source catalog: gaiadr3.gaia_source; default cuts G<20, RUWE<1.4.
"""
import argparse,hashlib,json,warnings
from dataclasses import dataclass,asdict,field as option
from importlib.metadata import version,PackageNotFoundError
from pathlib import Path
import numpy as np
import asdf
import astropy.units as u
from astropy.coordinates import SkyCoord
from astropy.time import Time
from astropy.table import Table
from astropy.io import fits
from astropy.wcs import WCS
from astropy.visualization import ImageNormalize,AsinhStretch
from scipy.ndimage import gaussian_filter,maximum_filter,binary_dilation
from scipy.spatial import cKDTree
from scipy.optimize import least_squares
from photutils.detection import DAOStarFinder
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


@dataclass(frozen=True)
class Settings:
    """Science settings; pixel lengths refer to native input pixels."""
    g_limit: float = option(default=20., metadata={'help':'Gaia G upper limit (mag)'})
    ruwe_limit: float = option(default=1.4, metadata={'help':'Gaia RUWE upper limit'})
    field_padding: float = option(default=.16, metadata={'help':'Catalog cone padding beyond detector centers (degrees); include detector extent and pointing uncertainty'})
    detector_radius: float = option(default=.18, metadata={'help':'Per-detector Gaia selection radius (degrees)'})
    background_sigma: float = option(default=20., metadata={'help':'Gaussian background smoothing sigma (pixels)'})
    detection_sigma: float = option(default=8., metadata={'help':'Detection threshold in robust MAD noise units'})
    fwhm: float = option(default=3.5, metadata={'help':'DAOStarFinder FWHM (pixels)'})
    max_stars: int = option(default=5000, metadata={'help':'Maximum initial detections per detector'})
    edge_margin: float = option(default=15., metadata={'help':'Excluded image border width (pixels; at least 8)'})
    translation_limit: float = option(default=2500., metadata={'help':'Blind translation search half-width (pixels)'})
    vote_bin: float = option(default=4., metadata={'help':'Fine translation histogram bin width (pixels)'})
    coarse_vote_bin: float = option(default=20., metadata={'help':'Fallback translation histogram bin width (pixels)'})
    seed_window: float = option(default=400., metadata={'help':'Seeded search and footprint padding (pixels)'})
    vote_catalog_stars: int = option(default=2000, metadata={'help':'Bright Gaia sources used in blind voting'})
    vote_image_stars: int = option(default=1500, metadata={'help':'Bright image sources used in blind voting'})
    seeded_catalog_stars: int = option(default=5000, metadata={'help':'Gaia sources used in seeded voting'})
    seeded_image_stars: int = option(default=4000, metadata={'help':'Image sources used in seeded voting'})
    max_candidates: int = option(default=30, metadata={'help':'Translation peaks refined with affine fits'})
    min_fit_matches: int = option(default=15, metadata={'help':'Minimum pairs for candidate refinement (at least 3)'})
    min_matches: int = option(default=100, metadata={'help':'Minimum accepted matches per detector'})
    match_radius: float = option(default=1.5, metadata={'help':'Final mutual-neighbor matching radius (pixels)'})
    max_median_residual: float = option(default=.6, metadata={'help':'Maximum accepted median radial residual (pixels)'})
    affine_loss_scale: float = option(default=.3, metadata={'help':'Soft-L1 robust loss scale (pixels)'})
    affine_normalization: float = option(default=2000., metadata={'help':'Pixel scale used to condition the affine design matrix'})
    max_affine_deviation: float = option(default=.02, metadata={'help':'Maximum absolute element of affine linear matrix minus identity'})
    clip_sigma: float = option(default=4., metadata={'help':'Residual clipping multiplier of per-axis MAD scatter'})
    clip_floor: float = option(default=.25, metadata={'help':'Minimum per-axis residual clipping threshold (pixels)'})
    clip_iterations: int = option(default=6, metadata={'help':'Number of residual clipping/refitting iterations'})
    prediction_lower_padding: float = option(default=2200., metadata={'help':'Allowed nominal Gaia pixels below zero'})
    prediction_upper_padding: float = option(default=2212., metadata={'help':'Allowed nominal Gaia pixels beyond image dimensions'})
    sip_error: float = option(default=.01, metadata={'help':'Requested forward/inverse FITS-SIP approximation tolerance (pixels)'})
    label_stars: int = option(default=25, metadata={'help':'Maximum brightest Gaia stars at affine-predicted positions labeled per detector'})
    vector_bins: int = option(default=8, metadata={'help':'Spatial vector bins per detector axis'})

    def validate(self):
        for name,value in asdict(self).items():
            if not np.isfinite(value) or value<=0:
                raise ValueError(f'{name.replace("_", "-")} must be finite and positive')
        if self.edge_margin<8:raise ValueError('edge-margin must be at least 8 for centroid cutouts')
        if self.min_fit_matches<3 or self.min_matches<self.min_fit_matches:
            raise ValueError('Require min-matches >= min-fit-matches >= 3')
        if self.coarse_vote_bin<self.vote_bin:raise ValueError('coarse-vote-bin must be >= vote-bin')
        if self.match_radius>10:raise ValueError('match-radius must be <= 10 for the refinement schedule')


DEFAULTS=Settings()
DEPENDENCIES=('numpy','scipy','astropy','asdf','gwcs','photutils','matplotlib',
              'astroquery','roman_datamodels','asdf-astropy','asdf-wcs-schemas',
              'asdf-transform-schemas','rad')


def file_hash(path):
    """Stream file contents; timestamps alone cannot establish cache identity."""
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()


def runtime_identity():
    packages={}
    for name in DEPENDENCIES:
        try:packages[name]=version(name)
        except PackageNotFoundError:packages[name]='not installed'
    return dict(script_sha256=file_hash(__file__),packages=packages)


def read_json(path):
    try:
        value=json.loads(Path(path).read_text())
        return value if isinstance(value,dict) else {}
    except (OSError,ValueError):return {}


def write_json(path,value):
    path=Path(path);temp=path.with_name(path.name+'.tmp')
    temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(path)


def cache_valid(manifest,provenance,out,products):
    """Require exact provenance and every expected product's content digest."""
    if manifest.get('provenance')!=provenance:return False
    hashes=manifest.get('products',{})
    return all((out/name).is_file() and hashes.get(name)==file_hash(out/name)
               for name in products)


def read_image(path,sip_error=.01):
    """Read Roman data/DQ and approximate the GWCS with FITS-SIP, in memory."""
    if path.suffix.lower()=='.asdf':
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',asdf.exceptions.AsdfConversionWarning)
            warnings.simplefilter('ignore',asdf.exceptions.AsdfPackageVersionWarning)
            with asdf.open(path,lazy_load=True) as f:
                r=f['roman'];ny,nx=r['data'].shape
                header=r['meta']['wcs'].to_fits_sip(
                    bounding_box=((-0.5,nx-0.5),(-0.5,ny-0.5)),
                    max_pix_error=sip_error,max_inv_pix_error=sip_error)
                return (WCS(header),np.array(r['data']),np.array(r['dq']),
                        r['meta']['instrument']['detector'],r['meta']['exposure']['start_time'].utc.isot)
    with fits.open(path) as f:
        return (WCS(f['SCI'].header),f['SCI'].data.copy(),f['DQ'].data.copy(),
                f[0].header.get('DETECTOR',path.stem),f[0].header.get('DATE-BEG',''))


def associations(predicted,detected,limit):
    """Return mutual nearest-neighbor pairs within limit, in input pixels."""
    distance,index=cKDTree(detected).query(predicted)
    reverse=cKDTree(predicted).query(detected)[1]
    keep=(distance<limit)&(reverse[index]==np.arange(len(predicted)))
    cat=np.where(keep)[0]
    return cat,index[keep],distance[keep]



def field_metadata(files,settings=DEFAULTS):
    rows=[]
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        for p in files:
            with asdf.open(p,lazy_load=True) as f:
                m=f['roman']['meta'];ny,nx=f['roman']['data'].shape
                ra,dec=m['wcs']((nx-1)/2,(ny-1)/2)
                rows.append(dict(file=str(p.resolve()),detector=m['instrument']['detector'],ra=float(ra),dec=float(dec),start=m['exposure']['start_time'].utc.isot,shape=[ny,nx]))
    detectors=[r['detector'] for r in rows]
    duplicates=sorted({d for d in detectors if detectors.count(d)>1})
    if duplicates:raise ValueError('Multiple inputs for detector(s): '+', '.join(duplicates)+'; use one exposure per detector in a run')
    c=SkyCoord([r['ra'] for r in rows]*u.deg,[r['dec'] for r in rows]*u.deg)
    xyz=np.mean(c.cartesian.xyz.value,axis=1)
    center=SkyCoord(x=xyz[0],y=xyz[1],z=xyz[2],representation_type='cartesian').icrs
    center=SkyCoord(center.spherical.lon,center.spherical.lat)
    return dict(detectors=rows,ra=center.ra.deg,dec=center.dec.deg,radius=float(np.max(c.separation(center).deg)+settings.field_padding))


def catalog(out,field,settings=DEFAULTS):
    path=out/'gaia_dr3_complete.ecsv';manifest_path=out/'gaia_catalog_cache.json'
    q=f"""SELECT source_id,ra,dec,pmra,pmdec,ref_epoch,phot_g_mean_mag,phot_rp_mean_mag,ruwe
    FROM gaiadr3.gaia_source WHERE 1=CONTAINS(POINT('ICRS',ra,dec),
    CIRCLE('ICRS',{field['ra']},{field['dec']},{field['radius']}))
    AND phot_g_mean_mag < {settings.g_limit} AND ruwe < {settings.ruwe_limit}
    AND pmra IS NOT NULL AND pmdec IS NOT NULL"""
    provenance=dict(query=q,service='https://gea.esac.esa.int/tap-server/tap',schema_version=1)
    manifest=read_json(manifest_path)
    if cache_valid(manifest,provenance,out,[path.name]):return Table.read(path)
    from astroquery.gaia import Gaia
    print('Downloading Gaia catalog: cache absent or provenance/content changed',flush=True)
    Gaia.ROW_LIMIT=-1
    job=Gaia.launch_job_async(q)
    if job.get_phase() != 'COMPLETED':
        raise RuntimeError('Gaia query did not complete successfully')
    t=job.get_results()
    temp=path.with_name(path.stem+'.tmp.ecsv');t.write(temp,overwrite=True);temp.replace(path)
    (out/'gaia_query.adql').write_text(q+'\n')
    write_json(manifest_path,dict(provenance=provenance,products={path.name:file_hash(path)},
                                 rows=len(t),job_id=str(job.jobid),phase='COMPLETED'))
    print(f'Cached {len(t)} Gaia DR3 sources',flush=True)
    return t


def detect(data,dq,settings=DEFAULTS):
    bad=~np.isfinite(data)|((dq&3)!=0)
    fill=np.where(bad,np.nanmedian(data[~bad]),data).astype('f4')
    bg=gaussian_filter(fill,settings.background_sigma)
    a=fill-bg
    sample=a[::4,::4];med=np.median(sample)
    sigma=1.4826*np.median(np.abs(sample-med))
    finder=DAOStarFinder(threshold=settings.detection_sigma*sigma,fwhm=settings.fwhm,exclude_border=True)
    t=finder(a,mask=binary_dilation(bad,iterations=3))
    if t is None:raise RuntimeError('No detected stars')
    margin=settings.edge_margin
    keep=(t['x_centroid']>margin)&(t['x_centroid']<data.shape[1]-margin)&(t['y_centroid']>margin)&(t['y_centroid']<data.shape[0]-margin)
    t=t[keep];t.sort('flux',reverse=True);t=t[:settings.max_stars]
    # Refine with a compact positive-flux centroid; reject masked footprints.
    rows=[]
    for row in t:
        x,y=float(row['x_centroid']),float(row['y_centroid'])
        ix,iy=int(round(x)),int(round(y));cut=data[iy-7:iy+8,ix-7:ix+8]
        yy,xx=np.mgrid[iy-7:iy+8,ix-7:ix+8];rr=np.hypot(xx-x,yy-y)
        if np.any(bad[iy-7:iy+8,ix-7:ix+8][rr<5]):continue
        bgval=np.median(cut[(rr>6)&(rr<7.5)])
        ww=np.where(rr<5,np.maximum(cut-bgval,0),0)
        flux=ww.sum()
        if not np.isfinite(flux) or flux<=0:continue
        cx=(xx*ww).sum()/flux;cy=(yy*ww).sum()/flux
        if np.hypot(cx-x,cy-y)>1.5:continue
        rows.append((cx+1,cy+1,float(flux)))
    t=Table(rows=rows,names=['x','y','flux']);t.sort('flux',reverse=True)
    xy=np.column_stack([t['x'],t['y']])
    tree=cKDTree(xy);keep=np.ones(len(t),bool)
    for i in range(len(t)):
        if keep[i]:
            neighbors=tree.query_ball_point(xy[i],4.)
            keep[[j for j in neighbors if j>i]]=False
    return t[keep]


def fit_affine(pred,obs,center=(2044.5,2044.5),settings=DEFAULTS):
    design=np.column_stack([(pred-center)/settings.affine_normalization,np.ones(len(pred))])
    co=np.linalg.lstsq(design,obs-pred,rcond=None)[0]
    result=least_squares(lambda c:(design@c.reshape(3,2)-(obs-pred)).ravel(),co.ravel(),loss='soft_l1',f_scale=settings.affine_loss_scale)
    return result.x.reshape(3,2)


def transform(xy,co,center=(2044.5,2044.5),settings=DEFAULTS):
    return xy+np.column_stack([(xy-center)/settings.affine_normalization,np.ones(len(xy))])@co


def match_at_scale(pred,obs,bin_width=4.,seed=None,shape=(4088,4088),settings=DEFAULTS):
    size=np.array(shape[::-1]);center=(size+1)/2
    # Magnitude rankings need not agree between Gaia and J129. All-pairs votes
    # among bright subsets allow a large initial WCS translation.
    if seed is None:
        voted=pred[:settings.vote_catalog_stars];observed=obs[:settings.vote_image_stars]
        edgesx=edgesy=np.arange(-settings.translation_limit,settings.translation_limit+bin_width,bin_width)
    else:
        expected=pred+seed
        voted=pred[np.all((expected>-settings.seed_window)&(expected<size+settings.seed_window),axis=1)][:settings.seeded_catalog_stars]
        observed=obs[:settings.seeded_image_stars]
        edgesx=np.arange(seed[0]-settings.seed_window,seed[0]+settings.seed_window+bin_width,bin_width)
        edgesy=np.arange(seed[1]-settings.seed_window,seed[1]+settings.seed_window+bin_width,bin_width)
    offsets=(observed[:,None,:]-voted[None,:,:]).reshape(-1,2)
    hist,_,_=np.histogram2d(offsets[:,0],offsets[:,1],bins=(edgesx,edgesy))
    del offsets
    background=gaussian_filter(hist,100/bin_width)
    hist=(gaussian_filter(hist,.8)-background)/np.sqrt(background+.2)
    peaks=np.argwhere(hist==maximum_filter(hist,size=9))
    peaks=sorted(peaks,key=lambda z:hist[tuple(z)],reverse=True)[:settings.max_candidates]
    solutions=[]
    for ix,iy in peaks:
        co=np.zeros((3,2));co[2]=[edgesx[ix]+bin_width/2,edgesy[iy]+bin_width/2]
        schedule=([30,20,10,6,3,2] if bin_width>settings.vote_bin else [10,6,3,2])
        for limit in [v for v in schedule if v>settings.match_radius]+[settings.match_radius]:
            ci,di,dist=associations(transform(pred,co,center,settings),obs,limit)
            if len(ci)<settings.min_fit_matches:break
            co=fit_affine(pred[ci],obs[di],center,settings)
        ci,di,dist=associations(transform(pred,co,center,settings),obs,settings.match_radius)
        if len(ci)>=settings.min_fit_matches and np.max(np.abs(co[:2]))/settings.affine_normalization<settings.max_affine_deviation:
            solutions.append((len(ci),float(np.median(dist)),co))
    solutions.sort(key=lambda s:(-s[0],s[1]))
    if not solutions or solutions[0][0]<settings.min_matches:raise RuntimeError('No convincing Gaia consensus')
    if len(solutions)>1 and solutions[0][0]<2*solutions[1][0]:
        if np.linalg.norm(solutions[0][2][2]-solutions[1][2][2])>5:
            raise RuntimeError('Ambiguous competing Gaia match solutions')
    co=solutions[0][2]
    ci,di,dist=associations(transform(pred,co,center,settings),obs,settings.match_radius)
    for _ in range(settings.clip_iterations):
        residual=obs[di]-transform(pred[ci],co,center,settings)
        scatter=1.4826*np.median(np.abs(residual-np.median(residual,axis=0)),axis=0)
        keep=np.all(np.abs(residual)<np.maximum(settings.clip_sigma*scatter,settings.clip_floor),axis=1)
        ci,di=ci[keep],di[keep]
        if len(ci)<settings.min_matches:raise RuntimeError('Too few inliers for this crowded field')
        co=fit_affine(pred[ci],obs[di],center,settings)
    radial=np.linalg.norm(obs[di]-transform(pred[ci],co,center,settings),axis=1)
    if np.median(radial)>settings.max_median_residual:
        raise RuntimeError('Residuals too large for a secure match')
    return ci,di,co,[(v[0],v[1]) for v in solutions]


def match(pred,obs,seed=None,shape=(4088,4088),settings=DEFAULTS):
    try:
        return match_at_scale(pred,obs,settings.vote_bin,shape=shape,settings=settings)
    except RuntimeError:
        print('Retrying with broader translation votes',flush=True)
        try:
            return match_at_scale(pred,obs,settings.coarse_vote_bin,shape=shape,settings=settings)
        except RuntimeError:
            if seed is None:raise
            print('Using other secure detectors to restrict the voting footprint',flush=True)
            return match_at_scale(pred,obs,settings.vote_bin,seed=seed,shape=shape,settings=settings)


def project_gaia(cat,base,start,shape,settings=DEFAULTS):
    """Project the available Gaia catalog, including sources not detected in the image."""
    ny,nx=shape;center_pixel=np.array([(nx+1)/2,(ny+1)/2])
    # Filter a generous cone before propagating Gaia positions.
    sky_center=SkyCoord(*base.all_pix2world(*center_pixel,1),unit='deg')
    coords=SkyCoord(cat['ra'],cat['dec'])
    c=cat[coords.separation(sky_center)<settings.detector_radius*u.deg].copy()
    coords=SkyCoord(ra=c['ra'],dec=c['dec'],pm_ra_cosdec=c['pmra'],pm_dec=c['pmdec'],obstime=Time(np.array(c['ref_epoch']),format='jyear'))
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        epoch=coords.apply_space_motion(new_obstime=Time(start))
    sky=np.column_stack([epoch.ra.deg,epoch.dec.deg])
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        pred=base.all_world2pix(sky,1,quiet=True)
    keep=np.all(np.isfinite(pred),axis=1)&np.all((pred>-settings.prediction_lower_padding)&(pred<np.array([nx,ny])+settings.prediction_upper_padding),axis=1)
    c=c[keep];pred=pred[keep];sky=sky[keep]
    order=np.argsort(np.array(c['phot_g_mean_mag']));c=c[order];pred=pred[order];sky=sky[order]
    return c,pred,sky,sky_center


def plot_bright_gaia(data,catalog,nominal_xy,coefficients,det,out,settings=DEFAULTS):
    """Plot the brightest on-detector Gaia predictions using the fitted affine map.

    Selection is independent of detection, saturation, and match acceptance.

    Average 4x4 blocks for display rather than decimating compact stars away.
    Pixel-edge extents preserve the original 1-based coordinate system.
    """
    ny,nx=data.shape
    padded=np.full(((ny+3)//4*4,(nx+3)//4*4),np.nan,dtype='f4')
    padded[:ny,:nx]=data
    with warnings.catch_warnings():
        warnings.simplefilter('ignore',RuntimeWarning)
        display=np.nanmean(padded.reshape(padded.shape[0]//4,4,padded.shape[1]//4,4),axis=(1,3))
    finite=display[np.isfinite(display)]
    lo,hi=np.percentile(finite,[5,99.8]) if finite.size else (0.,1.)
    if hi<=lo:hi=lo+1
    g=np.asarray(np.ma.filled(catalog['phot_g_mean_mag'],np.nan),dtype=float)
    center=np.array([(nx+1)/2,(ny+1)/2])
    xy=transform(np.asarray(nominal_xy),np.asarray(coefficients),center,settings)
    x,y=xy.T
    valid=np.isfinite(g)&np.isfinite(x)&np.isfinite(y)&(x>=.5)&(x<=nx+.5)&(y>=.5)&(y<=ny+.5)
    selected=np.flatnonzero(valid)
    selected=selected[np.argsort(g[selected],kind='stable')[:settings.label_stars]]
    labels=catalog[selected].copy()
    labels['x_affine']=x[selected];labels['y_affine']=y[selected]
    labels.meta.update(position_definition='Affine-transformed epoch-propagated Gaia WCS predictions; 1-based input pixels',
                       selection='Brightest finite G magnitudes with affine-predicted positions inside image; no detection or saturation cut')
    labels.write(out/f'{det}_bright_gaia.ecsv',overwrite=True)
    fig,ax=plt.subplots(figsize=(10,10),layout='constrained')
    ax.imshow(display,origin='lower',cmap='gray',interpolation='nearest',
              norm=ImageNormalize(vmin=lo,vmax=hi,stretch=AsinhStretch(.05)),
              extent=(.5,padded.shape[1]+.5,.5,padded.shape[0]+.5))
    ax.set(xlim=(.5,nx+.5),ylim=(.5,ny+.5),xlabel='x (pixels)',ylabel='y (pixels)',
           title=f'{det}: brightest Gaia stars — affine positions; labels are G magnitudes')
    ax.scatter(x[selected],y[selected],s=210,facecolors='none',edgecolors='#ffe066',linewidths=1.)
    # Try several text offsets to avoid existing labels and the image border.
    fig.canvas.draw();renderer=fig.canvas.get_renderer();occupied=[]
    offsets=[(12,12),(12,-12),(-12,12),(-12,-12),(22,0),(-22,0),(0,24),(0,-24),(30,25),(-30,-25)]
    for i in selected:
        choices=[]
        for dx,dy in offsets:
            label=ax.annotate(f'{g[i]:.2f}',(x[i],y[i]),xytext=(dx,dy),textcoords='offset points',
                              ha='left' if dx>=0 else 'right',va='bottom' if dy>=0 else 'top',
                              fontsize=9,color='#ffe066',bbox=dict(facecolor='black',alpha=.6,edgecolor='none',pad=1.5))
            box=label.get_window_extent(renderer).expanded(1.08,1.15)
            penalty=sum(box.overlaps(other) for other in occupied)
            if not ax.bbox.contains(box.x0,box.y0) or not ax.bbox.contains(box.x1,box.y1):penalty+=100
            choices.append((penalty,dx,dy,box));label.remove()
        _,dx,dy,box=min(choices,key=lambda item:item[0]);occupied.append(box)
        ax.annotate(f'{g[i]:.2f}',(x[i],y[i]),xytext=(dx,dy),textcoords='offset points',
                    ha='left' if dx>=0 else 'right',va='bottom' if dy>=0 else 'top',
                    fontsize=9,color='#ffe066',bbox=dict(facecolor='black',alpha=.6,edgecolor='none',pad=1.5),
                    arrowprops=dict(arrowstyle='-',color='#ffe066',alpha=.6,lw=.5,shrinkB=9))
    for ext in ('png','pdf'):
        fig.savefig(out/f'{det}_bright_gaia.{ext}',dpi=160,bbox_inches='tight')
    plt.close(fig)
    return selected


def process(path,cat,out,seed=None,settings=DEFAULTS,provenance=None):
    base,data,dq,det,start=read_image(path,settings.sip_error)
    shape=data.shape;ny,nx=shape;center_pixel=np.array([(nx+1)/2,(ny+1)/2])
    if provenance is None:raise ValueError("process requires input/catalog/settings provenance")
    star_path=out/f'{det}_stars.ecsv'
    star_manifest=out/f'{det}_stars_cache.json'
    star_provenance={k:provenance[k] for k in ('input','settings','runtime')}
    if cache_valid(read_json(star_manifest),star_provenance,out,[star_path.name]):
        stars=Table.read(star_path)
    else:
        stars=detect(data,dq,settings);stars.meta['input_mtime_ns']=path.stat().st_mtime_ns
        stars.write(star_path,overwrite=True)
        write_json(star_manifest,dict(provenance=star_provenance,products={star_path.name:file_hash(star_path)}))
    small=data[::8,::8].copy();del dq
    c,pred,sky,sky_center=project_gaia(cat,base,start,shape,settings)
    if len(c)<settings.min_matches:raise RuntimeError('Insufficient Gaia coverage near detector')
    obs=np.column_stack([stars['x'],stars['y']])
    ci,di,co,scores=match(pred,obs,seed=seed,shape=shape,settings=settings)
    offsets=obs[di]-pred[ci];residual=obs[di]-transform(pred[ci],co,center_pixel,settings)
    table=c[ci].copy()
    for key,v in dict(ra_epoch=sky[ci,0],dec_epoch=sky[ci,1],x=obs[di,0],y=obs[di,1],gaia_x=pred[ci,0],gaia_y=pred[ci,1],dx=offsets[:,0],dy=offsets[:,1],residual_x=residual[:,0],residual_y=residual[:,1]).items():table[key]=v
    table.meta.update(epoch=start,offset_definition='observed minus nominal WCS Gaia prediction; pixels; 1-based positions')
    table.write(out/f'{det}_matches.ecsv',overwrite=True)
    matrix=np.eye(2)+co[:2]/settings.affine_normalization
    intercept=co[2]-center_pixel@(co[:2]/settings.affine_normalization)
    predicted_at_center=(center_pixel-intercept)@np.linalg.inv(matrix)
    center_offset=center_pixel-predicted_at_center
    report=dict(detector=det,input=str(path.resolve()),input_mtime_ns=path.stat().st_mtime_ns,catalog_rows=len(cat),match_method_version=3,start_utc=start,n_detected=len(stars),n_matched=len(ci),
                dx_center=float(center_offset[0]),dy_center=float(center_offset[1]),offset_at_nominal_center=co[2].tolist(),median_dx=float(np.median(offsets[:,0])),median_dy=float(np.median(offsets[:,1])),
                residual_rms_pixels=float(np.sqrt(np.mean(np.sum(residual**2,axis=1)))),
                affine_offset_coefficients=co.tolist(),candidate_scores=scores,ra_center=sky_center.ra.deg,dec_center=sky_center.dec.deg,
                shape=list(shape),affine_center_xy=center_pixel.tolist(),affine_normalization=settings.affine_normalization,provenance=provenance,
                offset_definition='observed minus nominal Gaia prediction in input pixels')
    fig,ax=plt.subplots(figsize=(6,6),layout='constrained')
    lo,hi=np.nanpercentile(small,[5,99.5]);ax.imshow(small,origin='lower',cmap='gray',vmin=lo,vmax=hi,extent=(1,nx,1,ny))
    ax.scatter(obs[di,0],obs[di,1],s=20,facecolors='none',edgecolors='cyan',lw=.5)
    ax.set(title=f'{det}: {len(ci)} Gaia matches',xlabel='x',ylabel='y')
    fig.savefig(out/f'{det}_matches.png',dpi=140,bbox_inches='tight');plt.close(fig)
    print(f'{det}: {len(stars)} stars, {len(ci)} matches; dx,dy=({center_offset[0]:.3f},{center_offset[1]:.3f}) pix; residual RMS {report["residual_rms_pixels"]:.3f} pix',flush=True)
    plot_bright_gaia(data,c,pred,co,det,out,settings)
    del data
    report['products']={name:file_hash(out/name) for name in detector_products(det)}
    write_json(out/f'{det}_summary.json',report)
    return report


def plots(reports,out,settings=DEFAULTS):
    t=Table(rows=[{k:r[k] for k in ['detector','n_detected','n_matched','dx_center','dy_center','median_dx','median_dy','residual_rms_pixels']} for r in reports])
    t.write(out/'detector_offsets.ecsv',overwrite=True)
    fig,(ax,zoom)=plt.subplots(1,2,figsize=(9,6),layout='constrained',gridspec_kw={'width_ratios':[1,3]})
    colors=plt.get_cmap('turbo')(np.linspace(.05,.95,len(reports)))
    for r,color in zip(reports,colors):
        dx,dy=r['dx_center'],r['dy_center']
        ax.quiver(0,0,dx,dy,angles='xy',scale_units='xy',scale=1,color=color,width=.004)
        ax.scatter(dx,dy,s=18,color=color)
        zoom.scatter(dx,dy,s=30,color=color)
        zoom.annotate(r['detector'].replace('WFI',''),(dx,dy),xytext=(4,4),textcoords='offset points',fontsize=9)
    dx=np.array(t['dx_center']);dy=np.array(t['dy_center'])
    x0,x1=min(0,dx.min()),max(0,dx.max());y0,y1=min(0,dy.min()),max(0,dy.max());pad=max(x1-x0,y1-y0,1)*.08
    ax.set(xlim=(x0-pad,x1+pad),ylim=(y0-pad,y1+pad),xlabel='x offset (pixels)',ylabel='y offset (pixels)',title='Vectors from zero offset')
    zoom.set(xlabel='x offset (pixels)',ylabel='y offset (pixels)',title='Vector endpoints (detector numbers)')
    zoom.margins(.2)
    for panel in [ax,zoom]:panel.set_aspect('equal',adjustable='box');panel.grid(alpha=.2)
    fig.suptitle('Roman J129 offsets relative to Gaia DR3\nMeasured position − nominal WCS prediction, at detector center')
    for ext in ['png','pdf']:fig.savefig(out/f'detector_offset_vectors.{ext}',dpi=180,bbox_inches='tight')
    plt.close(fig)
    nrows=(len(reports)+5)//6
    fig,axes=plt.subplots(nrows,6,figsize=(20,10*nrows/3),layout='constrained',squeeze=False)
    magnitude=max(np.hypot(dx,dy).max(),1);factor=500/magnitude
    for ax,r in zip(axes.flat,reports):
        m=Table.read(out/f'{r["detector"]}_matches.ecsv')
        ny,nx=r['shape'];xstep=nx/settings.vector_bins;ystep=ny/settings.vector_bins
        # Median vectors in spatial cells avoid an unreadable crowded quiver.
        for x in np.arange(0,nx,xstep):
            for y in np.arange(0,ny,ystep):
                k=(m['x']>=x)&(m['x']<x+xstep)&(m['y']>=y)&(m['y']<y+ystep)
                if k.sum()>=3:
                    ax.quiver(x+xstep/2,y+ystep/2,np.median(m['dx'][k]),np.median(m['dy'][k]),angles='xy',scale_units='xy',scale=1/factor,width=.004)
        ax.set(xlim=(0,nx),ylim=(0,ny),title=f'{r["detector"]}  N={r["n_matched"]}\n({r["dx_center"]:.2f}, {r["dy_center"]:.2f}) pix',xlabel='x',ylabel='y');ax.set_aspect('equal')
    for ax in list(axes.flat)[len(reports):]:ax.set_visible(False)
    fig.suptitle(f'Gaia offsets across each detector: spatial-bin medians; arrows scaled ×{factor:.2f}',fontsize=16)
    for ext in ['png','pdf']:fig.savefig(out/f'all_detector_vectors.{ext}',dpi=150,bbox_inches='tight')
    plt.close(fig)


def detector_products(det):
    return [f'{det}_stars.ecsv',f'{det}_matches.ecsv',f'{det}_matches.png',f'{det}_bright_gaia.png',f'{det}_bright_gaia.pdf',f'{det}_bright_gaia.ecsv']


def build_parser():
    p=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument('directory',type=Path)
    p.add_argument('--output-dir',type=Path,default=Path('gaia_j129'))
    p.add_argument('--catalog-only',action='store_true',help='Download/validate the Gaia cache only')
    p.add_argument('--resume',action='store_true',help='Reuse fits only when provenance and output hashes match')
    p.add_argument('--detector',help='Process one detector, e.g. WFI01')
    for name,f in Settings.__dataclass_fields__.items():
        p.add_argument('--'+name.replace('_','-'),type=f.type,default=f.default,help=f.metadata['help'])
    return p


def main():
    p=build_parser();args=p.parse_args()
    settings=Settings(**{name:getattr(args,name) for name in Settings.__dataclass_fields__})
    try:settings.validate()
    except ValueError as e:p.error(str(e))
    files=sorted(args.directory.rglob('*_cal.asdf'))
    if not files:raise ValueError('No calibrated ASDF files')
    # Validate all detector IDs before creating outputs or issuing a query.
    field=field_metadata(files,settings)
    if args.detector and args.detector not in [r['detector'] for r in field['detectors']]:
        raise ValueError(f'Requested detector {args.detector} is not present')
    out=args.output_dir;out.mkdir(parents=True,exist_ok=True)
    write_json(out/'field.json',field)
    cat=catalog(out,field,settings)
    if args.catalog_only:return
    runtime=runtime_identity()
    catalog_identity=dict(sha256=file_hash(out/'gaia_dr3_complete.ecsv'),
                          provenance=read_json(out/'gaia_catalog_cache.json').get('provenance'))
    reports=[];errors=[]
    for path,row in zip(files,field['detectors']):
        det=row['detector']
        if args.detector and det!=args.detector:continue
        seed=np.median([np.array(r['affine_offset_coefficients'])[2] for r in reports],axis=0) if len(reports)>=3 else None
        provenance=dict(input=dict(path=str(path.resolve()),sha256=file_hash(path)),
                        catalog=catalog_identity,settings=asdict(settings),runtime=runtime,
                        seed=None if seed is None else seed.tolist())
        cached=read_json(out/f'{det}_summary.json')
        if args.resume and cache_valid(cached,provenance,out,detector_products(det)):
            reports.append(cached);print(f'{det}: reusing verified result',flush=True);continue
        try:
            reports.append(process(path,cat,out,seed=seed,settings=settings,provenance=provenance))
        except Exception as e:
            import traceback
            traceback.print_exc();errors.append(dict(detector=det,error=str(e)))
    write_json(out/'errors.json',errors)
    if reports:plots(reports,out,settings)
    if errors:raise RuntimeError(f'{len(errors)} detectors failed; see errors.json')

if __name__=='__main__':main()
