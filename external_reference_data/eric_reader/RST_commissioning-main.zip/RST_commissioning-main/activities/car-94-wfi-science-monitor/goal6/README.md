# CAP_94_goal6
Code associated to CAP 94 goal 6

Derive a flatfield for each filter appropriate to correct small-scale spatial variations. Check these for consistency with TVAC products.

The procedure is standard.
Identify flat images.
Process L1 images with standard pipeline without flat-field step (DQ, IRRC, Dark Decay, WFI18 anomaly, Saturation, Linearity, Ramp Fitting, Dark Current)
Using the resulting ramp image, divide said image by the median ramp value across all non-masked pixels, creating a “normalized” ramp.
Combine multiple normalized ramps for the same RCS band (or same filter element in case of using on-sky illumination) and compute per-pixel medians. Derive uncertainty via bootstrap resampling.

A `requirements.txt` file is included listing basic dependencies. However, the analysis will use the `roman-wfi-reference-pipeline` package and its dependencies, so a custom environment will 
be used.

Exit criteria already present at: https://outerspace.stsci.edu/display/RSC/Mapping+CARs+and+Exit+Criteria

CAP complete when reference file is generated.

Code to be ported to: https://github.com/RomanSpaceTelescope/RST_commissioning/tree/main/rst_commissioning

