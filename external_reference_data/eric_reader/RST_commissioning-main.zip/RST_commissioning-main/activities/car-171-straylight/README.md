Note that bright star analysis will be applicable for bright sources placed in the focal plane.
See [bright star notebook](https://github.com/spacetelescope/roman_notebooks/blob/main/notebooks/ground_test_analysis/wfi_tvac_brightstar.ipynb)
Potentially [skysurf](https://arxiv.org/abs/2507.05323)

See the [CAO](https://outerspace.stsci.edu/spaces/RSC/pages/428057545/CAO+for+CAP+171)

Artifacts:
* APT 1020, observation 5, exposure 4 pass 2 SCA 6 (F158), Maxime Rizzo 9/15/26, "Dragon's breath"
