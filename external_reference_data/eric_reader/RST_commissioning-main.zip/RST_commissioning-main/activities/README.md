Analysis code per CAR goes in this directory. Each directory can contain notebooks, scripts, source, configuration, `requirements.txt` as best support that CAR.

`activities/requirements.txt` is a catch-all for pip packages that you may use at some point. In contrast, the `requirements.txt` in each CAR can provide specific packages and versions that are known for the analysis. For example, you might want to use `pandas` at some point so can include that in `activities/requirements.txt`, but for a CAR analysis you need a specific version of `rosalia`. 

To see what pip packages you are using now, you can run `pip freeze` and boil that down to the parent packages that you recognize using. If you do not have version requirements, consider clearing the version flag and use the `activities/requirements.txt` more like an informal `requirements.in`. If you have version requirements, retain those.
