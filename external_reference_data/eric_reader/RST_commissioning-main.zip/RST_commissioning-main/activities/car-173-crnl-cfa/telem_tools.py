import numpy as np
import os
from astropy.stats import sigma_clipped_stats
from astropy.table import Table
from astropy.time import Time, TimeDelta
import astropy.units as u
from astroquery.mast import MastMissions
# get the following from https://github.com/RomanSpaceTelescope/roman-mast-tools.git
from roman_telem import query_telemetry, extract_mnemonics_from_groups

def start_telem_table(**kwargs):

    # Borrows from Tyler D's example code

    # Create MastMissions object and assign mission to 'roman'
    missions = MastMissions(mission='roman')

    # Login to search and retrieve Roman data
    token = os.getenv("MAST_API_TOKEN")
    missions.login(token=token)
               
    print(f'Mission: {missions.mission}')
    print(f'Service: {missions.service}')

    col_list = ['program', 'execution_plan', 'pass', 'segment', 'visit', 'observation', 
                'optical_element', 'exposure_type', 'instrument_name', 'detector', 'productLevel', 
                'product_type', 'exposure_time', 'exposure_start_time', 'exposure_end_time', 'fileSetName']

    if 'passn' in kwargs:
        kwargs['pass'] = kwargs.pop('passn')

    results = missions.query_criteria(
        **kwargs,
        select_cols=col_list)
    
    sinds = np.argsort(results['exposure_start_time'])

    t = Table()

    tmp = results['fileSetName'][sinds]
    stubend = tmp[0].find('_wfi')
    t['filestub'] = [fs[:stubend] for fs in tmp]
    t['obsnum'] = np.array([int(s[14:17]) for s in t['filestub']])
    t['expnum'] = np.array([int( s[s.find('_')+1:][:4] ) for s in t['filestub']])
    t['expstart'] = results['exposure_start_time']
    t['expend'] = results['exposure_end_time']
    t['duration'] = (Time(t['expend'], scale='utc') -
                     Time(t['expstart'], scale='utc')).to_value('second')

    return t

def getRCStelem(start_time, end_time, rcs_csv, from_file=False):

    if not from_file:
        
        mnemonics = ['WFI_MCE_SRCS_BOARD_T', 'WFI_MCE_SRCS_SPHERE_T',
                     'WFI_MCE_SRCS_PD1_V', 'WFI_MCE_SRCS_PD2_V',
                     'WFI_MCE_SRCS_PD1_INTOUTPUT_UPPER', 'WFI_MCE_SRCS_PD1_INTOUTPUT_LOWER',
                     'WFI_MCE_SRCS_PD2_INTOUTPUT_UPPER', 'WFI_MCE_SRCS_PD2_INTOUTPUT_LOWER']
        timebuf = TimeDelta(1 * u.minute)
        df = query_telemetry(
            mnemonics=mnemonics,
            start_time=(Time(start_time, scale='utc')-timebuf).isot,
            end_time=(Time(end_time, scale='utc')+timebuf).isot,
            combine=True,                # return one wide DataFrame indexed by ObsTime
            verbose=True,
            api_token=os.getenv("MAST_API_TOKEN")  # if you use a token
        )
        rcst = Table.from_pandas(df, index=True)
        rcst.write(rcs_csv, format='ascii.csv', overwrite=True)

    else:
        rcst = Table.read(rcs_csv)

    rcst['ObsTime'] = Time(rcst['ObsTime'])

    return rcst

def RCSintegrator_to_value(integral, v):

    intdiffs = np.diff(integral)
    ns = np.round( intdiffs / (.5*(v[:-1]+v[1:])) )
    mask = ns>0.
    intmeans = np.divide(intdiffs, ns, out=np.zeros_like(ns, dtype=float), where=mask)
    intmeans = np.insert( intmeans, 0, 0. )
    return intmeans, intmeans>0.


def averageRCStelem(rcst, tlist):

    boardT = rcst['WFI_MCE_SRCS_BOARD_T']
    sphereT = rcst['WFI_MCE_SRCS_SPHERE_T']
    pd1 = rcst['WFI_MCE_SRCS_PD1_V']
    pd2 = rcst['WFI_MCE_SRCS_PD2_V']
    int1 = (rcst['WFI_MCE_SRCS_PD1_INTOUTPUT_UPPER']*(1<<32) + 
            rcst['WFI_MCE_SRCS_PD1_INTOUTPUT_LOWER'])*5./2**24
    int2 = (rcst['WFI_MCE_SRCS_PD2_INTOUTPUT_UPPER']*(1<<32) + 
            rcst['WFI_MCE_SRCS_PD2_INTOUTPUT_LOWER'])*5./2**24

    pd1intarr, intmask1 = RCSintegrator_to_value(int1, pd1)
    pd2intarr, intmask2 = RCSintegrator_to_value(int2, pd2)

    pd1raw = []
    pd2raw = []
    pd1int = []
    pd2int = []
    RCSboardT = []
    RCSsphereT = []

    for stt, ent in tlist:
        mask = (rcst['ObsTime']>stt) & (rcst['ObsTime']<ent)
        _, m, _ = sigma_clipped_stats(pd1[mask])
        pd1raw.append(m)
        _, m, _ = sigma_clipped_stats(pd2[mask])
        pd2raw.append(m)
        _, m, _ = sigma_clipped_stats(pd1intarr[mask], mask=~intmask1[mask])
        pd1int.append(m)
        _, m, _ = sigma_clipped_stats(pd2intarr[mask], mask=~intmask2[mask])
        pd2int.append(m)
        _, m, _ = sigma_clipped_stats(boardT[mask])
        RCSboardT.append(m)
        _, m, _ = sigma_clipped_stats(sphereT[mask])
        RCSsphereT.append(m)

    pd1raw = np.array(pd1raw)
    pd2raw = np.array(pd2raw)
    pd1int = np.array(pd1int)
    pd2int = np.array(pd2int)
    RCSboardT = np.array(RCSboardT)
    RCSsphereT = np.array(RCSsphereT)
        
    return pd1raw, pd2raw, pd1int, pd2int, RCSboardT, RCSsphereT

def getFPStelem(start_time, end_time, fps_csv, from_file=False):

    if not from_file:

        groups_yaml = os.getenv("ROMAN_TELEM_GROUPS")
        
        mnemonics = extract_mnemonics_from_groups(
            groups_config=groups_yaml,
            selected_groups=['temp_fps'],
            verbose=True,
        )

        timebuf = TimeDelta(1 * u.minute)

        df = query_telemetry(
            mnemonics=mnemonics,
            start_time=(Time(start_time, scale='utc')-timebuf).isot,
            end_time=(Time(end_time, scale='utc')+timebuf).isot,
            groups_config=groups_yaml,   # needed if temp_fps contains derived mnemonics
            selected_groups=['temp_fps'],
            combine=True,                # return one wide DataFrame indexed by ObsTime
            verbose=True,
            api_token=os.getenv("MAST_API_TOKEN"),  # if you use a token
        )

        fpst = Table.from_pandas(df, index=True)
        fpst.write(fps_csv, format='ascii.csv', overwrite=True)

    else:
        fpst = Table.read(fps_csv)

    fpst['ObsTime'] = Time(fpst['ObsTime'])

    return fpst

def averageFPStelem(fpst, tlist):

    mpaT = []
    sceaT = []
    FPSboardT = []
    u7caseT = []
    FPGAcaseT = []

    for stt, ent in tlist:
        mask = (fpst['ObsTime']>stt) & (fpst['ObsTime']<ent)
        _, m, _ = sigma_clipped_stats(fpst[mask]['WFI_MCU_B_MPA_T_CTRLSENS'])
        mpaT.append(m)
        _, m, _ = sigma_clipped_stats(fpst[mask]['WFI_MCU_B_SCEA_T_CTRLSENS'])
        sceaT.append(m)
        _, m, _ = sigma_clipped_stats(fpst[mask]['WFI_MCU_B_BOARD_T'])
        FPSboardT.append(m)
        _, m, _ = sigma_clipped_stats(fpst[mask]['WFI_MCU_B_U7_CASE_T'])
        u7caseT.append(m)
        _, m, _ = sigma_clipped_stats(fpst[mask]['WFI_MCU_B_FPGA_CASE_T'])
        FPGAcaseT.append(m)

    mpaT = np.array(mpaT)
    sceaT = np.array(sceaT)
    FPSboardT = np.array(FPSboardT)
    u7caseT = np.array(u7caseT)
    FPGAcaseT = np.array(FPGAcaseT)
        
    return mpaT, sceaT, FPSboardT, u7caseT, FPGAcaseT

