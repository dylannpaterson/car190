import numpy as np
import matplotlib.pyplot as plt
from astropy.table import Table
from astropy.stats import sigma_clip, sigma_clipped_stats
from astropy.convolution import convolve, CustomKernel
# from astropy.visualization import simple_norm
# import os
from os.path import expanduser
# import requests
import roman_datamodels as rdm
# from astroquery.mast import MastMissions
# from dotenv import load_dotenv
from romancal.dq_init import DQInitStep
from romancal.saturation import SaturationStep
# from romancal.linearity import LinearityStep
from romancal.refpix import RefPixStep
from romancal.wfi18_transient import WFI18TransientStep
from romancal.dark_decay import DarkDecayStep
# from romancal.ramp_fitting.ramp_fit_step import RampFitStep
# from romancal.assign_wcs import AssignWcsStep
# import tpStats as tps
import crds

# sce number of each scu
scenums = [20, 13, 97, 19, 2, 75, 21, 3, 87, 26, 16, 89, 17, 15, 5, 18, 12, 99]

convgains = 1. / np.array([
    1.98, 
    1.77,
    1.76,
    1.81,
    1.75,
    1.63,
    1.93,
    1.68,
    1.66,
    1.89,
    1.82,
    1.68,
    1.84,
    1.77,
    1.81,
    1.77,
    1.5,
    1.52
], dtype='float32')

# nominal good regions of each scu, where there are few patches of
# high inoperability 
SCUcorners = np.array([
    [[8*128, 8*128], [31*128, 31*128]], # SCU01
    [[0*128, 0*128], [32*128, 32*128]], # SCU02
    [[0*128, 0*128], [32*128, 32*128]], # SCU03
    [[0*128, 16*128], [16*128, 32*128]], # SCU04
    [[0*128, 0*128], [29*128, 32*128]], # SCU05
    [[0*128, 0*128], [32*128, 29*128]], # SCU06
    [[0*128, 0*128], [31*128, 32*128]], # SCU07
    [[1*128, 1*128], [30*128, 31*128]], # SCU08
    [[0*128, 0*128], [32*128, 32*128]], # SCU09
    [[0*128, 0*128], [32*128, 32*128]], # SCU10
    [[0*128, 0*128], [32*128, 32*128]], # SCU11
    [[0*128, 0*128], [32*128, 32*128]], # SCU12
    [[8*128, 6*128], [32*128, 32*128]], # SCU13
    [[0*128, 0*128], [32*128, 32*128]], # SCU14
    [[0*128, 0*128], [32*128, 32*128]], # SCU15
    [[0*128, 0*128], [32*128, 32*128]], # SCU16
    [[0*128, 0*128], [32*128, 32*128]], # SCU17
    [[0*128, 0*128], [32*128, 32*128]] # SCU18
])


def darkinit_romancal(fl):
    """ Function to run darks up until the linearity correction """
    data = rdm.open(fl)
    data = DQInitStep.call(data)   
    # data = SaturationStep(data)
    data = RefPixStep.call(data)
    data = DarkDecayStep.call(data)
    data = WFI18TransientStep.call(data)
                                           
    return data

def inl_correction(dm):

    nchan = 32
    channel_width = 128

    if not hasattr(inl_correction, "dn"):
    
        print('** Fetching INL correction params for first time **')

        dct = crds.getreferences(dm.get_crds_parameters(), reftypes=['integralnonlinearity'],
                                 observatory='roman')
        inl_model = rdm.open(dct['integralnonlinearity'])
        inl_correction.dn = inl_model.value.copy().astype("f4")

        corr = []
        for ichan in range(1, nchan+1):
            corr.append(inl_model.inl_table[
                f"science_channel_{ichan:02d}"]['correction'].copy())
        inl_correction.corr = np.array(corr)
        del corr
            
    result = np.zeros_like(dm.data)
    
    for ichan in range(0, nchan):
        channel_data = dm.data[..., ichan*channel_width:(ichan+1)*channel_width]
        result[..., ichan*channel_width:(ichan+1)*channel_width] = np.interp(
            channel_data, inl_correction.dn, inl_correction.corr[ichan])

    print('** INL Correction Computed **')
    
    return result
        

def flatinit_romancal(fl):
    """ Function to run darks up until the linearity correction """
    dat = rdm.open(fl)
    dat = DQInitStep.call(dat)   
    dat = SaturationStep.call(dat)
    dat = RefPixStep.call(dat)
    dat = DarkDecayStep.call(dat)
    dat = WFI18TransientStep.call(dat)
    dat.data += inl_correction(dat)
    
    return dat

def populate_states(info_csv, obsnum, expnum):

    cfa_info = Table.read(info_csv, format='ascii.csv')
    nact = len(cfa_info) #  number of "activities"

    # make activity number array and within-activity exposure number array 
    actn = np.arange(nact)
    act = np.array([val for arrval, ne in zip(actn, cfa_info['nexp']) for val in ne*[arrval]])
    exp_in_act = np.array([val for ne in cfa_info['nexp'] for val in np.arange(ne)])
    
    # unique fluxes of each bank
    bank1fl = np.unique(cfa_info['target_flux1'])
    bank2fl = np.unique(cfa_info['target_flux2'])
    # assign a bank1 and bank2 state to each activity
    bank1state = np.empty(nact, dtype=int)
    bank2state = np.empty(nact, dtype=int)
    total_target_flux = np.empty(nact)
    for i, (fl1, fl2) in enumerate( zip(cfa_info['target_flux1'], cfa_info['target_flux2']) ):
        bank1state[i] = np.where(fl1==bank1fl)[0][0]
        bank2state[i] = np.where(fl2==bank2fl)[0][0]
        total_target_flux[i] = fl1 + fl2
        
    # expand those states by number of exposures
    bank1stateexp = np.array([val for arrval, ne in zip(bank1state, cfa_info['nexp']) for val in ne*[arrval]])
    bank2stateexp = np.array([val for arrval, ne in zip(bank2state, cfa_info['nexp']) for val in ne*[arrval]])
    totflux_exp = np.array([val for arrval, ne in zip(total_target_flux, cfa_info['nexp']) for val in ne*[arrval]])

    # expand ma table strings and num_resultants by exposures
    matabexp = [val for arrval, ne in zip(cfa_info['MA_TABLE'], cfa_info['nexp']) for val in ne*[arrval]]
    nresexp = np.array([val for arrval, ne in
                        zip(cfa_info['RESULTANTS_PER_EXPOSURE'],
                            cfa_info['nexp']) for val in ne*[arrval]])

    # expand the obsnum from cfa_info into number of exposures
    obsexp = np.array([val for arrval, ne in zip(cfa_info['obs_num'], cfa_info['nexp']) for val in ne*[arrval]])
    # construct an expnum array from cfa_info where expnums increment
    # within and obsnum until a new obsnum (as in APT)
    changeinds = np.append(np.insert(np.where(np.diff(obsexp)!=0)[0]+1, 0, 0), len(obsexp))
    expobsexp = np.array([expn for ne in np.diff(changeinds) for expn in np.arange(1, ne+1)])

    # now batch provided obsnum and expnum with those generated from
    # cfa_info and fill state array
    st1 = []
    st2 = []
    fl = []
    matab = []
    nres = []
    actnum = []
    expnum_in_act = []
    
    for obsnum, expnum in zip(obsnum, expnum):
        wh = np.where( (obsexp==obsnum) & (expobsexp==expnum) )[0][0]
        st1.append(bank1stateexp[wh])
        st2.append(bank2stateexp[wh])
        fl.append(totflux_exp[wh])
        matab.append(matabexp[wh])
        nres.append(nresexp[wh])
        actnum.append(act[wh])
        expnum_in_act.append(exp_in_act[wh])
        
    return np.array(actnum), np.array(expnum_in_act), np.array(st1), np.array(st2), fl, matab, nres

def dilate_mask(bpix):

    ker = CustomKernel([[0, 1, 0], [1, 1, 1], [0, 1, 0]])
    
    return convolve(bpix, ker, normalize_kernel=False)>0


def medcube(imcube, xr=(0, 4096), yr=(0, 4096), tilesize=128,
            bf=None, bpix=None, rampsig=4., domean=False):

    # subtract bias frame from each frame if one is supplied
    if bf is not None:
        imcube -= bf.reshape(1, *bf.shape)
    
    # set the dimensions of a unit tile
    if not(isinstance(tilesize, tuple)):
        tilesize = (tilesize, tilesize)
        
    s = imcube.shape

    def reformat_cube(cube):

        result = cube[:, slice(*yr), slice(*xr)]
        result = result.reshape(s[0], s[1]//tilesize[1], tilesize[1], s[2]//tilesize[0], tilesize[0])
        result = np.moveaxis(result, 3, 2)
        return result.reshape(s[0], s[1]*s[2]//(tilesize[1]*tilesize[0]), tilesize[1]*tilesize[0])

    imcs = reformat_cube(imcube)
    
    bcube = np.zeros_like(imcube, dtype='bool')

    if bpix is not None:
        bcube |= bpix

    bss = reformat_cube(bcube)

    if rampsig is not None: # eliminate outlier ramps based on final value
        rampends = sigma_clip(imcs[-1], sigma=rampsig, stdfunc='mad_std')
        bss |= rampends.mask

    passfrac = np.sum(bss[0], axis=1, dtype='float32') / (tilesize[1]*tilesize[0])
    passfrac = passfrac.reshape(s[1]//tilesize[1], s[2]//tilesize[0])
    
    mn, md, _ = sigma_clipped_stats(imcs, mask=bss, axis=-1)
    meds = mn if domean else md
    meds = meds.reshape(s[0], s[1]//tilesize[1], s[2]//tilesize[0])
    
    return meds, passfrac

# def calc_ramprate(itime, iramp, read_noise, dn_per_e):

#     if (len(itime)!=len(iramp)) | (len(itime)<2) :
#         raise ValueError('Two inputs must have matching lengths > 2')

#     c1hi = iramp[1::2]
#     l1 = len(c1hi)
#     c1lo = iramp[::2][:l1]
#     t1hi = itime[1::2]
#     t1lo = itime[::2][:l1]

#     poiss1var = dn_per_e * (c1hi - c1lo) / (t1hi-t1lo)**2
#     tot1var = poiss1var + 2.*read_noise**2/(t1hi-t1lo)**2

#     rate1, wt1sum = np.average( (c1hi-c1lo)/(t1hi-t1lo), axis=0, weights=1./tot1var, returned=True)
#     var1 = 1./wt1sum

#     if len(itime)>2:

#         c2hi = iramp[2::2]
#         l2 = len(c2hi)
#         c2lo = iramp[1::2][:l2]
#         t2hi = itime[2::2]
#         t2lo = itime[1::2][:l2]
        
#         poiss2var = dn_per_e * (c2hi - c2lo) / (t2hi-t2lo)**2
#         tot2var = poiss2var + 2.*read_noise**2/(t2hi-t2lo)**2

#         rate2, wt2sum = np.average( (c2hi-c2lo)/(t2hi-t2lo), axis=0, weights=1./tot2var, returned=True)
#         var2 = 1./wt2sum

#         cv12 = -read_noise**2 / (wt1sum*wt2sum) \
#             * np.sum( 1./( (t1hi-t1lo)[:l2]*(t2hi-t2lo) ) / (tot1var[:l2]*tot2var) )

#         # now invert covariance matrix

#         g = (1./(var1*var2 - cv12**2))*np.array([ [var2, -cv12], [-cv12, var1] ])

#         var = 1./ np.sum(g)

#         rate = var * np.sum( g @ np.array([rate1, rate2]) )

#         return rate, var

#     else:

#         return rate1, var1

def calc_ramprate(itime, iramp, read_noise, dn_per_e):

    rateguess = (iramp[-1]-iramp[0]) / (itime[-1]-itime[0])
    if rateguess<0.:
        rateguess = 0.

    c1hi = iramp[1::2]
    l1 = len(c1hi)
    c1lo = iramp[::2][:l1]
    t1hi = itime[1::2]
    t1lo = itime[::2][:l1]

    poiss1var = dn_per_e * rateguess / (t1hi-t1lo)
    tot1var = poiss1var + 2.*read_noise**2/(t1hi-t1lo)**2
    
    var1 = 1. / np.sum( 1./tot1var  )
    fac1 = ( (1./(t1hi-t1lo)) / tot1var ) * var1 
    rate1 = np.sum( (c1hi-c1lo)*fac1 )
    
    if len(itime)>2:
    
        c2hi = iramp[2::2]
        l2 = len(c2hi)
        c2lo = iramp[1::2][:l2]
        t2hi = itime[2::2]
        t2lo = itime[1::2][:l2]
    
        poiss2var = dn_per_e * rateguess / (t2hi-t2lo)
        tot2var = poiss2var + 2.*read_noise**2/(t2hi-t2lo)**2
    
        var2 = 1. / np.sum( 1./tot2var  )
        fac2 = ( (1./(t2hi-t2lo)) / tot2var ) * var2 
        rate2 = np.sum( (c2hi-c2lo)*fac2 )
    
        cv12 = -read_noise**2 * np.sum( fac1[:l2] * fac2 )
    
        # now invert covariance matrix
        g = (1./(var1*var2 - cv12**2))*np.array([ [var2, -cv12], [-cv12, var1] ])
    
        var = 1./ np.sum(g)
    
        rate = var * np.sum( g @ np.array([rate1, rate2]) )
    
        return rate, np.sqrt(var)

    else:

        return rate1, np.sqrt(var1)


def nlCFA(al, *args):

    # this function picks up two things from outer namespace:
    # fluxmat and nlcfa_biascorr.  So, those must be defined prior
    # to calling it

    global fluxarr, mgood, Bmat
    
    usig = args[0]
    usig_err = args[1]
    mgood = (usig>0.) & (usig_err>0.)
    usig = usig[mgood]
    usig_err = usig_err[mgood]

    Bmat = fluxmat[mgood]
    fitmask = np.any(Bmat>0., axis=0)
    Bmat = Bmat[:, fitmask]

    wt = 1. / ( usig_err * ( 1. - al*(1.+np.log(usig)) ) )

    yvec = wt * usig*(1.-al*np.log(usig))

    if nlcfa_biascorr:
        yvec += wt * .5*al*usig_err**2 / usig
    
    Bmat = Bmat * wt.reshape(-1, 1)

    fitresult = np.linalg.lstsq(Bmat, yvec, rcond=None)
    fluxarr = fitresult[0]

    res = yvec - Bmat@fluxarr

    return res
