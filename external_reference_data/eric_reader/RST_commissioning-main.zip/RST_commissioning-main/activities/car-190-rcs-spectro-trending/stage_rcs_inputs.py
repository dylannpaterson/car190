"""
Stage per-SCA products as MPA mosaics plus a telemetry CSV, then compile them
into an RCS trend cube with ``compile_rcs_trend.py`` left completely unmodified.

The point of not touching the compiler is that case 1 -- the existing
``TVAC_HOB_OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA.h5`` -- was produced by that
exact code. A three-way comparison whose purpose is isolating *input data*
differences must not also vary the code that packages them. So instead of
adapting ``process_trending_run``, we hand it the directory shape it already
globs for:

    <root_data>/<directory_path>/<sub>/one_file.csv
    <root_data>/<directory_path>/<sub>/mosaics/<visit_id>*

and let it do the rest. The CSV is not a fabrication: every value in it is read
back out of the ``hdf5_telemetry`` blob embedded in the per-SCA products, so it
doubles as a human-readable audit trail of the recovered housekeeping.

Layout written under /mnt/roman-science-east-2/eswitzer/RCS_trend:

    car190_staging/<case>/TVAC_HOB/OTP00775_..._MCEA/stability_check/
        rcs_telemetry.csv
        activity_table.csv          (full provenance; the compiler ignores it)
        mosaics/<visit_id>_act<N>_<key>_mosaic.fits
        mosaics/sca_id_map_r4.fits
    car190_derived/<case>/TVAC_HOB_OTP00775_..._MCEA.h5

Cases are staged under separate roots so that
``directory_path.replace('/', '_') + '.h5'`` reproduces the original file name
without ever colliding with the original file.
"""
import argparse
import os
import sys
import time

import numpy as np
import pandas as pd

import form_mpa_mosaic as fm
import read_per_sca as rps
from compile_rcs_trend import load_from_hdf5, process_trending_run

RCS_TREND = "/mnt/roman-science-east-2/eswitzer/RCS_trend"
ORIGINAL_H5 = os.path.join(
    RCS_TREND, "TVAC_HOB_OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA.h5")
STAGING_ROOT = os.path.join(RCS_TREND, "car190_staging")
DERIVED_ROOT = os.path.join(RCS_TREND, "car190_derived")

DIRECTORY_PATH = "TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA"
SUB = "/stability_check/"

CASES = {
    "scipa": {
        "kind": "scipa",
        "root": "/mnt/roman-science-internal/romancal_l2_outputs/tvac/scipa/"
                "ChromaticStability/OTP00775_RCSEChrmStbA_SCIPAc_R17",
        "label": "romancal L2 _cal.asdf",
    },
    "ql": {
        "kind": "ql",
        "root": "/mnt/roman-science-east-2/ql_output/Program_00123",
        "label": "quicklook _slope.fits.fz",
    },
}

R = 4
REBIN = 5
# Activity index -> the array name process_trending_run will assign. Recorded in
# the mosaic headers so nobody has to rediscover that LED<n> is an activity
# index rather than a hardware LED id.
ACTIVITY_TO_KEY = {1: "DARK", 2: "LED1", 3: "LED2", 4: "LED3",
                   5: "LED4", 6: "LED5", 7: "LED6"}


def _run_label(table, program=None):
    """Compose a run label in ``process_rcs_trending.run_label``'s format.

    ``CAR190_<program>_<execution_plan>_<pass>_<segment>_<YYYYMMDD>`` -- the
    ``PPPPPCCAAASSS`` prefix of the first activity's 19-digit visit id plus
    the run's earliest start date. Reimplemented here rather than imported:
    ``process_rcs_trending`` imports constants from this module, so importing
    back would be circular, and its version takes a list of activity dicts
    with a ``staging_id``/``id_synthetic`` fallback that this module's
    per-activity ``visit_id`` never needs (every activity here already has a
    distinct 19-digit id -- see :func:`read_per_sca.discover_activities`).

    Only used for a ``--root`` that points away from the fixed OTP00775 case
    (see :func:`stage_case`), so this never needs to be exactly the TVAC name.
    """
    prefix = str(table["visit_id"].iloc[0])[:13]
    program_digits = f"{int(program):05d}" if program is not None else prefix[:5]

    starts = pd.to_datetime(table["SC Timestamp"], errors="coerce", utc=True)
    date = "unknown" if starts.isna().all() else starts.min().strftime("%Y%m%d")

    return (f"CAR190_{program_digits}_{prefix[5:7]}_{prefix[7:10]}_"
            f"{prefix[10:13]}_{date}")


def stage_case(case, r=R, orientation=fm.DEFAULT_ORIENTATION, apply_dq=True,
               dry_run=False, root=None, pass_number=None):
    """Write the mosaics, the CSV and the provenance table for one case.

    ``root`` overrides ``CASES[case]["root"]``, so the same staging call can
    be pointed at a different per-SCA source tree (e.g. a fresh quicklook
    rerun under a different directory) without editing this file. ``pass_number``
    is only needed for a live flight quicklook root where the activity
    sequence repeats across passes -- see :func:`read_per_sca.discover_activities`.

    The output directory/h5 name is the fixed ``TVAC_HOB/OTP00775_...`` path
    only for the default, no-``root`` case -- ``compare_rcs_h5.py`` and
    :func:`check_telemetry_against_original` both key off that exact name for
    the canonical TVAC comparison. Any ``root`` override instead gets a
    :func:`_run_label`-derived name, matching ``process_rcs_trending.py``'s
    convention as closely as this table shape allows, so a staged flight run
    never collides with, or is mistaken for, the TVAC one. Returns
    ``(table, directory_path)`` so the caller can pass the same name to
    :func:`compile_case`.
    """
    config = CASES[case]
    kind, source_root = config["kind"], root or config["root"]
    geom = fm.load_geometry()

    activities = rps.discover_activities(source_root, kind, pass_number=pass_number)
    table = rps.build_activity_table(activities)
    directory_path = DIRECTORY_PATH if root is None else _run_label(table)

    stage_dir = os.path.join(STAGING_ROOT, case, directory_path,
                             SUB.strip("/"))
    mosaic_dir = os.path.join(stage_dir, "mosaics")

    print(f"\n===== staging case '{case}' ({config['label']}) =====")
    print(f"  source : {source_root}")
    print(f"  target : {stage_dir}")

    missing = sorted(set(range(1, 8)) - set(activities))
    if missing:
        raise ValueError(f"case {case}: missing activities {missing}")
    visit_ids = list(table["visit_id"])
    if len(set(visit_ids)) != len(visit_ids):
        raise ValueError(f"case {case}: visit ids are not unique: {visit_ids}")

    for _, row in table.iterrows():
        print(f"  activity {int(row['activity_number'])} "
              f"visit {row['visit_id']} n_sca={int(row['n_sca'])} "
              f"wlen={row['wavelength_nm']}")

    if dry_run:
        print("  [dry run] no files written")
        return table, directory_path

    os.makedirs(mosaic_dir, exist_ok=True)
    reader = rps.READERS[kind]

    for _, row in table.iterrows():
        activity = int(row["activity_number"])
        entry = activities[activity]
        key = ACTIVITY_TO_KEY[activity]
        start = time.time()

        # Read and bin one SCA at a time; the full-resolution arrays are 128 MB
        # each and there is no reason to hold more than one.
        binned = {}
        for sca in sorted(entry["frames"]):
            frame, _, _ = reader(entry["frames"][sca], apply_dq=apply_dq)
            binned[sca] = fm.bin_frame(fm.pad_to_4096(frame), r)

        mosaic = fm.build_mosaic(binned, r=r, geom=geom, dtype=np.float32,
                                 orientation=orientation, prebinned=True)
        scas = sorted(binned)
        out = os.path.join(
            mosaic_dir, f"{row['visit_id']}_act{activity}_{key}_mosaic.fits")
        fm.write_mosaic_fits(
            mosaic, out, r=r, scas=scas,
            meta={
                "CASE": (case, "staging case"),
                "SRCKIND": (kind, "per-SCA product type"),
                "SRCROOT": (source_root, "per-SCA source tree"),
                "ORIENT": (orientation, "SCA array orientation convention"),
                "APPLYDQ": (bool(apply_dq), "DQ-flagged pixels set to NaN"),
                "ACTNUM": (activity, "OTP activity number"),
                "H5KEY": (key, "array name in the compiled trend h5"),
                "WLEN": (float(row["wavelength_nm"])
                         if np.isfinite(row["wavelength_nm"]) else -99.0,
                         "[nm] approx LED wavelength"),
                "WLENSRC": (str(row["wavelength_source"]), "wavelength origin"),
                "HWLED": (rps.enabled_led(row), "hardware BANK2SEL LED enabled"),
                "VISITID": (str(row["visit_id"]), "19-digit visit id"),
                "EXPTIME": (float(row["exposure_time"]), "[s] exposure time"),
                "STARTTIM": (str(row["SC Timestamp"]), "activity start time"),
                "TARGTYPE": (str(row["targettype"]), "WFI OTP target type"),
            })
        finite = np.isfinite(mosaic)
        print(f"    act{activity} {key:5s} -> {os.path.basename(out)}  "
              f"{len(scas)} SCAs  finite={finite.mean():.5f}  "
              f"median={np.nanmedian(mosaic):.4f}  ({time.time()-start:.0f}s)")

    # One label array per case: which SCA each mosaic pixel came from. The
    # original mosaics carried no provenance at all, so per-SCA statistics on
    # them had to be inferred from geometry; this makes it explicit.
    union = sorted({s for a in activities.values() for s in a["frames"]})
    id_map = fm.build_sca_id_map(union, r=r, geom=geom)
    fm.write_mosaic_fits(id_map.astype(np.float32),
                         os.path.join(mosaic_dir, f"sca_id_map_r{r}.fits"),
                         r=r, scas=union,
                         meta={"CONTENT": ("SCA id per pixel, 0 = gap", "")})

    # process_trending_run raises if it finds more than one CSV here, so the
    # full provenance table goes one directory up, outside its glob.
    csv_path = os.path.join(stage_dir, "rcs_telemetry.csv")
    compiler_columns = (["SC Timestamp", "exp_path_done"] + rps.HK_COLUMNS
                        + rps.LED_SELECT_COLUMNS)
    table[compiler_columns].to_csv(csv_path, index=False)
    provenance = os.path.join(STAGING_ROOT, case, directory_path,
                              "activity_table.csv")
    table.to_csv(provenance, index=False)
    print(f"  wrote {csv_path} ({len(table)} rows, "
          f"{len(compiler_columns)} compiler columns)")
    print(f"  wrote {provenance} (provenance, outside the compiler's glob)")

    return table, directory_path


def check_telemetry_against_original(table, case, directory_path=DIRECTORY_PATH):
    """Confirm the recovered telemetry reproduces the original cube's scalars.

    This is the strongest available check on the CSV reconstruction, and it runs
    on telemetry alone -- before any mosaic is involved -- so a failure here
    localises the problem precisely. Only meaningful for the fixed OTP00775
    case: ``ORIGINAL_H5`` is that specific TVAC run, so a ``--root``-staged
    run (a different ``directory_path``) has nothing to compare against.
    """
    if directory_path != DIRECTORY_PATH:
        print("  non-default root; skipping telemetry cross-check against "
              "the OTP00775 original")
        return {}
    if not os.path.exists(ORIGINAL_H5):
        print("  original h5 unavailable; skipping telemetry cross-check")
        return {}

    original, _ = load_from_hdf5(ORIGINAL_H5)
    derived = {
        "COBA_temp": np.nanmedian(table["WFI_COBA_WTSC10P_K"]),
        "RCS_Sphere_temp": np.nanmedian(table["WFI_MCE_SRCS_SPHERE_T"] + 273.15),
        "RCS_Board_temp": np.nanmedian(table["WFI_MCE_SRCS_BOARD_T"] + 273.15),
        "MPA_A_temp": np.nanmedian(table["WFI_MCU_A_MPA_CSENS_FPSSEN_K"]),
        "MPA_B_temp": np.nanmedian(table["WFI_MCU_B_MPA_CSENS_FPSSEN_K"]),
        "ACM_LVDT": np.array([np.nanmedian(table[f"WFI_MCE_LVDT_ACM_{i}"])
                              for i in range(1, 7)]),
        "RCS_forward_voltage": table["WFI_MCE_SRCS_BANK2_LED_V"].to_numpy(),
        "RCS_photodiode": (table["WFI_MCE_SRCS_PD2_V"].to_numpy()
                           - table["WFI_MCE_SRCS_PD2_V"].to_numpy()[0]),
    }

    print(f"  telemetry cross-check ({case} vs original h5):")
    report = {}
    for key, value in derived.items():
        reference = original[key]
        ok = np.allclose(np.asarray(value, float), np.asarray(reference, float),
                         rtol=0, atol=1e-9, equal_nan=True)
        report[key] = ok
        if np.ndim(value) == 0:
            print(f"    {key:22s} {'OK ' if ok else 'DIFF'} "
                  f"diff={float(value) - float(reference):+.9f}")
        else:
            worst = np.nanmax(np.abs(np.asarray(value, float)
                                     - np.asarray(reference, float)))
            print(f"    {key:22s} {'OK ' if ok else 'DIFF'} max|diff|={worst:.3e}")

    # timestamp is known not to be recoverable: the original holds a telemetry
    # sample time that matches none of the seven activity start times.
    staged = str(table["SC Timestamp"].iloc[3])
    print(f"    {'timestamp':22s} EXPECTED-DIFF original={original['timestamp']!r} "
          f"staged(activity 4 start)={staged!r}")
    report["timestamp"] = None

    return report


def compile_case(case, directory_path=DIRECTORY_PATH, out_root=DERIVED_ROOT):
    """Run the untouched compiler over a staged case.

    ``directory_path`` must match whatever :func:`stage_case` used -- the
    fixed OTP00775 path by default, or its :func:`_run_label` for a
    ``--root``-staged run -- since that is also the compiled h5's name.
    """
    root_data = os.path.join(STAGING_ROOT, case) + "/"
    out_path = os.path.join(out_root, case) + "/"
    os.makedirs(out_path, exist_ok=True)

    print(f"\n----- compiling case '{case}' with compile_rcs_trend -----")
    process_trending_run(directory_path, sub=SUB, bank="BANK2", stamp_pos=3,
                         rebin=REBIN, root_data=root_data, subtract_dark=True,
                         out_path=out_path)

    return out_path + directory_path.replace("/", "_") + ".h5"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=list(CASES) + ["both"], default="both")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--no-dq", action="store_true")
    parser.add_argument("--skip-compile", action="store_true")
    parser.add_argument("--orientation", default=fm.DEFAULT_ORIENTATION,
                        choices=fm.ORIENTATIONS)
    parser.add_argument("--root", default=None,
                        help="override the per-SCA source root for --case "
                             "(requires a single --case, not 'both')")
    parser.add_argument("--pass", dest="pass_number", type=int, default=None,
                        help="which pass to stage, for a live flight quicklook "
                             "--root where the activity sequence repeats "
                             "(requires a single --case, not 'both')")
    args = parser.parse_args()
    if args.root and args.case == "both":
        raise SystemExit("--root requires a single --case, not 'both'")
    if args.pass_number is not None and args.case == "both":
        raise SystemExit("--pass requires a single --case, not 'both'")

    cases = list(CASES) if args.case == "both" else [args.case]
    for case in cases:
        table, directory_path = stage_case(
            case, orientation=args.orientation, apply_dq=not args.no_dq,
            dry_run=args.dry_run, root=args.root, pass_number=args.pass_number)
        if args.dry_run:
            continue
        check_telemetry_against_original(table, case, directory_path)
        if not args.skip_compile:
            path = compile_case(case, directory_path)
            dictionary, led_arrays = load_from_hdf5(path)
            print(f"  compiled {path}")
            for key in sorted(led_arrays):
                arr = led_arrays[key]
                print(f"    {key}: {arr.shape} {arr.dtype} "
                      f"NaNfrac={np.isnan(arr).mean():.5f} "
                      f"median={np.nanmedian(arr):.4f}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
