#!/bin/bash
#SBATCH --job-name=rcs-plan
#SBATCH --time=02:00:00
#SBATCH --output=batch/logs/slurm-%j.out
#
# Rung 1 of the staging ladder: resolve every manifest row's MAST product
# names into a cached query plan under <staging_root>/plans/, and stream
# nothing. Rung 2 is submit_manifest.sbatch with USE_PLAN=1, which then
# issues no listing calls at all.
#
# Why this exists as a separate submission: the listing API -- not bandwidth
# -- is what fails under concurrent load (one listing request per matched
# dataset, degrading to a response with no 'filename' column). Splitting it
# out means the fragile step runs once per pass at low concurrency, and the
# robust step runs wide. A transient listing failure then costs a cheap
# replan instead of re-downloading 3.75 GB.
#
# Deliberately low concurrency. Run it 4-way, and do not widen it:
#
#   sbatch --nodes=1 --ntasks-per-node=4 batch/submit_plan.sbatch \
#       <repo_root> <manifest.csv> <token_file> <staging_root> <out_dir> \
#       [n_tasks]
#
# <out_dir> is required but unused -- --plan-only writes no .h5. Pass the same
# directory the streaming phase will use so the two submissions stay legible
# side by side in the logs.
#
# Then inspect coverage before streaming:
#
#   ls batch/status/*.degraded | wc -l          # passes MAST has not indexed
#   grep -h DEGRADED batch/status/*.degraded    # and by how much
#
# Each plan holds product *names*, never presigned URLs, so it does not
# expire and can be reused indefinitely -- see rcs_mast.py's module docstring
# for the measurement behind that. What a plan *is* a snapshot of is coverage
# at the moment it was built, which is why a degraded pass is worth replanning
# later rather than abandoning.
set -euo pipefail

export REPO_ROOT="${1:?usage: sbatch --nodes=1 --ntasks-per-node=4 submit_plan.sbatch <repo_root> <manifest.csv> <token_file> <staging_root> <out_dir> [n_tasks]}"
export MANIFEST="${2:?manifest csv required}"
export TOKEN_FILE="${3:?token file required}"
export STAGING_ROOT="${4:?staging root required}"
export OUT_DIR="${5:?out dir required}"
export N_TASKS="${6:--1}"

# This submission plans and only plans; USE_PLAN is cleared so an exported
# leftover from a previous streaming submission cannot turn this into a no-op.
export PLAN_ONLY=1
export USE_PLAN=""

# Optional, from the submitting environment (sbatch exports it by default):
#   MIN_SCAS      lit SCAs required per activity before a plan counts as
#                 complete; below it the row is recorded degraded (default 18)
#   QUERY_LEASES  concurrent listing calls allowed across all ranks sharing
#                 STAGING_ROOT -- a second cap underneath --ntasks-per-node,
#                 and the one that holds when several submissions overlap
export MIN_SCAS="${MIN_SCAS:-}"
export QUERY_LEASES="${QUERY_LEASES:-}"

# Planning writes no pixels, so BIN_FACTOR and FORCE have nothing to act on
# here. Cleared rather than passed through, so a value exported for the
# streaming submission cannot look as though it influenced the plan.
export BIN_FACTOR=""
export FORCE=""

srun bash "$REPO_ROOT/batch/worker_entrypoint.sh"
