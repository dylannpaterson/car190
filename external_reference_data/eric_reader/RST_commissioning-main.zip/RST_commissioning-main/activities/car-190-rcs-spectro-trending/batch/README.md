# SLURM batch flow

Runs many `process_rcs_trending.py` passes in parallel across a SLURM
allocation. One CSV manifest lists every task; the allocation's node/task
count decides how many run at once. See the main
[README.md](../README.md#batch-processing-with-slurm) for the step-by-step
commands -- this file is about how the pieces fit together and, specifically,
how a rerun decides what to redo.

Staging runs as a two-rung ladder -- a narrow `--plan-only` sweep, then a wider
streaming pass over the cached plans -- because the step that fails under
concurrent load is the MAST *listing* API, not bandwidth. See
[The staging ladder](#the-staging-ladder) for the commands and the reasoning.

**For routine intake, use `refresh.py` rather than these pieces directly.**
`python batch/refresh.py status` compares the archive, the manifest and the
trend tree, and every subcommand ends with the exact next command to run
(`probe` -> `label` -> `pull [--submit]` -> `check`). `pull` writes
`run_manifest_new.csv`, only the rows lacking a complete product, so rung 1 plans
nothing it does not need, and prints both chained sbatch rungs; `--submit`
submits them, and `--local N` runs the same two rungs on this machine with N
ranks each (logs in `logs_local/`). `check` then reports every pulled row's
outcome from `status/`, so the `ls status/*` listings below are for a
whole-manifest SLURM run. `seed` copies a whole trend tree into an empty new
root, verified, which is how a tree generation or a deployment starts.

## Pieces

* **`run_manifest.csv`** (built by `make_manifest.py`) -- one row per
  `(program, execution_plan, pass, decon_cycle, blank_dark, mce_side)` task.
  `mce_side` is `A`, `B` or blank; the worker forwards a value as
  `--mce-side`, and a blank forwards nothing (stage 1 then records
  `assumed:flight-side-A`, as every pre-swap row was staged). Why each row
  has its labels is in [../MANIFEST.md](../MANIFEST.md). Row order
  is fixed (sorted by program/execution_plan/pass), which matters for `-n`
  and rank slicing below. **Build it with `--from-survey`**, which asks the
  archive which passes exist; see "Keeping the manifest honest".
* **`refresh.py`** -- the intake driver: `status`, `probe`, `label`, `pull`,
  `check` (and `seed`, once per tree), each printing what it found and what to
  run next. Wraps the pieces
  below; nothing it does is unavailable by hand.
* **`side_witness.py`** -- read-only. Per epoch, the LED map and the
  photodiode side witnesses, from `--pd-only` sidecars or from products, in
  PD-stream time order; `--strict` exits 2 when a product's `mce_side`
  contradicts its LED map. The evidence for the manifest's `mce_side`.
* **`run_manifest_worker.py`** -- one rank's slice of the manifest. Invoked
  once per SLURM task (`--rank $SLURM_PROCID --world-size $SLURM_NTASKS`), or
  directly with `--rank 0 --world-size 1` for a local smoke test.
* **`worker_entrypoint.sh`** -- what `srun` actually launches. Reads the MAST
  token out of the token file, then execs `run_manifest_worker.py`, forwarding
  `$FORCE`, `$QUERY_DELAY_SECONDS`, `$MIN_SCAS`, `$QUERY_LEASES`,
  `$PLAN_ONLY` and `$USE_PLAN` if set. It always passes `--stagger`.
* **`submit_plan.sbatch`** -- rung 1: cache a query plan per row and stream
  nothing. Run it 4-way.
* **`submit_manifest.sbatch`** -- rung 2: the streaming submission. Takes repo
  root, manifest path, token file, staging root, out dir, `n_tasks`, and
  (optional) `query_delay_seconds` as positional args and exports them as env
  vars for `worker_entrypoint.sh`; `--nodes`/`--ntasks-per-node` are passed on
  the `sbatch` command line, not baked into the script, so parallelism is a
  submission-time knob. Set `USE_PLAN=1` to stream from rung 1's plans.
* **`logs/<stem>.log`** -- full stdout+stderr for one manifest row, written by
  the worker after `process_rcs_trending.py` exits. `<stem>` is
  `{CAR-label}_{program:05d}_{execution_plan:02d}_{pass:03d}_{decon_cycle}`.
* **`status/<stem>.{done,planned,failed,skipped,degraded}`** -- one file per
  row, written by the worker: empty for `done`/`planned`/`skipped`, the
  `DEGRADED:` line for `degraded`, or `returncode N` plus the last 20 lines of
  stderr for `failed`. `done` means a product was written; a successful
  `--plan-only` row is `planned` instead, so that `ls status/*.done | wc -l`
  does not count cached plans as finished products.

## Task assignment

Each worker invocation is told `--n-tasks` (how many manifest rows, in file
order, are in scope for this submission; `-1` = all) and `--rank`/
`--world-size` (this task's index and the allocation's total task count).
The worker takes `selected = manifest[:n_tasks]` then
`mine = selected[rank::world_size]` -- a static, index-based round-robin
split. There's no dynamic work-stealing: if one rank's rows are slower than
another's, that rank just finishes later, and idle ranks don't pick up its
remainder within the same submission.

## What actually gates a rerun

For each row assigned to it, the worker's only skip check is
`_already_done()`: a glob for
`{out_dir}/{CAR-label}_{program:05d}_{execution_plan:02d}_{pass:03d}_*.h5`.
If that glob matches anything, the row is skipped (status written as
`skipped`); otherwise `process_rcs_trending.py` runs for real.

**`status/` and `logs/` are output, not input.** They exist for a human (or
`ls`/`cat`) to check progress and diagnose failures -- the worker never reads
them to decide what to do. Consequences:

* A row whose `.h5` never got written -- because it previously failed, was
  never attempted, or its output was deleted -- reruns automatically the next
  time you resubmit, regardless of what `status/<stem>.failed` says. You
  don't need to clear or touch `status/`/`logs/` before retrying; just fix
  whatever caused the failure and rerun the same submission command.
  `process_rcs_trending.py` itself has its own idempotency for a given
  `--out-dir` (see the main README), so this glob check is a cheap
  first-pass filter on top of that.
* Conversely, a stale `status/<stem>.done` next to a `.h5` you manually
  deleted doesn't stop a rerun -- the glob is what's checked, not the status
  file.
* `_write_status()` removes any other-suffix status file for that `<stem>`
  before writing the new one, so `status/` always reflects the *last*
  attempt for a row, not history across attempts. `logs/<stem>.log` is
  overwritten the same way -- it's the last attempt's stdout+stderr, not an
  append-only log.
* `--force` (plumbed through `worker_entrypoint.sh` as `$FORCE`, or passed
  directly to `run_manifest_worker.py`) skips the `_already_done()` check
  entirely and always reruns every assigned row.
* Under `--plan-only` the `_already_done()` glob is skipped, because that mode
  writes no `.h5` at all -- a plan sweep over a directory that already held
  products would otherwise skip every row and cache nothing.

**The gap this check still has.** `_already_done()` asks only whether an `.h5`
exists, not whether it is *complete*. A product written from a short listing --
2 of 18 SCAs -- satisfies the glob and so blocks its own retry forever. That is
how `rcs_trend_batch` ended up with 79 of 91 products holding 1-6 SCAs and no
way to notice. Two things address it:

* **Prevention**, in place now: `--min-scas` (default 18) is checked against
  the query *plan* before anything streams, so a short listing costs one cheap
  query and leaves no product behind. The row is recorded `degraded` and exits
  3, which the worker treats as neither success nor crash -- `ls
  batch/status/*.degraded` is the retry list. Degraded rows deliberately do not
  fail the rank, since a nonzero exit would make SLURM report a normal plan
  sweep as a broken job.
* **Detection**, for products that already exist: `batch/triage_products.py`
  reports per-product SCA coverage over a directory. Making `_already_done()`
  itself coverage-aware is still to come.

## Keeping the manifest honest

```bash
.venv/bin/python batch/make_manifest.py --from-survey --dry-run \
    --default-decon-cycle decon2 --default-mce-side B
.venv/bin/python batch/make_manifest.py --relabel --program 1039 \
    --execution-plan 3 --passes 53-57 --mce-side A --dry-run
.venv/bin/python batch/make_manifest.py --self-test     # no network
```

This surveys both programs (or `--programs 1039`, 2.5 min rather than 11) and
prints the diff against the current manifest in both directions, writing
nothing. Drop `--dry-run` to apply it. Both directions matter and they fail
differently: a **stale** row (a pass that does not exist) fails with "no
products matched" and leaves a `status/*.failed` marker that looks exactly like
the overload failures you are trying to be rid of, while a **missing** row is
work that is silently never staged and that nothing reports.

Neither the decon cycle nor the MCE side can be surveyed -- they are operational
knowledge about when the instrument was warmed and which MCE drove it, not
archive metadata. So rows already in the manifest keep the labels they have,
including a blank side, and only genuinely new passes take the two defaults.
Both defaults are required as soon as any new pass is found, and the tool lists
which passes took them. `--relabel` is the only way an existing row's labels
change; it prints each before -> after and refuses a pass the manifest does not
hold. `side_witness.py` reads the evidence for the side; the procedure is the
[../DATA_PULL.md](../DATA_PULL.md).

Two ways the survey could once delete good rows, both now refused:

* **A failed query reads as an empty program.** `rcs_mast.survey_rows` returns
  an empty frame on an HTTP error, with only a WARNING, so every existing row of
  that program read as stale. `make_manifest.py` now refuses to write when a
  level comes back empty for a program the manifest already holds.
* **`--programs` dropped every program it was not given.** Stale was "known and
  not surveyed", so `--programs 1039` would have dropped all 126 CAR-216 rows.
  Rows of an unsurveyed program are now carried over unchanged, and only a
  surveyed program's rows can be stale.

**A trap worth knowing about, because it does not look like one.** A single
`query_criteria` response is capped at 5000 rows, announced only as a
`MaxResultsWarning` -- invisible in any log that filters warnings. A truncated
whole-program survey does not read as an error; it reads as *a program with
fewer passes*. Surveyed unpaginated on 2026-10-03 it reported CAR-190 ending at
pass 48 and CAR-216 having 28 plan-2 passes and no plan 3, which would have
condemned 98 perfectly good manifest rows as nonexistent. `_survey_rows` now
pages with explicit offsets and raises rather than return a possibly-truncated
survey. The paged CAR-216 counts close to the file -- 15 and 10 exposures x 18
detectors x 126 passes = 34020 L1 and 22680 L2 -- which is what establishes that
offset paging neither duplicates nor drops rows.

The passes the manifest covers, and why any pass number is absent, are in
[../MANIFEST.md](../MANIFEST.md)'s *Current state* table.

## Throttling MAST

One pass streams ~126 per-SCA files from MAST one at a time
(`process_rcs_trending.py`'s `stage_run()`), and a full-scale submission runs
many passes concurrently. **The binding constraint is the listing API, not
bandwidth** -- see "The staging ladder" below, which is the main defence. These
knobs tune the rate underneath it:

* **Start-time stagger** (`--stagger`, always passed by
  `worker_entrypoint.sh`): each rank sleeps a rank-dependent interval before
  its first row, spread over a window **scaled by `--world-size`**. This
  replaced a flat `RANDOM % 61` in the entrypoint, which was the same 61s
  window regardless of fan-out width -- so widening 8-way to 32-way quadrupled
  the listing *rate* into an unchanged window, which is precisely the overload
  it was meant to prevent. Scaling the window keeps the rate constant as the
  fan-out widens. Skipped automatically under `USE_PLAN`, which issues no
  listing calls at all.
* **`--query-leases`** (default 4): a lock-directory lease in
  `<staging_root>/plans/.query_lease/` capping how many ranks may be inside a
  *listing* call at once, while streaming stays fully parallel. This is a
  second cap underneath `--ntasks-per-node`, and the one that still holds when
  two submissions overlap on the same staging root. A lease held longer than
  `--query-lease-timeout` (900s) is stolen with a warning, so a rank that dies
  holding one cannot block the fan-out.
* **`--query-delay-seconds`** (`process_rcs_trending.py`, default 1.0s,
  configurable end-to-end): sleeps this long before each per-SCA fetch after
  the first, inside every rank, for the life of the submission. This spaces out
  the sustained per-rank *streaming* rate, not the startup burst.

To change it for a submission, add it as the 7th positional arg to
`submit_manifest.sbatch` (6th, `n_tasks`, must also be given -- pass `-1` for
"all rows" if you're not otherwise limiting the run):
```bash
sbatch --partition=cpu-lg --nodes=4 --ntasks-per-node=8 batch/submit_manifest.sbatch \
    "$(pwd)" batch/run_manifest.csv ../../variables.env \
    /data/eswitzer/rcs_trend_batch/ /data/eswitzer/rcs_trend_batch/ -1 3
```
raises it to 3s/file. Leaving it unset (the normal case) lets
`process_rcs_trending.py`'s own default (1.0s) apply. For the local smoke
test (`run_manifest_worker.py` run directly), pass
`--query-delay-seconds <N>` the same way you'd pass `--force`.

Raise this if MAST starts erroring or rejecting requests under concurrent
batch load; at the 1.0s default, the added cost is ~126s per pass, which is
negligible against `submit_manifest.sbatch`'s 4-hour `--time` limit even
across several rows per rank.

## The staging ladder

The expensive, fragile step is turning a search into per-SCA product *names*;
streaming them is just bandwidth. So do those separately. Run every rung from
the activity directory with the manifest built as above.

**Rung 1 -- plan, 4-way. No downloads.**

```bash
sbatch --partition=cpu-lg --nodes=1 --ntasks-per-node=4 batch/submit_plan.sbatch \
    "$(pwd)" batch/run_manifest.csv ../../variables.env \
    /data/eswitzer/rcs_trend_v2/stage /data/eswitzer/rcs_trend_v2/h5 -1
```

Caches `<staging>/plans/<run_label>_plan.json` per pass and streams nothing.
Do not widen this past 4 -- it is the rung that touches the API that fails.

**Rung 2 -- inspect before committing to a download.**

```bash
ls batch/status/*.planned | wc -l            # plans cached
ls batch/status/*.degraded | wc -l           # passes whose plan is short
grep -h DEGRADED batch/status/*.degraded     # and by how much
ls batch/status/*.failed | wc -l             # should be ~0 on a surveyed manifest
```

A `degraded` row means the plan did not cover 18 SCAs on every lit activity, so
MAST has not finished indexing that pass. Nothing was streamed and nothing was
written. Re-plan those later; the row is not lost.

**Rung 3 -- stream, 8-way, from the cached plans.**

```bash
USE_PLAN=1 sbatch --partition=cpu-lg --nodes=1 --ntasks-per-node=8 \
    batch/submit_manifest.sbatch \
    "$(pwd)" batch/run_manifest.csv ../../variables.env \
    /data/eswitzer/rcs_trend_v2/stage /data/eswitzer/rcs_trend_v2/h5 -1
```

**8-way, not the 32-way the old step-4 example used.** 32-way is what produced
`rcs_trend_batch{,_run1}`, where 79 of 91 products hold only 1-6 of 18 SCAs.
Under `USE_PLAN=1` this rung issues no listing calls whatsoever, so widening it
only adds streaming bandwidth against no known limit -- but 8-way is the
recommendation until a wider run has actually been shown to be clean, and
there is little to gain: at ~5.5s per SCA, 8-way clears 177 passes in roughly
four hours, which fits the sbatch `--time` default.

### Why a plan does not go stale

Streaming does go through a presigned S3 URL with a 5-minute TTL, so "query
everything now, fetch it later" sounds like it should break. It does not,
because a plan stores product **names**: `read_product` resolves a name to a
signed URL at *read* time, via a stable service endpoint that answers 307. So
rung 1's output has no expiring content in it -- verify with
`grep -c 'X-Amz\|s3://' <staging>/plans/*.json`, which should print 0.

The real exposure is inverted from the intuitive one: it bounds how long a
*single file* may be held open, not how many may be planned. `asdf` reads
lazily through the handle opened against one signed URL, so anything that
collected open products and read them afterwards -- batching reads, or holding
18 handles to parallelise -- would blow past 300s and fail mid-array.
`stage_run` closes each file in a `finally` before touching the next, keeping
that interval at ~5.5s, i.e. under 2% of the signature's life. See
`rcs_mast.py`'s module docstring for the measurements.

What a plan *is* a snapshot of is coverage at the moment it was built: a plan
built while MAST had indexed 6 of 18 SCAs stays a 6-SCA plan forever. That is
caught by `check_plan_coverage` on read as well as on write, rather than by an
age limit -- a plan that is complete cannot become less so.

### The dark is always missing, and that is correct

Every row carries `blank_dark`. The RCS dark exposure is **not processed to L2
at all**, so it contributes zero products and its identity and timing come from
L1 instead. `check_plan_coverage` exempts the dark and the CAR-216 obs-8/9 aux
activities explicitly: requiring 18 SCAs there would reject every run that
exists. A pass showing "6/7 exposures at L2" (CAR-190) or "10/15" (CAR-216) is
complete, not short.

## Concurrency notes

Many ranks across many nodes write into the same `logs/`/`status/`
directories concurrently. Each row's files are named by its own `<stem>`, so
there's no shared/appended file for two ranks to race on -- but nothing
locks the `_already_done()` glob against a *different* rank writing the same
`.h5` at the same time. In practice this isn't an issue because the manifest
partition (`rank::world_size` over a fixed row order) assigns each row to
exactly one rank per submission, so two ranks never work the same row within
one `sbatch` call.
