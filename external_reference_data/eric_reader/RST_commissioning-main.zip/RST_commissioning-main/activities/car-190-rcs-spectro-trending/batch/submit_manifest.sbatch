#!/bin/bash
#SBATCH --job-name=rcs-trend
#SBATCH --time=08:00:00
#SBATCH --output=batch/logs/slurm-%j.out
#
# 8 h, not the 4 h this asked for until 2026-10-04. Measured on job 8889: 118
# passes streamed in 3.77 h at 8-way, i.e. 1.92 min/pass, so a 177-pass manifest
# needs 5.7 h and the 4 h limit cancelled the job with 59 rows untouched. The
# limit is the wrong place to economise: SLURM bills elapsed time, not the
# reservation, and a cancelled rung costs a whole resubmission. Scale it with
# the manifest -- roughly `rows * 2 min / ntasks-per-node`, doubled for margin.
#
# A cancellation is survivable rather than ruinous, and that is by design: the
# coverage-aware skip means a resubmission rebuilds only the rows whose product
# is missing or short, so the work already on disk is not repeated.
#
# --nodes / --ntasks-per-node are deliberately not set above: pass them on
# the sbatch command line so node count and jobs-per-node are a per-submission
# tuning knob, not a script edit. Example:
#
#   sbatch --nodes=4 --ntasks-per-node=8 batch/submit_manifest.sbatch \
#       <repo_root> <manifest.csv> <token_file> <staging_root> <out_dir> \
#       [n_tasks] [query_delay_seconds]
#
# n_tasks (default -1) selects how many of the manifest's rows (in file
# order) are in scope for this submission; -1 means all of them.
#
# query_delay_seconds (default: unset, i.e. process_rcs_trending.py's own
# default applies) is how long each worker sleeps between per-SCA MAST
# fetches -- raise it if MAST is throttling/erroring under concurrent batch
# load. See README.md's "Batch processing with SLURM" section for the
# staged rollout this is meant to support.
set -euo pipefail

export REPO_ROOT="${1:?usage: sbatch --nodes=N --ntasks-per-node=K submit_manifest.sbatch <repo_root> <manifest.csv> <token_file> <staging_root> <out_dir> [n_tasks] [query_delay_seconds]}"
export MANIFEST="${2:?manifest csv required}"
export TOKEN_FILE="${3:?token file required}"
export STAGING_ROOT="${4:?staging root required}"
export OUT_DIR="${5:?out dir required}"
export N_TASKS="${6:--1}"
export QUERY_DELAY_SECONDS="${7:-}"

# This submission streams; PLAN_ONLY is cleared so an exported leftover from a
# submit_plan.sbatch run cannot silently turn a streaming job into a replan.
export PLAN_ONLY=""

# Optional, from the submitting environment (sbatch exports it by default):
#   USE_PLAN=1    stream from the plans cached by submit_plan.sbatch, issuing
#                 no listing calls at all. This is the recommended mode; it is
#                 not the default only because it requires that sweep first.
#   MIN_SCAS      lit SCAs required per activity before anything is streamed;
#                 below it the row exits degraded having written nothing, which
#                 is what stops a short listing becoming a 2-SCA product that
#                 then blocks its own retry. The same number also decides
#                 whether an *existing* product counts as done (default 18)
#   QUERY_LEASES  concurrent listing calls allowed across all ranks sharing
#                 STAGING_ROOT; ignored under USE_PLAN, which lists nothing
#   BIN_FACTOR    superpixel bin factor for the per-SCA product (default 16,
#                 giving 256x256 per SCA). Must divide 4096 -- checked at parse
#                 time, before any pull. Do not mix bin factors within one
#                 OUT_DIR: the digests assert a single value across the set,
#                 because per-SCA medians differ at 0.1%, the size of the signal
#   AUX_L2_DIR    directory of a local L2 reprocessing that supersedes MAST
#                 for any pass it covers completely. A pass it covers only
#                 partly is refused, not mixed: half a pass on one flux
#                 calibration and half on another is worse than the step it
#                 would be curing, and nothing downstream could see it.
#                 Reads are local, so QUERY_DELAY_SECONDS does not apply and
#                 the fan-out is bounded by disk, not by the listing API
#   FORCE=1       rebuild every row in scope, ignoring existing products
export USE_PLAN="${USE_PLAN:-}"
export MIN_SCAS="${MIN_SCAS:-}"
export QUERY_LEASES="${QUERY_LEASES:-}"
export BIN_FACTOR="${BIN_FACTOR:-}"
export AUX_L2_DIR="${AUX_L2_DIR:-}"
export FORCE="${FORCE:-}"

srun bash "$REPO_ROOT/batch/worker_entrypoint.sh"
