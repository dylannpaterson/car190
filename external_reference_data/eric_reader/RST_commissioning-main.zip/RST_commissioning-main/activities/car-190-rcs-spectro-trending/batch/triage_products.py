"""Per-product SCA coverage over a directory of RCS trend h5 files.

Read-only by default. The point is to separate a product that simply exists from
one that is complete: a MAST product listing degraded by query overload returns
only some of the 18 SCAs, the pipeline streams and writes what it was given, and
nothing in the file records that it is short. This is the tool for finding those
after the fact -- the directories staged before the coverage guards existed
(``rcs_trend_batch``, 79 of 91 short) are its reason for being.

Coverage is also reported *per LED*, because products are pulled one activity
(one LED) at a time, so a truncated listing can leave LED3 complete and LED5 at
two SCAs. The number ``--min-scas`` screens on is
:func:`rcs_products.coverage_from_h5`, which AND-reduces over activities and is
the same function ``batch/run_manifest_worker.py`` uses to decide whether a pass
still needs building. The per-LED spread is the diagnostic beside it.

    # look
    python batch/triage_products.py /data/eswitzer/rcs_trend
    python batch/triage_products.py /data/eswitzer/rcs_trend_batch --only-degraded

    # act
    python batch/triage_products.py /data/eswitzer/rcs_trend_batch \
        --apply --move-degraded

Nothing is deleted: ``--move-degraded`` relocates into ``<dir>/degraded/``.
"""
import argparse
import os
import shutil
import sys

import h5py
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rcs_products import coverage_from_h5  # noqa: E402
from rcs_sca_grid import sca_footprint_masks, sorted_scas  # noqa: E402
from rcs_trend_config import DEGRADED_SUBDIR, LED_NAMES, N_SCAS  # noqa: E402

# Cache of footprint masks by mosaic shape: the masks cost a few seconds to
# build (a point-in-polygon test per mosaic pixel per SCA) and every legacy
# product in a directory shares one shape.
_MASK_CACHE = {}


def _masks_for(shape):
    if shape not in _MASK_CACHE:
        _MASK_CACHE[shape] = sca_footprint_masks(shape)
    return _MASK_CACHE[shape]


def _per_led_coverage(handle):
    """``{led: n_scas_with_finite_data}`` for either product layout.

    Three cases, in the order they are tried: an explicit ``coverage/`` group
    (per-SCA products from Phase 5 on), a ``sca_arrays/`` stack, and a legacy
    ``led_arrays/`` mosaic, whose per-SCA occupancy has to be recovered through
    the footprint masks.
    """
    if "sca_arrays" in handle:
        return {led: int(np.sum([np.isfinite(plane).any()
                                 for plane in handle["sca_arrays"][led][:]]))
                for led in LED_NAMES if led in handle["sca_arrays"]}

    if "led_arrays" not in handle:
        return {}

    counts = {}
    for led in LED_NAMES:
        if led not in handle["led_arrays"]:
            continue
        mosaic = handle["led_arrays"][led][:]
        masks = _masks_for(mosaic.shape)
        counts[led] = int(sum(bool(np.isfinite(mosaic[masks[sca]]).any())
                              for sca in sorted_scas(masks)))
    return counts


def inspect(path):
    """One record per product: coverage, annotation, and LVDT health."""
    record = {"path": path, "name": os.path.basename(path),
              "size_mb": os.path.getsize(path) / 1e6, "error": ""}
    try:
        # The number that decides degraded-or-not comes from
        # rcs_products.coverage_from_h5 -- the same function
        # batch/run_manifest_worker.py screens on, so a product this tool calls
        # degraded is exactly one the worker will move aside and retry. Two
        # implementations of "is it complete" would eventually disagree, and the
        # disagreement would look like a pass that will not stay built.
        record["n_sca"] = int(np.sum(coverage_from_h5(path)))

        with h5py.File(path, "r") as handle:
            attrs = dict(handle.attrs)
            record["stage"] = str(attrs.get("stage", "legacy"))
            record["product_kind"] = str(attrs.get(
                "product_kind", "per_sca" if "sca_arrays" in handle else "mosaic"))
            record["car_label"] = str(attrs.get("car_label", ""))
            record["decon_cycle"] = str(attrs.get("decon_cycle", ""))

            # Detail, not a second opinion: coverage_from_h5 AND-reduces over
            # activities, so it already answers with the worst LED. The spread
            # is what tells a listing truncated on one activity apart from a
            # pass that never had 18 detectors in any of them.
            per_led = _per_led_coverage(handle)
            record["per_led"] = per_led
            record["n_sca_worst"] = min(per_led.values()) if per_led \
                else record["n_sca"]
            record["n_sca_best"] = max(per_led.values()) if per_led \
                else record["n_sca"]
            record["n_leds"] = len(per_led)

            lvdt = (handle["dictionary"]["ACM_LVDT"][:]
                    if "dictionary" in handle
                    and "ACM_LVDT" in handle["dictionary"] else np.array([]))
            record["n_lvdt_nan"] = int(np.sum(~np.isfinite(lvdt)))
            record["lvdt_mean"] = (float(np.nanmean(lvdt))
                                   if np.isfinite(lvdt).any() else float("nan"))
    except (OSError, KeyError, ValueError) as error:
        record["error"] = f"{type(error).__name__}: {error}"
        record.setdefault("n_sca", 0)
        record.setdefault("n_sca_worst", 0)
        record.setdefault("n_sca_best", 0)
        record.setdefault("per_led", {})
    return record


def report(records, min_scas, only_degraded=False):
    """Print one line per product plus a summary; returns the degraded records."""
    degraded = [r for r in records
                if r["error"] or r["n_sca"] < min_scas]
    shown = degraded if only_degraded else records

    print(f"{'product':<52} {'kind':>8} {'SCAs':>9} {'MB':>7} "
          f"{'LVDT NaN':>9}  annotation")
    for record in sorted(shown, key=lambda r: r["name"]):
        if record["error"]:
            print(f"{record['name']:<52} {'UNREADABLE':>8}  {record['error']}")
            continue
        span = (f"{record['n_sca_worst']}/{N_SCAS}"
                if record["n_sca_worst"] == record["n_sca_best"]
                else f"{record['n_sca_worst']}-{record['n_sca_best']}/{N_SCAS}")
        annotation = "/".join(v for v in (record["car_label"],
                                          record["decon_cycle"]) if v) or "-"
        flag = " " if record["n_sca"] >= min_scas else "*"
        print(f"{record['name']:<52} {record['product_kind']:>8} {span:>9}"
              f"{flag}{record['size_mb']:7.1f} {record['n_lvdt_nan']:9d}  "
              f"{annotation}")

    complete = [r for r in records if not r["error"]
                and r["n_sca"] >= min_scas]
    print(f"\n{len(records)} product(s): {len(complete)} with >= {min_scas} "
          f"SCAs in every LED, {len(degraded)} degraded or unreadable")
    if degraded:
        # The per-LED histogram is the signature of the failure: overload gives
        # a long tail at 1-6 SCAs, whereas a genuinely partial downlink gives a
        # handful just short of 18.
        worst = np.array([r["n_sca"] for r in degraded])
        print(f"  degraded worst-LED coverage: min {worst.min()}, median "
              f"{int(np.median(worst))}, max {worst.max()}")
    unannotated = [r for r in records
                   if not r["error"] and not (r["car_label"] and r["decon_cycle"])]
    if unannotated:
        print(f"  {len(unannotated)} product(s) lack a car_label/decon_cycle "
              f"attribute (predate annotate_h5)")
    nan_lvdt = [r for r in records if not r["error"] and r["n_lvdt_nan"]]
    if nan_lvdt:
        print(f"  {len(nan_lvdt)} product(s) have a non-finite ACM_LVDT channel")
    return degraded


def move_degraded(degraded, out_dir, apply=False):
    """Relocate degraded products into ``<out_dir>/degraded/``. Never deletes."""
    target = os.path.join(out_dir, DEGRADED_SUBDIR)
    if not degraded:
        return []
    if apply:
        os.makedirs(target, exist_ok=True)
    moved = []
    for record in degraded:
        destination = os.path.join(target, record["name"])
        if apply:
            shutil.move(record["path"], destination)
        moved.append(destination)
        print(f"{'moved' if apply else 'would move'} {record['name']} -> "
              f"{DEGRADED_SUBDIR}/")
    if not apply:
        print("\n(dry run; pass --apply to actually move)")
    return moved


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("directories", nargs="+",
                        help="directories of RCS trend h5 products")
    parser.add_argument("--min-scas", type=int, default=N_SCAS,
                        help=f"SCAs required in every LED for a product to "
                             f"count as complete (default {N_SCAS})")
    parser.add_argument("--only-degraded", action="store_true",
                        help="list only the products that fall short")
    parser.add_argument("--move-degraded", action="store_true",
                        help=f"relocate degraded products into "
                             f"<dir>/{DEGRADED_SUBDIR}/ so the batch worker "
                             f"retries them")
    parser.add_argument("--apply", action="store_true",
                        help="actually move; without it --move-degraded is a "
                             "dry run")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    for directory in args.directories:
        paths = sorted(os.path.join(directory, name)
                       for name in os.listdir(directory)
                       if name.endswith(".h5"))
        print(f"\n=== {directory}: {len(paths)} h5 file(s) ===")
        if not paths:
            continue
        records = [inspect(path) for path in paths]
        degraded = report(records, args.min_scas, args.only_degraded)
        if args.move_degraded:
            move_degraded(degraded, directory, apply=args.apply)


if __name__ == "__main__":
    main()
