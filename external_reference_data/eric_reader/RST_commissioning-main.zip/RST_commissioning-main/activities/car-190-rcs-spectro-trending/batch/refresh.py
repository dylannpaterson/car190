#!/usr/bin/env python
"""Bring new RCS passes into the trend. Each step is one command that says what
it found and ends with a "Next:" block naming the exact command to run after it.

    .venv/bin/python batch/refresh.py status      # start here, every time
    .venv/bin/python batch/refresh.py probe  --program 1063 --passes 4:8-10,5:1-5
    .venv/bin/python batch/refresh.py label  --program 1063 --passes 4:8-10,5:1-5 \\
                                             --decon-cycle decon2 --mce-side B
    .venv/bin/python batch/refresh.py pull   [--submit | --local 4]
    .venv/bin/python batch/refresh.py check
    .venv/bin/python run_trend.py             # stages 2 and 3 over the tree

    .venv/bin/python batch/refresh.py seed --from OLD_ROOT   # once, a new tree

Run from the activity directory. The MAST token is read from ../../variables.env
(or an exported MAST_API_TOKEN) and never printed.

What each step is for:

``status``  Asks the archive what exists (every program in PROGRAM_LABELS;
            ``--program`` narrows it) and compares it with the manifest, with
            the products in the trend tree, and with the calibrated products and
            digests. Most of its time is the paged MAST survey. Also re-checks
            whether the EDP has started serving the side-status mnemonics in
            ``rcs_trend_config.SIDE_STATUS_MNEMONICS``.
``probe``   Streams no imagery: photodiode-only sidecars for the new passes
            plus a couple of earlier ones for context (~2 min/pass, 4-way), then
            the side witnesses and the MPA temperature. PROPOSES the two labels
            a manifest row needs, with the evidence. Writes only to scratch.
``label``   Writes the labels into batch/run_manifest.csv (after backing it up)
            and prints a MANIFEST.md entry to fill in. The labels are operator
            knowledge -- nothing in the archive or the telemetry names the decon
            cycle or the MCE side -- so this step is never automatic.
``pull``    Writes batch/run_manifest_new.csv: the manifest rows that have no
            complete product in the tree. Prints the SLURM submission (or, for
            one or two passes, the by-hand commands); ``--submit`` submits it,
            and ``--local N`` runs the same two rungs here, N worker ranks
            each, and waits (a handful of passes, no SLURM queue).
``check``   The worker outcome of every row of the last pull, triage of the
            products, and ``side_witness --strict``.
``seed``    Copies a whole trend tree into an empty ``--root``, verifies every
            file, and records where it came from in SEEDED_FROM.txt. How a new
            tree generation or a new deployment starts; ``--resume`` finishes
            an interrupted one.

The steps are the same in a quiet stretch and in a key period. In a key period
(a side swap, a decon, an ACM move) run them one pass at a time and read every
witness block as it lands. DATA_PULL.md has each step in detail.
"""
import argparse
import concurrent.futures
import datetime
import glob
import os
import re
import shlex
import shutil
import subprocess
import sys

BATCH = os.path.dirname(os.path.abspath(__file__))
ACTIVITY = os.path.dirname(BATCH)
sys.path.insert(0, ACTIVITY)
sys.path.insert(0, BATCH)

import numpy as np  # noqa: E402

import make_manifest  # noqa: E402
import rcs_activities  # noqa: E402
import rcs_fsutil  # noqa: E402
import rcs_trend_config as cfg  # noqa: E402
import side_witness  # noqa: E402

PROGRAM_LABELS = {1039: "CAR190", 1063: "CAR216"}
# Passes that will never have a product, and why. A row here is reported, never
# pulled: pulling it only produces a status/*.failed that looks like a fault.
KNOWN_ABSENT = {
    (1039, 2, 12): "not in the archive at L1 or L2",
    (1039, 2, 25): "short sequence: observation 7 was never taken",
    **{(1039, 3, p): "never executed: the pass counter jumped at the "
                     "2026-10-06 side swap" for p in range(58, 71)},
}
PRODUCT = re.compile(r"CAR\d+_(\d{5})_(\d{2})_(\d{3})_\d{3}_\d{8}_raw\.h5$")
MPA = "WFI_MCE_ADC_WTSM00"
DECON_WARM_K = 95.0      # a decon's cooldown starts near 124 K; the plateau is 89.5
PYTHON = sys.executable
NEW_MANIFEST = os.path.join(BATCH, "run_manifest_new.csv")


# ---------------------------------------------------------------------------
# Shared pieces
# ---------------------------------------------------------------------------

def load_token(token_file):
    """Put MAST_API_TOKEN in the environment from ``token_file``; never print it.

    Read the way ``worker_entrypoint.sh`` sources the same file: the first
    ``MAST_API_TOKEN=...`` line, quotes stripped. An already-exported token wins.
    """
    if os.environ.get("MAST_API_TOKEN"):
        return True
    if not os.path.exists(token_file):
        return False
    with open(token_file) as handle:
        for line in handle:
            match = re.match(r"\s*(?:export\s+)?MAST_API_TOKEN\s*=\s*(.+?)\s*$",
                             line)
            if match:
                os.environ["MAST_API_TOKEN"] = match.group(1).strip("'\"")
                return True
    return False


def parse_passes(spec):
    return make_manifest._parse_pass_ranges(spec) if spec else []


def parse_plan_passes(spec, plan=None):
    """``"4:8-10,5:1-5"`` -> ``[(4, 8), (4, 9), (4, 10), (5, 1), ...]``.

    A ``PLAN:`` prefix sets the execution plan for that chunk and the chunks
    after it; a bare chunk uses the plan in force, starting from ``plan``
    (``--plan``). So ``--plan 3 --passes 75-80`` still works, and one call can
    cover a batch that crosses into a new execution plan -- which is the normal
    case, because a plan boundary is a scheduling event, not a data one.
    """
    out = []
    for chunk in (spec or "").split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if ":" in chunk:
            head, chunk = chunk.split(":", 1)
            plan = int(head)
        if plan is None:
            raise SystemExit(f"--passes {spec!r}: no execution plan for "
                             f"{chunk!r}; give --plan or write PLAN:{chunk}")
        out.extend((plan, n) for n in parse_passes(chunk))
    return out


def format_plan_passes(pairs):
    """The inverse: ``[(4, 8), (4, 9), (5, 1)]`` -> ``"4:8-9,5:1"``."""
    by_plan = {}
    for plan, number in pairs:
        by_plan.setdefault(plan, []).append(number)
    return ",".join(f"{plan}:{ranges(numbers)}"
                    for plan, numbers in by_plan.items())


def product_times(products):
    """``{key: datetime64}`` from each product's own ``timestamp`` attr."""
    import h5py

    out = {}
    for key, (path, _) in products.items():
        with h5py.File(path, "r") as handle:
            stamp = handle.attrs.get("timestamp", "")
        stamp = stamp.decode() if isinstance(stamp, bytes) else str(stamp)
        if stamp:
            out[key] = np.datetime64(stamp[:26])
    return out


def latest_products(products, n):
    """The ``n`` most recent products in time, from any program or plan.

    The trend is one chronology: CAR-190 and CAR-216 interleave, and pass
    numbers restart with every execution plan. So "the passes before this one"
    means the latest in time, never the lower numbers of the same plan -- for
    the first pass of a new plan there are none of those at all.
    """
    times = product_times(products)
    return [key for key, _ in sorted(times.items(), key=lambda kv: kv[1])][-n:] \
        if n else []


def ranges(numbers):
    """``[53, 54, 55, 57]`` -> ``"53-55,57"``."""
    numbers, out = sorted(set(numbers)), []
    for number in numbers:
        if out and number == out[-1][1] + 1:
            out[-1][1] = number
        else:
            out.append([number, number])
    return ",".join(f"{a}" if a == b else f"{a}-{b}" for a, b in out)


def products_in(h5_dir):
    """``{(program, plan, pass): (path, n_sca_covered)}`` for raw products."""
    import rcs_products

    found = {}
    for path in glob.glob(os.path.join(h5_dir, "*_raw.h5")):
        match = PRODUCT.search(os.path.basename(path))
        if not match:
            continue
        key = (int(match.group(1)), int(match.group(2)), int(match.group(3)))
        try:
            covered = int(np.sum(rcs_products.coverage_from_h5(path)))
        except (OSError, KeyError, ValueError):
            covered = 0
        if key not in found or covered > found[key][1]:
            found[key] = (path, covered)
    return found


def missing_rows(manifest, products, min_scas=cfg.MIN_SCAS):
    """Manifest rows with no complete product, minus the known-absent ones.

    Returns ``(rows, skipped)``: the rows to pull, and ``[(key, reason)]`` for
    known-absent rows that were left out.
    """
    rows, skipped = [], []
    for _, row in manifest.iterrows():
        key = make_manifest._key(row)
        if key in products and products[key][1] >= min_scas:
            continue
        if key in KNOWN_ABSENT:
            skipped.append((key, KNOWN_ABSENT[key]))
            continue
        rows.append(row)
    return rows, skipped


def variant_name(entry, program=None):
    """A surveyed pass's sequence variant: its name, ``<name>?`` while its L1
    is still arriving (a registered layout with the tail missing), ``UNKNOWN``,
    or ``?`` with no L1 at all."""
    if not entry.get("signature"):
        return "?"
    kind, found = rcs_activities.match_sequence(
        entry["signature"], cfg.SEQUENCE_VARIANTS, program)
    if kind == "exact":
        return found
    if kind == "partial":
        return "|".join(found) + "?"
    return "UNKNOWN"


def latest_digests(root):
    """The newest ``digests_*`` set: under the tree since 2026-10-12, else the
    repo's ``digests/``, where ``run_trend.py`` wrote them before."""
    for parent in (os.path.join(root, "digests"),
                   os.path.join(ACTIVITY, "digests")):
        sets = sorted(glob.glob(os.path.join(parent, "digests_*")),
                      key=os.path.getmtime)
        if sets:
            return sets[-1]
    return None


def worker_outcomes(rows):
    """``{stem: outcome}`` from batch/status for manifest ``rows``.

    The stem is the worker's own (``CAR216_01063_05_001_decon2``), and the
    outcome the suffix of the one status file it leaves per row, or
    ``"not run"``.
    """
    import run_manifest_worker

    out = {}
    for _, row in rows.iterrows():
        stem = run_manifest_worker._stem(row)
        found = [suffix for suffix in run_manifest_worker.OUTCOMES
                 if os.path.exists(os.path.join(run_manifest_worker.STATUS_DIR,
                                                f"{stem}.{suffix}"))]
        out[stem] = found[0] if found else "not run"
    return out


def side_runs(passes, sides):
    """Contiguous runs of one proposed side: ``[(side, [passes])]``."""
    runs = []
    for number, side in zip(passes, sides):
        if runs and runs[-1][0] == side:
            runs[-1][1].append(number)
        else:
            runs.append((side, [number]))
    return runs


def next_block(*commands):
    print("\nNext:")
    for command in commands:
        print(f"  {command}")


def _run(command, check=True, **kwargs):
    print(f"$ {' '.join(shlex.quote(str(c)) for c in command)}", flush=True)
    result = subprocess.run([str(c) for c in command], cwd=ACTIVITY, **kwargs)
    if check and result.returncode != 0:
        raise SystemExit(f"command failed with exit {result.returncode}")
    return result


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------

def core_l2_scas(group):
    """The fewest SCAs any core LED flat (obs 2-7) has at L2; 0 if one is absent.

    What a pass needs before stage 1 can make a trend point. The aux
    observations do not count: some never reach L2 (the decon3 low-flux flats
    had not, a day on), and the trend does not use them.
    """
    lit = [o for o in sorted(rcs_activities.CORE_OBSERVATIONS) if o != 1]
    counts = [int(group[group["observation"] == o]["detector"].nunique())
              for o in lit]
    return min(counts) if counts else 0


SURVEY_CACHE = os.path.join("/tmp", f"rcs_survey_{os.environ.get('USER', 'u')}")


def survey_frames(programs, reuse_hours=0.0):
    """``{program: {1: L1 frame, 2: L2 frame}}``, from MAST or from the cache.

    Every fresh survey is written to ``SURVEY_CACHE`` as soon as it arrives,
    so anything that fails after it -- a parse error, a crash in the
    reporting -- can be re-run with ``--reuse-survey`` instead of paying for the
    survey again (half an hour for both programs by 2026-10-25). A cache older
    than ``reuse_hours`` is ignored.
    """
    import time

    import pandas as pd
    import rcs_mast

    os.makedirs(SURVEY_CACHE, exist_ok=True)
    out, missions = {}, None
    for program in programs:
        out[program] = {}
        for level in (1, 2):
            path = os.path.join(SURVEY_CACHE, f"{program}_L{level}.pkl")
            age_h = ((time.time() - os.path.getmtime(path)) / 3600
                     if os.path.exists(path) else None)
            if reuse_hours and age_h is not None and age_h <= reuse_hours:
                out[program][level] = pd.read_pickle(path)
                print(f"  reusing the L{level} survey of {program} from "
                      f"{path} ({age_h:.1f} h old)")
                continue
            missions = missions or rcs_mast.connect()
            frame = rcs_mast.survey_rows(missions, {"program": program}, level)
            if len(frame):
                frame.to_pickle(path)
            out[program][level] = frame
    return out


def survey(programs, reuse_hours=0.0):
    """``{(program, plan, pass): {...}}`` from the paged archive survey.

    Per pass: file counts at L1 and L2, the start time, the sequence
    ``signature`` (from L1, where every exposure is) and ``core_scas``, the
    fewest SCAs a core LED flat has at L2.
    """
    out = {}
    for program, frames in survey_frames(programs, reuse_hours).items():
        for level, frame in frames.items():
            if not len(frame):
                raise SystemExit(f"the L{level} survey of program {program} "
                                 f"returned nothing -- a failed query, not an "
                                 f"empty program. Re-run when MAST answers.")
            valid = frame[frame["pass"].notna() & frame["execution_plan"].notna()]
            for (plan, number), group in valid.groupby(["execution_plan", "pass"]):
                key = (program, int(plan), int(number))
                entry = out.setdefault(key, {"n_l1": 0, "n_l2": 0, "l2_scas": 0,
                                             "start": "", "signature": "",
                                             "core_scas": 0})
                entry[f"n_l{level}"] = len(group)
                if level == 1:
                    try:
                        entry["signature"] = rcs_activities.sequence_signature(
                            group.to_dict("records"))
                    except (ValueError, TypeError) as error:
                        # One malformed listing must not cost the whole
                        # survey; the pass reads "?" and says why.
                        print(f"  WARNING: no sequence signature for {key}: "
                              f"{error}")
                if level == 2:
                    entry["l2_scas"] = int(group["detector"].nunique())
                    entry["core_scas"] = core_l2_scas(group)
                starts = [s for s in group["start_time"].astype(str) if s]
                if starts:
                    entry["start"] = min([entry["start"] or "9999"] + starts)
    return out


def cmd_status(args):
    import rcs_edp

    have_token = load_token(args.token_file)
    manifest = make_manifest._load_existing(args.manifest)
    known = {make_manifest._key(row): row for _, row in manifest.iterrows()}
    if not os.path.isdir(os.path.join(args.root, "h5")):
        print(f"no trend tree at {args.root} (no h5/). A new tree starts as a "
              f"copy of the previous one:")
        next_block(f".venv/bin/python batch/refresh.py seed --from <old tree> "
                   f"--root {args.root}")
        return 2
    products = products_in(os.path.join(args.root, "h5"))
    # Every program by default: both CAR-190 and CAR-216 take new passes, and
    # a survey of one would report the other as "nothing new".
    programs = (sorted(set(args.program)) if args.program
                else sorted(PROGRAM_LABELS))

    print(f"trend tree {args.root}: {len(products)} raw product(s); manifest "
          f"{len(manifest)} row(s)")

    archive = {}
    if not have_token:
        print(f"\nno MAST token (looked for {args.token_file} and "
              f"$MAST_API_TOKEN), so the archive is NOT surveyed")
    else:
        print(f"\nsurveying the archive for program(s) {programs} (paged; "
              f"several minutes per program) ...", flush=True)
        archive = survey(programs, args.reuse_survey)
    # Time order, not (program, plan, pass) order: the trend is one chronology.
    new = sorted((key for key in archive if key not in known),
                 key=lambda k: (archive[k]["start"], k))
    print(f"\n----- the archive vs the manifest -----")
    for program in programs:
        for plan in sorted({k[1] for k in archive if k[0] == program}):
            numbers = sorted(k[2] for k in archive if k[:2] == (program, plan))
            absent = [n for n in range(numbers[0], numbers[-1] + 1)
                      if n not in numbers]
            variants = sorted({variant_name(archive[(program, plan, n)],
                                            program) for n in numbers})
            print(f"  {PROGRAM_LABELS[program]} plan {plan}: {len(numbers)} "
                  f"pass(es) {numbers[0]}-{numbers[-1]}"
                  + (f", absent {ranges(absent)}" if absent else "")
                  + f"  [{', '.join(variants)}]")
    if new:
        print(f"\n  {len(new)} pass(es) in the archive and NOT in the manifest:")
        print(f"    {'program':>7} {'plan':>4} {'pass':>4}  {'start (UTC)':19}  "
              f"{'L1':>4} {'L2':>4} {'SCAs':>4}  {'sequence':14} complete")
        for key in new:
            entry = archive[key]
            complete = entry["core_scas"] >= cfg.MIN_SCAS
            print(f"    {key[0]:>7} {key[1]:>4} {key[2]:>4}  "
                  f"{entry['start'][:19]:19}  {entry['n_l1']:>4} "
                  f"{entry['n_l2']:>4} {entry['l2_scas']:>4}  "
                  f"{variant_name(entry, key[0]):14} "
                  f"{'yes' if complete else 'NOT YET -- MAST still indexing'}")
        unknown = [k for k in new
                   if variant_name(archive[k], k[0]) == "UNKNOWN"]
        for signature in sorted({archive[k]["signature"] for k in unknown}):
            passes = [k for k in unknown if archive[k]["signature"] == signature]
            print(f"\n  WARNING: {len(passes)} new pass(es) ran a sequence not in "
                  f"rcs_trend_config.SEQUENCE_VARIANTS, first "
                  f"{PROGRAM_LABELS[passes[0][0]]} plan {passes[0][1]} pass "
                  f"{passes[0][2]}:\n    {signature}\n  A new layout can break "
                  f"stage 1. DATA_PULL.md, 'A new sequence variant', says how to "
                  f"check it and register it before pulling.")
    elif archive:
        print("  nothing new in the archive")
    stale = sorted(key for key in known if archive and key[0] in programs
                   and key not in archive)
    if stale:
        print(f"  WARNING: {len(stale)} manifest row(s) the archive no longer "
              f"has: {stale[:5]}")

    missing, skipped = missing_rows(manifest, products, args.min_scas)
    print(f"\n----- the manifest vs the trend tree -----")
    print(f"  {len(manifest) - len(missing) - len(skipped)} row(s) have a "
          f"complete product; {len(missing)} do not"
          + (f"; {len(skipped)} known-absent" if skipped else ""))
    for row in missing[:20]:
        key = make_manifest._key(row)
        have = products.get(key)
        print(f"    {key}  {row['decon_cycle']}/{row['mce_side'] or 'blank'}  "
              + (f"short product ({have[1]}/18 SCAs)" if have else "no product"))
    for key, reason in skipped:
        print(f"    {key}  known absent: {reason}")

    print(f"\n----- stages 2 and 3 -----")
    raw_times = [os.path.getmtime(p) for p, _ in products.values()]
    cal = glob.glob(os.path.join(args.root, "cal", "*_cal.h5"))
    latest = latest_digests(args.root)
    print(f"  {len(cal)} calibrated product(s) in {args.root}/cal")
    print(f"  latest digests: {latest or 'none'}")
    calibration_stale = bool(raw_times) and (
        not cal or max(raw_times) > min(os.path.getmtime(p) for p in cal)
        or len(cal) < len(products))
    verdict = ("STALE: a raw product is newer than it, or missing from it"
               if calibration_stale else "current")
    print(f"  calibration is {verdict}")

    if have_token:
        print(f"\n----- side-status telemetry -----")
        for name in cfg.SIDE_STATUS_MNEMONICS:
            try:
                table = rcs_edp.mnemonic_metadata(name)
                exists = len(table) > 0
            except Exception as error:          # noqa: BLE001 - service-side
                exists = None
                print(f"  {name}: dictionary lookup failed ({error})")
            if exists is not None:
                print(f"  {name}: "
                      + ("NOW IN THE EDP -- see rcs_trend_config."
                         "SIDE_STATUS_MNEMONICS for how to wire it in"
                         if exists else "still not in the EDP dictionary"))

    steps = []
    if new:
        # Only passes whose core is complete at L2: one still indexing would
        # fail to probe, and it is named here so it is not forgotten.
        ready = [k for k in new if archive[k]["core_scas"] >= cfg.MIN_SCAS]
        waiting = [k for k in new if k not in ready]
        # One call for every program, so the witnesses read in one time order
        # (probe --also).
        programs = sorted({k[0] for k in ready})
        if programs:
            first, others = programs[0], programs[1:]
            command = (f".venv/bin/python batch/refresh.py probe --program "
                       f"{first} --passes "
                       + format_plan_passes([k[1:] for k in ready
                                             if k[0] == first]))
            for program in others:
                command += (f" --also {program}:" + format_plan_passes(
                    [k[1:] for k in ready if k[0] == program]))
            steps.append(command)
        if waiting:
            steps.append("still indexing, for a later intake: " + ", ".join(
                f"{PROGRAM_LABELS[k[0]]} {format_plan_passes([k[1:]])}"
                for k in waiting))
    if missing:
        steps.append(".venv/bin/python batch/refresh.py pull")
    if calibration_stale and not missing and not new:
        steps.append(".venv/bin/python run_trend.py")
    if not steps:
        steps.append("nothing to do: the archive, the manifest, the products "
                     "and the calibration agree")
    next_block(*steps)
    return 0


# ---------------------------------------------------------------------------
# probe
# ---------------------------------------------------------------------------

def _probe_one(program, plan, number, scratch):
    key = (program, plan, number)
    existing = glob.glob(os.path.join(
        scratch, "pd", f"pd_{PROGRAM_LABELS[program]}_{program:05d}_{plan:02d}_"
        f"{number:03d}_*.h5"))
    if existing:
        return key, 0, "already probed"
    log = os.path.join(scratch, f"pass{program}_{plan}_{number}.log")
    with open(log, "w") as handle:
        result = subprocess.run(
            [PYTHON, "process_rcs_trending.py", "--blank-dark",
             "--program", str(program), "--execution-plan", str(plan),
             "--pass", str(number), "--decon-cycle", "unlabelled-probe",
             "--pd-only", "--staging-root", os.path.join(scratch, "stage"),
             "--out-dir", scratch],
            cwd=ACTIVITY, stdout=handle, stderr=subprocess.STDOUT)
    return key, result.returncode, log


def _mpa_by_epoch(epochs):
    """Max MPA temperature over each epoch's PD stream window, from the EDP."""
    import pandas as pd
    import rcs_edp

    starts = [e["start"] for e in epochs]
    t0 = (min(starts) - np.timedelta64(1, "h")).astype("datetime64[s]")
    t1 = (max(starts) + np.timedelta64(2, "h")).astype("datetime64[s]")
    frame = rcs_edp.query_mnemonics([MPA], str(t0), str(t1)).get(MPA)
    if frame is None or not len(frame):
        return [np.nan] * len(epochs)
    times = pd.to_datetime(frame[rcs_edp.TIME_COLUMN], utc=True).dt.tz_localize(None)
    values = pd.to_numeric(frame[rcs_edp.VALUE_COLUMN], errors="coerce")
    out = []
    for epoch in epochs:
        start = pd.Timestamp(epoch["start"])
        window = (times >= start) & (times <= start + pd.Timedelta(minutes=40))
        out.append(float(values[window].max()) if window.any() else np.nan)
    return out


def _latest_cycle(products, before):
    """``decon_cycle`` of the latest product starting before ``before``."""
    import h5py

    best, cycle = None, "decon?"
    for path, _ in products.values():
        with h5py.File(path, "r") as handle:
            stamp = np.datetime64(str(handle.attrs.get("timestamp", ""))[:26])
            label = handle.attrs.get("decon_cycle", "")
        label = label.decode() if isinstance(label, bytes) else str(label)
        if stamp < before and (best is None or stamp > best) and label:
            best, cycle = stamp, label
    return cycle


def _key_text(key):
    return f"{PROGRAM_LABELS.get(key[0], key[0])} p{key[1]}.{key[2]}"


def _is_key(epoch, keys):
    # Program, plan AND pass: a shared scratch directory can hold another
    # program's sidecar with the same plan and pass numbers.
    return any(f"_{p:05d}_{plan:02d}_{n:03d}_" in epoch["label"]
               for p, plan, n in keys)


def cmd_probe(args):
    if not load_token(args.token_file):
        raise SystemExit(f"no MAST token in {args.token_file} or "
                         f"$MAST_API_TOKEN; the probe queries MAST and the EDP")
    pairs = parse_plan_passes(args.passes, args.plan)
    if not pairs:
        raise SystemExit("--passes is required, e.g. --passes 75-80 or "
                         "--passes 4:8-10,5:1-5")
    products = products_in(os.path.join(args.root, "h5"))
    wanted = [(args.program, plan, n) for plan, n in pairs]
    # Another program's new passes, in the same call. Probed separately, the
    # second probe's context is the latest *products*, not the first probe's
    # passes, so a batch that switches program (CAR-216 p5.20-24 then CAR-190
    # p3.94-98, 2026-11-09) was never read in one time order.
    for extra in args.also:
        program, _, spec = extra.partition(":")
        if not program.isdigit() or not spec:
            raise SystemExit(f"--also {extra!r}: write PROGRAM:PLAN:PASSES, "
                             f"e.g. 1039:3:94-98")
        wanted += [(int(program), plan, n)
                   for plan, n in parse_plan_passes(spec)]
    programs = sorted({k[0] for k in wanted})
    context = [k for k in latest_products(products, args.context)
               if k not in wanted]
    scratch = args.scratch or f"/tmp/rcs_probe_{datetime.date.today():%Y%m%d}"
    os.makedirs(scratch, exist_ok=True)
    every = context + wanted
    print("probing " + "; ".join(
              f"{PROGRAM_LABELS[program]} "
              f"{format_plan_passes([k[1:] for k in wanted if k[0] == program])}"
              for program in programs)
          + (f", with the latest {len(context)} product(s) in time for context "
             f"({', '.join(_key_text(k) for k in context)})" if context else "")
          + f"\n  photodiode only, no imagery; {args.jobs}-way (the listing API "
          f"is what fails under load); scratch {scratch}", flush=True)
    with concurrent.futures.ThreadPoolExecutor(args.jobs) as pool:
        for key, code, detail in pool.map(
                lambda k: _probe_one(*k, scratch), every):
            status = "ok" if code == 0 else f"FAILED (exit {code})"
            print(f"  {_key_text(key):14s}: {status}  {detail}", flush=True)

    epochs = side_witness.discover([os.path.join(scratch, "pd")])
    epochs = [e for e in epochs if _is_key(e, every)]
    if not epochs:
        raise SystemExit("no sidecar was written; read the per-pass logs above")
    print()
    side_witness.report(epochs)

    temperatures = _mpa_by_epoch(epochs)
    print(f"\nMPA temperature ({MPA}), max over each sequence; the plateau is "
          f"89.5 K and a decon cooldown starts near 124 K:")
    for epoch, kelvin in zip(epochs, temperatures):
        flag = "  <-- warm: a decon cooldown" if kelvin > DECON_WARM_K else ""
        print(f"  {epoch['label']:34s} {kelvin:7.2f} K{flag}")

    # Proposals in PD-stream time order, which side_witness.discover already
    # gives, so a side run never jumps an execution-plan boundary out of
    # sequence. The decon cycle is that of the latest product IN TIME before
    # the batch, across programs and plans.
    new = [e for e in epochs if _is_key(e, wanted)]
    last_cycle = _latest_cycle(products, before=min(e["start"] for e in new))
    ordered = []
    for epoch in new:
        key = next(k for k in wanted if _is_key(epoch, [k]))
        ordered.append((key, side_witness.map_reading(epoch["led_map"])[0]
                        or "?"))
    ordered += [(k, "?") for k in wanted if k not in [o[0] for o in ordered]]
    warm_keys = [next(k for k in wanted if _is_key(e, [k]))
                 for e, t in zip(epochs, temperatures)
                 if t > DECON_WARM_K and _is_key(e, wanted)]
    new_cycle = next_cycle_name(last_cycle)
    cycles = proposed_cycles([k for k, _ in ordered], warm_keys, last_cycle,
                             new_cycle)

    print("\nproposed labels, in time order (CONFIRM before using -- the "
          "archive does not carry them):")
    runs = side_runs([k for k, _ in ordered],
                     [(side, cycle) for (_, side), cycle
                      in zip(ordered, cycles)])
    runs = [((side, cycle), [k for k in keys if k[0] == program])
            for (side, cycle), keys in runs
            for program in dict.fromkeys(k[0] for k in keys)]   # time order
    for (side, cycle), keys in runs:
        print(f"  {PROGRAM_LABELS[keys[0][0]]} "
              f"{format_plan_passes([k[1:] for k in keys])}: MCE side {side}, "
              f"{cycle}"
              + ("  (unrecognised LED map: decide the side from the PD "
                 "witnesses above)" if side == "?" else ""))
    if warm_keys:
        print(f"  decon: {_key_text(warm_keys[0])} is warm (above "
              f"{DECON_WARM_K:g} K), the top of a cooldown, so it opens a NEW "
              f"cycle; {new_cycle} is the next name after {last_cycle}. "
              f"Earlier passes in the batch stay {last_cycle}.")
    else:
        print(f"  decon: no warm pass, so the same cycle as the latest product "
              f"in time, {last_cycle}")
    commands, placeholders = [], False
    for (side, cycle), keys in runs:
        shown = "<A|B>" if side == "?" else side
        placeholders |= side == "?" or cycle.endswith("?")
        commands.append(f".venv/bin/python batch/refresh.py label --program "
                        f"{keys[0][0]} --passes "
                        f"{format_plan_passes([k[1:] for k in keys])} "
                        f"--decon-cycle {cycle.rstrip('?')} --mce-side {shown}")
    if placeholders:
        commands.append("(a <...> is a decision the evidence does not settle: "
                        "fill it in before running)")
    next_block(*commands)
    return 0


def next_cycle_name(cycle):
    """``"decon2"`` -> ``"decon3"``; ``"decon?"`` or a free name -> ``"<new cycle>"``."""
    match = re.match(r"^(.*?)(\d+)$", str(cycle or ""))
    return f"{match.group(1)}{int(match.group(2)) + 1}" if match else "<new cycle>"


def proposed_cycles(keys, warm_keys, last_cycle, new_cycle):
    """One decon cycle per key, in order: the latest cycle until the first warm
    pass, the new cycle from it on.

    A decon's cooldown is warm for several passes and only the first opens the
    cycle; the later warm passes belong to it too. A second cooldown inside one
    batch is not guessed at: those passes get ``<cycle?>`` for a person.
    """
    out, current, opened = [], last_cycle, False
    for key in keys:
        if key in warm_keys and not opened:
            current, opened = new_cycle, True
        elif key in warm_keys and opened and out and out[-1] != current:
            current = "<cycle?>"
        out.append(current)
    return out


# ---------------------------------------------------------------------------
# label
# ---------------------------------------------------------------------------

def cmd_label(args):
    pairs = parse_plan_passes(args.passes, args.plan)
    side = make_manifest.normalize_side(args.mce_side)
    if not pairs or not side or not args.decon_cycle:
        raise SystemExit("label needs --passes, --decon-cycle and --mce-side "
                         "(A or B); they are operator knowledge, never defaulted")
    manifest = make_manifest._load_existing(args.manifest)
    known = {make_manifest._key(row) for _, row in manifest.iterrows()}
    keys = [(args.program, plan, n) for plan, n in pairs]
    to_add = [k for k in keys if k not in known]
    to_relabel = [k for k in keys if k in known]
    program = PROGRAM_LABELS.get(args.program, args.program)

    print(f"labelling {program} {format_plan_passes(pairs)} as "
          f"{args.decon_cycle} / side {side}: {len(to_add)} new row(s), "
          f"{len(to_relabel)} relabelled")
    if args.dry_run:
        print("  [dry run] nothing written")
        return 0
    backups = os.path.join(BATCH, "manifest_backups")
    os.makedirs(backups, exist_ok=True)
    backup = os.path.join(
        backups, f"run_manifest_{datetime.datetime.now():%Y%m%dT%H%M%S}.csv")
    shutil.copy2(args.manifest, backup)
    print(f"  backed up the manifest to {os.path.relpath(backup, ACTIVITY)}")
    # make_manifest takes one execution plan per call.
    for mode, chosen in (("--append", to_add), ("--relabel", to_relabel)):
        for plan in sorted({k[1] for k in chosen}):
            _run([PYTHON, "batch/make_manifest.py", "--manifest", args.manifest,
                  mode, "--program", args.program, "--execution-plan", plan,
                  "--passes", ranges([k[2] for k in chosen if k[1] == plan]),
                  "--decon-cycle", args.decon_cycle, "--mce-side", side])

    today = datetime.date.today()
    print("\nRecord the decision in MANIFEST.md ('Label decisions' table), e.g.:")
    print(f"  | {today:%Y-%m-%d} | {program} {format_plan_passes(pairs)} added "
          f"as {args.decon_cycle} / {side} | confirmed | <LED map, PD "
          f"witnesses, MPA temperature from 'refresh.py probe'> |")
    next_block(".venv/bin/python batch/refresh.py pull")
    return 0


# ---------------------------------------------------------------------------
# pull
# ---------------------------------------------------------------------------

def cmd_pull(args):
    manifest = make_manifest._load_existing(args.manifest)
    products = products_in(os.path.join(args.root, "h5"))
    rows, skipped = missing_rows(manifest, products, args.min_scas)
    for key, reason in skipped:
        print(f"  not pulled, known absent: {key}  {reason}")

    import pandas as pd

    if not rows:
        # Rewritten header-only rather than left alone: a new-rows manifest
        # from an earlier pull would otherwise still be there to submit, and
        # resubmitting it is harmless only because the worker skips complete
        # products -- rung 1 would still re-plan every row of it.
        pd.DataFrame(columns=make_manifest.MANIFEST_COLUMNS).to_csv(
            NEW_MANIFEST, index=False)
        print(f"every manifest row has a complete product in {args.root}/h5; "
              f"{os.path.relpath(NEW_MANIFEST, ACTIVITY)} emptied")
        next_block(".venv/bin/python batch/refresh.py check")
        return 0

    table = pd.DataFrame(rows)[make_manifest.MANIFEST_COLUMNS]
    table.to_csv(NEW_MANIFEST, index=False)
    print(f"{len(table)} row(s) without a complete product, written to "
          f"{os.path.relpath(NEW_MANIFEST, ACTIVITY)}:")
    print(table.to_string(index=False))
    blank = table[table["mce_side"].astype(str).str.strip() == ""]
    if len(blank):
        print(f"\nWARNING: {len(blank)} row(s) have a BLANK mce_side and will "
              f"be staged as 'assumed:flight-side-A'. That is right only for "
              f"passes before the 2026-10-06 swap; label them first if not.")

    stage, h5 = os.path.join(args.root, "stage"), os.path.join(args.root, "h5")
    token = os.path.relpath(args.token_file, ACTIVITY)
    if args.local:
        # It is about to do the work itself; the alternatives are noise here.
        return _pull_local(args, stage, h5)
    print("\nBy hand (fine for one or two passes; ~9 min each at MAST's rate):")
    for _, row in table.head(args.by_hand_max).iterrows():
        flags = (f"--program {int(row['program'])} --execution-plan "
                 f"{int(row['execution_plan'])} --pass {int(row['pass'])} "
                 f"--decon-cycle {row['decon_cycle']} --blank-dark"
                 + (f" --mce-side {row['mce_side']}" if str(row['mce_side']).strip()
                    else ""))
        for mode in ("--plan-only", "--use-plan"):
            print(f"  .venv/bin/python process_rcs_trending.py {flags} {mode} "
                  f"--staging-root {stage} --out-dir {h5}")
    if len(table) > args.by_hand_max:
        print(f"  ... and {len(table) - args.by_hand_max} more: use SLURM")

    plan = ["sbatch", "--parsable", "--partition=cpu-lg", "--nodes=1",
            "--ntasks-per-node=4", "batch/submit_plan.sbatch", ACTIVITY,
            "batch/run_manifest_new.csv", token, stage, h5, "-1"]
    stream = ["sbatch", "--dependency=afterok:{PLAN}", "--partition=cpu-lg",
              "--nodes=1", "--ntasks-per-node=8", "batch/submit_manifest.sbatch",
              ACTIVITY, "batch/run_manifest_new.csv", token, stage, h5, "-1"]
    print("\nUnder SLURM (both rungs: plan 4-way, then stream 8-way only if no "
          "planning row failed):")
    print("  unset AUX_L2_DIR")
    print(f"  PLAN=$({' '.join(plan)})")
    print("  USE_PLAN=1 " + " ".join(stream).replace("{PLAN}", "${PLAN%%;*}"))
    print("  squeue -u \"$USER\"")
    if args.submit:
        env = dict(os.environ)
        env.pop("AUX_L2_DIR", None)
        result = subprocess.run(plan, cwd=ACTIVITY, env=env, capture_output=True,
                                text=True, check=True)
        job = result.stdout.strip().split(";")[0]
        print(f"\nsubmitted rung 1 as job {job}")
        env["USE_PLAN"] = "1"
        command = [part.replace("{PLAN}", job) for part in stream]
        result = subprocess.run(command, cwd=ACTIVITY, env=env,
                                capture_output=True, text=True, check=True)
        print(f"submitted rung 2 as job {result.stdout.strip()}, held until "
              f"{job} finishes without a failed row")
    next_block("squeue -u \"$USER\"   # until both jobs are gone",
               ".venv/bin/python batch/refresh.py check   # outcomes, triage, "
               "witnesses")
    return 0


# The worker's per-row and per-rank summary lines, as it prints them:
# "planned CAR216_...", "done CAR216_...", "FAILED CAR216_... (see ...)",
# "rank 0/4 finished: 1 done, ...".
TALLY = re.compile(r"(rank \d+/\d+ finished:|(planned|done|skipped|FAILED|"
                   r"degraded) \S)")


def _pull_local(args, stage, h5):
    """Both rungs on this machine: plan with N ranks, then stream with N.

    The same ``run_manifest_worker.py`` the sbatch scripts start, with the same
    rank/world-size split, so a local pull and a SLURM pull leave identical
    products and status files. Streaming starts only if no planning row
    failed, as the SLURM dependency does. Each rank logs to
    batch/logs_local/; the console gets each rank's tally line.
    """
    if not load_token(args.token_file):
        raise SystemExit(f"no MAST token in {args.token_file} or "
                         f"$MAST_API_TOKEN")
    env = dict(os.environ)
    env.pop("AUX_L2_DIR", None)     # MAST, never a stale local reprocessing
    # A rank's stdout is a file here, which python block-buffers: without
    # this the logs stay empty until a rank exits, and cannot be followed.
    env["PYTHONUNBUFFERED"] = "1"
    logs = os.path.join(BATCH, "logs_local")
    os.makedirs(logs, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%dT%H%M%S")
    n = args.local
    for mode in ("--plan-only", "--use-plan"):
        running = []
        for rank in range(n):
            log = os.path.join(logs, f"{stamp}_{mode.strip('-')}_rank{rank}.log")
            command = [PYTHON, "batch/run_manifest_worker.py", "--manifest",
                       NEW_MANIFEST, "--n-tasks", "-1", "--rank", str(rank),
                       "--world-size", str(n), mode, "--staging-root", stage,
                       "--out-dir", h5]
            handle = open(log, "w")
            running.append((rank, log, handle, subprocess.Popen(
                command, cwd=ACTIVITY, env=env, stdout=handle,
                stderr=subprocess.STDOUT)))
        print(f"\n{mode}: {n} rank(s) running, logs "
              f"{os.path.relpath(logs, ACTIVITY)}/{stamp}_{mode.strip('-')}_*",
              flush=True)
        failed = []
        for rank, log, handle, process in running:
            code = process.wait()
            handle.close()
            with open(log) as text:
                tally = [line.strip() for line in text
                         if TALLY.match(line)]
            for line in tally or [f"rank {rank}: no tally line (exit {code})"]:
                print(f"  {line}")
            if code:
                failed.append(rank)
        if failed:
            print(f"\n{mode}: rank(s) {failed} reported a failed row; "
                  + ("not streaming" if mode == "--plan-only" else "see logs"))
            break
    next_block(".venv/bin/python batch/refresh.py check   # outcomes, triage, "
               "witnesses")
    return 1 if failed else 0


# ---------------------------------------------------------------------------
# check
# ---------------------------------------------------------------------------

def read_readouts(h5_dir):
    """``[{label, time, variant, ma_table, mixed}]`` of every raw product, in time.

    ``ma_table`` is the core LED flats' MA table number as stage 1 recorded it
    (dataset attrs, from 2026-10-30); ``None`` for an older product.
    ``mixed`` is set when the six flats, or the SCAs of one flat, disagree.
    """
    import h5py

    out = []
    for path in glob.glob(os.path.join(h5_dir, "*_raw.h5")):
        try:
            with h5py.File(path, "r") as handle:
                attrs = handle.attrs
                tables = set()
                arrays = handle.get("sca_arrays", {})
                for led in (f"LED{i}" for i in range(1, 7)):
                    if led in arrays:
                        value = arrays[led].attrs.get("ma_table_number", "")
                        value = (value.decode() if isinstance(value, bytes)
                                 else str(value))
                        if value:
                            tables.add(value)
                row = {key: attrs.get(key, "") for key in
                       ("run_label", "timestamp", "sequence_variant")}
        except OSError:
            continue
        row = {key: (value.decode() if isinstance(value, bytes) else str(value))
               for key, value in row.items()}
        mixed = len(tables) > 1 or any("|" in t for t in tables)
        table = (int(next(iter(tables)))
                 if len(tables) == 1 and not mixed else None)
        out.append({"label": row["run_label"], "time": row["timestamp"],
                    "variant": row["sequence_variant"], "ma_table": table,
                    "mixed": mixed})
    return sorted(out, key=lambda r: r["time"])


def readout_report(rows, variants=None):
    """``(lines, warnings)``: the recorded MA tables, in time, against the registry.

    A switch between consecutive recorded products is named, because SCA18
    steps ~0.8 % at one (MANIFEST.md, 2026-10-22). A product whose MA table is
    not its variant's ``ma_table``, or whose flats disagree, is a warning: the
    readout changed under an unchanged sequence signature, which the survey
    cannot see, and is the sign of a new variant.
    """
    variants = cfg.SEQUENCE_VARIANTS if variants is None else variants
    recorded = [r for r in rows if r["ma_table"] is not None or r["mixed"]]
    lines, warnings = [], []
    lines.append(f"readout (core LED flats' MA table): {len(recorded)} of "
                 f"{len(rows)} product(s) record it (staged from 2026-10-30)")
    previous = None
    for row in recorded:
        expected = variants.get(row["variant"], {}).get("ma_table")
        if row["mixed"]:
            warnings.append(f"{row['label']}: its LED flats disagree on the MA "
                            f"table; read them with rcs_trend_reader.py summary")
        elif expected is not None and row["ma_table"] != expected:
            warnings.append(f"{row['label']}: MA table {row['ma_table']}, but "
                            f"variant {row['variant']} expects {expected}: the "
                            f"readout changed under the same signature, a new "
                            f"variant (DATA_PULL.md, A new sequence variant)")
        if previous is not None and row["ma_table"] != previous["ma_table"]:
            lines.append(f"  switch {previous['ma_table']} -> {row['ma_table']} "
                         f"between {previous['label']} and {row['label']}: "
                         f"expect SCA18 to step about 0.8 %")
        previous = row
    if recorded:
        tables = sorted({r["ma_table"] for r in recorded
                         if r["ma_table"] is not None})
        lines.append(f"  tables seen: {', '.join(map(str, tables))}; latest "
                     f"{recorded[-1]['label']} = {recorded[-1]['ma_table']}")
    return lines, warnings


def cmd_check(args):
    import pandas as pd

    h5 = os.path.join(args.root, "h5")
    pulled = (pd.read_csv(NEW_MANIFEST, dtype={"mce_side": str})
              if os.path.exists(NEW_MANIFEST) else pd.DataFrame())
    outcomes = worker_outcomes(pulled) if len(pulled) else {}
    if outcomes:
        print(f"worker outcome of the {len(outcomes)} row(s) of the last pull "
              f"({os.path.relpath(NEW_MANIFEST, ACTIVITY)}):")
        for stem, outcome in outcomes.items():
            print(f"  {stem:32s} {outcome}")
        bad = [s for s, o in outcomes.items() if o in ("failed", "degraded")]
        if bad:
            print(f"  {len(bad)} row(s) need action: batch/status/<stem>.* has "
                  f"the reason and batch/logs/<stem>.log the run. A degraded "
                  f"plan is a pass MAST had not finished indexing; re-run "
                  f"refresh.py pull later.")
        print()
    _run([PYTHON, "batch/triage_products.py", h5], check=False)
    print()
    lines, warnings = readout_report(read_readouts(h5))
    for line in lines:
        print(line)
    for warning in warnings:
        print(f"  WARNING: {warning}")
    epochs = side_witness.discover([h5])
    print()
    bad = side_witness.report(epochs)
    if bad:
        next_block("fix the manifest label(s) named above with "
                   "batch/refresh.py label, then re-stage those passes with "
                   "--force (refresh.py pull prints the commands)")
        return 2
    next_block(".venv/bin/python run_trend.py --dry-run   # read the plan",
               ".venv/bin/python run_trend.py             # stages 2 and 3",
               "and add a line to MANIFEST.md for anything that happened")
    return 0


# ---------------------------------------------------------------------------
# seed
# ---------------------------------------------------------------------------

SEED_NOTE = "SEEDED_FROM.txt"
# Left behind by an interrupted write-then-rename; never part of a tree.
_TEMPORARY = re.compile(r"\.tmp\d*$")


def tree_files(root):
    """``{relative path: size}`` for every regular file under ``root``."""
    out = {}
    for directory, subdirs, names in os.walk(root):
        subdirs.sort()
        for name in names:
            if _TEMPORARY.search(name) or name == SEED_NOTE:
                continue
            path = os.path.join(directory, name)
            if os.path.isfile(path) and not os.path.islink(path):
                out[os.path.relpath(path, root)] = os.path.getsize(path)
    return out


def _copy_one(source, dest, relative):
    target = os.path.join(dest, relative)
    os.makedirs(os.path.dirname(target), exist_ok=True)
    temporary = f"{target}.tmp{os.getpid()}"
    shutil.copy2(os.path.join(source, relative), temporary)
    rcs_fsutil.replace(temporary, target)
    return relative


def cmd_seed(args):
    source, dest = os.path.abspath(args.source), os.path.abspath(args.root)
    if source == dest:
        raise SystemExit("--from and --root are the same tree")
    if not os.path.isdir(os.path.join(source, "h5")):
        raise SystemExit(f"{source} has no h5/: not a trend tree")
    wanted = tree_files(source)
    have = tree_files(dest) if os.path.isdir(dest) else {}
    if have and not args.resume:
        raise SystemExit(f"{dest} already holds {len(have)} file(s). Seeding "
                         f"only ever fills an empty tree; --resume finishes an "
                         f"interrupted seed (copies what is missing or a "
                         f"different size, touches nothing else)")
    extra = sorted(set(have) - set(wanted))
    todo = sorted(r for r, size in wanted.items() if have.get(r) != size)
    by_top = {}
    for relative in todo:
        top = relative.split(os.sep)[0] if os.sep in relative else "."
        count, size = by_top.get(top, (0, 0))
        by_top[top] = (count + 1, size + wanted[relative])
    total = sum(wanted[r] for r in todo)
    print(f"seed {dest}\n  from {source}: {len(wanted)} file(s), "
          f"{sum(wanted.values()) / 1e9:.2f} GB; {len(todo)} to copy "
          f"({total / 1e9:.2f} GB)")
    for top, (count, size) in sorted(by_top.items()):
        print(f"    {top + '/':24s} {count:6d} file(s) {size / 1e9:8.3f} GB")
    if extra:
        print(f"  {len(extra)} file(s) in {dest} are not in the source and are "
              f"left alone, e.g. {extra[:3]}")
    if args.dry_run:
        next_block(f".venv/bin/python batch/refresh.py seed --from {source} "
                   f"--root {dest}" + (" --resume" if have else ""))
        return 0

    os.makedirs(dest, exist_ok=True)
    done, step = 0, max(1, len(todo) // 10)
    with concurrent.futures.ThreadPoolExecutor(args.jobs) as pool:
        for relative in pool.map(lambda r: _copy_one(source, dest, r), todo):
            done += 1
            if done % step == 0 or done == len(todo):
                print(f"  copied {done}/{len(todo)}", flush=True)

    copied = tree_files(dest)
    wrong = sorted(r for r, size in wanted.items() if copied.get(r) != size)
    if wrong:
        raise SystemExit(f"{len(wrong)} file(s) did not arrive intact, e.g. "
                         f"{wrong[:3]}; re-run with --resume")
    stamp = datetime.datetime.now().astimezone().isoformat(timespec="seconds")
    with open(os.path.join(dest, SEED_NOTE), "a") as note:
        note.write(f"{stamp}  seeded from {source} by {os.environ.get('USER', '?')}"
                   f" with batch/refresh.py seed{' --resume' if have else ''}: "
                   f"{len(wanted)} file(s), {sum(wanted.values())} bytes, "
                   f"every size verified\n")
    print(f"  verified: all {len(wanted)} file(s) present at the source's size; "
          f"recorded in {os.path.join(dest, SEED_NOTE)}")
    hint = ("" if os.path.abspath(cfg.TREND_ROOT) == dest
            else f" --root {dest}")
    next_block(f".venv/bin/python batch/refresh.py status{hint}   # the tree "
               f"is ready; this survey says what is new")
    return 0


# ---------------------------------------------------------------------------
# CLI and self-test
# ---------------------------------------------------------------------------

def self_test():
    """The selection logic, on synthetic manifests and products."""
    import tempfile

    import h5py
    import pandas as pd

    print("== refresh ==")
    assert ranges([53, 54, 55, 57, 71, 72]) == "53-55,57,71-72"
    assert parse_passes("53-55,57") == [53, 54, 55, 57]
    print("  ok   pass ranges round-trip")
    assert side_runs([53, 54, 71, 72], ["A", "A", "B", "B"]) == [
        ("A", [53, 54]), ("B", [71, 72])]
    print("  ok   proposed sides group into contiguous runs, one label command "
          "each")
    assert next_cycle_name("decon2") == "decon3"
    assert next_cycle_name("decon?") == "<new cycle>"
    keys = [(1063, 5, 11), (1063, 5, 12), (1063, 6, 1), (1063, 6, 2)]
    assert proposed_cycles(keys, [(1063, 6, 1), (1063, 6, 2)], "decon2",
                           "decon3") == ["decon2", "decon2", "decon3", "decon3"]
    assert side_runs(keys, [("B", "decon2"), ("B", "decon2"), ("B", "decon3"),
                            ("B", "decon3")]) == [
        (("B", "decon2"), keys[:2]), (("B", "decon3"), keys[2:])]
    import pandas as pd
    l2 = pd.DataFrame([{"observation": o, "detector": f"WFI{d:02d}"}
                       for o in range(2, 8) for d in range(1, 19)]
                      + [{"observation": 11, "detector": "WFI01"}])
    assert core_l2_scas(l2) == 18
    assert core_l2_scas(l2[l2["observation"] != 5]) == 0
    sig = cfg.SEQUENCE_VARIANTS["car216_decon3"]["signature"]
    assert variant_name({"signature": sig}, 1063) == "car216_decon3"
    core = cfg.SEQUENCE_VARIANTS["car190"]["signature"]
    assert variant_name({"signature": core}, 1039) == "car190"
    assert variant_name({"signature": core}, 1063) == "car216|car216_decon3?"
    assert variant_name({"signature": "1:Dx1@180 2:Dx9@40"}, 1063) == "UNKNOWN"
    assert variant_name({"signature": ""}) == "?"
    print("  ok   completeness is the core flats at L2; a sequence is named, or "
          "UNKNOWN")
    print("  ok   a cooldown in a batch splits it: the first warm pass opens "
          "the next cycle, the passes before it keep the old one")
    assert parse_plan_passes("4:8-10,5:1-2") == [(4, 8), (4, 9), (4, 10),
                                                 (5, 1), (5, 2)]
    assert parse_plan_passes("75-76", plan=3) == [(3, 75), (3, 76)]
    assert parse_plan_passes("4:9,10,5:1") == [(4, 9), (4, 10), (5, 1)]
    assert format_plan_passes([(4, 8), (4, 9), (4, 10), (5, 1)]) == "4:8-10,5:1"
    try:
        parse_plan_passes("8-10")
        raise AssertionError("bare passes with no plan were accepted")
    except SystemExit:
        pass
    print("  ok   plan-qualified pass lists cross an execution-plan boundary")
    for line, wanted in (("rank 2/4 finished: 0 done, 2 planned", True),
                         ("planned CAR216_01063_05_004_decon2", True),
                         ("FAILED CAR216_01063_05_004_decon2 (see logs)", True),
                         ("  read query plan /x/y.json", False)):
        assert bool(TALLY.match(line)) == wanted, line
    print("  ok   the local pull recognises the worker's tally lines")

    variants = {"a": {"ma_table": 9008}, "b": {"ma_table": 9010}}
    rows = [{"label": "old", "time": "1", "variant": "a", "ma_table": None,
             "mixed": False},
            {"label": "p1", "time": "2", "variant": "b", "ma_table": 9010,
             "mixed": False},
            {"label": "p2", "time": "3", "variant": "a", "ma_table": 9008,
             "mixed": False},
            {"label": "p3", "time": "4", "variant": "a", "ma_table": 9010,
             "mixed": False}]
    lines, warnings = readout_report(rows, variants)
    assert "2 of 4" not in lines[0] and "3 of 4" in lines[0], lines
    assert sum("switch" in line for line in lines) == 2, lines
    assert len(warnings) == 1 and warnings[0].startswith("p3"), warnings
    print("  ok   the readout check names each MA-table switch and flags a "
          "table its variant does not expect")

    with tempfile.TemporaryDirectory() as tmp:
        def product(name, covered):
            with h5py.File(os.path.join(tmp, name), "w") as handle:
                handle["coverage/per_sca"] = np.arange(18) < covered
                handle.attrs["stage"] = "raw"
                handle.attrs["product_kind"] = "per_sca"
        product("CAR190_01039_03_056_001_20261005_raw.h5", 18)
        product("CAR190_01039_03_057_001_20261006_raw.h5", 5)
        found = products_in(tmp)
        assert found[(1039, 3, 56)][1] == 18 and found[(1039, 3, 57)][1] == 5
        # Chronology across programs: a CAR-216 plan-4 product stamped after
        # both CAR-190 ones is the latest, whatever its plan or pass number.
        for name, stamp in (("CAR190_01039_03_056_001_20261005_raw.h5",
                             "2026-10-05T11:29:00"),
                            ("CAR190_01039_03_057_001_20261006_raw.h5",
                             "2026-10-06T04:03:00")):
            with h5py.File(os.path.join(tmp, name), "a") as handle:
                handle.attrs["timestamp"] = stamp
        product("CAR216_01063_04_001_001_20261009_raw.h5", 18)
        with h5py.File(os.path.join(
                tmp, "CAR216_01063_04_001_001_20261009_raw.h5"), "a") as handle:
            handle.attrs["timestamp"] = "2026-10-09T04:35:00"
        latest = latest_products(products_in(tmp), 2)
        assert latest == [(1039, 3, 57), (1063, 4, 1)], latest
        print("  ok   probe context is the latest products in time, across "
              "programs and plans")
        found = {k: v for k, v in products_in(tmp).items() if k[0] == 1039}
        manifest = pd.DataFrame([
            {"program": 1039, "execution_plan": p, "pass": n,
             "decon_cycle": "decon2", "blank_dark": True, "mce_side": s}
            for p, n, s in ((3, 56, "A"), (3, 57, "A"), (3, 71, "B"),
                            (2, 25, ""))])
        rows, skipped = missing_rows(manifest, found)
        keys = [make_manifest._key(r) for r in rows]
        assert keys == [(1039, 3, 57), (1039, 3, 71)], keys
        assert skipped == [((1039, 2, 25), KNOWN_ABSENT[(1039, 2, 25)])]
        print("  ok   pull selects short and absent products, skips complete "
              "ones, and never the known-absent pass 25")
    with tempfile.TemporaryDirectory() as tmp:
        source, dest = os.path.join(tmp, "src"), os.path.join(tmp, "dst")
        os.makedirs(os.path.join(source, "h5", "pd"))
        for name, body in (("h5/a_raw.h5", "aaaa"), ("h5/pd/p.ecsv", "pp"),
                           ("card.ecsv", "c"), ("h5/stray.h5.tmp123", "x")):
            with open(os.path.join(source, name), "w") as handle:
                handle.write(body)
        args = argparse.Namespace(source=source, root=dest, resume=False,
                                  dry_run=False, jobs=2)
        assert cmd_seed(args) == 0
        assert tree_files(dest) == {"h5/a_raw.h5": 4, "h5/pd/p.ecsv": 2,
                                    "card.ecsv": 1}, tree_files(dest)
        assert os.path.exists(os.path.join(dest, SEED_NOTE))
        try:
            cmd_seed(args)
            raise AssertionError("a second seed into a full tree was allowed")
        except SystemExit:
            pass
        os.remove(os.path.join(dest, "h5", "pd", "p.ecsv"))
        assert cmd_seed(argparse.Namespace(source=source, root=dest,
                                           resume=True, dry_run=False,
                                           jobs=2)) == 0
        assert "h5/pd/p.ecsv" in tree_files(dest)
        print("  ok   seed copies a tree, skips temporaries, refuses a full "
              "destination, and --resume restores a missing file")
    print("refresh self-test: all passed")
    return True


def main(argv=None):
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--self-test", action="store_true", dest="self_test")
    sub = parser.add_subparsers(dest="command")
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--root", default=cfg.TREND_ROOT,
                        help="trend tree (default %(default)s)")
    common.add_argument("--manifest", default=make_manifest.DEFAULT_MANIFEST)
    common.add_argument("--token-file",
                        default=os.path.join(ACTIVITY, "..", "..", "variables.env"))
    common.add_argument("--min-scas", type=int, default=cfg.MIN_SCAS)
    status = sub.add_parser("status", parents=[common],
                            help="what is new, missing or stale")
    status.add_argument("--reuse-survey", type=float, nargs="?", const=6.0,
                        default=0.0, metavar="HOURS",
                        help="reuse the last survey if it is under HOURS old "
                             "(default 6 when given): for re-running status "
                             "after a failure without surveying again")
    status.add_argument("--all-programs", action="store_true",
                        help="the default now; kept so older commands work")
    status.add_argument("--program", type=int, action="append",
                        choices=sorted(PROGRAM_LABELS),
                        help="survey only this program (repeatable; default: "
                             "every program, ~15 min, most of it CAR-216)")
    probe = sub.add_parser("probe", parents=[common],
                           help="PD-only witnesses for new passes")
    label = sub.add_parser("label", parents=[common],
                           help="write labels into the manifest")
    for command in (probe, label):
        command.add_argument("--program", type=int, default=1039)
        command.add_argument("--plan", type=int, default=None,
                             help="execution plan for bare pass ranges")
        command.add_argument("--passes", required=True,
                             help="e.g. 75-80,82, or plan-qualified across a "
                                  "plan boundary: 4:8-10,5:1-5")
    probe.add_argument("--also", action="append", default=[],
                       metavar="PROGRAM:PASSES",
                       help="more passes of another program, probed in the "
                            "same call so all of them read in one time "
                            "order: e.g. --also 1039:3:94-98 (repeatable)")
    probe.add_argument("--context", type=int, default=2,
                       help="the latest products in time to probe alongside, "
                            "any program or plan (default 2)")
    probe.add_argument("--scratch", default=None)
    probe.add_argument("--jobs", type=int, default=4)
    label.add_argument("--decon-cycle", required=True)
    label.add_argument("--mce-side", required=True)
    label.add_argument("--dry-run", action="store_true")
    pull = sub.add_parser("pull", parents=[common],
                          help="the rows to stage, and how")
    pull.add_argument("--submit", action="store_true",
                      help="submit both SLURM rungs instead of only printing them")
    pull.add_argument("--by-hand-max", type=int, default=2)
    pull.add_argument("--local", type=int, default=0, metavar="N",
                      help="run both rungs here with N worker ranks each, and "
                           "wait (instead of printing or submitting SLURM)")
    seed = sub.add_parser("seed", parents=[common],
                          help="copy a whole trend tree into an empty --root")
    seed.add_argument("--from", dest="source", required=True,
                      help="the tree to copy, e.g. /data/eswitzer/rcs_trend_v4")
    seed.add_argument("--resume", action="store_true",
                      help="finish an interrupted seed")
    seed.add_argument("--dry-run", action="store_true")
    seed.add_argument("--jobs", type=int, default=8,
                      help="parallel file copies (default %(default)s)")
    sub.add_parser("check", parents=[common], help="triage + side witnesses")
    args = parser.parse_args(argv)

    if args.self_test:
        return 0 if self_test() else 1
    handlers = {"status": cmd_status, "probe": cmd_probe, "label": cmd_label,
                "pull": cmd_pull, "check": cmd_check, "seed": cmd_seed}
    if args.command not in handlers:
        parser.print_help()
        return 2
    return handlers[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
