#!/bin/bash
# Launched once per SLURM task by srun (see submit_manifest.sbatch and
# submit_plan.sbatch). All of REPO_ROOT/MANIFEST/TOKEN_FILE/STAGING_ROOT/
# OUT_DIR/N_TASKS/QUERY_DELAY_SECONDS/MIN_SCAS/QUERY_LEASES/BIN_FACTOR/
# AUX_L2_DIR/PLAN_ONLY/USE_PLAN/FORCE are exported by the parent sbatch script;
# SLURM_PROCID/SLURM_NTASKS are set by srun itself. Every one is optional
# except the first six.
set -euo pipefail

cd "$REPO_ROOT"

# Parse MAST_API_TOKEN out of $TOKEN_FILE. Accepts the variables.env
# convention rcs_edp.edp_token() already reads elsewhere in this repo:
# a line like MAST_API_TOKEN='...' (quotes optional).
token_line="$(grep -m1 '^MAST_API_TOKEN' "$TOKEN_FILE")"
export MAST_API_TOKEN="$(echo "$token_line" | cut -d= -f2- | tr -d "'\" ")"
if [ -z "$MAST_API_TOKEN" ]; then
    echo "worker_entrypoint.sh: no MAST_API_TOKEN found in $TOKEN_FILE" >&2
    exit 1
fi

# Every task in the allocation starts at once, so without this every rank's
# first MAST query lands in the same instant. The stagger is now --stagger in
# the worker, which spreads over a window scaled by --world-size: the old
# `RANDOM % 61` here was flat regardless of fan-out width, so widening from
# 8-way to 32-way quadrupled the listing *rate* into the same 61s window --
# exactly the overload this is meant to prevent. It also skips itself under
# USE_PLAN, where no listing calls are issued at all.

exec "$REPO_ROOT/.venv/bin/python" "$REPO_ROOT/batch/run_manifest_worker.py" \
    --manifest "$MANIFEST" --n-tasks "$N_TASKS" \
    --rank "$SLURM_PROCID" --world-size "$SLURM_NTASKS" \
    --staging-root "$STAGING_ROOT" --out-dir "$OUT_DIR" --stagger \
    ${FORCE:+--force} \
    ${QUERY_DELAY_SECONDS:+--query-delay-seconds "$QUERY_DELAY_SECONDS"} \
    ${MIN_SCAS:+--min-scas "$MIN_SCAS"} \
    ${QUERY_LEASES:+--query-leases "$QUERY_LEASES"} \
    ${BIN_FACTOR:+--bin "$BIN_FACTOR"} \
    ${AUX_L2_DIR:+--aux-l2-dir "$AUX_L2_DIR"} \
    ${PLAN_ONLY:+--plan-only} \
    ${USE_PLAN:+--use-plan}
