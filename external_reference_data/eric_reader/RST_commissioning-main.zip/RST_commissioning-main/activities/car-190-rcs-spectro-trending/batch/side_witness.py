"""Which MCE side was each epoch on? Read the witnesses, before staging imagery.

Nothing in the L2 metadata or the telemetry names the MCE side -- every RCS
mnemonic is bank-specific and none is side-specific (PD_CORRECTION.md s8) -- so
the side is an operator label, recorded in batch/run_manifest.csv's
``mce_side`` column. This tool prints the evidence that label should agree with,
one row per epoch, from files that are cheap to make: a ``--pd-only`` sidecar
streams no imagery and takes ~2 min per pass, almost all of it the MAST listing.

    python batch/side_witness.py /tmp/probe/pd                  # sidecars
    python batch/side_witness.py /data/eswitzer/rcs_trend_v3/h5 # raw products
    python batch/side_witness.py --strict DIR ...   # exit 2 on a disagreement

Four witnesses per epoch, the first of them found at the 2026-10-06 swap:

* **The LED map** -- which EDP ``BANK2SEL`` select line was enabled during each
  sequence activity. It changed on every pass after the swap and on none before
  it, so unlike the other three it needs no baseline: one pass reads it.
  It is a *numbering* change, not a wavelength change -- PD1's InGaAs cutoff
  stays on sequence LED6, and LED2 keeps its PD1/PD2 ratio rather than taking
  the ratio of the LED its new hardware number used to mean.
* **PD2 and PD1 pedestals** -- the diodes are different devices on each side.
  At the swap PD2 fell 1.93 mV and PD1 rose 1.07 mV, against a 0.32 mV total
  range over 176 A-side epochs.
* **``pd_check_ratio`` per sequence slot** -- PD1/PD2 on the same LED, so lamp
  changes divide out and only a diode change survives. A swap moves it
  *chromatically* (-5.9 to +0.5 % across the six LEDs at the real one); the
  epoch-11 readout-chain shift moved it 0.14 % and achromatically.

The ratio is keyed by **sequence slot, not hardware number**: the hardware
numbering is what the swap changed, so keying by it compares different physical
LEDs across the boundary. (``calibration_plots._check_ratio_by_hardware_led``
still does; on the real swap it turns a -0.9 % LED4 shift into -12.8 %.)
"""
import argparse
import glob
import os
import sys

import h5py
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import rcs_trend_config as cfg  # noqa: E402

# Sequence LED1..LED6 -> hardware BANK2SEL number. Named for what they were
# observed on, not asserted as properties of a side: one swap has been seen.
KNOWN_MAPS = {
    (6, 1, 2, 3, 4, 5): ("A", "every v3 epoch, 2026-09-12..10-06 (TVAC's order "
                              "too)"),
    (1, 3, 2, 4, 6, 5): ("B", "CAR-190 plan 3 passes 71-74, after the "
                              "2026-10-06 swap"),
}

# Block medians either side of a map change, as in calibration_plots'
# _level_shift_sigmas: a one-epoch excursion is not a level change.
BLOCK = 5


def _text(value):
    return value.decode() if isinstance(value, bytes) else str(value)


def read_epoch(path):
    """One epoch's witnesses, or ``None`` for an h5 with no photodiode table."""
    with h5py.File(path, "r") as handle:
        group = handle.get("photodiode/per_activity")
        if group is None or "hardware_led" not in group:
            return None
        keys = [_text(k) for k in group["activity_key"][()]]
        hardware = np.asarray(group["hardware_led"][()], dtype=int)
        ratio = (np.asarray(group["pd_check_ratio"][()], dtype=float)
                 if "pd_check_ratio" in group else np.full(len(keys), np.nan))
        by_slot = {}
        for key, hw, value in zip(keys, hardware, ratio):
            if key in cfg.LED_NAMES and key not in by_slot:
                by_slot[key] = (int(hw), float(value))
        led_map = tuple(by_slot.get(led, (-1, np.nan))[0]
                        for led in cfg.LED_NAMES)
        check = np.array([by_slot.get(led, (-1, np.nan))[1]
                          for led in cfg.LED_NAMES])

        def pedestal(name):
            attrs = handle[name].attrs if name in handle else {}
            return (float(attrs.get("value", np.nan)),
                    float(attrs.get("rms", np.nan)))

        stream = handle.get("photodiode/stream/time")
        start = (np.datetime64(int(stream[0]), "ns")
                 if stream is not None and len(stream) else None)
        label = _text(handle.attrs.get("run_label",
                                       os.path.basename(path)[:-3]))
        side = _text(handle.attrs.get("mce_side", ""))
        source = _text(handle.attrs.get("mce_side_source", ""))
        return {"path": path, "label": label, "start": start,
                "led_map": led_map, "check_ratio": check,
                "pd2": pedestal("photodiode/pedestal"),
                "pd1": pedestal("photodiode/check_pedestal"),
                "mce_side": side, "mce_side_source": source}


def discover(inputs):
    """Every readable epoch under ``inputs``, in time order.

    Time order from the PD stream itself, never the filename: pass numbers
    restart per program and plan, so name order interleaves CAR-190 and CAR-216
    and puts a boundary in the wrong place (rcs-epoch-ordering-trap).
    """
    paths = []
    for item in inputs:
        if os.path.isdir(item):
            paths += glob.glob(os.path.join(item, "*.h5"))
        else:
            paths += glob.glob(item)
    epochs = [e for e in (read_epoch(p) for p in sorted(set(paths))) if e]
    undated = [e["label"] for e in epochs if e["start"] is None]
    if undated:
        raise SystemExit(f"no photodiode/stream/time, so no time order, for "
                         f"{undated[:5]}")
    return sorted(epochs, key=lambda e: e["start"])


def map_reading(led_map):
    known = KNOWN_MAPS.get(tuple(led_map))
    return (known[0], known[1]) if known else (None, "an unrecognised map")


def boundaries(epochs):
    """Indices ``i`` where epoch ``i``'s LED map differs from epoch ``i-1``'s."""
    return [i for i in range(1, len(epochs))
            if epochs[i]["led_map"] != epochs[i - 1]["led_map"]]


def shift_at(epochs, index, block=BLOCK):
    """Block-median shifts across a boundary: PD2, PD1 (V) and ratio (%)."""
    before = epochs[max(0, index - block):index]
    after = epochs[index:index + block]

    def median(rows, pick):
        return np.nanmedian(np.array([pick(r) for r in rows]), axis=0)

    pd2 = median(after, lambda r: r["pd2"][0]) - median(before, lambda r: r["pd2"][0])
    pd1 = median(after, lambda r: r["pd1"][0]) - median(before, lambda r: r["pd1"][0])
    ratio = 100 * (median(after, lambda r: r["check_ratio"])
                   / median(before, lambda r: r["check_ratio"]) - 1)
    return pd2, pd1, ratio, len(before), len(after)


def disagreements(epochs):
    """Epochs whose recorded side contradicts a recognised LED map."""
    out = []
    for epoch in epochs:
        side, _ = map_reading(epoch["led_map"])
        if side and epoch["mce_side"] and epoch["mce_side"] != side:
            out.append((epoch, side))
    return out


def report(epochs, out=print):
    out(f"{len(epochs)} epoch(s), in PD-stream time order")
    out(f"{'label':34s} {'start (UTC)':17s} {'map':6s} {'reads':5s} "
        f"{'label':10s} {'PD2 ped mV':>10s} {'rms uV':>6s} {'PD1 ped mV':>10s}  "
        + " ".join(f"{led:>6s}" for led in cfg.LED_NAMES))
    previous = None
    for epoch in epochs:
        side, _ = map_reading(epoch["led_map"])
        code = "".join(str(h) if h > 0 else "?" for h in epoch["led_map"])
        recorded = epoch["mce_side"] or "-"
        if epoch["mce_side_source"].startswith("assumed"):
            recorded += " (asm)"
        marker = "  <-- LED map changed" if (
            previous is not None and epoch["led_map"] != previous) else ""
        out(f"{epoch['label']:34s} {str(epoch['start'])[:16]:17s} {code:6s} "
            f"{side or '?':5s} {recorded:10s} {1e3 * epoch['pd2'][0]:10.3f} "
            f"{1e6 * epoch['pd2'][1]:6.1f} {1e3 * epoch['pd1'][0]:10.3f}  "
            + " ".join(f"{v:6.3f}" for v in epoch["check_ratio"]) + marker)
        previous = epoch["led_map"]

    for index in boundaries(epochs):
        pd2, pd1, ratio, n_before, n_after = shift_at(epochs, index)
        left, right = epochs[index - 1], epochs[index]
        out(f"\nLED map change between {left['label']} and {right['label']}")
        for epoch in (left, right):
            side, where = map_reading(epoch["led_map"])
            out(f"  {epoch['label']}: map reads side {side or '?'} ({where})")
        out(f"  block medians, {n_before} epoch(s) before vs {n_after} after:")
        out(f"    PD2 pedestal {1e3 * pd2:+.3f} mV, PD1 pedestal "
            f"{1e3 * pd1:+.3f} mV")
        out("    pd_check_ratio by sequence slot: "
            + ", ".join(f"{led} {r:+.1f}%" for led, r in zip(cfg.LED_NAMES, ratio))
            + f"  (spread {np.nanmax(ratio) - np.nanmin(ratio):.1f} points)")
        if n_after < 3 or n_before < 3:
            out("    fewer than 3 epochs on one side: read the shift as "
                "provisional, a one-epoch excursion looks the same")

    bad = disagreements(epochs)
    if bad:
        out("")
    for epoch, side in bad:
        out(f"WARNING: {epoch['label']} is labelled mce_side="
            f"{epoch['mce_side']} ({epoch['mce_side_source'] or 'no source'}) "
            f"but its LED map reads side {side}. Check the manifest's mce_side "
            f"for this pass before calibrating; the label is what stage 2 uses.")
    if not boundaries(epochs):
        out("\nno LED map change in this set")
    return bad


def self_test():
    """Synthetic sidecars: no network, no credentials, nothing kept."""
    import tempfile

    print("== side_witness ==")
    a_map, b_map = (6, 1, 2, 3, 4, 5), (1, 3, 2, 4, 6, 5)
    a_ratio = np.array([1.135, 1.056, 1.163, 1.193, 1.167, 0.205])
    b_ratio = np.array([1.068, 1.040, 1.169, 1.182, 1.157, 0.188])

    def write(path, start_ns, led_map, ratio, pd2, pd1, side=None):
        with h5py.File(path, "w") as handle:
            handle.attrs["run_label"] = os.path.basename(path)[:-3]
            if side:
                handle.attrs["mce_side"] = side
                handle.attrs["mce_side_source"] = "cli"
            group = handle.create_group("photodiode/per_activity")
            group["activity_key"] = np.array(
                [b"DARK"] + [n.encode() for n in cfg.LED_NAMES])
            group["hardware_led"] = np.array((-1,) + tuple(led_map))
            group["pd_check_ratio"] = np.concatenate([[np.nan], ratio])
            handle.create_group("photodiode/pedestal").attrs.update(
                {"value": pd2, "rms": 1e-5})
            handle.create_group("photodiode/check_pedestal").attrs.update(
                {"value": pd1, "rms": 1e-6})
            handle["photodiode/stream/time"] = np.array([start_ns], np.int64)

    with tempfile.TemporaryDirectory() as tmp:
        hour = 3_600_000_000_000
        # Names sort OPPOSITE to time, so a filename sort would put the swap
        # in the wrong place and the test would see two boundaries, not one.
        for n in range(4):
            write(os.path.join(tmp, f"z{n}.h5"), n * hour, a_map, a_ratio,
                  0.11637, 0.11205, side="A")
        for n in range(4):
            write(os.path.join(tmp, f"a{n}.h5"), (10 + n) * hour, b_map,
                  b_ratio, 0.11445, 0.11312, side="B" if n else "A")
        with h5py.File(os.path.join(tmp, "not_pd.h5"), "w") as handle:
            handle.attrs["stage"] = "raw"

        epochs = discover([tmp])
        assert len(epochs) == 8, len(epochs)
        print("  ok   an h5 with no photodiode table is skipped, not an error")
        assert boundaries(epochs) == [4], boundaries(epochs)
        print("  ok   epochs order by PD-stream time, not filename: one "
              "boundary, in the right place")

        pd2, pd1, ratio, _, _ = shift_at(epochs, 4)
        assert abs(pd2 - (0.11445 - 0.11637)) < 1e-12 and pd1 > 0
        # By sequence slot, LED4 moves -0.9 %. Keyed by hardware number it
        # would compare A's hw4 (LED5) with B's hw4 (LED4): +1.3 %, a
        # different LED. And hw3 would read -12.8 %.
        assert abs(ratio[3] - 100 * (1.182 / 1.193 - 1)) < 1e-9, ratio
        assert abs(ratio[5] - 100 * (0.188 / 0.205 - 1)) < 1e-9, ratio
        print("  ok   the ratio shift is by sequence slot, so LED4 reads its "
              "own -0.9 % and not a neighbour's")

        bad = disagreements(epochs)
        assert [e["label"] for e, _ in bad] == ["a0"], bad
        lines = []
        report(epochs, out=lines.append)
        text = "\n".join(lines)
        assert "WARNING: a0 is labelled mce_side=A" in text, text
        assert text.count("<-- LED map changed") == 1, text
        print("  ok   an A label on a B-map epoch is warned about by name, and "
              "the boundary is marked once")

        assert map_reading((2, 1, 3, 4, 5, 6))[0] is None
        print("  ok   an unrecognised map reads '?', not a guessed side")
    print("side_witness self-test: all passed")
    return True


def main():
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("inputs", nargs="*",
                        help="directories (every *.h5 in them) or globs: PD "
                        "sidecars, raw or calibrated products")
    parser.add_argument("--strict", action="store_true",
                        help="exit 2 if any epoch's mce_side label contradicts "
                        "its LED map -- for a scheduled intake check")
    parser.add_argument("--self-test", action="store_true", dest="self_test")
    args = parser.parse_args()
    if args.self_test:
        sys.exit(0 if self_test() else 1)
    if not args.inputs:
        parser.error("give at least one directory or glob")
    epochs = discover(args.inputs)
    if not epochs:
        raise SystemExit(f"no h5 with a photodiode/per_activity table under "
                         f"{args.inputs}")
    bad = report(epochs)
    if args.strict and bad:
        sys.exit(2)


if __name__ == "__main__":
    main()
