#!/bin/bash
# Stage 2: build the reference card over a directory of raw per-SCA products,
# then calibrate every one of them.
#
#   batch/run_calibration.sh <raw_dir> <cal_dir> [card.ecsv] [jobs] [extra...]
#
# Anything after the four positionals is forwarded verbatim to the calibration
# step (step 2 below), not to the card step. That is how the temperature-gain
# reference block gets in:
#
#   batch/run_calibration.sh "$ROOT/h5" "$ROOT/h5_cal" rcs_reference_card.ecsv \
#       "$(nproc)" --tempgain-model tempgain_model.ecsv
#
# The card is deliberately NOT given the extra flags: it is the one artifact
# that must stay reproducible from the raw set alone, and a gain model has no
# bearing on which epoch is the reference or where the ACM moved.
#
# Deliberately not an sbatch script. Calibration touches no network, reads
# ~33 MB and writes ~33 MB per epoch, and takes 1-2 s/file: 168 epochs is about
# five minutes single-threaded, less with --jobs. A SLURM fan-out would spend
# more wall-clock queueing than computing, and would reintroduce the thing
# stage 1 needs the batch system for (concurrency limits on a remote API) where
# there is no remote API. If you do need the escape hatch, calibrate_rcs_products.py
# takes --in on a file as happily as on a directory, so splitting by file list
# across ranks needs no new code.
#
# Two steps, in this order, and the order is the whole design:
#
#   1. --make-card is the ONLY step that sees the entire set. It is
#      metadata-only (~0.1 s/file): it picks the reference epoch, records that
#      epoch's pd_net per LED, segments the run by ACM LVDT, and writes the
#      per-segment reference LVDT. The card is a committed ECSV artifact, so
#      every later calibration is reproducible from a file rather than from
#      whatever happened to be in the directory that day.
#   2. calibration is then strictly per-file and parallel, because every
#      number it needs is in the card.
#
# What this does NOT do is the cross-epoch ACM bridge. A bridge step is fitted
# from the epochs either side of a boundary, so it cannot be baked into a
# per-file product; calibrated products carry bridge_applied=False and
# acm_mode="linear", and make_sca_digests.py applies the bridge at trend level.
set -euo pipefail

RAW_DIR="${1:?usage: batch/run_calibration.sh <raw_dir> <cal_dir> [card.ecsv] [jobs] [extra...]}"
CAL_DIR="${2:?cal dir required}"
CARD="${3:-rcs_reference_card.ecsv}"
JOBS="${4:-$(nproc)}"

# Shift off however many of the four positionals were actually supplied, so
# "$@" is left holding only the pass-through flags. A plain `shift 4` would
# abort under `set -u` when the caller gave two.
for _ in 1 2 3 4; do
    [[ $# -gt 0 ]] && shift
done
EXTRA=("$@")

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON="$REPO_ROOT/.venv/bin/python"

cd "$REPO_ROOT"
mkdir -p "$CAL_DIR"

echo "=== 1/2 reference card over $RAW_DIR -> $CARD ==="
"$PYTHON" calibrate_rcs_products.py --make-card \
    --raw-dir "$RAW_DIR" --card "$CARD"

# Step 1 rebuilds the card over whatever the raw directory now holds, and step 2
# skips epochs that already have a product. Run this over a *grown* raw set and
# the old products keep the old card's factors while the new ones get the new
# card's -- a set calibrated against two references, with nothing in the arrays
# to show it, because stage 2 multiplies the factors in. That happened: the
# 176-epoch set ended up holding three cards (118 + 50 + 8). So recalibrate
# everything by default, and let a caller who knows the card is unchanged say
# FORCE=0 to keep the skip. make_sca_digests.py refuses a mixed-card set either
# way, so the mistake is now loud rather than silent.
if [[ "${FORCE:-1}" == "1" ]]; then
    FORCE_FLAG=(--force)
    echo
    echo "    (recalibrating every epoch against the card just written;"
    echo "     FORCE=0 to skip epochs that already have a product)"
else
    FORCE_FLAG=()
fi

echo
echo "=== 2/2 calibrating $RAW_DIR -> $CAL_DIR with $JOBS job(s) ==="
if [[ ${#EXTRA[@]} -gt 0 ]]; then
    echo "    (forwarding: ${EXTRA[*]})"
fi
"$PYTHON" calibrate_rcs_products.py \
    --card "$CARD" --in "$RAW_DIR" --out-dir "$CAL_DIR" --jobs "$JOBS" \
    "${FORCE_FLAG[@]}" ${EXTRA[@]+"${EXTRA[@]}"}

echo
echo "card:        $CARD"
echo "calibrated:  $CAL_DIR ($(find "$CAL_DIR" -maxdepth 1 -name '*_cal.h5' | wc -l) product(s))"
echo
echo "Next: make_sca_digests.py --data-root $CAL_DIR --out-dir digests/<date>"
echo "      (the bridge is applied there, not here)"
