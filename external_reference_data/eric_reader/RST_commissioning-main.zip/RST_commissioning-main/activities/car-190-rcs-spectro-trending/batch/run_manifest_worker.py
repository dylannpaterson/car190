"""One rank's slice of batch/run_manifest.csv: run process_rcs_trending.py
per row, skipping rows already *complete* and recording a per-row status marker.

Complete, not merely present. A row is skipped only when an existing product
covers --min-scas detectors (see :func:`_already_done`); a short one is moved
into ``<out_dir>/degraded/`` and the pass is rebuilt. That is the difference
between this and the version that globbed for a filename, under which a 2-SCA
product written from a listing truncated by MAST load blocked its own retry
forever -- the state 79 of 91 products in ``rcs_trend_batch`` are in.

Invoked once per SLURM task by batch/worker_entrypoint.sh (rank/world-size
come from $SLURM_PROCID/$SLURM_NTASKS), or directly for a local smoke test
with --rank 0 --world-size 1. See README.md's "Batch processing with SLURM"
section for the end-to-end workflow.
"""
import argparse
import glob
import os
import shutil
import subprocess
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_manifest  # noqa: E402
import rcs_mast  # noqa: E402
import rcs_products  # noqa: E402
import rcs_trend_config as cfg  # noqa: E402
from process_rcs_trending import PROGRAM_LABELS  # noqa: E402

ACTIVITY_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BATCH_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_DIR = os.path.join(BATCH_DIR, "logs")
STATUS_DIR = os.path.join(BATCH_DIR, "status")

# process_rcs_trending.py exits 3 when a pass's query plan does not cover
# --min-scas. That is neither success nor a crash: the pass is real, nothing is
# wrong with the code, and it should be retried once MAST has finished indexing
# it. Recorded as its own outcome so `ls batch/status/*.degraded` is the retry
# list -- previously a partial success was indistinguishable from a full one.
DEGRADED_RETURNCODE = 3

# "done" must keep meaning "a product was written", so a --plan-only row that
# succeeded is recorded "planned" instead. Otherwise the obvious progress check,
# `ls batch/status/*.done | wc -l`, counts cached plans as finished products and
# over-reports the run -- and rung 1 of the ladder deliberately plans every row,
# so it would over-report by the entire manifest.
OUTCOMES = ("done", "planned", "failed", "skipped", "degraded")


def _stem(row):
    car_label = PROGRAM_LABELS.get(int(row["program"]), "CAR190")

    return (f"{car_label}_{int(row['program']):05d}_"
            f"{int(row['execution_plan']):02d}_{int(row['pass']):03d}_"
            f"{row['decon_cycle']}")


def _products_for(row, out_dir):
    """Existing stage-1 products for this (program, execution_plan, pass).

    ``_cal.h5`` is excluded: a calibrated product is written by
    ``calibrate_rcs_products.py`` from a raw one, so finding it says nothing
    about whether *this* worker's output exists, and relocating it as degraded
    would be relocating the wrong file.
    """
    car_label = PROGRAM_LABELS.get(int(row["program"]), "CAR190")
    pattern = os.path.join(
        out_dir, f"{car_label}_{int(row['program']):05d}_"
        f"{int(row['execution_plan']):02d}_{int(row['pass']):03d}_*.h5")

    return sorted(path for path in glob.glob(pattern)
                  if not path.endswith("_cal.h5"))


def _already_done(row, out_dir, min_scas):
    """``(done, detail)`` -- and completeness, not existence, decides.

    The failure this exists for was observed on 79 of 91 products in
    ``rcs_trend_batch``: a MAST listing degraded by query overload returns a few
    of the 18 SCAs, the pipeline streams exactly what it was given, and a glob
    for the filename then reports the pass finished forever.  So the question
    asked here is how many detectors are in the file, via
    :func:`rcs_products.coverage_from_h5`, which answers for legacy mosaics too
    -- otherwise every pre-``coverage/`` product would read as degraded and the
    whole archive would be re-pulled.

    A short or unreadable product is **moved** into ``out_dir/degraded/``, never
    deleted: it is the evidence of what the listing returned, and the pass is
    then free to be rebuilt in place.
    """
    complete, short = [], []
    for path in _products_for(row, out_dir):
        try:
            covered = int(np.sum(rcs_products.coverage_from_h5(path)))
        except (OSError, KeyError, ValueError) as error:
            # Unreadable counts as short, not as an error to raise: a truncated
            # write from a killed rank is the same situation as a truncated
            # listing, and both want the file out of the way and a retry.
            short.append((path, f"unreadable: {type(error).__name__}: {error}"))
            continue
        if covered >= min_scas:
            complete.append((path, covered))
        else:
            short.append((path, f"covers {covered}/{cfg.N_SCAS} SCAs"))

    if complete:
        # A complete product wins even if a short one sits beside it: the pass
        # has been built, and moving the short file is triage, not a retry.
        for path, reason in short:
            _move_degraded(path, out_dir, reason)
        return True, (f"{os.path.basename(complete[0][0])} covers "
                      f"{complete[0][1]}/{cfg.N_SCAS} SCAs")

    detail = "; ".join(f"{os.path.basename(path)} {reason}"
                       for path, reason in short)
    for path, reason in short:
        _move_degraded(path, out_dir, reason)
    return False, detail


def _move_degraded(path, out_dir, reason):
    """Relocate a short product into ``out_dir/degraded/``, keeping both files.

    A name collision is resolved by suffixing rather than overwriting, so a pass
    that degrades twice leaves two artifacts to compare -- which is how you tell
    a transient listing failure from a pass MAST has genuinely not indexed.
    """
    target_dir = os.path.join(out_dir, cfg.DEGRADED_SUBDIR)
    os.makedirs(target_dir, exist_ok=True)
    destination = os.path.join(target_dir, os.path.basename(path))
    stem, extension = os.path.splitext(destination)
    index = 1
    while os.path.exists(destination):
        destination = f"{stem}.{index}{extension}"
        index += 1
    shutil.move(path, destination)
    print(f"  retry: existing product {reason}; moved to "
          f"{cfg.DEGRADED_SUBDIR}/{os.path.basename(destination)}")


def side_args(row):
    """``["--mce-side", X]`` for a row that records a side, else ``[]``.

    Blank, or no column at all in a manifest from before it existed, forwards
    nothing, so stage 1 writes ``mce_side_source = "assumed:flight-side-A"``
    exactly as every pre-swap product was written. Nothing in the archive or
    the telemetry names the side, so this column is the only way a B-side pass
    gets labelled B -- see make_manifest's module docstring.
    """
    side = make_manifest.normalize_side(row.get("mce_side"))
    return ["--mce-side", side] if side else []


def _run_one(row, staging_root, out_dir, force, query_delay_seconds, opts=None):
    opts = opts or {}
    stem = _stem(row)
    min_scas = opts.get("min_scas")
    min_scas = cfg.MIN_SCAS if min_scas is None else int(min_scas)
    retry_short = False

    # --plan-only writes no .h5 at all, so the output glob is meaningless as a
    # done-check there: a plan sweep over a directory that already holds
    # products would skip every row and cache nothing.
    if not opts.get("plan_only") and not force:
        done, detail = _already_done(row, out_dir, min_scas)
        if done:
            _write_status(stem, "skipped", detail)
            print(f"skipped (already done) {stem}: {detail}")
            return "skipped"
        # Only when a short product was actually moved out of the way. The
        # staging directory it left behind is what --force is for; passing it
        # unconditionally would also override --force's guard on a clean rerun.
        retry_short = bool(detail)

    cmd = [sys.executable, "process_rcs_trending.py",
           "--program", str(int(row["program"])),
           "--execution-plan", str(int(row["execution_plan"])),
           "--pass", str(int(row["pass"])),
           "--decon-cycle", str(row["decon_cycle"]),
           "--staging-root", staging_root, "--out-dir", out_dir]
    if bool(row["blank_dark"]):
        cmd.append("--blank-dark")
    cmd += side_args(row)
    if force or retry_short:
        cmd.append("--force")
    if query_delay_seconds is not None:
        cmd += ["--query-delay-seconds", str(query_delay_seconds)]
    if opts.get("plan_only"):
        cmd.append("--plan-only")
    if opts.get("use_plan"):
        cmd.append("--use-plan")
    # Always forwarded, never left to the child's own default: the coverage
    # check above and the plan precondition inside the child must screen on the
    # same number, or a product this worker would reject gets written anyway.
    cmd += ["--min-scas", str(min_scas)]
    if opts.get("query_leases") is not None:
        cmd += ["--query-leases", str(opts["query_leases"])]
    if opts.get("bin_factor") is not None:
        cmd += ["--bin", str(opts["bin_factor"])]
    # Forwarded explicitly even though the child already defaults it from
    # AUX_L2_DIR in the inherited environment. The log below records the
    # command line, and a product built from a local reprocessing instead of
    # MAST must be legible from that line alone -- an environment variable
    # that silently redirected the data source would leave no trace here.
    if opts.get("aux_l2_dir"):
        cmd += ["--aux-l2-dir", str(opts["aux_l2_dir"])]

    result = subprocess.run(cmd, cwd=ACTIVITY_DIR, capture_output=True, text=True)
    with open(os.path.join(LOG_DIR, f"{stem}.log"), "w") as handle:
        handle.write(f"$ {' '.join(cmd)}\n\n")
        handle.write(result.stdout)
        handle.write(result.stderr)

    if result.returncode == 0:
        outcome = "planned" if opts.get("plan_only") else "done"
        _write_status(stem, outcome, "")
        print(f"{outcome} {stem}")
        return outcome

    if result.returncode == DEGRADED_RETURNCODE:
        # The DEGRADED: line is on stdout, not stderr -- it is a clean refusal
        # by the coverage precondition, not a traceback.
        detail = "\n".join(line for line in result.stdout.splitlines()
                           if line.startswith("DEGRADED:"))
        _write_status(stem, "degraded", detail or "incomplete query plan")
        print(f"degraded {stem}: {detail or 'incomplete query plan'}")
        return "degraded"

    tail = "\n".join(result.stderr.strip().splitlines()[-20:])
    _write_status(stem, "failed", f"returncode {result.returncode}\n{tail}")
    print(f"FAILED {stem} (see logs/{stem}.log)")
    return "failed"


def _write_status(stem, outcome, detail):
    # One file per row, never a shared/appended file -- many ranks across
    # many nodes write into this same directory concurrently.
    for suffix in OUTCOMES:
        path = os.path.join(STATUS_DIR, f"{stem}.{suffix}")
        if os.path.exists(path) and suffix != outcome:
            os.remove(path)
    with open(os.path.join(STATUS_DIR, f"{stem}.{outcome}"), "w") as handle:
        handle.write(detail)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--n-tasks", type=int, required=True, dest="n_tasks",
                         help="process the first N rows of the manifest; -1 "
                         "for all rows")
    parser.add_argument("--rank", type=int, required=True)
    parser.add_argument("--world-size", type=int, required=True, dest="world_size")
    parser.add_argument("--staging-root", required=True, dest="staging_root")
    parser.add_argument("--out-dir", required=True, dest="out_dir")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--query-delay-seconds", type=float, default=None,
                         dest="query_delay_seconds",
                         help="forwarded to process_rcs_trending.py; omit to "
                         "use its own default")
    parser.add_argument("--plan-only", action="store_true", dest="plan_only",
                         help="cache a query plan per row and stream nothing; "
                         "the cheap first rung of the ladder")
    parser.add_argument("--use-plan", action="store_true", dest="use_plan",
                         help="stream from the cached plans, issuing no "
                         "listing calls at all")
    parser.add_argument("--min-scas", type=int, default=cfg.MIN_SCAS,
                         dest="min_scas",
                         help="SCAs required for a pass to count as complete. "
                         "Used twice: a plan covering fewer lit SCAs exits "
                         "degraded and streams nothing, and an *existing* "
                         "product covering fewer is moved to degraded/ and "
                         f"rebuilt rather than skipped (default: %(default)s)")
    parser.add_argument("--bin", type=int, default=None, dest="bin_factor",
                         help="forwarded as --bin; superpixel bin factor for "
                         "the per-SCA product. Omit to use the pipeline "
                         f"default of {cfg.DEFAULT_BIN}")
    parser.add_argument("--query-leases", type=int, default=None,
                         dest="query_leases",
                         help="forwarded; concurrent listing calls allowed "
                         "across all ranks sharing --staging-root")
    parser.add_argument("--aux-l2-dir", default=os.environ.get("AUX_L2_DIR"),
                         dest="aux_l2_dir",
                         help="forwarded as --aux-l2-dir; a local L2 "
                         "reprocessing that supersedes MAST for any pass it "
                         "covers completely. A pass it covers only partly is "
                         "refused outright rather than mixed. Defaults to "
                         "$AUX_L2_DIR")
    parser.add_argument("--stagger", action="store_true",
                         help="sleep a rank-dependent interval before the "
                         "first row, scaled by --world-size")
    args = parser.parse_args()

    if args.plan_only and args.use_plan:
        raise SystemExit("--plan-only and --use-plan are opposites; pass one.")

    os.makedirs(LOG_DIR, exist_ok=True)
    os.makedirs(STATUS_DIR, exist_ok=True)

    # str, so a column holding only "A"/"B"/blank is never read as something
    # pandas guesses. Every row's side is checked here, before anything
    # streams: a bad cell raising inside _run_one would kill the rank partway
    # through its slice instead.
    table = pd.read_csv(args.manifest, dtype={"mce_side": str})
    selected = table if args.n_tasks == -1 else table.iloc[:args.n_tasks]
    try:
        for _, row in selected.iterrows():
            side_args(row)
    except ValueError as error:
        raise SystemExit(f"{args.manifest}: {error}") from error
    mine = selected.iloc[args.rank::args.world_size]

    print(f"rank {args.rank}/{args.world_size}: {len(mine)} of "
          f"{len(selected)} selected row(s)")

    # Once per rank, not once per row: the thing being spread out is the burst
    # of ranks all starting their first listing call in the same second.
    # --use-plan issues no listing calls, so it needs no spreading.
    if args.stagger and not args.use_plan:
        rcs_mast.startup_stagger(n_tasks=args.world_size, rank=args.rank)

    opts = {"plan_only": args.plan_only, "use_plan": args.use_plan,
            "min_scas": args.min_scas, "query_leases": args.query_leases,
            "bin_factor": args.bin_factor, "aux_l2_dir": args.aux_l2_dir}

    tally = {outcome: 0 for outcome in OUTCOMES}
    for _, row in mine.iterrows():
        tally[_run_one(row, args.staging_root, args.out_dir, args.force,
                       args.query_delay_seconds, opts=opts)] += 1

    print(f"rank {args.rank}/{args.world_size} finished: "
          f"{tally['done']} done, {tally['planned']} planned, "
          f"{tally['skipped']} skipped, {tally['degraded']} degraded, "
          f"{tally['failed']} failed")

    # Degraded rows do not fail the rank: they are the expected outcome for a
    # pass MAST has not finished indexing, and a nonzero exit would make SLURM
    # treat a normal plan sweep as a broken job. They are in status/*.degraded.
    if tally["failed"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
