"""Build/extend the SLURM batch run manifest (run_manifest.csv).

Each row is one process_rcs_trending.py invocation: a
(program, execution_plan, pass, decon_cycle) task plus whether to pass
--blank-dark. See batch/run_manifest_worker.py for how rows are consumed and
README.md's "Batch processing with SLURM" section for the end-to-end workflow.

Three modes that add rows, in descending order of how much you should trust them:

* ``--from-survey`` asks the archive which (plan, pass) combinations actually
  exist and writes exactly those. This is the one to use.
* ``--append`` adds a known range by hand.
* ``--init`` writes ``INITIAL_RANGES``, a hand-maintained guess. Kept to
  reproduce an older manifest; see the warning on that constant.

and one that changes them: ``--relabel`` sets ``decon_cycle`` and/or
``mce_side`` on rows that already exist. It is the only way a row's labels
change, because ``--from-survey`` deliberately never relabels.

``decon_cycle`` and ``mce_side`` are both **operational knowledge, not archive
metadata**. Nothing in the L2 products or the telemetry names either: the cycle
is when the instrument was warmed, and the side is which MCE was driving it.
``mce_side`` may be blank, which stage 1 records as
``mce_side_source = "assumed:flight-side-A"`` -- the state of every row written
before 2026-10-06, when flight swapped to side B between CAR-190 plan-3 passes
57 and 71. A blank on a B-side pass is a silent mislabel: the side picks the
photodiode reference and the per-LED side correction, both 1.5-6 % effects.
"""
import argparse
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import rcs_mast  # noqa: E402
from rcs_activities import PROGRAM_LABELS  # noqa: E402

MANIFEST_COLUMNS = ["program", "execution_plan", "pass", "decon_cycle",
                    "blank_dark", "mce_side"]
MCE_SIDES = ("A", "B")
DEFAULT_MANIFEST = os.path.join(os.path.dirname(__file__), "run_manifest.csv")

# The hand-maintained task list from 2026-09-28. Surveyed against the archive
# on 2026-10-03 it is very nearly right -- 167 of its 168 rows exist -- and it
# drifts only by lagging: CAR-190 has since added plan-2 passes 43-46 and
# plan-3 passes 47-52, and its pass 12 does not exist. Current truth is 177
# passes: CAR-190 plan 2 at 1-46 (no 12) and plan 3 at 47-52, CAR-216 plan 2 at
# 1-90 and plan 3 at 1-36.
#
# A row for a nonexistent pass is not free: it fails with "no products matched"
# and deposits a status/*.failed marker indistinguishable at a glance from the
# listing-overload failures the conservative-querying work exists to eliminate.
# Lagging the other way is worse -- a pass absent from the manifest is simply
# never staged, and nothing reports it. Hence --from-survey, which cannot drift
# in either direction.
#
# A caution for anyone tempted to re-derive these ranges by hand: an unpaginated
# survey silently truncates at 5000 rows per query, which reads as a *shorter
# program* rather than as an error. It reported CAR-190 ending at pass 48 and
# CAR-216 having only 28 plan-2 passes and no plan 3 at all, which would have
# condemned 98 perfectly good rows. rcs_mast._survey_rows now pages explicitly;
# the paged CAR-216 counts close to the file (15 and 10 exposures x 18 detectors
# x 126 passes = 34020 L1, 22680 L2), which is what establishes that offset
# paging neither duplicates nor drops rows.
#
# blank_dark is True for every row regardless of mode: the RCS dark exposure is
# never processed to L2, so the L1 fallback is always the one that supplies its
# identity and timing.
INITIAL_RANGES = [
    # (program, execution_plan, pass_start, pass_end, decon_cycle)
    (1039, 2, 1, 37, "decon1"),
    (1039, 2, 38, 42, "decon2"),
    (1063, 2, 1, 90, "decon2"),
    (1063, 3, 1, 36, "decon2"),
]


def _parse_pass_ranges(spec):
    """``"1-37,40,42-45"`` -> ``[1, 2, ..., 37, 40, 42, 43, 44, 45]``."""
    passes = []
    for chunk in spec.split(","):
        chunk = chunk.strip()
        if "-" in chunk:
            start, end = chunk.split("-")
            passes.extend(range(int(start), int(end) + 1))
        else:
            passes.append(int(chunk))
    return passes


def _rows_from_ranges(ranges):
    rows = []
    for program, execution_plan, start, end, decon_cycle in ranges:
        for pass_ in range(start, end + 1):
            rows.append({"program": program, "execution_plan": execution_plan,
                         "pass": pass_, "decon_cycle": decon_cycle,
                         "blank_dark": True, "mce_side": ""})
    return rows


def normalize_side(value):
    """``"A"``, ``"B"`` or ``""`` from a manifest cell; anything else raises.

    pandas reads an empty CSV cell as NaN, so blank has to be recognised as
    "not recorded" rather than stringified to ``"nan"`` and passed on as a side.
    """
    if value is None or (isinstance(value, float) and value != value):
        return ""
    side = str(value).strip().upper()
    if side in ("", "NAN"):
        return ""
    if side not in MCE_SIDES:
        raise ValueError(f"mce_side must be A, B or blank, not {value!r}")
    return side


def _refuse_empty_survey(frames, program, n_existing):
    """Raise if a level came back empty for a program the manifest already has.

    ``rcs_mast.survey_rows`` turns a failed query into an empty frame with a
    printed warning, so that a one-pass survey of something not yet archived
    reads as "nothing here". Over a whole program that kindness is a hazard:
    an empty L2 frame omits every pass, every existing row of the program then
    reads as stale, and a non-dry run *drops* them -- 51 rows of CAR-190 from
    one HTTP error. A program that has rows cannot honestly survey as empty.
    """
    empty = [level for level, frame in frames.items() if not len(frame)]
    if n_existing and empty:
        raise SystemExit(
            f"program {program}: the L{'/L'.join(str(lvl) for lvl in empty)} "
            f"survey returned nothing, but the manifest already holds "
            f"{n_existing} row(s) for it. That is a failed query (see the "
            f"WARNING above), not an empty program, and writing it would drop "
            f"every one of those rows. Nothing written; re-run when MAST "
            f"answers.")


def _survey_rows_for(missions, program, min_level_2=1, n_existing=0):
    """The ``(execution_plan, pass)`` combinations the archive actually holds.

    Two survey queries per program -- L1 and L2 -- not one, because a pass
    becomes visible at L1 first and the manifest should contain it from that
    moment: planning it is cheap, and a pass whose L2 has not landed yet is
    exactly what the degraded outcome is for. ``min_level_2`` requires at least
    that many L2 files before a combination is emitted, so the default of 1
    means "L2 has started", not "L2 is complete". Completeness is the query
    plan's job to assess per pass (rcs_mast.check_plan_coverage); duplicating
    that judgement here would mean one more full survey of every detector.

    Returns a frame of (execution_plan, pass_number, n_l1, n_l2), sorted. The
    column is ``pass_number``, not ``pass``, so callers can use attribute
    access; only the manifest itself uses the keyword-colliding ``pass``.
    """
    search = {"program": program}
    frames = {}
    for level in (1, 2):
        frame = rcs_mast.survey_rows(missions, search, level)
        frames[level] = frame
        print(f"  program {program}: {len(frame)} L{level} file(s)")
    _refuse_empty_survey(frames, program, n_existing)

    # groupby rather than itertuples: 'pass' is a Python keyword, so
    # itertuples renames that column positionally and the attribute name
    # depends on column order.
    counts = {}
    for level, frame in frames.items():
        if not len(frame):
            continue
        valid = frame[frame["pass"].notna() & frame["execution_plan"].notna()]
        grouped = valid.groupby(["execution_plan", "pass"]).size()
        for (execution_plan, pass_number), n_files in grouped.items():
            key = (int(execution_plan), int(pass_number))
            counts.setdefault(key, {1: 0, 2: 0})[level] = int(n_files)

    rows = [{"execution_plan": execution_plan, "pass_number": pass_number,
             "n_l1": seen[1], "n_l2": seen[2]}
            for (execution_plan, pass_number), seen in sorted(counts.items())
            if seen[2] >= min_level_2]
    skipped = [key for key, seen in sorted(counts.items())
               if seen[2] < min_level_2]
    if skipped:
        print(f"  program {program}: {len(skipped)} (plan, pass) with L1 but "
              f"fewer than {min_level_2} L2 file(s), omitted: {skipped}")

    return pd.DataFrame(rows)


def _decon_cycle_for(program, execution_plan, pass_number, known, default):
    """The decon cycle for a surveyed pass, preferring what is already known.

    The decon cycle is not in the archive metadata -- it is operational
    knowledge about when the instrument was warmed up, which only the operator
    has. So a surveyed pass that is already in the manifest keeps its recorded
    cycle, and only genuinely new passes take ``--default-decon-cycle``. That
    makes --from-survey safe to re-run as the trend grows: it can add passes
    without ever silently relabelling one.
    """
    recorded = known.get((program, execution_plan, pass_number))

    return recorded if recorded else default


def _load_existing(manifest_path):
    """The manifest, with ``mce_side`` normalised and present.

    A manifest written before the column existed reads with every side blank,
    which is exactly what those rows were run as.
    """
    if not os.path.exists(manifest_path):
        return pd.DataFrame(columns=MANIFEST_COLUMNS)
    table = pd.read_csv(manifest_path, dtype={"mce_side": str})
    if "mce_side" not in table.columns:
        table["mce_side"] = ""
    table["mce_side"] = [normalize_side(v) for v in table["mce_side"]]
    return table


def _write(manifest_path, table):
    table = table.sort_values(["program", "execution_plan", "pass"])
    table = table[MANIFEST_COLUMNS]
    table.to_csv(manifest_path, index=False)
    print(f"wrote {len(table)} row(s) to {manifest_path}")


def _key(values):
    return (int(values["program"]), int(values["execution_plan"]),
            int(values["pass"]))


def _merge_unsurveyed(table, existing, programs):
    """``(table, stale)``: surveyed rows plus every row of an unsurveyed program.

    Stale means "surveyed, and the archive does not have it" -- so only keys of
    a program that was actually surveyed can be stale. A row of a program left
    out by ``--programs`` was not asked about, and dropping it would let
    ``--programs 1039`` (the quick check while only CAR-190 is running) delete
    all 126 CAR-216 rows on a non-dry run.
    """
    surveyed = {_key(r) for _, r in table.iterrows()}
    keep = existing[~existing["program"].astype(int).isin(
        [int(p) for p in programs])]
    stale = sorted(key for key in (_key(r) for _, r in existing.iterrows())
                   if key[0] in programs and key not in surveyed)
    return pd.concat([table, keep[MANIFEST_COLUMNS]], ignore_index=True), stale


def _from_survey(args):
    """Write the manifest from what the archive actually holds.

    Reports both directions of the diff against the existing manifest, because
    both matter and they fail differently: a *missing* pass is work that will
    silently never be staged, while a *stale* row is a task that fails with
    "no products matched" and leaves a status/*.failed marker that looks like
    the listing-overload failures this pipeline works to avoid.

    Stale rows are reported and dropped, never kept "just in case". A row
    cannot be rescued by retrying it if the pass does not exist.
    """
    existing = _load_existing(args.manifest)
    known, known_side = {}, {}
    for row in existing.itertuples(index=False):
        values = dict(zip(existing.columns, row))
        known[_key(values)] = values["decon_cycle"]
        known_side[_key(values)] = values["mce_side"]

    missions = rcs_mast.connect()
    rows, new_keys = [], []
    for program in args.programs:
        label = PROGRAM_LABELS.get(program, str(program))
        print(f"\nsurveying {label} (program {program})...")
        n_existing = sum(1 for key in known if key[0] == program)
        surveyed = _survey_rows_for(missions, program,
                                    min_level_2=args.min_level_2,
                                    n_existing=n_existing)
        if not len(surveyed):
            print(f"  program {program}: no passes found")
            continue
        for entry in surveyed.itertuples(index=False):
            key = (program, int(entry.execution_plan), int(entry.pass_number))
            if key not in known:
                new_keys.append(key)
            # Not _decon_cycle_for's "recorded if truthy": a blank side is a
            # recorded state (run as assumed-A), and the default must not
            # overwrite it any more than it overwrites a recorded cycle.
            side = (known_side[key] if key in known_side
                    else args.default_mce_side or "")
            rows.append({"program": program,
                         "execution_plan": int(entry.execution_plan),
                         "pass": int(entry.pass_number),
                         "decon_cycle": _decon_cycle_for(
                             *key, known, args.default_decon_cycle),
                         "blank_dark": True,
                         "mce_side": side})
        plans = sorted({int(e.execution_plan) for e in
                        surveyed.itertuples(index=False)})
        for execution_plan in plans:
            in_plan = sorted(int(e.pass_number)
                             for e in surveyed.itertuples(index=False)
                             if int(e.execution_plan) == execution_plan)
            gaps = [p for p in range(min(in_plan), max(in_plan) + 1)
                    if p not in in_plan]
            print(f"  {label} plan {execution_plan}: {len(in_plan)} pass(es), "
                  f"{min(in_plan)}-{max(in_plan)}"
                  + (f", absent: {gaps}" if gaps else ""))

    if new_keys and not args.default_decon_cycle:
        raise SystemExit(
            f"the survey found {len(new_keys)} pass(es) not in the existing "
            f"manifest, so --default-decon-cycle is required: {new_keys[:10]}"
            + (" ..." if len(new_keys) > 10 else "")
            + "\nThe decon cycle is operational knowledge, not archive "
              "metadata, so it cannot be surveyed. Existing rows keep the "
              "cycle they already have; only these new ones need one.")
    if new_keys and not args.default_mce_side:
        raise SystemExit(
            f"the survey found {len(new_keys)} new pass(es), so "
            f"--default-mce-side is required too (A or B). Flight swapped to "
            f"side B on 2026-10-06, so 'blank = assumed A' is no longer a safe "
            f"default for a new pass. If the new passes straddle a swap, give "
            f"the majority side here and fix the rest with --relabel before "
            f"staging.")

    table, stale = _merge_unsurveyed(pd.DataFrame(rows), existing,
                                     args.programs)

    print("\n----- manifest diff -----")
    print(f"  existing rows   : {len(existing)}")
    print(f"  rows after      : {len(table)}"
          + ("" if set(args.programs) >= set(PROGRAM_LABELS) else
             " (unsurveyed programs carried over unchanged)"))
    print(f"  new (added)     : {len(new_keys)}"
          + (f" as {args.default_decon_cycle}, side {args.default_mce_side}"
             if new_keys else ""))
    for key in new_keys[:20]:
        print(f"      program {key[0]} plan {key[1]} pass {key[2]} "
              f"-- CONFIRM cycle is {args.default_decon_cycle}, "
              f"side is {args.default_mce_side}")
    if len(new_keys) > 20:
        print(f"      ... and {len(new_keys) - 20} more")
    if new_keys:
        print("    The decon cycle and side above are defaults, not "
              "measurements. A wrong label propagates into every digest, so "
              "check these against the decon schedule and the side witnesses "
              "(batch/side_witness.py) before streaming.")
    print(f"  stale (dropped) : {len(stale)}")
    for key in stale[:20]:
        print(f"      program {key[0]} plan {key[1]} pass {key[2]} "
              f"-- not in the archive")
    if len(stale) > 20:
        print(f"      ... and {len(stale) - 20} more")

    if args.dry_run:
        print("\n  [dry run] nothing written")
        return

    _write(args.manifest, table)


def relabel(table, program, execution_plan, passes, decon_cycle=None,
            mce_side=None):
    """``(table, changes)`` with the named rows' labels set.

    Only rows that exist: relabelling a pass the manifest does not hold is a
    typo in ``--passes`` or a missing survey, and silently adding it would make
    this a second, unsurveyed ``--append``. ``changes`` lists every row whose
    labels actually moved, before and after, so the edit is reviewable.
    """
    if decon_cycle is None and mce_side is None:
        raise ValueError("relabel needs --decon-cycle and/or --mce-side")
    side = None if mce_side is None else normalize_side(mce_side)
    table = table.copy()
    keys = [_key(r) for _, r in table.iterrows()]
    wanted = {(int(program), int(execution_plan), int(p)) for p in passes}
    missing = sorted(wanted - set(keys))
    if missing:
        raise ValueError(
            f"{len(missing)} pass(es) not in the manifest, so not relabelled: "
            f"{missing[:10]}. Add them with --from-survey first.")
    changes = []
    for index, key in zip(table.index, keys):
        if key not in wanted:
            continue
        before = (table.at[index, "decon_cycle"], table.at[index, "mce_side"])
        if decon_cycle is not None:
            table.at[index, "decon_cycle"] = decon_cycle
        if side is not None:
            table.at[index, "mce_side"] = side
        after = (table.at[index, "decon_cycle"], table.at[index, "mce_side"])
        if after != before:
            changes.append((key, before, after))
    return table, changes


def _relabel(args):
    missing = [name for name, value in (
        ("--program", args.program), ("--execution-plan", args.execution_plan),
        ("--passes", args.passes)) if value is None]
    if missing:
        raise SystemExit(f"--relabel requires {', '.join(missing)}")
    try:
        table, changes = relabel(
            _load_existing(args.manifest), args.program, args.execution_plan,
            _parse_pass_ranges(args.passes), decon_cycle=args.decon_cycle,
            mce_side=args.mce_side)
    except ValueError as error:
        raise SystemExit(str(error)) from error
    for key, before, after in changes:
        print(f"  program {key[0]} plan {key[1]} pass {key[2]}: "
              f"cycle {before[0]} -> {after[0]}, "
              f"side {before[1] or '(blank)'} -> {after[1] or '(blank)'}")
    print(f"  {len(changes)} row(s) changed")
    if changes:
        print("  A relabelled pass that already has a product keeps the OLD "
              "labels in its h5 until it is re-staged: the worker skips a "
              "complete product. Re-run those rows with --force.")
    if args.dry_run:
        print("\n  [dry run] nothing written")
        return
    _write(args.manifest, table)


def self_test():
    """Credential-free checks of the label logic. No network, no files kept."""
    import tempfile

    print("== make_manifest: labels ==")
    assert normalize_side(float("nan")) == ""
    assert normalize_side(" b ") == "B"
    try:
        normalize_side("C")
    except ValueError:
        pass
    else:
        raise AssertionError("a side other than A/B/blank was accepted")
    print("  ok   blank, NaN and lower case normalise; an unknown side raises")

    with tempfile.TemporaryDirectory() as tmp:
        # A pre-column manifest: every row must read back blank, which is what
        # those rows were actually staged as.
        old = os.path.join(tmp, "old.csv")
        pd.DataFrame([{"program": 1039, "execution_plan": 3, "pass": p,
                       "decon_cycle": "decon2", "blank_dark": True}
                      for p in (56, 57, 71)]).to_csv(old, index=False)
        table = _load_existing(old)
        assert list(table["mce_side"]) == ["", "", ""], list(table["mce_side"])
        print("  ok   a manifest from before the column reads as blank sides")

        relabelled, changes = relabel(table, 1039, 3, [71], mce_side="b")
        assert list(relabelled["mce_side"]) == ["", "", "B"]
        assert changes == [((1039, 3, 71), ("decon2", ""), ("decon2", "B"))]
        assert list(table["mce_side"]) == ["", "", ""], "relabel mutated input"
        print("  ok   relabel sets only the named pass and reports the change")

        _, again = relabel(relabelled, 1039, 3, [71], mce_side="B")
        assert again == [], again
        print("  ok   a relabel that changes nothing reports nothing")

        for bad in ({"passes": [72]}, {"passes": [71], "neither": True}):
            try:
                if "neither" in bad:
                    relabel(table, 1039, 3, bad["passes"])
                else:
                    relabel(table, 1039, 3, bad["passes"], mce_side="B")
            except ValueError:
                continue
            raise AssertionError(f"relabel accepted {bad}")
        print("  ok   relabel refuses an absent pass, and a call with no label")

        # The round trip through CSV: blank must stay blank, not become "nan".
        path = os.path.join(tmp, "new.csv")
        _write(path, relabelled)
        back = _load_existing(path)
        assert list(back["mce_side"]) == ["", "", "B"], list(back["mce_side"])
        print("  ok   a written manifest reads back with blank and B intact")

    existing = pd.DataFrame(
        [{"program": 1039, "execution_plan": 3, "pass": p, "decon_cycle": "decon2",
          "blank_dark": True, "mce_side": ""} for p in (56, 57)]
        + [{"program": 1063, "execution_plan": 2, "pass": 1,
            "decon_cycle": "decon2", "blank_dark": True, "mce_side": ""}])
    surveyed = pd.DataFrame(
        [{"program": 1039, "execution_plan": 3, "pass": p, "decon_cycle": "decon2",
          "blank_dark": True, "mce_side": side}
         for p, side in ((57, ""), (71, "B"))])
    merged, stale = _merge_unsurveyed(surveyed, existing, [1039])
    assert stale == [(1039, 3, 56)], stale
    assert sorted(_key(r) for _, r in merged.iterrows()) == [
        (1039, 3, 57), (1039, 3, 71), (1063, 2, 1)], merged
    print("  ok   --programs 1039 keeps every CAR-216 row; only a surveyed "
          "program's rows can be stale")

    empty, full = pd.DataFrame(), pd.DataFrame({"pass": [1]})
    try:
        _refuse_empty_survey({1: full, 2: empty}, 1039, n_existing=51)
    except SystemExit:
        pass
    else:
        raise AssertionError("an empty L2 survey of a known program passed")
    _refuse_empty_survey({1: empty, 2: empty}, 9999, n_existing=0)
    _refuse_empty_survey({1: full, 2: full}, 1039, n_existing=51)
    print("  ok   a failed survey of a program with rows refuses; a genuinely "
          "new or a complete one does not")
    print("make_manifest self-test: all passed")
    return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", default=DEFAULT_MANIFEST,
                         help=f"default: {DEFAULT_MANIFEST}")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--init", action="store_true",
                       help="write the full known task list, replacing any "
                       "existing manifest at --manifest")
    mode.add_argument("--append", action="store_true",
                       help="add rows for a new epoch to the existing manifest")
    mode.add_argument("--from-survey", action="store_true", dest="from_survey",
                       help="survey the archive and write exactly the (plan, "
                       "pass) combinations that exist; the recommended mode")
    mode.add_argument("--relabel", action="store_true",
                       help="set --decon-cycle and/or --mce-side on existing "
                       "rows named by --program/--execution-plan/--passes")
    mode.add_argument("--self-test", action="store_true", dest="self_test",
                       help="credential-free checks of the label logic")
    parser.add_argument("--programs", type=int, nargs="+",
                         default=sorted(PROGRAM_LABELS),
                         help="--from-survey only; default: "
                         f"{' '.join(str(p) for p in sorted(PROGRAM_LABELS))}")
    parser.add_argument("--default-decon-cycle", dest="default_decon_cycle",
                         help="--from-survey only: the cycle for surveyed "
                         "passes not already in the manifest. Required only if "
                         "the survey finds any such pass -- existing rows keep "
                         "the cycle they already have")
    parser.add_argument("--default-mce-side", dest="default_mce_side",
                         type=lambda v: normalize_side(v) or None,
                         help="--from-survey only: A or B for surveyed passes "
                         "not already in the manifest, required whenever "
                         "there are any. Existing rows keep their side, "
                         "including a blank one")
    parser.add_argument("--min-level-2", type=int, default=1, dest="min_level_2",
                         help="--from-survey only: L2 files a (plan, pass) "
                         "needs before it is written (default 1, i.e. L2 has "
                         "started; completeness is assessed per pass by the "
                         "query plan, not here)")
    parser.add_argument("--dry-run", action="store_true", dest="dry_run",
                         help="--from-survey and --relabel: print what would "
                         "change and write nothing")
    parser.add_argument("--program", type=int,
                         help="required with --append and --relabel, e.g. "
                         "1039 or 1063")
    parser.add_argument("--execution-plan", type=int, dest="execution_plan",
                         help="required with --append and --relabel")
    parser.add_argument("--decon-cycle", dest="decon_cycle",
                         help="required with --append, e.g. decon1, decon2; "
                         "optional with --relabel")
    parser.add_argument("--mce-side", dest="mce_side",
                         help="--append and --relabel: A or B. Blank on "
                         "--append means stage 1 records 'assumed:flight-"
                         "side-A'")
    parser.add_argument("--passes", help="required with --append and "
                         "--relabel, e.g. '43-50' or '43,45,48-50'")
    parser.add_argument("--blank-dark", dest="blank_dark",
                         action=argparse.BooleanOptionalAction, default=True,
                         help="--append only; default: --blank-dark")
    args = parser.parse_args()

    if args.self_test:
        sys.exit(0 if self_test() else 1)

    if args.relabel:
        _relabel(args)
        return

    if args.init:
        print("WARNING: --init writes a hand-maintained list that lags the "
              "archive (as of 2026-10-03 it misses 10 passes and invents 1); "
              "prefer --from-survey. See the comment on INITIAL_RANGES.")
        new_rows = pd.DataFrame(_rows_from_ranges(INITIAL_RANGES))
        _write(args.manifest, new_rows)
        return

    if args.from_survey:
        _from_survey(args)
        return

    missing = [name for name, value in (
        ("--program", args.program), ("--execution-plan", args.execution_plan),
        ("--decon-cycle", args.decon_cycle), ("--passes", args.passes))
        if value is None]
    if missing:
        raise SystemExit(f"--append requires {', '.join(missing)}")

    existing = _load_existing(args.manifest)
    new_rows = pd.DataFrame([
        {"program": args.program, "execution_plan": args.execution_plan,
         "pass": pass_, "decon_cycle": args.decon_cycle,
         "blank_dark": args.blank_dark,
         "mce_side": normalize_side(args.mce_side)}
        for pass_ in _parse_pass_ranges(args.passes)])

    key = ["program", "execution_plan", "pass"]
    if len(existing):
        duplicate = new_rows.merge(existing[key], on=key, how="inner")
        if len(duplicate):
            print(f"  skipping {len(duplicate)} row(s) already in the "
                  f"manifest: {duplicate[key].to_dict('records')}")
        new_rows = new_rows.merge(existing[key], on=key, how="left",
                                   indicator=True)
        new_rows = new_rows[new_rows["_merge"] == "left_only"].drop(columns="_merge")

    combined = pd.concat([existing, new_rows], ignore_index=True)
    _write(args.manifest, combined)


if __name__ == "__main__":
    main()
