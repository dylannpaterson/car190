# The trend passes: what happened, and why each row has its labels

[`batch/run_manifest.csv`](batch/run_manifest.csv) is the machine record: one
row per pass, with the two labels the archive cannot supply, `decon_cycle` and
`mce_side`. This file is the human record of the same rows. It says why each
label is what it is, which passes are absent and why, and when the instrument
did something the trend has to know about. Add to it whenever a label is set or
changed, a pass turns out absent or short, or a new data tree is made. The
procedure that produces those moments is `batch/refresh.py` (start with
`status`; `label` prints the line to add here), described in
[DATA_PULL.md](DATA_PULL.md).

Times are UTC exposure starts. "Epoch" means one pass's product. Temperatures
are the MPA (`WFI_MCE_ADC_WTSM00`, stored as `WFI_MCU_A_MPA_CSENS_FPSSEN_K`).

## Current state, 2026-11-09: 253 rows

| program | plan | passes | first .. last | decon | MCE side | notes |
|---|---|---|---|---|---|---|
| CAR-190 (1039) | 2 | 1-37 | 09-12 01:22 .. 09-23 08:45 | decon1 | A (assumed) | 12 absent, 25 short |
| CAR-216 (1063) | 2 | 1-90 | 09-24 23:08 .. 09-26 11:47 | decon2 | A (assumed) | every 24 min, from the top of the decon2 cooldown |
| CAR-216 (1063) | 3 | 1-36 | 09-26 12:11 .. 09-27 02:09 | decon2 | A (assumed) | |
| CAR-190 (1039) | 2 | 38-46 | 09-27 02:55 .. 09-30 04:22 | decon2 | A (assumed) | |
| CAR-190 (1039) | 3 | 47-57 | 09-30 15:20 .. 10-06 04:13 | decon2 | A (47-52 assumed, 53-57 recorded) | |
| CAR-190 (1039) | 3 | 71-75 | 10-06 11:54 .. 10-08 19:24 | decon2 | **B** | first passes after the side swap; 58-70 never ran |
| CAR-216 (1063) | 4 | 1-10 | 10-09 04:45 .. 10-11 06:02 | decon2 | **B** | **the enclosure +1 degree test**, from 10-09 05:11 (pass 1 is the last epoch before it); not after a decon (MPA 89.54-89.56 K). ACM staircase between 8 and 9 |
| CAR-216 (1063) | 5 | 1-5 | 10-11 16:39 .. 10-12 08:20 | decon2 | **B** | continues plan 4 with no visible change: heater setpoints, enclosure thermistors and MPA all as at the end of plan 4 |
| CAR-216 (1063) | 4 | 11 | 10-12 20:19 | decon2 | **B** | plan 4 again, after plan 5 pass 5: the plans interleave |
| CAR-216 (1063) | 5 | 6 | 10-13 05:21 | decon2 | **B** | small LVDT tilt (mean +20 counts) between p4.11 and this pass |
| CAR-190 (1039) | 3 | 76-82 | 10-13 19:59 .. 10-17 18:47 | decon2 | **B** | CAR-190 resumes after 5 days; side B, same plateau. Two ACM staircases, before 78 and before 81 |
| CAR-216 (1063) | 5 | 7-12 | 10-17 22:33 .. 10-19 15:18 | decon2 | **B** | **enclosure bump** (confirmed): setpoints 06-09 at 143 (from 139) from 10-17 23:00, after pass 7's core flats, so passes 8-12 run warmer; COBA +1.7 K, slowly |
| CAR-216 (1063) | 6 | 1-8 | 10-20 20:31 .. 10-22 03:55 | **decon3** | **B** | **the decon3 sequence variant** (`car216_decon3`), down the decon3 cooldown from 121.5 K to the 89.5 K plateau at pass 8; enclosure setpoint back at 139 |
| CAR-190 (1039) | 3 | 83-93 | 10-23 17:19 .. 10-29 10:50 | **decon3** | **B** | CAR-190 resumes after 6 days, inside decon3, on the plateau. SCA18 reads ~0.8 % lower than in the `car216_decon3` passes before it: the MA table (DROP_2_OF_3), see the 10-22 entry |
| CAR-216 (1063) | 5 | 13-24 | 10-29 14:56 .. 11-04 08:00 | **decon3** | **B** | plan 5 again, ten days after its pass 12 and inside decon3, with the decon2 `car216` sequence and its DROP_2_OF_3 readout. ACM staircase 10-29 18:15-21:27 (13 \| 14). **The telescope bumps**: the AOM from 10-30 01:48 (pass 14 starts 16 min into it, 15 mid-ramp, 16-20 on its +5.16 K plateau), the AMS from 11-01 23:48 (21-24 on both plateaus). **romancal 1.0.3** from pass 23 |
| CAR-190 (1039) | 3 | 94-98 | 11-05 04:43 .. 11-09 09:22 | **decon3** | **B** | CAR-190 resumes after 7 days: pass 94 starts 13 min after the 11-05 04:30 command that ended both bumps, 95-98 back at baseline. ACM staircases 11-06 (94 \| 95) and 11-07 (96 \| 97). DROP_2_OF_3, so no SCA18 step at the switch |

Each row is one contiguous run in time of one program and plan, and the rows
are in time order, which is the order of the trend. Execution plan and
pass number are scheduling labels: they restart with every plan, and CAR-190
and CAR-216 interleave. Read the chronology from the start times, never from
the numbering (`refresh.py status` and `probe` list passes in time order).

"Assumed" is a blank manifest cell, which stage 1 records as
`mce_side_source = "assumed:flight-side-A"`. Since 2026-10-08 the assumption is
corroborated pass by pass: all 176 v3 products show the side-A LED map (see the
swap entry below). "Recorded" means the cell holds the side, forwarded as
`--mce-side` and recorded as `mce_side_source = "cli"`.

ACM segments, from the v4 reference card (reference LVDT, mean of the six channels):

| segment | from | LVDT |
|---|---|---|
| 0 | CAR-190 p2 pass 1, 09-12 | 7558 |
| 1 | CAR-190 p2 pass 16, 09-14 23:54 | -2814 |
| 2 | CAR-190 p2 pass 37, 09-23 08:52 | -5232 |
| 3 | CAR-190 p2 pass 41, 09-27 15:13 | -2815 (-3110 after the small 53->54 move) |
| 4 | CAR-190 p3 pass 71, 10-06 11:54 -- **the side swap, not an ACM move** | -3115, read by the B electronics (-2742 after the small 75->CAR-216 p4 move) |

Whether each step across a move is measured (`bridge`) or modelled
(`multiplier`) is a stage-3 result, stated in each digest set's
`run_log.txt`, not here.

## Sequence variants

Every pass's L1 layout reduces to a signature (`rcs_activities.sequence_signature`),
registered in `rcs_trend_config.SEQUENCE_VARIANTS`; `refresh.py status` names
each new pass's variant and stops on an unknown one (DATA_PULL.md, *A new
sequence variant*). Observations 1-7 (the dark and the six LED flats) are the
same in all three in exposure time; the aux tail differs, and it is never
trended. The readout differs too, and that one does reach the trend: on SCA18
only, `car216_decon3` reads about 0.76 % higher than CAR-190 (2026-10-22 entry
below). The MA table is not in the survey listing, so the signature cannot see
it; it was read off the L2 frames' `meta.exposure` on 2026-10-30 (SCA18 LED3 of
CAR-216 p5.6 and p6.8, CAR-190 p3.76 and p3.83), and stage 1 records
`ma_table_name`/`ma_table_number`/`nresultants` on each activity of products
made from 2026-10-30.

| variant | first seen | readout (MA table) | aux tail (obs 8 on) | aux at L2 |
|---|---|---|---|---|
| `car190` | 2026-09-12, CAR-190 p2 1 | `DROP_2_OF_3` (9008): reads 1,4,7,10,13 | none | -- |
| `car216` | 2026-09-24, CAR-216 p2 1 | `DROP_2_OF_3` (9008) | obs 8: 4 darks (41 s); obs 9: 4 band-3 flats (41 s) | obs 9, as `AUX_LED3FLAT1..4` |
| `car216_decon3` | 2026-10-20, CAR-216 p6 1 | `IM_DIAGNOSTIC` (9010): every read 1-13, full-frame downlink | obs 8: persistence dark (177 s); 9: 4 darks (41 s); 10: 5 low-flux band-3 flats (66 s, 150 e/pix/s); 11: 4 high-flux band-3 flats (41 s, 1500 e/pix/s); 12: persistence dark | obs 11, as `AUX_LED3FLAT1..4`. Obs 10 never reaches L2: it is 22 resultants, and L2 processing takes 16 or fewer |

The decon3 sequence (operations, 2026-10-21): 177 s persistence clean-up dark;
6 x 41 s flats through all six bands; 177 s persistence dark; 4 x 41 s darks
(pixel families, excess dark, ramp-fit statistics); 5 x 66 s low-flux band-3
flats; 4 x 41 s high-flux band-3 flats; 177 s persistence dark. 1262 s of
science in 1800 s of execution.

## Timeline

**2026-09-12 01:22 -- CAR-190 plan 2 pass 1, the reference epoch.** Response == 1
here, on side A, for the whole trend. Decon1's cooldown is still running: the
MPA reads 110 K at pass 1, is within 0.5 K of the 89.5 K plateau by pass 11,
and reaches it (<= 89.6 K) at pass 15, 09-14 16:44. The
pass 1 | 2 photometric step of +/-2 % was a Roman L2 photom reference change, and
pass 1 is the epoch that's right. v3 stages plan 2 passes 1-37 from the local
L2 reprocessing instead (`--aux-l2-dir`, README -> *Rebuilding passes from a
local L2 reprocessing*).

**Pass 11 -> 13 (pass 12 absent) -- a photodiode readout-chain shift, not a
swap.** Both diode pedestals stepped and stayed stepped (+307 uV PD2, +131 uV
PD1) while the lit nets did not move. The two-diode ratio moved -0.14 % and
only 23 % chromatically. Side A throughout.
[PD_CORRECTION.md](PD_CORRECTION.md) Sec. 8.

**Pass 12 -- absent.** Not in the archive at L1 or L2.

**Between passes 11 and 13 (09-13 20:14 -> 09-14 04:25) -- a WFI power cycle**,
per the operations team (2026-10-10), who place pass 13 just after it. The
power cycle explains three things:
- the 8 h gap, twice the cadence, with pass 12 lost;
- the readout-chain pedestal step above;
- **a one-pass hiccup at pass 13.**

Against a local quadratic through its neighbours with pass 13 left out, pass
13 reads +0.066 ... +0.085 % high on every LED (LED6 lowest), so it is nearly
achromatic. Its per-SCA achromatic scatter is 0.081 % rms, against 0.005-0.019 %
at passes 3-11; SCA5 and SCA7 are the largest, at +0.15 %. Pass 14 has mostly
recovered (0.034 % rms, SCA11 +0.10 % the largest), and pass 15 reads normally.
Reproduce with `trend_change_check.py outliers --first CAR190_01039_02_001
--last CAR190_01039_02_015 --exclude CAR190_01039_02_013`. The
temperature-gain correction does not remove it: the MPA is unaffected. Nothing
corrects it, and it is too small and too short to matter for the ACM bridge at
15 -> 16, which is >= 25 h away. Treat pass 13 as a known outlier (detector
settling after power-on is the obvious candidate); pass 13 is still labelled
decon1 / A like its neighbours.

**09-14, pass 15 -> 16 -- ACM move**, LVDT 7559 -> -2814 (segment 0 -> 1).

**Pass 25 -- short.** A 5-observation sequence: observation 7 was never taken.
No plan can be built for it, so its manifest row **fails on every full run, by
design** (`batch/status/CAR190_01039_02_025_decon1.failed`, "no cached plan").
It is absent from the MAST-built and the reprocessed sets alike.

**09-22/23, pass 36 -> 37 -- ACM move**, -2815 -> -5232 (segment 1 -> 2). Pass 37
(09-23 08:45) is the last decon1 epoch.

**09-23 .. 09-24 -- decon2.** No pass ran during it. CAR-216 plan 2 pass 1
(09-24 23:08) reads **124.5 K**, the top of the decon2 cooldown. It is below
90 K by CAR-216 plan 2 pass 72 (09-26 03:28) and on the plateau at pass 78
(09-26 07:00). CAR-216 adds two observations
to the CAR-190 sequence: obs 8 is 4 darks, and obs 9 is 4 LED3 flats (the
`car216` variant, until decon3; see *Sequence variants*).

**09-27 02:55 -- CAR-190 resumes**, plan 2 pass 38. **09-27 15:13, pass 40 -> 41 --
ACM move**, -5232 -> -2815 (segment 2 -> 3).

**09-30 15:20 -- CAR-190 plan 3 begins**, pass 47.

**10-03/04, pass 53 -> 54 -- a small ACM move**, all six LVDT channels together by
-240 to -370 counts (mean -296). It is below `ACM_MOVE_MIN_DELTA` (500), so it is
not a segment boundary, and the linear in-segment ACM term covers it at ~0.1 %. It
pushes segment 3's maximum fractional travel to 0.105, just over the 0.10 at which
the card and the digests warn. Open question: make it a segment, which would add
a bridge with 1 epoch a side (passes 53/54), or accept the linear model there.

**2026-10-06 ~05:00-06:00 -- the MCE swapped from side A to side B**
(the LVDT reads 0 at 04:42-04:52 and 05:23-05:34 and comes back at 05:34:32
reading -3303 where it read -3132: the B electronics' first reading), between
CAR-190 plan 3 pass 57 (04:13) and pass 71 (11:54). Found 2026-10-08 from
`--pd-only` sidecars; [DATA_PULL.md](DATA_PULL.md#step-2-probe-and-a-telemetry-look-the-evidence)
has the procedure and the full reading.

- **Passes 58-70 never ran.** The pass counter jumped, and no time is missing:
  pass 71 started 7.7 h after pass 57, inside the usual spacing.
- **No decon.** MPA 89.48-89.54 K throughout, with a -0.02 K step between 04:00
  and 07:00, plausibly the B-side ADC on the same thermistor. 71-74 stay
  `decon2`.
- **LED map** (hardware select line per sequence LED1..6): `612345` on every
  earlier epoch, `132465` on every pass from 71. It is a **renumbering**:
  PD1's 1670 nm cutoff stays on sequence LED6, and LED2 keeps its PD1/PD2
  ratio, so sequence LEDn is the same physical LED on both sides.
- **Photodiodes:** PD2 pedestal -1.92 mV, PD1 +1.06 mV (6x and 8x their whole
  A-side ranges). PD1/PD2 by LED moved -5.8, -1.5, +0.5, -0.9, -0.8, -8.2 %,
  an 8.7-point chromatic spread. B-side PD2 pedestal rms 0.9 uV against ~15 uV.
- **Pass 71 only:** ~4 min of extra illumination after its sequence
  (presumably checkout). Its LED nets are clean, but its pedestal-drift
  statistic reads an impossible +1.54 V/hr. 72-74 are normal.
- No telemetry name flags the side. `WFI_MCU_B_RIO_SEL` reads `PRI` before and
  after, and the products' MCU-B MPA column is NaN by construction.
  `WFIF_ICDH_HPSM_MCE_OHPA/OHPB_STS` were suggested; neither is in the MAST EDP
  (2026-10-09; `refresh.py status` re-checks every run).
- **ACM LVDT read by different electronics:** -172, +205, -6, -91, -352, +21
  counts by channel across the swap. That is a readout change, not a move. The
  swap opens ACM segment 4 so side B has its own reference LVDT, and there is no
  ACM step across it.
- **Calibrated 2026-10-09** (schema 2): side bridge, A scaled onto B, LED1 0.8933,
  LED2 0.9439, LED3 1.0322, LED4 0.9919, LED5 0.9911, LED6 1.0006, +/-0.6-3 x 10^-4.
  Illumination-pattern test 1.90x noise (SCA8/17/18 largest, ~-2 x 10^-4). The
  B-side photodiode is re-based to 1 at pass 71.

**2026-10-08/09 -- L2 calibration context `roman_0075`**, from CAR-190 p3 pass 75
on. It is a new `ref_file_id` (`5c871b249e2f6eaf`), and stage 3 refused the set
until it was measured. Only the distortion reference changed (0027 -> 0053,
WCS-only). The B-side trend puts no step at 74|75: 0.0085 % per-SCA
achromatic rms (quadratic) against 0.0040-0.0092 % for null splits; 0.0151 %
against 0.0098-0.0169 % linear (`trend_change_check.py steptest`). It is mapped to
`unity-photom` in `rcs_trend_config.CALIBRATION_EQUIVALENCE`; README has the
measurement.

**2026-10-10 -- `roman_0076`** from CAR-216 p4 pass 4 on (`2dd418ec414b1196`):
again only distortion moved (0053 -> 0061). A quadratic over the twelve B-side
epochs puts a 0.0037 % per-SCA achromatic step at p4 3|4, against 0.0042-0.0074 %
for null splits. Mapped to `unity-photom` like 0075.

**10-07 05:46 -> 08:45, between passes 72 and 73 -- an ACM staircase.** The
LVDT (channel 1) stepped -3309 -> -8277 -> -5815 -> -3323 -> -777 -> +1764 ->
-3315, about 2500 counts a step at roughly 45 min intervals, and came back
(`trend_change_check.py telemetry WFI_MCE_LVDT_ACM_1 --dropout 0`). No
RCS pass ran during it. Passes 72 and 73 read the same position (mean -3175.5
/ -3176.6), and the 72|73 null split above is ordinary, so it leaves nothing
in the trend. It is not a segment boundary, by design: the products only ever
see the before and after.

**10-08 23:09, CAR-190 p3 pass 75 -> CAR-216 plan 4 pass 1 -- a small ACM move
on side B**, all six LVDT channels together by +419 to +462 counts (mean
+435). It comes about 6 h before the enclosure heater change below, so it is a
commanded move, not a thermal one. Like 53->54 it is under the 500 threshold, so it is not a
segment boundary. It raises the worst in-segment travel from 0.105 to 0.139.
Uncorrected it is a +0.14-0.15 % achromatic focal-plane step. The linear ACM
term (0.99868 at p4) leaves +0.006...+0.018 % (quadratic trend), and the per-SCA
part is at the 0.010 % noise floor. The open question at 53->54 now covers both
moves. A segment here would have 2 epochs on each side within +/-25 h.

**2026-10-09 -- CAR-216 plan 4 begins** (04:45), on side B with no decon (MPA
89.56 K). Pass 3 (15:42) finished indexing at L2 about three hours after its
start.

**2026-10-09 05:11 -- the WFI enclosure raised by about 1 degree**; CAR-216 plan
4 is that test, per the operations team (2026-10-10). In the telemetry:
- Heater setpoints `WFI_MCE_HTR_SETPOINT_06`...`09` step 132 -> 139 at
  05:10:58-05:13:20, and the other eleven setpoints do not move.
- `WFI_MCE_ADC_WTSM20`...`23` go from passive (137.2-137.9) to controlled at
  139.0, and heater `WFI_MCE_HTR_CHN_PWM_07` comes on.
- The enclosure thermistors start rising about 05:30 and take roughly a day
  to settle. 10-08 to 10-10 12:00:

  | mnemonic | units | before | after |
  |---|---|---|---|
  | `WFI_MCE_ADC_WTSM10` | K | 143.4 | 144.2 (+0.8) |
  | `WFI_MCE_ADC_WTSM11` | K | 140.5 | 141.7 (+1.2) |
  | `CDHA_TCS_WTSC22P` | degC | -130.6 | -129.3 (+1.3) |
  | `CDHA_TCS_WTSC24P` | degC | -126.8 | -125.9 (+0.9) |
  | `WFI_MCE_TEMP_CMU` | -- | 144.2 | 144.2 (unmoved) |
  | `WFI_MCE_TEMP_ACM_1`...`6` | -- | 143.0 / 140.2 (1 / 4) | +0.7 over the day |
  | `WFI_MCE_ADC_WTSM00` (MPA) | K | 89.5 | 89.5 (unmoved) |

  `CDHA_TCS_WTSC22P` and `WTSC24P` are the raw names behind
  `WFI_ENCL_FRM_NR_LATCH_A_WTSC22P_K` and `WFI_ENCL_CAP_WTSC24P_K`. Those two
  `_K` names are not in the MAST EDP dictionary (HTTP 400). The B-side
  `CDHB_TCS_WTSC22R`/`24R` return no samples.
- **CAR-216 p4 pass 1 (04:45-05:09) is the last epoch at the old enclosure
  temperature**, ending 2 minutes before the first setpoint change. Passes 2-7
  are on the warm-up. The products record none of these temperatures; the
  pipeline's housekeeping carries the MPA only.
- **What the trend shows (193 epochs, 2026-10-10): nothing resolvable.** Fit
  across the twelve B-side epochs with a step at p4 1|2, the focal-plane step
  is -0.012 ... -0.001 % per LED and the per-SCA achromatic part is 0.0050 % rms
  (`trend_change_check.py steptest --first CAR190_01039_03_071 --last
  CAR216_01063_04_007 --at CAR216_01063_04_002`).
  Both are inside the null splits. LED1's focal-plane slope does go from -0.2
  to +0.9 %/day across the change, but that is the film fringe turnover. The
  per-SCA LED1 slopes cross zero in a staggered sequence: SCA1 by 10-05; SCA7,
  10 and 18 by 10-07; SCA4 and 5 on 10-09; SCA2, 3, 6 and others not yet. They
  run smoothly through 05:11. A slow thermal response over the day-long
  settling cannot be separated from growth with these data.

**10-10 18:42 -> 21:41, between CAR-216 p4 passes 8 (16:08) and 9 (21:59) -- a
second ACM staircase**, the same six steps of about 2500 counts as on 10-07:
`WFI_MCE_LVDT_ACM_1` -2860 -> -7846 -> -5419 -> -2864 -> -374 -> +2219 -> -2872,
settling 6 counts from where it started (-2860 before, -2866 after). No RCS pass
ran during it (`trend_change_check.py telemetry WFI_MCE_LVDT_ACM_1 --start
2026-10-10T00:00 --end 2026-10-12T12:00 --dropout 0`).

**2026-10-11 16:39 -- CAR-216 plan 5 begins**, 10.6 h after plan 4's last pass.
Nothing in the telemetry changes at the boundary: the fourteen heater setpoints
are as plan 4 left them (06-09 at 139, the +1 degree enclosure), `WTSM10/11`,
`CDHA_TCS_WTSC22P/24P` and `WFI_MCE_TEMP_CMU` are flat, and the MPA reads
89.55-89.58 K. LED map `132465`, side B, decon2.

**2026-10-12 -- deployed to the shared path** with `batch/refresh.py seed`: the
193-epoch tree went from `/data/eswitzer/rcs_trend_v4` to
`/mnt/smdc-rom-com-ops/rrn-ops/activities/car-190-rcs-spectro-trending/rcs_trend_v4`
(group `romcom`), and the 8 new passes were staged and processed there.

**10-12 22:23, between CAR-216 p4 pass 11 (20:19) and p5 pass 6 (05:21) -- a
small LVDT tilt.** All six channels stepped once, by +75, +54, -29, -31, +12 and
+42 counts (mean +20). Opposite signs across the channels make it a tilt rather
than the common shift of an ACM move, far below the 500-count segment threshold
(`trend_change_check.py telemetry WFI_MCE_LVDT_ACM_1 ... WFI_MCE_LVDT_ACM_6
--start 2026-10-12T20:00 --end 2026-10-13T02:00 --every 1h --dropout 0`).
Heater setpoints, enclosure thermistors, CMU and MPA were flat 10-12 to 10-14.

**2026-10-13 -- L2 calibration context `roman_0077`**, from CAR-190 p3 pass 76
on (`2c8d2de83f5ace81`), and stage 3 refused the set until it was measured.
`trend_change_check.py refdiff CAR216_01063_05_006 CAR190_01039_03_076`:
only distortion moved (0061 -> 0078), as at 0075 and 0076. Over the nineteen
B-side epochs CAR-216 p4 1 .. CAR-190 p3 77, `steptest --degree 2` puts a
per-SCA achromatic step of 0.0103 % rms at p5.6|p3.76, inside the null range
0.0041-0.0136 %, so it is mapped to `unity-photom`. Open item: with only two
0077 epochs, at a CAR-216 -> CAR-190 switch, the focal-plane LED1 step read
-0.172 % against nulls of +/-0.10 %. **Resolved 2026-10-17**, below. That is not the per-SCA photom signature,
and it is unexplained. A program switch alone does not do it: the 09-27
CAR-216 -> CAR-190 switch (p3.36|p2.38, same segment, no calibration change)
reads +0.021 %, inside its nulls. LED1's growth curvature at a window edge
remains possible. Re-test once more 0077 passes are in, e.g. `steptest --first
CAR216_01063_04_001 --last <latest> --at CAR190_01039_03_076 --degree 2`.

**2026-10-13 19:59 -- CAR-190 resumes** with plan 3 pass 76, 5 days after pass
75, on side B and the decon2 plateau (MPA 89.54 K).

**10-14 13:04 -> 16:04, before CAR-190 p3 pass 78 (19:40) -- an ACM staircase**,
the same six steps out to about -7780 and back (channel 1 -2799 -> -2797), all
six channels together.

**10-15 23:07 -> 10-16 13:41, between CAR-190 p3 passes 80 (16:20) and 81
(13:47) -- a slow ACM staircase**, the same six steps with about 2.7 h between
them instead of half an hour, back to where it started (-2791 -> -2799). It
ended 6 min before pass 81's sequence began (its dark), 16 min before its first
lit exposure: the closest a pass has come to a move. Pass 81 is the last epoch,
so `outliers` cannot interpolate it yet; check it once the next pass is in.
Heater setpoints, enclosure thermistors and MPA were flat 10-14 to 10-16
(`trend_change_check.py telemetry`, DATA_PULL.md step 2).

**10-17 23:00:54 -> 10-20 05:05:12 -- enclosure setpoints 06-09 at 143**,
up from 139 (the +1 K setting of 10-09), and back to 139 at the decon. It came
during CAR-216 plan 5 pass 7's aux tail, after its six core flats, so pass 7's
trend point is at 139 and pass 8 is the first at 143. The enclosure thermistors followed: `WTSM10`
144.2 -> 147.0 K, `WTSM11` 141.7 -> 144.9 K, `CDHA_TCS_WTSC22P` -129.3 -> -126.5
C, `WTSC24P` -125.9 -> -123.0 C, taking about half a day to settle. So CAR-216
p5 passes 8-12, the end of decon2, ran about 2.8 degrees warmer again. It was a
deliberate enclosure temperature bump (confirmed by operations, 2026-10-22).
The COBA (`WFI_MCE_ADC_WTSM04`) followed more slowly. It held at 144.15 K until
about 10-18 06:00, seven hours after the setpoint change, then rose steadily to
145.85 K by 10-20 00:00, +1.7 K (operations: about +1.5 K). It was still rising
when the decon heaters came on, so it never settled at the bumped setting.
The trend shows no step at p5.7|p5.8 (Re-run at 220 epochs, below).

**2026-10-20 05:03 -- decon3.** Heater setpoint 04 went 130 -> 165 and the MPA
peaked near 186 K. The enclosure setpoints 06-09 went back to 139 two minutes
later (05:05), and decon3 runs at 139, the +1 K setting of 10-09. The decon
heat reached the COBA as well, 165.6 K at 10-20 06:00 falling to 147.8 K by
10-21 18:00. CAR-216 plan 6 pass 1 (20:31) reads 121.5 K on the cooldown,
then 106.5, 99.0 and 94.7 K at passes 2-4. Plan 5 pass 12 (10-19 15:18) is the
last decon2 epoch. `probe` proposed the split itself, decon2 for 5:7-12 and
decon3 for 6:1-4.

**2026-10-20 20:31 -- CAR-216 plan 6 begins, the `car216_decon3` sequence.**
Observations 1-7 are unchanged. The aux observations renumbered, which broke
stage 1: `probe` failed with `expected exactly one dark exposure at L1 ...
found 2` (obs 1 and the obs-12 persistence dark), and the obs-11 flats would
have counted as extra core flats. Fixed 2026-10-21 by making obs 1-7 the core
by definition (`rcs_activities.CORE_OBSERVATIONS`) and keying aux exposures by
content; the obs-11 flats keep the old name `AUX_LED3FLAT1..4`. The obs-10
low-flux flats are 22 resultants, beyond L2 processing's limit of 16, so they
are never at L2 and never in a product. Products staged from plans written
from 2026-10-22 on record their variant in `sequence_variant` /
`sequence_signature`; the earlier ones say `not recorded` until they are
re-staged by a batch rerun. `status` also
called these passes "complete" only because 10 x 18 L2 files matched the old
CAR-216 count; completeness is now the core flats at L2.

**CAR-216 p6 pass 5 (10-21 15:58).** On 10-22 its six core flats were at L2 on
18 SCAs, but L1 held only observations 1-7, a prefix of `car216` /
`car216_decon3`. By 10-25 its full tail was there (396 L1 files) and it reads
`car216_decon3`: MAST had still been indexing it, more than a day after the
pass. A partial signature resolves this way; it is not evidence of a short
sequence until it stays partial.

**2026-10-21 to 10-25 -- quiet.** No ACM steps, no setpoint changes (06-09 at
139 throughout), and the decon3 heat drained away: the MPA reached its 89.5 K
plateau by about 10-22 12:00 (CAR-216 p6.8 reads 89.54 K), the enclosure
thermistors were back at their 139-setpoint values by about 10-22, and the COBA
at 144.1 K by 10-24 (`trend_change_check.py telemetry --preset intake
WFI_MCE_ADC_WTSM04 --start 2026-10-20T12:00 --end 2026-10-25T12:00`).

**Re-run at 227 epochs (2026-10-25).** Digests `digests_v4_10_25_26`. The 220
earlier epochs are bit-identical; every check in `run_trend.py` closes; the
warnings are the understood ones (epochs 182 and 218); all new passes are
`roman_0077` and record `sequence_variant` (`car216_decon3`, `car190`), the
first intake to do so. The first run of stage 2 died on a lost NFS RENAME reply
(`FileNotFoundError` on a `*_cal.h5.tmp-<pid>` whose rename had in fact
succeeded), which left 115 products on the new pass and 112 on the old.
`rcs_fsutil.replace` now recognises it, and the rerun closed.

Checks inside decon3, now 11 epochs:
- `outliers --first CAR216_01063_06_001 --last CAR190_01039_03_085`: nothing
  flagged (median per-SCA rms 0.023 %, higher than on a plateau because the
  film is regrowing).
- At the CAR-216 -> CAR-190 switch (p6.8 | p3.83, a 37 h gap), `steptest
  --degree 2` reads 0.14-0.17 % per-SCA rms against nulls of 0.03-0.05 %, in
  every window and with or without the gain. It is **SCA18 alone**, and it is
  a real step (below). This entry first called it SCA18's regrowth curve, from a
  comparison against SCA17 alone; that was wrong, because SCA17 drifts too.

**2026-10-22 04:02 -> 10-23 17:25 -- SCA18 reads about 0.76 % lower** (the
CAR-216 -> CAR-190 switch in decon3; a readout-mode effect, see the last points).
Investigated 2026-10-25; figures and a README in
`$ROOT/plots/diagnostics/sca18_step_20261023/`.
- Against the median of the other 17 SCAs, with each side's trend fitted (4
  epochs before, 3 after) and extrapolated to the middle of the gap, SCA18
  steps -0.90, -0.76, -0.74, -0.67, -0.76, -0.72 % in LED1..LED6: achromatic.
  Every other SCA moves 0.12 % or less (`trend_change_check.py relative --sca 18
  --at CAR190_01039_03_083`).
- It is uniform across the detector: the spread across SCA18's 32 readout
  channels is 0.03-0.13 % against the -0.4 to -0.9 % shift, with no regional
  structure beyond the film regrowth every SCA shows over 37 h
  (`trend_change_check.py mosaic ... --zoom 18`).
- It is not the program switch. The three decon2 switches (10-09, 10-13,
  10-17) show nothing (SCA18 mean -0.04 to +0.01 %), and nothing like it occurs
  anywhere else in the trend; it is SCA18's largest move outside the two decons.
- It is not L2 calibration. SCA18's own reference files are identical on both
  sides (`ref_file_id` a9dbd1863f981031, `gain_0045`). The set's fingerprint is
  SCA01's alone, so a per-SCA reference change would not have shown in it; this
  checked SCA18 directly.
- No telemetry MAST serves shows an SCA18-specific event in the gap: ACM, heater
  setpoints, enclosure, COBA and MPA are quiet, the SCU18 SpaceWire error
  counters stay 0, and the SCE18 command acks match SCE17's. The per-SCA
  `WFI_SCE_18_FFHK_*` housekeeping registers are raw address/data pairs with no
  decoding in the EDP; a detector or ASIC temperature or bias there would need
  the register map from the instrument team.
- Not recovered by CAR-190 p3.85, 30 h later.
- **Explained (operations, 2026-10-30): it is the readout mode, not an event.**
  The decon3 CAR-216 variant (`car216_decon3`) downlinks full frames, while
  CAR-190 uses a drop-frame MA table. SCA18 is the only detector with an initial
  transient in its up-the-ramp sampling, and romancal corrects the read-1
  transient from the other reads. With different reads available the
  correction lands about 1 % differently on SCA18 alone. The frames confirm the
  tables: p6.8 is `IM_DIAGNOSTIC` (9010, 14 resultants), p3.83 `DROP_2_OF_3`
  (9008, 6 resultants), and so are the decon2 CAR-216 passes (p5.6). That it is only of
  order 1 % is a good result. **No action is needed.**
- **For downstream users:** SCA18's response differs by about 0.76 %,
  achromatically, between `car216_decon3` passes and CAR-190 passes. Expect a
  step of that size, one sign or the other, at every switch between the two,
  and treat SCA18 across a program switch in decon3 with that in mind. The
  earlier `car216` variant used the same drop-frame sampling as CAR-190, which
  is why the decon2 switches show nothing. The digests carry the offset as it
  is; nothing corrects it.
- **Null test, 2026-10-30:** CAR-216 p5.13 (below) ran with the decon2 `car216`
  sequence, whose core flats are `DROP_2_OF_3` like CAR-190 (only its aux
  band-3 flats are `IM_DIAGNOSTIC`). `relative --sca 18 --at
  CAR216_01063_05_013` reads -0.02 to +0.02 % in LED2-6 (LED1 +0.15 %, its
  growth curvature at the end of the trend): no step, as the readout predicts.
  Re-measured with four more days of CAR-190, the p6.8 | p3.83 step is -0.65 to
  -0.75 % in LED2-6 (LED1 -1.09 %). Figures and README:
  `$ROOT/plots/diagnostics/sca18_step_20261023/`.

**2026-10-25 to 10-29 -- CAR-190 p3 86-93, quiet.** Side B, MPA 89.53-89.56 K,
heater setpoints unchanged (04 at 165, 06-09 at 139), enclosure thermistors
flat, ACM within 4 counts (`telemetry --preset intake --start 2026-10-24T12:00
--end 2026-10-30T00:00 --every 12h`). Every core flat `DROP_2_OF_3`.

**2026-10-29 15:03 -- CAR-216 plan 5 pass 13, inside decon3.** Plan 5 again,
ten days after its pass 12 (10-19, decon2) and after plan 6, with the decon2
`car216` sequence: core flats `DROP_2_OF_3`, aux band-3 flats `IM_DIAGNOSTIC`
(9010, 14 resultants). Labelled decon3 by time: no warm pass since 10-20, MPA
89.55 K. It is the epoch that tested the SCA18 readout explanation (above).

**10-29 18:15 -> 21:27, after CAR-216 p5.13 -- an ACM staircase**, of a new
shape: -2797 -> -7782 -> -5348 -> -2807 -> -295 -> +2286 -> -2796, so out to
-7800 and then on up to +2300 before returning, ending within 1 count of where
it started. No pass falls inside it; the next pass is the first to test for
settling.

**2026-10-30 01:48 -- the AOM bump (operations), +5.15 K.** Operations warm
the telescope, the AOM first and then likely the AMS, to see whether either
changes the ice deposition rate. AOM 183 P (`TCEA_TME_EXT_THERMISTOR_50`) went
217.67 -> 222.82 K: a glitch on several telescope thermistors at 01:48 (the
command), then 10 % at 03:00, 50 % at 05:15, 90 % at 10:15, flat from about
16:00 (`telemetry --preset intake`, `ramps` block). `_45` beside it rose 4.7 K;
`CDHA_TCS_WTSC22P/24P` rose 0.1-0.2 K. AMS CT 16 P (`_101`) is unchanged at
267.0 K through 11-01, and so are TOMA, FMS, SM and everything on the WFI side
(setpoints, enclosure, MPA, ACM). Before it, from 10-01, AOM 183 P had held
217.672 +/- 0.004 K, and the only movers among all 192 `TCEA_TME_EXT_THERMISTOR_*`
were +/-0.3 K swings on 45/47/51/55/57 that come and go. TCEA is the live
channel; the TCEB twins serve no samples. CAR-216 p5.14 (10-30 02:11) starts
16 min in, p5.15 (06:44) mid-ramp, p5.16-19 on the plateau; CAR-190 has no
pass after 10-29.
- **Ended 2026-11-05 04:30:31**, with the AMS bump (below): the AOM thermistor
  first responds at 05:20 and is 50 % back at 10:15, at baseline by 11-06.
- **Trend effect, first look (2026-11-01): not measurable yet.** A rate change
  is a bend, not a step (`steptest` does not apply). Extrapolating the
  pre-bump decon3 plateau (p3.84 or p3.87 .. p5.13, degree 1 or 2) to p5.19
  gives LED2 +0.47, +0.17, -0.61 or -0.15 %, depending on the choice: the
  pre-bump curve is curved, and three days out the extrapolation dominates.
  The best pre-bump fit (degree 2 from 10-26, rms 0.003-0.04 %) has LED2-6
  drifting -0.15 to +0.24 % by p5.19. Re-test with more passes, as a growth
  rate per episode (`fit_film_thickness.py` style) rather than an
  extrapolation.

**2026-11-01 23:48 -- the AMS bump (operations), +5.00 K; 11-05 04:30 -- both
bumps end.** AMS CT 16 P (`TCEA_TME_EXT_THERMISTOR_101`) leaves 267.00 K at
23:48 (no shared glitch times the command), 50 % at 11-02 02:00, 90 % at 05:45,
plateau 272.00 K; FMS CT 127 P (`_134`) follows it, +2.59 K. One command at
11-05 04:30:31, a glitch on the AOM, AMS and FMS thermistors together, ends
both bumps: AMS 50 % back at 07:00, FMS 07:45, AOM 10:15. TOMA, SM, the MPA and
everything on the WFI side stayed put; the COBA cooled 0.5 K from 11-01 midday
to 11-03, but it starts about 10 h before the AMS command and is not attributed
to it. Passes by phase: baseline CAR-190 p3.84-93 and CAR-216 p5.13; AOM ramp
p5.14-15; AOM plateau p5.16-20; AOM + AMS plateau p5.21-24; cool-down CAR-190
p3.94 (13 min after the command); baseline again p3.95-98. Every one is
DROP_2_OF_3. Profiles, the per-pass table and a README:
`$ROOT/plots/diagnostics/telescope_bumps_20261030/`; the trend over the period,
with the three commands marked: `$ROOT/digest_plots/since_20261024/`.
- **Trend effect, 2026-11-09: a hint, not a measurement.** `outliers --first
  CAR216_01063_05_013 --last CAR190_01039_03_098` flags nothing (median per-SCA
  rms 0.010 %), but its focal-plane LED1 residuals are structured: negative
  through the AMS plateau (p5.22-24: -0.06, -0.19, -0.08 %) and rising after
  (p3.95-97: +0.05, +0.13, +0.41 %), the shape a change of curvature makes.
  In LED1 every SCA passes its interference minimum between 10-28 and 11-03,
  inside the bumps, which is growth crossing a fringe and says nothing by
  itself about the rate. The test is a film-growth fit with a rate break at
  the commands (10-30 01:48, 11-01 23:48, 11-05 04:30), on the per-pass phases
  above; not yet done.

**2026-11-03, CAR-216 p5.23 -- romancal 1.0.2 -> 1.0.3.** From p5.23 on, MAST
serves the frames from cal 1.0.3 under the same roman_0077 context, reference
files and steps (`refdiff CAR216_01063_05_022 CAR216_01063_05_023`), so the
`ref_file_id` (2c8d2de83f5ace81) and the equivalence check do not change and
`run_trend.py` reports it only as a seventh configuration run. Code can move
pixels with no reference file moving, so it was measured: `steptest --first
CAR190_01039_03_084 --last CAR190_01039_03_098 --at CAR216_01063_05_023
--degree 2` reads a per-SCA achromatic step of 0.126 % rms, inside nulls of
0.028-0.264 % that the bump-era curvature widens, so only a step well above
~0.13 % is excluded; SCA18 against the rest (`relative --sca 18 --at
CAR216_01063_05_023`) reads -0.15..+0.01 % in LED2-6, nothing like the 0.76 %
its read-1 correction gave at the MA-table change. It sits inside the AOM +
AMS plateau, which confounds it with any bump effect. **Open:** the pixel test,
once MAST serves a pre-1.0.3 pass from 1.0.3 (`refdiff` now prints a NOTE
when the served software differs from the product's), and a steptest once the
bumps are further back.

**11-06 08:42 -> 12:21 and 11-07 19:14 -> 22:21 -- two ACM staircases**,
the shape since 10-29 (out to -7780, up to +2290, back; the 11-06 one also
overshoots to -3678 on the way home), each ending within 10 counts of where it
started. Between CAR-190 p3.94 | p3.95 (which starts 2 h after it) and p3.96 |
p3.97; neither pass reads as an outlier (0.008 and 0.023 %, the latter at the
window edge).

**`decon_evidence.png` now also flags epoch 40** (CAR-216 p2.5, 09-25 00:51,
the third pass down the decon2 cooldown), with 182 (the side swap) and 218
(decon3's regrowth). Its digest values are unchanged (`regress`); the
statistic's floor is computed over the whole set, ten more quiet epochs
lowered it, and an early-regrowth step now crosses it. The same kind of flag
as 218, not an unrecorded decon.

**Re-run at 252 epochs (2026-11-09).** Digests `digests_v4_11_09_26`. `regress`:
"round-off only: 15 column(s) differ by at most 6.7e-16" over the 242 earlier
epochs; one L2 equivalence class (seven configuration runs, the seventh the
romancal 1.0.3 above); the warnings are the known ones plus epoch 40 in
`decon_evidence` (above). `refresh.py check`: 25 products record the MA table,
all 9008, no switch, no mismatch, so no new CAR-216 variant. `outliers` over
p5.13 .. p3.98 flags nothing; p5.18, flagged at the window edge on 11-01, now
reads 0.006 %. Step times: `status` 7 min, `probe` (both programs) 8, `pull
--local 4` 47 (ten passes), `check` 2, `run_trend.py` 17.

**Re-run at 242 epochs (2026-11-01).** Digests `digests_v4_11_01_26`. The 236
earlier epochs agree with `digests_v4_10_30_26` to round-off (`trend_change_check.py
regress`: "round-off only: 15 column(s) differ by at most 6.7e-16"; earlier
intakes were exactly identical); no new L2
calibration class; the warnings are the known ones. `refresh.py check`'s new
readout block: 15 products record the MA table, all 9008, no switch and no
mismatch, so no new CAR-216 variant. `outliers --first CAR190_01039_03_084
--last CAR216_01063_05_019` flags p5.18 (10-31 19:48) only just: per-SCA rms
0.023 % against a 0.021 % threshold (median 0.007 %), focal-plane LED2
+0.11 %, no single SCA (SCA1 +0.06, SCA18 +0.04). It is the second-to-last
epoch, with one later neighbour, after the run's longest gap (19.7 h): re-test
at the next intake, alongside the AOM growth question. Step times: `status` 10
min, `probe` 5, `pull --local 4` 34, `check` 2, `run_trend.py` 14.

**Re-run at 236 epochs (2026-10-30).** Digests `digests_v4_10_30_26`. The 227
earlier epochs are bit-identical in all 28 float columns of every SCA digest;
no new L2 calibration class; the warnings are the known ones (141 epochs with
unrecorded L2, ACM travel 15 %, `decon_evidence` epochs 182 and 218). `outliers
--first CAR216_01063_06_005 --last CAR216_01063_05_013` flags only p6.8 and
p3.83, each carried by SCA18 alone (+0.19 / -0.15 %): the readout step seen
from either side of a leave-one-out fit. The median per-SCA rms is 0.009 %.
The nine new products are the first to record the MA table per activity
(`rcs_trend_reader.py summary` prints it). Step times: `status` 19 min, `probe`
5, telemetry 2, `pull --local 4` 41, `check` 2, `run_trend.py` 15.

**Re-run at 220 epochs (2026-10-21), the first with three decon episodes.**
Digests `digests_v4_10_21_26` (named for the day the run started). The 209
earlier epochs are bit-identical; every check in `run_trend.py` closes; the
side bridge is unchanged; all eleven new passes are `roman_0077`. The run log
lists the decon2 -> decon3 transition at epoch 217 (CAR-216 p6.1) and the
bridges do not fit across it. One new warning: `decon_evidence.png` flags
epoch 218 (p6.2) as an unlabelled chromatic step. It is decon3's regrowth: the
reset itself (216 -> 217) is a 10.9 % chromatic step, and the next three steps
shrink, 1.07, 0.48 and 0.33 %, about 0.2 %/h, as fast as at the start of decon2,
with the MPA cooling monotonically (121.5 -> 106.5 K). Checks:
- the 143 setpoint at p5.7|p5.8 (`steptest --first CAR216_01063_05_001 --last
  CAR216_01063_05_012 --at CAR216_01063_05_008 --degree 2`): per-SCA 0.0100 %
  against nulls of 0.0069-0.0210 %, so no step is seen;
- `outliers --first CAR190_01039_03_078 --last CAR216_01063_05_012`: nothing
  flagged; CAR-190 p3.81, 16 min after the slow ACM staircase, reads 0.007 %,
  so the settling check left open on 10-17 is closed;
- decon3 has four epochs, too few for `outliers` yet.

**Re-run at 209 epochs (2026-10-17), the first intake run from DATA_PULL.md.**
The 205 earlier epochs are bit-identical in `digests_v4_10_17_26`; every check
in `run_trend.py` closes; the four new passes are `roman_0077`, already mapped.
The 0077 open item is resolved: with six 0077 epochs, `steptest --first
CAR216_01063_04_001 --last CAR190_01039_03_081 --at CAR190_01039_03_076
--degree 2` reads 0.0148 % per-SCA against nulls of 0.0058-0.0182 %, and the
focal-plane LED1 step flips to +0.150 % against nulls of -0.219..+0.176 %. The
earlier -0.172 % was LED1's growth curvature at a window edge. `outliers` over
CAR-216 p5 1 .. CAR-190 p3 81 flags nothing (median per-SCA rms 0.006 %); passes
79-80 carry an LED1-only residual near +0.11 % with normal per-SCA scatter, the
film turnover's curvature at the end of the trend. Step times: `status` 13 min,
`probe` 2 min, `pull --local 4` 12 min, `check` 2 min, `run_trend.py` 14 min.

**Re-run at 205 epochs (2026-10-14).** The 201 earlier epochs are bit-identical
in every digest column of `digests_v4_10_14_26`, the side bridge is unchanged,
and every check in `run_trend.py` closes. The worst in-segment ACM travel is now
0.146 (was 0.139), from the 10-12 tilt. `trend_change_check.py outliers --first
CAR216_01063_05_001 --last CAR190_01039_03_077` flags no epoch (median per-SCA
rms 0.006 %). It does show CAR-190 p3.76's focal-plane LED1 residual at +0.134 %,
with the other LEDs within +/-0.04 %: the same LED1-only signal at the CAR-216 ->
CAR-190 switch as the 0077 open item above.

**Re-run at 201 epochs (2026-10-12), on the deployed tree.** The 193 earlier
epochs are bit-identical in every digest column of `digests_v4_10_12_26`; the
side bridge and its errors are unchanged (every new pass is outside the scan
windows); all 12 epochs from CAR-216 p4 pass 4 on are `roman_0076`, so no new
calibration class. On the B side, `trend_change_check.py steptest --first
CAR216_01063_04_001 --last CAR216_01063_05_005 --degree 2` reads 0.0048 % at
p4.8|p4.9 (the ACM staircase) and 0.0071 % at p4.10|p5.1 (the plan boundary),
inside the null range 0.0020-0.0075 %, and `outliers` flags no epoch.
`run_trend.py` took 20 min on the NFS mount, against ~5 on `/data`.

**Re-run at 188, then 189 epochs (2026-10-09), then 193 (2026-10-10).** Neither CAR-216 p4 3 nor p4 4-7 changed the side bridge; they sit outside every scan window. The 189 earlier epochs are bit-identical in the 193-epoch digests:
- The 185 shared epochs are bit-identical in every digest column.
- The side bridge values are unchanged, since the +/-50 h window ends before
  pass 75.
- Its systematic grew, LED1 +/-0.00026 -> +/-0.00131. The +/-75 h scan choices now
  reach the later B passes, and that admitted the 1-dof linear +/-25 h choice to
  the systematic. The degree-2 +/-75 h fit, which sees 6 B epochs, reads LED1
  0.89305, so the new data agree with the step.
- The 185-epoch card, solution and digests are kept in
  `rcs_trend_v4/previous_185epoch/`.

## Label decisions

| date | rows | decision | evidence |
|---|---|---|---|
| 2026-09-28 | CAR-190 p2 1-37 decon1, 38-42 decon2; CAR-216 all decon2 | hand-maintained list (`INITIAL_RANGES`) | decon schedule |
| 2026-10-03 | CAR-190 p2 43-46, p3 47-52 added as decon2 | survey default, unchecked | -- |
| 2026-10-09 | CAR-190 p2 43-46, p3 47-52 | **decon2 confirmed** | MPA 89.50-90.77 K at all 78 epochs from 09-26 on, the cooldown tail and then the plateau, never rising. A decon in any gap would put the next pass near 124 K, as at CAR-216 p2 pass 1 |
| 2026-10-09 | CAR-190 p3 53-57 added as decon2 / A | confirmed | LED map `612345`, pedestals and PD ratio unchanged; MPA 89.5 K |
| 2026-10-09 | CAR-190 p3 71-74 added as decon2 / **B** (`--relabel`) | confirmed | LED map `132465` and the three PD witnesses, above |
| 2026-10-09 | the 177 earlier rows, side left blank | kept as assumed A | LED map `612345` on all 176 products; re-staging them as `cli` would change provenance and no number |
| 2026-10-09 | CAR-190 p3 75 added as decon2 / B (`refresh.py label`) | confirmed | LED map `132465`; PD2 pedestal 114.448 mV and PD1 113.113 mV, the side-B values; MPA 89.53 K |
| 2026-10-09 | CAR-216 p4 1-2 added as decon2 / B | confirmed | LED map `132465`; PD2 114.449 / 114.448 mV, PD1 113.113 / 113.112 mV; MPA 89.56 / 89.55 K. CAR-216 has so far followed a decon, so a new plan suggested one; the temperature says not, so it continues decon2 |
| 2026-10-09 | CAR-216 p4 3 added as decon2 / B | confirmed | LED map `132465`; PD2 114.448 mV, PD1 113.113 mV; MPA 89.54 K. L1 only at 17:00, complete (180 L2) by 18:30 |
| 2026-10-10 | CAR-216 p4 4-7 added as decon2 / B | confirmed | LED map `132465`; PD2 114.447-114.448 mV, PD1 113.111-113.112 mV; MPA 89.54-89.56 K. Plan 4 is the enclosure +1 degree test (operations, 2026-10-10); that is a timeline note, not a label |
| 2026-10-10 | CAR-190 p2 13 | unchanged (decon1 / A) | just after a WFI power cycle (operations); a one-pass outlier, see the timeline. No label exists for it, and the pass stays in the trend |
| 2026-10-12 | CAR-216 4:8-10,5:1-5 added as decon2 / B (one `refresh.py label` across the plan boundary) | confirmed by the operations team and by `probe` | LED map `132465` on all eight; PD2 pedestal 114.445-114.447 mV, PD1 113.111-113.112 mV, the side-B values; MPA 89.54-89.58 K, no warm pass |
| 2026-10-14 | CAR-216 4:11,5:6 and CAR-190 3:76-77 added as decon2 / B | confirmed by `probe` (the operations team for CAR-216 plans 4-5) | LED map `132465` on all four; PD2 pedestal 114.443-114.445 mV, PD1 113.110-113.112 mV; MPA 89.54 K, no warm pass |
| 2026-10-17 | CAR-190 3:78-81 added as decon2 / B | applied as `probe` proposed; not yet confirmed against the operations record | LED map `132465` on all four; PD2 pedestal 114.444 mV, PD1 113.111 mV; MPA 89.54-89.55 K, no warm pass |
| 2026-10-21 | CAR-190 3:82, CAR-216 5:7-12 added as decon2 / B; CAR-216 6:1-4 as **decon3** / B | decon3 from the operations team; the rest as `probe` proposed | LED map `132465` on all eleven, PD2 114.439-114.443 mV, PD1 113.105-113.110 mV; MPA 89.58-89.62 K through p5.12, then 121.5 K at p6.1 (the first warm pass) down to 94.7 K at p6.4 |
| 2026-10-25 | CAR-216 6:5-8 and CAR-190 3:83-85 added as decon3 / B | as `probe` proposed; decon3 from the operations record | LED map `132465` on all seven; PD2 114.438-114.440 mV, PD1 113.105-113.107 mV; MPA 92.43 K at p6.5 falling to 89.54 K at p6.8, then 89.53-89.56 K for CAR-190 83-85, no warm pass |
| 2026-10-30 | CAR-190 3:86-93 and CAR-216 5:13 added as decon3 / B | as `probe` proposed | LED map `132465` on all nine; PD2 114.436-114.438 mV, PD1 113.103-113.106 mV; MPA 89.53-89.56 K, no warm pass. CAR-216 5:13 is plan 5 resuming inside decon3, labelled by time, not by plan |
| 2026-11-01 | CAR-216 5:14-19 added as decon3 / B | as `probe` proposed | LED map `132465` on all six; PD2 114.436-114.437 mV, PD1 113.103-113.104 mV; MPA 89.53-89.56 K, no warm pass |
| 2026-11-09 | CAR-216 5:20-24 and CAR-190 3:94-98 added as decon3 / B | as `probe` proposed, both programs in one call | LED map `132465` on all ten; PD2 114.435-114.437 mV, PD1 113.102-113.104 mV; MPA 89.53-89.57 K, no warm pass |

## Data trees

| tree | what it is |
|---|---|
| `/data/eswitzer/rcs_trend` | legacy mosaics; the bit-exact regression target (`--stage legacy`) |
| `/data/eswitzer/rcs_trend_v2` | 176 epochs, MAST L2 with mixed photom families |
| `/data/eswitzer/rcs_trend_v3` | 176 epochs, CAR-190 p2 1-37 from the local L2 reprocessing; card `rcs_reference_card_v3.ecsv`. Production through 2026-10-08, left untouched since |
| `/mnt/smdc-rom-com-ops/rrn-ops/activities/car-190-rcs-spectro-trending/rcs_trend_v4` | **the deployed working tree** (`rcs_trend_config.TREND_ROOT`) since 2026-10-12, on the shared mount. Seeded with `batch/refresh.py seed` from `/data/eswitzer/rcs_trend_v4` (1043 files, 9.63 GB, every size verified; `SEEDED_FROM.txt`), then extended in place. From here on it also holds the digests (`digests/`) and figures (`digest_plots/`, `plots/`) |
| `/data/eswitzer/rcs_trend_v4` | **the working tree until 2026-10-12**, frozen since as the seed source (193 epochs). Seeded 2026-10-09 from v3's `h5/` and `stage/plans/` (real copies), plus the 9 new passes: 185 epochs, the first set spanning the side swap. 189 from 2026-10-09 (pass 75, CAR-216 p4 1-3), 193 from 2026-10-10 (p4 4-7). The 185-epoch card, solution and digests are in `previous_185epoch/`, and the 189-epoch card and solution in `previous_189epoch/` (its digests are `digests/digests_v4_10_09_26`). `cal/` is schema 2 (nothing applied, every step recorded); `rcs_reference_card.ecsv` (per-side PD), `rcs_bridge_solution.ecsv`, `tempgain_model.ecsv` (the v4 gain fit), `digests_pass1/` (`run_trend.py`'s intermediate). Digests: `digests/digests_v4_10_10_26` |
| `rcs_trend_batch{,_run1}` | the 32-way overload casualties; 79 of 91 products hold 1-6 SCAs. Do not use |
