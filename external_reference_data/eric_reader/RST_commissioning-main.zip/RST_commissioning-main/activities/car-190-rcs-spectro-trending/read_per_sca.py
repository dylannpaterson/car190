"""
Readers for the two per-SCA forms of the same TVAC RCS chromatic-stability run.

Case 2  romancal L2   ``*_cal.asdf``      float32 4088x4088, electrons, calibrated
Case 3  quicklook     ``*_slope.fits.fz`` float64 4096x4096, e/s, uncalibrated

Both embed the full housekeeping telemetry as a single long string under the key
``hdf5_telemetry``, formatted ``p@KEY, VALUE, p@KEY, VALUE, ...`` with roughly
2500 keys -- in the SCI-extension header for quicklook, in the ASDF ``meta``
tree for romancal. That blob is what lets us rebuild the telemetry CSV that
``compile_rcs_trend.py`` expects, even though the original CSV lives on an
unmounted filesystem.

Note on FITS parsing: the quicklook SCI header contains a keyword literally
named ``END_TIME``. Any hand-rolled header parser that ends on
``card.startswith("END")`` truncates at card 59 of 2042 and silently drops the
telemetry. Use astropy, as we do here.
"""
import glob
import os
import re

import numpy as np
import pandas as pd

# Telemetry mnemonics that compile_rcs_trend.process_trending_run reads out of
# the CSV. Everything here is a straight passthrough from the embedded blob;
# the +273.15 conversions happen downstream in that script, not here.
HK_COLUMNS = [
    "WFI_COBA_WTSC10P_K",
    "WFI_MCE_SRCS_SPHERE_T",
    "WFI_MCE_SRCS_BOARD_T",
    "WFI_MCU_A_MPA_CSENS_FPSSEN_K",
    "WFI_MCU_B_MPA_CSENS_FPSSEN_K",
    "WFI_MCE_LVDT_ACM_1",
    "WFI_MCE_LVDT_ACM_2",
    "WFI_MCE_LVDT_ACM_3",
    "WFI_MCE_LVDT_ACM_4",
    "WFI_MCE_LVDT_ACM_5",
    "WFI_MCE_LVDT_ACM_6",
    "WFI_MCE_SRCS_PD1_V",
    "WFI_MCE_SRCS_PD2_V",
    "WFI_MCE_SRCS_BANK1_LED_V",
    "WFI_MCE_SRCS_BANK2_LED_V",
]

LED_SELECT_COLUMNS = [f"WFI_MCE_SRCS_BANK2SEL_LED{n}" for n in range(1, 7)]
LED_SELECT_COLUMNS_B1 = [f"WFI_MCE_SRCS_BANK1SEL_LED{n}" for n in range(1, 7)]

VISIT_ID_RE = re.compile(r"(\d{19})")

# Activity -> approximate LED wavelength for this OTP. Read out of the romancal
# products' groundtest.led_bank2_approx_wlen; the quicklook headers omit it
# entirely, so this serves as the fallback there. Activity 1 is the dark
# reference and carries the -99 sentinel in the files.
ACTIVITY_WAVELENGTH_NM = {1: np.nan, 2: 625.0, 3: 880.0, 4: 1070.0,
                          5: 1300.0, 6: 1550.0, 7: 1750.0}


def parse_telemetry(blob):
    """Unpack the ``p@KEY, VALUE, ...`` housekeeping blob into a dict.

    Values are left as strings; callers coerce. Keys not prefixed ``p@`` are
    positional filler in the original dump and are skipped.
    """
    tokens = [tok.strip() for tok in str(blob).split(",")]
    telem = {}
    index = 0
    while index < len(tokens) - 1:
        if tokens[index].startswith("p@"):
            telem[tokens[index][2:]] = tokens[index + 1]
            index += 2
        else:
            index += 1

    return telem


def _as_float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return np.nan


def _as_time_string(value):
    """Normalise a time field to an ISO string.

    romancal stores exposure times as an ASDF time object that round-trips to
    ``{'base_format': 'datetime', 'value': '2025-10-03T06:07:40.714'}``;
    quicklook stores a plain string. Both end up as the bare timestamp.
    """
    if isinstance(value, dict) and "value" in value:
        value = value["value"]
    value = getattr(value, "isot", value)

    return str(value).strip()


def _unwrap_quantity(value):
    """Pull a plain scalar out of an ASDF quantity-like ``{unit, value}`` dict."""
    if isinstance(value, dict) and "value" in value:
        value = value["value"]
    value = getattr(value, "value", value)
    array = np.asarray(value).ravel()

    return float(array[0]) if array.size else np.nan


def _ql_activity_number(header):
    """Derive the activity number when the header has no ``activity_number``.

    TVAC quicklook (``Program_00123``/OTP00775) stamps ``activity_number``
    directly. Flight quicklook (e.g. ``Program_01039``) carries no such key at
    all -- only ``LED``/``BANK``/``ACTIVE``, the same scheme ``meta.rcs.led``
    uses on flight L2 products (see ``process_rcs_trending.group_activities``
    and the README's "LED numbering" section): the dark has no LED lit, and
    LED *n* on is activity *n+1* -- ``meta.rcs.led``/this ``LED`` header is
    already a sequential activity counter, not the hardware LED id.
    """
    led = header.get("LED")
    if not header.get("ACTIVE", False) or led in (None, ""):
        return 1

    return int(led) + 1


def read_ql_sca(path, data=True, apply_dq=True):
    """Read one quicklook slope file.

    Returns ``(data, meta, telem)``; ``data`` is None when ``data=False``,
    which keeps metadata-only passes cheap since these are fpack-compressed.

    ``apply_dq`` is on by default and matters a great deal: the raw slope
    arrays reach |value| ~ 3e8, and essentially every such pixel is flagged in
    the DQ extension (128 of the 129 pixels above 1e4 in a sample frame). Left
    in, a single hot pixel dominates its whole 20x20 native superpixel once the
    mosaic is rebinned.
    """
    from astropy.io import fits

    with fits.open(path) as hdul:
        header = hdul["SCI"].header
        frame = None
        if data:
            frame = np.array(hdul["SCI"].data, dtype=np.float64)
            if apply_dq and "DQ" in hdul:
                frame[np.asarray(hdul["DQ"].data) != 0] = np.nan

    telem = parse_telemetry(header.get("hdf5_telemetry", ""))
    visit_id = str(header.get("VISIT_ID", "")).strip()
    # Only SCANUM is per-file correct; detector_id/DETECTOR/sca_number/CRVAL*
    # are all SCA01's values copied into every SCA's header, so the filename is
    # the authority and SCANUM is the cross-check.
    detector = _detector_from_name(path)
    scanum = header.get("SCANUM")
    if scanum is not None and int(scanum) != sca_number(detector):
        raise ValueError(f"{path}: SCANUM={scanum} disagrees with filename "
                         f"detector {detector}")
    activity_number = (int(header["activity_number"])
                       if "activity_number" in header
                       else _ql_activity_number(header))
    meta = {
        "activity_number": activity_number,
        "visit_id": visit_id,
        "detector": detector,
        "start_time": _as_time_string(header.get("start_time", "")),
        "end_time": _as_time_string(header.get("END_TIME", "")),
        "exposure_time": _as_float(header.get("exposure_time", np.nan)),
        "targettype": str(header.get("wfi_otp_targettype", "")).strip(),
        "observation_id": str(header.get("observation_id", "")).strip(),
        # Reconstruct the SDH path shape so extract_identifier_specific's
        # r'/(\d{19})/Science/' regex matches, exactly as it did on the CSV.
        "exp_path_done": f"/{visit_id}/Science/000000001/fits",
        "bunit": str(header.get("BUNIT", "")).strip(),
        "source_path": path,
    }

    return frame, meta, telem


def _quiet_asdf_extension_warnings():
    """Silence asdf's "extension not installed" chatter.

    The L2 files were written with ``rad``/``roman_datamodels``/``gwcs``
    extensions. We deliberately do not install those: everything needed here is
    plain arrays and a metadata mapping, and asdf reads both without the schema
    packages. It just says so about a dozen times per file.
    """
    import warnings

    try:
        from asdf.exceptions import AsdfPackageVersionWarning
    except ImportError:
        return
    warnings.filterwarnings("ignore", category=AsdfPackageVersionWarning)


def _scipa_from_tree(roman, data=True, apply_dq=True, source=""):
    """Extract ``(data, meta, telem)`` from an already-open L2 ``roman`` tree.

    Split out from :func:`read_scipa_sca` so the flight path can hand in a tree
    that arrived over the network (``MastMissions.read_product()`` returns an
    open ``AsdfFile``, never a path) without either caller having to duplicate
    the extraction. ``source`` stands in for the filename: it is used only for
    the detector fallback and for the recorded provenance, so a basename or
    an S3 URI both work.

    Every ``groundtest`` lookup here has to tolerate the branch being missing
    entirely. It is a TVAC-only branch: flight products carry no
    ``activity_number``, no ``wfi_otp_targettype``, no ``led_bank2_approx_wlen``
    and no ``hdf5_telemetry``, so those degrade to sentinels (activity ``-1``,
    empty strings, an empty telemetry dict) rather than raising. The flight
    pipeline fills the same fields from MAST metadata and the EDP instead.
    """
    meta_tree = roman["meta"]
    frame = None
    if data:
        frame = np.array(roman["data"], dtype=np.float64)
        if apply_dq and "dq" in roman:
            frame[np.asarray(roman["dq"]) != 0] = np.nan

    # `or {}` and not just a .get default: a present-but-null key returns None,
    # which .get's default does not cover.
    ground = meta_tree.get("groundtest", {}) or {}
    telem = parse_telemetry(meta_tree.get("hdf5_telemetry", ""))
    exposure = meta_tree.get("exposure", {}) or {}
    filepath = str(ground.get("filepath_level_pnt5", ""))
    visit_match = VISIT_ID_RE.search(filepath)
    meta = {
        "activity_number": int(ground.get("activity_number", -1)),
        "visit_id": visit_match.group(1) if visit_match else "",
        "detector": str(meta_tree.get("instrument", {}).get(
            "detector", _detector_from_name(source))),
        "start_time": _as_time_string(exposure.get("start_time", "")),
        "end_time": _as_time_string(exposure.get("end_time", "")),
        "exposure_time": _as_float(exposure.get("exposure_time", np.nan)),
        "targettype": str(ground.get("wfi_otp_targettype", "")).strip(),
        "observation_id": str(
            (meta_tree.get("observation", {}) or {}).get("observation_id", "")),
        # On TVAC products this field is already literally
        # '.../<19 digits>/Science/...', which is what the compiler's regex
        # wants. On flight products it is empty and the caller composes it.
        "exp_path_done": filepath,
        "bunit": "electrons",
        "source_path": source,
    }
    if "led_bank2_approx_wlen" in ground:
        meta["led_bank2_approx_wlen"] = _unwrap_quantity(
            ground["led_bank2_approx_wlen"])

    return frame, meta, telem


def read_scipa_sca(path, data=True, apply_dq=True):
    """Read one romancal L2 ``_cal.asdf`` product from a local path.

    The science array is 4088x4088 (reference pixels trimmed); padding back to
    4096 is :func:`form_mpa_mosaic.pad_to_4096`. DQ is applied
    on the same terms as the quicklook reader so the two cases are masked
    symmetrically.
    """
    import asdf

    _quiet_asdf_extension_warnings()
    with asdf.open(path, lazy_load=True, memmap=False) as af:
        return _scipa_from_tree(af.tree["roman"], data=data,
                                apply_dq=apply_dq, source=path)


def read_streamed_l2(af, data=True, apply_dq=True, source=""):
    """Read one L2 product from an open, streamed ``AsdfFile``.

    The flight entry point, for the object ``MastMissions.read_product()``
    hands back and nothing is written to disk. Beyond
    :func:`_scipa_from_tree` this adds the fields that only exist on flight
    products:

    * ``led`` -- ``meta.rcs.led``, the flight-era home for LED identity, as a
      *string*. This is the primary discriminator between the dark reference and
      the six LED activities now that ``groundtest.activity_number`` is gone.
    * ``observation_fields`` -- whatever of ``program``/``execution_plan``/
      ``pass``/``segment``/``observation``/``visit``/``exposure`` the
      ``meta.observation`` branch actually carries uncoerced. Collected
      rather than required because the authoritative copy of
      these is the MAST query result. This provide a cross-check.

    ``lazy_load`` here because the file is already open, so
    the arrays are from :func:`_scipa_from_tree`'s ``np.array`` and
    the caller should bin and drop them one SCA at a time.
    """
    _quiet_asdf_extension_warnings()
    roman = af.tree["roman"]
    frame, meta, telem = _scipa_from_tree(roman, data=data, apply_dq=apply_dq,
                                          source=source)

    meta_tree = roman["meta"]
    rcs = meta_tree.get("rcs", {}) or {}
    meta["led"] = str(rcs.get("led", "")).strip()

    observation = meta_tree.get("observation", {}) or {}
    meta["observation_fields"] = {
        key: observation[key] for key in
        ("program", "execution_plan", "pass", "segment", "observation", "visit",
         "exposure", "visit_id", "exposure_id")
        if key in observation}

    return frame, meta, telem


def _detector_from_name(path):
    """Pull ``WFInn`` out of a filename, in either case convention."""
    match = re.search(r"wfi(\d{2})", os.path.basename(path), re.I)

    return f"WFI{match.group(1)}" if match else ""


def sca_number(detector):
    """``'WFI07'`` -> ``7``. MPA position and WFI detector number coincide."""
    match = re.search(r"(\d{1,2})$", str(detector))
    if not match:
        raise ValueError(f"cannot parse SCA number from {detector!r}")

    return int(match.group(1))


READERS = {"ql": read_ql_sca, "scipa": read_scipa_sca}


def _visit_id_pass(visit_id):
    """Pull the 3-digit pass field out of a 19-digit Visit Identifier.

    ``None`` for anything that isn't the flight 19-digit
    ``PPPPPCCAAASSSOOOVVV`` form (TVAC's quicklook visit ids are a different,
    longer scheme and have no pass field at all -- and never repeat an
    activity, so they never need this).
    """
    return visit_id[7:10] if len(visit_id) == 19 and visit_id.isdigit() else None


def discover_activities(root, kind, pass_number=None):
    """Map out the per-SCA files for one run, grouped by activity.

    Activity numbers come from file metadata rather than from path parsing, so
    the two very different directory conventions need no special-casing.

    Live flight quicklook ingest can land more than one directory for the
    same activity: a partial landing gets superseded by a complete relanding
    of the same visit, and the whole seven-activity sequence repeats every
    pass (see the README's "Passes" section). Both collapse to one directory
    per activity here: relandings of the *same* visit_id keep whichever
    directory has the most SCA files, and a genuine spread across more than
    one pass requires ``pass_number`` (a 1-based int, or the zero-padded
    3-digit string) to pick one -- there is no way to guess which pass the
    caller wants.

    Returns
    -------
    dict
        ``{activity_number: {"frames": {sca: path}, "meta": ..., "telem": ...}}``
        where meta/telem are taken from the lowest-numbered SCA present.
    """
    if kind == "ql":
        paths = sorted(glob.glob(os.path.join(root, "*_slope_SCAs",
                                              "*_slope.fits.fz")))
    elif kind == "scipa":
        paths = sorted(glob.glob(os.path.join(root, "*", "*_cal.asdf")))
    else:
        raise ValueError(f"unknown kind {kind!r}")

    if not paths:
        raise FileNotFoundError(f"no {kind} per-SCA files under {root}")

    if pass_number is not None:
        pass_number = f"{int(pass_number):03d}"

    reader = READERS[kind]
    # One metadata read per activity is enough; group cheaply first by the
    # directory the files sit in, which is one directory per activity landing
    # in both conventions, then confirm against the metadata.
    by_dir = {}
    for path in paths:
        by_dir.setdefault(os.path.dirname(path), []).append(path)

    candidates = {}
    for directory, members in sorted(by_dir.items()):
        members = sorted(members)
        _, meta, telem = reader(members[0], data=False)
        activity = meta["activity_number"]
        candidates.setdefault(activity, []).append((directory, members, meta, telem))

    activities = {}
    for activity, entries in sorted(candidates.items()):
        if pass_number is not None:
            filtered = [e for e in entries
                       if _visit_id_pass(e[2]["visit_id"]) in (pass_number, None)]
            if filtered:
                entries = filtered

        passes = {_visit_id_pass(entry[2]["visit_id"]) for entry in entries}
        passes.discard(None)
        if len(passes) > 1:
            raise ValueError(
                f"activity {activity} spans multiple passes {sorted(passes)}; "
                "pass pass_number= to discover_activities to pick one")

        directory, members, meta, telem = max(entries, key=lambda e: len(e[1]))
        frames = {}
        for path in members:
            frames[sca_number(_detector_from_name(path))] = path
        activities[activity] = {"frames": frames, "meta": meta, "telem": telem,
                                "directory": directory}

    return activities


def build_activity_table(activities, bank="BANK2"):
    """Build the telemetry table ``compile_rcs_trend.py`` reads as its CSV.

    One row per activity, ordered by activity number, so that row 0 is the dark
    reference and rows 1-6 are the LED sweep -- which is the ordering
    ``process_trending_run`` assumes when it names arrays ``LED1``..``LED6`` by
    *activity index*. Provenance columns are appended past the mnemonics the
    script needs; it ignores extras.
    """
    led_columns = LED_SELECT_COLUMNS if bank == "BANK2" else LED_SELECT_COLUMNS_B1

    rows = []
    for activity in sorted(activities):
        entry = activities[activity]
        meta, telem = entry["meta"], entry["telem"]
        row = {
            "SC Timestamp": meta["start_time"],
            "exp_path_done": meta["exp_path_done"],
        }
        for column in HK_COLUMNS:
            row[column] = _as_float(telem.get(column, np.nan))
        for column in led_columns:
            row[column] = str(telem.get(column, "DIS")).strip()

        # Prefer the wavelength the file states; fall back to the run's known
        # activity->wavelength map for quicklook, which omits the field.
        file_wlen = meta.get("led_bank2_approx_wlen", np.nan)
        if np.isfinite(file_wlen) and file_wlen > 0:
            wavelength, wavelength_source = file_wlen, "file"
        else:
            wavelength = ACTIVITY_WAVELENGTH_NM.get(activity, np.nan)
            wavelength_source = "activity_map"

        row.update({
            "activity_number": activity,
            "visit_id": meta["visit_id"],
            "detector_ref": meta["detector"],
            "targettype": meta["targettype"],
            "exposure_time": meta["exposure_time"],
            "led_bank2_approx_wlen": file_wlen,
            "wavelength_nm": wavelength,
            "wavelength_source": wavelength_source,
            "n_sca": len(entry["frames"]),
            "scas_present": ",".join(str(s) for s in sorted(entry["frames"])),
            "source_dir": entry["directory"],
        })
        rows.append(row)

    return pd.DataFrame(rows)


def enabled_led(row, bank="BANK2"):
    """Which hardware LED a telemetry row has enabled, or ``'DRK'`` for none.

    Worth keeping separate from the array naming: the hardware enable order is
    *not* the activity order in this run (activity 2 lights hardware LED6), so
    ``led_arrays/LED1`` in the output h5 is an activity index, not an LED id.
    """
    columns = LED_SELECT_COLUMNS if bank == "BANK2" else LED_SELECT_COLUMNS_B1
    enabled = [c.split("_")[-1] for c in columns if str(row.get(c)).strip() == "ENA"]
    if not enabled:
        return "DRK"

    return enabled[0] if len(enabled) == 1 else "MULTIPLE"


if __name__ == "__main__":
    ROOTS = {
        "scipa": "/mnt/roman-science-internal/romancal_l2_outputs/tvac/scipa/"
                 "ChromaticStability/OTP00775_RCSEChrmStbA_SCIPAc_R17",
        "ql": "/mnt/roman-science-east-2/ql_output/Program_00123",
    }
    for kind, root in ROOTS.items():
        print(f"\n===== {kind} =====")
        acts = discover_activities(root, kind)
        table = build_activity_table(acts)
        table["hw_led"] = table.apply(enabled_led, axis=1)
        print(table[["activity_number", "visit_id", "SC Timestamp", "hw_led",
                     "led_bank2_approx_wlen", "n_sca", "exposure_time"]]
              .to_string(index=False))
