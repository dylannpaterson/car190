"""Per-SCA array stacks, and the mosaic as a view onto them.

The RCS trend products used to be stored as an MPA mosaic, which forced every
downstream consumer to recover per-SCA numbers by re-deriving SCA footprints on
the mosaic grid (:func:`sca_footprint_masks`). That is both indirect and, at the
historical net binning of 20 native pixels per side, wrong at the edges:
``4096 / 20 = 204.8``, so each SCA block was a ragged 204 or 205 superpixels and
the superpixels at the block boundaries mixed two detectors, or mixed a detector
with the inter-SCA NaN gap.

The native product is now a stack, ``(18, n, n)`` indexed by ``sca - 1``, at a
bin factor that divides 4096 (16 -> 256x256 per SCA). Statistics come from
:func:`per_sca_reduce` on the stack. The mosaic survives only as a display view
built by :func:`stack_to_mosaic`.

Standing rule: never store a mosaic, and never compute a statistic by iterating
mosaic pixels.
"""
import astropy.units as u
import numpy as np
from astropy.table import QTable
from matplotlib.path import Path as MplPath
from pathlib import Path

import form_mpa_mosaic as fm
from rcs_trend_config import N_SCAS, SCA_NAMES, SCA_PIX, validate_bin

_REPO_ROOT = Path(__file__).resolve().parents[2]
SCA_GEOMETRY_FILE = _REPO_ROOT / "config" / "WFI_SCA_physical_centers.ecsv"

__all__ = [
    "SCA_GEOMETRY_FILE", "coverage_fraction", "median_per_sca",
    "mosaic_to_stack", "per_sca_reduce", "read_sca_geometry", "sca_footprint_masks",
    "sca_index", "sca_name", "sorted_scas", "stack_coverage", "stack_to_mosaic",
    "validate_bin",
]


# ---------------------------------------------------------------------------
# SCA naming and indexing
# ---------------------------------------------------------------------------

def sca_index(sca):
    """Zero-based stack index for an SCA given as ``"SCA7"``, ``7``, or ``"7"``."""
    if isinstance(sca, str):
        number = int(sca[3:]) if sca.upper().startswith("SCA") else int(sca)
    else:
        number = int(sca)
    if not 1 <= number <= N_SCAS:
        raise ValueError(f"SCA number {number} outside 1..{N_SCAS}")
    return number - 1


def sca_name(index):
    """``"SCA<n>"`` for a zero-based stack index."""
    if not 0 <= int(index) < N_SCAS:
        raise ValueError(f"stack index {index} outside 0..{N_SCAS - 1}")
    return f"SCA{int(index) + 1}"


def sorted_scas(keys):
    """SCA names in numeric order."""
    return sorted(keys, key=lambda s: int(s[3:]))


# ---------------------------------------------------------------------------
# Reductions on a per-SCA stack
# ---------------------------------------------------------------------------

def per_sca_reduce(stack, reducer=np.nanmedian, as_dict=True):
    """Reduce each SCA plane of a ``(18, n, n)`` stack to one number.

    This replaces :func:`median_per_sca` for per-SCA products: there are no
    footprints to derive and no straddling superpixels to inset, because each
    plane already holds exactly one detector. An all-NaN plane (an SCA missing
    from this epoch) reduces to NaN without a warning.
    """
    stack = np.asarray(stack)
    if stack.ndim != 3:
        raise ValueError(f"expected a (n_sca, n, n) stack, got {stack.shape}")

    values = np.full(stack.shape[0], np.nan)
    for ind in range(stack.shape[0]):
        plane = stack[ind]
        if np.isfinite(plane).any():
            with np.errstate(invalid="ignore"):
                values[ind] = float(reducer(plane))

    if not as_dict:
        return values
    return {sca_name(ind): float(values[ind]) for ind in range(len(values))}


def stack_coverage(stack):
    """Boolean per-SCA presence: does this plane hold any finite pixel."""
    stack = np.asarray(stack)
    return np.array([bool(np.isfinite(stack[i]).any())
                     for i in range(stack.shape[0])])


def coverage_fraction(stack):
    """Fraction of finite pixels in each SCA plane."""
    stack = np.asarray(stack)
    n_pix = int(np.prod(stack.shape[1:]))
    return np.array([np.isfinite(stack[i]).sum() / n_pix
                     for i in range(stack.shape[0])], dtype=np.float32)


# ---------------------------------------------------------------------------
# Mosaic view
# ---------------------------------------------------------------------------

def stack_to_mosaic(stack, bin_factor, geom=None, orientation=None,
                    dtype=np.float32):
    """Lay a per-SCA stack onto the MPA mosaic grid, for display only.

    ``bin_factor`` must divide 4096, which is what makes every SCA block land
    on exact superpixel boundaries -- so unlike the legacy r=20 mosaic there is
    nothing to inset and no footprint mask is needed to get back out.
    """
    stack = np.asarray(stack)
    bin_factor = validate_bin(bin_factor)
    expected = SCA_PIX // bin_factor
    if stack.ndim != 3 or stack.shape[1:] != (expected, expected):
        raise ValueError(f"stack {stack.shape} does not match bin factor "
                         f"{bin_factor} (expected (n_sca, {expected}, {expected}))")

    orientation = fm.DEFAULT_ORIENTATION if orientation is None else orientation
    frames = {ind + 1: stack[ind] for ind in range(stack.shape[0])
              if np.isfinite(stack[ind]).any()}
    return fm.build_mosaic(frames, r=bin_factor, geom=geom, dtype=dtype,
                           orientation=orientation, prebinned=True)


def mosaic_to_stack(mosaic, bin_factor, geom=None, dtype=np.float32):
    """Exact inverse of :func:`stack_to_mosaic` for a block-aligned bin factor.

    Only valid when ``bin_factor`` divides 4096 and the mosaic was built at the
    default orientation. A legacy r=20 trend mosaic cannot be inverted this way
    -- its SCA blocks straddle superpixels -- so use
    :func:`sca_footprint_masks` with an inset for those.
    """
    mosaic = np.asarray(mosaic)
    bin_factor = validate_bin(bin_factor)
    if mosaic.shape != fm.mosaic_shape(bin_factor):
        raise ValueError(f"mosaic {mosaic.shape} is not the r={bin_factor} grid "
                         f"{fm.mosaic_shape(bin_factor)}; a legacy r=20 trend "
                         "mosaic needs sca_footprint_masks instead")

    geom = fm.load_geometry() if geom is None else geom
    side = SCA_PIX // bin_factor
    stack = np.full((N_SCAS, side, side), np.nan, dtype=dtype)
    for sca in range(1, N_SCAS + 1):
        r1, r2, c1, c2 = fm.sca_placement(sca, bin_factor, geom)
        block = mosaic[r1:r2, c1:c2]
        stack[sca - 1] = fm.orient_frame(block, geom[sca][2],
                                         fm.DEFAULT_ORIENTATION)
    return stack


def stack_to_mosaic_grid(stacks, bin_factor, **kwargs):
    """``{label: stack}`` -> ``{label: mosaic}``, for the 6-LED panel figures."""
    return {label: stack_to_mosaic(stack, bin_factor, **kwargs)
            for label, stack in stacks.items()}


# ---------------------------------------------------------------------------
# Legacy: SCA footprints on the mosaic grid
# ---------------------------------------------------------------------------

def read_sca_geometry(geometry_file=SCA_GEOMETRY_FILE):
    """SCA centers in mm, the MPA extent, and the SCA width."""
    table = QTable.read(geometry_file, format="ascii.ecsv")
    centers = {str(row["label"]): (row["x_center"].to_value(u.mm),
                                   row["y_center"].to_value(u.mm))
               for row in table}
    extent = (table.meta["extent_xlow_mm"], table.meta["extent_xhigh_mm"],
              table.meta["extent_ylow_mm"], table.meta["extent_yhigh_mm"])
    return centers, extent, table.meta["width"]


def sca_footprint_masks(mosaic_shape, geometry_file=SCA_GEOMETRY_FILE):
    """Boolean mask of the mosaic grid inside each SCA, keyed by SCA name.

    Only for legacy mosaic products. The mosaic spans the MPA extent recorded in
    the geometry file, so pixel centers map onto physical millimeters by a simple
    linspace in each axis. Masks depend only on the mosaic shape, so they are
    built once and reused for every epoch and every LED.
    """
    centers, extent, width = read_sca_geometry(geometry_file)
    half_width = width / 2.0

    x_mpa = np.linspace(extent[0], extent[1], mosaic_shape[1])
    y_mpa = np.linspace(extent[2], extent[3], mosaic_shape[0])
    xx, yy = np.meshgrid(x_mpa, y_mpa)
    points = np.column_stack((xx.ravel(), yy.ravel()))

    masks = {}
    for sca, (x_c, y_c) in centers.items():
        corners = np.array([
            [x_c - half_width, y_c - half_width],
            [x_c + half_width, y_c - half_width],
            [x_c + half_width, y_c + half_width],
            [x_c - half_width, y_c + half_width],
        ])
        masks[sca] = MplPath(corners).contains_points(points).reshape(mosaic_shape)

    missing = [name for name in SCA_NAMES if name not in masks]
    if missing:
        raise ValueError(f"{geometry_file} has no geometry for {', '.join(missing)}")
    return masks


def median_per_sca(mosaic, masks):
    """Nanmedian of ``mosaic`` inside each SCA footprint. Legacy products only.

    An all-NaN footprint is a legitimate outcome -- that SCA was not downlinked
    at this epoch, or not at the reference epoch the ratio divides by -- and
    yields NaN. numpy's RuntimeWarning for it is suppressed because it fires once
    per LED per epoch and says nothing the NaN does not.
    """
    values = {}
    for sca, mask in masks.items():
        patch = mosaic[mask]
        if not np.isfinite(patch).any():
            values[sca] = float("nan")
            continue
        values[sca] = float(np.nanmedian(patch))
    return values


# ---------------------------------------------------------------------------
# Self test
# ---------------------------------------------------------------------------

def self_test(verbose=True):
    """Checks that need no data: indexing, reductions, mosaic round trip."""
    def report(name):
        if verbose:
            print(f"  ok  {name}")

    assert sca_index("SCA7") == 6 and sca_index(7) == 6 and sca_index("7") == 6
    assert sca_name(0) == "SCA1" and sca_name(17) == "SCA18"
    for bad in ("SCA0", 0, 19):
        try:
            sca_index(bad)
            raise AssertionError(f"sca_index({bad!r}) should have raised")
        except ValueError:
            pass
    assert sorted_scas(["SCA10", "SCA2", "SCA1"]) == ["SCA1", "SCA2", "SCA10"]
    report("SCA indexing and ordering")

    rng = np.random.default_rng(7)
    side = SCA_PIX // 16
    stack = rng.normal(size=(N_SCAS, side, side)).astype(np.float32)
    stack[3] = np.nan                       # SCA4 absent this epoch
    stack[5, :10, :10] = np.nan             # partial coverage

    medians = per_sca_reduce(stack)
    assert set(medians) == set(SCA_NAMES)
    assert np.isnan(medians["SCA4"]) and np.isfinite(medians["SCA6"])
    coverage = stack_coverage(stack)
    assert coverage.sum() == N_SCAS - 1 and not coverage[3]
    fractions = coverage_fraction(stack)
    assert fractions[0] == 1.0 and 0.0 < fractions[5] < 1.0 and fractions[3] == 0.0
    report("per-SCA reductions and coverage")

    mosaic = stack_to_mosaic(stack, 16)
    assert mosaic.shape == fm.mosaic_shape(16), mosaic.shape
    back = mosaic_to_stack(mosaic, 16)
    present = np.isfinite(stack)
    assert np.allclose(back[present], stack[present]), "mosaic round trip lost data"
    assert np.all(np.isnan(back[3])), "absent SCA came back populated"
    report("mosaic round trip is exact at bin 16")

    # The reason the stack exists: 20 is not a divisor, so a per-SCA product
    # could not be laid out on it without ragged blocks.
    for good in (4, 8, 16, 32, 64):
        assert SCA_PIX % good == 0
        assert stack_to_mosaic(
            np.zeros((N_SCAS, SCA_PIX // good, SCA_PIX // good), dtype=np.float32),
            good).shape == fm.mosaic_shape(good)
    try:
        validate_bin(20)
        raise AssertionError("bin 20 should have been rejected")
    except ValueError:
        pass
    report("bin factors validated against 4096")

    if SCA_GEOMETRY_FILE.exists():
        masks = sca_footprint_masks((900, 1400))
        assert len(masks) >= N_SCAS
        assert all(masks[name].any() for name in SCA_NAMES)
        report("legacy footprint masks still build")
    elif verbose:
        print(f"  skip  footprint masks ({SCA_GEOMETRY_FILE} not found)")

    return True


if __name__ == "__main__":
    print("rcs_sca_grid self test")
    self_test()
    print("all checks passed")
