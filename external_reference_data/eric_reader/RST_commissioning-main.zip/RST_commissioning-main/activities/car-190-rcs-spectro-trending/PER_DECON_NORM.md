# Per-decon normalization: what it would take, and why it is not built

A decon removes the contaminant film from the detector surface, so each decon cycle is a
fresh film-growth episode starting from a clean surface. It is therefore tempting to gauge
the trend *per episode* — divide every epoch in an episode by that episode's first epoch, so
each episode's curve starts at 1.0 and reads as growth since its own reset.

This document records the decision not to implement that as a pipeline mode, what was
measured on the way to it, and what would have to change if someone builds it later. It is a
design record, not a how-to: the three-line post-processing recipe is in
[the recipe section](#the-post-processing-recipe) and is all most users need.

Everything numeric below was measured on `digests/digests_v3_10_06_26/` (176 epochs,
CAR-190 + CAR-216, bin 16).


## Why it is not implemented

The proposal originally had a **calibration** motivation, which turned out not to exist.

The trend's 176 epochs come from two L2 sources: an aux reprocessing on
`/mnt/roman-s3-romcom/activities/CAR190/` supplies the 35 `decon1` epochs, and MAST supplies
the 141 `decon2` epochs. The break is exactly clean — `decon_cycle` and `l2_source` both
change at the single epoch index 35 (0-based), cross-tabbing as `decon1 × aux : 35` and
`decon2 × mast : 141` — so the proposal was viable. The worry was that the two sources were
differently calibrated, specifically that the aux tree skipped the flat field while MAST
applied it. Under that worry, dividing MAST epochs by an aux t=0 reference would leave a
per-pixel flat ratio in every number, and re-gauging each episode on its own source would
have been a *correction*, not a view.

**Neither source applies a flat field.** Both report `cal_step_flat_field = SKIPPED` with
`ref_file.flat = INCOMPLETE`; the WFI flat reference is not delivered in CRDS at all. That
was confirmed independently of the metadata on pass 1, the one pass that exists both ways: a
flat is a per-pixel multiplicative map, so a differential one cannot hide in a pixel ratio,
and 46 M usable pixels across SCA 1/9/18 give a median ratio of `1.00000000`, rms `0.0000 %`,
**100.000 % of pixels within 1e-6**, with a 64×64 block-median rms of `0.0000 %`. The
homogeneity guard agrees from the metadata side: all 176 epochs are one calibration
equivalence class (`unity-photom`), which is what `digest_plots/calibration_timeline.png`
draws and what `l2_calibration_audit.ecsv` records per epoch.

So dividing MAST epochs by the aux t=0 reference is sound, and the calibration motivation is
gone. What remains is the **physical** motivation — a decon really does reset the film, so
growth really can be measured from each reset — and a physical re-gauge is a *change of
origin*, i.e. a view. A view that a user can construct in one line should not be a pipeline
mode that doubles the number of digest sets in circulation and gives every downstream
consumer a second convention to branch on.

The decision is therefore: **ship the episode bounds, not the division.** The digests now
carry everything needed to do it safely (next section); the division stays the user's.


## The post-processing recipe

```python
from astropy.table import Table
import numpy as np

t = Table.read("digests/digests_v3_10_06_26/time_series_SCA1.ecsv")
leds = [f"LED{i}" for i in range(1, 7)]

# 1-based inclusive pairs, straight out of the digest -- do NOT re-derive these
for first, last in t.meta["decon_episode_bounds"]:
    block = slice(first - 1, last)          # to 0-based, end-exclusive
    for led in leds:
        t[led][block] = t[led][block] / t[led][first - 1]
```

Use `t["decon_time_hours"]` as the x-axis: it is already hours since each epoch's own
episode began, zero at every episode's first epoch. `t["time_hours"]` is deliberately left
on the global reference epoch (see
[time_hours must not be re-origined](#time_hours-must-not-be-re-origined)).

### The trap: group by contiguous runs, not by label identity

**Do not `groupby("decon_cycle")`.** A label sequence `decon1, decon2, decon1` is **three**
episodes, not two. The third is not the first resumed — the film was removed in between — and
a groupby would gauge those epochs against a reference hundreds of hours and one decon in
their past, producing a curve that looks like continued growth across a reset.

`decon_episode_bounds` is already contiguous-run semantics, which is why the recipe above
reads it rather than grouping. `decon_episode_labels` lists the label of each episode *by
position*, so a recurring label simply appears twice; `decon_reference_epochs` is likewise
positional, for the same reason — a `label → run_label` dict is lossy the moment a label
recurs. The current set has two episodes with distinct labels, so the two groupings agree
here — which is exactly why getting this wrong would go unnoticed.

The same bounds come from `rcs_acm.decon_episodes(labels)` if you are working from code
rather than from a digest. Note that `rcs_acm._same_decon_episode` answers a **different**
question with a **different** rule: it governs whether a bridge fit window may span two
epochs, and it treats an *unlabelled* epoch as usable in whichever episode it adjoins,
whereas `decon_episodes` makes an unlabelled run its own episode (there is no defensible
first epoch by which to divide a block of unknown provenance). Both answers are pinned
side by side in `rcs_acm.self_test()` so the asymmetry is not "simplified" away.


## What the view buys, stated asymmetrically

The benefit is that an episode's internal numbers stop depending on bridge steps that were
measured outside it. It is **not symmetric between episodes**, and a plan that assumes it is
will overstate the gain.

`bridge_factors` composes `factor[segment j] = 1 / ∏_{k<j} step_k`, so re-gauging episode *e*
on its first epoch *i₀* cancels every step below `seg(i₀)` and retains those whose segment
index lies in `[seg(i₀), seg(i))`. The surviving set is the boundaries interior to the
episode's **segment span**, not its epoch span — and the two differ when an episode ends a
few epochs after an ACM move.

On this dataset the ACM segment changes at 0-based epochs `14, 34, 164` (so
`acm_move_epoch_indices = [15, 35, 165]`, which is 1-based) while the decon label changes at
0-based epoch `35`:

| episode | 0-based epochs | segments spanned | boundaries retained after re-gauging |
|---|---|---|---|
| `decon1` | 0 – 34 | 0, 1, 2 | **1 and 2** |
| `decon2` | 35 – 175 | 2, 3 | **3 only** |

- `decon2` begins at epoch 35, which is already inside segment 2, so re-gauging on it cancels
  boundaries 1 *and* 2. The unmeasured boundary-2 multiplier (see below) genuinely drops out
  of that 141-epoch block — this is the real win.
- `decon1` ends at epoch 34, which is *already segment 2*: the ACM moved one epoch before the
  decon transition. So `decon1` retains both boundary 1 and boundary 2, the latter carried by
  that single last epoch. Re-gauging buys it nothing.

Reproduced from the shipped digests (`time_series_SCA1.ecsv`):

```
decon1 re-gauged factor by segment: {0: 1.0, 1: 1.038517, 2: 1.047511}
   segment 1 retains product of steps [1] = 1.038517
   segment 2 retains product of steps [1, 2] = 1.047511
decon2 re-gauged factor by segment: {2: 1.0, 3: 0.990783}
   segment 3 retains product of steps [3] = 0.990783
```

Boundary 2 is the one worth shedding: it is the only boundary of the three that took the
linear-LVDT fallback rather than a fitted bridge (`bridge_method[1] = 'multiplier'`, step
`0.991414`, `bridge_step_errors[1] = nan`), because it has 3 early / 1 late epochs inside the
±25 h window and at least 2 of each are needed to separate the step from the trend. So the
asymmetry is: the view removes the pipeline's weakest step from the long episode, and does
nothing for the short one.


## What it would cost in measurement

The view sets a **real, chromatic, measured** film reset to exactly 1.0 for every LED. Median
over the 18 SCAs of `response[35] / response[34]`, per LED:

```
LED1     LED2     LED3     LED4     LED5     LED6
1.13271  0.97736  1.00234  0.95494  0.98144  1.00773
+13.3 %   -2.3 %   +0.2 %   -4.5 %   -1.9 %   +0.8 %
```

Peak-to-peak **17.8 %**; across-LED rms of the log step **5.5 %**. **Quote the metric with
the number.** "The decon step is 5.5 %" read alone is wrong by a factor of three against
LED1, and 5.5 % is an rms over LEDs of a log ratio, not any LED's step. The chromaticity is
the whole point — it is what makes the step a film reset rather than a gain change, and it is
what `digest_plots/decon_evidence.png` tests. Discarding it into a gauge of 1.0 is discarding
the measurement that identifies the event.

Also note that the decon does **not** reset lamp drift (see `plots/calibration/pd_trend_summary.png`;
the photodiode trends run straight through the transition). The pre-reset lamp level is part
of what a per-episode gauge divides out, so each episode's curve is a film-growth *shape*,
not an absolute response, and shapes from two episodes are not directly comparable in
amplitude.


## Where it would be implemented, if it is

**Stage 3 only.** The reasoning for that, since "normalize per decon" sounds like it could
live anywhere:

- **Stage 2 stores absolute corrected rates by design**, so there is no t=0 ratio there to
  re-baseline. The one stage-2 quantity that could be re-baselined is the photodiode factor
  `reference_pd / pd_net` — and that corrects **lamp** drift, which the decon does not reset.
  Re-baselining it per decon would *inject* a spurious step at the transition rather than
  removing one.
- **Stage 3's denominator is `paths[0]` unconditionally**
  ([make_sca_digests.py:868](make_sca_digests.py#L868))
  and it never reads `reference_run_label`. `TrendSeries.response(sca)` is
  `self.raw[sca] * self.factors[sca][:, None]`
  ([make_sca_digests.py:748-750](make_sca_digests.py#L748-L750)).
  A re-gauge is therefore a post-bridge multiplicative factor composed in `response()` — a
  change of origin only, touching no fit.

Concrete shape, if built:

- `--response-baseline {global,decon}`, defaulting to `global`.
- `TrendSeries.decon_gauge: dict` and `TrendSeries.response_baseline: str`.
- An `apply_decon_baseline` called between `estimate_systematics`
  ([:1117](make_sca_digests.py#L1117)) and
  `write_digests` ([:1184](make_sca_digests.py#L1184)).
- A `decon_gauge` column, so either view is recoverable from either file.

### The gauge must be `(n_epoch, n_led)`, not a per-epoch scalar

The divisor is the episode's first-epoch response **vector**, and it is chromatic. For SCA1,
`decon2`'s is:

```
0.996212  0.993099  0.993394  0.991535  0.992445  0.993264
```

A scalar gauge (say its mean) would destroy the chromatic information while appearing to
work: every episode would still start at ~1.0 and every plot would still look right.

### `time_hours` must not be re-origined

The bridge window, every `BridgeStep.boundary_time`, and the whole `bridge_*` meta block are
measured in `time_hours`, and the x-axis label "hours since reference epoch" is correct
*because* of that. Add a separate origin — which is what the `decon_time_hours` column
already is — rather than moving the existing one. "Fixing" the axis label by re-origining
`time_hours` is the change that would silently desynchronize the axis from
`bridge_window_hours` and from the boundary markers drawn on it.

### A NaN at an episode's first epoch must propagate

A photodiode-flagged LED is NaN by design. If the gauge defaults such an LED to 1.0, the
output table carries one un-regauged LED beside five regauged ones with nothing in the file
to distinguish them. Propagate the NaN: an episode whose first epoch is unusable for an LED
has no origin for that LED, and saying so is the correct answer.

### A filename suffix is not a safe output convention

Do **not** write `time_series_SCA1_decon.ecsv` beside `time_series_SCA1.ecsv`.
`fit_film_rank1.py` globs `time_series_*.ecsv` and, with no `--dets`, treats every match as a
detector ([fit_film_rank1.py:258-261](fit_film_rank1.py#L258-L261)),
so it would be handed 36 "detectors" on one time grid — and it would **run, and produce a
number**, since the rank-1 model has no way to notice that half its detectors are the other
half re-origined. `fit_film_thickness.discover_digests` globs `time_series_SCA*.ecsv`
([fit_film_thickness.py:2532](fit_film_thickness.py#L2532))
and would crash on `int("1_decon")` instead — loud, and therefore the lesser problem.

A separate `--out-dir` is required, enforced by refusing to read a directory whose
`response_baseline` meta does not match what the consumer expects.

### Consumers that would need a branch

- `compare_to_reference_digests`
  ([:1430](make_sca_digests.py#L1430)) — comparing a
  re-gauged set against a globally gauged one would report a deviation of order the retained
  bridge factors (~0.7 % here) and read as a pipeline regression. It should refuse on a
  baseline mismatch and return NaN, not difference the numbers.
- The titles and y-labels in `plot_single_sca`, `plot_all_scas`, `plot_led_all_scas` — "response
  relative to the reference epoch" becomes false.

### Consumers that must *not* change

- `plot_decon_evidence` / the decon evidence statistic, whose entire job is detecting the
  reset this view discards. Feed it the globally gauged response or it tests nothing.
- `estimate_systematics`, where a per-episode constant cancels in log space.


## Deliberately not added

The `decon_gauge` column. Computing it is most of the feature, and with the calibration
motivation gone the episode bounds are what make the recipe safe, while the division stays
the user's to make. What *was* added, in support of the recipe:

- `rcs_acm.decon_episodes(labels)` — contiguous-run episode bounds, matplotlib/astropy-free.
- `decon_time_hours` column — hours since this epoch's episode began.
- `meta["decon_n_episodes"]`, `meta["decon_episode_bounds"]` (1-based inclusive),
  `meta["decon_episode_labels"]`, `meta["decon_reference_epochs"]` (positional),
  `meta["decon_episode_note"]` (states that the response is gauged globally, not per episode).
- An episode listing in the `DECON CYCLES` block of `run_log.txt`, *added beside* the existing
  per-label epoch totals rather than replacing them.
