"""The ice response model: the relative response of WFI detectors from ice
films, evaluated at any SCA position, time and wavelength.

Model based on an h5 containing principal components of the spectral response.

    python ice_response_model.py [MODEL_H5] [--out-dir DIR] [--sca 16] [--x 2000] [--y 2000]

``main()`` loads the model (default: the current release, or ``$ICE_RESPONSE_MODEL``)
and writes example figures of the response against time and wavelength.

    from ice_response_model import IceResponseModel
    m = IceResponseModel("ice_response_model_v1.h5")
    P = m.response(sca=16, x=2000, y=2000, t="2026-10-01T12:00")     # (1, 1, n_lambda)
    p = m.spectrum(16, 2000, 2000, "2026-10-01T12:00")               # (n_lambda,)

Return the change in relative spectrophotometric response due to ice films.
Does not include RCS trend-specific effects like PD, MCE side, ACM steps.
Temperature-dependent response is also not included.

Gray level shifts per decon cycle (thought to be real sky response shifts) are included.

**Conventions.**

* Positions: SCA 1..18 and full-SCA pixel ``(x, y)`` = (column, row), 0..4095, of the
  4096 x 4096 array in the calibrated products' orientation. The model is per
  superpixel (row = y // px, col = x // px; ``px`` = 64 for the 64 x 64 grid).
* Times: UTC ISO strings (``Z`` or ``+00:00``), ``datetime`` (aware ones are converted
  to UTC) or ``numpy.datetime64``; plain numbers are hours since the model's first
  epoch (``t0_utc``). The response is NaN before the first epoch and inside the decon
  warm-ups (the ice is removed there). After the last epoch the last deposition rate
  is extended; no future decon is known to the model.
* Wavelengths: nm, within the model grid (475-2350 nm; the WFI band is 480-2300 nm).
  The default is the grid itself, 1 nm steps.
* Shapes: ``(n_position, n_time, n_wavelength)``; ``sca``, ``x``, ``y`` broadcast
  together into positions.

**Where the model comes from.** ``IceResponseModel()`` (or a release version such as
``IceResponseModel("v1")``) reads the release from ``RELEASE_ROOTS`` in order:
``s3://smdc-rom-com-ops/...`` (downloaded once into ``~/.cache/ice_response_model``,
or ``$ICE_RESPONSE_MODEL_CACHE``, and checked against the release's MANIFEST.json
sha256), else its mount ``/mnt/smdc-rom-com-ops/...``. ``$ICE_RESPONSE_MODEL`` (a path,
an s3:// URI or a version) overrides the default.

Needs numpy, scipy and h5py (matplotlib for ``main``) and ``ice_response_core.py``
beside this file; boto3 for s3:// (optional: without it the mount is used).
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np

try:                                       # inside a package (e.g. the fitting repo)
    from . import ice_response_core as core
except ImportError:                        # the two files copied side by side
    import ice_response_core as core

SCHEMA = "rcs_response_model/1"
# The released models, tried in order: the bucket itself, then its NFS mount on the
# Roman science platform. A release is <root>/<version>/ice_response_model_<version>.h5
# with its MANIFEST.json beside it.
RELEASE_ROOTS = ("s3://smdc-rom-com-ops/rrn-ops/activities/car-190-rcs-spectro-trending/"
                 "ice_response_model",
                 "/mnt/smdc-rom-com-ops/rrn-ops/activities/car-190-rcs-spectro-trending/"
                 "ice_response_model")
DEFAULT_VERSION = "v3"
ENV_MODEL = "ICE_RESPONSE_MODEL"          # a path, an s3:// URI, or a release version
ENV_CACHE = "ICE_RESPONSE_MODEL_CACHE"    # where models read from S3 are kept
DEFAULT_CACHE = Path.home() / ".cache" / "ice_response_model"

# wavelengths near the WFI filter centres (nm), for the examples
EXAMPLE_NM = (620.0, 869.0, 1060.0, 1293.0, 1577.0, 1842.0, 2125.0)
EXAMPLE_FILTERS = ("F062", "F087", "F106", "F129", "F158", "F184", "F213")


def _str(v):
    return v.decode() if isinstance(v, bytes) else str(v)


# --------------------------------------------------------------------------- #
# data access: s3:// URIs and local paths behind one interface
# --------------------------------------------------------------------------- #
_S3 = {}


def s3_client():
    """A boto3 S3 client (the default credentials), or None without boto3."""
    if "client" not in _S3:
        try:
            import boto3
            _S3["client"] = boto3.client("s3")
        except ImportError:
            _S3["client"] = None
    return _S3["client"]


def _split_s3(uri: str):
    bucket, _, key = str(uri)[len("s3://"):].partition("/")
    return bucket, key


def join(root, *parts) -> str:
    """``root/part/...`` for an s3:// URI or a local path."""
    return "/".join([str(root).rstrip("/")] + [str(x).strip("/") for x in parts])


def read_bytes(where, start: int | None = None, stop: int | None = None) -> bytes:
    """The bytes of an s3:// object or a local file, or ``[start, stop)`` of them."""
    if str(where).startswith("s3://"):
        c = s3_client()
        if c is None:
            raise RuntimeError("reading s3:// needs boto3")
        b, k = _split_s3(where)
        kw = {} if start is None else dict(Range=f"bytes={start}-{'' if stop is None else stop - 1}")
        return c.get_object(Bucket=b, Key=k, **kw)["Body"].read()
    with open(where, "rb") as f:
        if start is not None:
            f.seek(start)
        return f.read() if start is None or stop is None else f.read(stop - start)


def list_names(where, prefix: str = "") -> list:
    """The file names (not paths) directly under an s3:// prefix or a local directory
    that start with ``prefix``."""
    if str(where).startswith("s3://"):
        c = s3_client()
        if c is None:
            raise RuntimeError("listing s3:// needs boto3")
        b, k = _split_s3(join(where, ""))
        out = []
        for page in c.get_paginator("list_objects_v2").paginate(Bucket=b, Prefix=k + prefix):
            out += [o["Key"][len(k):] for o in page.get("Contents", [])]
        return sorted(n for n in out if n and "/" not in n)
    return sorted(n for n in os.listdir(where) if n.startswith(prefix))


def first_root(roots, probe: str, say=None):
    """The first of ``roots`` (s3:// URIs or local paths) where ``probe`` (a path
    under the root) can be read; the others are skipped with the reason."""
    tried = []
    for r in roots:
        try:
            read_bytes(join(r, probe), 0, 1)
            if say:
                say(f"data from {r}" + (f" ({'; '.join(tried)})" if tried else ""))
            return r
        except Exception as e:                      # no boto3, credentials, network, ...
            tried.append(f"{r}: {type(e).__name__}: {str(e)[:80]}")
    raise FileNotFoundError(f"{probe} under none of: " + "; ".join(tried))


def release_path(version=None, roots=RELEASE_ROOTS, cache=None, say=None) -> Path:
    """The local h5 of a released model: from the first root that has it. A release
    read from S3 is downloaded once into ``cache`` (``$ICE_RESPONSE_MODEL_CACHE``, else
    ~/.cache/ice_response_model) and checked against its MANIFEST.json sha256."""
    import hashlib
    v = version or DEFAULT_VERSION
    name = f"ice_response_model_{v}.h5"
    root = first_root(roots, join(v, "MANIFEST.json"), say=say)
    if not str(root).startswith("s3://"):
        return Path(join(root, v, name))
    man = json.loads(read_bytes(join(root, v, "MANIFEST.json")))
    cache = Path(cache or os.environ.get(ENV_CACHE) or DEFAULT_CACHE) / v
    dst = cache / name
    if dst.exists() and dst.stat().st_size == int(man["size_bytes"]):
        return dst
    cache.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_suffix(".part")
    b, k = _split_s3(join(root, v, name))
    if say:
        say(f"downloading {join(root, v, name)} ({int(man['size_bytes']) / 1e6:.0f} MB) to {dst}")
    s3_client().download_file(b, k, str(tmp))
    h = hashlib.sha256()
    with open(tmp, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 24), b""):
            h.update(chunk)
    if h.hexdigest() != man["sha256"]:
        tmp.unlink()
        raise ValueError(f"{name}: sha256 {h.hexdigest()} is not the release's {man['sha256']}")
    tmp.replace(dst)
    for extra in ("MANIFEST.json",):
        (cache / extra).write_bytes(read_bytes(join(root, v, extra)))
    return dst


def resolve_model(model=None, say=None) -> Path:
    """A local h5 for ``model``: a path; an s3:// URI of an h5 (cached); a release
    version (``"v2"``); or None for ``$ICE_RESPONSE_MODEL``, else the current release
    (``DEFAULT_VERSION``, from ``RELEASE_ROOTS`` in order)."""
    model = model or os.environ.get(ENV_MODEL) or DEFAULT_VERSION
    m = str(model)
    if m.startswith("s3://"):
        cache = Path(os.environ.get(ENV_CACHE) or DEFAULT_CACHE) / "s3"
        dst = cache / _split_s3(m)[0] / _split_s3(m)[1]
        if not dst.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            tmp = dst.with_suffix(".part")
            s3_client().download_file(*_split_s3(m), str(tmp))
            tmp.replace(dst)
        return dst
    if not m.endswith(".h5") and "/" not in m:
        return release_path(m, say=say)
    return Path(m)


class IceResponseModel:
    """A released ice response model, read whole from its h5."""

    def __init__(self, path=None, say=None):
        """``path``: a model h5, an s3:// URI of one, a release version (``"v2"``), or
        None for ``$ICE_RESPONSE_MODEL``, else the current release -- read from
        ``RELEASE_ROOTS`` in order (S3, then the mount); see :func:`resolve_model`."""
        import h5py
        self.path = resolve_model(path, say=say)
        path = self.path
        with h5py.File(self.path, "r") as f:
            self.attrs = {k: (_str(v) if isinstance(v, (bytes, str)) else v)
                          for k, v in f.attrs.items()}
            if self.attrs.get("schema") != SCHEMA:
                raise ValueError(f"{path}: schema {self.attrs.get('schema')!r}, expected {SCHEMA}")
            g = f["reflectance"]
            self.wavelength_nm = g["wavelength_nm"][()]
            self._mean, self._modes, self._amp = g["mean"][()], g["modes"][()], g["amplitudes"][()]
            s = f["superpixels"]
            self._sca, self._row, self._col = s["sca"][()], s["row"][()], s["col"][()]
            self._cos_theta = s["cos_theta"][()]
            self._reportable, self._dq = s["reportable"][()], s["dq_flags"][()]
            # the full mask set, in models built from 2026-10-23 on
            self._qmask = s["quality_mask"][()] if "quality_mask" in s else None
            self.quality_bits = (json.loads(_str(s["quality_mask"].attrs["bits"]))
                                 if "quality_mask" in s else {})
            d = f["deposition"]
            self._t_epoch, self._episode = d["time_hours"][()], d["episode"][()]
            self.epoch_utc = np.array([_str(x) for x in d["timestamp_utc"][()]])
            self._blocks = d["blocks"][()]
            self._mult, self._tau = d["multipliers"][()], d["tau_h"][()]
            self._offset_episodes = d["offset_episodes"][()]
            self._log_a, self._d_off = d["log_a"][()], d["d_off"][()]
            self._rate_map = d["rate_nm_per_day"][()]
            o = f["film"]
            self._n, self._kappa, self._b = o["n"][()], o["kappa"][()], o["b"][()]
            self._n_ref = float(o.attrs["n_snell_ref"])
            self._snell = bool(o.attrs["chromatic_snell"])
            # the fit's LED band quadrature, in models built from 2026-10-23 on
            if "led_bands" in f:
                lb = f["led_bands"]
                self.led_nodes_nm, self.led_weight = lb["wavelength_nm"][()], lb["weight"][()]
                self.led_center_nm = lb["center_nm"][()]
            else:
                self.led_nodes_nm = self.led_weight = self.led_center_nm = None
            i = f["instrument"]
            self._gray_hours = i["gray_period_hours"][()] if "gray_period_hours" in i else np.zeros(0)
            self._gray = (i["gray"][()][:, :self._gray_hours.size] if "gray" in i
                          else np.zeros((self._sca.size, 0)))
        self.n_bin = int(self.attrs["n_bin"])
        self.superpixel_px = core.SCA_PIX // self.n_bin
        self.n_modes = int(self._modes.shape[0])
        self.version = self.attrs.get("release_version")
        self.t0_utc, self.t_last_utc = self.epoch_utc[0], self.epoch_utc[-1]

    def __repr__(self):
        return (f"IceResponseModel({self.path.name}: release {self.version}, {self.n_modes} "
                f"modes, {self.n_bin} x {self.n_bin} superpixels per SCA, "
                f"{self.wavelength_nm[0]:.0f}-{self.wavelength_nm[-1]:.0f} nm, epochs "
                f"{self.t0_utc[:16]} to {self.t_last_utc[:16]} UTC)")

    # -- positions and times ---------------------------------------------- #
    def superpixel(self, sca, x, y):
        """Superpixel index of each (SCA, x, y); arrays broadcast together."""
        return core.superpixel_index(sca, x, y, self.n_bin, self._sca, self._row, self._col)

    def hours(self, t):
        """Hours since the first epoch (``t0_utc``) of each time in ``t``."""
        return np.atleast_1d(core.hours_since(t, self.t0_utc))

    def valid(self, t):
        """True where the model describes time ``t``: not before the first epoch and not
        inside a decon warm-up."""
        return core.modelled(self.hours(t), self._t_epoch, self._episode)

    def quality(self, sca, x, y):
        """``{"reportable", "dq_flags", "quality_mask", "ref_imputed"}`` per position.
        Superpixels that are not reportable failed the fit's quality cuts; their model
        is still returned. ``quality_mask`` (when the file has it): one bit per reason,
        named in ``self.quality_bits``; -1 for older files.

        ``ref_imputed`` (release v3 on): the superpixel is on the reference epoch's guide
        window. The reference exposure there is corrupted, so the model was fitted to
        the LATER epochs with a free level per LED, and its response relative to the
        reference epoch is IMPUTED: the fitted model carried back to t = 0, not a
        measurement. Ratios between two later times are measured as elsewhere."""
        sp = self.superpixel(sca, x, y)
        qm = (self._qmask[sp].astype(np.int64) if self._qmask is not None
              else np.full(np.shape(sp), -1, np.int64))
        b = self.quality_bits.get("ref_imputed")
        return dict(reportable=self._reportable[sp].astype(bool), dq_flags=self._dq[sp],
                    quality_mask=qm,
                    ref_imputed=(qm >= 0) & ((qm & int(b)) > 0) if b else np.zeros(np.shape(sp), bool))

    # -- the model ---------------------------------------------------------- #
    def thickness(self, sca, x, y, t):
        """Physical ice thickness (nm), ``(n_position, n_time)``; NaN where not valid."""
        sp, th = self.superpixel(sca, x, y), self.hours(t)
        d = core.thickness(th, self._log_a[sp], self._d_off[sp], self._t_epoch, self._episode,
                           self._blocks, self._mult, self._tau, self._offset_episodes)
        d[:, ~core.modelled(th, self._t_epoch, self._episode)] = np.nan
        return d

    def rate(self, sca, x, y, t):
        """Deposition rate (nm/day of physical thickness), ``(n_position, n_time)``."""
        sp, th = self.superpixel(sca, x, y), self.hours(t)
        k = core.block_at(th, self._t_epoch, self._episode, self._blocks)
        r = self._rate_map[sp][:, np.maximum(k, 0)]
        r[:, k < 0] = np.nan
        return r

    def gray(self, sca, x, y, t):
        """The achromatic gray factor ``1 + level`` of each decon cycle after the first
        (the first is the reference, 1), ``(n_position, n_time)``."""
        sp = self.superpixel(sca, x, y)
        return core.step_factor(self.hours(t), self._gray_hours, self._gray[sp])

    def reflectance(self, sca, x, y, wavelength_nm=None):
        """The detector's complex reflectance (under no ice), ``(n_position, n_wavelength)``."""
        sp = self.superpixel(sca, x, y)
        lam = self.wavelength_nm if wavelength_nm is None else np.atleast_1d(
            np.asarray(wavelength_nm, float))
        return core.reflectance(self._amp[sp], self.wavelength_nm, self._mean, self._modes, lam)

    def response(self, sca, x, y, t, wavelength_nm=None, gray: bool = True):
        """Relative response (no ice = 1), ``(n_position, n_time, n_wavelength)``: the ice
        film, times the per-decon gray when ``gray``. NaN where the model is not valid."""
        sp, th = self.superpixel(sca, x, y), self.hours(t)
        lam = self.wavelength_nm if wavelength_nm is None else np.atleast_1d(
            np.asarray(wavelength_nm, float))
        r = core.reflectance(self._amp[sp], self.wavelength_nm, self._mean, self._modes, lam)
        d = core.thickness(th, self._log_a[sp], self._d_off[sp], self._t_epoch, self._episode,
                           self._blocks, self._mult, self._tau, self._offset_episodes)
        P = core.relative_response(r, lam, d, self._cos_theta[sp], self.wavelength_nm, self._n,
                                   self._kappa, self._b, self._n_ref, self._snell)
        P[:, :, ~core.modelled(th, self._t_epoch, self._episode)] = np.nan
        if gray:
            P = P * core.step_factor(th, self._gray_hours, self._gray[sp])[:, None, :]
        return np.transpose(P, (0, 2, 1))

    def spectrum(self, sca, x, y, t, wavelength_nm=None, gray: bool = True):
        """``response`` at one position and time: ``(n_wavelength,)``."""
        if np.size(sca) != 1 or np.size(x) != 1 or np.size(y) != 1 or np.size(t) != 1:
            raise ValueError("spectrum takes one position and one time; use response")
        return self.response(sca, x, y, t, wavelength_nm, gray)[0, 0]

    def band_response(self, sca, x, y, t, wavelength_nm, weight, gray: bool = True,
                      no_ice_weight: bool = False):
        """``sum_l w_l P_l / sum_l w_l``, ``(n_position, n_time)``. For a calibration the
        weight is the source's photon spectrum times the full system throughput,
        including the detector's no-ice QE: the result is then the ratio of detected
        signals with and without ice.

        ``no_ice_weight``: multiply the weight by each position's own no-ice
        transmission ``S(0)`` (:func:`ice_response_core.no_ice_transmission`), the
        detector's reflectance ripple. Pass the source spectrum times the rest of the
        throughput then; the result is ``sum w S(d) / sum w S(0)``."""
        w = np.asarray(weight, float)
        P = self.response(sca, x, y, t, wavelength_nm, gray)
        if not no_ice_weight:
            return P @ w / np.sum(w)
        sp = self.superpixel(sca, x, y)
        lam = np.atleast_1d(np.asarray(wavelength_nm, float))
        r = core.reflectance(self._amp[sp], self.wavelength_nm, self._mean, self._modes, lam)
        _, _, b_l = core.optics_at(self.wavelength_nm, self._n, self._kappa, self._b, lam)
        W = w[None, :] * core.no_ice_transmission(r, b_l[None, :])
        return np.einsum("ptl,pl->pt", P, W) / W.sum(axis=1)[:, None]

    def led_band_response(self, sca, x, y, t, gray: bool = True):
        """The response in each RCS LED band, ``(n_position, n_time, n_led)``: the fit's
        own band integral (``led_bands/``: its quadrature, weighted by each position's
        no-ice transmission), so it reproduces the fitted LED band response. For data
        taken with the LEDs, e.g. RCS flats."""
        if self.led_weight is None:
            raise ValueError(f"{self.path.name} has no led_bands (models built from "
                             "2026-10-23 on)")
        return np.stack([self.band_response(sca, x, y, t, self.led_nodes_nm[j],
                                            self.led_weight[j], gray, no_ice_weight=True)
                         for j in range(self.led_weight.shape[0])], axis=-1)


# --------------------------------------------------------------------------- #
# the example
# --------------------------------------------------------------------------- #
# The fitting repository's validated palette (viz/viz_palette.py), in its fixed order.
_COLORS = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7"]
_ORDINAL = ["#86b6ef", "#5598e7", "#2a78d6", "#1c5cab", "#104281"]
_INK, _INK2, _MUTED, _GRID = "#0b0b0b", "#52514e", "#7a7974", "#e4e3df"


def _style():
    import matplotlib as mpl
    mpl.rcParams.update({"axes.edgecolor": _INK2, "axes.labelcolor": _INK, "text.color": _INK,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.grid": True, "grid.color": _GRID, "grid.linewidth": 0.6,
                         "xtick.color": _INK2, "ytick.color": _INK2, "legend.frameon": False,
                         "font.size": 9})


def main(argv=None) -> int:
    import argparse
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.dates as mdates
    import matplotlib.pyplot as plt

    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("model", nargs="?", default=None,
                   help=f"model h5 (default ${ENV_MODEL}, else the current release)")
    p.add_argument("--out-dir", default="ice_response_examples")
    p.add_argument("--sca", type=int, default=16)
    p.add_argument("--x", type=int, default=2000)
    p.add_argument("--y", type=int, default=2000)
    a = p.parse_args(argv)
    _style()
    m = IceResponseModel(a.model)
    out = Path(a.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    print(m)

    # an hourly UTC time axis over the epochs
    t0 = np.datetime64(core._datetime64_utc(m.t0_utc), "h")
    t1 = np.datetime64(core._datetime64_utc(m.t_last_utc), "h")
    times = np.arange(t0, t1 + np.timedelta64(2, "h"), np.timedelta64(1, "h"))
    tt = times.astype("datetime64[s]").astype(object)
    lab = [f"{lam:.0f} nm ({f})" for lam, f in zip(EXAMPLE_NM, EXAMPLE_FILTERS)]
    pos = f"SCA {a.sca}, pixel ({a.x}, {a.y})"

    # a query, printed
    t_q = m.epoch_utc[-1]
    s = m.spectrum(a.sca, a.x, a.y, t_q, EXAMPLE_NM)
    print(f"{pos} at {t_q[:19]} UTC: thickness {m.thickness(a.sca, a.x, a.y, t_q)[0, 0]:.1f} nm, "
          f"gray {m.gray(a.sca, a.x, a.y, t_q)[0, 0]:.5f}, reportable "
          f"{bool(m.quality(a.sca, a.x, a.y)['reportable'][0])}")
    for lam, v in zip(EXAMPLE_NM, s):
        print(f"   response at {lam:6.0f} nm: {v:.5f}")

    # 1. one position against time: the response, the thickness and rate, the gray
    P = m.response(a.sca, a.x, a.y, times, EXAMPLE_NM)[0]           # (n_t, n_lam)
    P0 = m.response(a.sca, a.x, a.y, times, EXAMPLE_NM, gray=False)[0]
    fig, ax = plt.subplots(3, 1, figsize=(11.0, 10.0), sharex=True,
                           gridspec_kw=dict(height_ratios=[2.2, 1.0, 1.0]))
    for j in range(len(EXAMPLE_NM)):
        ax[0].plot(tt, (P[:, j] - 1) * 100, lw=1.8, color=_COLORS[j], label=lab[j])
    ax[0].axhline(0.0, color=_MUTED, lw=0.7)
    ax[0].set_ylabel("response - 1 (%)")
    ax[0].legend(fontsize=8, ncol=4, loc="lower left")
    ax[0].set_title(f"{pos}: relative response (ice film x gray; no ice = 1); gaps are the "
                    "decon warm-ups", loc="left", fontsize=10)
    ax[1].plot(tt, m.thickness(a.sca, a.x, a.y, times)[0], lw=1.8, color=_COLORS[0],
               label="ice thickness")
    ax[1].set_ylabel("thickness (nm)")
    ax[1].set_title("the time model: ice thickness", loc="left", fontsize=10)
    ax[2].plot(tt, (P[:, 0] / P0[:, 0] - 1) * 1e6, lw=1.8, color=_COLORS[0],
               label="gray factor - 1")
    ax[2].axhline(0.0, color=_MUTED, lw=0.7)
    ax[2].set_ylabel("gray - 1 (ppm)")
    ax[2].set_title("the per-decon gray level (achromatic; decon 1 is the reference)",
                    loc="left", fontsize=10)
    ax[2].xaxis.set_major_formatter(mdates.DateFormatter("%m-%d"))
    ax[2].set_xlabel("date (UTC)")
    fig.tight_layout()
    f1 = out / f"response_vs_time_SCA{a.sca:02d}.png"
    fig.savefig(f1, dpi=130)
    plt.close(fig)

    # 2. one position against wavelength, at five dates
    lam = np.arange(480.0, 2300.0 + 1e-9, 2.0)
    ok_t = times[m.valid(times)]
    pick = ok_t[np.linspace(0, ok_t.size - 1, len(_ORDINAL)).astype(int)]
    Pl = m.response(a.sca, a.x, a.y, pick, lam)[0]                  # (n_pick, n_lam)
    fig, ax = plt.subplots(figsize=(11.0, 5.0))
    for i in range(pick.size):
        ax.plot(lam, (Pl[i] - 1) * 100, lw=1.6, color=_ORDINAL[i],
                label=str(pick[i]).replace("T", " ") + " UTC")
    ax.axhline(0.0, color=_MUTED, lw=0.7)
    ax.set_xlabel("wavelength (nm)")
    ax.set_ylabel("response - 1 (%)")
    ax.legend(fontsize=8, ncol=2)
    ax.set_title(f"{pos}: relative response against wavelength (light to dark: early to late)",
                 loc="left", fontsize=10)
    fig.tight_layout()
    f2 = out / f"response_vs_wavelength_SCA{a.sca:02d}.png"
    fig.savefig(f2, dpi=130)
    plt.close(fig)

    # 3. every SCA centre against time
    fig, axes = plt.subplots(3, 6, figsize=(24.0, 11.0), sharex=True, sharey=True)
    for sca in range(1, 19):
        axk = axes.ravel()[sca - 1]
        Pk = m.response(sca, a.x, a.y, times, EXAMPLE_NM)[0]
        for j in range(len(EXAMPLE_NM)):
            axk.plot(tt, (Pk[:, j] - 1) * 100, lw=1.4, color=_COLORS[j],
                     label=lab[j] if sca == 1 else None)
        ok = bool(m.quality(sca, a.x, a.y)["reportable"][0])
        axk.set_title(f"SCA {sca}, pixel ({a.x}, {a.y})" + ("" if ok else " (not reportable)"),
                      fontsize=9)
        axk.axhline(0.0, color=_MUTED, lw=0.7)
        axk.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d"))
        axk.tick_params(labelsize=7)
    axes[0][0].legend(fontsize=7, loc="lower left")
    for axk in axes[:, 0]:
        axk.set_ylabel("response - 1 (%)", fontsize=8)
    for axk in axes[-1]:
        axk.set_xlabel("date (UTC)", fontsize=8)
    fig.suptitle(f"relative response (ice film x gray) at each SCA, {m.path.name}", fontsize=12)
    fig.tight_layout()
    f3 = out / "response_vs_time_sca_centers.png"
    fig.savefig(f3, dpi=110)
    plt.close(fig)
    for f in (f1, f2, f3):
        print(f)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
