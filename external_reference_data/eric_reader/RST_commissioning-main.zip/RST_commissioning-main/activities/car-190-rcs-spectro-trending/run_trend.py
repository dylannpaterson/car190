#!/usr/bin/env python
"""Stages 2 and 3 over a whole trend tree, as one verbose, resumable call.

    .venv/bin/python run_trend.py --dry-run          # print the plan, run nothing
    .venv/bin/python run_trend.py                    # card -> cal -> digests, both passes
    .venv/bin/python run_trend.py --fit-tempgain     # and refit the temperature gain

Every step prints the exact command before running it, so anything this does
can be redone by hand, one step at a time, from its own output.

Why two passes. The calibrated h5 products carry every factor needed to
calibrate them (schema 2: recorded, never applied). Two of those factors -- the
ACM bridge and the MCE side bridge -- are fitted from the whole trend, which no
per-file stage can see. So:

  1  reference card          the whole-set quantities: reference epoch,
                             per-side photodiode references, ACM segments
  2  stage 2, pass 1         photodiode + linear ACM recorded, no bridges
  3  stage 3, pass 1         fits both bridges, writes the bridge solution
  4  (optional) gain fit     the temperature gain, from pass-1 digests
  5  stage 2, pass 2         records the bridges (and the gain) as well
  6  stage 3, final          digests, figures, run log -- and the check that
                             the products now carry the bridges it fits
  7  stage-2 diagnostics     calibration factors, PD trend, housekeeping

That is a bootstrap, not an iteration: pass 2 adds metadata without moving a
pixel or a per-file factor, so the bridges and the gain are fitted from
bit-identical input both times. Step 6 proves it two ways -- the run log's
"bridge solution check" must read "current", and the final digests' LED1..LED6
must equal pass 1's exactly -- and this script fails if either does not hold.
"""
import argparse
import datetime
import glob
import os
import shlex
import shutil
import subprocess
import sys

import rcs_trend_config as cfg

HERE = os.path.dirname(os.path.abspath(__file__))
PYTHON = sys.executable


def _banner(number, total, title, why):
    print(f"\n{'=' * 78}\n[{number}/{total}] {title}\n{'=' * 78}")
    for line in why:
        print(f"  {line}")


def _run(command, dry_run):
    print(f"\n$ {' '.join(shlex.quote(str(part)) for part in command)}\n",
          flush=True)
    if dry_run:
        return
    result = subprocess.run([str(part) for part in command], cwd=HERE)
    if result.returncode != 0:
        raise SystemExit(f"\nstep failed (exit {result.returncode}); fix it and "
                         f"re-run, or run the remaining steps by hand from the "
                         f"commands printed above")


def _digest_columns(directory):
    from astropy.table import Table
    import numpy as np

    out = {}
    for path in sorted(glob.glob(os.path.join(directory, "time_series_SCA*.ecsv"))):
        table = Table.read(path, format="ascii.ecsv")
        out[os.path.basename(path)] = (
            np.column_stack([np.asarray(table[led], dtype=float)
                             for led in cfg.LED_NAMES]), dict(table.meta))
    return out


def verify(pass1_dir, final_dir):
    """The two bootstrap checks. Returns a list of failures (empty if fine)."""
    import numpy as np

    failures = []
    first, final = _digest_columns(pass1_dir), _digest_columns(final_dir)
    if set(first) != set(final) or not first:
        return [f"digest sets differ: {sorted(first)[:3]} vs {sorted(final)[:3]}"]
    changed = [name for name in first
               if not np.array_equal(first[name][0], final[name][0],
                                     equal_nan=True)]
    if changed:
        failures.append(f"LED1..LED6 moved between pass 1 and the final digests "
                        f"in {len(changed)} file(s), e.g. {changed[0]}: pass 2 "
                        f"changed an input it must not touch")
    else:
        print(f"  ok   LED1..LED6 in all {len(first)} final digests are "
              f"bit-identical to pass 1: recording the bridges and the gain "
              f"moved nothing")
    checks = {meta.get("bridge_solution_check", "") for _, meta in final.values()}
    if all(str(check).startswith("current") for check in checks):
        print(f"  ok   the products carry the bridge solution the final digests "
              f"fit: {sorted(checks)[0]}")
    else:
        failures.append(f"bridge_solution_check reads {sorted(checks)}, not "
                        f"'current'")
    return failures


def main(argv=None):
    today = datetime.date.today()
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--root", default=cfg.TREND_ROOT,
                        help="trend tree holding h5/ (default %(default)s)")
    parser.add_argument("--digests", default=None,
                        help="final digest directory (default ROOT/digests/"
                             "digests_<tree>_<mm_dd_yy>)")
    parser.add_argument("--plot-dir", default=None,
                        help="digest figures (default ROOT/digest_plots)")
    parser.add_argument("--plots", default=None,
                        help="parent of the stage-2 diagnostic, PD-sequence, "
                             "housekeeping and gain-fit figures (default "
                             "ROOT/plots)")
    parser.add_argument("--tempgain-model", default=None,
                        help="temperature-gain model to record at pass 2 when "
                             "--fit-tempgain is not given (default: the tree's "
                             "own ROOT/tempgain_model.ecsv if it exists, else "
                             "the repo's tempgain_model.ecsv)")
    parser.add_argument("--fit-tempgain", action="store_true",
                        help="refit the temperature gain from the pass-1 "
                             "digests (~25 min) and record THAT model at pass 2")
    parser.add_argument("--jobs", type=int, default=min(16, os.cpu_count() or 1))
    parser.add_argument("--skip-diagnostics", action="store_true",
                        help="stop after the final digests")
    parser.add_argument("--dry-run", action="store_true",
                        help="print every command and run none of them")
    args = parser.parse_args(argv)

    root = os.path.abspath(args.root)
    tree = os.path.basename(root).replace("rcs_trend_", "") or "trend"
    # Everything a reader of the trend needs lives in the tree, so the shared
    # deployment is the tree itself: no copy step after a run, and a digest
    # set never sits in one person's checkout.
    digests = args.digests or os.path.join(
        root, "digests", f"digests_{tree}_{today:%m_%d_%y}")
    plot_dir = args.plot_dir or os.path.join(root, "digest_plots")
    plots = args.plots or os.path.join(root, "plots")
    args.plot_dir, args.calibration_plots = plot_dir, os.path.join(
        plots, "calibration")
    pass1 = os.path.join(root, "digests_pass1")
    card = os.path.join(root, "rcs_reference_card.ecsv")
    cal = os.path.join(root, "cal")
    solution = os.path.join(root, "rcs_bridge_solution.ecsv")
    fitted_model = os.path.join(root, "tempgain_model.ecsv")
    repo_model = os.path.join(HERE, "tempgain_model.ecsv")
    if args.tempgain_model is None:
        args.tempgain_model = (fitted_model if os.path.exists(fitted_model)
                               else repo_model)
    model = (fitted_model if args.fit_tempgain
             else args.tempgain_model if os.path.exists(args.tempgain_model)
             else None)
    if not os.path.isdir(os.path.join(root, "h5")) and not args.dry_run:
        raise SystemExit(f"no {root}/h5: run batch/refresh.py first")

    total = 7
    print(f"trend tree   {root}")
    print(f"card         {card}")
    print(f"calibrated   {cal}")
    print(f"digests      {digests}   (pass 1 in {pass1})")
    print(f"figures      {args.plot_dir}, {args.calibration_plots}")
    print(f"gain model   {model or 'none'}"
          + ("  (refitted here)" if args.fit_tempgain else ""))

    _banner(1, total, "reference card",
            ["metadata only, ~0.1 s per product. Per-side photodiode reference",
             "(1.0 at each MCE side's first epoch) and ACM segments, which also",
             "break at a side change."])
    # Not --quiet: the card's report -- sides, segments, the travel warning --
    # is the part of this run someone coming back to it needs to read.
    _run([PYTHON, "calibrate_rcs_products.py", "--make-card",
          "--raw-dir", os.path.join(root, "h5"), "--card", card], args.dry_run)

    _banner(2, total, "stage 2, pass 1: record photodiode + ACM",
            ["no pixel is changed; metadata and multipliers only"])
    _run([PYTHON, "calibrate_rcs_products.py", "--card", card,
          "--in", os.path.join(root, "h5"), "--out-dir", cal,
          "--jobs", args.jobs, "--force", "--quiet"], args.dry_run)

    _banner(3, total, "stage 3, pass 1: fit the ACM and side bridges",
            ["writes the bridge solution stage 2 records next; no figures yet"])
    _run([PYTHON, "make_sca_digests.py", "--data-root", cal, "--out-dir", pass1,
          "--no-plots", "--quiet", "--solution-out", solution], args.dry_run)

    _banner(4, total, "temperature-gain fit",
            ["from the pass-1 digests' gain-free LED1..LED6, so the fit never",
             "reads its own output" if args.fit_tempgain else
             "skipped (pass --fit-tempgain to refit); recording "
             + (model or "no model")])
    if args.fit_tempgain:
        if os.path.exists(fitted_model):
            kept = os.path.join(root, f"tempgain_model_before_"
                                      f"{today:%Y%m%d}.ecsv")
            print(f"  the tree's current model is kept as {kept}; the new fit "
                  f"replaces {fitted_model}")
            if not args.dry_run and not os.path.exists(kept):
                shutil.copy2(fitted_model, kept)
        _run([PYTHON, "fit_temperature_gain.py", "--digest-dir", pass1,
              "--cal-dir", cal, "--processes", args.jobs,
              "--model-out", fitted_model, "--out-dir",
              os.path.join(plots, "temperature_gain")],
             args.dry_run)

    _banner(5, total, "stage 2, pass 2: record the bridges"
            + (" and the gain" if model else ""),
            ["metadata only: the pixels and the per-file factors are those of "
             "pass 1"])
    command = [PYTHON, "calibrate_rcs_products.py", "--card", card,
               "--in", os.path.join(root, "h5"), "--out-dir", cal,
               "--jobs", args.jobs, "--force", "--quiet",
               "--bridge-solution", solution]
    if model:
        command += ["--tempgain-model", model]
    _run(command, args.dry_run)

    _banner(6, total, "stage 3, final: digests, figures, run log",
            ["the bridges are refitted and checked against the ones the "
             "products now carry"])
    _run([PYTHON, "make_sca_digests.py", "--data-root", cal, "--out-dir", digests,
          "--plot-dir", args.plot_dir, "--report",
          os.path.join(digests, "run_log.txt"), "--quiet"], args.dry_run)
    if not args.dry_run:
        print("\nbootstrap checks:")
        failures = verify(pass1, digests)
        if failures:
            for failure in failures:
                print(f"  FAIL {failure}")
            raise SystemExit("the bootstrap did not close; see above")
    # The products must stand on their own: the free-standing reader rebuilds
    # every digest column and data-bearing meta key from them alone, and this
    # fails above 1e-9. Run every time, so a change that puts something into
    # the digests and not into the products is caught where it is made.
    print("\nself-containment check (rcs_trend_reader, from the h5 alone):")
    _run([PYTHON, "rcs_trend_reader.py", "compare", cal, digests], args.dry_run)

    if not args.skip_diagnostics:
        _banner(7, total, "stage-2 diagnostics",
                ["what each product records, read back from calibration/"])
        _run([PYTHON, "-c", "import calibration_plots as c; "
              f"c.write_all({cal!r}, {args.calibration_plots!r})"], args.dry_run)
        _run([PYTHON, "calibrate_rcs_products.py", "--card", card,
              "--plot-pd-trend", args.calibration_plots], args.dry_run)
        _run([PYTHON, "plot_pd_sequence.py", "--in",
              os.path.join(root, "h5", "pd", "pd_*.h5"),
              "--out-dir", os.path.join(plots, "pd_sequence")], args.dry_run)
        _run([PYTHON, "housekeeping_trends.py", "--cal-dir", cal,
              "--out-dir", os.path.join(plots, "housekeeping")], args.dry_run)

    print(f"\n{'=' * 78}\nwhere to look\n{'=' * 78}")
    print(f"  {digests}/run_log.txt   read first: ACM moves, the side bridge, "
          f"the solution check")
    print(f"  {args.plot_dir}/side_bridge.png   the A->B step per LED and the "
          f"illumination-pattern test")
    print(f"  {args.plot_dir}/time_series_LED*_all_scas.png   the bridged trend")
    print(f"  {args.calibration_plots}/calibration_factors.png   what each "
          f"product records")
    print(f"  {solution}   the fitted bridges, as recorded in every product")
    if args.fit_tempgain:
        print(f"  {plots}/temperature_gain/   the refit, recorded at pass 2 "
              f"and the default from now on (the repo's {repo_model} is "
              f"unchanged)")
    print("  any product, interactively: .venv/bin/python rcs_trend_reader.py "
          f"summary {cal}/<run_label>_cal.h5")
    return 0


if __name__ == "__main__":
    sys.exit(main())
