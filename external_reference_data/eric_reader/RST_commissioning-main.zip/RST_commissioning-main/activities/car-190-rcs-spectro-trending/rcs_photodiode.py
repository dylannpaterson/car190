"""Photodiode reduction from the RCS PD *time stream* rather than per-activity medians.

What this replaces. The frozen compiler reduces the photodiode to one median per
exposure window and then subtracts the first entry::

    RCS_photodiode = pd_raw - pd_raw[0]        # stage_rcs_inputs.py:251-253

That works only because activity 1 happens to be the dark, and it conflates two
different things: the dark *exposure window* (when the shutter sequence says an
exposure was taken) and the interval during which the LEDs were actually off
(what the pedestal is a property of). Those are not the same interval, and the
pedestal is the larger of the two effects -- the dark PD carries more pedestal
than it does signal.

Why it matters more than it looks. ``rcs_corrections.led_scale_factors`` forms
``reference.photodiode[i] / epoch.photodiode[i]``, so ``pd_net`` is a
*denominator*. Measured on real passes the pedestal is ~0.1164 V against
illuminated readings of 0.347-0.396 V, i.e. ``pd_net`` ~ 0.23-0.28 V. A pedestal
taken from a window that was not actually off can push ``pd_raw`` down to ~0.12 V,
giving ``pd_net`` = 0.004 V and a **60x response factor that looks exactly like a
real instrument event**. Hence ``pd_net_valid`` and ``PD_MIN_NET``: an invalid
net is NaN and a flag, never a correction factor.

The two diodes are different detectors. ``PD2`` is HgCdTe and ``PD1`` is InGaAs,
which is why they are not interchangeable and why only one of them is a baseline.
Measured over 176 epochs of the v3 set they differ in three ways that matter
here: their dark pedestals differ by a median 4.33 mV (so each needs its own,
see ``check_pedestal``); PD1's dark noise is ~18x lower, to the point of being
quantization-limited at 1-2 telemetry LSB rather than resolved; and PD1's
response collapses by 5.7x at the longest band, 1670 nm, which is an InGaAs
cutoff. That last one is the reason PD1 is a check and not a candidate baseline
despite being the quieter device: it cannot see one sixth of the sequence. Every
correction in the pipeline is built on PD2. See ``PD_CORRECTION.md`` section 8.

A side swap changes the physical diode behind the same mnemonic name. ``PD2_V``
is ``PD2_V`` on both MCE sides, so nothing in the telemetry stream announces
that it is now reading a different device -- only the ``mce_side`` attribute
does, and on every product written so far it is *assumed* rather than read. The
per-epoch pedestal handles the swap by itself. The *reference* PD vector does
not, which is what ``--pd-reference per-side`` exists for.

The derivation costs no extra EDP requests. Every mnemonic needed here --
``WFI_MCE_SRCS_PD2_V``, ``WFI_MCE_SRCS_BANK2SEL_LED1..6``,
``WFI_MCE_SRCS_BANK2_LED_V``, plus ``PD1_V`` as a free which-bank check -- is
already inside ``rcs_telemetry.build_telemetry_table``'s single
``rcs_edp.query_mnemonics`` call. It just has to hand back the raw ``series``
alongside the sampled table, which it does under ``return_series=True``.

Deliberately dependency-light: numpy and pandas only. No astroquery, no
matplotlib, so ``--self-test`` stays credential-free and this module is
importable on a batch node.
"""
import dataclasses
import os
import sys

import numpy as np
import pandas as pd

import rcs_trend_config as cfg

TIME_COLUMN = "ObsTime"
VALUE_COLUMN = "EUValue"

PD_COLUMN = "WFI_MCE_SRCS_PD2_V"
FORWARD_COLUMN = "WFI_MCE_SRCS_BANK2_LED_V"

# PD1 is BANK1's *measurement* diode (rcs_products.py:317-318 selects the diode
# from the bank), so it is the spare here only because all flight trending is
# BANK2. It is not dark during a BANK2 sequence -- it sees the lamp too, see
# reduce_per_activity -- so the old "PD1 should be flat" reading of this channel
# was wrong and could never have fired.
#
# What it is good for: PD1 is InGaAs where PD2 is HgCdTe, a genuinely
# independent device with its own pedestal (4.33 mV below PD2's) and ~18x less
# dark noise. Reducing it costs nothing, it is already in the query, and it
# gives a second witness on every epoch. Two things it cannot do: substitute for
# PD2, because its InGaAs cutoff suppresses the 1670 nm band by 5.7x, and
# announce a side swap, because the mnemonic name is per-bank and never
# per-side. Recorded, never used in a correction.
PD_CHECK_COLUMN = "WFI_MCE_SRCS_PD1_V"

# Local copy of read_per_sca.LED_SELECT_COLUMNS, so importing this module does
# not drag in the asdf/roman stack. self_test() asserts the two still agree, so
# a rename over there fails loudly here rather than silently reducing against an
# empty set of select channels (which would read as "the LEDs were never on").
LED_SELECT_COLUMNS = [f"WFI_MCE_SRCS_BANK2SEL_LED{n}" for n in range(1, 7)]

MAD_TO_SIGMA = 1.4826

RULE_WINDOW = "window"
RULE_NEAREST = "nearest"
RULE_MISSING = "missing"


@dataclasses.dataclass
class StateInterval:
    """One run of constant LED-enable state on the PD's own sample grid."""

    state: int
    i_begin: int
    i_end: int               # exclusive
    t_begin: np.datetime64
    t_end: np.datetime64
    n_samples: int
    pd_median: float
    pd_mad: float
    is_transition: bool      # too few samples to be a state rather than a flip


@dataclasses.dataclass
class Pedestal:
    """The adopted dark-period PD level, and where it came from."""

    value: float
    rms: float
    n_samples: int
    source: str              # dark_window | pooled_off | nearest_off | unavailable
    drift_v_per_hr: float
    warnings: list = dataclasses.field(default_factory=list)


@dataclasses.dataclass
class ActivityPd:
    """The PD reduction for one activity's exposure window."""

    key: str
    number: int
    state_code: int
    hardware_led: object     # int 1-6, or None for dark/off/unknown/multiple
    pd_raw: float            # median over modal-state in-window samples
    pd_raw_all: float        # median over *all* in-window samples (legacy rule)
    pd_net: float            # pd_raw - pedestal
    pd_rms: float
    pd_n_samples: int
    forward_v: float
    pd_check_v: float        # the second diode, PD1 -- also lit, see pd_check_ratio
    pd_net_valid: bool
    state_pure: bool
    state_fraction: float
    is_dark: bool
    rule: str
    multiple_leds: bool
    n_railed: int = 0        # in-window samples clipped at cfg.PD_RAIL_V
    # Logically these belong beside pd_check_v; they carry defaults only because
    # dataclass ordering forces defaulted fields last.
    pd_check_net: float = np.nan    # pd_check_v minus PD1's own pedestal
    pd_check_ratio: float = np.nan  # pd_check_net / pd_net, the two-diode check
    warnings: list = dataclasses.field(default_factory=list)


@dataclasses.dataclass
class PdReduction:
    """Everything the ``photodiode/`` h5 group and the summary plot need."""

    times: np.ndarray
    pd_v: np.ndarray
    forward_v: np.ndarray
    pd_check_v: np.ndarray
    state: np.ndarray
    activity_index: np.ndarray
    intervals: list
    pedestal: Pedestal
    per_activity: list
    # PD1's pedestal, adopted by the same rule but from its *own* interval table
    # (see the check_intervals call in reduce_pd_stream). Present because PD1 is
    # lit too, so it needs a pedestal before it can be compared -- and because
    # the two diodes' pedestals genuinely differ, by a median 4.33 mV over the
    # 176-epoch v3 set, so PD2's is not a usable stand-in.
    check_pedestal: Pedestal = None
    warnings: list = dataclasses.field(default_factory=list)

    def photodiode_array(self):
        """``pd_net`` per activity -- the quantity the corrections should use."""
        return np.array([act.pd_net for act in self.per_activity], dtype=float)

    def legacy_photodiode_array(self):
        """The frozen compiler's ``pd_raw - pd_raw[dark]``, bit-for-bit.

        Kept because it is the only anchor that can show the new derivation
        against the old on already-written products: every existing h5 holds
        this array at ``dictionary/RCS_photodiode``. It uses ``pd_raw_all``
        (all in-window samples) and the *dark activity's own window*, not the
        pedestal, because those are the two choices the old code made.
        """
        raw = np.array([act.pd_raw_all for act in self.per_activity], dtype=float)
        if not len(raw):
            return raw
        dark = [i for i, act in enumerate(self.per_activity) if act.is_dark]

        return raw - raw[dark[0] if dark else 0]

    def legacy_delta(self):
        """``pd_net`` minus the legacy array: how much the new pedestal moved.

        A near-constant offset here is expected and harmless -- it cancels in
        every LED *ratio*. A per-LED spread is not, and is the thing to look at.
        """
        return self.photodiode_array() - self.legacy_photodiode_array()


def _column_series(series, column):
    """``(times, values)`` for one mnemonic, time-sorted; empty if unavailable."""
    frame = series.get(column) if series else None
    if frame is None or not len(frame) or TIME_COLUMN not in frame.columns:
        return (np.array([], dtype="datetime64[ns]"), np.array([], dtype=object))

    times = pd.to_datetime(frame[TIME_COLUMN], errors="coerce", utc=True)
    times = times.dt.tz_localize(None).to_numpy()
    values = frame.get(VALUE_COLUMN, pd.Series(dtype=object)).to_numpy()
    keep = ~pd.isna(times)
    times, values = times[keep], values[keep]
    order = np.argsort(times, kind="stable")

    return times[order], values[order]


def _step_values(channel_times, channel_values, times):
    """Last channel value at or before each ``times`` entry.

    Returns ``(values, known)``. ``known`` is False before the channel's first
    sample, which is the distinction the pedestal logic depends on: a select
    channel with no sample yet is **unknown, not DIS**. Treating it as DIS would
    declare the start of the query window "all LEDs off" and let a pedestal be
    adopted from an interval nobody has any telemetry for.
    """
    if not len(channel_times):
        return np.empty(len(times), dtype=object), np.zeros(len(times), dtype=bool)

    index = np.searchsorted(channel_times, times, side="right") - 1
    known = index >= 0
    values = channel_values[np.clip(index, 0, len(channel_values) - 1)]

    return values, known


def led_state_timeline(series, led_columns=None, pd_column=PD_COLUMN,
                       forward_column=FORWARD_COLUMN,
                       check_column=PD_CHECK_COLUMN):
    """Step the LED-enable states onto the photodiode's own sample grid.

    The PD is never resampled. Each select channel is instead stepped forward
    onto the PD's timestamps, because the PD is the measurement and the enables
    are a slower-cadence description of the instrument's configuration; the
    other direction would interpolate the quantity being measured.

    Returns ``(times, pd_v, forward_v, check_v, state)``. ``state`` is
    ``cfg.PD_STATE_UNKNOWN`` (-1) where no select channel has reported yet,
    ``cfg.PD_STATE_OFF`` (0) where all report DIS, ``1..6`` for the single
    enabled hardware LED, and ``cfg.PD_STATE_MULTIPLE`` (7) for more than one.
    """
    led_columns = LED_SELECT_COLUMNS if led_columns is None else led_columns
    times, pd_values = _column_series(series, pd_column)
    pd_v = pd.to_numeric(pd.Series(pd_values), errors="coerce").to_numpy(dtype=float)

    n = len(times)
    n_ena = np.zeros(n, dtype=int)
    n_unknown = np.zeros(n, dtype=int)
    which = np.zeros(n, dtype=int)
    for position, column in enumerate(led_columns, start=1):
        channel_times, channel_values = _column_series(series, column)
        values, known = _step_values(channel_times, channel_values, times)
        enabled = known & np.array(
            [str(value).strip().upper() == "ENA" for value in values], dtype=bool)
        n_ena += enabled
        n_unknown += ~known
        # Only meaningful where exactly one is enabled; the n_ena test below is
        # what decides whether this is read at all.
        which = np.where(enabled, position, which)

    state = np.full(n, cfg.PD_STATE_MULTIPLE, dtype=np.int8)
    state = np.where(n_ena == 1, which, state)
    state = np.where(n_ena == 0, cfg.PD_STATE_OFF, state)
    # Unknown only where we would otherwise have claimed "off". If some channel
    # reads ENA the sample is certainly not a pedestal candidate, so an unknown
    # neighbour cannot do any harm there.
    state = np.where((n_ena == 0) & (n_unknown > 0), cfg.PD_STATE_UNKNOWN, state)

    forward_v = _numeric_on_grid(series, forward_column, times)
    check_v = _numeric_on_grid(series, check_column, times)

    return times, pd_v, forward_v, check_v, state.astype(np.int8)


def _numeric_on_grid(series, column, times):
    """A numeric mnemonic stepped onto ``times``; all-NaN if unavailable."""
    channel_times, channel_values = _column_series(series, column)
    if not len(channel_times):
        return np.full(len(times), np.nan)

    numeric = pd.to_numeric(pd.Series(channel_values),
                            errors="coerce").to_numpy(dtype=float)
    values, known = _step_values(channel_times, numeric, times)

    return np.where(known, np.asarray(values, dtype=float), np.nan)


def _mad(values):
    finite = np.asarray(values, dtype=float)
    if not np.isfinite(finite).any():
        return np.nan

    return float(np.nanmedian(np.abs(finite - np.nanmedian(finite))))


def state_intervals(times, pd_v, state, min_samples=None):
    """Run-length encode the state timeline into :class:`StateInterval` records.

    Runs shorter than ``min_samples`` are kept but flagged ``is_transition``,
    rather than dropped or merged. One flipped telemetry sample must not be able
    to manufacture a state -- in particular it must not be able to manufacture a
    one-sample "all off" interval in the middle of an illuminated exposure and
    have that adopted as the pedestal.
    """
    min_samples = cfg.MIN_INTERVAL_SAMPLES if min_samples is None else min_samples
    state = np.asarray(state)
    if not len(state):
        return []

    edges = np.flatnonzero(np.diff(state) != 0) + 1
    bounds = np.concatenate(([0], edges, [len(state)]))

    intervals = []
    for i_begin, i_end in zip(bounds[:-1], bounds[1:]):
        window = pd_v[i_begin:i_end]
        intervals.append(StateInterval(
            state=int(state[i_begin]), i_begin=int(i_begin), i_end=int(i_end),
            t_begin=times[i_begin], t_end=times[i_end - 1],
            n_samples=int(i_end - i_begin),
            pd_median=float(np.nanmedian(window))
            if np.isfinite(window).any() else np.nan,
            pd_mad=_mad(window),
            is_transition=bool(i_end - i_begin < min_samples)))

    return intervals


def _overlaps(interval, t_start, t_end):
    return interval.t_begin <= t_end and interval.t_end >= t_start


def _drift_v_per_hr(intervals):
    """Least-squares slope through the per-off-interval medians.

    A drifting pedestal is the failure mode that a single adopted scalar cannot
    represent, so it is measured and reported rather than corrected: correcting
    it would mean choosing a model for the drift on the strength of two or three
    points.
    """
    usable = [iv for iv in intervals
              if iv.state == cfg.PD_STATE_OFF and not iv.is_transition
              and np.isfinite(iv.pd_median)]
    if len(usable) < 2:
        return np.nan

    origin = usable[0].t_begin
    hours = np.array([(iv.t_begin - origin) / np.timedelta64(1, "h")
                      for iv in usable], dtype=float)
    medians = np.array([iv.pd_median for iv in usable], dtype=float)
    if np.ptp(hours) == 0:
        return np.nan

    return float(np.polyfit(hours, medians, 1)[0])


def adopt_pedestal(times, pd_v, state, intervals, dark_window=None,
                   min_samples=None):
    """Choose the PD pedestal, preferring the off interval around the dark.

    Four sources, tried in order, each recorded in ``Pedestal.source`` so the
    choice is auditable from the product rather than inferred from the value:

    ``dark_window``
        An off interval overlapping the dark activity's exposure window. This is
        the one the design asks for -- the dark period's PD readings, which carry
        the pedestal and no signal.
    ``pooled_off``
        All non-transition off intervals pooled. Used when the dark window has no
        off interval of its own, which happens if the select channels only start
        reporting after the dark.
    ``nearest_off``
        The off samples closest in time, ignoring the run-length test. A last
        resort that is still a measurement.
    ``unavailable``
        NaN, and the epoch is flagged. Better than a plausible wrong number: the
        pedestal is a denominator's offset, so a wrong one is a fabricated
        instrument event.
    """
    min_samples = cfg.PEDESTAL_MIN_SAMPLES if min_samples is None else min_samples
    state = np.asarray(state)
    warnings = []
    drift = _drift_v_per_hr(intervals)

    candidates = [iv for iv in intervals
                  if iv.state == cfg.PD_STATE_OFF and not iv.is_transition
                  and iv.n_samples >= min_samples]

    chosen, source = [], "unavailable"
    if dark_window is not None and candidates:
        t_start, t_end = (np.datetime64(pd.Timestamp(dark_window[0])),
                          np.datetime64(pd.Timestamp(dark_window[1])))
        overlapping = [iv for iv in candidates if _overlaps(iv, t_start, t_end)]
        if overlapping:
            chosen, source = overlapping, "dark_window"

    if not chosen and candidates:
        chosen, source = candidates, "pooled_off"
        if dark_window is not None:
            warnings.append(
                "no all-off interval overlaps the dark exposure window; "
                "pedestal pooled over every off interval instead")

    if chosen:
        samples = np.concatenate([pd_v[iv.i_begin:iv.i_end] for iv in chosen])
    else:
        off = np.flatnonzero(state == cfg.PD_STATE_OFF)
        if len(off):
            samples, source = pd_v[off], "nearest_off"
            warnings.append(
                f"no all-off interval has {min_samples} samples; pedestal taken "
                f"from {len(off)} scattered off sample(s)")
        else:
            warnings.append(
                "no all-off photodiode samples in the query window; pedestal is "
                "unavailable and pd_net cannot be formed")
            return Pedestal(value=np.nan, rms=np.nan, n_samples=0,
                            source="unavailable", drift_v_per_hr=drift,
                            warnings=warnings)

    value = float(np.nanmedian(samples))
    rms = MAD_TO_SIGMA * _mad(samples)
    if np.isfinite(drift) and abs(drift) > max(3.0 * rms, 1e-3):
        warnings.append(
            f"pedestal drifts {drift:+.4f} V/hr across the off intervals, more "
            f"than 3x its own scatter ({rms:.4f} V); a single scalar pedestal "
            f"is a poor description of it")

    return Pedestal(value=value, rms=float(rms), n_samples=int(len(samples)),
                    source=source, drift_v_per_hr=drift, warnings=warnings)


def _modal_state(state_window):
    """The state holding the most in-window samples, preferring known ones.

    Unknown samples lose to any known state, however few: "we have no telemetry
    for part of this window" is not a competing description of the hardware.
    """
    values, counts = np.unique(state_window, return_counts=True)
    known = values != cfg.PD_STATE_UNKNOWN
    if known.any():
        values, counts = values[known], counts[known]

    return int(values[np.argmax(counts)])


def reduce_per_activity(times, pd_v, forward_v, check_v, state, activities,
                        pedestal, pd_min_net=None, check_pedestal=None):
    """Reduce the PD stream to one row per activity exposure window.

    In-window is ``t_start <= t <= t_end``, matching ``rcs_edp.sample_window`` so
    the comparison against the stored legacy arrays is like-for-like. The
    reduction then uses **only the modal-state samples**, which is the right
    answer when a window straddles an enable switch; ``state_fraction`` records
    how much of the window agreed, and ``state_pure`` whether all of it did.
    ``pd_raw_all`` keeps the all-samples median beside it, because that -- not
    the modal one -- is what the frozen compiler computed.

    ``activities`` is a list of dicts with ``key``, ``number``, ``t_start``,
    ``t_end``, ``is_dark``, and optionally ``edp_led`` and ``meta_led`` for the
    three-way hardware-LED cross-check.
    """
    pd_min_net = cfg.PD_MIN_NET if pd_min_net is None else pd_min_net
    times = np.asarray(times)
    rows = []

    for activity in activities:
        t_start = np.datetime64(pd.Timestamp(activity["t_start"]))
        t_end = np.datetime64(pd.Timestamp(activity["t_end"]))
        inside = np.flatnonzero((times >= t_start) & (times <= t_end))

        rule, warnings = RULE_WINDOW, []
        if not len(inside) and len(times):
            # Same fallback rcs_edp.sample_window uses: the PD cadence can be
            # slower than one exposure, and an empty column is worse than a
            # labelled substitution.
            midpoint = t_start + (t_end - t_start) / 2
            inside = np.array([int(np.argmin(np.abs(times - midpoint)))])
            rule = RULE_NEAREST

        if not len(inside):
            rows.append(ActivityPd(
                key=activity.get("key", ""), number=int(activity.get("number", 0)),
                state_code=cfg.PD_STATE_UNKNOWN, hardware_led=None,
                pd_raw=np.nan, pd_raw_all=np.nan, pd_net=np.nan, pd_rms=np.nan,
                pd_n_samples=0, forward_v=np.nan, pd_check_v=np.nan,
                pd_net_valid=False, state_pure=False, state_fraction=np.nan,
                is_dark=bool(activity.get("is_dark", False)), rule=RULE_MISSING,
                multiple_leds=False,
                warnings=["no photodiode samples for this activity window"]))
            continue

        state_window = np.asarray(state)[inside]
        modal = _modal_state(state_window)
        fraction = float(np.count_nonzero(state_window == modal) / len(state_window))
        modal_rows = inside[state_window == modal]

        pd_raw = float(np.nanmedian(pd_v[modal_rows]))
        pd_raw_all = float(np.nanmedian(pd_v[inside]))
        hardware_led = modal if 1 <= modal <= 6 else None

        for source in ("edp_led", "meta_led"):
            claimed = activity.get(source)
            if claimed is not None and hardware_led is not None \
                    and int(claimed) != hardware_led:
                # All three are reported rather than one silently winning: a
                # mismatch means a flat may be attributed to the wrong lamp, and
                # which source is wrong is not knowable from here.
                warnings.append(
                    f"hardware LED disagreement for {activity.get('key', '?')}: "
                    f"state timeline says LED{hardware_led}, {source} says "
                    f"LED{int(claimed)}")

        pd_net = pd_raw - pedestal.value
        valid = bool(np.isfinite(pd_net) and pd_net > pd_min_net)
        if hardware_led is not None and not valid:
            warnings.append(
                f"pd_net = {pd_net:.5f} V is at or below PD_MIN_NET "
                f"({pd_min_net} V) for an illuminated activity; refusing to form "
                f"a response factor from it")
        # The photodiode rails at cfg.PD_RAIL_V. On the passes measured so far
        # every railed sample lands in an inter-exposure gap while the drive
        # settles, never inside a window -- but a railed sample is clipped
        # rather than measured, so one inside a window would pull pd_raw up and
        # inflate the response factor in the direction that looks like the lamp
        # brightening. Counted, not clipped: clipping would hide it.
        n_railed = int(np.count_nonzero(pd_v[modal_rows] >= cfg.PD_RAIL_V))
        if n_railed:
            warnings.append(
                f"{n_railed} of {len(modal_rows)} in-window photodiode samples "
                f"for {activity.get('key', '?')} are railed at "
                f"{cfg.PD_RAIL_V} V; pd_raw = {pd_raw:.5f} V is biased high by "
                f"clipped data, not measured")

        if modal == cfg.PD_STATE_MULTIPLE:
            warnings.append(
                f"more than one LED enabled during {activity.get('key', '?')}")
        if not activity.get("is_dark", False) and fraction < 1.0:
            warnings.append(
                f"{activity.get('key', '?')} window straddles an enable change; "
                f"only {fraction:.0%} of its samples are state {modal}")

        # The second diode. PD1 is NOT dark during the sequence -- measured on 21
        # epochs of the good set, it sees the lamp at 1.03-1.20x PD2's net for
        # five of the six LEDs and 0.205x for hardware LED 5.
        #
        # Mind the two LED numberings, which do not agree. ``hardware_led`` is
        # the BANK2SEL channel number; cfg.LED_WAVELENGTHS is keyed by the
        # *sequence* names the activity keys use, and the map between them is
        # LED1->hw6, LED2->hw1, LED3->hw2, LED4->hw3, LED5->hw4, LED6->hw5
        # (verified on 40 v3 epochs, no exceptions). So the suppressed channel,
        # hardware LED 5, is the sequence's LED6 at **1670 nm** -- the longest
        # band, not 1481 nm. In band order the ratio reads 1.135 / 1.056 / 1.163
        # / 1.193 / 1.168 at 624-1481 nm and then 0.205 at 1670 nm: flat to +-6%
        # and then a cliff. That is the InGaAs cutoff, which sits near 1.7 um and
        # moves shorter as the diode cools. An earlier version of this comment
        # read the wavelength off the hardware number and concluded the dip was
        # at 1481 nm and therefore *not* a cutoff, which is why the numbering is
        # now spelled out wherever a hardware LED number appears.
        #
        # So the useful check is not "PD1 is flat" but "PD1/PD2 holds its per-LED
        # value": that ratio repeats to ~1100 ppm across the trend, so a change
        # in it separates a lamp change (both diodes move together, ratio fixed)
        # from a diode or mapping change (ratio moves) -- including an MCE side
        # swap, which no mnemonic name reports. Recorded, never corrected with.
        check_raw = (float(np.nanmedian(check_v[modal_rows]))
                     if np.isfinite(check_v[modal_rows]).any() else np.nan)
        check_net = (check_raw - check_pedestal.value
                     if check_pedestal is not None else np.nan)
        check_ratio = (check_net / pd_net
                       if np.isfinite(pd_net) and abs(pd_net) > pd_min_net
                       else np.nan)

        rows.append(ActivityPd(
            key=activity.get("key", ""), number=int(activity.get("number", 0)),
            state_code=modal, hardware_led=hardware_led,
            pd_raw=pd_raw, pd_raw_all=pd_raw_all, pd_net=float(pd_net),
            pd_rms=float(MAD_TO_SIGMA * _mad(pd_v[modal_rows])),
            pd_n_samples=int(len(modal_rows)),
            forward_v=float(np.nanmedian(forward_v[modal_rows]))
            if np.isfinite(forward_v[modal_rows]).any() else np.nan,
            pd_check_v=check_raw, pd_check_net=check_net,
            pd_check_ratio=check_ratio,
            pd_net_valid=valid, state_pure=bool(fraction == 1.0),
            state_fraction=fraction,
            is_dark=bool(activity.get("is_dark", False)), rule=rule,
            multiple_leds=bool(modal == cfg.PD_STATE_MULTIPLE),
            n_railed=n_railed, warnings=warnings))

    return rows


def _activity_index(times, activities):
    """Which activity's window each PD sample falls in; -1 for none."""
    index = np.full(len(times), -1, dtype=np.int8)
    for position, activity in enumerate(activities):
        t_start = np.datetime64(pd.Timestamp(activity["t_start"]))
        t_end = np.datetime64(pd.Timestamp(activity["t_end"]))
        index[(times >= t_start) & (times <= t_end)] = position

    return index


def reduce_photodiode(series, activities, led_columns=None,
                      pd_column=PD_COLUMN, forward_column=FORWARD_COLUMN,
                      check_column=PD_CHECK_COLUMN, min_interval_samples=None,
                      pedestal_min_samples=None, pd_min_net=None, quiet=False):
    """Full PD reduction for one trending epoch.

    Parameters
    ----------
    series : dict
        ``{mnemonic: DataFrame}`` from ``rcs_edp.query_mnemonics``, as returned
        by ``rcs_telemetry.build_telemetry_table(..., return_series=True)``.
    activities : list of dict
        One per activity in write order, with ``key``, ``number``, ``t_start``,
        ``t_end``, ``is_dark``, optionally ``edp_led`` / ``meta_led``.

    Returns
    -------
    PdReduction
    """
    times, pd_v, forward_v, check_v, state = led_state_timeline(
        series, led_columns=led_columns, pd_column=pd_column,
        forward_column=forward_column, check_column=check_column)

    warnings = []
    if not len(times):
        warnings.append(f"no {pd_column} samples in the query window; the "
                        f"photodiode cannot be reduced for this epoch")

    intervals = state_intervals(times, pd_v, state,
                                min_samples=min_interval_samples)
    dark = [a for a in activities if a.get("is_dark", False)]
    dark_window = (dark[0]["t_start"], dark[0]["t_end"]) if dark else None
    if dark_window is None:
        warnings.append("no dark activity in this epoch; the pedestal cannot "
                        "use the dark window")

    pedestal = adopt_pedestal(times, pd_v, state, intervals,
                              dark_window=dark_window,
                              min_samples=pedestal_min_samples)

    # PD1 gets its own pedestal from its own intervals. The run-length structure
    # depends only on ``state``, so check_intervals partitions time identically
    # and differs from ``intervals`` only in the medians -- which is exactly what
    # makes the drift slope inside adopt_pedestal describe PD1 rather than PD2.
    # Reusing ``intervals`` here would have quietly reported PD2's drift twice.
    check_intervals = state_intervals(times, check_v, state,
                                      min_samples=min_interval_samples)
    check_pedestal = adopt_pedestal(times, check_v, state, check_intervals,
                                    dark_window=dark_window,
                                    min_samples=pedestal_min_samples)
    per_activity = reduce_per_activity(times, pd_v, forward_v, check_v, state,
                                       activities, pedestal,
                                       pd_min_net=pd_min_net,
                                       check_pedestal=check_pedestal)

    reduction = PdReduction(
        times=times, pd_v=pd_v, forward_v=forward_v, pd_check_v=check_v,
        state=state, activity_index=_activity_index(times, activities),
        intervals=intervals, pedestal=pedestal, per_activity=per_activity,
        check_pedestal=check_pedestal, warnings=warnings)

    if not quiet:
        report(reduction)

    return reduction


def pd_activities(activities, edp_leds=None):
    """Adapt ``process_rcs_trending``'s activity entries to this module's input.

    ``edp_leds`` is the telemetry table's ``edp_led`` column (``'LED3'``,
    ``'DRK'``, ``'MULTIPLE'``). It comes from the *same* BANK2SEL enables as the
    state timeline but by a different rule -- mode over the whole exposure
    window, rather than the median over the modal state's own samples -- so
    comparing the two is a real check on this module's windowing rather than a
    tautology.

    The L2 ``meta.rcs.led`` value is deliberately not supplied as a third
    source. It counts LEDs in *activity* order, not hardware order, so it
    disagrees by construction for every activity; the permutation is
    ``(6, 1, 2, 3, 4, 5)`` and ``rcs_telemetry.report_led_order`` already
    asserts it. Feeding it in here would emit six warnings an epoch and say
    nothing.
    """
    rows = []
    for position, entry in enumerate(activities):
        claimed = None
        if edp_leds is not None and position < len(edp_leds):
            text = str(edp_leds[position]).strip().upper()
            if text.startswith("LED") and text[3:].isdigit():
                claimed = int(text[3:])
        rows.append({
            "key": entry.get("key", ""),
            "number": entry.get("activity_number", position + 1),
            "t_start": entry["start_time"],
            "t_end": entry["end_time"] or entry["start_time"],
            "is_dark": bool(entry.get("is_dark", False)),
            "edp_led": claimed})

    return rows


def to_table(reduction, **meta):
    """The per-activity reduction as an astropy ``Table``, ready for ECSV.

    astropy is imported here rather than at module scope so that importing this
    module stays numpy+pandas only.
    """
    from astropy.table import Table

    columns = ["key", "number", "state_code", "hardware_led", "pd_raw",
               "pd_raw_all", "pd_net", "pd_rms", "pd_n_samples", "forward_v",
               "pd_check_v", "pd_check_net", "pd_check_ratio",
               "pd_net_valid", "state_pure", "state_fraction",
               "is_dark", "rule", "n_railed"]
    data = {name: [] for name in columns}
    for activity in reduction.per_activity:
        for name in columns:
            value = getattr(activity, name)
            # hardware_led is None for the dark, which astropy cannot type.
            data[name].append(-1 if name == "hardware_led" and value is None
                              else value)

    table = Table(data)
    table["pd_net_legacy"] = reduction.legacy_photodiode_array()
    pedestal = reduction.pedestal
    table.meta.update({
        "pedestal_v": pedestal.value, "pedestal_rms_v": pedestal.rms,
        "pedestal_n_samples": pedestal.n_samples,
        "pedestal_source": pedestal.source,
        "pedestal_drift_v_per_hr": pedestal.drift_v_per_hr,
        "check_pedestal_v": (reduction.check_pedestal.value
                             if reduction.check_pedestal else np.nan),
        # PD1's dark scatter. Written to the h5 group already, and carried here
        # too because it is not redundant with PD2's: the two are *different
        # devices*, and the pair of numbers is the whole measurement -- PD1's
        # dark sigma runs ~18x below PD2's, and at 1-2 telemetry quanta it is
        # bounded by the stream's resolution rather than measured. Without this
        # key that comparison is only available from the h5.
        "check_pedestal_rms_v": (reduction.check_pedestal.rms
                                 if reduction.check_pedestal else np.nan),
        "check_pedestal_source": (reduction.check_pedestal.source
                                  if reduction.check_pedestal else "absent"),
        "check_pedestal_drift_v_per_hr": (
            reduction.check_pedestal.drift_v_per_hr
            if reduction.check_pedestal else np.nan),
        "pd_check_column": PD_CHECK_COLUMN,
        "pd_column": PD_COLUMN, "pd_min_net": cfg.PD_MIN_NET,
        "pd_rail_v": cfg.PD_RAIL_V,
        "n_railed_in_window": int(sum(a.n_railed
                                      for a in reduction.per_activity)),
        "n_pd_samples": int(len(reduction.times)),
        "n_state_intervals": len(reduction.intervals),
        "warnings": reduction.warnings + pedestal.warnings})
    table.meta.update(meta)

    return table


def write_photodiode_group(path, reduction, group="photodiode", run_label=None):
    """Write the reduction into an h5 as a self-contained ``photodiode/`` group.

    **Additive only, by deliberate choice.** The plan's Phase 4 line says
    ``dictionary/RCS_photodiode`` should be recomputed from ``pd_net``, but doing
    that in the *legacy* product would break the bit-exact regression against
    /data/eswitzer/rcs_trend that Phases 1 and 7 both test against -- and that
    anchor is worth more than the substitution, because the substitution buys
    almost nothing. Measured over all 34 passes of the good set: ``pd_net``
    differs from the stored array by at most 26 telemetry quanta (7.8e-06 V),
    the difference is a *common* offset across the six LEDs to within 3e-17, and
    it therefore cancels exactly in the ``reference_pd / epoch_pd`` ratio that
    ``led_scale_factors`` forms. Worst-case residual impact on a response factor
    is 33.6 ppm. So the new derivation is written beside the old one rather than
    over it; the RAW per-SCA writer in ``rcs_products`` (Phase 5) is where
    ``dictionary/`` gets populated from ``pd_net``, since that product has no
    bit-exactness obligation to honour.

    h5py is imported here, not at module scope, for the same reason astropy is
    in :func:`to_table`: importing this module stays numpy+pandas only, so
    ``--self-test`` and a batch node pay for neither.
    """
    import h5py

    def put(handle, name, values, dtype=None):
        array = np.asarray(values)
        if array.dtype.kind in "US" or dtype == "str":
            array = np.asarray([str(v) for v in values],
                               dtype=h5py.string_dtype())
        handle.create_dataset(name, data=array, compression=None)

    with h5py.File(path, "a") as handle:
        # Only set when asked, and only if absent: on a staged product
        # annotate_h5 owns this attribute, and this writer must not race it.
        # Standalone PD sidecars have no annotate_h5 pass, so they need it set
        # here or every downstream plot falls back to parsing the filename.
        if run_label is not None and "run_label" not in handle.attrs:
            handle.attrs["run_label"] = run_label
        if group in handle:
            del handle[group]
        root = handle.create_group(group)

        stream = root.create_group("stream")
        # Stored as epoch nanoseconds: h5py has no datetime64, and an ISO string
        # per sample would cost more than the PD values themselves.
        put(stream, "time", reduction.times.astype("datetime64[ns]").astype(np.int64))
        stream["time"].attrs["units"] = "nanoseconds since 1970-01-01T00:00:00"
        put(stream, "pd_v", reduction.pd_v)
        put(stream, "forward_v", reduction.forward_v)
        put(stream, "pd_check_v", reduction.pd_check_v)
        put(stream, "state", np.asarray(reduction.state, dtype=np.int8))
        put(stream, "activity_index",
            np.asarray(reduction.activity_index, dtype=np.int8))

        intervals = root.create_group("intervals")
        put(intervals, "state", [iv.state for iv in reduction.intervals])
        put(intervals, "t_begin", [np.datetime64(iv.t_begin, "ns").astype(np.int64)
                                   for iv in reduction.intervals])
        put(intervals, "t_end", [np.datetime64(iv.t_end, "ns").astype(np.int64)
                                 for iv in reduction.intervals])
        put(intervals, "n_samples", [iv.n_samples for iv in reduction.intervals])
        put(intervals, "pd_median", [iv.pd_median for iv in reduction.intervals])
        put(intervals, "pd_mad", [iv.pd_mad for iv in reduction.intervals])
        put(intervals, "is_transition",
            [iv.is_transition for iv in reduction.intervals])

        for name, source in (("pedestal", reduction.pedestal),
                             ("check_pedestal", reduction.check_pedestal)):
            if source is None:
                continue
            node = root.create_group(name)
            for field in ("value", "rms", "n_samples", "drift_v_per_hr"):
                node.attrs[field] = getattr(source, field)
            node.attrs["source"] = source.source
            node.attrs["warnings"] = [str(w) for w in source.warnings]

        per = root.create_group("per_activity")
        activities = reduction.per_activity
        put(per, "activity_key", [a.key for a in activities], dtype="str")
        put(per, "rule", [a.rule for a in activities], dtype="str")
        # hardware_led is None for the dark, which h5py cannot type; -1 is the
        # same sentinel to_table uses, so the ECSV and the h5 agree.
        put(per, "hardware_led", [-1 if a.hardware_led is None else a.hardware_led
                                  for a in activities])
        for field in ("number", "state_code", "pd_raw", "pd_raw_all", "pd_net",
                      "pd_rms", "pd_n_samples", "forward_v", "pd_check_v",
                      "pd_check_net", "pd_check_ratio", "pd_net_valid",
                      "state_pure", "state_fraction", "is_dark",
                      "multiple_leds", "n_railed"):
            put(per, field, [getattr(a, field) for a in activities])
        put(per, "pd_net_legacy", reduction.legacy_photodiode_array())

        root.attrs["pd_column"] = PD_COLUMN
        root.attrs["pd_check_column"] = PD_CHECK_COLUMN
        root.attrs["forward_column"] = FORWARD_COLUMN
        root.attrs["pd_min_net"] = cfg.PD_MIN_NET
        root.attrs["pd_rail_v"] = cfg.PD_RAIL_V
        root.attrs["n_railed_in_window"] = int(sum(a.n_railed for a in activities))
        root.attrs["dictionary_is_legacy"] = True
        root.attrs["warnings"] = [str(w) for w in reduction.warnings]

    return path


def read_photodiode_group(path, group="photodiode"):
    """Rebuild a :class:`PdReduction` from a ``photodiode/`` group.

    The inverse of :func:`write_photodiode_group`, and the reason the sequence
    timeline plot costs nothing: the PD stream is ~2600 samples, so every
    diagnostic that needs it can read it back out of an already-written product
    instead of re-querying the EDP. Returns ``None`` if the group is absent,
    which is the normal case for any product staged before the writer existed.

    ``i_begin``/``i_end`` are not stored -- they are indices into the stream, so
    they are recovered by searching the stream times rather than persisted, which
    keeps the group's interval table independent of the stream's own length.
    """
    import h5py

    def text(value):
        return value.decode() if isinstance(value, bytes) else str(value)

    with h5py.File(path, "r") as handle:
        if group not in handle:
            return None
        root = handle[group]
        stream = root["stream"]
        times = stream["time"][...].astype("datetime64[ns]")
        pd_v = stream["pd_v"][...]
        forward_v = stream["forward_v"][...]
        check_v = stream["pd_check_v"][...]
        state = stream["state"][...].astype(int)
        activity_index = stream["activity_index"][...].astype(int)

        node = root["intervals"]
        t_begin = node["t_begin"][...].astype("datetime64[ns]")
        t_end = node["t_end"][...].astype("datetime64[ns]")
        begins = np.searchsorted(times, t_begin, side="left")
        ends = np.searchsorted(times, t_end, side="right")
        intervals = [
            StateInterval(state=int(node["state"][i]),
                          i_begin=int(begins[i]), i_end=int(ends[i]),
                          t_begin=t_begin[i], t_end=t_end[i],
                          n_samples=int(node["n_samples"][i]),
                          pd_median=float(node["pd_median"][i]),
                          pd_mad=float(node["pd_mad"][i]),
                          is_transition=bool(node["is_transition"][i]))
            for i in range(len(t_begin))]

        pedestals = {}
        for name in ("pedestal", "check_pedestal"):
            if name not in root:
                pedestals[name] = None
                continue
            attrs = root[name].attrs
            pedestals[name] = Pedestal(
                value=float(attrs["value"]), rms=float(attrs["rms"]),
                n_samples=int(attrs["n_samples"]),
                source=text(attrs["source"]),
                drift_v_per_hr=float(attrs["drift_v_per_hr"]),
                warnings=[text(w) for w in attrs.get("warnings", [])])

        per = root["per_activity"]
        activities = []
        for i in range(len(per["activity_key"])):
            hardware = int(per["hardware_led"][i])
            activities.append(ActivityPd(
                key=text(per["activity_key"][i]),
                number=int(per["number"][i]),
                state_code=int(per["state_code"][i]),
                hardware_led=None if hardware < 1 else hardware,
                pd_raw=float(per["pd_raw"][i]),
                pd_raw_all=float(per["pd_raw_all"][i]),
                pd_net=float(per["pd_net"][i]),
                pd_rms=float(per["pd_rms"][i]),
                pd_n_samples=int(per["pd_n_samples"][i]),
                forward_v=float(per["forward_v"][i]),
                pd_check_v=float(per["pd_check_v"][i]),
                pd_net_valid=bool(per["pd_net_valid"][i]),
                state_pure=bool(per["state_pure"][i]),
                state_fraction=float(per["state_fraction"][i]),
                is_dark=bool(per["is_dark"][i]),
                rule=text(per["rule"][i]),
                multiple_leds=bool(per["multiple_leds"][i]),
                n_railed=int(per["n_railed"][i]),
                pd_check_net=float(per["pd_check_net"][i]),
                pd_check_ratio=float(per["pd_check_ratio"][i])))

        return PdReduction(
            times=times, pd_v=pd_v, forward_v=forward_v, pd_check_v=check_v,
            state=state, activity_index=activity_index, intervals=intervals,
            pedestal=pedestals["pedestal"], per_activity=activities,
            check_pedestal=pedestals["check_pedestal"],
            warnings=[text(w) for w in root.attrs.get("warnings", [])])


def enable_runs(reduction):
    """One record per activity describing its LED-enable run and its settle.

    This is the measurement behind the sequence timeline plot, and it is where
    the LED turn-on transient is quantified. For each activity it finds the
    contiguous run of the activity's own hardware-LED state nearest that
    activity's exposure window, then reports when the PD became *readable*
    inside that run.

    The settle is not a smooth ramp. Measured identically on CAR-190 pass 1 and
    CAR-216 pass 66 -- two weeks and two different activity sequences apart --
    the six LEDs split cleanly into two groups:

    * hardware LEDs 6, 1 and 2 reach their exposure level within a single 1 Hz
      sample; there is no observable transient at this cadence;
    * hardware LEDs 3, 4 and 5 drive the PD **into a 2.5 V clip** for 64, 52 and
      35 s respectively, then drop to the exposure level as the forward voltage
      settles (1.3111 V -> 0.9778 V for hardware LED 3).

    2.5 V is a saturation limit of the readout, not a physical plateau, and the
    distinction is what justifies refusing to interpret the level. Proof: over
    the 64 s that hardware LED 3 sits there, 149 of 152 samples read 2.5000000 V
    to within one telemetry quantum (2.98e-07 V) while the forward voltage is
    still visibly drifting, 1.31113 -> 1.30647. An unclipped analog signal cannot
    hold the same LSB for a minute while its own drive changes.

    So the transient's *amplitude* is unmeasurable and only its duration is
    reported -- hence ``rail_seconds`` rather than an overshoot level. The lone
    sample per step that exceeds 2.5 V (3.81187 V on CAR-190 pass 1) is not
    headroom: it falls exactly on the drive step, where the forward voltage is
    also mid-transition (1.17407, between 1.30647 and 0.97779), so it is one
    sample integrating across the switch.

    What matters operationally is ``settle_margin_s``: the gap between the PD
    coming back on-scale and the start of the exposure. It is 56-59 s for exactly
    the three LEDs that clip and 16-18 s for the three that do not, so the
    observing sequence already allocates a longer lead where the hardware needs
    one. A *negative* margin would mean an exposure integrating while the PD was
    off-scale -- the failure this function exists to detect, and one that would
    silently corrupt that LED's ``pd_net`` denominator. None occurs in any pass
    examined.

    Returns a list of dicts, one per activity with a resolvable hardware LED.
    """
    rail = cfg.PD_RAIL_V
    times, state = reduction.times, reduction.state
    records = []
    for position, activity in enumerate(reduction.per_activity):
        led = activity.hardware_led
        exposure = np.flatnonzero(reduction.activity_index == position)
        if led is None or not len(exposure):
            continue
        enabled = np.flatnonzero(state == led)
        if not len(enabled):
            continue
        # Split into contiguous runs and take the one bracketing this exposure.
        # The four CAR-216 AUX_LED3FLAT activities share a single enable run, so
        # "nearest to this exposure" is the only rule that assigns all four
        # correctly; keying on run order would give them all the same lead time.
        runs = np.split(enabled, np.flatnonzero(np.diff(enabled) > 1) + 1)
        run = min(runs, key=lambda r: abs(int(r[0]) - int(exposure[0])))
        origin = times[run[0]]
        seconds = lambda index: float(
            (times[index] - origin) / np.timedelta64(1, "s"))

        railed = run[reduction.pd_v[run] >= rail - 1e-6]
        # One sample past the last railed one is the first that is on-scale; with
        # no railed samples the PD is readable from the first sample after enable.
        settled = (seconds(railed[-1]) + 1.0) if len(railed) else 1.0
        records.append({
            "key": activity.key,
            "hardware_led": led,
            "enable_seconds": seconds(run[-1]),
            "rail_seconds": int(len(railed)),
            "settled_at_s": settled,
            "exposure_start_s": seconds(exposure[0]),
            "exposure_seconds": seconds(exposure[-1]) - seconds(exposure[0]),
            "settle_margin_s": seconds(exposure[0]) - settled,
            "pd_exposure_v": float(np.nanmedian(reduction.pd_v[exposure])),
            "t_enable": origin,
            "t_settled": origin + np.timedelta64(int(settled * 1e9), "ns"),
            "t_exposure_begin": times[exposure[0]],
            "t_exposure_end": times[exposure[-1]],
        })

    return records


def report(reduction):
    """Print the per-epoch PD summary, warnings first."""
    pedestal = reduction.pedestal
    print(f"  PD: {len(reduction.times)} sample(s), "
          f"{len(reduction.intervals)} state interval(s); pedestal "
          f"{pedestal.value:.5f} +/- {pedestal.rms:.5f} V from "
          f"{pedestal.source} ({pedestal.n_samples} sample(s))")
    for message in reduction.warnings + pedestal.warnings:
        print(f"    WARNING: {message}")
    for activity in reduction.per_activity:
        led = ("dark" if activity.is_dark
               else (f"LED{activity.hardware_led}" if activity.hardware_led
                     else f"state {activity.state_code}"))
        flag = "" if activity.pd_net_valid or activity.is_dark else "  INVALID"
        print(f"    {activity.key or activity.number:>10} {led:>6}: "
              f"raw {activity.pd_raw:.5f}  net {activity.pd_net:.5f} V  "
              f"n={activity.pd_n_samples:<5d} pure={activity.state_fraction:.0%} "
              f"{activity.rule}{flag}")
        for message in activity.warnings:
            print(f"      WARNING: {message}")

    delta = reduction.legacy_delta()
    if np.isfinite(delta).any():
        # The spread, not the offset: a common offset cancels in every LED ratio
        # the corrections actually form, so it is the per-LED variation that
        # would change a result.
        print(f"    vs legacy pd_raw-pd_raw[dark]: offset "
              f"{np.nanmedian(delta):+.5f} V, spread "
              f"{np.nanstd(delta):.2e} V")


# PD1's net response relative to PD2's, keyed by **hardware** LED (the BANK2SEL
# channel number, not the sequence name -- see reduce_per_activity for the map).
# Rounded from the 21-epoch measurement on /data/eswitzer/rcs_trend so the
# synthetic series exercises the same shape the real data has -- in particular
# hardware LED 5, which is the sequence's LED6 at 1670 nm, sits at a fifth of
# the others because of PD1's InGaAs cutoff, and would be mistaken for a fault
# by a self-test that assumed the two diodes track.
CHECK_RATIO_NOMINAL = {1: 1.057, 2: 1.165, 3: 1.195, 4: 1.168, 5: 0.205, 6: 1.135}

# Hardware LED (the BANK2SEL channel number) -> the sequence name the activity
# table and ``cfg.LED_WAVELENGTHS`` use. Verified on 40 v3 epochs, 40/40 on
# every entry, and the same permutation ``rcs_telemetry.report_led_order``
# asserts from the other direction.
#
# This exists as a dict rather than a sentence because the two keyings have
# been crossed before: ``cfg.LED_WAVELENGTHS`` is keyed by *sequence* name, so
# looking up hardware LED 5 as "LED5" returns 1481 nm when the channel is
# actually at 1670 nm. That one substitution turned PD1's 5.7x suppression into
# a dip at 1481 nm with full response restored at 1670 nm -- physically absurd
# for a photodiode -- and the absurdity was written down as a finding ("not a
# detector cutoff") instead of as a bug. It is the InGaAs cutoff. ``self_test``
# pins the map against the wavelength table so it cannot invert again.
SEQUENCE_LED_FOR_HARDWARE = {6: "LED1", 1: "LED2", 2: "LED3",
                             3: "LED4", 4: "LED5", 5: "LED6"}


def _synthetic_series(n_per=40, pedestal=0.1164, signal=0.25, dark_gap=10,
                      check_pedestal=0.1121):
    """A fake EDP ``series`` for self_test: dark, then LED1..6 in turn."""
    start = pd.Timestamp("2026-09-22T00:00:00")
    times, pd_values, forward, selects = [], [], [], {c: [] for c in LED_SELECT_COLUMNS}
    check = []

    def emit(when, pd_value, forward_value, enabled):
        times.append(when)
        pd_values.append(pd_value)
        forward.append(forward_value)
        # PD1 carries its own pedestal and its own per-LED gain, so pd_check_net
        # / pd_net comes back as CHECK_RATIO_NOMINAL and not as 1.
        check.append(check_pedestal + (0.0 if enabled is None else
                                       (pd_value - pedestal)
                                       * CHECK_RATIO_NOMINAL[enabled]))
        for position, column in enumerate(LED_SELECT_COLUMNS, start=1):
            selects[column].append("ENA" if position == enabled else "DIS")

    clock = start
    for _ in range(n_per):                      # the dark: all off
        emit(clock, pedestal, 0.0, None)
        clock += pd.Timedelta(seconds=1)
    for led in range(1, 7):
        for _ in range(dark_gap):               # off between exposures
            emit(clock, pedestal, 0.0, None)
            clock += pd.Timedelta(seconds=1)
        for _ in range(n_per):
            emit(clock, pedestal + signal + 0.001 * led, 1.5 + 0.01 * led, led)
            clock += pd.Timedelta(seconds=1)

    series = {PD_COLUMN: pd.DataFrame({TIME_COLUMN: times, VALUE_COLUMN: pd_values}),
              FORWARD_COLUMN: pd.DataFrame({TIME_COLUMN: times, VALUE_COLUMN: forward}),
              PD_CHECK_COLUMN: pd.DataFrame({TIME_COLUMN: times,
                                             VALUE_COLUMN: check})}
    for column, values in selects.items():
        series[column] = pd.DataFrame({TIME_COLUMN: times, VALUE_COLUMN: values})

    activities = [{"key": "dark", "number": 1, "t_start": start,
                   "t_end": start + pd.Timedelta(seconds=n_per - 1),
                   "is_dark": True}]
    offset = n_per
    for led in range(1, 7):
        offset += dark_gap
        activities.append({"key": f"LED{led}", "number": led + 1,
                           "t_start": start + pd.Timedelta(seconds=offset),
                           "t_end": start + pd.Timedelta(seconds=offset + n_per - 1),
                           "is_dark": False})
        offset += n_per

    return series, activities, pedestal, signal


def self_test():
    """Exercise the reduction on synthetic telemetry. No credentials needed."""
    failures = []

    try:
        import read_per_sca as rps
        if list(rps.LED_SELECT_COLUMNS) != list(LED_SELECT_COLUMNS):
            failures.append(
                f"LED_SELECT_COLUMNS has drifted from read_per_sca's: "
                f"{LED_SELECT_COLUMNS} vs {list(rps.LED_SELECT_COLUMNS)}")
    except ImportError as error:
        print(f"  (read_per_sca not importable here, skipping the "
              f"LED_SELECT_COLUMNS cross-check: {error})")

    series, activities, pedestal, signal = _synthetic_series()
    reduction = reduce_photodiode(series, activities, quiet=True)

    if reduction.pedestal.source != "dark_window":
        failures.append(f"pedestal source is {reduction.pedestal.source!r}, "
                        f"expected 'dark_window'")
    if not np.isclose(reduction.pedestal.value, pedestal, atol=1e-9):
        failures.append(f"pedestal {reduction.pedestal.value} != {pedestal}")

    leds = [a for a in reduction.per_activity if not a.is_dark]
    if [a.hardware_led for a in leds] != [1, 2, 3, 4, 5, 6]:
        failures.append(f"hardware LEDs came out as "
                        f"{[a.hardware_led for a in leds]}, expected 1..6")
    if not all(a.state_pure for a in reduction.per_activity):
        failures.append("some synthetic activity window is not state-pure, but "
                        "every one was built inside a single enable state")
    for position, activity in enumerate(leds, start=1):
        want = signal + 0.001 * position
        if not np.isclose(activity.pd_net, want, atol=1e-9):
            failures.append(f"LED{position} pd_net {activity.pd_net} != {want}")
        if not activity.pd_net_valid:
            failures.append(f"LED{position} pd_net was marked invalid")
        # The second diode must come back on its own pedestal with its own
        # per-LED gain. A reduction that reused PD2's pedestal for PD1, or that
        # compared raw levels instead of nets, fails here -- and LED5 fails
        # loudest, which is the point of keeping its real 0.205 in the fixture.
        want_ratio = CHECK_RATIO_NOMINAL[position]
        if not np.isclose(activity.pd_check_ratio, want_ratio, atol=1e-6):
            failures.append(f"LED{position} pd_check_ratio "
                            f"{activity.pd_check_ratio} != {want_ratio}")

    # The two diodes are different devices, and the fixture gives them
    # different dark levels (0.1121 against 0.1164) for that reason. Asserted
    # directly rather than only through the ratio: a reduction that reused
    # PD2's pedestal for PD1 would still produce *a* ratio, just a wrong one,
    # and the real offset is 4.33 mV on a 0.116 V pedestal.
    if reduction.check_pedestal is None:
        failures.append("PD1 got no pedestal of its own from a series that "
                        "carries its channel")
    else:
        if np.isclose(reduction.check_pedestal.value, reduction.pedestal.value,
                      atol=1e-6):
            failures.append(
                f"PD1's pedestal {reduction.check_pedestal.value} came back "
                f"equal to PD2's {reduction.pedestal.value}; they are "
                f"different detectors and the fixture separates them by 4.3 mV")
        if not np.isclose(reduction.check_pedestal.value, 0.1121, atol=1e-9):
            failures.append(f"PD1's pedestal {reduction.check_pedestal.value} "
                            f"!= the planted 0.1121")
        if not np.isfinite(reduction.check_pedestal.rms):
            failures.append("PD1's pedestal rms is not finite, so the ECSV "
                            "meta key check_pedestal_rms_v carries nothing")

    # The hardware/sequence keying, pinned. CHECK_RATIO_NOMINAL is keyed by
    # hardware LED and cfg.LED_WAVELENGTHS by sequence name; crossing them is
    # what once inverted the conclusion about PD1's cutoff. See
    # SEQUENCE_LED_FOR_HARDWARE.
    if sorted(SEQUENCE_LED_FOR_HARDWARE) != list(range(1, 7)) or \
            sorted(SEQUENCE_LED_FOR_HARDWARE.values()) != sorted(cfg.LED_NAMES):
        failures.append(f"SEQUENCE_LED_FOR_HARDWARE is not a permutation of "
                        f"1..6 onto {cfg.LED_NAMES}: "
                        f"{SEQUENCE_LED_FOR_HARDWARE}")
    else:
        suppressed = min(CHECK_RATIO_NOMINAL, key=CHECK_RATIO_NOMINAL.get)
        name = SEQUENCE_LED_FOR_HARDWARE[suppressed]
        nanometres = float(cfg.LED_WAVELENGTHS[name].to_value("nm"))
        longest = max(float(v.to_value("nm"))
                      for v in cfg.LED_WAVELENGTHS.values())
        if (suppressed, name) != (5, "LED6"):
            failures.append(f"the suppressed PD1 channel is hardware "
                            f"{suppressed} -> {name}, expected 5 -> LED6")
        if abs(nanometres - 1670.0) > 1.0:
            failures.append(f"the suppressed channel reads {nanometres:.0f} nm, "
                            f"expected 1670; 1481 is the mislabel")
        if nanometres != longest:
            failures.append(f"the suppressed channel is not the longest band "
                            f"({nanometres:.0f} vs {longest:.0f} nm), so it "
                            f"cannot be read as a cutoff")
        others = [v for k, v in CHECK_RATIO_NOMINAL.items() if k != suppressed]
        if max(others) / min(others) > 1.2:
            failures.append(f"the five short bands are not flat to ~6% "
                            f"({min(others):.3f}..{max(others):.3f}), so the "
                            f"shape is not a band edge")
        if min(others) / CHECK_RATIO_NOMINAL[suppressed] < 4.0:
            failures.append("the suppressed band is less than 4x down on the "
                            "others; CHECK_RATIO_NOMINAL no longer carries the "
                            "cutoff the fixture exists to exercise")

    dark = [a for a in reduction.per_activity if a.is_dark][0]
    if abs(dark.pd_net) > 1e-9:
        failures.append(f"the dark's pd_net is {dark.pd_net}, expected 0 -- the "
                        f"pedestal came from its own off interval")
    if not np.allclose(reduction.legacy_delta(), 0.0, atol=1e-9):
        failures.append("the legacy mirror disagrees with pd_net on synthetic "
                        "data where the dark window *is* the off interval")

    # The guard that matters: an illuminated activity whose pd_raw equals the
    # pedestal must be refused, not turned into a ~60x response factor.
    flat = dict(series)
    flat[PD_COLUMN] = flat[PD_COLUMN].copy()
    flat[PD_COLUMN][VALUE_COLUMN] = pedestal
    degenerate = reduce_photodiode(flat, activities, quiet=True)
    if any(a.pd_net_valid for a in degenerate.per_activity if not a.is_dark):
        failures.append("pd_net == 0 for an illuminated activity was accepted; "
                        "PD_MIN_NET is not being enforced")

    # A railed exposure must be reported, not silently averaged in. The real
    # passes have railed samples only in the inter-exposure gaps, so this
    # condition has to be provoked to be tested at all.
    railed = dict(series)
    railed[PD_COLUMN] = railed[PD_COLUMN].copy()
    railed[PD_COLUMN].loc[65, VALUE_COLUMN] = cfg.PD_RAIL_V
    clipped = reduce_photodiode(railed, activities, quiet=True)
    hit = [a for a in clipped.per_activity if a.n_railed]
    if len(hit) != 1 or not any("railed" in w for w in hit[0].warnings):
        failures.append(f"a railed in-window sample was not counted and "
                        f"warned about (got {[a.n_railed for a in clipped.per_activity]})")

    # The h5 group must round-trip and, critically, must NOT have touched
    # dictionary/ -- that is the whole basis of the bit-exact regression the
    # legacy products are still checked against.
    try:
        import tempfile

        import h5py

        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "probe.h5")
            with h5py.File(path, "w") as handle:
                handle.create_dataset("dictionary/RCS_photodiode",
                                      data=np.arange(7, dtype=float))
            write_photodiode_group(path, reduction)
            with h5py.File(path, "r") as handle:
                sentinel = handle["dictionary/RCS_photodiode"][...]
                if not np.array_equal(sentinel, np.arange(7, dtype=float)):
                    failures.append("write_photodiode_group modified "
                                    "dictionary/, which must stay legacy")
                stored = handle["photodiode/per_activity/pd_net"][...]
                want = reduction.photodiode_array()
                if not np.allclose(stored, want, equal_nan=True):
                    failures.append("photodiode/per_activity/pd_net did not "
                                    "round-trip through the h5")
                if handle["photodiode/pedestal"].attrs["source"] != "dark_window":
                    failures.append("the pedestal source did not survive the "
                                    "round-trip into h5 attributes")
                if len(handle["photodiode/stream/pd_v"]) != len(reduction.times):
                    failures.append("the PD stream was truncated on write")
                # Re-writing must be idempotent, not raise or duplicate: a
                # restaged pass lands on an h5 that already has the group.
            write_photodiode_group(path, reduction)
    except ImportError:
        print("  SKIP h5 round-trip: h5py is not importable")

    # A select channel that only starts reporting mid-window must leave the
    # earlier samples unknown rather than off, or the pedestal can be adopted
    # from an interval with no telemetry behind it.
    late = dict(series)
    late[LED_SELECT_COLUMNS[0]] = series[LED_SELECT_COLUMNS[0]].iloc[100:].copy()
    times, _, _, _, state = led_state_timeline(late)
    if state[0] != cfg.PD_STATE_UNKNOWN:
        failures.append(f"a sample before a select channel's first reading came "
                        f"out as state {state[0]}, expected "
                        f"{cfg.PD_STATE_UNKNOWN} (unknown)")

    # A single flipped sample inside an exposure must not become a state.
    flipped = dict(series)
    column = LED_SELECT_COLUMNS[0]
    flipped[column] = series[column].copy()
    flipped[column].loc[60, VALUE_COLUMN] = "DIS"
    times, pd_v, _, _, state = led_state_timeline(flipped)
    intervals = state_intervals(times, pd_v, state)
    singletons = [iv for iv in intervals
                  if iv.state == cfg.PD_STATE_OFF and iv.n_samples == 1]
    if not all(iv.is_transition for iv in singletons):
        failures.append("a one-sample off interval was not flagged as a "
                        "transition")

    for message in failures:
        print(f"  FAIL {message}")
    print(f"rcs_photodiode.self_test: "
          f"{'FAILED' if failures else 'ok'} ({len(failures)} failure(s))")

    return not failures


if __name__ == "__main__":
    sys.exit(0 if self_test() else 1)
