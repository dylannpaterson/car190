"""
Engineering Data Portal (EDP) client for the flight RCS trending path.

The TVAC products carry the full housekeeping telemetry inside themselves, as a
single ~2500-key string under ``meta.groundtest.hdf5_telemetry`` (see
``read_per_sca.parse_telemetry``). Flight L2 products have no ``groundtest``
branch at all, so the same mnemonics have to be fetched from the EDP web service
instead. The mnemonic names are assumed unchanged, but that is not universally
true: ``WFI_MCU_A/B_MPA_CSENS_FPSSEN_K`` and ``WFI_COBA_WTSC10P_K`` (both used
by ``read_per_sca.HK_COLUMNS`` for TVAC telemetry) are absent from the live EDP
mnemonic dictionary as of 2026-09 -- see :func:`mnemonic_metadata`.

This duplicates the approach of ``notebooks/engineering_database_retrieval/``
as a HOWTO reference rather than importing it. Only the
streaming half is reproduced here, plus new windowed
sampling that turns a timeseries into one value per exposure.

Uses ``urllib`` rather than ``requests`` so this adds no dependency beyond
``pandas``.
"""
import io
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

import numpy as np
import pandas as pd

EDP_URL = "https://mast.stsci.edu/edp/api/v0.1/mnemonics/spa/roman/data"
METADATA_URL = "https://mast.stsci.edu/edp/api/v0.1/mnemonics/spa/roman/metadata"

# EDP response columns. 'ObsTime' is an ISO-T UTC string, 'EUValue' the value in
# engineering units -- a float for the temperatures/voltages and a string
# ('ENA'/'DIS') for the LED enable mnemonics.
TIME_COLUMN = "ObsTime"
VALUE_COLUMN = "EUValue"

# How a sampled value was obtained, recorded alongside it so the provenance
# table can show that a given activity's telemetry came from outside its
# exposure window.
RULE_WINDOW = "window"
RULE_NEAREST = "nearest"
RULE_MISSING = "missing"


def edp_token(dotenv_path="./variables.env"):
    """Return the MAST API token, loading ``variables.env`` if present.

    Follows the convention the repo's other astroquery entry points use (see
    ``scripts/astroquery_cron/astroquery_cron_example.py``): a ``variables.env``
    file holding ``MAST_API_TOKEN='...'``, falling back to the bare environment
    variable. Deliberately does *not* touch ``shared/CASSI_query.py``, which
    calls ``load_env_file()`` at import time and raises if ``~/.env`` is absent.
    """
    if dotenv_path and os.path.exists(dotenv_path):
        try:
            from dotenv import load_dotenv
        except ImportError:
            pass
        else:
            load_dotenv(dotenv_path=dotenv_path)

    token = os.getenv("MAST_API_TOKEN")
    if not token:
        raise RuntimeError(
            "MAST_API_TOKEN is not set. Create a token at "
            "https://auth.mast.stsci.edu/info and either export it or put "
            f"MAST_API_TOKEN='...' in {dotenv_path}.")

    return token


def compact_iso(when):
    """Format a time as ``YYYY-MM-DDTHH:MM:SS`` (UTC) for the EDP query params.

    The service takes this form for both ``s_time`` and ``e_time``. It used to
    also accept the compact ``YYYYMMDDTHHMMSS`` form (hence the name, kept for
    the two existing call sites); as of 2026-09 that form instead fails with a
    422 ``datetime_from_date_parsing`` error, so the dashed/colon form is now
    the only one that works.
    """
    stamp = pd.Timestamp(when)
    if stamp.tz is not None:
        stamp = stamp.tz_convert("UTC").tz_localize(None)

    return stamp.strftime("%Y-%m-%dT%H:%M:%S")


def mnemonic_metadata(pattern="", token=None):
    """Look up EDP mnemonics matching ``pattern`` (substring, case-sensitive).

    Hits the dictionary endpoint the EDP web UI itself calls -- undocumented in
    the v0.1 API surface but the only way to check whether a mnemonic exists
    without spending a full :func:`query_mnemonics` round trip on it. Metadata
    is limited to storage type (``rawType``/``EUType``/``sqlType``); there are
    no human-readable descriptions, and ``subsystem`` reads ``"unknown"`` for
    every entry as of 2026-09.

    An empty pattern returns the full dictionary (~20k rows as of 2026-09).
    """
    token = edp_token() if token is None else token
    query = f"?{urllib.parse.urlencode({'mnemonic': pattern})}" if pattern else ""
    request = urllib.request.Request(
        f"{METADATA_URL}{query}", headers={"Authorization": f"token {token}"})
    with urllib.request.urlopen(request, timeout=120) as response:
        payload = json.loads(response.read())

    return pd.DataFrame(payload.get("TlmMnemonics", []))


def _fetch_csv(mnemonic, t_start, t_end, token, retries=3, backoff=2.0):
    """GET one mnemonic's timeseries as raw CSV text, or None on failure.

    Returning None rather than raising is deliberate: a run should not be lost
    because one of 21 housekeeping mnemonics is unavailable. The caller reports
    the gap and the affected column ends up NaN, which is visible in the CSV.
    """
    query = urllib.parse.urlencode({
        "mnemonic": mnemonic,
        "s_time": t_start,
        "e_time": t_end,
        "result_format": "csv",
    })
    request = urllib.request.Request(
        f"{EDP_URL}?{query}", headers={"Authorization": f"token {token}"})

    for attempt in range(1, retries + 1):
        try:
            with urllib.request.urlopen(request, timeout=300) as response:
                return response.read().decode("utf-8")
        except (urllib.error.URLError, TimeoutError) as error:
            if attempt == retries:
                print(f"    EDP {mnemonic}: giving up after {retries} "
                      f"attempts ({error})")

                return None
            wait = backoff ** attempt
            print(f"    EDP {mnemonic}: attempt {attempt} failed ({error}); "
                  f"retrying in {wait:.0f}s")
            time.sleep(wait)

    return None


def query_mnemonics(mnemonics, t_start, t_end, token=None, retries=3):
    """Stream a set of mnemonic timeseries into memory.

    Parameters
    ----------
    mnemonics : iterable of str
        EDP mnemonic names, e.g. ``WFI_MCE_SRCS_SPHERE_T``.
    t_start, t_end : str or datetime-like
        Bounds of the query window; passed through :func:`compact_iso`.

    Returns
    -------
    dict
        ``{mnemonic: DataFrame or None}``, each frame carrying at least
        ``ObsTime`` and ``EUValue``. None means the fetch failed or the service
        returned nothing parseable.
    """
    token = edp_token() if token is None else token
    t_start, t_end = compact_iso(t_start), compact_iso(t_end)

    series = {}
    for mnemonic in mnemonics:
        text = _fetch_csv(mnemonic, t_start, t_end, token, retries=retries)
        frame = None
        if text and text.strip():
            try:
                frame = pd.read_csv(io.StringIO(text))
            except (pd.errors.ParserError, pd.errors.EmptyDataError) as error:
                print(f"    EDP {mnemonic}: unparseable response ({error})")
        if frame is not None and TIME_COLUMN not in frame.columns:
            print(f"    EDP {mnemonic}: response has no {TIME_COLUMN!r} column "
                  f"(got {list(frame.columns)})")
            frame = None
        series[mnemonic] = frame

    found = sum(f is not None and len(f) for f in series.values())
    print(f"  EDP {t_start}..{t_end}: {len(mnemonics)} mnemonics, "
          f"{found} total samples")

    return series


def _to_naive_utc(values):
    """Parse a time column to a tz-naive UTC ``Series``, index preserved.

    EDP returns ISO-T strings; the MAST exposure times may or may not carry a
    trailing 'Z'. Normalising both sides here keeps the window comparison from
    silently failing on a tz-aware/tz-naive mismatch.

    The index has to survive: the caller selects out of ``EUValue`` with the
    boolean mask and the ``idxmin`` computed from this, so a reset index would
    misalign times from values.
    """
    parsed = pd.to_datetime(pd.Series(values), errors="coerce", utc=True)

    return parsed.dt.tz_localize(None)


def sample_window(frame, t_start, t_end, how="median"):
    """Reduce one mnemonic timeseries to a single value over an exposure window.

    Returns ``(value, rule)``, where ``rule`` records how the value was obtained
    -- see ``RULE_*``. The nearest-sample fallback matters in practice: EDP
    sampling cadences are per-mnemonic and can be slower than a single exposure,
    so requiring an in-window sample would leave real columns empty. Recording
    which rule fired keeps that substitution auditable rather than invisible.

    ``how='median'`` is for the numeric housekeeping mnemonics; ``how='mode'``
    is for the string-valued LED enables, where averaging is meaningless.
    """
    if frame is None or len(frame) == 0:
        return (np.nan if how == "median" else ""), RULE_MISSING

    times = _to_naive_utc(frame[TIME_COLUMN])
    values = frame[VALUE_COLUMN]
    t_start, t_end = pd.Timestamp(t_start), pd.Timestamp(t_end)
    if t_start.tz is not None:
        t_start = t_start.tz_convert("UTC").tz_localize(None)
    if t_end.tz is not None:
        t_end = t_end.tz_convert("UTC").tz_localize(None)

    inside = (times >= t_start) & (times <= t_end)
    if inside.any():
        return _reduce(values[inside], how), RULE_WINDOW

    # Nothing inside: fall back to whichever sample sits closest to the middle
    # of the window.
    midpoint = t_start + (t_end - t_start) / 2
    offsets = (times - midpoint).abs()
    if offsets.notna().any():
        return _reduce(values[[offsets.idxmin()]], how), RULE_NEAREST

    return (np.nan if how == "median" else ""), RULE_MISSING


def _reduce(values, how):
    """Collapse a selection of EDP values to one, numerically or by mode."""
    if how == "median":
        numeric = pd.to_numeric(values, errors="coerce")

        return float(np.nanmedian(numeric)) if numeric.notna().any() else np.nan

    if how == "mode":
        text = values.astype(str).str.strip()
        counts = text.value_counts()

        return str(counts.index[0]) if len(counts) else ""

    raise ValueError(f"unknown reduction {how!r}; expected 'median' or 'mode'")


def sample_activities(series, windows, numeric_columns, string_columns):
    """Sample every mnemonic at every activity's exposure window.

    Parameters
    ----------
    series : dict
        Output of :func:`query_mnemonics`.
    windows : list of (t_start, t_end)
        One exposure window per activity, in the order the rows will be written.
    numeric_columns, string_columns : list of str
        Mnemonics reduced by median and by mode respectively.

    Returns
    -------
    (list of dict, list of dict)
        Per-activity ``{mnemonic: value}`` rows, and the matching
        ``{mnemonic: rule}`` provenance rows.
    """
    rows, rules = [], []
    for t_start, t_end in windows:
        row, rule = {}, {}
        for column in numeric_columns:
            row[column], rule[column] = sample_window(
                series.get(column), t_start, t_end, how="median")
        for column in string_columns:
            value, which = sample_window(
                series.get(column), t_start, t_end, how="mode")
            # The compiler tests for equality with 'ENA', so an unknown state
            # must land on the safe side rather than on an empty string.
            row[column] = value if value else "DIS"
            rule[column] = which
        rows.append(row)
        rules.append(rule)

    return rows, rules


def enabled_leds(row, led_columns):
    """Which LED enables are asserted in one sampled row.

    Returns the bare suffixes (``['LED6']``). Kept separate from
    ``read_per_sca.enabled_led`` because this one reports *all* matches so the
    caller can distinguish "no LED" (a dark) from "more than one" (a fault)
    rather than collapsing both to a sentinel string.
    """
    return [column.split("_")[-1] for column in led_columns
            if str(row.get(column, "")).strip() == "ENA"]


# ---------------------------------------------------------------------------
# When did a mnemonic change, and by how much
# ---------------------------------------------------------------------------
#
# The questions behind these two helpers were all "what happened between two
# passes": the 2026-10-09 enclosure setpoint change (WFI_MCE_HTR_SETPOINT_06-09,
# 132 -> 139 at 05:11), the ACM move at 2026-10-08 23:09 that preceded it, and
# the ACM sweep of 2026-10-07 between passes 72 and 73. The products sample
# telemetry at the exposures only, so anything between passes has to come
# from the EDP timeseries. ``trend_change_check.py telemetry`` is the command
# line.

def edp_series(frame, dropout=None):
    """One :func:`query_mnemonics` frame as a float ``Series`` on UTC time.

    Sorted, duplicate times dropped, non-numeric values dropped. ``dropout`` is
    a value the readout reports when it has no reading -- the ACM LVDT reads
    exactly 0 for ~10 min at a time (2026-10-06 22:08-22:18) -- removed before
    anything is computed, so a dropout cannot be mistaken for a move.
    """
    if frame is None or not len(frame):
        return pd.Series(dtype=float)
    values = pd.to_numeric(frame[VALUE_COLUMN], errors="coerce").to_numpy()
    times = _to_naive_utc(frame[TIME_COLUMN]).to_numpy()
    series = pd.Series(values, index=pd.DatetimeIndex(times)).sort_index()
    series = series[~series.index.duplicated()].dropna()
    if dropout is not None:
        series = series[series != dropout]
    return series


def find_steps(series, min_step=None, smooth=5, merge="5min", n_level=10,
               noise_factor=10.0, n_flicker=50):
    """Episodes where ``series`` moves by more than ``min_step``.

    A step is a change of more than ``min_step`` between neighbouring samples
    of the ``smooth``-sample running median (which rejects single-sample
    glitches). ``min_step=None`` sets it per series at ``noise_factor`` times
    the 99th percentile of that change, so a mnemonic's own readout jitter (the
    LVDT's +-1 count) never chains into an episode, while a setpoint, whose
    jitter is zero, counts any change at all. A slow ramp (a thermistor
    warming over a day) is not a step at either setting; read it off the
    medians instead.

    A quantized thermistor that sits on one ADC level and flickers to the next
    on under 1 % of samples has a 99th percentile of zero, which made every
    flicker a step (the telescope's TCEA_TME_EXT_THERMISTOR_* read ~1000
    zero-size episodes over two weeks, 2026-10-30). So when a series has more
    than ``n_flicker`` nonzero jumps, the median nonzero jump (one quantum)
    also sets a floor. A setpoint's only nonzero jumps are its real changes,
    far fewer than that, so it still counts any change.

    Steps closer than ``merge`` are one episode -- a sweep or a settling
    transient -- reported as ``{"start", "end", "n_steps", "before",
    "after", "threshold"}``. ``before`` is the median of the ``n_level``
    samples preceding the episode and ``after`` of the ``n_level`` following
    it, by count rather than time, so a dropout gap next to a step does not
    leave a level empty.
    """
    if len(series) < 2:
        return []
    level = series.rolling(smooth, center=True, min_periods=1).median()
    jumps = level.diff().abs()
    if min_step is None:
        jitter = float(np.nanquantile(jumps.dropna(), 0.99))
        moved = jumps[jumps > 0]
        if len(moved) > n_flicker:
            jitter = max(jitter, float(moved.median()))
        min_step = noise_factor * jitter
    hits = jumps.index[jumps > min_step]
    if not len(hits):
        return []
    merge = pd.Timedelta(merge)
    episodes, start, end, count = [], hits[0], hits[0], 1
    for when in hits[1:]:
        if when - end > merge:
            episodes.append((start, end, count))
            start, count = when, 0
        end, count = when, count + 1
    episodes.append((start, end, count))

    out = []
    for start, end, count in episodes:
        before = series[series.index < start].tail(n_level)
        after = series[series.index > end].head(n_level)
        out.append({"start": start, "end": end, "n_steps": count,
                    "threshold": min_step,
                    "before": float(before.median()) if len(before) else np.nan,
                    "after": float(after.median()) if len(after) else np.nan})
    return out


def find_excursions(series, min_change, edge="2h", grid="15min",
                    min_duration="1h"):
    """Every sustained departure of more than ``min_change`` from the baseline.

    :func:`find_steps` is blind to a heater bump by construction: the AOM bump
    of 2026-10-30 took the AOM thermistor +5.15 K over about 14 h, never more
    than a quantum or two per sample. The baseline here is the median of the
    first ``edge`` of the window; the level is the median on a ``grid``; an
    excursion is a run of grid points more than ``min_change`` from the
    baseline lasting at least ``min_duration``. A first version compared only
    the window's two ends, and so reported nothing for the AOM and AMS bumps
    once both had come back down (2026-11-05): a test bump goes up AND down.

    Each excursion is ``{"baseline", "level", "change", "rise", "fall",
    "returned"}``: ``level`` its plateau (the median of the grid points within
    20 % of its largest departure), ``rise`` the times it was first 10, 50 and
    90 % of the way up, ``fall`` the times it was last above 90, 50 and 10 %
    on the way back, and ``returned`` whether it came back inside the window
    (if not, ``fall`` is empty: a lasting change, or a bump still on). Swings
    smaller than ``min_change`` (the +/-0.3 K that come and go on the telescope
    thermistors) are never excursions.
    """
    if len(series) < 2:
        return []
    edge, min_duration = pd.Timedelta(edge), pd.Timedelta(min_duration)
    start, end = series.index[0], series.index[-1]
    if end - start < 3 * edge:
        return []
    baseline = float(series[series.index < start + edge].median())
    level = series.resample(grid).median().dropna()
    if not np.isfinite(baseline) or level.empty:
        return []
    away = (level - baseline).abs() > min_change
    runs, first = [], None
    for k, flag in enumerate(away.to_numpy()):
        if flag and first is None:
            first = k
        if not flag and first is not None:
            runs.append((first, k - 1))
            first = None
    if first is not None:
        runs.append((first, len(level) - 1))
    times = level.index
    out, search_from = [], 0
    for lo, hi in runs:
        if times[hi] - times[lo] < min_duration:
            continue
        deviation = level.iloc[lo:hi + 1] - baseline
        peak = float(deviation.abs().max())
        near = deviation[deviation.abs() >= 0.8 * peak]
        change = float(near.median())
        progress = ((level - baseline) / change).to_numpy()
        returned = hi < len(level) - 1
        rise = {}
        for frac in (10, 50, 90):
            hits = [k for k in range(search_from, hi + 1)
                    if progress[k] >= frac / 100.0]
            rise[frac] = times[hits[0]] if hits else None
        fall = {}
        if returned:
            top = max(k for k in range(lo, hi + 1) if progress[k] >= 0.9)
            for frac in (90, 50, 10):
                hits = [k for k in range(top + 1, len(level))
                        if progress[k] < frac / 100.0]
                fall[frac] = times[hits[0]] if hits else None
        out.append({"baseline": baseline, "level": baseline + change,
                    "change": change, "rise": rise, "fall": fall,
                    "returned": returned})
        search_from = hi + 1
    return out


def self_test(verbose=True):
    """``edp_series`` and ``find_steps`` on a synthetic setpoint and LVDT."""
    failures = []

    def check(name, ok, detail=""):
        if not ok:
            failures.append(f"{name}: {detail}")
        if verbose:
            print(f"    {'ok  ' if ok else 'FAIL'} {name}"
                  f"{('  ' + detail) if detail and not ok else ''}")

    times = pd.date_range("2026-10-09T04:00", periods=240, freq="1min")
    setpoint = np.where(times < pd.Timestamp("2026-10-09T05:11"), 132.0, 139.0)
    lvdt = -3310.0 + np.random.default_rng(1).integers(-1, 2, len(times))
    lvdt[120:] += 450.0
    lvdt[30:40] = 0.0                       # a readout dropout
    lvdt[200] = -9000.0                     # a one-sample glitch

    def frame(values):
        return pd.DataFrame({TIME_COLUMN: times.strftime("%Y-%m-%dT%H:%M:%S"),
                             VALUE_COLUMN: values})

    steps = find_steps(edp_series(frame(setpoint)))
    check("a setpoint change is one step at the right minute",
          len(steps) == 1 and steps[0]["start"] == pd.Timestamp(
              "2026-10-09T05:11") and steps[0]["before"] == 132.0
          and steps[0]["after"] == 139.0, str(steps))
    raw = find_steps(edp_series(frame(lvdt)), min_step=50)
    clean = find_steps(edp_series(frame(lvdt), dropout=0.0), min_step=50)
    check("a dropout to 0 reads as a move unless it is removed",
          len(raw) == 3 and len(clean) == 1, f"{len(raw)} raw, {len(clean)}")
    check("the move's before/after levels are read off its neighbours",
          clean and abs(clean[0]["before"] + 3310.0) <= 1
          and abs(clean[0]["after"] + 2860.0) <= 1, str(clean))
    auto = find_steps(edp_series(frame(lvdt), dropout=0.0))
    check("the automatic threshold ignores +-1 count jitter but not a move",
          len(auto) == 1 and auto[0]["threshold"] < 450, str(auto))
    many = pd.date_range("2026-10-09T00:00", periods=20000, freq="1s")
    flicker = np.full(len(many), 217.672)
    for start in range(0, len(many), 400):  # one quantum, dwelling 10 s, so
        flicker[start:start + 10] += 0.004  # the running median keeps it
    flicker[15000:] += 0.5                  # a real heater step
    therm = find_steps(edp_series(pd.DataFrame({
        TIME_COLUMN: many.strftime("%Y-%m-%dT%H:%M:%S"),
        VALUE_COLUMN: flicker})))
    check("a quantized thermistor's flicker is not a step, its bump is",
          len(therm) == 1 and abs(therm[0]["after"] - therm[0]["before"]
                                  - 0.5) < 0.01, str(therm[:3]))
    day = pd.date_range("2026-10-30T00:00", periods=24 * 360, freq="10s")
    hours = (day - day[0]).total_seconds() / 3600
    bump = 217.672 + 5.148 * np.clip((hours - 2) / 10, 0, 1) \
        + 0.004 * (np.arange(len(day)) % 7 == 0)
    ramp = find_excursions(pd.Series(bump, index=day), 1.0)
    check("a heater ramp is found, timed and sized; its steps are not",
          len(ramp) == 1 and abs(ramp[0]["change"] - 5.148) < 0.01
          and not ramp[0]["returned"]
          and abs((ramp[0]["rise"][50] - pd.Timestamp("2026-10-30T07:00"))
                  .total_seconds()) <= 900
          and not find_steps(pd.Series(bump, index=day)), str(ramp))
    swing = 230.8 + 0.3 * np.sin(2 * np.pi * hours / 8)
    check("a swing that comes and goes is not an excursion",
          find_excursions(pd.Series(swing, index=day), 1.0) == [])
    week = pd.date_range("2026-11-01T00:00", periods=7 * 24 * 60, freq="1min")
    days = (week - week[0]).total_seconds() / 86400
    there_and_back = 267.0 + 5.0 * (np.clip((days - 1) * 4, 0, 1)
                                    - np.clip((days - 4) * 4, 0, 1))
    bumps = find_excursions(pd.Series(there_and_back, index=week), 1.0)
    check("a bump that comes back is one excursion, with rise and fall times",
          len(bumps) == 1 and bumps[0]["returned"]
          and abs(bumps[0]["change"] - 5.0) < 0.01
          and abs((bumps[0]["rise"][50] - pd.Timestamp("2026-11-02T03:00"))
                  .total_seconds()) <= 900
          and abs((bumps[0]["fall"][50] - pd.Timestamp("2026-11-05T03:00"))
                  .total_seconds()) <= 900, str(bumps))
    near_gap = lvdt.copy()
    near_gap[110:120] = 0.0
    gap = find_steps(edp_series(frame(near_gap), dropout=0.0), min_step=50)
    check("a dropout gap beside a step leaves no level empty",
          len(gap) == 1 and np.isfinite(gap[0]["before"]), str(gap))
    check("an empty frame is an empty series",
          edp_series(None).empty and find_steps(edp_series(None), 1) == [])

    if verbose:
        print(f"  rcs_edp.self_test: "
              f"{'OK' if not failures else str(len(failures)) + ' FAILURE(S)'}")
    for failure in failures:
        print(f"    {failure}")
    return not failures


if __name__ == "__main__":
    import sys
    sys.exit(0 if self_test() else 1)
