"""Diagnostic figures for stage 2, read back from the calibrated products.

Distinct from :mod:`rcs_trend_plots`, which plots what a *single* epoch's
product contains, and from :mod:`digest_plots`, which plots digest quantities
(response versus time, bridge steps). This module plots stage 2 across the whole
set: what the calibration actually multiplied into the arrays, and whether it
was able to.

The reason this is worth a figure at all: in a schema-1 product stage 2's
corrections were *multiplied into the data and then not recoverable from it*,
so the ``calibration/`` group was the only record of how a pixel got its value.
In schema 2 nothing is multiplied in, and the group is instead the *only source*
of the factors every consumer applies -- the same weight, for the opposite
reason. Both schemas are read; schema 2's per-step ``(6, 18)`` multipliers are
mapped onto the per-LED fields below by :class:`_FactorView`. Three failure
modes are invisible in the trend but obvious here:

* a photodiode factor that is really a near-zero ``pd_net`` denominator, which
  arrives as a 10-60x spike that looks exactly like a real instrument event;
* a per-LED factor drifting away from the others, which is either a real lamp
  divergence or a pedestal problem, and the decomposition says which;
* an epoch whose factors are NaN, which the trend shows as a gap rather than as
  the refusal it is.

Everything is read from ``calibration/`` and the root attributes, never
recomputed, so the figure shows what was applied rather than what should have
been.
"""
import os
import textwrap
import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt    # noqa: E402
import numpy as np                 # noqa: E402

import rcs_trend_config as cfg     # noqa: E402

__all__ = ["collect_calibration", "plot_calibration_factors",
           "plot_calibration_coverage", "write_all", "self_test"]

LED_COLORS = ["#d62728", "#ff7f0e", "#bcbd22", "#2ca02c", "#1f77b4", "#9467bd"]

# Each panel names the question it answers rather than the array it draws, so a
# reader who did not write the pipeline can tell which panel to look at.
FACTOR_PANELS = [
    ("pd_factor", "photodiode\nreference / epoch",
     "lamp output drift; 1.0 at the start of each MCE side"),
    ("side_factor", "side bridge",
     "per-LED step across an MCE side swap; the present side is 1"),
    ("acm_factor", "ACM piston", "source-to-focal-plane distance"),
    ("total_factor", "total per LED",
     "photodiode x side / ACM; recorded (schema 2) or applied (schema 1)"),
]


def _as_str(value):
    return value.decode() if isinstance(value, bytes) else str(value)


def _span_hours(handle):
    """Epoch wall-clock span in hours, from the root time attributes.

    Needed to turn the pedestal's drift rate into the thing that actually
    matters: how far the pedestal moved between the dark activity it was
    measured in and the farthest lit activity it is subtracted from.
    """
    try:
        start = np.datetime64(_as_str(handle.attrs["time_start"])[:26])
        end = np.datetime64(_as_str(handle.attrs["time_end"])[:26])
    except (KeyError, ValueError):
        return np.nan
    return float((end - start) / np.timedelta64(1, "h"))


def collect_calibration(cal_dir, stage="calibrated"):
    """Per-epoch calibration record over a directory of calibrated products.

    Returns a dict of arrays in chronological order. Kept separate from the
    plotting so the same collection can be asserted on in a test or dumped to
    ECSV without importing matplotlib.
    """
    import h5py

    rows = []
    for name in sorted(os.listdir(cal_dir)):
        if not name.endswith(".h5"):
            continue
        path = os.path.join(cal_dir, name)
        with h5py.File(path, "r") as handle:
            if _as_str(handle.attrs.get("stage", "")) != stage:
                continue
            group = _factor_view(handle["calibration"],
                                 int(handle.attrs.get("calibration_schema", 1)
                                     or 1))
            # The pedestal lives in attributes rather than datasets, and is
            # absent from legacy products, so every read of it is defaulted.
            ped = (handle["photodiode/pedestal"].attrs
                   if "photodiode/pedestal" in handle else {})
            # PD1's pedestal, read the same defaulted way. It is a *second
            # device* (InGaAs against PD2's HgCdTe) with its own dark level,
            # 4.33 mV below PD2's, so it is not a redundant copy: a persistent
            # shift in *both* pedestals is a change in the chain rather than in
            # one off-window, which is the only handle on a side swap the
            # telemetry offers -- no mnemonic name reports one. Necessary but
            # not sufficient; see _side_witness and PD_CORRECTION.md s8.
            check = (handle["photodiode/check_pedestal"].attrs
                     if "photodiode/check_pedestal" in handle else {})
            # The two-diode net ratio, per LED. This is the third side-swap
            # witness and the only *chromatic* one: it is a ratio of two lit
            # responses, so a lamp change divides out of it and only a change
            # in one of the diodes survives. Keyed by SEQUENCE slot, LED1..6,
            # which is the physical LED. It used to be keyed by the BANK2SEL
            # hardware number, on the reasoning that that is "what the diode
            # sees" -- and at the 2026-10-06 swap the B-side MCE renumbered
            # the select lines (map 612345 -> 132465) while every sequence
            # slot kept its physical LED (PD1's 1670 nm cutoff stayed on
            # LED6). Keyed by hardware number, four of six positions then
            # compared different LEDs across the swap, and LED4's -0.9 % read
            # as -12.8 %. See PD_CORRECTION.md s8.
            ratio = _check_ratio_by_led(handle)
            span = _span_hours(handle)
            rows.append({
                "label": name[:-3],
                "timestamp": _as_str(handle.attrs["timestamp"]),
                "pedestal": float(ped.get("value", np.nan)),
                "pedestal_rms": float(ped.get("rms", np.nan)),
                "pedestal_drift": float(ped.get("drift_v_per_hr", np.nan)),
                "pedestal_n": int(ped.get("n_samples", 0)),
                "pedestal_source": _as_str(ped.get("source", "")),
                "pedestal_warnings": len(ped.get("warnings", ())),
                "check_pedestal": float(check.get("value", np.nan)),
                "check_pedestal_rms": float(check.get("rms", np.nan)),
                "check_pedestal_drift": float(
                    check.get("drift_v_per_hr", np.nan)),
                "check_pedestal_n": int(check.get("n_samples", 0)),
                "check_ratio": ratio,
                "span_hours": span,
                "car_label": _as_str(handle.attrs.get("car_label", "")),
                "decon_cycle": _as_str(handle.attrs.get("decon_cycle", "")),
                "mce_side": _as_str(handle.attrs.get("mce_side", "")),
                "segment": int(handle.attrs.get("acm_segment", -1)),
                "coverage": int(handle.attrs.get("coverage_n_sca", 0)),
                "corrections": _as_str(handle.attrs.get("corrections_applied", "")),
                "pd_factor": group["pd_factor"][:],
                "side_factor": group["side_factor"][:],
                "acm_factor": group["acm_factor"][:],
                "total_factor": group["total_factor"][:],
                "pd_net": group["pd_net"][:],
                "pd_reference": group["pd_reference"][:],
                "valid": group["valid"][:],
            })

    if not rows:
        raise ValueError(
            f"no stage='{stage}' products in {cal_dir}. Discovery keys on the "
            "h5 'stage' attribute, not the filename, so a directory of raw or "
            "legacy products reads as empty here")

    # Chronological by timestamp, not by filename: pass numbers are per
    # execution plan, so CAR216 plan 3 pass 1 sorts before CAR190 pass 40 by
    # name while following it in time.
    rows.sort(key=lambda row: row["timestamp"])

    times = np.array([np.datetime64(row["timestamp"][:26]) for row in rows])
    out = {
        "label": [row["label"] for row in rows],
        "time": times,
        "hours": (times - times[0]) / np.timedelta64(1, "h"),
        "n_epoch": len(rows),
    }
    for key in ("car_label", "decon_cycle", "mce_side", "corrections",
                "pedestal_source"):
        out[key] = [row[key] for row in rows]
    for key in ("segment", "coverage", "pedestal_n", "pedestal_warnings",
                "check_pedestal_n"):
        out[key] = np.array([row[key] for row in rows])
    for key in ("pd_factor", "side_factor", "acm_factor", "total_factor",
                "pd_net", "pd_reference", "valid",
                "pedestal", "pedestal_rms", "pedestal_drift", "span_hours",
                "check_pedestal", "check_pedestal_rms", "check_pedestal_drift",
                "check_ratio"):
        out[key] = np.array([row[key] for row in rows])
    return out


class _FactorView(dict):
    """A schema-2 ``calibration/`` group read as the schema-1 per-LED fields.

    The figures below draw ``pd_factor``, ``side_factor``, ``acm_factor`` and
    ``total_factor`` per LED. Schema 2 records ``(6, 18)`` multipliers per step
    instead, and none of them is applied; this maps one onto the other so every
    figure keeps its meaning while saying "recorded" where it said "applied":

    * ``pd_factor`` is ``photodiode/multiplier``, which does not vary by SCA;
    * ``side_factor`` is ``side_bridge/multiplier`` (SCA-common), or 1 where no
      bridge solution was recorded -- the ground B-side table is no longer a
      step;
    * ``acm_factor`` keeps its schema-1 meaning, the factor that DIVIDES, so it
      is the reciprocal of ``acm/multiplier``;
    * ``total_factor`` is their per-LED product. The per-SCA ACM bridge is left
      out: it is achromatic and per SCA, which a per-LED panel cannot draw.
    """


def _factor_view(group, schema):
    if schema < 2:
        return group
    n_led = len(cfg.LED_NAMES)

    def column(step):
        return np.asarray(group[step]["multiplier"][()], dtype=float)[:, 0]

    pd_factor = column("photodiode") if "photodiode" in group else np.ones(n_led)
    acm_factor = (1.0 / column("acm")) if "acm" in group else np.ones(n_led)
    side_factor = (column("side_bridge") if "side_bridge" in group
                   else np.ones(n_led))
    pd_group = group["photodiode"] if "photodiode" in group else None
    view = _FactorView({
        "pd_factor": pd_factor, "side_factor": side_factor,
        "acm_factor": acm_factor,
        "total_factor": pd_factor * side_factor / acm_factor,
        "pd_net": (np.asarray(pd_group["pd_net"][()], dtype=float)
                   if pd_group is not None else np.full(n_led, np.nan)),
        "pd_reference": (np.asarray(pd_group["pd_reference"][()], dtype=float)
                         if pd_group is not None else np.full(n_led, np.nan)),
        "valid": np.isfinite(pd_factor * side_factor / acm_factor),
    })
    return view


def _check_ratio_by_led(handle):
    """Per-epoch ``pd_check_ratio``, one entry per sequence LED.

    Keyed by ``activity_key`` (LED1..LED6), the physical LED -- not by the
    BANK2SEL hardware number, which the B-side MCE renumbers. The per-activity
    table also holds the dark and the CAR-216 aux flats, and can repeat or omit
    an LED, so it is reduced to a fixed six-vector to make epoch-to-epoch
    differencing possible at all. Only single-LED, valid-net activities
    contribute: a ``multiple_leds`` activity has no single wavelength and an
    invalid net is a near-zero denominator.

    Returns a NaN vector for a legacy product with no per-activity table, so
    the caller's array stays rectangular.
    """
    want = len(cfg.LED_NAMES)
    out = np.full(want, np.nan)
    group = handle.get("photodiode/per_activity")
    if group is None or "pd_check_ratio" not in group:
        return out
    ratio = np.asarray(group["pd_check_ratio"][:], dtype=float)
    keys = np.asarray(group["activity_key"][:]).astype(str)
    keep = np.isfinite(ratio)
    for name in ("multiple_leds", "is_dark"):
        if name in group:
            keep &= ~np.asarray(group[name][:], dtype=bool)
    if "pd_net_valid" in group:
        keep &= np.asarray(group["pd_net_valid"][:], dtype=bool)
    for index, led in enumerate(cfg.LED_NAMES):
        members = keep & (keys == led)
        if np.any(members):
            out[index] = float(np.median(ratio[members]))
    return out


# A witness is called "stepped" above this many times its own robust scatter.
# Calibrated on the 176-epoch v3 set: the largest coincident shift there reads
# 54x / 439x / 42x (see _side_witness), and the quiet epochs sit at ~1x, so 5
# separates them by a wide margin in both directions.
SIDE_WITNESS_TRIP = 5.0
# Epochs on each side of a candidate boundary used to decide whether a step
# *persisted*. Five is a compromise: long enough that the pass-1 lamp warm-up
# transient does not read as a level change, short enough to fit between the
# ACM moves in the flight trend.
SIDE_WITNESS_WINDOW = 5


def _largest_pedestal_step(record):
    """Difference index of the largest PD2 pedestal step, or ``None``.

    The largest step is the strongest place to read any differential test of
    the pedestal, because a step is not confounded with the lamp's slow drift
    the way a long baseline is. Shared by the panel-2 annotation and the
    stdout summary so both quote the same epoch.
    """
    steps = np.abs(np.diff(np.asarray(record["pedestal"], dtype=float)))
    if not len(steps) or not np.isfinite(steps).any() or np.nanmax(steps) <= 0:
        return None
    return int(np.nanargmax(steps))


def _level_shift_sigmas(series, window=SIDE_WITNESS_WINDOW):
    """Persistent level shift at every boundary, in units of local scatter.

    One value per difference index: the median of the ``window`` epochs after
    the boundary minus the median of the ``window`` before, divided by the
    pooled scatter about those two medians. NaN where either side is shorter
    than three epochs, because a level change cannot be told from a single
    excursion there and a number would imply it could.

    **A level shift, not a step, and the distinction is load-bearing.** The
    largest single epoch-to-epoch step in the flight photodiode record is the
    first one, where the lamp is still warming up; it moves all three witnesses
    at once and then relaxes. Differencing medians of neighbouring blocks keeps
    only what persisted, which is what a hardware change does.

    The scale is floored at the series' own median absolute step so a witness
    whose local scatter is zero -- PD1's dark level is quantization-limited and
    often constant to the bit over five epochs -- does not divide by nothing
    and read as infinitely significant.
    """
    values = np.asarray(series, dtype=float)
    out = np.full(max(len(values) - 1, 0), np.nan)
    if len(values) < 2:
        return out
    floor = float(np.nanmedian(np.abs(np.diff(values))))
    for index in range(len(values) - 1):
        before = values[max(0, index + 1 - window):index + 1]
        after = values[index + 1:index + 1 + window]
        if np.count_nonzero(np.isfinite(before)) < 3 or \
                np.count_nonzero(np.isfinite(after)) < 3:
            continue
        shift = np.nanmedian(after) - np.nanmedian(before)
        spread = np.nanmedian(np.abs(np.concatenate(
            [before - np.nanmedian(before), after - np.nanmedian(after)])))
        scale = max(spread, floor) if np.isfinite(floor) else spread
        if np.isfinite(scale) and scale > 0:
            out[index] = abs(shift) / scale

    return out


def _witness_sigmas(record, window=SIDE_WITNESS_WINDOW):
    """``{name: (n_epoch-1,)}`` of level-shift significance per witness.

    The ratio witness is reduced over LEDs by the *max*, because a diode change
    is chromatic and one band may carry all of it -- PD1's 1670 nm channel sits
    past its own cutoff, so a replacement diode moves that band far more than
    the other five.
    """
    out = {"PD2 pedestal": _level_shift_sigmas(record["pedestal"], window),
           "PD1 pedestal": _level_shift_sigmas(record["check_pedestal"],
                                               window)}
    ratio = record.get("check_ratio")
    if ratio is not None and np.isfinite(np.asarray(ratio, float)).any():
        ratio = np.asarray(ratio, dtype=float)
        with np.errstate(invalid="ignore", divide="ignore"):
            scaled = ratio / np.nanmedian(ratio, axis=0)[None, :]
        per_led = np.vstack([_level_shift_sigmas(scaled[:, led], window)
                             for led in range(scaled.shape[1])])
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            out["two-diode ratio"] = np.nanmax(per_led, axis=0)

    return out


def _ratio_chromaticity(record, index, window=SIDE_WITNESS_WINDOW):
    """Per-LED spread of the ratio's fractional shift, over its mean.

    The one witness property that separates a *diode* from an *offset*. A
    replacement photodiode has a different responsivity curve, so the six
    ratios move by different fractions -- most of all in the band at PD1's
    cutoff. A bias, gain or dark-level change in the shared chain moves them
    all by the same fraction. Returns NaN if the ratio was not recorded.
    """
    ratio = record.get("check_ratio")
    if ratio is None or not np.isfinite(np.asarray(ratio, float)).any():
        return np.nan
    ratio = np.asarray(ratio, dtype=float)
    before = ratio[max(0, index + 1 - window):index + 1]
    after = ratio[index + 1:index + 1 + window]
    if len(before) < 3 or len(after) < 3:
        return np.nan
    base = np.nanmedian(before, axis=0)
    fractional = (np.nanmedian(after, axis=0) - base) / base
    mean = float(np.nanmean(fractional))
    if not np.isfinite(mean) or mean == 0.0:
        return np.nan

    return float(np.ptp(fractional[np.isfinite(fractional)]) / abs(mean))


def _side_witness(record, index=None, window=SIDE_WITNESS_WINDOW):
    """How the three photodiode witnesses read at one boundary.

    ``index`` is a *difference* index: the boundary between epochs ``index``
    and ``index + 1``. Passing ``None`` asks for the record's strongest
    *coincident* boundary -- the one where the weakest of the three witnesses
    is strongest -- which is the right question when no side change is
    labelled and the point is to find one if it is there.

    This exists because **no mnemonic name changes when the MCE side changes**.
    The mnemonics are per-bank, never per-side, so the only announcement is the
    ``mce_side`` attribute, which reads ``assumed:flight-side-A`` on every
    flight product to date. A swap puts a *different physical diode* behind the
    same name, and with a ``global`` photodiode reference that becomes a
    per-LED constant the achromatic bridge step cannot absorb
    (PD_CORRECTION.md s8).

    Three witnesses, because each alone is ambiguous:

    * **PD2's pedestal** and **PD1's pedestal** are dark levels. A bad off
      window moves either one with nothing in the hardware having changed.
    * **``pd_check_ratio``** is a ratio of two *lit* responses, so the lamp
      divides out of it and only a change in the diodes survives -- but it
      cannot say which diode, or tell a diode from its electronics.

    **What the witnesses can and cannot conclude.** All three stepping together
    is the signature a swap makes, but it is not unique to one: the v3 flight
    set is labelled side A throughout and still contains exactly that
    signature at pass 11 -> pass 13, a persistent +307 uV / +131 uV pedestal
    shift with a -0.14 % ratio shift that is only 23 % chromatic. So the
    verdict here is conditioned on whether ``mce_side`` is *labelled* to change
    at the boundary: on a labelled swap the witnesses corroborate or fail to
    corroborate it, and on an unlabelled one they report a photodiode-chain
    change and say it is not a swap on these labels. The chromaticity of the
    ratio shift is quoted because that is the part a swap cannot fake: a
    different diode has a different responsivity curve, most visibly in the
    band past PD1's cutoff.

    Returns a one-line string, empty if PD1 was never recorded.
    """
    check = record.get("check_pedestal")
    if check is None or not np.isfinite(np.asarray(check, float)).any():
        return ""

    sigmas = _witness_sigmas(record, window)
    names = [name for name in ("PD2 pedestal", "PD1 pedestal",
                               "two-diode ratio") if name in sigmas]
    stacked = np.vstack([sigmas[name] for name in names])
    if index is None:
        # The weakest witness, maximized: the best candidate for a change that
        # moved all of them, rather than the largest excursion of any one.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            coincident = np.nanmin(stacked, axis=0)
        if not np.isfinite(coincident).any():
            return ""
        index = int(np.nanargmax(coincident))
    at = {name: float(sigmas[name][index])
          if index < len(sigmas[name]) else np.nan for name in names}

    tripped = [name for name in names
               if np.isfinite(at[name]) and at[name] > SIDE_WITNESS_TRIP]
    all_three = len(tripped) == len(names) == 3
    sides = list(record.get("mce_side", []))
    labelled = (index + 1 < len(sides)
                and str(sides[index]) != str(sides[index + 1]))
    chromatic = _ratio_chromaticity(record, index, window)
    colour = ("" if not np.isfinite(chromatic) else
              f", ratio shift {100 * chromatic:.0f}% chromatic")

    if labelled and all_three:
        verdict = (f"the LABELLED {sides[index]}->{sides[index + 1]} swap is "
                   f"corroborated by all three witnesses{colour}")
    elif labelled:
        verdict = (f"the labelled {sides[index]}->{sides[index + 1]} swap is "
                   f"NOT corroborated ({', '.join(tripped) or 'no witness'} "
                   f"stepped): either the label is wrong or the two diodes are "
                   f"closely matched, and only the label is load-bearing")
    elif all_three:
        verdict = ("all three step and persist, but mce_side does not change "
                   f"here: a photodiode-chain change, NOT a swap on these "
                   f"labels{colour} -- a swap would be strongly chromatic")
    elif tripped:
        verdict = (f"{' and '.join(tripped)} step: not the joint signature, so "
                   f"a baseline or off-window move rather than the hardware")
    else:
        verdict = "no witness steps: the photodiode chain is continuous here"

    def fmt(name):
        value = at[name]
        return "n/a" if not np.isfinite(value) else f"{value:.0f}x"

    return (f"side witnesses at epoch {index + 1}->{index + 2}, persistent "
            f"shift over local scatter: "
            + ", ".join(f"{name} {fmt(name)}" for name in names)
            + f" -- {verdict}")


def _transitions(values):
    """Indices where a per-epoch label changes, as (index, before, after)."""
    return [(i, values[i - 1], values[i])
            for i in range(1, len(values)) if values[i] != values[i - 1]]


def _mark_episodes(axis, record, label=True):
    """Shade ACM segments, and draw decon transitions as a distinct line.

    The two are deliberately drawn differently because they mean different
    things: an ACM segment boundary is a step the bridge *measures*, a decon
    transition is a reset the bridge must *not* fit across.
    """
    hours = record["hours"]
    acm_label = "ACM move" if label else None
    for index, _, _ in _transitions(list(record["segment"])):
        mid = 0.5 * (hours[index - 1] + hours[index])
        axis.axvline(mid, color="#1f77b4", lw=1.0, ls="--", zorder=1,
                     label=acm_label)
        acm_label = None
    decon_label = "decon" if label else None
    for index, _, _ in _transitions(record["decon_cycle"]):
        mid = 0.5 * (hours[index - 1] + hours[index])
        axis.axvline(mid, color="#d62728", lw=1.4, ls="-", alpha=0.7, zorder=1,
                     label=decon_label)
        decon_label = None


def plot_calibration_factors(record, path, dpi=120):
    """The whole of stage 2 in one figure: each factor, per LED, versus time.

    Returns ``(path, worst_total_departure)``.
    """
    figure, axes = plt.subplots(len(FACTOR_PANELS), 1, figsize=(11, 11),
                                sharex=True)
    hours = record["hours"]
    n_led = record["total_factor"].shape[1]

    for axis, (key, ylabel, why) in zip(axes, FACTOR_PANELS):
        values = record[key]
        for led in range(n_led):
            axis.plot(hours, values[:, led], ".-", ms=3, lw=0.8,
                      color=LED_COLORS[led % len(LED_COLORS)],
                      label=cfg.LED_NAMES[led] if key == "pd_factor" else None)
        axis.axhline(1.0, color="0.3", lw=0.6, zorder=0)
        axis.set_ylabel(f"{ylabel}\nfactor", fontsize=9)
        axis.grid(alpha=0.3, lw=0.4)
        _mark_episodes(axis, record, label=(key == "pd_factor"))

        # A factor identical across all six LEDs is a different situation from
        # six factors that happen to agree, and saying which is the point of
        # annotating the spread rather than leaving it to be eyeballed.
        spread = float(np.nanmax(np.nanmax(values, axis=1)
                                 - np.nanmin(values, axis=1)))
        note = (f"{why}; achromatic (per-LED spread {spread:.1e})"
                if spread < 1e-9 else f"{why}; per-LED spread up to {spread:.4f}")
        axis.set_title(note, fontsize=8, loc="left", color="0.35")

    # Invalid epochs are marked on the total panel: NaN is a refusal, and a
    # reader scanning for gaps should not have to distinguish it from no data.
    invalid = ~np.all(record["valid"], axis=1)
    if np.any(invalid):
        for hour in hours[invalid]:
            axes[-1].axvline(hour, color="k", lw=2.0, alpha=0.6, zorder=3)
        axes[-1].plot([], [], color="k", lw=2.0, alpha=0.6,
                      label=f"{int(invalid.sum())} epoch(s) refused")
        axes[-1].legend(fontsize=7, loc="lower left")

    axes[0].legend(fontsize=7, ncol=4, loc="upper left")
    axes[-1].set_xlabel(f"hours since {record['label'][0]}")
    worst = float(np.nanmax(np.abs(record["total_factor"] - 1.0)))
    figure.suptitle(
        f"stage 2 calibration factors, {record['n_epoch']} epochs, "
        f"{len(set(record['segment']))} ACM segment(s), "
        f"{len([c for c in set(record['decon_cycle']) if c])} decon cycle(s); "
        f"worst total correction {100 * worst:.2f}%",
        fontsize=10)
    figure.tight_layout(rect=(0, 0, 1, 0.975))
    _save(figure, path, dpi)
    return path, worst


def plot_calibration_coverage(record, path, dpi=120):
    """Per-epoch SCA coverage, pd_net against its reference, and the segments.

    The coverage panel is the visual form of the check that caught 79 of 91
    products in the overloaded batch: a short product is a complete-looking
    product with most of its focal plane missing.
    """
    figure, axes = plt.subplots(3, 1, figsize=(11, 8.5), sharex=True,
                               gridspec_kw={"height_ratios": (1.1, 1.4, 0.55)})
    hours = record["hours"]

    axes[0].plot(hours, record["coverage"], ".-", ms=4, lw=0.7, color="#1f77b4")
    axes[0].axhline(cfg.N_SCAS, color="#2ca02c", lw=0.8, ls="--",
                    label=f"complete ({cfg.N_SCAS} SCAs)")
    short = record["coverage"] < cfg.N_SCAS
    if np.any(short):
        axes[0].plot(hours[short], record["coverage"][short], "o", ms=6,
                     mfc="none", mec="#d62728",
                     label=f"{int(short.sum())} short product(s)")
    axes[0].set_ylim(0, cfg.N_SCAS + 1)
    axes[0].set_ylabel("SCAs present")
    axes[0].legend(fontsize=7, loc="lower left")

    # pd_net, not the factor: the factor is a ratio and hides a common shift in
    # both numerator and denominator, which is exactly the pedestal failure the
    # PD_MIN_NET guard exists for.
    for led in range(record["pd_net"].shape[1]):
        axes[1].plot(hours, record["pd_net"][:, led], ".-", ms=3, lw=0.8,
                     color=LED_COLORS[led % len(LED_COLORS)],
                     label=cfg.LED_NAMES[led])
    axes[1].axhline(cfg.PD_MIN_NET, color="k", lw=1.0, ls=":",
                    label=f"PD_MIN_NET = {cfg.PD_MIN_NET} V (factor refused below)")
    axes[1].set_ylabel("pd_net [V]")
    axes[1].legend(fontsize=7, ncol=4, loc="lower left")

    for axis in axes[:2]:
        axis.grid(alpha=0.3, lw=0.4)
        _mark_episodes(axis, record, label=False)

    # The band at the bottom is the run's structure: which ACM segment and
    # which decon cycle each epoch belongs to, which is what makes a fallback
    # at a particular boundary legible rather than arbitrary.
    segments = record["segment"]
    for seg in sorted(set(segments.tolist())):
        members = segments == seg
        axes[2].fill_between(hours, 0.55, 1.0, where=members, step="mid",
                             color=plt.cm.Blues(0.3 + 0.17 * (seg % 4)), lw=0)
        mid = float(np.median(hours[members]))
        axes[2].text(mid, 0.77, f"ACM seg {seg}", fontsize=7, ha="center",
                     va="center")
    cycles = [c or "unlabelled" for c in record["decon_cycle"]]
    for index, cycle in enumerate(sorted(set(cycles))):
        members = np.array([c == cycle for c in cycles])
        axes[2].fill_between(hours, 0.0, 0.45, where=members, step="mid",
                             color=plt.cm.Reds(0.25 + 0.2 * index), lw=0)
        mid = float(np.median(hours[members]))
        axes[2].text(mid, 0.22, cycle, fontsize=7, ha="center", va="center")
    axes[2].set_ylim(0, 1)
    axes[2].set_yticks([])
    axes[2].set_ylabel("run\nstructure", fontsize=8)
    axes[2].set_xlabel(f"hours since {record['label'][0]}")

    sides = sorted(set(record["mce_side"]))
    figure.suptitle(
        f"stage 2 coverage and photodiode, {record['n_epoch']} epochs; "
        f"side(s) {'/'.join(sides)}; "
        f"{int(short.sum())} short, "
        f"{int((~np.all(record['valid'], axis=1)).sum())} refused",
        fontsize=10)
    figure.tight_layout(rect=(0, 0, 1, 0.97))
    _save(figure, path, dpi)
    return path, int(short.sum())


def plot_pd_pedestal(record, path, dpi=120):
    """The pedestal: the subtrahend every photodiode number rests on.

    ``pd_net = pd_raw - pedestal`` and ``pd_net`` is then a *denominator*, so a
    wrong pedestal is the one photodiode error that leaves no trace anywhere
    else. It shifts all six LEDs by the same number of volts, which is very
    nearly a common factor, and a common factor cancels in every LED ratio the
    rest of the pipeline looks at. ``calibration_coverage.png`` draws ``pd_net``
    for the near-zero-denominator case; this figure draws the quantity that was
    subtracted to get there, which is what says whether a *small* pedestal error
    is masquerading as lamp drift.

    Four panels, and the second is the reason for the figure:

    * which pedestal each epoch adopted, and from where. A fallback source is a
      quiet downgrade -- ``nearest`` means no off interval overlapped the dark
      activity, so the pedestal came from a different part of the timeline.
    * the one available *test* of it, which has to be differential. Because
      ``pd_raw == pd_net + pedestal`` identically, differencing neighbouring
      epochs separates the two explanations for a pedestal excursion: a real
      shift of the diode baseline moves ``pd_raw`` with the pedestal and cancels
      in ``pd_net``, while a bad off-window moves the pedestal alone and pushes
      ``pd_net`` the other way by the same amount. Differencing is what makes it
      legible at all -- the lamp's own drift across a run is several times the
      pedestal's whole range, so on an absolute scale the pedestal is a flat
      line.
    * whether a single scalar describes it. The drift rate times the epoch span
      is the error a scalar leaves behind, and comparing it to the pedestal's own
      scatter says whether the scalar or the drift dominates.
    * how much of the per-LED ``pd_net`` variation the pedestal could account
      for. If the pedestal's own range is a large fraction of an LED's
      ``pd_net`` range, then what the photodiode correction removes from that
      LED is substantially pedestal rather than lamp.

    Returns ``(path, worst_drift_volts, n_fallback, leak, resolution)``, where
    ``leak`` is how much of the largest epoch-to-epoch pedestal step survives
    into ``pd_net`` and ``resolution`` is the lamp's own typical motion between
    neighbouring epochs. ``leak`` within a couple of ``resolution`` means the
    step was a real baseline shift that the subtraction removed; the ratio on
    its own is not interpretable, which is why both are returned.
    """
    figure, axes = plt.subplots(4, 1, figsize=(11, 12),
                                gridspec_kw={"height_ratios": (1.2, 1.2, 1.0,
                                                               1.0)})
    hours = record["hours"]
    pedestal = record["pedestal"]
    rms = record["pedestal_rms"]
    sources = record["pedestal_source"]
    primary = np.array([s == "dark_window" for s in sources])
    n_fallback = int((~primary).sum())
    net_med = np.nanmedian(record["pd_net"], axis=1)

    axes[0].fill_between(hours, 1e6 * (pedestal - rms), 1e6 * (pedestal + rms),
                         color="#1f77b4", alpha=0.25, lw=0,
                         label="+/- pedestal rms")
    axes[0].plot(hours, 1e6 * pedestal, "-", lw=0.8, color="#1f77b4")
    axes[0].plot(hours[primary], 1e6 * pedestal[primary], ".", ms=4.5,
                 color="#1f77b4", label="source: dark_window (primary)")
    # Each fallback gets its own marker and its own legend entry, because
    # "which fallback" is the whole content: pooled off intervals are a mild
    # downgrade, a nearest sample outside the window is a large one.
    for index, style in enumerate(("s", "^", "v", "D")):
        kinds = sorted({s for s in sources if s != "dark_window"})
        if index >= len(kinds):
            break
        members = np.array([s == kinds[index] for s in sources])
        axes[0].plot(hours[members], 1e6 * pedestal[members], style, ms=7,
                     mfc="none", mew=1.6, color="#9467bd",
                     label=f"source: {kinds[index]} ({int(members.sum())})")
    warned = record["pedestal_warnings"] > 0
    if np.any(warned):
        axes[0].plot(hours[warned], 1e6 * pedestal[warned], "o", ms=10,
                     mfc="none", mew=1.4, color="#ff7f0e",
                     label=f"{int(warned.sum())} epoch(s) with a pedestal warning")
    axes[0].set_ylabel("adopted\npedestal [uV]")
    span = float(np.nanmax(pedestal) - np.nanmin(pedestal))

    # PD1's pedestal, on its own axis. It has to be a twin: PD1 sits ~4.3 mV
    # below PD2, so a shared microvolt scale would compress PD2's own 324 uV
    # range to a flat line -- the opposite of what this panel is for. Drawn here
    # because the two diodes are *different devices* (InGaAs against HgCdTe),
    # which makes this the one panel that can show a side swap: a persistent
    # shift in *both* traces is a change in the chain, while a shift in one is
    # that diode's own baseline or off-window moving. No mnemonic name reports
    # the swap. Both-traces is necessary and not sufficient -- the real v3 set
    # has one on a side-A-only label -- so the verdict is `_side_witness`'s,
    # which also weighs the mce_side label and the shift's chromaticity.
    #
    # The twin removes the offset but is then *locked to the left axis's
    # microvolt span*, which is the only part of the twin that is allowed to be
    # free. Left to autoscale, matplotlib gives each trace the full panel
    # height, so PD1's 134 uV range is magnified 2.4x against PD2's 324 uV and
    # the two appear to track each other -- which would assert the opposite of
    # the measured 18x noise ratio. Equal uV per pixel makes "PD1 is quieter"
    # something the reader measures rather than something the caption claims.
    check = record.get("check_pedestal")
    offset = np.nan
    if check is not None and np.isfinite(check).any():
        bottom, top = axes[0].get_ylim()        # before the twin exists
        twin = axes[0].twinx()
        twin.plot(hours, 1e6 * check, "-", lw=0.8, color="#8c564b", alpha=0.9)
        twin.plot(hours, 1e6 * check, ".", ms=3.5, color="#8c564b",
                  label="PD1 (InGaAs) pedestal, right axis")
        twin.set_ylabel("PD1 pedestal [uV], same uV span as left",
                        color="#8c564b", fontsize=8)
        twin.tick_params(axis="y", labelcolor="#8c564b", labelsize=7)
        twin.legend(fontsize=7, loc="lower right")
        offset = float(np.nanmedian(pedestal - check))
        check_span = float(np.nanmax(check) - np.nanmin(check))
        middle = 1e6 * float(np.nanmedian(check))
        twin.set_ylim(middle - 0.5 * (top - bottom),
                      middle + 0.5 * (top - bottom))
        axes[0].set_ylim(bottom, top)           # pin it against later artists
        axes[0].set_ylabel("PD2 adopted\npedestal [uV]")

    offset_text = ("" if not np.isfinite(offset) else
                   f"; PD1 sits {1e3 * offset:.2f} mV lower, own range "
                   f"{1e6 * check_span:.0f} uV")
    axes[0].set_title(
        f"range {1e6 * span:.0f} uV peak-to-peak; {n_fallback} epoch(s) on a "
        f"fallback source{offset_text}",
        fontsize=8, loc="left", color="0.35")
    axes[0].legend(fontsize=7, loc="best", ncol=2)

    # Panel 2: the only available *test* of the pedestal, and it has to be
    # differential. pd_raw = pd_net + pedestal identically, so all three could be
    # drawn together -- but the lamp's own drift across this run is ~2500 uV
    # against a 324 uV pedestal range, so on a shared absolute scale the thing
    # being tested is a flat line. Differencing neighbouring epochs removes the
    # lamp's slow drift and leaves the comparison that matters: at a step, a real
    # shift of the diode baseline moves pd_raw with the pedestal and cancels in
    # pd_net, while a bad off-window moves the pedestal alone and pushes pd_net
    # the other way by the same amount.
    steps_signed = np.diff(pedestal)
    raw_signed = np.diff(net_med + pedestal)
    net_signed = np.diff(net_med)
    mid = 0.5 * (hours[1:] + hours[:-1])
    axes[1].axhline(0, color="0.3", lw=0.6, zorder=0)
    axes[1].plot(mid, 1e6 * steps_signed, ".-", ms=3, lw=0.8, color="#1f77b4",
                 label="change in pedestal")
    axes[1].plot(mid, 1e6 * raw_signed, ".-", ms=3, lw=0.8, color="#d62728",
                 label="change in pd_raw: follows a real baseline shift")
    axes[1].plot(mid, 1e6 * net_signed, ".-", ms=3, lw=1.1, color="#2ca02c",
                 label="change in pd_net: stays put if the pedestal is right")
    axes[1].set_ylabel("epoch-to-epoch\nchange [uV]")

    # The largest pedestal step is the strongest form of the test, because a step
    # is not confounded with the lamp's slow drift the way a long baseline is. It
    # is not *free* of it either: the lamp moves a little between any two epochs,
    # so leakage can only be resolved down to that typical motion. Quoting the
    # resolution beside the leakage is what stops a floor-limited result reading
    # as a measurement -- without it the synthetic in self_test reads 17%
    # leakage and looks like a failure, when 17% is just its own per-epoch lamp
    # drift divided by the planted step.
    steps = np.abs(steps_signed)
    resolution = (float(np.nanmedian(np.abs(net_signed))) if len(net_signed)
                  else np.nan)
    leak = np.nan
    if len(steps) and np.nanmax(steps) > 0:
        worst_step = int(np.nanargmax(steps))
        leak = abs(float(net_signed[worst_step]))
        verdict = ("consistent with complete removal"
                   if leak <= 2 * resolution else
                   "LARGER than the lamp's own motion: suspect the off-window")
        axes[1].plot(mid[worst_step], 1e6 * steps_signed[worst_step], "o",
                     ms=11, mfc="none", mew=1.5, color="k",
                     label="largest pedestal step")
        note = (f"largest step {1e6 * steps[worst_step]:.0f} uV at "
                f"{hours[worst_step + 1]:.0f} h leaves {1e6 * leak:.0f} uV in "
                f"pd_net ({100 * leak / steps[worst_step]:.0f}%) against a "
                f"{1e6 * resolution:.0f} uV\nresolution set by the lamp's own "
                f"per-epoch drift: {verdict}")
        # A second question about the same panel, at its own epoch. The test
        # above asks whether the pedestal was *subtracted* correctly; this one
        # asks whether the photodiode chain changed underneath it, which is the
        # testable form of a claim nothing in the telemetry makes. Deliberately
        # *not* read at the largest single step -- that is the pass-1 lamp
        # warm-up, which moves all three witnesses and then relaxes -- but at
        # the strongest persistent coincident shift, which it names. Empty on
        # every product that predates PD1's pedestal being stored.
        witness = _side_witness(record)
        if witness:
            # Wrapped, not truncated. The reading's verdict clause is its
            # payload and it sits at the *end* of the line, so a title left to
            # run off the axes loses exactly the part worth reading.
            note = "\n".join([note] + textwrap.wrap(witness, width=110))
    else:
        note = "pedestal is constant to the recorded precision"
    axes[1].set_title(note, fontsize=8, loc="left", color="0.35")
    axes[1].legend(fontsize=7, loc="best", ncol=2)

    # Panel 3: the error a single scalar leaves behind. Drift is fitted across
    # the off intervals; multiplying by the epoch span is the conservative
    # conversion, since the dark activity and the farthest lit activity are
    # about that far apart.
    drift_v = np.abs(record["pedestal_drift"]) * record["span_hours"]
    axes[2].plot(hours, 1e6 * drift_v, ".-", ms=4, lw=0.7, color="#d62728",
                 label="|drift| x epoch span: what a scalar pedestal misses")
    axes[2].plot(hours, 1e6 * rms, ".-", ms=4, lw=0.7, color="#1f77b4",
                 label="pedestal rms: the scatter it was measured against")
    axes[2].set_yscale("log")
    axes[2].set_ylabel("within-epoch\n[uV]")
    axes[2].set_xlabel(f"hours since {record['label'][0]}")
    worst_drift = float(np.nanmax(drift_v))
    median_net = float(np.nanmedian(record["pd_net"]))
    axes[2].set_title(
        f"worst scalar-pedestal error {1e6 * worst_drift:.0f} uV = "
        f"{100 * worst_drift / median_net:.3f}% of pd_net; above the rms means "
        "the drift, not the noise, sets the pedestal's accuracy",
        fontsize=8, loc="left", color="0.35")
    axes[2].legend(fontsize=7, loc="best")

    for axis in axes[:3]:
        axis.grid(alpha=0.3, lw=0.4)
        _mark_episodes(axis, record, label=False)

    # Panel 4: the attribution question. Not a time series -- a comparison of
    # two ranges, which is what decides whether the pd correction on a given LED
    # is measuring the lamp or the pedestal.
    n_led = record["pd_net"].shape[1]
    net_span = np.array([float(np.nanmax(record["pd_net"][:, led])
                               - np.nanmin(record["pd_net"][:, led]))
                         for led in range(n_led)])
    positions = np.arange(n_led)
    axes[3].bar(positions, 1e6 * net_span, color=LED_COLORS[:n_led], alpha=0.8)
    axes[3].axhline(1e6 * span, color="k", lw=1.4, ls="--",
                    label=f"pedestal range ({1e6 * span:.0f} uV): the part of "
                          "each bar that may not be the lamp")
    for position, value in zip(positions, net_span):
        axes[3].text(position, 1e6 * value, f"  {100 * span / value:.0f}%",
                     fontsize=8, ha="center", va="bottom", color="0.3")
    axes[3].set_xticks(positions)
    axes[3].set_xticklabels(cfg.LED_NAMES[:n_led])
    axes[3].set_ylabel("pd_net range\nover the run [uV]")
    axes[3].set_ylim(0, 1e6 * max(net_span.max(), span) * 1.25)
    # A common pedestal shift is not exactly achromatic: it divides by each
    # LED's own pd_net. That residual colour is what decides whether a pedestal
    # error could be mistaken for a film reset in decon_evidence.png, so it is
    # quoted here in the same units that figure uses.
    induced = span / np.nanmedian(record["pd_net"], axis=0)
    axes[3].set_title(
        f"percentages are the pedestal range as a fraction of each LED's; a "
        f"common pedestal shift that size induces a chromatic spread of only\n"
        f"{np.std(induced, ddof=1):.1e} across the LEDs "
        f"(cf. decon_evidence.png), so it cannot imitate a decon",
        fontsize=8, loc="left", color="0.35")
    axes[3].legend(fontsize=7, loc="upper left")
    axes[3].grid(alpha=0.3, lw=0.4, axis="y")

    kinds = "/".join(sorted(set(sources)))
    figure.suptitle(
        f"photodiode pedestal, {record['n_epoch']} epochs; source(s) {kinds}; "
        f"worst scalar error {100 * worst_drift / median_net:.3f}% of pd_net",
        fontsize=10)
    figure.tight_layout(rect=(0, 0, 1, 0.965))
    _save(figure, path, dpi)
    return path, worst_drift, n_fallback, leak, resolution


def write_all(cal_dir, plot_dir, dpi=120):
    """Every stage-2 figure into ``plot_dir``. Returns the paths written."""
    os.makedirs(plot_dir, exist_ok=True)
    record = collect_calibration(cal_dir)
    written = []
    path, worst = plot_calibration_factors(
        record, os.path.join(plot_dir, "calibration_factors.png"), dpi)
    written.append(path)
    print(f"  calibration_factors.png: worst total correction "
          f"{100 * worst:.2f}% over {record['n_epoch']} epochs")
    path, short = plot_calibration_coverage(
        record, os.path.join(plot_dir, "calibration_coverage.png"), dpi)
    written.append(path)
    print(f"  calibration_coverage.png: {short} short product(s), "
          f"{int((~np.all(record['valid'], axis=1)).sum())} refused epoch(s)")
    if np.any(np.isfinite(record["pedestal"])):
        path, drift, fallback, leak, resolution = plot_pd_pedestal(
            record, os.path.join(plot_dir, "pd_pedestal.png"), dpi)
        written.append(path)
        median_net = float(np.nanmedian(record["pd_net"]))
        print(f"  pd_pedestal.png: {fallback} fallback source(s), worst "
              f"scalar-pedestal error {100 * drift / median_net:.3f}% of pd_net; "
              f"the largest pedestal step leaves {1e6 * leak:.0f} uV in pd_net "
              f"against a {1e6 * resolution:.0f} uV resolution")
        witness = _side_witness(record)
        if witness:
            print(f"    {witness}")
    else:
        # Legacy products carry no photodiode group, so this is a normal
        # outcome for that set rather than a failure. Say so, because a silently
        # missing figure reads as a figure that was drawn and found nothing.
        print("  pd_pedestal.png: skipped, no product records a pedestal "
              "(expected for legacy mosaic products)")
    return written


def _save(figure, path, dpi):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    figure.savefig(path, dpi=dpi)
    plt.close(figure)


def self_test(verbose=True):
    """Draw both figures from a synthetic record; assert the annotations."""
    import tempfile

    def report(message):
        if verbose:
            print(f"  ok  {message}")

    n_epoch, n_led = 40, 6
    times = (np.datetime64("2026-09-12T00:00:00")
             + np.arange(n_epoch) * np.timedelta64(6, "h"))
    pd_net = 0.25 * (1.0 - 0.0002 * np.arange(n_epoch))[:, None] * np.ones(n_led)
    pd_net[17, 3] = 0.004      # the near-zero denominator, as a 60x trap
    valid = pd_net > cfg.PD_MIN_NET
    record = {
        "label": [f"EPOCH{i:03d}" for i in range(n_epoch)],
        "time": times,
        "hours": (times - times[0]) / np.timedelta64(1, "h"),
        "n_epoch": n_epoch,
        "car_label": ["CAR190"] * 20 + ["CAR216"] * 20,
        "decon_cycle": ["decon1"] * 18 + ["decon2"] * 22,
        "mce_side": ["A"] * n_epoch,
        "corrections": ["photodiode,side,acm"] * n_epoch,
        "segment": np.array([0] * 10 + [1] * 15 + [2] * 15),
        "coverage": np.full(n_epoch, cfg.N_SCAS),
        "pedestal": 0.1164 + 3e-6 * np.arange(n_epoch),
        "pedestal_rms": np.full(n_epoch, 1.8e-5),
        "pedestal_drift": np.full(n_epoch, 2e-6),
        "pedestal_n": np.full(n_epoch, 327),
        "pedestal_source": ["dark_window"] * n_epoch,
        "pedestal_warnings": np.zeros(n_epoch, dtype=int),
        "span_hours": np.full(n_epoch, 0.26),
        "pd_net": pd_net,
        "pd_reference": np.full((n_epoch, n_led), 0.25),
        "pd_factor": np.where(valid, 0.25 / pd_net, np.nan),
        "side_factor": np.ones((n_epoch, n_led)),
        "acm_factor": np.full((n_epoch, n_led), 1.000001),
        "valid": valid,
    }
    record["coverage"][5] = 3   # a short product must be circled, not hidden
    record["total_factor"] = (record["pd_factor"] * record["side_factor"]
                              * record["acm_factor"])

    with tempfile.TemporaryDirectory() as tmp:
        path, worst = plot_calibration_factors(
            record, os.path.join(tmp, "f.png"))
        assert os.path.getsize(path) > 10000, "factors figure is suspiciously small"
        # The 0.004 V pd_net would be a 62x factor; it must be NaN instead, so
        # the worst *applied* correction stays small.
        assert worst < 0.05, f"an invalid pd_net leaked into a factor: {worst}"
        report(f"factor decomposition drawn; worst applied {100 * worst:.3f}% "
               "(the 0.004 V pd_net was refused, not applied)")

        path, short = plot_calibration_coverage(
            record, os.path.join(tmp, "c.png"))
        assert short == 1, short
        assert os.path.getsize(path) > 10000
        report("coverage figure drawn; the one short product is counted")

        path, drift, fallback, _, _ = plot_pd_pedestal(
            record, os.path.join(tmp, "p.png"))
        assert os.path.getsize(path) > 10000
        assert fallback == 0, fallback
        report(f"pedestal figure drawn; all-primary sources, worst scalar "
               f"error {1e6 * drift:.2f} uV")

        # The tracking statistic has two poles and both must read correctly,
        # because they are opposite conclusions about the same 300 uV step: a
        # real shift of the diode baseline (pd_raw moves, pd_net does not) is
        # fine, a bad off-window (pd_net absorbs the whole step) is not. The
        # synthetic holds pd_net fixed, so planting the step in the pedestal
        # alone is the good case, and shifting pd_net with it is the bad one.
        real = dict(record)
        real["pedestal"] = record["pedestal"].copy()
        real["pedestal"][20:] += 3e-4
        _, _, _, leak, floor = plot_pd_pedestal(real,
                                                os.path.join(tmp, "pr.png"))
        # Note what is *not* asserted: leak == 0. The synthetic lamp moves 50 uV
        # per epoch, so 50 uV of the 300 uV step is unresolvable and the raw
        # ratio reads 17%. The test is leak against the resolution, which is the
        # same comparison the panel title makes.
        assert leak <= 2 * floor, (leak, floor)

        bad = dict(real)
        bad["pd_net"] = record["pd_net"].copy()
        bad["pd_net"][20:] -= 3e-4
        _, _, _, leaked, floor_bad = plot_pd_pedestal(bad,
                                                      os.path.join(tmp, "pb.png"))
        assert leaked > 2 * floor_bad, (leaked, floor_bad)
        report(f"a real baseline step leaks {1e6 * leak:.0f} uV (within the "
               f"{1e6 * floor:.0f} uV lamp-drift resolution) while a bad "
               f"off-window leaks {1e6 * leaked:.0f} uV -- not confused, and "
               "the floor-limited case is not called a failure")

        # A fallback source and a drift warning are the two things this figure
        # exists to make visible, so both are planted. The drifting pedestal is
        # given a rate that matters -- 0.01 V/hr across a 0.26 h epoch is 2.6 mV
        # against a 0.25 V pd_net -- so a silent change that stopped reading
        # `pedestal_drift` would fail here rather than draw an empty panel.
        degraded = dict(record)
        degraded["pedestal_source"] = (["dark_window"] * 36 + ["pooled_off"] * 2
                                       + ["nearest"] * 2)
        degraded["pedestal_warnings"] = np.zeros(n_epoch, dtype=int)
        degraded["pedestal_warnings"][38:] = 1
        degraded["pedestal_drift"] = np.full(n_epoch, 2e-6)
        degraded["pedestal_drift"][39] = 0.01
        path, drift, fallback, _, _ = plot_pd_pedestal(
            degraded, os.path.join(tmp, "pd.png"))
        assert fallback == 4, fallback
        assert abs(drift - 0.0026) < 1e-9, drift
        report(f"a 4-epoch fallback and a 0.01 V/hr drift are both reported "
               f"({100 * drift / 0.25:.2f}% of pd_net, not averaged away)")

        # The side witnesses. The base `record` carries no PD1 pedestal at
        # all -- the legacy-product case, already drawn four times above
        # without raising, which is the tolerance the extended collector
        # needs. The planted cases below exist because the reading has to tell
        # causes apart rather than flag any step, and because the real flight
        # record contains a coincident three-witness shift on a set that never
        # left side A.
        assert _side_witness(record) == "", (
            "a product with no PD1 pedestal must read as no witness at all, "
            "not as a witness that did not step")

        witnessed = dict(real)        # `real` steps PD2's pedestal at 20
        rng = np.random.default_rng(190)
        # Jitter so each witness has a non-zero scale to be standardised
        # against; without it the scale is zero and every reading is n/a.
        witnessed["check_pedestal"] = (0.11207
                                       + 3e-7 * rng.standard_normal(n_epoch))
        witnessed["check_ratio"] = (
            np.tile(np.array([1.135, 1.056, 1.163, 1.193, 1.167, 0.205]),
                    (n_epoch, 1))
            * (1.0 + 6e-5 * rng.standard_normal((n_epoch, n_led))))

        # Asked for the strongest *coincident* boundary, a set where only PD2
        # moved has none, and the reading says so rather than promoting the one
        # witness that did move. Panel 2's own test already covers a lone
        # pedestal step; this line is only about the chain.
        text = _side_witness(witnessed)
        assert "no witness steps" in text, text
        report(f"a lone pedestal step leaves no coincident boundary: {text}")
        # At that boundary explicitly, the single witness is named and the
        # verdict stays negative.
        text = _side_witness(witnessed, 19)
        assert "not the joint signature" in text and "PD2 pedestal" in text, text
        report(f"and read at the step itself, it is named and still refused: "
               f"{text}")

        # A transient must not read as a change, which is the whole reason the
        # statistic differences block medians instead of neighbouring epochs:
        # the largest single step in the real record is the pass-1 lamp
        # warm-up, and it moves all three witnesses at once.
        # Sized above `real`'s level step at 20 so the excursion really is the
        # largest single step in the set, which is the configuration the flight
        # record is in: a one-epoch warm-up bigger than any later level change.
        transient = dict(witnessed)
        for key, size in (("pedestal", 1e-3), ("check_pedestal", 4.3e-4)):
            transient[key] = np.asarray(witnessed[key], dtype=float).copy()
            transient[key][0] += size
        transient["check_ratio"] = witnessed["check_ratio"].copy()
        transient["check_ratio"][0, :] *= 1.002
        assert _largest_pedestal_step(transient) == 0, "the plant missed"
        text = _side_witness(transient)
        assert "epoch 1->2" not in text, (
            "a one-epoch excursion was read as a level change: " + text)
        report("a single-epoch excursion in all three is not a level change")

        # The signature itself, on a set whose label does not change: that is
        # what the v3 flight record actually contains, and it must be reported
        # without being called a swap.
        unlabelled = dict(witnessed)
        unlabelled["check_pedestal"] = np.asarray(
            witnessed["check_pedestal"], dtype=float).copy()
        unlabelled["check_pedestal"][20:] += 1.3e-4
        unlabelled["check_ratio"] = witnessed["check_ratio"].copy()
        unlabelled["check_ratio"][20:, :] *= 0.9986      # achromatic
        text = _side_witness(unlabelled)
        assert "NOT a swap on these labels" in text and "epoch 20->21" in text, text
        assert "% chromatic" in text, text
        report(f"the joint signature without a side label is reported as a "
               f"chain change, not a swap: {text}")

        # And the labelled case, which is what the mechanism is for.
        swapped = dict(unlabelled)
        swapped["mce_side"] = ["A"] * 20 + ["B"] * (n_epoch - 20)
        swapped["check_ratio"] = witnessed["check_ratio"].copy()
        swapped["check_ratio"][20:, :] *= np.array(
            [0.97, 0.99, 1.01, 1.02, 1.03, 1.18])       # a different diode
        text = _side_witness(swapped)
        assert "LABELLED A->B swap is corroborated" in text, text
        report(f"a labelled swap with all three stepping is corroborated: "
               f"{text}")

        # The converse, and the one case where the label wins: closely matched
        # diodes leave the witnesses quiet, and the reading must say the label
        # is what is load-bearing rather than imply no swap happened.
        quiet = dict(witnessed)
        quiet["pedestal"] = record["pedestal"]
        quiet["mce_side"] = ["A"] * 20 + ["B"] * (n_epoch - 20)
        text = _side_witness(quiet, 19)
        assert "NOT corroborated" in text and "only the label is load-bearing" in text, text
        report("a labelled swap the witnesses cannot see is reported as "
               "uncorroborated, not as absent")

    assert not np.all(record["valid"], axis=1)[17]
    report("side and ACM panels report achromatic; PD does not")
    return True


if __name__ == "__main__":
    print("calibration_plots self test")
    self_test()
    print("all checks passed")
