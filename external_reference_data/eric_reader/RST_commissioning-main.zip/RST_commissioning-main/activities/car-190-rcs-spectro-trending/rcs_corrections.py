"""Per-epoch scalar corrections: photodiode, electronics side, ACM position.

Three corrections, all per-LED scalars, which is what makes the whole two-stage
split possible: a scalar commutes with the median, so it can be applied to an
epoch's own superpixel arrays once and the result still equals what applying it
to a per-SCA ratio downstream would have given. That is why stage 2 can be
per-file and embarrassingly parallel while still producing numbers identical to
the old single-pass pipeline.

==============  =======================================  ===================
correction      what it divides out                      size
==============  =======================================  ===================
photodiode      lamp output drift, per LED channel        1000-3700 ppm
                (``reference_pd / epoch_pd``)             pass to pass
side            MCE A vs B electronics gain               1.5-6 % per LED
acm             linear response vs fractional LVDT        0.1 % within a
                travel from the segment's reference       correctly segmented
                                                          run; 86 % if the
                                                          segmentation misses
                                                          a move
==============  =======================================  ===================

**What "calibrated" means here.** The corrected arrays are *absolute* corrected
rates, normalized to the reference epoch's lamp output and to each segment's
reference ACM position. They are deliberately **not** the ratio to the
reference epoch: that is a pixel-level division by another epoch's 33 MB of
arrays, so putting it here would force every parallel worker to read the
reference product. The ratio stays in ``make_sca_digests.py``, and because the
factors are scalars the composition is exact either way.

**The reference card.** Everything above needs quantities only the *whole set*
knows: which epoch is the reference, its per-LED photodiode level, and each
segment's reference LVDT. :class:`ReferenceCard` computes those once in a
metadata-only pass (~0.1 s/file) and writes them to an ECSV. Stage 2 then reads
the card rather than re-deriving anything, so the calibration of one epoch does
not depend on which other epochs happened to be in the directory that day --
and the card's sha256 is recorded in every product it calibrated, so a product
can always be traced to the exact reference it used.

**The guard that matters.** ``pd_net`` is a *denominator*. Measured pedestal is
~0.1164 V and illuminated levels are 0.347-0.396 V, so ``pd_net`` is
0.23-0.28 V. A pedestal taken from a window that was not actually dark can push
``pd_net`` to a few mV and produce a 60x response factor that looks exactly like
a real instrument event. So a factor is never formed from an invalid
``pd_net``: it is NaN, the epoch is flagged, and :mod:`rcs_report` lists it.
"""

import dataclasses
import hashlib
import os

import numpy as np

import rcs_acm
import rcs_products
import rcs_trend_config as cfg

__all__ = [
    "CalibrationFactors", "Corrections", "EpochMeta", "ReferenceCard",
    "acm_correction", "apply_factors", "led_scale_factors", "self_test",
]


@dataclasses.dataclass(frozen=True)
class Corrections:
    """Which per-epoch scalar corrections to fold in."""

    photodiode: bool = True
    side: bool = True
    acm: bool = True

    def applied(self):
        """The names of the enabled corrections, for the product attribute."""
        return tuple(name for name, on in (("photodiode", self.photodiode),
                                           ("side", self.side),
                                           ("acm", self.acm)) if on)


@dataclasses.dataclass(frozen=True)
class EpochMeta:
    """What a correction needs to know about one epoch, product-shape agnostic.

    Built from the ``dictionary/`` group, which the legacy mosaic product, the
    RAW per-SCA product and the CALIBRATED one all carry in the same layout --
    so one reader covers all three and nothing here branches on product kind.
    """

    path: str
    name: str
    run_label: str
    timestamp: object
    pass_number: int
    photodiode: np.ndarray      # (6,) pd_net per LED, the dark entry dropped
    acm_lvdt: float
    mce_side: str
    mce_side_source: str
    car_label: str = ""
    decon_cycle: str = ""
    stage: str = ""
    product_kind: str = ""
    bin_factor: int = 0

    @property
    def is_b_side(self):
        return self.mce_side.upper() == "B"

    @property
    def acm_offset(self):
        """LVDT readout offset for this epoch's electronics side."""
        return cfg.acm_offset_for(self.mce_side)

    @property
    def acm_coefficient(self):
        """Linear response coefficient in fractional LVDT travel."""
        return cfg.acm_coefficient_for(self.mce_side)

    @property
    def pd_valid(self):
        """``(6,)`` bool: which LED channels have a usable ``pd_net``."""
        return np.isfinite(self.photodiode) & (self.photodiode > cfg.PD_MIN_NET)

    @classmethod
    def from_product(cls, path, sequence_number=None, assume_side=None):
        """Read one epoch's metadata without touching a single pixel.

        ``acm_lvdt`` is a **nanmean** over the six LVDT channels, not a mean:
        two products in the overloaded batch set had one NaN channel, and a
        plain mean turns the whole epoch's position into NaN, which then
        silently disables both the ACM correction and the travel warning that
        would have reported it.
        """
        import h5py

        meta = rcs_products.read_metadata(path)
        attrs = meta["attrs"]
        with h5py.File(path, "r") as handle:
            group = handle["dictionary"]
            # Entry 0 is the dark, which is 0 by construction in both the
            # compiler's rule and pd_net's; entries 1..6 track LED1..LED6.
            photodiode = np.asarray(group["RCS_photodiode"][()],
                                    dtype=float)[1:]
            lvdt = np.asarray(group["ACM_LVDT"][()], dtype=float)
            timestamp = rcs_products.parse_timestamp(group["timestamp"][()])

        name = os.path.basename(path)
        side, source = rcs_products.mce_side_from(name, attrs,
                                                  assume=assume_side)

        return cls(
            path=str(path), name=name,
            run_label=str(meta.get("run_label", "") or os.path.splitext(name)[0]),
            timestamp=timestamp,
            pass_number=rcs_products.pass_number_from(
                name, attrs, sequence_number=sequence_number),
            photodiode=photodiode,
            acm_lvdt=float(np.nanmean(lvdt)) if np.isfinite(lvdt).any()
            else float("nan"),
            mce_side=side, mce_side_source=source,
            car_label=str(meta.get("car_label", "")),
            decon_cycle=str(meta.get("decon_cycle", "")),
            stage=meta["stage"], product_kind=meta["product_kind"],
            bin_factor=int(meta["bin_factor"]),
        )


@dataclasses.dataclass
class CalibrationFactors:
    """The per-LED factors applied to one epoch, and why each is what it is.

    Kept as parallel ``(6,)`` arrays rather than a dict because this is written
    straight into the product's ``calibration/`` group, where the point is that
    a sweep looking for epochs with an invalid photodiode factor can read six
    numbers instead of 33 MB of pixels.
    """

    led_names: list
    pd_factor: np.ndarray
    side_factor: np.ndarray
    acm_factor: np.ndarray
    total_factor: np.ndarray
    pd_net: np.ndarray
    pd_reference: np.ndarray
    valid: np.ndarray
    notes: list = dataclasses.field(default_factory=list)

    def as_group(self):
        """The ``calibration/`` group payload for :func:`rcs_products.write_calibrated`."""
        return {
            "led_name": list(self.led_names),
            "pd_factor": np.asarray(self.pd_factor, dtype=np.float64),
            "side_factor": np.asarray(self.side_factor, dtype=np.float64),
            "acm_factor": np.asarray(self.acm_factor, dtype=np.float64),
            "total_factor": np.asarray(self.total_factor, dtype=np.float64),
            "pd_net": np.asarray(self.pd_net, dtype=np.float64),
            "pd_reference": np.asarray(self.pd_reference, dtype=np.float64),
            "valid": np.asarray(self.valid, dtype=bool),
        }

    def factor_for(self, led):
        """The total factor for one LED name."""
        return float(self.total_factor[self.led_names.index(led)])

    @property
    def all_valid(self):
        return bool(np.all(self.valid))


def acm_correction(epoch, reference_lvdt, corr=Corrections()):
    """Response change from ACM travel about its own configuration's position.

    ``reference_lvdt`` must come from the same ACM configuration as ``epoch``.
    The linear form has no validity across a reconfiguration: on the 34-epoch
    reference set a segmentation that missed two same-sign moves put the worst
    fractional travel at 0.859, i.e. 86 % extrapolation of a model fitted for
    sub-percent excursions. Correct segmentation brings it to 0.001.
    """
    if not corr.acm:
        return 1.0
    if not np.isfinite(reference_lvdt) or reference_lvdt == 0.0 \
            or not np.isfinite(epoch.acm_lvdt):
        return float("nan")
    travel = (epoch.acm_lvdt + epoch.acm_offset) / reference_lvdt - 1.0

    return 1.0 + epoch.acm_coefficient * travel


def led_scale_factors(epoch, reference_pd, reference_lvdt,
                      corr=Corrections(), led_names=None):
    """The per-LED factor that normalizes ``epoch`` onto the reference.

    ``factor = (1 / acm) * (reference_pd / pd_net) * side``, exactly the
    composition ``make_sca_digests.led_scale_factors`` applies to a response
    ratio -- so a calibrated product divided by the calibrated reference gives
    the same numbers the old single-pass pipeline did.

    The photodiode term is skipped, and the LED marked invalid, when this
    epoch's or the reference's ``pd_net`` falls at or below
    ``cfg.PD_MIN_NET``. An invalid channel yields NaN rather than 1.0: a
    silently *uncorrected* LED looks like a real response excursion of whatever
    size the lamp drifted, while a NaN propagates to the digest and is counted.
    """
    led_names = list(led_names or cfg.LED_NAMES)
    reference_pd = np.asarray(reference_pd, dtype=float)
    pd_net = np.asarray(epoch.photodiode, dtype=float)
    acm = acm_correction(epoch, reference_lvdt, corr)

    pd_factor = np.ones(len(led_names))
    side_factor = np.ones(len(led_names))
    acm_factor = np.full(len(led_names), float(acm))
    valid = np.ones(len(led_names), dtype=bool)
    notes = []

    if not np.isfinite(acm):
        valid[:] = False
        notes.append(f"ACM factor is NaN: epoch LVDT {epoch.acm_lvdt!r}, "
                     f"segment reference {reference_lvdt!r}")

    for index, led in enumerate(led_names):
        if corr.photodiode:
            epoch_net = pd_net[index] if index < len(pd_net) else np.nan
            ref_net = reference_pd[index] if index < len(reference_pd) else np.nan
            usable = (np.isfinite(epoch_net) and epoch_net > cfg.PD_MIN_NET
                      and np.isfinite(ref_net) and ref_net > cfg.PD_MIN_NET)
            if usable:
                pd_factor[index] = ref_net / epoch_net
            else:
                pd_factor[index] = np.nan
                valid[index] = False
                notes.append(
                    f"{led}: pd_net {epoch_net!r} / reference {ref_net!r} is "
                    f"not usable (needs > {cfg.PD_MIN_NET} V); the factor is "
                    f"NaN rather than 1.0")
        if corr.side and epoch.is_b_side:
            side_factor[index] = cfg.b_side_correction_for(led, epoch.mce_side)

    total = pd_factor * side_factor / acm_factor

    return CalibrationFactors(
        led_names=led_names, pd_factor=pd_factor, side_factor=side_factor,
        acm_factor=acm_factor, total_factor=total,
        pd_net=np.asarray([pd_net[i] if i < len(pd_net) else np.nan
                           for i in range(len(led_names))]),
        pd_reference=np.asarray([reference_pd[i] if i < len(reference_pd)
                                 else np.nan for i in range(len(led_names))]),
        valid=valid, notes=notes)


def apply_factors(stacks, factors):
    """``{led: stack * factor}``, leaving NaN where the factor is invalid.

    Multiplying by a NaN factor is the whole mechanism by which an invalid
    photodiode channel reaches the digests as missing data rather than as an
    apparent response excursion -- so this does *not* fall back to 1.0.
    """
    out = {}
    for led, stack in stacks.items():
        if led in factors.led_names:
            out[led] = np.asarray(stack, dtype=np.float32) * np.float32(
                factors.factor_for(led))
        else:
            out[led] = np.asarray(stack, dtype=np.float32)

    return out


# ---------------------------------------------------------------------------
# The reference card
# ---------------------------------------------------------------------------

# Per-LED pd_net is carried on the card, not just the valid count, so a trend
# plot or a factor audit over 168 epochs reads one ECSV instead of reopening
# 168 h5 files -- and so the pd values a product was calibrated against are
# recoverable from the card alone even if a raw product is later re-staged.
# How the photodiode numerator is gauged. "global" is one vector for all time,
# the only mode that existed before the side swap was considered; "per-side"
# re-bases at each MCE side because the A and B diodes are different devices.
PD_REFERENCE_GLOBAL = "global"
PD_REFERENCE_PER_SIDE = "per-side"
PD_REFERENCE_MODES = (PD_REFERENCE_GLOBAL, PD_REFERENCE_PER_SIDE)

CARD_COLUMNS = ("run_label", "name", "timestamp", "pass_number", "car_label",
                "decon_cycle", "mce_side", "mce_side_source", "stage",
                "product_kind", "bin_factor", "acm_lvdt", "segment",
                "is_reference", "pd_valid_n") + tuple(
                    f"pd_{led}" for led in cfg.LED_NAMES)


@dataclasses.dataclass
class ReferenceCard:
    """The whole-set quantities stage 2 needs, as a committed artifact.

    One row per epoch plus the reference's own photodiode levels and each
    segment's reference LVDT. Written to ECSV and read back rather than
    recomputed, for one reason: a calibrated product must be reproducible, and
    a quantity derived from "whatever was in the directory" is not. The card's
    sha256 goes into every product it calibrates, so a later digest run can
    assert that its whole input set was calibrated against one card.

    The reference epoch is the earliest by its own h5 timestamp, matching
    ``make_sca_digests.discover_h5_files``. Ordering never comes from filenames.

    ``pd_reference_mode`` selects whether the photodiode numerator is one vector
    for all time (``"global"``, the default and what every card to date holds) or
    one per MCE side (``"per-side"``). The second exists because **the A and B
    photodiodes are different physical devices behind the same mnemonic**, so a
    global numerator would put ``PD2_B/PD2_A`` into every B-side factor as a
    per-LED constant -- and the ACM bridge fits a single shared step, so it
    cannot absorb a chromatic offset. The residual would look like film growth.
    See ``PD_CORRECTION.md`` section 8.
    """

    epochs: list                                  # list[dict], one per epoch
    reference_run_label: str
    reference_name: str
    reference_timestamp: str
    reference_pd: np.ndarray                      # (6,)
    segment_reference_lvdt: dict                  # {segment: lvdt}
    led_names: list = dataclasses.field(default_factory=lambda: list(cfg.LED_NAMES))
    moves: list = dataclasses.field(default_factory=list)
    move_min_delta: float = cfg.ACM_MOVE_MIN_DELTA
    max_fractional_travel: float = 0.0
    # "global" or "per-side". In "global" mode neither this nor
    # side_reference_pd is written to the ECSV at all, so a default card stays
    # byte-identical to every card written before the option existed -- which
    # matters because the card's sha256 is recorded in every product it
    # calibrates and assert_homogeneous refuses a mismatch.
    pd_reference_mode: str = PD_REFERENCE_GLOBAL
    side_reference_pd: dict = dataclasses.field(default_factory=dict)  # {side: (6,)}
    path: str = ""
    sha256: str = ""

    @property
    def n_segments(self):
        return len(self.segment_reference_lvdt)

    @property
    def sides(self):
        """Distinct MCE sides present, canonicalized, in first-seen order."""
        seen = []
        for row in self.epochs:
            side = cfg.normalize_side(row["mce_side"])
            if side not in seen:
                seen.append(side)

        return seen

    def reference_pd_for(self, side=None):
        """The photodiode numerator for one MCE side.

        In ``"global"`` mode this ignores ``side`` and returns the set-wide
        vector, which is what keeps the mode a bit-exact no-op. In
        ``"per-side"`` mode it returns that side's own earliest epoch, so the
        first epoch after a swap gets a factor of exactly 1.0 per LED.
        """
        if self.pd_reference_mode != PD_REFERENCE_PER_SIDE:
            return np.asarray(self.reference_pd, dtype=float)

        key = cfg.normalize_side(side)
        if key not in self.side_reference_pd:
            raise KeyError(
                f"the card has no {key}-side photodiode reference "
                f"(it has {sorted(self.side_reference_pd)}). A per-side card "
                f"only covers the sides it was built from; rebuild it with "
                f"--make-card once the new side's epochs are staged.")

        return np.asarray(self.side_reference_pd[key], dtype=float)

    def row_for(self, run_label):
        """The card row for one epoch, by run label or by filename."""
        for row in self.epochs:
            if run_label in (row["run_label"], row["name"],
                             os.path.splitext(row["name"])[0]):
                return row

        raise KeyError(
            f"{run_label!r} is not in the reference card {self.path!r} "
            f"({len(self.epochs)} epochs). The card has to be rebuilt when new "
            f"passes arrive -- calibrating against a card that predates an "
            f"epoch would reference the wrong segment.")

    def pd_matrix(self):
        """``(n_epoch, 6)`` of ``pd_net``, in the card's time order."""
        return np.array([[row[f"pd_{led}"] for led in self.led_names]
                         for row in self.epochs], dtype=float)

    def pd_factor_matrix(self):
        """``(n_epoch, 6)`` of the photodiode factor each epoch would get.

        What the trend plot shows, and the cheapest audit of the correction: a
        column that wanders by a few hundred ppm is lamp drift being divided
        out, while a single point an order of magnitude away is a pedestal
        failure and should be NaN, not a factor. See :func:`led_scale_factors`.
        """
        pd = self.pd_matrix()
        if self.pd_reference_mode == PD_REFERENCE_PER_SIDE:
            # One row per epoch rather than one broadcast row, so a trend plot
            # of a two-side set shows each side normalized to its own origin
            # instead of a step at the swap.
            reference = np.array(
                [self.reference_pd_for(row["mce_side"]) for row in self.epochs],
                dtype=float)
        else:
            reference = np.asarray(self.reference_pd, dtype=float)[None, :]
        with np.errstate(divide="ignore", invalid="ignore"):
            factor = reference / pd

        return np.where((pd > cfg.PD_MIN_NET) & (reference > cfg.PD_MIN_NET),
                        factor, np.nan)

    def times(self):
        """Epoch timestamps as ``numpy.datetime64``, in card order."""
        return np.array([np.datetime64(row["timestamp"][:26])
                         for row in self.epochs])

    def factors_for(self, epoch, corr=Corrections()):
        """The :class:`CalibrationFactors` for one :class:`EpochMeta`.

        Both references are looked up per epoch: the ACM reference LVDT by the
        epoch's segment, and -- in ``per-side`` mode -- the photodiode numerator
        by its MCE side. The two are the same kind of thing, a reference that is
        only valid within the configuration it was measured in.
        """
        row = self.row_for(epoch.run_label)
        reference_lvdt = self.segment_reference_lvdt[int(row["segment"])]
        reference_pd = self.reference_pd_for(epoch.mce_side)

        return led_scale_factors(epoch, reference_pd, reference_lvdt,
                                 corr=corr, led_names=self.led_names)

    # -- build / write / read ------------------------------------------------

    @classmethod
    def build(cls, paths, assume_side=None,
              move_min_delta=cfg.ACM_MOVE_MIN_DELTA, verbose=True,
              pd_reference=PD_REFERENCE_PER_SIDE):
        """Metadata-only pass over a product set; ~0.1 s per file.

        ACM segmentation is sign-independent on purpose
        (:func:`rcs_acm.find_acm_moves`). The historical rule required a
        positive-to-negative sign change *and* a 5000-unit step, which missed
        two same-sign repositions in the flight trend and left the linear
        correction extrapolating 86 % of the way across them.

        A side change also opens a segment, through
        :func:`rcs_acm.side_change_indices` -- the same rule the digests use, so
        the two stages cannot disagree about where a configuration starts. The
        B electronics read the same ACM position with a different offset per
        LVDT channel (-172 to +205 at the 2026-10-06 swap), so without the break
        the first B epochs would be referenced to the last A segment's LVDT and
        the readout offset would reach the linear term as a fake ACM move.

        ``pd_reference="per-side"`` (the default since the swap) re-bases the
        photodiode numerator at each MCE side; see :class:`ReferenceCard`. On a
        one-side set it is bit-exact with ``"global"``. A set spanning both
        sides is *refused* in ``"global"`` mode rather than quietly carrying a
        chromatic diode offset into the trend.
        """
        if pd_reference not in PD_REFERENCE_MODES:
            raise ValueError(
                f"pd_reference must be one of {PD_REFERENCE_MODES}, "
                f"not {pd_reference!r}")
        metas = [EpochMeta.from_product(path, sequence_number=index + 1,
                                        assume_side=assume_side)
                 for index, path in enumerate(paths)]
        metas.sort(key=lambda m: m.timestamp)
        if not metas:
            raise ValueError("no products to build a reference card from")

        lvdt = np.array([m.acm_lvdt for m in metas], dtype=float)
        offsets = np.array([m.acm_offset for m in metas], dtype=float)
        sides = [m.mce_side for m in metas]
        moves = rcs_acm.label_side_moves(rcs_acm.find_acm_moves(
            lvdt, min_delta=move_min_delta,
            extra_breaks=rcs_acm.side_change_indices(sides)), sides)
        segment = rcs_acm.acm_segments(len(metas), moves)
        references = rcs_acm.segment_reference_lvdt(lvdt, segment,
                                                    offsets=offsets)
        travel = rcs_acm.max_fractional_travel(lvdt, segment, offsets=offsets,
                                               references=references)

        reference = metas[0]
        rows = []
        for index, meta in enumerate(metas):
            pd_columns = {
                f"pd_{led}": float(meta.photodiode[position])
                if position < len(meta.photodiode) else float("nan")
                for position, led in enumerate(cfg.LED_NAMES)}
            rows.append({
                **pd_columns,
                "run_label": meta.run_label, "name": meta.name,
                "timestamp": meta.timestamp.isoformat(),
                "pass_number": int(meta.pass_number),
                "car_label": meta.car_label, "decon_cycle": meta.decon_cycle,
                "mce_side": meta.mce_side,
                "mce_side_source": meta.mce_side_source,
                "stage": meta.stage, "product_kind": meta.product_kind,
                "bin_factor": int(meta.bin_factor),
                "acm_lvdt": float(meta.acm_lvdt),
                "segment": int(segment[index]),
                "is_reference": index == 0,
                "pd_valid_n": int(meta.pd_valid.sum()),
            })

        # Each side's earliest epoch, exactly as segment_reference_lvdt takes
        # each ACM segment's first epoch. metas is already timestamp-sorted, so
        # "first seen" is "earliest".
        side_reference = {}
        for meta in metas:
            side = cfg.normalize_side(meta.mce_side)
            if side not in side_reference:
                side_reference[side] = np.asarray(meta.photodiode, dtype=float)

        assert_pd_reference_spans(list(side_reference), pd_reference)

        card = cls(epochs=rows, reference_run_label=reference.run_label,
                   reference_name=reference.name,
                   reference_timestamp=reference.timestamp.isoformat(),
                   reference_pd=np.asarray(reference.photodiode, dtype=float),
                   segment_reference_lvdt={int(k): float(v)
                                           for k, v in references.items()},
                   led_names=list(cfg.LED_NAMES), moves=moves,
                   move_min_delta=float(move_min_delta),
                   max_fractional_travel=float(travel),
                   pd_reference_mode=pd_reference,
                   side_reference_pd=side_reference)

        if verbose:
            card.report()

        return card

    def report(self):
        """Print the card: segmentation, reference, and anything flagged."""
        print(f"  reference epoch : {self.reference_name} "
              f"({self.reference_timestamp})")
        print(f"  reference pd    : "
              + " ".join(f"{v:.6f}" for v in self.reference_pd))
        print(f"  epochs          : {len(self.epochs)}")
        print(f"  pd reference    : {self.pd_reference_mode}")
        if self.pd_reference_mode == PD_REFERENCE_PER_SIDE:
            for side in sorted(self.side_reference_pd):
                count = sum(1 for r in self.epochs
                            if cfg.normalize_side(r["mce_side"]) == side)
                print(f"    side {side}: "
                      + " ".join(f"{v:.6f}"
                                 for v in self.side_reference_pd[side])
                      + f"  ({count} epoch(s))")
            print(f"    each side is normalized to its own earliest epoch, "
                  f"because the A and B photodiodes are different devices")

        reference_side = cfg.normalize_side(
            self.epochs[0]["mce_side"]) if self.epochs else "A"
        if reference_side != "A":
            # Not an error: a B-only set is internally consistent. But the
            # response origin has moved off A-side t=0, and only the bridge can
            # tie the two together again.
            print(f"  NOTE: the reference epoch is on MCE side {reference_side},"
                  f" so response = 1 is at the first side-{reference_side} "
                  f"epoch rather than at A-side t=0. The side correction is "
                  f"gauged A-nominal (cfg.B_SIDE_CORRECTIONS), so these numbers "
                  f"read on the A scale; tying them to the A-side trend needs "
                  f"the A<->B bridge, not this card.")
        print(f"  ACM segments    : {self.n_segments} "
              f"(|dLVDT| >= {self.move_min_delta:g})")
        for move in self.moves:
            # 1-based, and named the same way report_acm_configuration names it.
            # move.index is the 0-based index of the first epoch *after* the
            # move; printing it raw here while the digest report prints
            # index + 1 made one move look like two different epochs.
            print(f"    move at epoch {move.index + 1:3d} of "
                  f"{len(self.epochs)}: {move.describe()}")
        for segment in sorted(self.segment_reference_lvdt):
            count = sum(1 for r in self.epochs if r["segment"] == segment)
            print(f"    segment {segment}: reference LVDT "
                  f"{self.segment_reference_lvdt[segment]:10.1f}, "
                  f"{count} epoch(s)")
        warn = "" if self.max_fractional_travel <= cfg.ACM_TRAVEL_WARN else \
            f"  <-- exceeds ACM_TRAVEL_WARN {cfg.ACM_TRAVEL_WARN}"
        print(f"  max fractional travel: {self.max_fractional_travel:.4f}{warn}")

        assumed = [r["name"] for r in self.epochs
                   if str(r["mce_side_source"]).startswith("assumed")]
        if assumed:
            print(f"  NOTE: {len(assumed)} epoch(s) have an *assumed* MCE "
                  f"side, not a recorded one; the B-side per-LED corrections "
                  f"are 1.5-6% if that assumption is wrong")
        flagged = [r["name"] for r in self.epochs
                   if r["pd_valid_n"] < len(self.led_names)]
        if flagged:
            print(f"  WARNING: {len(flagged)} epoch(s) have an unusable "
                  f"pd_net on at least one LED: {flagged[:5]}")

        for early, late, lvdt_early, lvdt_late in self.closure_checks():
            print(f"  closure: segments {early} and {late} share an LVDT "
                  f"({lvdt_early:.1f} vs {lvdt_late:.1f}) -- the product of the "
                  f"intervening bridge steps must be 1.0")

    def closure_checks(self, tolerance=cfg.ACM_CLOSURE_LVDT_TOLERANCE):
        """Segment pairs sitting at the same LVDT, which must bridge to 1.0.

        Delegates to :func:`rcs_acm.closure_checks` over the card's own
        per-epoch LVDT and segment columns, so the pairs a calibration run
        reports are the same pairs the digest run will test the fitted bridge
        steps against -- one implementation, not two that can drift.
        """
        lvdt = np.array([row["acm_lvdt"] for row in self.epochs], dtype=float)
        segment = np.array([row["segment"] for row in self.epochs], dtype=int)

        return rcs_acm.closure_checks(lvdt, segment, tolerance=tolerance)

    def to_table(self):
        """The card as an astropy ``Table``, metadata in ``table.meta``."""
        from astropy.table import Table

        table = Table([[row[name] for row in self.epochs]
                       for name in CARD_COLUMNS], names=CARD_COLUMNS)
        table.meta["reference_run_label"] = self.reference_run_label
        table.meta["reference_name"] = self.reference_name
        table.meta["reference_timestamp"] = self.reference_timestamp
        table.meta["led_names"] = list(self.led_names)
        table.meta["reference_pd"] = [float(v) for v in self.reference_pd]
        table.meta["segment_reference_lvdt"] = {
            str(k): float(v) for k, v in self.segment_reference_lvdt.items()}
        # Only in per-side mode. A default card must stay byte-identical to the
        # cards written before this option existed: its sha256 is recorded in
        # every product it calibrated, and assert_homogeneous refuses a
        # mismatch, so adding a key here unconditionally would force a stage-2
        # re-run of the whole set.
        if self.pd_reference_mode == PD_REFERENCE_PER_SIDE:
            table.meta["pd_reference_mode"] = str(self.pd_reference_mode)
            table.meta["side_reference_pd"] = {
                str(side): [float(v) for v in values]
                for side, values in self.side_reference_pd.items()}
        table.meta["move_min_delta"] = float(self.move_min_delta)
        table.meta["max_fractional_travel"] = float(self.max_fractional_travel)
        table.meta["acm_moves"] = [
            {"index": int(m.index), "lvdt_before": float(m.lvdt_before),
             "lvdt_after": float(m.lvdt_after),
             "crosses_zero": bool(m.crosses_zero)} for m in self.moves]
        table.meta["comments"] = [
            "RCS trending reference card. Produced by "
            "calibrate_rcs_products.py --make-card.",
            "reference_pd is the reference epoch's pd_net per LED, the "
            "numerator of the photodiode correction.",
            "segment_reference_lvdt is each ACM configuration's reference "
            "position; the linear ACM correction is only valid within a "
            "segment, never across a move.",
            "mce_side_source 'assumed' means nothing in the product recorded "
            "the electronics side. The B-side per-LED corrections are 1.5-6%.",
            "Every product calibrated against this card records its sha256, so "
            "a digest run can assert its input set used one card.",
        ]
        # Appended, not inserted, and only in per-side mode -- see the note on
        # byte-identity above.
        if self.pd_reference_mode == PD_REFERENCE_PER_SIDE:
            table.meta["comments"].append(
                "side_reference_pd gauges the photodiode per MCE side: the A "
                "and B diodes are different devices behind the same mnemonic, "
                "so each side is normalized to its own earliest epoch. The "
                "response origin is unaffected. See PD_CORRECTION.md section 8.")

        return table

    def write(self, path):
        """Write the ECSV and record its sha256 on the card."""
        table = self.to_table()
        directory = os.path.dirname(os.path.abspath(path))
        os.makedirs(directory, exist_ok=True)
        table.write(path, format="ascii.ecsv", overwrite=True)
        self.path = str(path)
        self.sha256 = file_sha256(path)

        return path

    @classmethod
    def read(cls, path):
        """Read a card back, including its own sha256."""
        from astropy.table import Table

        table = Table.read(path, format="ascii.ecsv")
        meta = table.meta
        rows = [{name: row[name] for name in table.colnames} for row in table]
        for row in rows:
            row["is_reference"] = bool(row["is_reference"])
            row["segment"] = int(row["segment"])

        moves = [rcs_acm.AcmMove(index=int(m["index"]),
                                 lvdt_before=float(m["lvdt_before"]),
                                 lvdt_after=float(m["lvdt_after"]))
                 for m in meta.get("acm_moves", [])]

        card = cls(
            epochs=rows,
            reference_run_label=str(meta["reference_run_label"]),
            reference_name=str(meta["reference_name"]),
            reference_timestamp=str(meta["reference_timestamp"]),
            reference_pd=np.asarray(meta["reference_pd"], dtype=float),
            segment_reference_lvdt={int(k): float(v) for k, v
                                    in meta["segment_reference_lvdt"].items()},
            led_names=[str(n) for n in meta["led_names"]],
            moves=moves,
            move_min_delta=float(meta.get("move_min_delta",
                                          cfg.ACM_MOVE_MIN_DELTA)),
            max_fractional_travel=float(meta.get("max_fractional_travel", 0.0)),
            # Absent on every card written in global mode, including all cards
            # written before the option existed.
            pd_reference_mode=str(meta.get("pd_reference_mode",
                                           PD_REFERENCE_GLOBAL)),
            side_reference_pd={
                cfg.normalize_side(k): np.asarray(v, dtype=float)
                for k, v in meta.get("side_reference_pd", {}).items()},
            path=str(path), sha256=file_sha256(path))

        return card


def assert_pd_reference_spans(sides, pd_reference):
    """Refuse a multi-side product set gauged with one photodiode reference.

    This is the guard that makes ``global`` -- the default -- safe for someone
    who never reads the flag, so it is deliberately a refusal and not a
    warning. It is also the *only* refusal in the side-swap work: the other
    readings are reported, because a chromatic step across a swap is expected
    (the side table is ground-derived and known to need a flight replacement)
    while a global numerator across a swap is simply wrong.

    Split out of :meth:`ReferenceCard.build` so it can be exercised without
    staging two sides of synthetic products.
    """
    sides = [cfg.normalize_side(s) for s in sides]
    if len(set(sides)) > 1 and pd_reference == PD_REFERENCE_GLOBAL:
        raise SystemExit(
            f"this set spans MCE sides {sorted(set(sides))} but the photodiode "
            f"reference is gauged 'global'.\n"
            f"The A and B photodiodes are different physical devices behind "
            f"the same mnemonic, so one global numerator puts the "
            f"PD2_B/PD2_A responsivity ratio into every {sides[-1]}-side "
            f"factor as a per-LED constant. The ACM bridge fits a single "
            f"shared step and cannot absorb a chromatic offset, so that "
            f"residual survives into the trend looking like film growth.\n"
            f"Rebuild with --pd-reference per-side (see PD_CORRECTION.md "
            f"section 8), or restrict the set to one side.")


def file_sha256(path, chunk=1 << 20):
    """Hex sha256 of a file, read in chunks."""
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(chunk), b""):
            digest.update(block)

    return digest.hexdigest()


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------

def self_test(verbose=True):
    """Checks that need no data: the factor algebra and the card round trip."""
    failures = []

    def check(name, condition, detail=""):
        if condition:
            if verbose:
                print(f"  ok   {name}")
        else:
            failures.append(name)
            print(f"  FAIL {name} {detail}")

    def epoch(pd, lvdt=-2815.0, side="A", label="E"):
        return EpochMeta(path=f"/tmp/{label}.h5", name=f"{label}.h5",
                         run_label=label, timestamp=None, pass_number=1,
                         photodiode=np.asarray(pd, dtype=float),
                         acm_lvdt=lvdt, mce_side=side,
                         mce_side_source="attribute")

    nominal = np.full(cfg.N_LEDS, 0.25)

    # 1. An epoch calibrated against itself has every factor exactly 1.
    reference = epoch(nominal, label="REF")
    factors = led_scale_factors(reference, nominal, -2815.0)
    check("self-calibration gives exactly 1.0",
          np.all(factors.total_factor == 1.0) and factors.all_valid,
          str(factors.total_factor))

    # 2. The photodiode factor is exactly ref_pd / epoch_pd, by hand.
    dim = epoch(nominal * 0.9, label="DIM")
    factors = led_scale_factors(dim, nominal, -2815.0)
    check("pd factor is ref/epoch", np.allclose(factors.total_factor, 1 / 0.9),
          str(factors.total_factor[:2]))

    # 3. A pd_net at the guard threshold yields NaN, never 1.0 -- the 60x
    #    runaway this guard exists for.
    collapsed = epoch(np.array([0.25, 0.25, 0.004, 0.25, 0.25, 0.25]),
                      label="BAD")
    factors = led_scale_factors(collapsed, nominal, -2815.0)
    check("a collapsed pd_net gives NaN, not a 60x factor",
          np.isnan(factors.total_factor[2]) and not factors.valid[2]
          and np.isfinite(factors.total_factor[[0, 1, 3, 4, 5]]).all(),
          str(factors.total_factor))
    check("the collapsed channel is explained in notes",
          any("pd_net" in note for note in factors.notes))
    check("60x is what would have happened without the guard",
          abs(0.25 / 0.004 - 62.5) < 1e-9)

    # 4. The ACM term, and that it is valid only within a segment.
    moved = epoch(nominal, lvdt=-2900.0, label="MOVED")
    factors = led_scale_factors(moved, nominal, -2815.0)
    travel = (-2900.0) / (-2815.0) - 1.0
    expected = 1.0 / (1.0 + cfg.ACM_COEF_DEFAULT * travel)
    check("acm factor matches the linear form by hand",
          np.allclose(factors.total_factor, expected), str(factors.total_factor[0]))
    check("corrections can be switched off individually",
          np.all(led_scale_factors(moved, nominal, -2815.0,
                                   Corrections(acm=False)).total_factor == 1.0))

    # 5. The side term fires only on B, and uses the per-LED table.
    b_side = epoch(nominal, side="B", label="B")
    factors = led_scale_factors(b_side, nominal, cfg.acm_offset_for("B") - 2815.0)
    check("B side applies the per-LED correction",
          np.allclose(factors.side_factor,
                      [cfg.b_side_correction_for(led, "B")
                       for led in cfg.LED_NAMES]))
    check("A side applies no side correction",
          np.all(led_scale_factors(reference, nominal, -2815.0).side_factor
                 == 1.0))

    # 6. apply_factors propagates NaN rather than silently leaving data
    #    uncorrected.
    stacks = {led: np.ones((cfg.N_SCAS, 4, 4), dtype=np.float32)
              for led in cfg.LED_NAMES}
    out = apply_factors(stacks, led_scale_factors(collapsed, nominal, -2815.0))
    check("an invalid LED's arrays become NaN",
          np.all(np.isnan(out["LED3"])) and np.all(np.isfinite(out["LED1"])))

    # 7. Card round trip, including the closure pair the reference set has.
    import tempfile

    lvdt = [7559.0, 7559.1, -2815.2, -2815.1, -5232.0, -5232.1, -2814.7]
    rows = []
    moves = rcs_acm.find_acm_moves(np.array(lvdt), min_delta=cfg.ACM_MOVE_MIN_DELTA)
    segment = rcs_acm.acm_segments(len(lvdt), moves)
    references = rcs_acm.segment_reference_lvdt(np.array(lvdt), segment)
    for index, value in enumerate(lvdt):
        rows.append({"run_label": f"E{index}", "name": f"E{index}.h5",
                     "timestamp": f"2026-09-{index+10:02d}T00:00:00+00:00",
                     "pass_number": index + 1, "car_label": "CAR190",
                     "decon_cycle": "decon2", "mce_side": "A",
                     "mce_side_source": "attribute", "stage": "raw",
                     "product_kind": "per_sca", "bin_factor": 16,
                     "acm_lvdt": value, "segment": int(segment[index]),
                     "is_reference": index == 0, "pd_valid_n": cfg.N_LEDS,
                     **{f"pd_{led}": 0.25 for led in cfg.LED_NAMES}})
    card = ReferenceCard(epochs=rows, reference_run_label="E0",
                         reference_name="E0.h5",
                         reference_timestamp="2026-09-10T00:00:00+00:00",
                         reference_pd=nominal,
                         segment_reference_lvdt={int(k): float(v) for k, v
                                                 in references.items()},
                         moves=moves)
    check("sign-independent detection finds all three moves",
          len(moves) == 3, f"{len(moves)} moves")
    check("four ACM segments", card.n_segments == 4, str(card.n_segments))
    closure = card.closure_checks()
    check("segments 1 and 3 are flagged as a closure pair",
          any((c[0], c[1]) == (1, 3) for c in closure), str(closure))

    with tempfile.TemporaryDirectory() as tmp:
        path = card.write(os.path.join(tmp, "card.ecsv"))
        check("card write records a sha256", len(card.sha256) == 64)
        back = ReferenceCard.read(path)
        check("card sha256 round-trips", back.sha256 == card.sha256)
        check("card reference_pd round-trips",
              np.allclose(back.reference_pd, card.reference_pd))
        check("card segments round-trip",
              back.segment_reference_lvdt == card.segment_reference_lvdt,
              f"{back.segment_reference_lvdt} vs {card.segment_reference_lvdt}")
        check("card moves round-trip", len(back.moves) == 3)
        check("row lookup works by run label and by filename",
              back.row_for("E4")["segment"] == 2
              and back.row_for("E4.h5")["segment"] == 2)
        check("an unknown epoch is refused, not defaulted",
              _raises(KeyError, back.row_for, "E99"))

        # The point of the card: each epoch is referenced to its *own*
        # segment, so an epoch sitting at -5232 is not extrapolated from
        # -2815. Without segmentation that is 86% fractional travel.
        far = epoch(nominal, lvdt=-5232.0, label="E4")
        in_segment = back.factors_for(far)
        naive = led_scale_factors(far, nominal,
                                  back.segment_reference_lvdt[0])
        check("segment referencing beats a single global reference",
              abs(in_segment.total_factor[0] - 1.0)
              < abs(naive.total_factor[0] - 1.0) / 100,
              f"{in_segment.total_factor[0]} vs {naive.total_factor[0]}")

    # 8. mce_side resolution, the latent-bug guard.
    side, source = rcs_products.mce_side_from("SCIPA_R1_MCEB.h5", {})
    check("TVAC filenames still resolve the side",
          (side, source) == ("B", "filename:_MCE[AB]"), f"{side} {source}")
    check("a flight name with no attribute raises rather than assuming A",
          _raises(ValueError, rcs_products.mce_side_from,
                  "CAR190_01039_02_036_001_20260922.h5", {}))
    check("--assume-side is the explicit escape hatch",
          rcs_products.mce_side_from("CAR190_x.h5", {}, assume="A")
          == ("A", "assumed"))

    # 9. The per-side photodiode reference. Three things have to hold at once:
    #    the default is a bit-exact no-op, the opt-in re-bases at the swap, and
    #    the combination nobody should ever get (two sides, one global
    #    numerator) is refused rather than quietly carrying a chromatic offset.
    #    The A/B ratio planted here is chromatic by construction, because an
    #    achromatic one would be absorbed by the bridge step and would not be a
    #    test of anything.
    diode_ratio = np.array([1.031, 1.012, 0.994, 1.021, 1.008, 0.977])

    def side_rows(sides, pd_by_side):
        out = []
        for index, side in enumerate(sides):
            out.append({"run_label": f"S{index}", "name": f"S{index}.h5",
                        "timestamp": f"2026-09-{index + 10:02d}T00:00:00+00:00",
                        "pass_number": index + 1, "car_label": "CAR190",
                        "decon_cycle": "decon2", "mce_side": side,
                        "mce_side_source": "attribute", "stage": "raw",
                        "product_kind": "per_sca", "bin_factor": 16,
                        "acm_lvdt": -2815.0, "segment": 0,
                        "is_reference": index == 0,
                        "pd_valid_n": cfg.N_LEDS,
                        **{f"pd_{led}": float(pd_by_side[side][position])
                           for position, led in enumerate(cfg.LED_NAMES)}})
        return out

    pd_by_side = {"A": nominal, "B": nominal * diode_ratio}
    two_sided = side_rows(["A"] * 3 + ["B"] * 3, pd_by_side)

    check("a one-side set in global mode is allowed",
          assert_pd_reference_spans(["A", "A"], PD_REFERENCE_GLOBAL) is None)
    check("two sides with a global pd reference is REFUSED",
          _raises(SystemExit, assert_pd_reference_spans, ["A", "B"],
                  PD_REFERENCE_GLOBAL))
    check("two sides with a per-side pd reference is allowed",
          assert_pd_reference_spans(["A", "B"], PD_REFERENCE_PER_SIDE) is None)

    per_side = ReferenceCard(
        epochs=two_sided, reference_run_label="S0", reference_name="S0.h5",
        reference_timestamp="2026-09-10T00:00:00+00:00",
        reference_pd=nominal, segment_reference_lvdt={0: -2815.0},
        pd_reference_mode=PD_REFERENCE_PER_SIDE,
        side_reference_pd={"A": nominal, "B": nominal * diode_ratio})
    check("both sides are listed in first-seen order",
          per_side.sides == ["A", "B"], str(per_side.sides))
    factors = per_side.pd_factor_matrix()
    check("the first epoch after the swap is exactly 1.0 on every LED",
          np.all(factors[3] == 1.0), str(factors[3]))
    check("the A-side origin is untouched by the opt-in",
          np.all(factors[0] == 1.0), str(factors[0]))

    # What the refusal above is protecting: the same rows with one global
    # numerator put the diode ratio into every B-side factor, and it is
    # chromatic, so no single bridge step can take it out.
    global_mode = dataclasses.replace(per_side,
                                      pd_reference_mode=PD_REFERENCE_GLOBAL)
    leaked = global_mode.pd_factor_matrix()[3]
    check("a global numerator would leak the diode ratio into the B factors",
          np.allclose(leaked, 1.0 / diode_ratio)
          and np.std(leaked, ddof=1) > 0.01, str(leaked))

    # The no-op requirement, on a single-side set: identical factors at 0.0,
    # and -- separately -- no new ECSV meta key, because the card's sha256 is
    # recorded in every product it calibrates.
    one_side = side_rows(["A"] * 4, pd_by_side)
    base = ReferenceCard(epochs=one_side, reference_run_label="S0",
                         reference_name="S0.h5",
                         reference_timestamp="2026-09-10T00:00:00+00:00",
                         reference_pd=nominal,
                         segment_reference_lvdt={0: -2815.0})
    opted = dataclasses.replace(base,
                                pd_reference_mode=PD_REFERENCE_PER_SIDE,
                                side_reference_pd={"A": nominal})
    difference = np.abs(base.pd_factor_matrix() - opted.pd_factor_matrix())
    check("per-side on a one-side set is bit-exact, not just close",
          np.all(difference == 0.0), str(np.nanmax(difference)))
    check("global mode writes no new card meta key",
          "pd_reference_mode" not in base.to_table().meta
          and "side_reference_pd" not in base.to_table().meta,
          str(sorted(base.to_table().meta)))
    check("per-side mode does write them",
          "side_reference_pd" in opted.to_table().meta)
    # A per-side card only covers the sides it was built from. Asking it for
    # the other side has to fail loudly: silently falling back to the global
    # vector is exactly the chromatic leak the mode exists to prevent.
    check("a side the card does not cover is refused, not defaulted to global",
          _raises(KeyError, opted.reference_pd_for, "B"))
    check("an uninterpretable side label is refused upstream of the lookup",
          _raises(ValueError, opted.reference_pd_for, "C"))

    with tempfile.TemporaryDirectory() as tmp:
        path = per_side.write(os.path.join(tmp, "per_side.ecsv"))
        back = ReferenceCard.read(path)
        check("the per-side mode round-trips through the ECSV",
              back.pd_reference_mode == PD_REFERENCE_PER_SIDE
              and np.allclose(back.reference_pd_for("B"),
                              nominal * diode_ratio),
              f"{back.pd_reference_mode} {back.side_reference_pd}")
        plain = ReferenceCard.read(
            base.write(os.path.join(tmp, "global.ecsv")))
        check("a card with no mode key reads back as global",
              plain.pd_reference_mode == PD_REFERENCE_GLOBAL
              and np.allclose(plain.reference_pd_for("B"), nominal),
              plain.pd_reference_mode)

    print(f"rcs_corrections.self_test: "
          f"{'ok' if not failures else 'FAILED'} ({len(failures)} failure(s))")

    return not failures


def _raises(kind, function, *args, **kwargs):
    try:
        function(*args, **kwargs)
    except kind:
        return True

    return False


if __name__ == "__main__":
    import sys

    sys.exit(0 if self_test() else 1)
