"""Plots for the RCS trending products: photodiode diagnostics and mosaic views.

Separate from :mod:`digest_plots`, which plots *digest* quantities (response
versus time, bridge steps). This module plots the things a single epoch's product
contains, and it is the only plotting module the staging path imports -- always
lazily, so a batch node that never passes ``--pd-plot`` does not pay for
matplotlib.

The photodiode figure here is the one deliverable that can actually answer "is
the housekeeping really mapped per activity". Every other check on the PD is a
number that has to be trusted; this one puts the exposure windows, the LED
enable states and the PD trace on a shared time axis, so a window attributed to
the wrong lamp or a pedestal taken from a not-actually-off interval is visible
rather than inferred.
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt    # noqa: E402
import numpy as np                 # noqa: E402

import rcs_trend_config as cfg     # noqa: E402

# One colour per LED state. The all-off state gets a neutral grey and unknown
# gets a hatch rather than a colour, because "we have no telemetry here" must
# not look like a measurement.
STATE_COLORS = {
    cfg.PD_STATE_OFF: "0.85",
    1: "#d62728", 2: "#ff7f0e", 3: "#bcbd22",
    4: "#2ca02c", 5: "#1f77b4", 6: "#9467bd",
    cfg.PD_STATE_MULTIPLE: "#e377c2",
}
UNKNOWN_COLOR = "#f0e0e0"


def _state_label(state):
    if state == cfg.PD_STATE_UNKNOWN:
        return "unknown"
    if state == cfg.PD_STATE_OFF:
        return "all off"
    if state == cfg.PD_STATE_MULTIPLE:
        return "MULTIPLE"

    return f"LED{state}"


def _minutes_since(times, origin):
    return (times - origin) / np.timedelta64(1, "m")


def _shade_states(axis, reduction, origin):
    """Shade each state interval; transitions get an outline instead of a fill.

    Drawing a one-sample interval as a filled band would make a flipped
    telemetry sample look like a state the instrument was in, which is exactly
    the confusion ``is_transition`` exists to prevent.
    """
    seen = set()
    for interval in reduction.intervals:
        t0 = _minutes_since(interval.t_begin, origin)
        t1 = _minutes_since(interval.t_end, origin)
        if interval.is_transition:
            axis.axvline(t0, color="0.4", lw=0.5, ls=":", zorder=0)
            continue
        color = STATE_COLORS.get(interval.state, UNKNOWN_COLOR)
        label = None if interval.state in seen else _state_label(interval.state)
        seen.add(interval.state)
        axis.axvspan(t0, t1, color=color, alpha=0.45, lw=0, zorder=0,
                     label=label,
                     hatch="///" if interval.state == cfg.PD_STATE_UNKNOWN
                     else None)


def plot_pd_activity_summary(reduction, label, path, dpi=120):
    """Write the per-epoch photodiode summary PNG.

    Three stacked panels on a shared time axis plus a bar panel:

    1. PD volts with the LED state intervals shaded, the exposure windows
       outlined, the adopted pedestal as a horizontal line and the off-interval
       medians as points. The pedestal line crossing a shaded *off* band is the
       visual confirmation that it came from telemetry that was really off.
    2. The LED forward voltage, which should step with the shading. A forward
       voltage that rises while the shading says "all off" means the enables and
       the drive disagree.
    3. The second diode (PD1), which is **also lit** -- see
       ``rcs_photodiode.reduce_per_activity`` for the measurement. Plotted with
       the per-activity ``pd_check_ratio`` overlaid on a right-hand axis, since
       the check this panel provides is that the ratio holds its per-LED value
       (~1100 ppm reproducibility across the trend), not that PD1 is flat.
    4. Per-activity ``pd_raw`` / ``pedestal`` / ``pd_net`` bars, annotated with
       the hardware LED and the state fraction, with invalid nets called out.
    """
    times = reduction.times
    if not len(times):
        figure, axis = plt.subplots(figsize=(10, 3))
        axis.text(0.5, 0.5, f"{label}\nno photodiode samples in the EDP window",
                  ha="center", va="center", transform=axis.transAxes)
        axis.set_axis_off()
        _save(figure, path, dpi)
        return path

    origin = times[0]
    minutes = _minutes_since(times, origin)
    pedestal = reduction.pedestal

    figure, axes = plt.subplots(
        4, 1, figsize=(13, 12), sharex=False,
        gridspec_kw={"height_ratios": [3, 1.1, 1.1, 2.2], "hspace": 0.33})
    pd_axis, forward_axis, check_axis, bar_axis = axes

    # ---- panel 1: the PD trace -------------------------------------------
    _shade_states(pd_axis, reduction, origin)
    pd_axis.plot(minutes, reduction.pd_v, color="k", lw=0.8, zorder=3)

    if np.isfinite(pedestal.value):
        pd_axis.axhline(pedestal.value, color="#17becf", lw=1.4, ls="--",
                        zorder=4,
                        label=f"pedestal {pedestal.value:.5f} V "
                              f"({pedestal.source})")
        pd_axis.axhspan(pedestal.value - pedestal.rms,
                        pedestal.value + pedestal.rms,
                        color="#17becf", alpha=0.25, lw=0, zorder=2)

    off_intervals = [iv for iv in reduction.intervals
                     if iv.state == cfg.PD_STATE_OFF and not iv.is_transition]
    if off_intervals:
        mids = [_minutes_since(iv.t_begin, origin)
                + 0.5 * _minutes_since(iv.t_end, iv.t_begin)
                for iv in off_intervals]
        pd_axis.plot(mids, [iv.pd_median for iv in off_intervals], "o",
                     ms=5, mfc="none", mec="#17becf", mew=1.4, zorder=5,
                     label=f"off-interval medians ({len(off_intervals)})")

    # Scale to the pedestal-and-exposure band, not to the full trace, and do it
    # before anything is positioned relative to the axis limits. The PD rails at
    # cfg.PD_RAIL_V in the inter-exposure gaps while the drive settles, which is
    # ~7x the illuminated level and flattens everything this panel exists to
    # show. Off-scale samples are not dropped: they are redrawn as markers along
    # the top edge with a count, so clipped telemetry stays visible.
    in_window = reduction.activity_index >= 0
    band = reduction.pd_v[in_window & np.isfinite(reduction.pd_v)]
    if len(band):
        low = min(np.nanmin(band), pedestal.value if
                  np.isfinite(pedestal.value) else np.nanmin(band))
        high = np.nanmax(band)
        margin = 0.25 * max(high - low, 1e-3)
        pd_axis.set_ylim(low - margin, high + margin)
        above = np.flatnonzero(reduction.pd_v > high + margin)
        if len(above):
            pd_axis.plot(minutes[above],
                         np.full(len(above), high + margin * 0.92), "v",
                         ms=4, color="#d62728", zorder=8,
                         label=f"{len(above)} sample(s) above scale, max "
                               f"{np.nanmax(reduction.pd_v):.3f} V")

    # enumerate, not .index(activity): ActivityPd is a dataclass, so .index()
    # would match by *value* and two activities with identical reductions would
    # both resolve to the first one's window.
    for position, activity in enumerate(reduction.per_activity):
        rows = np.flatnonzero(reduction.activity_index == position)
        if not len(rows):
            continue
        pd_axis.axvspan(minutes[rows[0]], minutes[rows[-1]], facecolor="none",
                        edgecolor="k", lw=1.0, ls="-", zorder=6)
        pd_axis.text(minutes[rows[0]], pd_axis.get_ylim()[1], activity.key,
                     rotation=90, fontsize=7, va="top", ha="right", zorder=7)

    pd_axis.set_ylabel("PD2 (V)")
    pd_axis.set_title(
        f"{label}   photodiode per activity\n"
        f"pedestal {pedestal.value:.5f} +/- {pedestal.rms:.5f} V from "
        f"{pedestal.source} ({pedestal.n_samples} samples), drift "
        f"{pedestal.drift_v_per_hr:+.2e} V/hr", fontsize=10)
    pd_axis.legend(fontsize=7, ncol=4, loc="center left", framealpha=0.9)

    # ---- panels 2 and 3: the corroborating channels ----------------------
    for axis, values, name, note in (
            (forward_axis, reduction.forward_v, "LED drive (V)",
             "should step with the shading"),
            (check_axis, reduction.pd_check_v, "PD1, 2nd monitor (V)",
             "lit too; watch the ratio, not the level")):
        _shade_states(axis, reduction, origin)
        axis.plot(minutes, values, color="k", lw=0.8, zorder=3)
        axis.set_ylabel(name, fontsize=9)
        axis.text(0.995, 0.9, note, fontsize=7, color="0.35", ha="right",
                  va="top", transform=axis.transAxes)
        # PD1 rails in the gaps exactly as PD2 does, so it needs the same
        # in-window scaling or the illuminated steps this panel exists to show
        # are squashed into the bottom sixth of it. The drive voltage does not
        # rail, hence keying off the measured band rather than hard-coding.
        band = values[in_window & np.isfinite(values)]
        if len(band) and np.nanmax(band) < np.nanmax(values):
            axis.set_ylim(np.nanmin(band) - 0.05 * np.ptp(band),
                          np.nanmax(band) + 0.25 * max(np.ptp(band), 1e-3))

    # PD1/PD2 net per activity, on its own axis. This is the panel's actual
    # check: the ratio is a fixed per-LED number, so a point off its neighbours'
    # trend means a diode or a window-to-lamp mapping moved, whereas a real lamp
    # change moves both diodes and leaves the ratio alone.
    ratio_axis = check_axis.twinx()
    ratios = [(position, activity.pd_check_ratio)
              for position, activity in enumerate(reduction.per_activity)
              if np.isfinite(activity.pd_check_ratio)]
    if ratios:
        centres = []
        for position, _ in ratios:
            rows = np.flatnonzero(reduction.activity_index == position)
            centres.append(np.nan if not len(rows)
                           else 0.5 * (minutes[rows[0]] + minutes[rows[-1]]))
        ratio_axis.plot(centres, [value for _, value in ratios], "D",
                        ms=4, color="#8c564b", zorder=6)
        # Suppress a label only when it would *repeat* its neighbour's value at
        # the printed precision. CAR-216's four AUX_LED3FLAT activities run back
        # to back on one lamp, so labelling each renders four identical numbers
        # overprinted into a smear. Keying on the value rather than on x-distance
        # matters: the exposures are packed tightly enough that a distance rule
        # also drops genuinely distinct LEDs, which are the whole point here.
        # The diamonds are drawn for every activity either way.
        last = None
        for centre, (_, value) in zip(centres, ratios):
            text = f"{value:.3f}"
            if not np.isfinite(centre) or text == last:
                continue
            ratio_axis.annotate(text, (centre, value), fontsize=6,
                                color="#8c564b", ha="center",
                                textcoords="offset points", xytext=(0, 5))
            last = text
    ratio_axis.set_ylabel("PD1/PD2 net", fontsize=8, color="#8c564b")
    ratio_axis.tick_params(axis="y", labelsize=7, colors="#8c564b")

    check_axis.set_xlabel(f"minutes since {str(origin)[:19]} UTC")
    for axis in (pd_axis, forward_axis, check_axis):
        axis.set_xlim(minutes[0], minutes[-1])
    ratio_axis.set_xlim(minutes[0], minutes[-1])

    # ---- panel 4: the per-activity reduction ----------------------------
    activities = reduction.per_activity
    positions = np.arange(len(activities))
    width = 0.27
    raw = [a.pd_raw for a in activities]
    net = [a.pd_net for a in activities]
    bar_axis.bar(positions - width, raw, width, label="pd_raw", color="0.55")
    bar_axis.bar(positions, [pedestal.value] * len(activities), width,
                 label="pedestal", color="#17becf")
    bar_axis.bar(positions + width, net, width, label="pd_net",
                 color=["#2ca02c" if a.pd_net_valid or a.is_dark else "#d62728"
                        for a in activities])
    bar_axis.axhline(cfg.PD_MIN_NET, color="#d62728", lw=1.0, ls=":",
                     label=f"PD_MIN_NET = {cfg.PD_MIN_NET} V")

    for position, activity in zip(positions, activities):
        hardware = ("dark" if activity.is_dark
                    else (f"LED{activity.hardware_led}"
                          if activity.hardware_led is not None
                          else _state_label(activity.state_code)))
        note = f"{hardware}\n{activity.state_fraction:.0%} pure\nn={activity.pd_n_samples}"
        if not activity.state_pure:
            note += "\nSTRADDLES"
        if activity.n_railed:
            note += f"\n{activity.n_railed} RAILED"
        if not (activity.pd_net_valid or activity.is_dark):
            note += "\nINVALID"
        if activity.rule != "window":
            note += f"\n{activity.rule}"
        bar_axis.text(position, max(raw) * 1.04, note, fontsize=6.5,
                      ha="center", va="bottom")

    bar_axis.set_xticks(positions)
    bar_axis.set_xticklabels([a.key for a in activities], rotation=30,
                             ha="right", fontsize=8)
    bar_axis.set_ylabel("volts")
    bar_axis.set_ylim(0, max(raw) * 1.45)
    bar_axis.legend(fontsize=7, ncol=4, loc="upper left")

    messages = reduction.warnings + pedestal.warnings + [
        w for a in activities for w in a.warnings]
    if messages:
        figure.text(0.01, 0.005,
                    "WARNINGS: " + "  |  ".join(messages[:4])
                    + (f"  (+{len(messages) - 4} more)"
                       if len(messages) > 4 else ""),
                    fontsize=7, color="#d62728", va="bottom")

    _save(figure, path, dpi)

    return path


def plot_pd_sequence_timeline(reduction, label, path, dpi=120, runs=None):
    """Write the LED-sequence diagnostic PNG: settle, exposure, and what L2 saw.

    This answers "the LED is turned on for some settling time, then the exposure
    value is recorded" -- with one correction to the premise. **The L2 metadata
    holds no photodiode reading.** ``meta.rcs`` is
    ``{active, bank, counts, electronics, led}``, and none of the 146 metadata
    leaves of a ``*_cal.asdf`` matches photo/diode/pd/current/volt/lamp. So there
    is no L2-recorded PD to plot against the stream. What L2 *does* declare is
    the LED flag, the commanded drive (``counts``, 1500) and the exposure
    bracket; the PD value the L2 frame actually integrated against is the
    in-exposure median of this stream, which is the quantity drawn here and the
    one the corrections consume.

    Three panels:

    1. The PD trace on a **log** axis, which is required rather than cosmetic:
       the pedestal (~0.116 V), the exposure level (~0.36 V) and the 2.5 V rail
       span a factor of 21, and :func:`plot_pd_activity_summary` deliberately
       clips to the exposure band, so the turn-on transient is invisible there.
       Enable intervals are shaded by LED, exposure windows outlined, the adopted
       in-exposure level drawn across each window, and the moment the PD comes
       off its rail marked.
    2. PD versus **seconds since that activity's enable**, all activities
       overlaid. This is the settle shape itself: three LEDs step straight to
       level, three sit on the rail for 35-64 s first.
    3. A Gantt row per activity splitting the enable interval into railed /
       settled-and-waiting / exposing. The bar that matters is the amber one: it
       is the margin between the PD becoming readable and the shutter opening,
       and a missing amber segment would mean an exposure integrating against an
       off-scale PD.
    """
    import rcs_photodiode

    times = reduction.times
    if not len(times):
        figure, axis = plt.subplots(figsize=(10, 3))
        axis.text(0.5, 0.5, f"{label}\nno photodiode samples in the EDP window",
                  ha="center", va="center", transform=axis.transAxes)
        axis.set_axis_off()
        _save(figure, path, dpi)
        return path

    runs = rcs_photodiode.enable_runs(reduction) if runs is None else runs
    origin = times[0]
    minutes = _minutes_since(times, origin)
    pedestal = reduction.pedestal

    figure, axes = plt.subplots(
        3, 1, figsize=(13, 11),
        gridspec_kw={"height_ratios": [2.6, 1.8, 1.9], "hspace": 0.62})
    trace_axis, settle_axis, gantt_axis = axes

    # ---- panel 1: the whole stream, log scale ----------------------------
    _shade_states(trace_axis, reduction, origin)
    trace_axis.plot(minutes, reduction.pd_v, color="k", lw=0.8, zorder=3)
    trace_axis.set_yscale("log")

    if np.isfinite(pedestal.value):
        trace_axis.axhline(pedestal.value, color="#17becf", lw=1.3, ls="--",
                           zorder=4,
                           label=f"pedestal {pedestal.value:.5f} V "
                                 f"({pedestal.source})")
    trace_axis.axhline(cfg.PD_RAIL_V, color="#d62728", lw=1.2, ls=":", zorder=4,
                       label=f"PD clip {cfg.PD_RAIL_V} V (readout saturated; "
                             f"overshoot amplitude unmeasurable)")

    railed = np.flatnonzero(reduction.pd_v >= cfg.PD_RAIL_V - 1e-6)
    if len(railed):
        trace_axis.plot(minutes[railed], reduction.pd_v[railed], ".",
                        ms=3, color="#d62728", zorder=5,
                        label=f"{len(railed)} clipped sample(s)")

    # The in-exposure level, drawn across the window it was measured over. This
    # is the "value recorded for each LED flag" that L2 has no field for.
    for position, activity in enumerate(reduction.per_activity):
        rows = np.flatnonzero(reduction.activity_index == position)
        if not len(rows):
            continue
        trace_axis.axvspan(minutes[rows[0]], minutes[rows[-1]], facecolor="none",
                           edgecolor="k", lw=1.0, zorder=6)
        trace_axis.plot([minutes[rows[0]], minutes[rows[-1]]],
                        [activity.pd_raw] * 2, color="#2ca02c", lw=2.6,
                        solid_capstyle="butt", zorder=7,
                        label="in-exposure median (what L2 integrated against)"
                              if position == 0 else None)
        # Labels go in the empty decade between the exposure level (~0.36 V) and
        # the rail (2.5 V), not at the top of the axis: CAR-216's four
        # AUX_LED3FLAT exposures are ~1 minute apart, so top-anchored labels
        # collide with each other and with the title. Alternating the height
        # separates the close pairs without shrinking the font further.
        trace_axis.text(0.5 * (minutes[rows[0]] + minutes[rows[-1]]),
                        activity.pd_raw * (1.9 if position % 2 else 4.2),
                        activity.key, rotation=90, fontsize=6.5,
                        va="bottom", ha="center", zorder=7)

    for record in runs:
        if not record["rail_seconds"]:
            continue
        trace_axis.axvline(_minutes_since(record["t_settled"], origin),
                           color="#ff7f0e", lw=1.1, zorder=5)

    trace_axis.set_ylabel("PD2 (V, log)")
    trace_axis.set_xlabel(f"minutes since {str(origin)[:19]} UTC", fontsize=9)
    trace_axis.set_xlim(minutes[0], minutes[-1])
    trace_axis.set_ylim(top=cfg.PD_RAIL_V * 1.6)
    trace_axis.set_title(
        f"{label}   LED sequence: enable, settle, exposure\n"
        f"L2 metadata carries no photodiode value (meta.rcs = active, bank, "
        f"counts, electronics, led) -- the green bars are the measured "
        f"in-exposure level", fontsize=10)
    trace_axis.legend(fontsize=7, ncol=3, loc="upper center",
                      bbox_to_anchor=(0.5, -0.20), framealpha=0.9)

    # ---- panel 2: the settle shape, aligned on enable --------------------
    for record in runs:
        led = record["hardware_led"]
        rows = np.flatnonzero(reduction.state == led)
        if not len(rows):
            continue
        groups = np.split(rows, np.flatnonzero(np.diff(rows) > 1) + 1)
        begin = int(np.searchsorted(times, record["t_enable"]))
        run = min(groups, key=lambda r: abs(int(r[0]) - begin))
        elapsed = (times[run] - record["t_enable"]) / np.timedelta64(1, "s")
        settle_axis.plot(elapsed, reduction.pd_v[run], lw=1.0,
                         color=STATE_COLORS.get(led, "0.4"),
                         label=f"{record['key']} (LED{led})")
        window = (elapsed >= record["exposure_start_s"]) & (
            elapsed <= record["exposure_start_s"] + record["exposure_seconds"])
        if window.any():
            settle_axis.plot(elapsed[window], reduction.pd_v[run][window],
                             lw=3.0, alpha=0.5,
                             color=STATE_COLORS.get(led, "0.4"))

    settle_axis.set_yscale("log")
    settle_axis.axhline(cfg.PD_RAIL_V, color="#d62728", lw=1.0, ls=":")
    if np.isfinite(pedestal.value):
        settle_axis.axhline(pedestal.value, color="#17becf", lw=1.0, ls="--")
    settle_axis.set_xlabel("seconds since that activity's LED enable")
    settle_axis.set_ylabel("PD2 (V, log)")
    settle_axis.text(0.995, 0.06,
                     "thick segment = the exposure window; three LEDs step "
                     "straight to level, three rail first",
                     fontsize=7, color="0.35", ha="right", va="bottom",
                     transform=settle_axis.transAxes)
    settle_axis.legend(fontsize=6.5, ncol=2, loc="center right",
                       framealpha=0.9)

    # ---- panel 3: enable interval split into rail / wait / expose --------
    for row, record in enumerate(runs):
        rail_end = record["settled_at_s"]
        gantt_axis.barh(row, rail_end, left=0, height=0.62,
                        color="#d62728", alpha=0.85,
                        label="clipped (PD off-scale)" if row == 0 else None)
        gantt_axis.barh(row, max(record["settle_margin_s"], 0.0), left=rail_end,
                        height=0.62, color="#ff7f0e", alpha=0.85,
                        label="on-scale, waiting" if row == 0 else None)
        gantt_axis.barh(row, record["exposure_seconds"],
                        left=record["exposure_start_s"], height=0.62,
                        color="#2ca02c", alpha=0.9,
                        label="exposing" if row == 0 else None)
        gantt_axis.barh(row, record["enable_seconds"], left=0, height=0.62,
                        facecolor="none", edgecolor="0.3", lw=0.8,
                        label="LED enabled" if row == 0 else None)
        note = (f"{record['pd_exposure_v']:.4f} V"
                f"   margin {record['settle_margin_s']:.0f} s")
        if record["settle_margin_s"] < 0:
            note += "   EXPOSED WHILE RAILED"
        gantt_axis.text(record["enable_seconds"] + 4, row, note,
                        fontsize=6.5, va="center",
                        color="#d62728" if record["settle_margin_s"] < 0
                        else "0.25")

    gantt_axis.set_yticks(range(len(runs)))
    gantt_axis.set_yticklabels(
        [f"{r['key']}  (hw LED{r['hardware_led']})" for r in runs], fontsize=7.5)
    gantt_axis.invert_yaxis()
    gantt_axis.set_xlabel("seconds since that activity's LED enable")
    if runs:
        gantt_axis.set_xlim(0, max(r["enable_seconds"] for r in runs) * 1.36)
        # Below the axes, not inside: the longest enable interval is CAR-216's
        # 238 s AUX run, so an in-axes legend lands on top of that row's bar and
        # its annotation no matter which corner it is given.
        gantt_axis.legend(fontsize=7, ncol=4, loc="upper center",
                          bbox_to_anchor=(0.5, -0.22), framealpha=0.9)

    _save(figure, path, dpi)

    return path


def plot_pd_trend_summary(card, out_dir, dpi=120):
    """Set-wide photodiode behaviour, from a reference card. Returns paths.

    The companion to :func:`plot_pd_activity_summary`: that one answers "is this
    epoch's housekeeping mapped correctly", this one answers "is the correction
    doing something physical across the trend". Three panels:

    1. ``pd_net`` per LED versus time, each LED on its own normalization so six
       curves with different absolute levels are comparable.
    2. the photodiode factor each epoch receives, with ACM moves marked. Lamp
       drift is a few hundred to a few thousand ppm; a point an order of
       magnitude off is a pedestal failure, and it should appear as a *gap*
       (NaN) rather than as a factor, which is what the guard in
       :func:`rcs_corrections.led_scale_factors` enforces.
    3. per-epoch validity, so a flagged channel is countable at a glance.

    Plotted against the card rather than against the products because the card
    already holds every quantity involved and is ~100 kB instead of 5.5 GB.
    """
    times = card.times()
    pd = card.pd_matrix()
    factor = card.pd_factor_matrix()
    origin = times[0] if len(times) else np.datetime64("2026-01-01")
    days = (times - origin) / np.timedelta64(1, "D")

    figure, axes = plt.subplots(3, 1, figsize=(11, 10), sharex=True,
                                gridspec_kw={"height_ratios": [3, 3, 1]})

    for index, led in enumerate(card.led_names):
        colour = STATE_COLORS.get(index + 1, "0.4")
        level = np.nanmedian(pd[:, index])
        axes[0].plot(days, pd[:, index] / level if np.isfinite(level) and level
                     else pd[:, index], ".-", color=colour, label=led,
                     markersize=4, linewidth=0.8)
        axes[1].plot(days, factor[:, index], ".-", color=colour, label=led,
                     markersize=4, linewidth=0.8)

    axes[0].set_ylabel("pd_net / its own median")
    axes[0].set_title(
        f"RCS photodiode across {len(card.epochs)} epoch(s)   "
        f"reference {card.reference_run_label}")
    axes[1].set_ylabel("photodiode factor\n(reference_pd / pd_net)")
    axes[1].axhline(1.0, color="0.6", linewidth=0.8, linestyle=":")

    # ACM moves: not a photodiode quantity, but the two corrections multiply,
    # so a step in the response at a move must be attributable to one or the
    # other and that is only decidable with both on the same axis.
    for move in card.moves:
        if 0 <= move.index < len(days):
            for axis in axes[:2]:
                axis.axvline(days[move.index], color="k", linewidth=0.8,
                             linestyle="--", alpha=0.5)
            axes[0].annotate(f"ACM {move.kind}", (days[move.index], 1.0),
                             xytext=(3, 0), textcoords="offset points",
                             rotation=90, fontsize=7, va="center")

    valid = np.array([row["pd_valid_n"] for row in card.epochs], dtype=float)
    axes[2].step(days, valid, where="mid", color="#2ca02c", linewidth=1.0)
    axes[2].axhline(len(card.led_names), color="0.6", linewidth=0.8,
                    linestyle=":")
    axes[2].set_ylim(-0.3, len(card.led_names) + 0.5)
    axes[2].set_ylabel("valid\nLEDs")
    axes[2].set_xlabel(f"days since {np.datetime_as_string(origin, unit='D')}")

    for axis in axes[:2]:
        axis.grid(alpha=0.25)
    axes[2].grid(alpha=0.25)
    axes[0].legend(ncol=6, fontsize=8, loc="upper center",
                   bbox_to_anchor=(0.5, -0.04), framealpha=0.9)

    path = os.path.join(out_dir, "pd_trend_summary.png")
    _save(figure, path, dpi)

    return [path]


def _save(figure, path, dpi):
    directory = os.path.dirname(os.path.abspath(path))
    os.makedirs(directory, exist_ok=True)
    figure.savefig(path, dpi=dpi, bbox_inches="tight")
    plt.close(figure)


def self_test():
    """Render the PD summary from synthetic telemetry into a temp file."""
    import tempfile

    import rcs_photodiode

    failures = []
    series, activities, _, _ = rcs_photodiode._synthetic_series()
    reduction = rcs_photodiode.reduce_photodiode(series, activities, quiet=True)
    with tempfile.TemporaryDirectory() as tmp:
        path = plot_pd_activity_summary(reduction, "synthetic",
                                        os.path.join(tmp, "pd.png"))
        if not os.path.exists(path) or os.path.getsize(path) < 10_000:
            failures.append(f"the PD summary PNG was not written, or is "
                            f"implausibly small ({path})")

        # The empty case has its own branch, so it needs its own exercise: an
        # epoch with no PD telemetry must still produce a figure saying so,
        # rather than raise inside a batch run.
        empty = rcs_photodiode.reduce_photodiode({}, activities, quiet=True)
        path = plot_pd_activity_summary(empty, "empty",
                                        os.path.join(tmp, "empty.png"))
        if not os.path.exists(path):
            failures.append("the no-samples PD figure was not written")

    for message in failures:
        print(f"  FAIL {message}")
    print(f"rcs_trend_plots.self_test: "
          f"{'FAILED' if failures else 'ok'} ({len(failures)} failure(s))")

    return not failures


if __name__ == "__main__":
    import sys

    sys.exit(0 if self_test() else 1)
