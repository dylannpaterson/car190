# Make RCS trend digests

## Purpose

Stage 3 of the pipeline. Turns a directory of per-SCA (or legacy mosaic) HDF5
products into one ECSV time series per SCA (`time_series_SCA1.ecsv` ...
`time_series_SCA18.ecsv`), each holding that SCA's relative response to all 6
LEDs at every epoch, corrected for the known instrumental effects and bridged
across every ACM reconfiguration.

* `make_sca_digests.py` — main driver
* `rcs_acm.py` — move detection, segments, bridge fit, sensitivity scans
* `rcs_corrections.py` — the per-epoch scalars
* `digest_plots.py` — diagnostic figures
* `rcs_report.py` — the text run log (`--report`)

The figure to read first is `run_structure.png`: it draws the ACM segments and
the decon episodes as two independent bands, annotates each boundary with the
method chosen and the fitter's own reason for choosing it, and reports the
closure test together with how many of its composed steps were actually fitted.
A boundary on the `multiplier` is usually explained by the structure rather than
by the data, and that is what this shows. Stage 2 has its own figures in
`plots/calibration/`; see **The nine figures to look at first** in
[README.md](README.md), and [PD_CORRECTION.md](PD_CORRECTION.md) for the
photodiode chain those four of them cover.

The second figure to read is `decon_evidence.png`, which checks the decon labels
the bridge now depends on against the response itself — see
**The decon labels are checked against the data** below.

`calibration_timeline.png` is the third, and the one to reach for when a step
looks physical: it draws how the L2 pipeline calibrated each epoch against time,
in two bands — the audited grouping from `--l2-audit` and what the products
themselves record — so an L2 calibration change, which is upstream of every
correction stage 3 applies, is visible rather than inferred.

See [README.md](README.md) for stages 1 and 2 and for the end-to-end batch
recipe. This file is only about the digest step.

## Inputs

`--data-root` is a directory of products; `--file-list` is optional and only
needed to run on a subset or to override the chronological order. **The first
epoch in the set is the reference epoch**: `time_hours` is measured from it and
its ratio is 1.0 by construction.

`--stage` selects which product stage to read, by the h5 `stage` **attribute**,
not by the filename:

| `--stage` | reads | corrections |
|---|---|---|
| `auto` (default) | whichever single stage the directory holds | per that stage; **refuses a mixed directory** |
| `cal` | `*_cal.h5`, `stage="calibrated"` | **schema 2** (current): nothing is in the pixels, and the digest applies exactly the `photodiode` and `acm` multipliers each product recorded, never re-deriving them. **Schema 1** (`rcs_trend_v3/cal`): already in the pixels, so switched off automatically, since re-applying would **square** each factor. A set mixing the two is refused |
| `raw` | `*_raw.h5`, `stage="raw"` | applied here |
| `legacy` | the old r=20 mosaic product | applied here, via `sca_footprint_masks` |

`auto` is the default rather than `cal` because the failure it prevents is the
worse one: naming a stage that does not match the directory's contents reads as
a configuration error and stops, whereas a directory holding two stages would
otherwise be reduced into one series with a step at the changeover. Name the
stage explicitly in a script, where a directory quietly gaining a second stage
should be a failure rather than a silent re-interpretation.

Which corrections are in the numbers is read back from the products, not
assumed from the CLI flags. For schema 2 that is `calibration_recorded`; for
schema 1, `corrections_applied`. A 1.002 photodiode factor applied twice is 1.004:
indistinguishable from a real 0.2 % response change.

Mixing per-SCA and mosaic products in one set puts a ~0.1 % step in the trend at
the changeover, which is the size of the film-growth signal, so it is refused
unless you pass `--allow-mixed-product-kind`.

**A/B side comes from the product's `mce_side` attribute.** It used to be read
from an `_MCEB` marker in the filename, which flight filenames never carry, so
every flight epoch was silently classified side A. A set that records no side is
now **refused** rather than defaulted; pass `--assume-side A` to accept the
assumption, which is then recorded in the run log as an assumption. The side
decides where the side bridge goes (below) and which photodiode reference an
epoch is gauged to, so a wrong label misplaces a chromatic step of several
percent.

**`--l2-audit` supplies the L2 provenance the products do not carry**, and
defaults to `l2_calibration_audit.ecsv` beside the script, which exists and is
the record. It is matched to epochs on `run_label`, never on the audit's `epoch`
column — that index is a position in whatever list produced the audit, so
positional matching would silently shift every label by the number of passes
added since. A missing file is not an error; the figure then draws the
product-recorded band alone and says the audit was not supplied. Coverage is
printed, and total non-coverage warns, because "audit supplied but matched
nothing" and "no audit supplied" are different failures.

Filename conventions still matter only as a fallback for products with no
attributes:

* flight: `CAR190_01039_02_022_001_20260917.h5`, timestamps with 7
  fractional-second digits and no zone marker;
* SCIPA: `TVAC_HOB_OTP00775_..._SCIPAc_R14_MCEA.h5`, timestamps with a trailing
  `Z`. SCIPA filenames carry no pass number, so the pass column falls back to the
  file's position in the list, and `_MCEA`/`_MCEB` is where the side comes from.

## Pipeline flow

```
product directory  ->  metadata-only pass: find every ACM move, segment the run
                   ->  per-epoch load, ratioed to the reference epoch
                   ->  photodiode and ACM: the products' recorded multipliers
                       (schema 2), nothing (schema 1, already in the pixels),
                       or computed here (raw / legacy)
                   ->  per_sca_reduce(stack, nanmedian), or a footprint median
                       for a legacy mosaic
                   ->  bridge fit across each ACM reconfiguration (per SCA),
                       per-SCA bridge systematic scan
                   ->  side bridge across each MCE side change (per LED,
                       common to every SCA), with its own systematic scan
                   ->  check against the bridges the products recorded
                   ->  one ECSV per SCA, and --solution-out for stage 2
                   ->  diagnostic figures (digest_plots.py)
                   ->  text run log (rcs_report.py, --report)
                   ->  optional diff against an existing digest set
```

## ACM moves and the bridge

An ACM move is **a consecutive-epoch LVDT change of at least
`--acm-move-min-delta` (default 500) counts, regardless of sign.** The flight
trend has three:

| when | LVDT | delta | what |
|---|---|---|---|
| 2026-09-14T23:54 | +7559 → −2815 | −10374 | deploy (crosses zero) |
| 2026-09-24T23:15 | −2815 → −5232 | −2417 | reposition, deployed side |
| 2026-09-28T01:40 | −5232 → −2815 | +2417 | reposition, back again |

The deploy goes **positive → negative**, and the old rule that required a sign
change plus |Δ| ≥ 5000 caught only that one — the two deployed-to-deployed
repositions were invisible. The consequence was not cosmetic: the linear ACM
correction is only valid within one configuration, and with 2 segments instead of
4 the worst fractional travel from a segment reference was **0.859**, i.e. 86 %
extrapolation, against **0.00053** once every move is seen. Within-segment LVDT
scatter is < 200 and the smallest real move is 2417, so the 500 threshold has
nearly a decade of margin either way.

Each configuration is a **segment**. The scalar linear ACM correction is gauged
within a segment; the step between two segments is **bridged**: one
multiplicative scalar per SCA, found by least squares in log space with
inverse-variance weights, fitting a per-LED polynomial for the ongoing evolution
(`--bridge-degree`, default 2) simultaneously with a single shared step. A move
is bridged across a finite time, so the solution cannot simply set post = pre;
and each LED has its own evolution, which is what lets a common-mode shift be
separated from film growth. The bridge assumes the ACM effect is **geometric and
achromatic**.

`bridge_method` is recorded per boundary per SCA, and the distinction is
load-bearing:

* `bridge` — measured from the epochs either side.
* `multiplier` — **predicted** from the LVDT and the linear coefficient. Used
  where a side of the boundary has fewer than 2 epochs inside
  `--bridge-window` (default ±25 h). It is a model, not a measurement.
  `--no-bridge-multiplier` leaves such a boundary at 1.0 instead, which leaves a
  known ~3.6 % step in the output.
* `none` — unity.

### The bridge never fits across a decon

A decon removes the film, so thickness resets. The per-LED polynomial that
stands in for *ongoing* film evolution is therefore meaningless across a decon
transition, and `fit_bridge_step` enforces that: it takes the per-epoch
`decon_cycle` and confines each boundary's fit to a single growth episode. Two
consequences, both deliberate:

* **A boundary sitting *on* a transition is refused outright**, not fitted
  badly. A multiplicative ACM scalar and a film reset are the same shape in the
  data, so the step is not identifiable even in principle. It routes to the
  linear fallback with the reason recorded in its note.
* **A transition *inside* the window trims the window**, and if that leaves
  fewer than 2 epochs on a side, the boundary falls back. Trimmed epochs belong
  to a different film, not to a noisier version of the same one.

An **unlabelled** epoch is kept, not quarantined: an epoch whose cycle was never
recorded is not one known to be from a different cycle. This is also what keeps
the mostly-unannotated 34-file legacy set bit-exact.

This was found the expensive way. Before the guard existed, on the 118-epoch
flight set, boundary 2 (epoch 35) had only 3 early / 1 late epochs inside ±25 h,
and widening the window to "fix" that made the answer dramatically worse:

| `--bridge-window` | boundary 2, before the guard | closure, before | **closure, now** |
|---|---|---|---|
| 25 h (default) | `multiplier` | 0.058 % | **0.058 %** |
| 48 h | `bridge`, per-LED spread 0.028 | 0.488 % | **0.224 %** |
| 72 h | `bridge`, per-LED spread 0.191 | 3.899 % | **0.736 %** |
| 120 h | `bridge`, per-LED spread 0.237 | 2.360 % | **1.032 %** |

The mechanism: boundary 2's first-after epoch is CAR190 pass 37 at t = 271.4 h
and the next epoch in the run is CAR216 pass 1 at t = 309.8 h — a 38.4 h gap
that is *also* the decon1 → decon2 transition. At ≥48 h the late side gained
25+ CAR216/decon2 epochs and the shared step absorbed the decon1 → decon2 offset
instead of the ACM reposition. Now the late side is trimmed back to 1 epoch at
every window, so boundary 2 takes the `multiplier` regardless of
`--bridge-window` and the 67× closure blow-up cannot happen.

**Widening the window is still a bad idea, for a weaker reason.** Closure now
degrades from 0.058 % to 1.03 % across the same window range, and that residual
comes from boundaries 1 and 3, which cross no decon at all: their per-LED spread
grows 0.0018 → 0.0089 as the degree-2 polynomial extrapolates further. That is
ordinary over-extrapolation rather than a model violation, but the default ±25 h
is still the best-closing choice. A `multiplier` is not a failure to be
engineered around — at a boundary with a real time gap it is the better of the
two available answers.

Two recorded quantities flag a bad fit before closure does: the per-LED spread
(anything above ~0.001 is hard to reconcile with an effect assumed achromatic)
and the fit-choice scan, which reports `0-0 choices survive` and warns
**model-limited** when nothing defensible is left. Note the trap:
`bridge_method` still reads `bridge` in that case, and
`bridge_systematic_per_boundary` is NaN — the same NaN a `multiplier` boundary
writes, for the opposite reason. See the note on `bridge_systematic_note` in the
digest metadata.

### Film-growth episodes, and gauging per decon

The same labels define the **episodes**: contiguous runs of one `decon_cycle`,
which is what a stretch of uninterrupted film growth is. The digests record them
so this does not have to be re-derived — `decon_n_episodes`,
`decon_episode_bounds` (1-based, inclusive), `decon_episode_labels` and
`decon_reference_epochs` in `meta`, all positional, plus a `decon_time_hours`
column giving hours since each epoch's own episode began. `run_log.txt` lists
them in its `DECON CYCLES` block, beside the per-label epoch totals.

Two things worth knowing about that definition:

* **Contiguous, not label identity.** `decon1, decon2, decon1` is three
  episodes, not two: the third is not the first resumed, because the film was
  removed in between. So a `groupby` on the label is wrong, and
  `rcs_acm.decon_episodes` is what the bounds come from.
* **It is deliberately not the rule `_same_decon_episode` uses.** That function
  governs a bridge fit *window* and keeps an unlabelled epoch in whichever
  episode it adjoins (above); `decon_episodes` makes an unlabelled run its own
  episode, because a block of unknown provenance has no defensible first epoch
  to gauge against. Both answers are asserted side by side in
  `rcs_acm.self_test()`.

**The response columns are gauged globally, to the run's reference epoch — not
per episode.** Re-gauging each episode on its own first row is a view, and the
bounds above make it a three-line post-processing step. It is not a pipeline
mode, and the reasons (including the measurement it discards and the fact that
it buys nothing for `decon1` on this dataset) are in
[PER_DECON_NORM.md](PER_DECON_NORM.md).

### The decon labels are checked against the data

Because the bridge refuses to fit across a decon, the `decon_cycle` labels are
load-bearing, and they come from the staging CLI rather than from the data. A
decon that happened but was never annotated is a film reset the fitter will
absorb into an ACM step. `decon_evidence.png` is the independent check, and it
works because the two effects have different **colour**:

* a **decon** resets the interference thickness, so each LED lands at a
  different fringe point — the step is strongly **chromatic**;
* an **ACM move** changes the source-to-focal-plane distance, which is geometric
  and therefore **achromatic** — the same factor for all six LEDs, contributing
  nothing to the spread across them.

So the statistic is the std of the per-LED log step across the six LEDs,
medianed over the 18 SCAs (median, not mean: one bad SCA epoch must not set the
focal-plane answer). The bottom panel's control is the three ACM moves — steps
already known to be geometric. All three land on the achromatic axis (chromatic
0.0007–0.002) while spanning achromatic −0.035 to +0.009; the decon sits at
chromatic 0.054, 25–75× higher. An ACM boundary that coincides with a cycle
*change* is drawn as a separate grey marker and excluded from the control, and
the rule there is deliberately the opposite of the one for labelled transitions:
to claim a transition you need both cycles known and different, but to claim a
clean control you need to know nothing happened, so an unknown → known change
disqualifies it. The 34-file legacy set is exactly this case — its last ACM
boundary coincides with the `'' → decon2` change and reads chromatic 0.045, and
drawing that as a clean geometric step would argue the opposite of the figure's
own claim.

**Film growth is chromatic too, so the step is judged against how much growth
the elapsed gap allows. Dividing by the gap is wrong.** A decon is an
*instantaneous* reset, so its signature does not scale with elapsed time and
dividing suppresses exactly what is being looked for. Measured: the same decon
reads 0.00141/h across the flight set's 38.4 h gap but only 0.00075/h across the
legacy set's 63.6 h gap — and the second falls *below* the detection floor, i.e.
the per-hour version misses the one real decon the legacy set contains. Instead
the gap dependence of ordinary growth is fitted and the statistic is observed /
predicted. The flight set recovers exponent 1.02, the legacy set 1.19 — both ≈1,
as steady growth predicts.

The prediction is `sqrt(noise² + (a·gap^p)²)`, not a bare power law, and the
5σ floor is calibrated on the **noisier** of the two gap regimes. Both pieces
exist because of a measured false-positive mode, not for tidiness:

* noise does not scale with the gap, so a growth-only model under-predicts the
  shortest steps and reports them as resets (on a 40-epoch synthetic, the three
  gaps under 5 h were flagged at 1.03–1.29× the floor, and only those three);
* the ratio's own scatter depends on the gap. Where growth dominates, the 18
  SCAs see one film and the ratio is tight (2.5 %); where noise dominates it is
  a std over six LEDs and four times looser. One floor fitted to the many quiet
  long gaps is far too tight for the few short ones.

That conservatism costs real power — on the 168-epoch set where the two floors
were compared directly, the flight margin went 2.2× → 1.9× — and is the right
trade here, because a false positive sends you to doubt a decon label that is in
fact correct.

**Three verdicts, never a bare pass.** The run prints the weakest labelled
decon's margin over the floor (flight set at 176 epochs: 1.8×, so a decon 54 % as
strong would still have been caught); `UNDERPOWERED` when the labelled decon itself reads
below the floor, since a clean result there was obtained by being blind; and
`uncalibrated` when the set contains no labelled transition at all. The 34-file
legacy set gets the third verdict, because its one cycle change is `'--' →
'decon2'` and **unknown is not known-different** — the same rule
`rcs_acm._same_decon_episode` enforces, so the figure cannot claim a constraint
the fitter does not apply. The cadence blind spot is printed every time: on the
flight set, at the sparsest step (38.4 h) a chromatic reset below 0.029 would
hide, against 0.054 for the loudest step seen. On the legacy set that limit is
0.101 against a loudest step of 0.048, and the caption says so in words: the
limit is above every step in the run, so at that cadence no reset of any size
present would be caught.

**The test loses power as the cadence sparsens, and that is physical.** A spread
across six LEDs *saturates* — once a reset scrambles the fringe phase the six
land effectively at random — while predicted growth keeps rising with the gap.
At 38 h the decon stands 6.1× above predicted growth; at 63.6 h, only 2.2×. So
the test confirms labels on the dense flight set, which is the set the guard
runs on, and is underpowered on sparse ones.

**What this settled.** Ten CAR-190 passes (plan 2: 43–46, plan 3: 47–52) took
`decon2` by default rather than from a record, which the guard made
load-bearing. Across passes 44–52 the chromatic step sits at 0.9–1.5× the median
rate with no step anywhere, while the one real decon reads 6.1× and is unique in
the run; a decon-sized reset in that stretch would have read 9–23× louder than
what is there. The default is confirmed by the response, not merely
self-consistent in time.

Two statistics were tried and rejected on measurement, both recorded in the
`decon_evidence` docstring: a `sqrt(noise² + (growth·gap)²)` least-squares fit on
squares (mis-weights the 114 steps at the 0.4 h cadence, overpredicting small
gaps 7×), and comparing each step to a local median of its temporal neighbours
(margin drops to 2.0× *and* it invents two false positives, because a decon's own
neighbourhood contains the accelerated regrowth it caused).

### Two free tests of the ACM model

**Closure.** When two segments sit at the same LVDT (the flight trend returns to
−2815 after the second reposition), the composed bridge between them must read
1.0 if the effect is purely geometric. The residual is printed. The printout
distinguishes a real test from a tautology: if every intervening step came from
the shared linear gauge it closes by construction and says so.

**The null test.** `--acm-segment-breaks N` asserts a segment boundary the LVDT
does not show, at 1-based epoch *N*. Point it at a quiet stretch and nothing
physically happened, so the fitted step must be 1.0. Measured on the 34-file set
at epoch 20 with `--bridge-window 120`: **0.99984–1.00021 across all 18 SCAs,
worst departure 0.021 %** — the fitter's false-positive floor, ~180× below the
3.7 % real deploy step. Manual breaks are reported as `manual` and never as
detected moves.

```bash
python make_sca_digests.py --data-root /data/eswitzer/rcs_trend --stage legacy \
    --assume-side A --acm-segment-breaks 20 --bridge-window 120 \
    --out-dir /tmp/nulltest --report /tmp/nulltest/run_log.txt
```

**Caveat on `bridge_led_spread`.** It is quoted in the digest metadata as a
systematic to add in quadrature, but at the null boundary it is **one LED**, not
scatter over six: LED1 sits +0.261 % with the same sign at all 18 SCAs while
LED2–6 are within ±0.013 % with no consistent sign. The run log names the widest
LED for exactly this reason. Check whether the spread is LED1 alone before using
it as an error bar.

## Corrections

| correction | source | note |
|---|---|---|
| photodiode | schema 2: `calibration/photodiode/multiplier`; raw: `photodiode/per_activity`, keyed by activity | `pd_net` is a **denominator**; 1.0 at each MCE side's first epoch |
| ACM piston | schema 2: `calibration/acm/multiplier`; raw: LVDT and the linear coefficient, gauged within a segment | changes the source-to-focal-plane distance |
| ACM bridge | fitted here, per SCA | see *ACM moves and the bridge* |
| side bridge | fitted here, per LED, common to every SCA | see below |

The TVAC per-LED B-side table (`B_SIDE_CORRECTIONS`) is no longer applied on a
calibrated set: the side bridge measures the swap from flight data. A raw or
legacy set with `--no-side` off still applies it, as before.

**The photodiode guard.** `pd_net` divides into every response. Measured pedestal
is ≈0.1164 V against 0.347–0.396 V illuminated, so `pd_net` ≈ 0.23–0.28 V; a bad
pedestal leaving it at 0.004 V is a **60× factor that looks exactly like a real
instrument event**. A reading the product flagged invalid therefore yields
**NaN**, not a skipped photodiode correction — an uncorrected point inside a
corrected series is worse than a missing one — and every flagged epoch is named
in the run log and in the digest metadata.

`--no-pd-from-product` falls back to the legacy positional
`dictionary/RCS_photodiode` mirror. That mirror carries no validity flag, so no
reading can be refused there; it exists only to reproduce a pre-2026-10 digest.

`estimate_systematics` evaluates a range of bridging choices against the
baseline, per SCA per boundary, and the surviving range is what the digest quotes
as the bridge systematic.

### The side bridge: one step per LED across an MCE side swap

At an MCE side change (the first was 2026-10-06, between CAR-190 plan 3 passes
57 and 71) the detector electronics, the LED drive and the photodiode all change
at once. The photodiode is a different physical diode behind the same
mnemonic, so it cannot be tied across the swap. It is re-based to 1.0 at each
side's first epoch, and one step absorbs everything:

```
log y[s, l, i] = P_{s,l}(t_i) - log(step_l) * [epoch i is on the early side]
```

The model has 108 polynomials, one per (SCA, LED), and **six steps, one per LED,
shared by all 18 SCAs**. It is the transpose of the ACM bridge, which has one
achromatic step per SCA. The swap is chromatic but should not move where light
lands on the focal plane, so the SCA-common constraint is the physics. A
per-SCA freedom would let the fit absorb an illumination change it should
report. The ACM step at a side boundary is fixed at 1.0 (method `side`), so the
two never double-count. The side change still opens an ACM segment, because the
B electronics read the LVDT with a per-channel offset.

- **Window**: `--side-bridge-window` (±50 h) and `--side-bridge-degree` (2), its
  own rather than the ACM bridge's ±25 h, which held only two B-side passes. The
  window stops at a decon and at any other side change.
- **Errors**: stat (covariance), SCA scatter (18 independent per-SCA fits),
  and the systematic (spread over degree {1, 2} × window {25, 35, 50, 75 h}
  choices the residuals accept). Total = max(stat, scatter) ⊕ systematic.
- **The pattern test**: each SCA's own steps, averaged over LEDs, against the
  common step. The rms is compared with what the per-SCA fit errors predict;
  under 3× is "no illumination change". The run log and `side_bridge.png` print
  it, and every digest carries its own SCA's reading.
- **Gauge**: the step multiplies the early side, so side B (the present) is 1.
  That is what `rcs_bridge_solution.ecsv` and the h5 record. The digest divides
  by the reference epoch, so its `LED1…LED6` stay 1.0 at A-side pass 1 and side
  B reads ×1/step; the `side_bridge_LEDx` columns hold exactly that factor.
- **A side change that cannot be fitted** is left at 1.0, method `none`, with
  an unconditional WARNING: the swap is then in the output at full size.

At 2026-10-06, A scaled onto B: LED1 0.89325, LED2 0.94393, LED3 1.03224,
LED4 0.99189, LED5 0.99106, LED6 1.00056, totals +/- 1.2–13e-4 from 188 epochs
(+/-0.6–33-4 at 185; the values are unchanged, see RCS_TREND_REFERENCE S7.5). The fit used
3 A-side and 4 B-side epochs. Pattern test 1.90×, with SCA8, 17 and 18 the
largest at about −2 × 10⁻⁴.

**The recorded bridges are checked, not applied.** On a schema-2 set whose
products carry `calibration/acm_bridge` and `side_bridge`, the digest still fits
its own and compares. `bridge_solution_check` in the meta reads `current` when
they agree to 1e-9 and `STALE` with the size when not. `--solution-out` writes
this run's fit for stage 2 to record.

### The temperature gain is a fifth correction, and it is opt-in

Not in the table above because stage 3 never applies it to the canonical
columns. When the calibrated products carry `calibration/tempgain/` (schema 2)
or a top-level `tempgain/` (schema 1) — they only do if stage 2 was given
`--tempgain-model`; `run_trend.py --fit-tempgain` does both — each digest gains
12 conditional columns and each LED gains a second figure:

| artifact | content |
|---|---|
| `LED1_tgcorr`…`LED6_tgcorr` | the bridged response with the modelled gain **change** divided out, re-gauged so row 0 is exactly 1.0 |
| `tempgain_LED1`…`tempgain_LED6` | the raw per-epoch multiplier, so the correction can be undone or re-gauged |
| `time_series_<LED>_all_scas_tgcorr.png` | the delivered figure redrawn from the corrected series, on **identical axes** so the two can be blinked |

`LED1..LED6` stay gain-free, and that is load-bearing rather than cosmetic:
`fit_temperature_gain.py` reads those columns (`:267`), so applying the gain to
them would make the fit read its own output. Three files read them directly —
that fit, `fit_film_thickness.load_digest` and `fit_film_rank1.load_digest_cube`
— and all three are unaffected by the block's presence. The rest of the activity
is downstream of those three rather than of the digest: `bridge_noise.py` takes
a digest's `.meta` and `acm_segment` column plus residuals from the film fit,
and `fit_initial_offset.py` reads the fits' `{led}_abs` / `{led}_phase_deg`
result tables. They inherit the gauge; they do not choose it.

Three rules worth knowing before relying on the columns:

* **The ratio, not the multiplier.** `LEDx_tgcorr[i] = LEDx[i] *
  tempgain_LEDx[i] / tempgain_LEDx[0]`. The digest's gauge is already set by
  the ratio to the reference epoch, so a time-constant gain is absorbed
  entirely and must leave `LEDx_tgcorr` *bit-identical* to `LEDx`. Using the
  absolute multiplier instead rescales the whole series by a constant — smooth,
  plausible and uniformly wrong.
* **All of the products or none of them, and all the same model.** A set where
  only some epochs carry a block is refused rather than half-corrected, which
  would put a step the size of the correction at the changeover. Two *different*
  models across one set is refused the same way, naming both sha256s — the same
  failure with a smaller step, and the harder one to notice.
* **Don't apply it twice.** The h5 records the multiplier with
  `applied = False`; these columns are the one place it is applied.

Model, caveats and the fit itself: [TEMPERATURE_GAIN.md](TEMPERATURE_GAIN.md).
Column-by-column format: `RCS_TREND_REFERENCE.md` §6.2.

## Invocations

```bash
# the normal case: calibrated products in, digests + figures + run log out
python make_sca_digests.py \
    --data-root /data/eswitzer/rcs_trend_v2/h5_cal \
    --out-dir digests/$(date +%Y%m%d) --plot-dir digest_plots \
    --report digests/$(date +%Y%m%d)/run_log.txt

# the legacy regression: must report worst response deviation 0.000e+00
python make_sca_digests.py \
    --data-root /data/eswitzer/rcs_trend --stage legacy --assume-side A \
    --acm-move-min-delta 5000 --acm-require-sign-change \
    --compare-dir digests_9_29_26 --out-dir /tmp/regress --no-plots --quiet

# SCIPA / TVAC, where the side does come from the filename
python make_sca_digests.py \
    --data-root /data/eswitzer/rcs_trend_scipa/ --file-list scipa_rcs_trend.txt \
    --out-dir digests_scipa --plot-dir digests_scipa_plots
```

## Known constraint downstream

`BridgeNoise.from_meta` raises `NotImplementedError` for more than 2 ACM
segments — the model carries one rank-one term and nested steps are not
orthogonal. **Neither downstream fit stops, and they fail differently:**

* `fit_film_thickness.py` catches it (`:2214`) unless `--strict`, warns
  `no noise model for N SCA(s)`, and reports a best fit with **no credible
  interval**. The thickness is still printed.
* `fit_film_rank1.py` never builds a `BridgeNoise`. It runs, using its own
  `_step_tau` (max over `bridge_step_errors`, in quadrature with
  `bridge_systematic`) and **one** achromatic nuisance step applied to every
  epoch after the *first* move. On a 3-move set one parameter stands in for
  three, so its step uncertainty is under-marginalized rather than refused —
  a lower bound, not a refusal.

Until it is extended, build the digest set the film fit consumes with
`--acm-move-min-delta 5000 --acm-require-sign-change`, which collapses the run
to 2 segments, and be aware that those digests carry the 86 % extrapolated
linear ACM correction described above.
