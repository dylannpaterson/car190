"""
script to compile the RCS trending data 

TODO:
trend_ice /path/to/ql_stability.csv /path/to/excel_output
"""
import pandas as pd
import os
import glob
import h5py
from astropy.io import fits
import numpy as np


def determine_led_status(df, bank="BANK1"):
    """
    Creates a new column showing LED status for a specific bank.
    
    Args:
        df: pandas DataFrame
        bank: string specifying which bank to analyze (e.g., "BANK1", "BANK2")
    
    Returns:
        pandas Series with LED status for each row
    """
    
    # Find columns that match the pattern for the specified bank
    led_pattern = f"WFI_MCE_SRCS_{bank}SEL_LED"
    led_columns = [col for col in df.columns if col.startswith(led_pattern)]
    
    if not led_columns:
        raise ValueError(f"No LED columns found for bank {bank}")
    
    def get_row_status(row):
        enabled_leds = []
        
        for col in led_columns:
            if row[col] == 'ENA':
                # Extract LED number from column name (e.g., LED1, LED2, etc.)
                led_num = col.split('_')[-1]  # Gets 'LED1', 'LED2', etc.
                enabled_leds.append(led_num)
        
        if len(enabled_leds) == 0:
            return 'DRK'
        elif len(enabled_leds) == 1:
            return enabled_leds[0]
        else:
            return 'MULTIPLE'  # Multiple LEDs enabled
    
    return df.apply(get_row_status, axis=1)


def extract_identifier_specific(df, column_name):
    """Extract identifier with specific pattern matching"""
    # This assumes the identifier always comes before '/Science/'
    pattern = r'/(\d{19})/Science/'
    extracted = df[column_name].str.extract(pattern, expand=False)
    
    # If that doesn't work, try the more general pattern
    if extracted.isna().all():
        pattern = r'/(\d{19})/'
        extracted = df[column_name].str.extract(pattern, expand=False)
    
    return extracted


def save_to_hdf5(filename, dictionary, led_arrays, shuffle=False):
    """
    Save a dictionary and numpy arrays to HDF5 with maximum compression.
    
    Parameters:
    filename (str): Output HDF5 filename
    dictionary (dict): Dictionary with string, numeric, numpy array, or tuple values
    led_arrays (dict): Dictionary containing LED1-LED6 numpy arrays
    """
    
    with h5py.File(filename, 'w') as f:
        # Create a group for the dictionary
        dict_group = f.create_group('dictionary')
        
        # Save dictionary items with compression
        for key, value in dictionary.items():
            if isinstance(value, str):
                # For strings, use compression and utf-8 encoding
                dict_group.create_dataset(
                    key, 
                    data=value, 
                    dtype=h5py.string_dtype(encoding='utf-8')
                )
            elif isinstance(value, (tuple, list)):
                # Convert tuples/lists to numpy arrays and save
                array_data = np.array(value)
                dict_group.create_dataset(
                    key, 
                    data=array_data, 
                    fletcher32=True
                )
                # Store metadata to remember original type
                dict_group[key].attrs['original_type'] = 'tuple' if isinstance(value, tuple) else 'list'
            elif isinstance(value, np.ndarray):
                # For numpy arrays
                dict_group.create_dataset(
                    key, 
                    data=value, 
                    fletcher32=True
                )
                dict_group[key].attrs['original_type'] = 'numpy_array'
            else:
                # For scalars (numbers), convert to numpy array
                dict_group.create_dataset(
                    key, 
                    data=np.array(value)
                )
                dict_group[key].attrs['original_type'] = 'scalar'
        
        # Create a group for LED arrays
        led_group = f.create_group('led_arrays')
        
        # Save LED arrays with maximum compression
        for led_name, array in led_arrays.items():
            led_group.create_dataset(
                led_name,
                data=array,
                compression='gzip',
                compression_opts=9,
                shuffle=shuffle,
                fletcher32=True
            )


def load_from_hdf5(filename):
    """
    Load dictionary and LED arrays from HDF5 file.
    
    Parameters:
    filename (str): HDF5 filename to read
    
    Returns:
    tuple: (dictionary, led_arrays_dict)
    """
    
    with h5py.File(filename, 'r') as f:
        # Load dictionary
        dictionary = {}
        dict_group = f['dictionary']
        for key in dict_group.keys():
            data = dict_group[key][()]
            original_type = dict_group[key].attrs.get('original_type', 'unknown')
            
            if isinstance(data, bytes):
                # Handle string decoding
                dictionary[key] = data.decode('utf-8')
            elif original_type == 'tuple':
                # Convert back to tuple
                dictionary[key] = tuple(data) if data.ndim > 0 else tuple([data.item()])
            elif original_type == 'list':
                # Convert back to list  
                dictionary[key] = data.tolist()
            elif original_type == 'numpy_array':
                # Keep as numpy array
                dictionary[key] = data
            elif original_type == 'scalar':
                # Convert back to scalar
                dictionary[key] = data.item()
            else:
                # Default handling
                dictionary[key] = data.item() if data.shape == () else data
        
        # Load LED arrays
        led_arrays = {}
        led_group = f['led_arrays']
        for led_name in led_group.keys():
            led_arrays[led_name] = led_group[led_name][:]
    
    return dictionary, led_arrays


def nan_superpixel(in_matrix, n_pix, count_limit=0):
    """rebin a matrix into n_pix x n_pix superpixels
    ignore NaN
    """
    nan_mask = np.logical_not(np.isfinite(in_matrix))
    matrix = np.copy(in_matrix)
    matrix[nan_mask] = 0
    n_row, n_col = matrix.shape

    result_shape = (n_row // n_pix, n_pix, n_col // n_pix, n_pix)
    superpixel_matrix = matrix.reshape(result_shape).sum(axis=(1, 3))
    count_matrix = (~nan_mask).reshape(result_shape).sum(axis=(1, 3))

    superpixel_mean_matrix = np.where(count_matrix > count_limit,
                                      superpixel_matrix / count_matrix, np.nan)
    
    return superpixel_mean_matrix


def process_trending_run(directory_path, sub="/stability_check/",
                         bank="BANK2", stamp_pos=3, rebin=5,
                         root_data="./", subtract_dark=True,
                         out_path="../rcs_trending/"):
    """
    Process the trending data and put into an hdf5 file structure
    """
    # Find and load the CSV file in the directory
    #--------------------------------------------------------------------------
    csv_files = glob.glob(os.path.join(root_data + directory_path + sub, "*.csv"))
    
    if len(csv_files) == 0:
        raise FileNotFoundError("No CSV files found in the directory")
    elif len(csv_files) > 1:
        raise ValueError(f"Multiple CSV files found: {csv_files}. Expected only one.")
    
    csv_file = csv_files[0]
    print(f"Found CSV file: {csv_file}")
    df = pd.read_csv(csv_file)
    
    # Form the metadata
    #--------------------------------------------------------------------------
    meta_dict = {}
    try:
        meta_dict["timestamp"] = df['SC Timestamp'][stamp_pos]
    except KeyError:
        meta_dict["timestamp"] = df['Timestamp'][stamp_pos]
    
    # Add a column which tells which LED is on
    df['LED_STATUS'] = determine_led_status(df, bank=bank)
    # Add a column which is the visit ID
    df['Visit_ID'] = extract_identifier_specific(df, 'exp_path_done')
    
    # also see WFI_COBA_WTSC10R_K, WFI_SIS_COBA_WTSC10R_K
    meta_dict['COBA_temp'] = np.nanmedian(df['WFI_COBA_WTSC10P_K'])
    meta_dict['RCS_Sphere_temp'] = np.nanmedian(df['WFI_MCE_SRCS_SPHERE_T'] + 273.15)
    meta_dict['RCS_Board_temp'] = np.nanmedian(df['WFI_MCE_SRCS_BOARD_T'] + 273.15)
    meta_dict['MPA_A_temp'] = np.nanmedian(df['WFI_MCU_A_MPA_CSENS_FPSSEN_K'])
    meta_dict['MPA_B_temp'] = np.nanmedian(df['WFI_MCU_B_MPA_CSENS_FPSSEN_K'])
    
    lvdt_array = np.array([np.nanmedian(df['WFI_MCE_LVDT_ACM_1']),
                           np.nanmedian(df['WFI_MCE_LVDT_ACM_2']),
                           np.nanmedian(df['WFI_MCE_LVDT_ACM_3']),
                           np.nanmedian(df['WFI_MCE_LVDT_ACM_4']),
                           np.nanmedian(df['WFI_MCE_LVDT_ACM_5']),
                           np.nanmedian(df['WFI_MCE_LVDT_ACM_6'])])
    
    meta_dict['ACM_LVDT'] = lvdt_array
    if bank == "BANK1":
        pd_array = df['WFI_MCE_SRCS_PD1_V'].to_numpy()
        meta_dict['RCS_forward_voltage'] = df['WFI_MCE_SRCS_BANK1_LED_V'].to_numpy()
    else:
        pd_array = df['WFI_MCE_SRCS_PD2_V'].to_numpy()
        meta_dict['RCS_forward_voltage'] = df['WFI_MCE_SRCS_BANK2_LED_V'].to_numpy()

    pd_array -= pd_array[0]
    meta_dict['RCS_photodiode'] = pd_array

    print_rcs_param(meta_dict)
    
    # Loop through the activities and assign LED numbers
    #--------------------------------------------------------------------------
    visit_number = df['Visit_ID'][0]
    fits_files = glob.glob(os.path.join(root_data + directory_path + sub + "mosaics/",
                                        f"{visit_number}*"))
    
    exp_file = fits_files[0]
    print(f"Opening dark {exp_file}")
    with fits.open(exp_file) as hdul:
        dark_array = nan_superpixel(hdul[1].data, rebin)
    
    led_arrays = {}
    for act_ind in range(1,7):
        led_name = f"LED{act_ind}"
        visit_number = df['Visit_ID'][act_ind]
        fits_files = glob.glob(os.path.join(root_data + directory_path + sub + "mosaics/",
                                            f"{visit_number}*"))

        exp_file = fits_files[0]
        print(f"{led_name} Opening {exp_file}")
        with fits.open(exp_file) as hdul:
            led_data = nan_superpixel(hdul[1].data, rebin)
            if subtract_dark:
                led_arrays[led_name] = led_data - dark_array
            else:
                led_arrays[led_name] = led_data
        
    outfile = out_path + directory_path.replace("/", "_") + ".h5"
    print("Writing to: ", outfile)
    save_to_hdf5(outfile, meta_dict, led_arrays)


def print_rcs_param(meta_dict):
    print("Timestamp: ", meta_dict["timestamp"])
    print("COBA Temperature: ", meta_dict["COBA_temp"])
    print("RCS Sphere Temperature: ", meta_dict["RCS_Sphere_temp"])
    print("RCS Board Temperature: ", meta_dict["RCS_Board_temp"])
    print("MPA temp (side A): ", meta_dict["MPA_A_temp"])
    print("MPA temp (side B): ", meta_dict["MPA_B_temp"])
    print("RCS Photodiode: ", meta_dict["RCS_photodiode"])
    print("RCS Forward voltage: ", meta_dict["RCS_forward_voltage"])
    print("ACM LVDT: ", meta_dict["ACM_LVDT"])


def get_timestamps(directory_path, sub="/stability_check/", root_data="./", stamp_pos=3):
    """
    Find the timestamp per file
    """
    csv_files = glob.glob(os.path.join(root_data + directory_path + sub, "*.csv"))
    
    if len(csv_files) == 0:
        raise FileNotFoundError("No CSV files found in the directory")
    elif len(csv_files) > 1:
        raise ValueError(f"Multiple CSV files found: {csv_files}. Expected only one.")
    
    csv_file = csv_files[0]
    df = pd.read_csv(csv_file)

    try:
        timestamp = df['SC Timestamp'][stamp_pos]
    except KeyError:
        timestamp = df['Timestamp'][stamp_pos]
    
    outfile = directory_path.replace("/", "_") + ".h5"
    print(timestamp, outfile, len(df))


if __name__ == "__main__":
    root_data = "/sdh/analysis/gs448wfi/ql_scipa_output/"

    # /sdh/analysis/gs448wfi/ql_scipa_output$ find ./ -maxdepth 2 -type d -name "*Chrm*"
    # find /sdh/analysis/gs448wfi/ql_scipa_output -maxdepth 2 -type d -name "*Chrm*"
    run_list = []
    ##run_list.append("TVAC_CSBtoCC2/OTP00775_sRCSEChrmStb_SCIPAa_R1_MCEB")
    ##run_list.append("TVAC_CSBtoCC2/OTP00775_sRCSEChrmStb_SCIPAb_R1_MCEB")
    ##run_list.append("TVAC_CSBtoCC2/OTP00775_sRCSEChrmStb_SCIPAc_R1_MCEB")
    #run_list.append("TVAC_CC2/OTP00775_RCSEChrmStbA_SCIPAa_R1_MCEA")
    #run_list.append("TVAC_CC2/OTP00775_RCSEChrmStbA_SCIPAa_R2_MCEA")
    #run_list.append("TVAC_CC2/OTP00775_RCSEChrmStbA_SCIPAa_R3_MCEA")
    #run_list.append("TVAC_CC2/OTP00775_RCSEChrmStbA_SCIPAa_R4_MCEA")
    #run_list.append("TVAC_CC2/OTP00775_RCSEChrmStbA_SCIPAa_R5_MCEA")
    #run_list.append("TVAC_CC2/OTP00775_sRCSEChrmStbB_SCIPAc_R2_MCEB")
    #run_list.append("TVAC_CC2toNOB_COB/OTP00775_sRCSEChrmStbB_SCIPAc_R3_MCEB")
    #run_list.append("TVAC_CC2toNOB_COB/OTP00775_sRCSEChrmStbB_SCIPAc_R4_MCEB")
    #run_list.append("TVAC_NOB_COB/OTP00775_RCSEChrmStbA_SCIPAa_R6_MCEA")
    #run_list.append("TVAC_NOB_COB/OTP00775_RCSEChrmStbA_SCIPAa_R7_MCEA")
    #run_list.append("TVAC_NOB_COB/OTP00775_RCSEChrmStbA_SCIPAa_R8_MCEA")
    #run_list.append("TVAC_NOB_COB/OTP00775_RCSEChrmStbA_SCIPAa_R9_MCEA")
    #run_list.append("TVAC_NOB_COB/OTP00775_sRCSEChrmStbB_SCIPAc_R5_MCEB")
    #run_list.append("TVAC_NOB_COB/OTP00775_sRCSEChrmStbB_SCIPAc_R6_MCEB")
    ##run_list.append("TVAC_NOB_COB/OTP00775_sRCSEChrmStbB_SCIPAc_R7_MCEB")
    #run_list.append("TVAC_NOB_COB/OTP00775_sRCSEChrmStbB_SCIPAd_R1_MCEB")
    #run_list.append("TVAC_NOB_COB/OTP00775_sRCSEChrmStbB_SCIPAe_R1_MCEB")
    #run_list.append("TVAC_NOB_COB/OTP00775_sRCSEChrmStbB_SCIPAe_R2_MCEB")
    #run_list.append("TVAC_NOB_COB/OTP00775_sRCSEChrmStbB_SCIPAe_R3_MCEB")
    #run_list.append("TVAC_NOB_COB/OTP00775_sRCSEChrmStbB_SCIPAe_R4_MCEB")
    #run_list.append("TVAC_NOB_COB/OTP00775_sRCSEChrmStbB_SCIPAe_R5_MCEB")
    #run_list.append("TVAC_NOB_COB/OTP00775_sRCSEChrmStbB_SCIPAe_R6_MCEB")
    #run_list.append("TVAC_NOB_COBtoHOB/OTP00775_sRCSEChrmStbB_SCIPAe_R7_MCEB")
    #run_list.append("TVAC_HOB/OTP00775_sRCSEChrmStbB_SCIPAe_R8_MCEB")
    #run_list.append("TVAC_HOB/OTP00775_sRCSEChrmStbB_SCIPAe_R9_MCEB")
    #run_list.append("TVAC_HOB/OTP00775_sRCSEChrmStbB_SCIPAe_R10_MCEB")
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAb_R1_MCEA")
    ##run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAb_R2_MCEA") # did not have EWA move?
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R1_MCEA")
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R2_MCEA")
    # Now at ACM ROM position
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R3_MCEA")
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R4_MCEA")
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R5_MCEA")
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R6_MCEA")
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R7_MCEA")
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R8_MCEA")
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R9_MCEA")
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R10_MCEA")
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R11_MCEA")
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R12_MCEA")
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R13_MCEA")
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R14_MCEA")
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R15_MCEA")
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R16_MCEA")
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA")
    #run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R18_MCEA")
    run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R19_MCEA")
    # before prism test
    run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R20_MCEA")
    # after the prism pos test
    run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R21_MCEA")

    # filter_analysis/filter_analysis$ python compile_rcs_trend.py | tee ../rcs_trending/process.log
    for item in run_list:
        #get_timestamps(item, root_data=root_data)
        process_trending_run(item, root_data=root_data)
