"""
Full flight RCS trending pipeline: MAST/S3 query -> streamed L2 -> mosaics -> h5.

The flight sibling of ``stage_rcs_inputs.py``. That script reads per-SCA products
off local mounts. This one streams them out of S3 through MAST and never writes
an L2 product to disk. A single run is ~126 L2 files at ~67 MB each, and this
activity repeats many times, so keeping local copies is not an option. Only the
small intermediates are written:

    car190_flight_staging/<run_label>/activity_table.csv     (full provenance)
    car190_flight_staging/<run_label>/stability_check/
        rcs_telemetry.csv                                    (compiler's input)
        mosaics/<staging_id>_act<N>_<key>_mosaic.fits         (~126 MB/run total)
        mosaics/sca_id_map_r4.fits
    car190_flight_derived/<run_label>.h5

``<run_label>`` carries the run's identity -- ``<CAR190|CAR216>_<program>_
<execution_plan>_<pass>_<segment>_<date>`` (see ``PROGRAM_LABELS``) -- into both
the directory and the h5 name, because the activity is repeated and a fixed
output name would silently overwrite the last run. It is derived from MAST
metadata, so there is no local counter to keep. One pass of the activity is
one trend point, and ``--pass`` is required to say which: consecutive passes
reuse the same observation numbers, so an unpinned query returns two
interleaved runs. Run ``--survey`` for the per-(execution_plan, pass) L1/L2
inventory that ``--pass`` is chosen from; :func:`survey_passes` explains what
mixing them would do. ``--blank-dark`` handles the case where the flats have
reached L2 but the dark has not -- see :func:`find_l1_dark`.

CAR-216 (program 1063) repeats the same 7-observation sequence as CAR-190
across execution plans 2 and 3, and tacks two extra observations onto it: obs
8 (4 dark exposures) and obs 9 (4 LED3-flat exposures). Those are written into
a new ``aux_arrays`` h5 group by :func:`attach_aux_activities` after the
compiler runs -- see :func:`group_activities` and ``CORE_OBSERVATIONS``
Every run also requires ``--decon-cycle`` (e.g. ``decon1``, ``decon2``): it is
independent of ``--program`` and is never inferred from it.

Notes:
* ``compile_rcs_trend.py`` is called completely unmodified, exactly as
  ``stage_rcs_inputs.py`` does, so the flight and TVAC cubes are packaged by
  identical code and a comparison between them isolates the input data.
* ``form_mpa_mosaic.py`` needed no changes either: it is pure geometry with no
  product I/O. The only reader change was splitting
  ``read_per_sca.read_scipa_sca`` into a tree extractor plus a path wrapper,
  since ``MastMissions.read_product()`` returns an already-open ``AsdfFile``
  rather than a path.
* Flight L2 products have no ``meta.groundtest``, which is where the TVAC path
  got its activity numbers and its whole ~2500-key ``hdf5_telemetry`` blob. The
  21 telemetry columns now come from the Engineering Data Portal (``rcs_edp.py``)
  and LED identity from ``meta.rcs.led`` (activity order) cross-referenced against
  the EDP enables (hardware order) -- see :func:`report_led_order`, and note the
  two are *expected* to differ. Most EDP mnemonic names carry over from
  TVAC unchanged, which is what lets the compiler's CSV stay drop-in; the three
  that do not are redirected by ``FLIGHT_MNEMONIC_ALIASES``, which keeps the
  column names the compiler reads while querying the flight name.

See ``check_compiler_globs`` for a correctness trap in this
pipeline. It is not obvious and it fails silently if not guarded.

What is left in this module is the staging half: the CLI, :func:`stage_run`,
the frozen compiler's wrappers and the h5 delivery. The three other halves sit
beside it, and the cross-references in the paragraphs above point into them:

* :mod:`rcs_activities` -- visit identifiers, staging ids, run labels,
  ``group_activities``, ``describe``. No astroquery import, which is what
  keeps ``--self-test`` runnable with no token.
* :mod:`rcs_mast` -- ``connect``, the product queries, ``survey_passes``,
  ``find_l1_dark``, ``stream_product``.
* :mod:`rcs_telemetry` -- the EDP query, ``build_telemetry_table``,
  ``report_led_order``, ``FLIGHT_MNEMONIC_ALIASES``.

Requires the astroquery fork with streaming support (see requirements.txt) and a
MAST token with Roman proprietary access.
"""
import argparse
import glob
import os
import shutil
import sys
import tempfile
import time

import numpy as np
import pandas as pd
import s3fs

import form_mpa_mosaic as fm
import read_per_sca as rps
from compile_rcs_trend import load_from_hdf5, nan_superpixel, process_trending_run
# The three halves this module used to contain now live beside it:
# rcs_activities (identity and grouping, no astroquery), rcs_mast (every call
# that touches the archive) and rcs_telemetry (the EDP and the compiler's CSV).
# Their names are imported rather than re-implemented, which also keeps
# `from process_rcs_trending import PROGRAM_LABELS` working for batch/.
import rcs_activities
import rcs_l2_source
import rcs_mast
import rcs_photodiode
import rcs_products
import rcs_sca_grid as grid
import rcs_telemetry
import rcs_trend_config as cfg
from rcs_activities import (CORE_OBSERVATIONS, DEFAULT_PROGRAM,
                            EXPECTED_EXPOSURES, N_ACTIVITIES, PROGRAM_LABELS,
                            _as_header_float, assert_single_execution_plan,
                            assert_single_pass, describe, group_activities,
                            is_dark, run_label)
from rcs_mast import (_query_products, connect, find_l1_dark, stream_product,
                      survey_passes)
from rcs_telemetry import (FLIGHT_MNEMONIC_ALIASES, build_empty_telemetry_table,
                           build_telemetry_table, report_led_order,
                           report_pull_timing)
# Imported rather than redefined so the two entry points cannot drift on the
# conventions the compiler actually depends on.
from stage_rcs_inputs import ACTIVITY_TO_KEY, R, REBIN, RCS_TREND, SUB

FLIGHT_STAGING_ROOT = os.path.join(RCS_TREND, "car190_flight_staging")
FLIGHT_DERIVED_ROOT = os.path.join(RCS_TREND, "car190_flight_derived")


# ---------------------------------------------------------------------------
# Staging
# ---------------------------------------------------------------------------

def check_compiler_globs(mosaic_dir, table):
    """Re-run the compiler's own per-row mosaic glob and demand one match each.

    ``process_trending_run`` does ``glob(mosaics/{visit_number}*)`` then
    ``fits_files[0]`` with no check on how many matched. Doing the same glob here
    and asserting a unique match converts that silent wrong-answer path (see
    :func:`assign_staging_ids`) into a loud failure, without modifying the
    compiler -- which has to stay byte-for-byte identical so the flight and TVAC
    cubes are packaged by the same code.
    """
    problems = []
    for _, row in table.iterrows():
        pattern = os.path.join(mosaic_dir, f"{row['staging_id']}*")
        matches = sorted(glob.glob(pattern))
        if len(matches) != 1:
            problems.append(
                f"    activity {int(row['activity_number'])} "
                f"({row['h5_key']}): id {row['staging_id']} matched "
                f"{len(matches)} files "
                f"{[os.path.basename(m) for m in matches]}")

    if problems:
        raise ValueError(
            "the compiler's per-row mosaic glob is ambiguous; it would take "
            "fits_files[0] and silently pair the wrong mosaic with this row:\n"
            + "\n".join(problems))

    print(f"  compiler glob pre-flight: {len(table)} rows, one mosaic each")



def stage_run(missions, activities, table, stage_dir, r=R,
              orientation=fm.DEFAULT_ORIENTATION, apply_dq=True,
              query_delay=0.0, per_sca_bin=cfg.DEFAULT_BIN,
              legacy_mosaic=False, l2_source=None):
    """Stream every SCA once; emit per-SCA stacks, mosaic FITS, or both.

    Returns ``(csv_path, arrays, provenance)`` where ``arrays`` is the list of
    :class:`rcs_products.ActivityArray` in activity order (empty when
    ``per_sca_bin`` is None) and ``provenance`` is the calibration fingerprint
    read off the first L2 actually opened.

    ``l2_source`` is the :class:`rcs_l2_source.L2Source` saying where frames
    come from -- MAST/S3, or a local uniformly-reprocessed directory that
    supersedes it. Resolved for the whole pass before this is called, so the
    loop below does not care which it got: both hand back an open ``AsdfFile``
    for ``read_streamed_l2``. ``None`` means MAST, which keeps every existing
    caller working.

    **The streaming loop is shared and runs exactly once per SCA either way.**
    The network fetch is ~85 s per activity and the two binnings are a few
    hundred milliseconds of local CPU over an array that is already in memory,
    so when both products are asked for the frame is padded once and binned
    twice -- at ``r`` for the mosaic and at ``per_sca_bin`` for the stack.
    Deriving one from the other is not an option: the legacy net factor is 20
    (r=4 then a 5x mosaic rebin) and 16 does not nest inside it.

    Memory is lower on the per-SCA path, not higher. A ``(18, 256, 256)``
    float32 stack is 4.7 MB against the ``(1125, 1750)`` float32 mosaic's 7.9 MB
    at the same bin, and the stack holds no inter-SCA gap pixels at all.

    ``query_delay`` sleeps that many seconds before each per-SCA fetch (after
    the first one overall) -- a single process is not itself the bottleneck,
    but many batch ranks running this loop concurrently can be, and this is
    the knob that spaces out one rank's contribution to that load.
    """
    mosaic_dir = os.path.join(stage_dir, "mosaics")
    geom = fm.load_geometry()
    by_number = {entry["activity_number"]: entry for entry in activities}
    made_first_request = False
    arrays = []
    if l2_source is None:
        l2_source = rcs_l2_source.L2Source(kind=rcs_l2_source.MAST)
    # Read once, off the first L2 opened, and carried into the product's root
    # attributes. One frame's calibration fingerprint stands for the pass
    # because a pass is all-aux or all-MAST by construction -- see
    # rcs_l2_source.resolve_source, which is what makes that true.
    l2_provenance = rcs_l2_source.empty_provenance()
    if legacy_mosaic:
        os.makedirs(mosaic_dir, exist_ok=True)

    for _, row in table.iterrows():
        activity = int(row["activity_number"])
        entry = by_number[activity]
        key = entry["key"]
        start = time.time()

        # One SCA in flight at a time. Each full-resolution array is ~128 MB as
        # float64 and there is no reason to hold more than one -- doubly so here,
        # where they arrive over the network rather than off a mount, so peak
        # memory would otherwise scale with how fast S3 happens to be.
        binned = {}
        stack = (rcs_products.empty_stack(per_sca_bin)
                 if per_sca_bin is not None else None)
        # "Pull" time is stream_product + read_streamed_l2 only: the network
        # fetch and the ASDF decode of what it returns. bin_frame afterward is
        # local CPU work with no data volume behind it, so it is timed
        # separately (below) and left out of the rate this is meant to answer:
        # how fast data is actually moving out of MAST/S3 for this activity.
        pull_bytes = 0
        pull_seconds = 0.0
        readouts = set()
        if entry.get("dark_blank"):
            # Nothing to stream. On the mosaic path build_mosaic over no frames
            # is the all-NaN placeholder the compiler needs at row 0; on the
            # per-SCA path empty_stack already is one, and its zero coverage is
            # why _write_coverage excludes empty activities from the AND.
            print(f"    act{activity} {key:5s} blank dark placeholder "
                  f"(no L2 products; all-NaN, not subtracted)")
        for sca in sorted(entry["frames"]):
            filename = entry["frames"][sca]
            # The aux path reads off a local mount, so the delay that exists to
            # space out one rank's load on the MAST listing API has nothing to
            # throttle and only slows the run down.
            if made_first_request and query_delay > 0 and not l2_source.is_aux:
                time.sleep(query_delay)
            made_first_request = True
            pull_start = time.time()
            af = l2_source.open(missions, filename)
            try:
                frame, _, _ = rps.read_streamed_l2(
                    af, apply_dq=apply_dq, source=filename)
                readouts.add(_readout(af))
                if not l2_provenance.get("ref_file_id"):
                    l2_provenance = rcs_l2_source.read_provenance(
                        af, source=filename)
                    print(f"    L2 calibration: "
                          f"{rcs_l2_source.describe_provenance(l2_provenance)}")
            finally:
                af.close()
            pull_seconds += time.time() - pull_start
            pull_bytes += l2_source.nbytes(
                filename, entry["sizes"].get(sca, 0))
            padded = fm.pad_to_4096(frame)
            del frame
            if legacy_mosaic:
                binned[sca] = fm.bin_frame(padded, r)
            if stack is not None:
                stack[grid.sca_index(sca)] = fm.bin_frame(padded, per_sca_bin)
            del padded

        # Recorded on the entry (not just printed) so a summary across the
        # whole run can be built once streaming is done -- see
        # report_pull_timing, called after this loop.
        entry["pull_bytes"] = pull_bytes
        entry["pull_seconds"] = pull_seconds
        entry["readout"] = _join_readouts(readouts)

        if stack is not None:
            arrays.append(rcs_products.ActivityArray(
                key=key, stack=stack,
                attrs=_array_attrs(entry, row, pull_bytes, pull_seconds)))

        if not legacy_mosaic:
            covered = grid.stack_coverage(stack)
            finite = grid.coverage_fraction(stack)
            median = (np.nanmedian(stack[covered])
                      if covered.any() else np.nan)
            print(f"    act{activity} {key:5s} -> stack "
                  f"{covered.sum()}/{cfg.N_SCAS} SCAs  "
                  f"finite={finite[covered].mean() if covered.any() else 0:.5f}"
                  f"  median={median:.4f}  ({time.time()-start:.0f}s)  "
                  f"pulled {pull_bytes/1e6:.0f} MB in {pull_seconds:.0f}s")
            del stack
            continue

        mosaic = fm.build_mosaic(binned, r=r, geom=geom, dtype=np.float32,
                                 orientation=orientation, prebinned=True)
        scas = sorted(binned)
        out = os.path.join(
            mosaic_dir,
            f"{entry['staging_id']}_act{activity}_{key}_mosaic.fits")
        fm.write_mosaic_fits(
            mosaic, out, r=r, scas=scas,
            meta={
                "CASE": ("flight", "staging case"),
                "SRCKIND": ("scipa", "per-SCA product type"),
                "SRCROOT": ("MAST/S3 stream", "per-SCA source"),
                "ORIENT": (orientation, "SCA array orientation convention"),
                "APPLYDQ": (bool(apply_dq), "DQ-flagged pixels set to NaN"),
                "ACTNUM": (activity, "activity index (1 = dark reference)"),
                "H5KEY": (key, "array name in the compiled trend h5"),
                "BLANKDRK": (bool(entry.get("dark_blank")),
                             "all-NaN dark placeholder, L2 not available"),
                # Two different numberings of the same lamp, both kept: ACTLED
                # counts in activity order, HWLED names the hardware LED. See
                # report_led_order for why they are expected to differ.
                "ACTLED": (str(row["product_led"]),
                           "LED in activity order (meta.rcs.led)"),
                "HWLED": (str(row["edp_led"]),
                          "hardware LED (EDP BANK2SEL enables)"),
                "STAGEID": (entry["staging_id"], "19-digit id used for staging"),
                "SYNTHID": (bool(entry["id_synthetic"]),
                            "STAGEID is synthetic, not an archive id"),
                "VISITID": (entry["visit_id"], "true 19-digit visit id"),
                "EXPNUM": (int(entry["exposure"]), "exposure identifier"),
                "FILESET": (entry["file_set_name"][:68], "MAST fileSetName"),
                "EXPTIME": (_as_header_float(entry.get("exposure_time")),
                            "[s] exposure time, -99 if unknown"),
                "STARTTIM": (str(entry["start_time"]), "exposure start time"),
                "OPTELEM": (str(entry.get("optical_element", "")),
                            "optical element"),
                "PULLB": (int(pull_bytes),
                          "[bytes] pulled from MAST/S3 for this activity"),
                "PULLSEC": (float(pull_seconds),
                            "[s] time in stream_product+read_streamed_l2"),
                "PULLMBPS": (float(pull_bytes / pull_seconds / 1e6)
                             if pull_seconds > 0 else -99.0,
                             "[MB/s] implied data rate, -99 if not pulled"),
            })
        finite = np.isfinite(mosaic)
        median = np.nanmedian(mosaic) if finite.any() else np.nan
        pull_rate = (pull_bytes / pull_seconds / 1e6) if pull_seconds > 0 else np.nan
        print(f"    act{activity} {key:5s} -> {os.path.basename(out)}  "
              f"{len(scas)} SCAs  finite={finite.mean():.5f}  "
              f"median={median:.4f}  ({time.time()-start:.0f}s)  "
              f"pulled {pull_bytes/1e6:.0f} MB in {pull_seconds:.0f}s "
              f"({pull_rate:.1f} MB/s)")
        del binned, mosaic, stack

    report_pull_timing(activities, table)

    if legacy_mosaic:
        union = sorted({s for entry in activities for s in entry["frames"]})
        id_map = fm.build_sca_id_map(union, r=r, geom=geom)
        fm.write_mosaic_fits(id_map.astype(np.float32),
                             os.path.join(mosaic_dir, f"sca_id_map_r{r}.fits"),
                             r=r, scas=union,
                             meta={"CONTENT": ("SCA id per pixel, 0 = gap", "")})

    # process_trending_run raises if it finds more than one CSV beside the
    # mosaics, so only the compiler's own columns go here; the wide provenance
    # table goes one directory up, outside its glob. CAR-216's aux rows (obs
    # 8/9) are excluded here -- the compiler takes np.nanmedian and
    # pd_array[0] over the *entire* CSV column, so leaving them in would
    # silently corrupt every scalar and lengthen RCS_photodiode past 7 (see
    # the module docstring). For CAR-190, is_aux is False everywhere, so this
    # is the same rows as before.
    csv_path = os.path.join(stage_dir, "rcs_telemetry.csv")
    compiler_columns = (["SC Timestamp", "exp_path_done"] + rps.HK_COLUMNS
                        + rps.LED_SELECT_COLUMNS)
    core_table = table[~table["is_aux"].astype(bool)] \
        if "is_aux" in table.columns else table
    core_table[compiler_columns].to_csv(csv_path, index=False)
    provenance = os.path.join(os.path.dirname(stage_dir.rstrip("/")),
                              "activity_table.csv")
    table.to_csv(provenance, index=False)
    print(f"  wrote {csv_path} ({len(core_table)} rows, "
          f"{len(compiler_columns)} compiler columns)")
    print(f"  wrote {provenance} (provenance, outside the compiler's glob)")

    if legacy_mosaic:
        check_compiler_globs(mosaic_dir, table)

    return csv_path, arrays, l2_provenance


def _readout(af):
    """``(ma_table_name, ma_table_number, nresultants)`` off one open L2 frame.

    The MA table is not in the survey listing, only in each file's
    ``meta.exposure``, and it matters: CAR-216 in decon3 downlinks every read
    (IM_DIAGNOSTIC, 9010) while CAR-190 and decon2 CAR-216 drop two reads in
    three (DROP_2_OF_3, 9008), and SCA18's read-1 transient correction makes its
    response differ by ~0.8 % between the two (MANIFEST.md, 2026-10-22). A
    field a frame lacks reads as "" / -1 rather than failing the pull.
    """
    try:
        exposure = af["roman"]["meta"]["exposure"]
    except (KeyError, TypeError):
        return ("", -1, -1)

    def integer(value):
        try:
            return int(value)
        except (TypeError, ValueError):
            return -1

    return (str(exposure.get("ma_table_name") or ""),
            integer(exposure.get("ma_table_number")),
            integer(exposure.get("nresultants")))


def _join_readouts(readouts):
    """One activity's readout fields; SCAs that disagree are joined with "|"."""
    if not readouts:
        return {"ma_table_name": "", "ma_table_number": "", "nresultants": ""}
    names, numbers, counts = (sorted({str(r[i]) for r in readouts})
                              for i in range(3))
    return {"ma_table_name": "|".join(names),
            "ma_table_number": "|".join(numbers),
            "nresultants": "|".join(counts)}


def _array_attrs(entry, row, pull_bytes, pull_seconds):
    """Per-dataset provenance for one activity's ``sca_arrays/`` entry.

    The same facts the mosaic FITS header carries, so a per-SCA product is as
    traceable to its L2 inputs as the legacy one. ``hardware_led`` is the EDP
    BANK2SEL answer and ``activity_led`` the L2 ``meta.rcs.led`` one: the two
    disagree by construction (the permutation is ``(6, 1, 2, 3, 4, 5)``, see
    ``rcs_telemetry.report_led_order``) and both are kept rather than one being
    picked, because a future sequence change would show up as the permutation
    changing and that is only visible if both are recorded.
    """
    def integer(value, default=-1):
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    led = str(row.get("edp_led", ""))

    return {
        "activity_number": int(entry["activity_number"]),
        "activity_led": str(row.get("product_led", "")),
        "hardware_led": integer(led[3:]) if led.startswith("LED") else -1,
        "visit_id": str(entry["visit_id"]),
        "staging_id": str(entry["staging_id"]),
        "exposure": integer(entry.get("exposure")),
        "observation": str(entry.get("observation", "")),
        "file_set_name": str(entry.get("file_set_name", "")),
        "start_time": str(entry.get("start_time", "")),
        "end_time": str(entry.get("end_time") or ""),
        "exposure_time": str(entry.get("exposure_time", "")),
        "optical_element": str(entry.get("optical_element", "")),
        "is_dark": bool(entry.get("is_dark", False)),
        "is_aux": bool(entry.get("is_aux", False)),
        "dark_blank": bool(entry.get("dark_blank", False)),
        "pull_bytes": int(pull_bytes),
        "pull_seconds": float(pull_seconds),
        # Strings, since SCAs that disagree are joined ("9008|9010"); empty
        # for a blank dark, and absent on products made before 2026-10-30.
        **entry.get("readout", _join_readouts(())),
        "units": "DN/s",
    }


def _is_s3_uri(path):
    """Whether ``path`` names an S3 object rather than a local filesystem path."""
    return str(path).startswith("s3://")


def publish_file(local_path, destination_root, filename=None):
    """Copy or upload ``local_path`` into ``destination_root``, local or s3://.

    The one place that has to know which kind of path it was given, so callers
    (e.g. the h5 delivery step in ``main``) can be handed either a local
    directory or an ``s3://`` URI without caring which. A no-op if
    ``destination_root`` already *is* where ``local_path`` lives. Returns the
    final path/URI.
    """
    filename = filename or os.path.basename(local_path)
    if _is_s3_uri(destination_root):
        destination = destination_root.rstrip("/") + "/" + filename
        s3fs.S3FileSystem().put(local_path, destination)

        return destination

    destination_dir = destination_root.rstrip("/")
    os.makedirs(destination_dir, exist_ok=True)
    destination = os.path.join(destination_dir, filename)
    if os.path.abspath(destination) != os.path.abspath(local_path):
        shutil.copy2(local_path, destination)

    return destination


def compile_run(label, staging_root=FLIGHT_STAGING_ROOT,
                out_root=FLIGHT_DERIVED_ROOT, subtract_dark=True):
    """Run the untouched compiler over a staged run, producing a local h5.

    ``staging_root`` and ``out_root`` are taken as arguments rather than read
    off the module globals, so a caller can point either at something other
    than the default (see ``--staging-root``/``--out-dir`` on the CLI).

    ``compile_rcs_trend.save_to_hdf5`` only ever opens a real local file
    (``h5py.File(path, 'w')``), so when ``out_root`` is an ``s3://`` URI this
    compiles into a local temp directory instead and returns that local path;
    the caller publishes it to ``out_root`` with :func:`publish_file` once it
    is done annotating/inspecting the local file (h5py cannot touch S3
    directly, and neither can ``annotate_h5``/``load_from_hdf5``).

    ``subtract_dark`` is normally True, matching ``stage_rcs_inputs.py`` and
    every TVAC product. It is False only for ``--blank-dark``, where row 0's
    mosaic is an all-NaN placeholder; with subtraction left on, every LED array
    would come out entirely NaN, since the compiler does a plain
    ``led_data - dark_array``.
    """
    root_data = staging_root.rstrip("/") + "/"
    if _is_s3_uri(out_root):
        local_dir = tempfile.mkdtemp(prefix="car190_h5_")
    else:
        local_dir = out_root.rstrip("/")
        os.makedirs(local_dir, exist_ok=True)
    local_out_path = local_dir + "/"

    print(f"\n----- compiling '{label}' with compile_rcs_trend "
          f"(subtract_dark={subtract_dark}) -----")
    process_trending_run(label, sub=SUB, bank="BANK2", stamp_pos=3,
                         rebin=REBIN, root_data=root_data,
                         subtract_dark=subtract_dark, out_path=local_out_path)

    return local_out_path + label.replace("/", "_") + ".h5"


def attach_aux_activities(h5_path, aux_activities, mosaic_dir, rebin=REBIN):
    """Patch CAR-216's tacked-on aux activities onto an already-compiled h5.

    ``compile_rcs_trend.py`` never sees these, they are deliberately excluded
    from the 7-row CSV it reads (see the module docstring for why), so this
    writes them directly into a new, top-level ``aux_arrays`` group after the
    compiler has already produced the h5. A no-op when ``aux_activities`` is
    empty, which is every CAR-190 run, so this changes nothing about the file a
    CAR-190 run produces: :func:`load_from_hdf5` and every other existing
    reader (``make_sca_digests.py``, ``compare_rcs_h5.py``, ``animate_trend.py``)
    only iterate the ``dictionary``/``led_arrays`` groups' keys, never the
    file's top-level groups, so ``aux_arrays`` is invisible to them.

    Raw mosaics, not dark-subtracted: nothing here pairs a specific
    ``AUX_LED3FLAT*`` exposure with a specific ``AUX_DARK*`` one, so subtracting
    would be a guess. Downstream analysis can do that pairing itself if/when it
    needs to.
    """
    if not aux_activities:
        return []

    import h5py
    from astropy.io import fits

    written = []
    with h5py.File(h5_path, "a") as handle:
        group = handle.require_group("aux_arrays")
        for entry in sorted(aux_activities, key=lambda e: e["activity_number"]):
            pattern = os.path.join(mosaic_dir, f"{entry['staging_id']}*")
            matches = sorted(glob.glob(pattern))
            if len(matches) != 1:
                raise ValueError(
                    f"aux activity {entry['key']}: id {entry['staging_id']} "
                    f"matched {len(matches)} mosaic files "
                    f"{[os.path.basename(m) for m in matches]}")
            with fits.open(matches[0]) as hdul:
                binned = nan_superpixel(hdul[1].data, rebin)
            dataset = group.create_dataset(
                entry["key"], data=binned, compression="gzip",
                compression_opts=9, fletcher32=True)
            dataset.attrs["observation"] = entry["observation"]
            dataset.attrs["exposure"] = entry["exposure"]
            dataset.attrs["visit_id"] = entry["visit_id"]
            dataset.attrs["start_time"] = entry["start_time"]
            written.append(entry["key"])

    print(f"  attached {len(written)} aux array(s) to "
          f"{os.path.basename(h5_path)}: {sorted(written)}")

    return written


def _l2_origin_phrase(l2_source):
    """Where the pixels came from, for the product's ``provenance`` string.

    Spelled out in the attribute rather than left to the log, because the log
    is not part of the product and a year from now the h5 is all there is.
    """
    if l2_source is not None and l2_source.is_aux:
        return f"a LOCAL REPROCESSING at {l2_source.root} (superseding MAST)"
    return "MAST, streamed"


def sequence_attrs(signature, program=None):
    """The product's record of which RCS sequence variant its pass ran.

    ``sequence_signature`` is the pass's L1 layout, taken from the query plan
    (``rcs_activities.sequence_signature``, written at planning from the L1
    listing); ``sequence_variant`` is its name in
    ``rcs_trend_config.SEQUENCE_VARIANTS``, or ``UNKNOWN``. A plan written
    before signatures were recorded (2026-10-22) has none, and the product says
    so in ``sequence_source`` rather than guessing; re-planning the pass (rung 1
    of any rerun) fills it in.
    """
    import rcs_activities

    if not signature:
        return {"sequence_variant": "", "sequence_signature": "",
                "sequence_source": ("not recorded: the query plan predates "
                                    "sequence signatures; re-plan the pass")}
    kind, found = rcs_activities.match_sequence(
        signature, cfg.SEQUENCE_VARIANTS, program)
    if kind == "partial":
        # Planned while MAST was still indexing the aux tail: the signature is
        # true but incomplete, and naming a variant from it would be a guess.
        return {"sequence_variant": "",
                "sequence_signature": signature,
                "sequence_source": (f"L1 incomplete at planning: a prefix of "
                                    f"{', '.join(found)} (still indexing, or "
                                    f"the sequence stopped short); re-plan "
                                    f"the pass to update it")}
    return {"sequence_variant": found if kind == "exact" else "UNKNOWN",
            "sequence_signature": signature,
            "sequence_source": ("L1 listing at planning, matched against "
                                "rcs_trend_config.SEQUENCE_VARIANTS")}


def write_per_sca_product(arrays, label, table, reduction, activities, out_dir,
                          bin_factor=cfg.DEFAULT_BIN,
                          orientation=fm.DEFAULT_ORIENTATION, apply_dq=True,
                          car_label="CAR190", program=None, decon_cycle="",
                          blank_dark=False, mce_side=None,
                          l2_provenance=None, l2_source=None,
                          sequence_signature=""):
    """Assemble the RAW per-SCA product's root attributes and write it.

    The attribute set is the whole point: everything a digest run needs to
    decide whether two epochs are comparable has to be *in the file*, because
    the alternative is inferring it from the filename, and that is where the
    existing pipeline's worst latent bug lives. ``make_sca_digests.is_b_side``
    reads ``"MCEB" in self.name``, a marker only TVAC/SCIPA filenames carry, so
    every flight epoch is silently classified side A -- and the per-LED B-side
    corrections are 1.5-6 %, the same size as the film-growth signal. Recording
    ``mce_side`` with an explicit ``mce_side_source`` is what lets Phase 7 raise
    instead of guess.

    ``mce_side`` is ``None`` unless ``--mce-side`` was passed. Flight has run
    side A throughout, so "A" is the right default, but it is recorded as
    ``assumed`` rather than ``observed``: nothing in the L2 metadata or in the
    housekeeping queried here distinguishes the sides, so claiming otherwise
    would be inventing provenance.

    h5py can only write a real local file, so an ``s3://`` ``out_dir`` gets a
    temp directory and an upload, exactly as :func:`compile_run` does.
    """
    visit_id = str(activities[0]["visit_id"])
    starts = [e["start_time"] for e in activities if e.get("start_time")]
    ends = [e.get("end_time") or e.get("start_time") for e in activities
            if e.get("end_time") or e.get("start_time")]

    attrs = {
        "run_label": label,
        "car_label": car_label,
        "program": int(program) if program is not None else -1,
        "execution_plan": int(visit_id[5:7]),
        "pass_number": int(visit_id[7:10]),
        "segment": int(visit_id[10:13]),
        "decon_cycle": str(decon_cycle or ""),
        "orientation": str(orientation),
        "dq_applied": bool(apply_dq),
        "mce_side": mce_side or "A",
        "mce_side_source": "cli" if mce_side else "assumed:flight-side-A",
        "mce_bank": "BANK2",
        "dark_subtracted": False,
        "dark_image_available": not blank_dark,
        "dark_policy": (
            "none; the dark has no L2 products and its stack is an all-NaN "
            "placeholder" if blank_dark else
            "none; the dark stack is stored alongside the LEDs and subtraction "
            "is left to stage 2"),
        "timestamp": str(min(starts)) if starts else "",
        "time_start": str(min(starts)) if starts else "",
        "time_end": str(max(ends)) if ends else "",
        "provenance": (
            f"{car_label} flight L2 from {_l2_origin_phrase(l2_source)}, "
            f"read per SCA and binned {bin_factor}x. No corrections applied: "
            f"LED stacks are NOT dark-subtracted and NOT photodiode/side/ACM "
            f"corrected."),
    }

    # The calibration fingerprint of the L2 this product was built from.
    # Recorded because MAST's CAR-190 L2 is *not* uniformly calibrated -- six
    # CRDS contexts across the program, with a per-SCA photom change between
    # them worth up to 3 % -- so "which calibration" is a property of the epoch
    # and has to travel with it. make_sca_digests.assert_homogeneous_calibration
    # is what then refuses to build one trend out of two calibrations.
    attrs["l2_source"] = (l2_source.kind if l2_source is not None
                          else rcs_l2_source.MAST)
    attrs["l2_source_dir"] = (l2_source.root if l2_source is not None else "")
    attrs.update(l2_provenance or rcs_l2_source.empty_provenance())
    attrs.update(sequence_attrs(sequence_signature, program))

    # Deliberately *not* dark-subtracted, which differs from the legacy
    # compiler. The dark is negligible against the illuminated frames and has no
    # L2 anyway, so baking a subtraction in would only destroy the ability to
    # check it later; the dark stack is stored as its own activity instead.
    if _is_s3_uri(out_dir):
        local_dir = tempfile.mkdtemp(prefix="car190_persca_")
    else:
        local_dir = out_dir.rstrip("/")
        os.makedirs(local_dir, exist_ok=True)

    local_path = rcs_products.product_path(local_dir, label, stage="raw")
    rcs_products.write_raw(local_path, arrays, bin_factor=bin_factor,
                           root_attrs=attrs, table=table, reduction=reduction)

    coverage = rcs_products.coverage_from_h5(local_path)
    print(f"  wrote {os.path.basename(local_path)}: {len(arrays)} activities, "
          f"{coverage.sum()}/{cfg.N_SCAS} SCAs covered, "
          f"{os.path.getsize(local_path)/1e6:.1f} MB")
    if not coverage.all():
        missing = [i + 1 for i in np.flatnonzero(~coverage)]
        print(f"  WARNING: SCAs {missing} are absent from at least one "
              f"activity; this product is degraded and should be re-pulled")

    path = publish_file(local_path, out_dir)
    if _is_s3_uri(out_dir):
        shutil.rmtree(local_dir, ignore_errors=True)

    return path


def annotate_h5(path, **attrs):
    """Record run provenance as root-level attributes on a compiled h5.

    ``compile_rcs_trend`` has to stay byte-for-byte unmodified, so it cannot
    write these itself, and it has no argument for them. Attributes on the file's
    root group are the one place they can go without changing the product:
    ``load_from_hdf5`` reads only the ``dictionary`` and ``led_arrays`` groups'
    *keys*, so nothing that consumes these h5 files sees a new field, while
    ``h5dump -A`` and ``h5py.File(path).attrs`` both show them.

    Used for ``dark_subtracted``. A cube that was never dark-subtracted is not
    comparable to a TVAC cube that was, and nothing else in the file records the
    difference -- the dark image itself never enters the h5, only its subtraction
    does, so the two are indistinguishable from the arrays alone.
    """
    import h5py

    with h5py.File(path, "a") as handle:
        for name, value in attrs.items():
            handle.attrs[name] = value
    print(f"  annotated {os.path.basename(path)} with "
          + ", ".join(f"{k}={v!r}" for k, v in attrs.items()))


# ---------------------------------------------------------------------------
# Self-test of the pure functions
# ---------------------------------------------------------------------------

def run_photodiode(activities, label, pd_dir, pad_minutes=cfg.PD_PAD_MINUTES,
                   make_plot=False, series=None, table=None,
                   write_sidecars=True):
    """Reduce the photodiode time stream for one epoch; write the ECSV and PNG.

    Needs no pixels, so it runs in seconds: one EDP query (the same one the
    telemetry table already makes) and a reduction over the PD's own sample
    grid. ``build_telemetry_table`` is asked for its raw ``series`` rather than
    re-queried, so this costs zero extra EDP requests on a full run.

    A caller that has already built the telemetry table -- the staging path has,
    by the time it compiles -- passes ``series`` and ``table`` in so the EDP is
    queried once per run rather than twice. ``--pd-only`` has neither, and
    queries here.

    Returns the :class:`rcs_photodiode.PdReduction`.
    """
    if series is None:
        table, series = build_telemetry_table(activities,
                                              pad_minutes=pad_minutes,
                                              return_series=True)
    # table is a pandas DataFrame (not an astropy Table), so `in table` tests
    # column names -- which is what is wanted here.
    edp_leds = (table["edp_led"].tolist()
                if table is not None and "edp_led" in table else None)
    reduction = rcs_photodiode.reduce_photodiode(
        series, rcs_photodiode.pd_activities(activities, edp_leds=edp_leds))

    if not write_sidecars:
        print(f"  pd_dir {pd_dir} is not local; the reduction goes into the h5 "
              f"photodiode/ group only, no ECSV or PNG")

        return reduction

    os.makedirs(pd_dir, exist_ok=True)
    ecsv_path = os.path.join(pd_dir, f"pd_{label}.ecsv")
    rcs_photodiode.to_table(reduction, run_label=label,
                            pd_pad_minutes=pad_minutes).write(ecsv_path,
                                                              overwrite=True)
    print(f"  wrote {ecsv_path}")

    # The stream itself, as a standalone h5 holding just the photodiode/ group.
    # Cheap -- ~2600 samples, under 100 kB -- and it is what makes the sequence
    # timeline available for every pass without staging any imagery: the ECSV
    # carries only the per-activity reduction, so the settle structure (which
    # lives in the stream) cannot be recovered from it. A --pd-only sweep over
    # all 168 passes therefore leaves behind everything the LED turn-on
    # diagnostics need, for a few megabytes total.
    stream_path = os.path.join(pd_dir, f"pd_{label}.h5")
    if os.path.exists(stream_path):
        os.remove(stream_path)
    rcs_photodiode.write_photodiode_group(stream_path, reduction,
                                          run_label=label)
    print(f"  wrote {stream_path}")

    if make_plot:
        # Imported here, not at module scope: matplotlib is not needed by the
        # staging path and pulling it in on a batch node costs a second of
        # import for nothing.
        import rcs_trend_plots

        png_path = os.path.join(pd_dir, f"pd_summary_{label}.png")
        rcs_trend_plots.plot_pd_activity_summary(reduction, label, png_path)
        print(f"  wrote {png_path}")

        seq_path = os.path.join(pd_dir, f"pd_sequence_{label}.png")
        rcs_trend_plots.plot_pd_sequence_timeline(reduction, label, seq_path)
        print(f"  wrote {seq_path}")

    return reduction


def self_test():
    """Exercise the pure functions of this pipeline and of its three modules.

    Runs with no credentials, no network and no flight data, which is the most
    that can be checked before the real products exist. This is the single
    no-credentials gate for the whole staging pipeline: :mod:`rcs_activities`,
    :mod:`rcs_mast` and :mod:`rcs_telemetry` each carry their own
    ``self_test()`` and all three are called here, so there is one command to
    run rather than four. The streaming and query paths are covered by
    ``--dry-run`` once a token is available.
    """
    known = cfg.SEQUENCE_VARIANTS["car216_decon3"]["signature"]
    attrs = sequence_attrs(known, 1063)
    assert attrs["sequence_variant"] == "car216_decon3"
    core = cfg.SEQUENCE_VARIANTS["car190"]["signature"]
    assert sequence_attrs(core, 1039)["sequence_variant"] == "car190"
    partial = sequence_attrs(core, 1063)
    assert partial["sequence_variant"] == "" and \
        "incomplete" in partial["sequence_source"], partial
    assert sequence_attrs("1:Dx1@180 2:Dx9@40", 1063)["sequence_variant"] == \
        "UNKNOWN"
    assert sequence_attrs("")["sequence_variant"] == "" and \
        "re-plan" in sequence_attrs("")["sequence_source"]
    print("  sequence_attrs: a known variant is named, an unknown one says "
          "UNKNOWN, and a missing signature says why")

    frame = {"roman": {"meta": {"exposure": {
        "ma_table_name": "DROP_2_OF_3", "ma_table_number": 9008,
        "nresultants": 6}}}}
    assert _readout(frame) == ("DROP_2_OF_3", 9008, 6)
    assert _readout({"roman": {}}) == ("", -1, -1)
    one = _join_readouts({_readout(frame)})
    assert one == {"ma_table_name": "DROP_2_OF_3", "ma_table_number": "9008",
                   "nresultants": "6"}, one
    mixed = _join_readouts({("DROP_2_OF_3", 9008, 6),
                            ("IM_DIAGNOSTIC", 9010, 14)})
    assert mixed["ma_table_number"] == "9008|9010", mixed
    assert _join_readouts(())["ma_table_name"] == ""
    print("  _readout: the MA table is read off meta.exposure, a frame "
          "without one does not fail, and SCAs that disagree are joined")

    print("===== rcs_activities =====")
    ids = rcs_activities.self_test()

    print("\n===== rcs_mast =====")
    rcs_mast.self_test()

    print("\n===== rcs_l2_source =====")
    if not rcs_l2_source.self_test():
        raise AssertionError("rcs_l2_source.self_test reported failures")

    print("\n===== rcs_telemetry =====")
    rcs_telemetry.self_test()

    print("\n===== rcs_edp (step finder) =====")
    import rcs_edp

    if not rcs_edp.self_test():
        raise AssertionError("rcs_edp.self_test reported failures")

    print("\n===== rcs_fsutil =====")
    import rcs_fsutil

    if not rcs_fsutil.self_test():
        raise AssertionError("rcs_fsutil.self_test reported failures")

    print("\n===== ascii_tidy =====")
    import ascii_tidy

    if not ascii_tidy.self_test():
        raise AssertionError("ascii_tidy.self_test reported failures")

    print("\n===== digest_trend_plots =====")
    import digest_trend_plots

    if not digest_trend_plots.self_test():
        raise AssertionError("digest_trend_plots.self_test reported failures")

    print("\n===== rcs_step_tests =====")
    import rcs_step_tests

    if not rcs_step_tests.self_test():
        raise AssertionError("rcs_step_tests.self_test reported failures")

    print("\n===== rcs_photodiode =====")
    if not rcs_photodiode.self_test():
        raise AssertionError("rcs_photodiode.self_test reported failures")

    print("\n===== rcs_sca_grid =====")
    if not grid.self_test():
        raise AssertionError("rcs_sca_grid.self_test reported failures")

    print("\n===== rcs_products =====")
    if not rcs_products.self_test():
        raise AssertionError("rcs_products.self_test reported failures")

    # The ACM/bridge algebra. Omitted from this gate until now, which meant its
    # assertions only ran when someone typed `python rcs_acm.py` -- and the
    # first thing they caught when wired up here was a name shadowed between
    # two of its own test cases. Everything downstream of the bridge divides by
    # these factors, so a silent regression here rescales a trend.
    print("\n===== rcs_acm =====")
    import rcs_acm

    if not rcs_acm.self_test():
        raise AssertionError("rcs_acm.self_test reported failures")

    # Stage 2 is a separate CLI, but it shares this gate: its correctness
    # depends on the same product schema, and a schema change that breaks the
    # calibration should fail here rather than at the next batch run.
    print("\n===== rcs_corrections =====")
    import rcs_corrections

    if not rcs_corrections.self_test():
        raise AssertionError("rcs_corrections.self_test reported failures")

    # Before the calibrator, which reads model files through it.
    print("\n===== tempgain_model =====")
    import tempgain_model

    if not tempgain_model.self_test():
        raise AssertionError("tempgain_model.self_test reported failures")

    # Before the calibrator, which records the bridges through it.
    print("\n===== rcs_bridge_solution =====")
    import rcs_bridge_solution

    if not rcs_bridge_solution.self_test():
        raise AssertionError("rcs_bridge_solution.self_test reported failures")

    print("\n===== calibrate_rcs_products =====")
    import calibrate_rcs_products

    if not calibrate_rcs_products.self_test():
        raise AssertionError(
            "calibrate_rcs_products.self_test reported failures")

    # The stage-2 figures are in this gate because of what they are for: they
    # are the only record of corrections that have already been multiplied into
    # the arrays. A figure that silently stops drawing the pd_net guard line, or
    # that renders a refused epoch as an ordinary gap, removes the evidence
    # rather than producing a visible error.
    print("\n===== calibration_plots =====")
    import calibration_plots

    if not calibration_plots.self_test():
        raise AssertionError("calibration_plots.self_test reported failures")

    # Stage 3. Its photodiode guard protects a *denominator*, so a regression
    # there shows up as a plausible response excursion rather than an error,
    # which is exactly the kind of thing this gate exists to catch.
    print("\n===== make_sca_digests =====")
    import make_sca_digests

    if not make_sca_digests.self_test():
        raise AssertionError("make_sca_digests.self_test reported failures")

    # Stage 3's figures. Here for the same reason as calibration_plots, plus one
    # of its own: decon_evidence.png decides whether the decon labels the bridge
    # refuses to fit across are confirmed by the data, and a statistic that
    # quietly loses its noise term starts reporting resets that are not there --
    # it draws, it prints a verdict, and the verdict is wrong.
    print("\n===== digest_plots =====")
    import digest_plots

    if not digest_plots.self_test():
        raise AssertionError("digest_plots.self_test reported failures")

    # The run log. In this gate because its failure mode is a report that reads
    # cleanly while omitting what it exists to say -- a modelled bridge step
    # presented as a measured one, or an asserted segment break shown as a
    # detected move. Nothing downstream would notice.
    print("\n===== rcs_report =====")
    import rcs_report

    if not rcs_report.self_test():
        raise AssertionError("rcs_report.self_test reported failures")

    # Intake. Both labels a manifest row carries -- decon cycle and MCE side --
    # are operator knowledge the archive cannot supply, so the code that keeps
    # them from being silently defaulted or dropped is in the gate too.
    print("\n===== batch intake =====")
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    "batch"))
    import make_manifest
    import refresh
    import side_witness

    if not make_manifest.self_test():
        raise AssertionError("make_manifest.self_test reported failures")
    if not side_witness.self_test():
        raise AssertionError("side_witness.self_test reported failures")
    if not refresh.self_test():
        raise AssertionError("refresh.self_test reported failures")

    # The free-standing reader. In the gate because it is the one consumer of
    # the products that is meant to leave this repo, so a schema change that
    # breaks it would break someone else's code first.
    print("\n===== rcs_trend_reader =====")
    import rcs_trend_reader

    if not rcs_trend_reader.self_test():
        raise AssertionError("rcs_trend_reader.self_test reported failures")

    print("\n===== staging =====")
    print("== compiler glob pre-flight ==")
    docs = "0012301008002013005"
    with tempfile.TemporaryDirectory() as tmp:
        table = pd.DataFrame([
            {"activity_number": n + 1, "h5_key": ACTIVITY_TO_KEY[n + 1],
             "staging_id": ids[n]} for n in range(7)])
        for identifier in ids:
            open(os.path.join(tmp, f"{identifier}_act1_DARK_mosaic.fits"),
                 "w").close()
        check_compiler_globs(tmp, table)

        # Now the ambiguous case the guard exists for: every row globbing the
        # same shared visit id, which is what an unguarded run would do.
        collide = pd.DataFrame([
            {"activity_number": n + 1, "h5_key": ACTIVITY_TO_KEY[n + 1],
             "staging_id": docs} for n in range(7)])
        for n in range(7):
            open(os.path.join(tmp, f"{docs}_act{n+1}_x_mosaic.fits"),
                 "w").close()
        try:
            check_compiler_globs(tmp, collide)
        except ValueError as error:
            assert "ambiguous" in str(error)
        else:
            raise AssertionError("ambiguous compiler glob was not caught")
    print("  ambiguous glob caught, unique glob accepted")

    print("\nall self-tests passed")

    return 0


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--program", type=int, default=DEFAULT_PROGRAM,
                        help="MAST program number (CAR-190 is 1039, CAR-216 "
                             "is 1063)")
    parser.add_argument("--decon-cycle", default=None,
                        help="e.g. decon1, decon2. Independent of --program: "
                             "CAR-190 and CAR-216 can each run in either "
                             "cycle, so this is never inferred from --program "
                             "and must always be passed explicitly. Existing/"
                             "historical data on record is decon1.")
    parser.add_argument("--pass", dest="pass_", type=int,
                        help="which pass of the activity to process. Required: "
                             "passes reuse observation numbers, so an unpinned "
                             "query mixes runs. Omit it to get the survey.")
    parser.add_argument("--segment", type=int, help="restrict to one segment")
    parser.add_argument("--observation", type=int,
                        help="restrict to one observation")
    parser.add_argument("--visit", type=int, help="restrict to one visit")
    parser.add_argument("--execution-plan", type=int,
                        help="restrict to one execution plan")
    parser.add_argument("--exposure-type", default=None,
                        help="e.g. WFI_FLAT; omit to take whatever matches")
    parser.add_argument("--run-label", default=None,
                        help="override the derived run label")
    parser.add_argument("--staging-root", default=None,
                        help="root directory for staged intermediates "
                             "(mosaics, activity_table.csv, rcs_telemetry.csv). "
                             "Must be a local path: the compiler globs mosaics "
                             "and opens FITS/CSV files directly and cannot read "
                             f"them from S3. Default: {FLIGHT_STAGING_ROOT}")
    parser.add_argument("--out-dir", default=None,
                        help="delivery location for the compiled h5: a local "
                             "directory or an s3:// URI. Default: "
                             f"{FLIGHT_DERIVED_ROOT}")
    parser.add_argument("--survey", action="store_true",
                        help="print the per-pass L1/L2 inventory and exit")
    parser.add_argument("--blank-dark", action="store_true",
                        help="proceed when the dark has no L2 products: row 0 "
                             "becomes an all-NaN placeholder and the LED arrays "
                             "are stored WITHOUT dark subtraction")
    parser.add_argument("--dry-run", action="store_true",
                        help="query, group, label and validate ids; stream "
                             "nothing and write nothing")
    parser.add_argument("--skip-compile", action="store_true")
    parser.add_argument("--skip-telemetry", action="store_true",
                        help="omit the EDP query; the CSV's mnemonic columns "
                             "are left empty and the compiler's scalars will "
                             "be NaN")
    parser.add_argument("--no-dq", action="store_true")
    parser.add_argument("--orientation", default=fm.DEFAULT_ORIENTATION,
                        choices=fm.ORIENTATIONS)
    product_group = parser.add_argument_group(
        "products",
        "The per-SCA stack is the primary product: each SCA keeps its own "
        "(256, 256) superpixel array at index sca-1, so no superpixel straddles "
        "an SCA edge and no per-SCA number has to be recovered from a mosaic "
        "footprint. The mosaic is a display view built on demand by "
        "rcs_sca_grid.stack_to_mosaic, never stored.")
    product_group.add_argument("--bin", type=int, default=cfg.DEFAULT_BIN,
                               dest="bin_factor",
                               help="superpixel bin factor for the per-SCA "
                                    "product. Must divide 4096, which is "
                                    "checked here at parse time rather than by "
                                    "bin_frame after a multi-gigabyte pull "
                                    "(default: %(default)s, giving 256x256 "
                                    "per SCA)")
    product_group.add_argument("--no-per-sca-h5", action="store_false",
                               dest="per_sca_h5",
                               help="skip the per-SCA product. Only sensible "
                                    "together with --legacy-mosaic-h5, since "
                                    "otherwise the run streams several GB and "
                                    "writes no h5 at all")
    product_group.add_argument("--legacy-mosaic-h5", action="store_true",
                               dest="legacy_mosaic_h5",
                               help="also stage r=4 mosaic FITS and run the "
                                    "frozen compiler, producing the historical "
                                    "r=20 mosaic h5. Off by default. The frame "
                                    "is streamed once and binned twice, so this "
                                    "costs local CPU, not network")
    parser.add_argument("--force", action="store_true",
                        help="overwrite an existing run directory")
    parser.add_argument("--query-delay-seconds", type=float, default=1.0,
                        dest="query_delay_seconds",
                        help="sleep this long before each per-SCA MAST "
                             "fetch in stage_run; throttles the request "
                             "rate a single process puts on MAST, which "
                             "matters when many batch ranks run concurrently "
                             "(default: %(default)s)")
    plan_group = parser.add_argument_group(
        "query planning",
        "Listing MAST is the step that falls over under load, not streaming. "
        "These options separate the two so a pass is listed once and streamed "
        "as many times as it takes. A cached plan holds product *names*, which "
        "do not expire -- see rcs_mast's module docstring for the measured "
        "presigned-URL behaviour behind that.")
    plan_group.add_argument("--plan-only", action="store_true",
                            help="query MAST, write the cached query plan, and "
                                 "stop. Streams nothing. Seconds per pass, so "
                                 "a whole trend set can be planned and its "
                                 "coverage inspected before any download.")
    plan_group.add_argument("--use-plan", action="store_true",
                            help="stream from an existing cached plan instead "
                                 "of listing MAST again. A rerun after a "
                                 "transient listing failure then costs zero "
                                 "listing calls.")
    plan_group.add_argument("--min-scas", type=int, default=cfg.MIN_SCAS,
                            help="SCAs required per lit activity in the plan "
                                 "before streaming starts. Below this the run "
                                 "exits as degraded and writes no product, so "
                                 "a listing truncated by load cannot leave "
                                 "behind a short h5 that blocks its own retry. "
                                 "The dark is exempt: it has no L2 at all "
                                 "(default: %(default)s)")
    plan_group.add_argument("--query-leases", type=int, default=cfg.QUERY_LEASES,
                            help="cap on concurrent MAST *listing* calls across "
                                 "all ranks sharing --staging-root. Streaming "
                                 "stays fully parallel (default: %(default)s)")
    plan_group.add_argument("--query-lease-timeout", type=float,
                            default=cfg.QUERY_LEASE_TIMEOUT,
                            help="steal a query lease held longer than this, on "
                                 "the assumption its holder died "
                                 "(default: %(default)s)")
    plan_group.add_argument("--no-query-leases", action="store_true",
                            help="skip leasing entirely; right for a single "
                                 "interactive run, wrong for a fan-out")
    aux_group = parser.add_argument_group(
        "local L2 override",
        "MAST's CAR-190 L2 is not uniformly calibrated: the program spans six "
        "CRDS contexts and two cal-software versions, and the per-SCA photom "
        "reference changed across them. Measured on identical pass-1 exposures "
        "the two calibrations differ by -2.28 % to +3.08 % per SCA (1.79 % "
        "rms) and only 0.028 % across LEDs -- achromatic, i.e. a flux "
        "calibration rather than an instrument event. Re-pulling cannot fix "
        "it, because MAST serves whatever each exposure was processed with at "
        "the time. These options let a uniformly reprocessed local set "
        "supersede the archive.")
    aux_group.add_argument("--aux-l2-dir", default=os.environ.get("AUX_L2_DIR"),
                           help="directory of locally reprocessed L2 .asdf "
                                "products, named exactly as MAST names them. "
                                "A pass whose every frame is present is built "
                                "entirely from here and MAST is not contacted "
                                "for pixels; a pass with none of its frames "
                                "here is built from MAST as usual; a pass with "
                                "SOME of its frames here is REFUSED as "
                                "degraded, because mixing two calibrations "
                                "inside one epoch is worse than the "
                                "between-epoch step this exists to remove and "
                                "leaves no trace in the product. Defaults to "
                                "$AUX_L2_DIR so the batch entrypoint can set "
                                "it once.")
    aux_group.add_argument("--aux-inventory", action="store_true",
                           help="print per-pass coverage of --aux-l2-dir and "
                                "exit. Read-only pre-flight: says exactly "
                                "which passes the override will apply to "
                                "before any run commits to it.")
    plan_group.add_argument("--stagger", action="store_true",
                            help="sleep a rank-dependent interval before "
                                 "listing, scaled by SLURM_NTASKS so the "
                                 "listing rate stays flat as the fan-out "
                                 "widens. Set by the batch entrypoint.")
    pd_group = parser.add_argument_group(
        "photodiode",
        "The PD pedestal is derived from the dark-period PD *time stream*, not "
        "from the first activity's windowed median, so these affect how much "
        "off-LED telemetry is available to derive it from.")
    pd_group.add_argument("--pd-pad-minutes", type=float,
                          default=cfg.PD_PAD_MINUTES, dest="pd_pad_minutes",
                          help=f"EDP window padding either side of the run "
                               f"(default {cfg.PD_PAD_MINUTES}). The pad is "
                               f"what makes an all-off interval exist before "
                               f"the first exposure and after the last")
    pd_group.add_argument("--pd-only", action="store_true", dest="pd_only",
                          help="query MAST metadata, pull the EDP, reduce the "
                               "photodiode, write the ECSV (and PNG with "
                               "--pd-plot), and stream no pixels at all. "
                               "Seconds per pass, so the PD derivation can be "
                               "checked across the whole trend cheaply")
    pd_group.add_argument("--pd-plot", action="store_true", dest="pd_plot",
                          help="write the per-epoch PD summary PNG: the figure "
                               "that answers whether the housekeeping really "
                               "is mapped per activity")
    pd_group.add_argument("--pd-dir", default=None, dest="pd_dir",
                          help="where the PD ECSV/PNG go (default "
                               "<out-dir>/pd)")
    product_group.add_argument("--mce-side", default=None, choices=["A", "B"],
                               dest="mce_side",
                               help="which MCE side ran this pass. Recorded as "
                                    "the mce_side attribute, with "
                                    "mce_side_source saying whether it was "
                                    "given here or assumed. Flight filenames "
                                    "carry no _MCEA/_MCEB marker, unlike TVAC, "
                                    "so with this omitted the product records "
                                    "side A as an assumption rather than as a "
                                    "measurement -- and the per-LED B-side "
                                    "corrections are 1.5-6%%, so a wrong answer "
                                    "is the size of the signal")
    parser.add_argument("--self-test", action="store_true",
                        help="check the pure functions; no network, no data")
    args = parser.parse_args()

    if args.self_test:
        return self_test()

    # Indexed once, up front, so --aux-inventory and a wrong --aux-l2-dir both
    # resolve before any credential is needed or any pass is planned.
    aux_index = None
    if args.aux_l2_dir:
        try:
            aux_index = rcs_l2_source.AuxIndex.scan(args.aux_l2_dir)
        except ValueError as error:
            raise SystemExit(str(error))
        print(f"aux L2 override: {len(aux_index.by_name)} products indexed "
              f"from {aux_index.root}")
        if aux_index.unparsed:
            print(f"  note: {len(aux_index.unparsed)} .asdf file(s) there do "
                  f"not match the flight L2 naming and are ignored: "
                  f"{', '.join(aux_index.unparsed[:4])}")

    if args.aux_inventory:
        if aux_index is None:
            raise SystemExit("--aux-inventory needs --aux-l2-dir")
        rcs_l2_source.aux_inventory_report(aux_index)

        return 0

    # Before the pull, not after it. bin_frame would raise on an indivisible
    # factor only once several GB had already been streamed and binned.
    try:
        args.bin_factor = cfg.validate_bin(args.bin_factor)
    except ValueError as error:
        raise SystemExit(str(error))

    if not args.per_sca_h5 and not args.legacy_mosaic_h5:
        raise SystemExit(
            "--no-per-sca-h5 without --legacy-mosaic-h5 would stream the whole "
            "pass and write no h5 at all. Pass one of the two.")

    if not args.decon_cycle and not args.survey:
        raise SystemExit(
            "--decon-cycle is required (e.g. decon1, decon2). It is "
            "independent of --program -- CAR-190 and CAR-216 can each run in "
            "either cycle -- so it is never inferred and must be passed "
            "explicitly. (Not required for --survey, which writes nothing.)")

    staging_root = args.staging_root or FLIGHT_STAGING_ROOT
    if _is_s3_uri(staging_root):
        raise SystemExit(
            "--staging-root must be a local path: the compiler globs mosaics "
            "and opens FITS/CSV files directly, and cannot read them from S3.")
    out_dir = args.out_dir or FLIGHT_DERIVED_ROOT

    search = {"program": args.program, "productLevel": 2}
    for name, value in (("pass", args.pass_), ("segment", args.segment),
                        ("observation", args.observation),
                        ("visit", args.visit),
                        ("execution_plan", args.execution_plan),
                        ("exposure_type", args.exposure_type)):
        if value is not None:
            search[name] = value

    print("===== CAR-190 flight RCS trending =====")
    print(f"  query : {search}")

    if args.plan_only and args.use_plan:
        raise SystemExit("--plan-only and --use-plan are opposites; pass one.")

    # Reading a cached plan needs no archive connection at all, so in --use-plan
    # mode the handle is only opened if something is actually going to be
    # streamed. That is what makes --use-plan --dry-run a fully offline check.
    missions = None
    if not args.use_plan:
        missions = connect()

        if args.survey or args.pass_ is None:
            survey_passes(missions, search)
            if args.survey:
                return 0
            raise SystemExit(
                "\n--pass is required. Passes of this activity reuse the same "
                "observation numbers, so a query without it returns two "
                "interleaved runs; pick one from the inventory above (use "
                "--survey to see it without this error).")
    elif args.pass_ is None:
        raise SystemExit("--use-plan still needs --pass to identify the plan.")

    lease_root = None if args.no_query_leases \
        else os.path.join(staging_root, "plans", ".query_lease")

    if args.use_plan:
        plan = rcs_mast.QueryPlan.read(staging_root, args.run_label) \
            if args.run_label else rcs_mast.QueryPlan.find_for(staging_root,
                                                               search)
    else:
        if args.stagger:
            rcs_mast.startup_stagger()
        plan = rcs_mast.plan_pass(
            missions, search, program=args.program,
            blank_dark=args.blank_dark, label=args.run_label,
            decon_cycle=args.decon_cycle, lease_root=lease_root,
            n_leases=args.query_leases,
            lease_timeout=args.query_lease_timeout)
        plan.write(staging_root)

    activities = plan.activities
    print(f"  pass  : {assert_single_pass(activities)}")
    print(f"  plan  : {assert_single_execution_plan(activities)}")
    if plan.decon_cycle and args.decon_cycle \
            and plan.decon_cycle != args.decon_cycle:
        # The decon cycle is never inferred from the program, so a plan built
        # under one cycle and streamed under another would mislabel the product
        # with nothing in the data to contradict it.
        raise SystemExit(
            f"the cached plan was built with --decon-cycle "
            f"{plan.decon_cycle!r} but {args.decon_cycle!r} was passed now. "
            f"The cycle is recorded in the product and cannot be inferred from "
            f"the data, so refusing to guess which is right.")

    # Deliberately ahead of check_plan_coverage. The PD reduction needs only
    # activity timings plus the EDP, so a pass whose *pixel* listing is short
    # still has a perfectly good photodiode -- and gating this on 18-SCA
    # coverage would withhold the cheap check from exactly the passes most worth
    # checking. A listing short enough to be missing whole activities is a
    # different matter, and the reduction warns about that itself (no dark
    # activity, so no dark-window pedestal).
    if args.pd_only:
        pd_dir = args.pd_dir or os.path.join(out_dir, "pd")
        if _is_s3_uri(pd_dir):
            raise SystemExit("--pd-dir must be a local path; the ECSV and PNG "
                             "are written with plain file writers.")
        run_photodiode(activities, plan.label, pd_dir,
                       pad_minutes=args.pd_pad_minutes, make_plot=args.pd_plot)
        print("  [pd only] nothing streamed, no h5 written")

        return 0

    # Before anything is streamed. A listing degraded by load returns *some*
    # products, and without this the run would download them, write a short h5,
    # and have batch/_already_done treat it as complete forever.
    try:
        rcs_mast.check_plan_coverage(plan, min_scas=args.min_scas)
    except ValueError as error:
        print(f"\nDEGRADED: {error}")

        # Distinct from both success and a crash, so `ls batch/status/*.degraded`
        # can be the retry list rather than a hand-sifted log.
        return 3

    if args.plan_only:
        print("  [plan only] plan cached; nothing streamed, nothing written")

        return 0

    # Also before anything is streamed, and for the same reason as the coverage
    # gate above: a pass that cannot be built wholly from one calibration must
    # cost one directory listing, not a 23 GB download followed by a product
    # nobody can interpret.
    try:
        l2_source = rcs_l2_source.resolve_source(plan, aux_index,
                                                 label=plan.label)
    except ValueError as error:
        print(f"\nDEGRADED: {error}")

        return 3
    rcs_l2_source.announce(l2_source, label=plan.label)

    aux_activities = [e for e in activities if e.get("is_aux")]

    # False only if the dark's L2 really was absent. Passing --blank-dark when
    # the dark did arrive changes nothing: the real dark is used and subtracted.
    blank_dark = any(entry.get("dark_blank") for entry in activities)
    if args.blank_dark and not blank_dark:
        print("  --blank-dark was passed but the dark's L2 products are "
              "present; using the real dark and subtracting it as usual")

    # From the plan, not re-derived: a plan read back carries the label it was
    # built with, so a --use-plan rerun lands in the same staging directory as
    # the --plan-only pass rather than inventing a new one from today's date.
    label = plan.label
    stage_dir = os.path.join(staging_root, label, SUB.strip("/"))
    print(f"  run   : {label}")
    print(f"  target: {stage_dir}")
    describe(activities)

    expected_activities = EXPECTED_EXPOSURES.get(args.program, N_ACTIVITIES)
    if len(activities) != expected_activities:
        print(f"  WARNING: expected {expected_activities} activities, found "
              f"{len(activities)}; the h5 will not match the expected layout")

    if args.dry_run:
        print("  [dry run] nothing streamed, nothing written")

        return 0

    if os.path.exists(stage_dir) and not args.force:
        raise SystemExit(
            f"{stage_dir} already exists. This activity repeats, so refusing to "
            f"overwrite a previous run silently; pass --force or --run-label.")

    os.makedirs(stage_dir, exist_ok=True)
    if args.skip_telemetry:
        # No EDP, so no PD stream either; run_photodiode is skipped below
        # rather than handed an empty series it would only warn about.
        table, series = build_empty_telemetry_table(activities), None
    else:
        table, series = build_telemetry_table(
            activities, pad_minutes=args.pd_pad_minutes, return_series=True)

    # Deferred until now in --use-plan mode: reading a plan needs no archive
    # connection, so the handle is opened only once there is really something
    # to stream. An all-aux pass never streams, so it needs no MAST handle and
    # therefore no MAST token -- worth keeping true, because it means a
    # reprocessed set can be rebuilt from a cached plan with the archive
    # unavailable.
    if missions is None and not l2_source.is_aux:
        missions = connect()

    _, arrays, l2_provenance = stage_run(
        missions, activities, table, stage_dir,
        orientation=args.orientation, apply_dq=not args.no_dq,
        query_delay=args.query_delay_seconds,
        per_sca_bin=args.bin_factor if args.per_sca_h5 else None,
        legacy_mosaic=args.legacy_mosaic_h5, l2_source=l2_source)

    car_label = PROGRAM_LABELS.get(args.program, "CAR190")

    # Reduced once and shared. Both products carry the same photodiode/ group,
    # and the EDP has already been queried for the telemetry table, so this
    # costs one reduction over ~2600 samples however many products are written.
    reduction = None
    pd_dir = args.pd_dir or os.path.join(out_dir, "pd")
    if series is None:
        print("  no photodiode/ group: --skip-telemetry means there is no "
              "EDP stream to reduce")
    else:
        # The ECSV and PNG go through plain file writers, so an S3 out_dir
        # cannot host them. The group itself still lands in the h5, which *is*
        # uploaded -- so the reduction is never lost, only its sidecars, and
        # only when no local --pd-dir was given.
        reduction = run_photodiode(
            activities, label, pd_dir, pad_minutes=args.pd_pad_minutes,
            make_plot=args.pd_plot, series=series, table=table,
            write_sidecars=not _is_s3_uri(pd_dir))

    if arrays:
        raw_path = write_per_sca_product(
            arrays, label, table, reduction, activities, out_dir,
            bin_factor=args.bin_factor, orientation=args.orientation,
            apply_dq=not args.no_dq, car_label=car_label,
            program=args.program, decon_cycle=args.decon_cycle,
            blank_dark=blank_dark, mce_side=args.mce_side,
            l2_provenance=l2_provenance, l2_source=l2_source,
            sequence_signature=plan.sequence_signature)
        print(f"  per-SCA product: {raw_path}")

    if args.legacy_mosaic_h5 and not args.skip_compile:
        local_path = compile_run(label, staging_root=staging_root,
                                 out_root=out_dir, subtract_dark=not blank_dark)
        aux_written = attach_aux_activities(
            local_path, aux_activities, os.path.join(stage_dir, "mosaics"))
        execution_plan = activities[0]["visit_id"][5:7]
        annotate_h5(local_path, dark_subtracted=not blank_dark,
                    dark_blank=blank_dark,
                    program=args.program, execution_plan=execution_plan,
                    car_label=car_label, decon_cycle=args.decon_cycle,
                    provenance=(f"{car_label} flight; LED arrays are NOT "
                                "dark-subtracted because the dark exposure had "
                                "no L2 products at staging time"
                                if blank_dark else
                                f"{car_label} flight; LED arrays are "
                                "dark-subtracted"))
        # The PD reduction, attached before publishing. Additive: it creates a
        # photodiode/ group and leaves dictionary/ exactly as the frozen
        # compiler wrote it, so the bit-exact regression against
        # /data/eswitzer/rcs_trend still holds. See
        # rcs_photodiode.write_photodiode_group for why that choice beats
        # recomputing dictionary/RCS_photodiode from pd_net here -- and note
        # that the per-SCA writer does make the substitution, so the two
        # products' dictionary/RCS_photodiode differ by design.
        if reduction is not None:
            rcs_photodiode.write_photodiode_group(local_path, reduction)
            print(f"  attached photodiode/ to {os.path.basename(local_path)}")

        dictionary, led_arrays = load_from_hdf5(local_path)
        path = publish_file(local_path, out_dir)
        if _is_s3_uri(out_dir):
            # local_path lived in a throwaway tempdir made by compile_run
            # (h5py can only write a real local file); it has now been
            # uploaded, so nothing more needs it.
            shutil.rmtree(os.path.dirname(local_path), ignore_errors=True)
        print(f"  compiled {path}")
        if blank_dark:
            print("  NOTE: LED arrays in this h5 are NOT dark-subtracted. The "
                  "dark's L2 products did not exist when it was staged, so its "
                  "mosaic is an all-NaN placeholder. Do not compare these "
                  "arrays' absolute levels against dark-subtracted TVAC cubes.")
        for key in sorted(led_arrays):
            arr = led_arrays[key]
            print(f"    {key}: {arr.shape} {arr.dtype} "
                  f"NaNfrac={np.isnan(arr).mean():.5f} "
                  f"median={np.nanmedian(arr):.4f}")
        if aux_written:
            print(f"    aux_arrays: {sorted(aux_written)}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
