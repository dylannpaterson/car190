# CAR-190 for RCS trending of spectrophotometric trending

## Notes on data arrival and trending
* WFI to Operate is at 4.10 pm 9/11/26 and takes an hour. If RCS sphere is at operatin temperature
 then we can start RCS charge up which takes about 3 hours. Could be starting CAR-190 as early as 8pm tonight. 
 Downlink 1015pm and ~2 hours to process to MAST.
* 10AM 9/12/26 passes 1-3 
* Day 15.3 ACM deploy expected (nom. Sept 16), will impact trending. Need to figure out ACM monitoring.

## MAST EDP temperature of interest
* MPA: WFI_MCE_ADC_WTSM00
* COBA:	WFI_MCE_ADC_WTSM04
* EWA motor: WFI_MCE_TEMP_EWA
* AMS CT 16 P:	TCEA_TME_EXT_THERMISTOR_101
* TOMA CT 82 P:	TCEA_TME_EXT_THERMISTOR_17
* FMS CT 127 P:	TCEA_TME_EXT_THERMISTOR_134
* SM IT 143 P:	TCEA_TME_EXT_THERMISTOR_9
* AOM 183 P:	TCEA_TME_EXT_THERMISTOR_50
* The five TCEA_TME_EXT_* above are in `trend_change_check.py telemetry --preset intake`. TCEA is the
  live channel (1 Hz); the TCEB_* twins serve no samples. Operations bump the AOM, then AMS, temperature
  to test the ice deposition rate: the AOM +5.16 K from 2026-10-30 01:48, the AMS +5.00 K from 11-01
  23:48, both back from 11-05 04:30 (MANIFEST.md; profiles in plots/diagnostics/telescope_bumps_20261030/).

## TODO
* move the EDP utilities and caller to a shared area
* refactor compile_rcs_trend.py to not use in-place copy and so go to most recent pandas
* confirm the two flight temperature mnemonics with the instrument team -- see
  [EDP mnemonics](#edp-mnemonics-3-of-15-were-tvac-only-names). The `WFI_MCE_ADC_WTSM*`
  index-to-sensor assignment rests on the list above alone; the EDP reports
  `subsystem='unknown'` for all of them.

## Coordinate conventions

There are two coordinate conventions at the SCA level that apply to forming mosaics:

* **Detector frame** -- native to a physical SCA's readout electronics. The
  old `mosaic_plot_FPS.py` mosaic placement assumed its per-SCA inputs were in
  this frame and flipped each one into place to match.
* **Science frame** -- the SOC convention. This is the nominal frame for SOC
  products, and by definition it already matches the mosaic's orientation --
  no flip needed. The per-SCA inputs used here (romancal L2 `_cal.asdf` and
  quicklook `_slope.fits.fz`) are both delivered in this frame, which is why
  `form_mpa_mosaic.DEFAULT_ORIENTATION = "identity"` (confirmed empirically;
  see [plots/orientation_calibration.md](plots/orientation_calibration.md)).

The detector-frame flip depends on physical mounting: SCAs 1, 2, 4, 5, 7, 8,
10, 11, 13, 14, 16, 17 have their connecting side facing FPA +Y; the other
six (3, 6, 9, 12, 15, 18) have it facing FPA -Y. This is recorded as
`rotation_deg` in `config/WFI_SCA_physical_centers.ecsv` and is what the two
`mosaic_plot_fps*` orientations (kept only for comparison, not for building
products) branch on.

The mosaic frame itself is the *view from the sky, looking down at the
detectors*: in this right-handed system, +Z points from the sky through the
detectors (the direction light travels), and the mosaic is drawn as that view
would appear -- FPA -X to the right, FPA +Y up.

## Environment setup

Dependencies come in two tiers, split by whether they need `romancal`:

* [requirements.txt](requirements.txt) -- numpy, h5py, pandas, astropy, asdf,
  lz4, matplotlib, tabulate, the pinned astroquery fork, fsspec[s3]/s3fs,
  python-dotenv, requests. Enough for `stage_rcs_inputs.py` end to end, and
  for `process_rcs_trending.py` through `--self-test`/`--survey`/`--dry-run`
  and a real run's query, staging, telemetry, and h5 delivery (local or
  `s3://`). Nothing in this tier needs Python above 3.10 -- in particular, the
  pinned astroquery fork's base install (no `[all]` extra) pulls in neither
  `romancal` nor `roman_datamodels`.
* [requirements-romancal.txt](requirements-romancal.txt) -- `romancal`,
  `roman_datamodels`, `rad`. Needed only to stream and open a *real* per-SCA
  L2 product (`stage_run` past `--dry-run`): the astroquery fork's
  `MastMissions.read_product()` may resolve romancal datamodel tags
  internally when it opens one. `romancal>=1.0.1` requires Python >=3.11,
  which is the only reason this layer forces a newer interpreter than the
  system default.

Everything lives in a `.venv` inside this activity directory rather than a
`pip install --user`.

### Baseline venv (Python 3.10, no romancal)

This machine's system `python3` (3.10) has no `ensurepip`, so the plain
`python3 -m venv` module cannot bootstrap `pip` into a new environment --
`virtualenv` does the same job without needing `ensurepip`:

```bash
cd activities/car-190-rcs-spectro-trending

# one-time, only if `python3 -m virtualenv --version` fails:
python3 -m pip install --user virtualenv

python3 -m virtualenv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Covers `stage_rcs_inputs.py` fully, and `process_rcs_trending.py` up to but
not including streaming a real per-SCA product -- that fails with a
tag-resolution error until the romancal layer below is added.

### Full flight venv (Python 3.12, adds romancal)

`romancal>=1.0.1` requires Python >=3.11, and this machine's system `python3`
(3.10) has no `ensurepip` besides, so use the cluster-provided 3.12 instead,
which does have `ensurepip` and can bootstrap `pip` via the plain `venv`
module:

```bash
cd activities/car-190-rcs-spectro-trending

/opt/parallelcluster/pyenv/versions/3.12.8/bin/python3.12 -m venv .venv
source .venv/bin/activate        # .venv/bin/activate.fish, .csh, etc. also exist
pip install -r requirements.txt -r requirements-romancal.txt
```

Needed for any `process_rcs_trending.py` run that actually streams real
per-SCA products, and for `comm_streaming_example.ipynb`.

From then on, `source .venv/bin/activate` in a new shell, or call
`.venv/bin/python some_script.py` directly without activating.

Note: this Python 3.12 build lacks the `_sqlite3` C extension, which
produces a harmless (?) warning on `asdf` import (a resource-mappings plugin
from `stpipe` fails to load). It does not affect anything this activity
uses currently.

Note: `requirements.txt` caps **pandas below 3**. pandas 3
makes copy-on-write mandatory, so `Series.to_numpy()` returns a *read-only*
array; `compile_rcs_trend.py` line 252 does an in-place
`pd_array -= pd_array[0]` on one and dies with `ValueError: output array is
read-only`. This bites **both** entry points, `stage_rcs_inputs.py` as well as
`process_rcs_trending.py`, since both call the same compiler. The compiler has to
stay byte-for-byte unmodified -- that is what makes the flight and TVAC cubes
comparable -- so the fix belongs in the pin, which also keeps flight products on
the same pandas the existing TVAC products were built with. If you rebuild the
venv and skip `requirements.txt`, this is the failure you will see, and it will
appear only at the very end of a run, after all the streaming.

### Using the venv from a Jupyter notebook

Register it as a kernel once, from inside the activated venv:

```bash
source .venv/bin/activate
pip install ipykernel
python -m ipykernel install --user --name car-190-rcs-spectro-trending \
    --display-name "car-190-rcs-spectro-trending (.venv)"
```

Then in Jupyter (classic, Lab, or VS Code's notebook UI) pick
**"car-190-rcs-spectro-trending (.venv)"** from the kernel selector. This
registers the kernel under your user's Jupyter data dir
(`~/.local/share/jupyter/kernels/` on Linux), independent of whichever
environment launched the Jupyter server itself. The server does not need to
be started from inside `.venv`.

Verify the registration directly, without needing a global `jupyter` on
`PATH`:

```bash
.venv/bin/python -m jupyter kernelspec list
# should include:  car-190-rcs-spectro-trending   ~/.local/share/jupyter/kernels/car-190-rcs-spectro-trending
```

To remove it later:
`.venv/bin/python -m jupyter kernelspec uninstall car-190-rcs-spectro-trending`.

#### If the kernel doesn't show up in VS Code

VS Code's kernel picker has two independent sources, and this kernel only
appears in one of them:

* **"Python Environments"** shows auto-detected venvs. VS Code's Python
  extension only scans for `.venv`/`.conda` folders at each *workspace root*,
  so a venv nested under `activities/car-190-rcs-spectro-trending/.venv`
  (like this one) typically will **not** appear here.
* **"Jupyter Kernel..."** -- kernels registered via `ipykernel install`, read
  straight from the kernelspec directory above. This is where
  **"car-190-rcs-spectro-trending (.venv)"** shows up.

So, click the kernel selector in the top right of the notebook: **"Select
Another Kernel..."** -> **"Jupyter Kernel..."**, not "Python Environments".

If it's still missing there:

1. Confirm the kernelspec exists with the `kernelspec list` command above.
   If it's missing or points at a stale `.venv/bin/python` (e.g. after the
   venv was recreated), redo the `ipykernel install` step.
2. Click the refresh icon at the top of the kernel-picker list, or run
   **"Developer: Reload Window"** from the Command Palette -- VS Code caches
   the kernel list and doesn't always pick up a newly-installed kernelspec
   until it's refreshed.
3. If working over Remote-SSH, make sure VS Code is connected to the *same
   host and user* the kernel was installed on. kernelspecs are per-machine,
   per-user, so a kernel registered on this box won't appear if VS Code is
   pointed at a different remote, a container, or a local session.
4. Sanity-check the kernel actually launches outside VS Code:
   `.venv/bin/python -c "import ipykernel, jupyter_client"` should succeed
   with no import errors; a broken `ipykernel` install can leave a
   kernelspec on disk that VS Code silently drops after it fails to start.

## Running the pipeline

All scripts are run from this directory, either with the venv active or via
`.venv/bin/python <script>.py`. The chain is:

per-SCA products (romancal L2 / quicklook) to MPA mosaic FITS to RCS trend h5
(`compile_rcs_trend.py`, unmodified) to multi-way numerical comparison.

Everything is staged under
`/mnt/roman-science-east-2/eswitzer/RCS_trend/{car190_staging,car190_derived}`;
the original `TVAC_HOB_OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA.h5` one level up
should not be overwritten and is a reference dataset generated during SCIPA.

### 1. Build the mosaics and compile the trend h5s

```bash
# both cases (romancal L2 and quicklook), full pipeline:
python stage_rcs_inputs.py

# one case at a time:
python stage_rcs_inputs.py --case scipa   # romancal L2 _cal.asdf
python stage_rcs_inputs.py --case ql      # quicklook _slope.fits.fz

# preview what would be staged without writing anything:
python stage_rcs_inputs.py --dry-run

# stage mosaics + telemetry CSV only, skip compile_rcs_trend.py:
python stage_rcs_inputs.py --skip-compile

# point one case at a different per-SCA source tree without editing the script:
python stage_rcs_inputs.py --case ql --root /mnt/roman-science-east-2/ql_output/OTP00775
```

This writes, per case, seven `<visit_id>_act<N>_<key>_mosaic.fits` mosaics plus
`rcs_telemetry.csv` under `car190_staging/<case>/.../stability_check/`, then
calls `compile_rcs_trend.process_trending_run` unmodified to produce
`car190_derived/<case>/TVAC_HOB_OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA.h5`. It
also cross-checks the recovered telemetry against the original h5's
`dictionary/` fields and prints per-LED shape/NaN-fraction/median for a quick
sanity check.

### 1b. The flight path: stream from MAST instead of a mount

`process_rcs_trending.py` is the flight sibling of `stage_rcs_inputs.py`, using the same
chain, same compiler, but the per-SCA L2 products are streamed out of S3 through
MAST and **never written to disk** - a run is ~126 files at ~67 MB, and this
activity repeats many times. Only the small intermediates are dervied: one
mosaic per activity (~18 MB each), the telemetry CSV, and the h5.

```bash
python process_rcs_trending.py --self-test        # pure functions; no network, no data
python process_rcs_trending.py --survey           # which passes exist, and how complete
python process_rcs_trending.py --pass 1 --dry-run # query + group + label, stream nothing
python process_rcs_trending.py --pass 1           # run with real data
```

`--pass` is required for every run -- see [Passes](#passes---pass-is-required).
Add `--blank-dark` if the dark exposure has not reached L2 yet, and read what that
does to the product before using it.

What was verified before flight data existed: `--self-test` (identifier
composition, the staging-id fallback, run labelling, EDP window sampling, the
compiler-glob guard) and that the `read_per_sca.py` refactor it required is a
pure code motion, reproducing the pre-refactor reader's frames, metadata and
telemetry bit-for-bit on all seven TVAC activities.

#### First live-data run, 2026-09-12 (program 1039, pass 1)

The first CAR-190 flight data reached MAST on 2026-09-12 (pass 1 exposures
01:22-01:38 UTC), and the first flight trend h5 was produced the same day:

```bash
python process_rcs_trending.py --pass 1 --blank-dark
# -> car190_flight_derived/CAR190_01039_02_001_001_20260912.h5
```

```
  LED1: (900, 1400) NaNfrac=0.39920 median=998.8475
  LED2: (900, 1400) NaNfrac=0.39918 median=879.2400
  LED3: (900, 1400) NaNfrac=0.39919 median=840.7602
  LED4: (900, 1400) NaNfrac=0.39919 median=889.8513
  LED5: (900, 1400) NaNfrac=0.39919 median=917.0091
  LED6: (900, 1400) NaNfrac=0.39919 median=910.8176
  COBA_temp 169.70 K   MPA_A_temp 109.83 K   MPA_B_temp nan
  RCS_photodiode [0, 0.244, 0.280, 0.238, 0.241, 0.240, 0.230] V
```

The `NaNfrac` of 0.399 is the inter-SCA gap fraction of the MPA mosaic, not
missing data -- all 18 SCAs are present in all six flats. **These arrays are not
dark-subtracted**; see [Running with a blank dark](#running-with-a-blank-dark).
`MPA_B_temp` is NaN by design (no flight B-side sensor).

Resolved by the live data:

* **The dark is `led=None`.** MAST reports `led='None'` with
  `exposure_type='WFI_IM_DARK'`; `is_dark()` already returns `True` for that
  (`'none'` is in `DARK_LED_VALUES`), so no change was needed.
* **The seven activities are seven distinct observations**, `...001001`
  through `...001007`, exactly as in TVAC. The 19-digit ids are therefore unique
  and the id trap below does not bite; no synthetic ids are needed. Note the
  dark is a longer exposure than the flats (177.098 s vs 41.112 s), and every
  exposure has `optical_element='DARK'` (filter wheel parked; the RCS
  illuminates without a filter), which is why the file names all end `_dark`.

* **The dark has no L2 product; the run proceeds without dark subtraction.**
  All six LED flats reached L2 complete at 18/18 SCAs while *nothing* existed
  for the `WFI_IM_DARK` observation, which was still only at L1. The flats carry
  plenty of flux, so the dark is not what limits this measurement, and waiting on
  it holds up the trend point -- see [Running with a blank dark](#running-with-a-blank-dark).

##### MAST/S3 pull timing and data rate

`stage_run` times the network fetch and ASDF decode of every product
(`stream_product` + `read_streamed_l2` -- deliberately *not* `bin_frame`
afterward, which is local CPU work with no data volume behind it), sums bytes
and seconds across each activity's 18 SCAs, and reports the implied rate. This
answers the TODO of getting data-rate statistics out of the MAST pull, rather
than estimating it from wall-clock time and a guessed file size.

Real numbers from the pass-1 run above, byte totals from MAST's own
`products['size']` column:

```
  -- MAST/S3 pull timing, per activity (downlink of L2 products) --
    act1 DARK   no L2 pulled (blank dark)
    act2 LED1     3745.0 MB    89.2 s    42.0 MB/s
    act3 LED2     3744.8 MB    80.4 s    46.6 MB/s
    act4 LED3     3745.4 MB    80.6 s    46.5 MB/s
    act5 LED4     3746.4 MB    78.4 s    47.8 MB/s
    act6 LED5     3746.3 MB    70.4 s    53.2 MB/s
    act7 LED6     3746.0 MB    71.4 s    52.4 MB/s
    total      22473.9 MB   470.5 s    47.8 MB/s
```

18 SCAs at ~208 MB each is ~3.75 GB per activity; the run-wide rate climbed
from ~42 to ~53 MB/s over the ~8 minutes, with no `403 Forbidden` retries
triggered (see [Verified against real products](#verified-against-real-products)).
The blank dark pulls nothing, so its row has no rate rather than a
division-by-zero.

This is surfaced three ways:

* **Per-activity FITS header fields** on every mosaic (`PULLB` bytes,
  `PULLSEC` seconds, `PULLMBPS` MB/s; `-99` for `PULLMBPS` when nothing was
  pulled, matching the `EXPTIME`-absent convention elsewhere in this pipeline).
* **New `activity_table.csv` columns** (`pull_MB`, `pull_seconds`,
  `pull_MBps`) -- outside the compiler's glob, so adding them is free; see
  [Where the telemetry comes from](#where-the-telemetry-comes-from).
* **A run-total summary line** printed once staging finishes, before the
  compiler runs -- `report_pull_timing` in `process_rcs_trending.py`.

##### Passes: `--pass` is required

The activity repeats, and **consecutive passes reuse the same observation
numbers** -- only the `pass` field of the 19-digit Visit Identifier tells them
apart. A query that does not pin the pass therefore returns two interleaved runs,
and nothing downstream would notice: `assign_staging_ids` sees distinct ids and
stays quiet, `group_activities` finds more than six lit activities only if *both*
passes happen to be complete, and `build_telemetry_table` windows the EDP from the
earliest start to the latest end -- on 2026-09-12 that is 01:22 to 05:43, so every
housekeeping median would be taken over both passes plus the four-hour gap
between them.

So `--pass N` is required, and omitting it prints the inventory it is chosen from
(`--survey` prints the same thing without the error):

```bash
python process_rcs_trending.py --survey
```

```
  pass obs  exp exposure_type    led  L1  L2  start
     1   1    1 WFI_IM_DARK     None  18   0  2026-09-12T01:22:16.1080000  <- no L2 yet
     1   2    1 WFI_FLAT           1  18  18  2026-09-12T01:25:50.7140000
     1   3    1 WFI_FLAT           2  18  18  2026-09-12T01:27:12.4550000
     1   4    1 WFI_FLAT           3  18  18  2026-09-12T01:28:34.1960000
     1   5    1 WFI_FLAT           4  18  18  2026-09-12T01:31:42.0920000
     1   6    1 WFI_FLAT           5  18  18  2026-09-12T01:34:37.5000000
     1   7    1 WFI_FLAT           6  18  18  2026-09-12T01:37:14.1740000
       pass 001: 7 exposures, 6/7 exposures at L2
       span 2026-09-12T01:22:16.1080000 .. 2026-09-12T01:37:58.4490000
     2   3    1 WFI_FLAT           2  18  18  2026-09-12T05:32:23.7320000
     2   4    1 WFI_FLAT           3  18  18  2026-09-12T05:33:45.4740000
     2   5    1 WFI_FLAT           4  18  18  2026-09-12T05:36:53.3700000
     2   6    1 WFI_FLAT           5  18  18  2026-09-12T05:39:48.7770000
     2   7    1 WFI_FLAT           6  18  15  2026-09-12T05:42:25.4510000  <- L2 incomplete
       pass 002: 5 exposures, 4/7 exposures at L2
       span 2026-09-12T05:32:23.7320000 .. 2026-09-12T05:43:09.7260000
```

Read as of 2026-09-12 ~06:40 UTC. **Pass 1 is complete** apart from the dark's
L2: all six flats at 18/18, spanning a ~16-minute window. **Pass 2 is still
ingesting**: observations 1 (the dark) and 2 (`LED1`) had not appeared at *any*
level, observation 7 was at 15/18 at L2, and file dates were still advancing.
Each pass is one trend point and gets its own run label, so pass 1 can be
processed now and pass 2 re-run later without either overwriting the other.

Two layers enforce this. `--pass` is the ergonomic front door; `assert_single_pass`
is the invariant, checked after grouping, because `--visit`, `--run-label` and a
hand-built `search` all reach `group_activities` too.

##### Running with a blank dark

`--blank-dark` lets a run proceed when the dark exposure has no L2 products:

```bash
python process_rcs_trending.py --pass 1 --blank-dark
```

**The LED arrays in the resulting h5 are NOT dark-subtracted.** That is the whole
point of the flag and the one thing to know about the product. Specifically:

* Row 0's mosaic is written as an **all-NaN placeholder** (`BLANKDRK = T` in its
  header). NaN rather than zero deliberately: if anyone later re-enables
  subtraction against a blank dark, every array goes NaN rather than silently
  producing an unsubtracted trend that looks fine.
* `compile_run` is called with `subtract_dark=False`, so `compile_rcs_trend.py`
  stores `led_data` rather than `led_data - dark_array`. The compiler itself is
  still byte-for-byte unmodified; it already had the argument, and both callers
  simply hardcoded `True` before.
* Row 0's **telemetry is real, not blank.** The L1 dark supplies its true 19-digit
  id and its exposure window, so the EDP is sampled over the actual dark
  exposure. This matters beyond bookkeeping: the compiler does
  `pd_array -= pd_array[0]` unconditionally, so the photodiode baseline for the
  whole run comes from row 0 whether or not the image is subtracted.
* **No L1 pixels are read.** An L1 ramp is not a calibrated rate image, and
  quietly differencing one against L2 rates would be worse than not subtracting
  at all. Only metadata is taken from L1.
* The compiled h5 carries root-level attributes `dark_subtracted=False`,
  `dark_blank=True` and a `provenance` string. A cube that was never
  dark-subtracted is not comparable to a TVAC cube that was, and *nothing else in
  the file records the difference* -- the dark image never enters the h5, only its
  subtraction does. These are attributes rather than datasets so
  `load_from_hdf5` and everything reading these files are unaffected; read them
  with `h5py.File(path).attrs` or `h5dump -A`.

The flag is opt-in rather than an automatic fallback so that a future run where
the dark *does* exist but the query hiccups cannot silently yield an
unsubtracted product. Passing it when the dark did arrive is harmless: the real
dark is used and subtracted as usual, and the run says so.

Re-run without `--blank-dark` once the dark's `_cal` products appear, to get the
properly subtracted trend point.

##### EDP mnemonics: 3 of 15 were TVAC-only names

Querying `read_per_sca.HK_COLUMNS` over the run window returned data for 12 of
15; three failed with `HTTP 400 Bad Request`, i.e. the flight EDP does not know
the name at all:

| TVAC `HK_COLUMNS` name | flight mnemonic now queried | value over the run |
| --- | --- | --- |
| `WFI_COBA_WTSC10P_K` | `WFI_MCE_ADC_WTSM04` | ~169.7 K |
| `WFI_MCU_A_MPA_CSENS_FPSSEN_K` | `WFI_MCE_ADC_WTSM00` | ~109.8 K |
| `WFI_MCU_B_MPA_CSENS_FPSSEN_K` | *(none -- no flight equivalent)* | NaN |

`compile_rcs_trend.py` reads these three column names out of the CSV verbatim
(`COBA_temp`, `MPA_A_temp`, `MPA_B_temp`), and it stays unmodified, so the
columns cannot simply be renamed. `FLIGHT_MNEMONIC_ALIASES` in
`process_rcs_trending.py` queries the flight mnemonic and writes it back under
the TVAC column name. All 15 columns are now populated and the EDP query runs
clean.

**These two substitutions are unverified -- they need instrument-team
confirmation.** They are the mnemonics this README already lists under "MAST EDP
temperature of interest", and the values are physically plausible, but the EDP
metadata reports `subsystem='unknown'` for every `WFI_MCE_ADC_WTSM*`, so
nothing in the archive itself confirms which index is the MPA and which the
COBA. One consistency check does support the COBA choice:
`CDHA_TCS_WTSC10P` -- same sensor number as the TVAC name -- reads -103.0 degC
= 170.1 K, within a few tenths of `WTSM04`'s 169.7 K, which is what you would
expect if `WTSM04` is that same sensor already in Kelvin (as the TVAC `_K`
suffix implies).

There is no B-side MPA temperature in flight: the MPA temperature is exposed
once, off the MCE ADC rather than per-MCU, and the only `WFI_MCU_*_MPA_*`
mnemonics are heater/DAC, not `CSENS`. `MPA_B_temp` is therefore NaN. It is
deliberately *not* aliased to `WTSM00` as well -- that would make `MPA_B_temp`
look like an independent reading of a sensor that is only measured once.

##### LED numbering: `meta.rcs.led` counts activities, the EDP names hardware

For all six flats the EDP `BANK2SEL` enable flags and `meta.rcs.led` disagree by
one index, wrapping:

```
observation  :  002   003   004   005   006   007
meta.rcs.led :  1     2     3     4     5     6
EDP BANK2SEL :  LED6  LED1  LED2  LED3  LED4  LED5
```

**This is expected and already handled.** It looks alarming and is not.
`meta.rcs.led` is a sequential *activity* counter; the EDP names the *hardware*
LED, and the activity sequence lights the bank in the order 6, 1, 2, 3, 4, 5.
Two independent facts establish this:

* `group_activities`' own docstring records it from TVAC: *"the hardware order is
  not the activity order -- activity 2 there lit hardware LED6."*
* The TVAC telemetry CSV
  (`car190_staging/scipa/TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA/stability_check/rcs_telemetry.csv`)
  has hardware enables by CSV row order of *none, 6, 1, 2, 3, 4, 5* -- **identical
  to flight.**

So there is no off-by-one to fix and no risk of comparing different LEDs. The
`LED1`..`LED6` h5 keys are assigned by CSV **row order** (`ACTIVITY_TO_KEY`),
which is the activity order in both TVAC and flight, so a flight `LED1` and a
TVAC `LED1` are the same physical lamp -- they are both "the first lit activity",
which is hardware LED6 in both.

The sampling is also not timing slop: each flat falls entirely inside exactly one
LED's `ENA` window (coverage fraction 1.00 in every case) and the dark has no LED
enabled at all.

What changed as a result: both numberings are now recorded explicitly rather than
one being called the other. Per mosaic header, `ACTLED` is the activity-order
value from `meta.rcs.led` and `HWLED` is the hardware LED from the EDP enables
(the old header wrote the activity value *under the name* `HWLED`, which was
simply mislabelled). `report_led_order` prints the row->hardware map once per run
so a genuine change in the wiring or the activity sequence would be visible, and
warns only on the two things that would actually be wrong: more than one LED
enabled during an exposure, or the six flats not covering six distinct hardware
LEDs.

##### The photodiode: a time-stream derivation, validated against all 34 good products

The frozen compiler computed `dictionary/RCS_photodiode` as
`pd_raw - pd_raw[0]`, where `pd_raw` is a per-activity windowed median and entry
0 is the dark. That conflates the dark *exposure window* with the interval the
LEDs were actually *off*. `rcs_photodiode.py` replaces it with a reduction over
the photodiode's own sample grid: step-interpolate the six `BANK2SEL` enables
onto that grid, run-length encode the resulting state, and take the pedestal
from the all-off *interval* that overlaps the dark's window.

This matters because **`pd_net` is a denominator** -- `led_scale_factors` forms
`reference.photodiode[i] / epoch.photodiode[i]`. Nominal `pd_net` is 0.23-0.28 V
on a 0.1164 V pedestal, so a pedestal that was not really dark can push `pd_raw`
to 0.12 V, give `pd_net = 0.004`, and produce a 60x response factor
indistinguishable from a real instrument event. Hence `PD_MIN_NET` and
`pd_net_valid`: below the floor no factor is formed at all.

Validate it without downloading a single pixel:

```bash
# one pass, seconds, no streaming; --use-plan also issues no MAST listing
.venv/bin/python process_rcs_trending.py --pd-only --use-plan --pd-plot \
  --program 1063 --execution-plan 2 --pass 66 --decon-cycle decon2 --blank-dark \
  --staging-root /data/eswitzer/rcs_trend_v2_test/stage \
  --pd-dir /data/eswitzer/rcs_trend_v2_test/pd

# then compare every ECSV against whatever products already exist
.venv/bin/python check_pd_regression.py \
  --pd-dir /data/eswitzer/rcs_trend_v2_test/pd \
  --h5-dir /data/eswitzer/rcs_trend
```

`check_pd_regression.py` makes two deliberately different comparisons.
`pd_net_legacy` reimplements the old rule and must be **bit-exact**
(`--legacy-atol 1e-12`) -- it is a pure regression gate on the windowing and the
median. `pd_net` is the new quantity and is **not** bit-exact by design, so its
tolerance (`--atol 1e-5`) is a statement about tolerable pedestal drift.

**Result over all 34 passes of `/data/eswitzer/rcs_trend`: PASS.**

| quantity | result |
|---|---|
| legacy mirror vs stored array | worst 1.1e-16 V = **0.00 telemetry quanta** (bit-exact, 34/34) |
| `pd_net` vs stored array | worst 7.8e-06 V, i.e. 26 quanta |
| spread of that offset across the six LEDs | <= 3.4e-17 V -- a pure **common** offset |
| worst impact on a response factor | **33.6 ppm** |
| pedestal source | `dark_window` on **34/34**; no fallback ever fired |
| railed samples inside any exposure window | **0** |
| epoch-level warnings | **0** |

The offsets are every one an exact integer or half-integer multiple of the
2.9802322e-07 V telemetry LSB (`10 V / 2**25`), spanning -22 to +26 quanta --
so the entire disagreement is quantisation-level pedestal difference and nothing
else. Because it is a *common* offset it cancels exactly in the
`reference_pd / epoch_pd` ratio the corrections actually form; the spread, not
the offset, is the number that would signal a real per-LED change.

Two measured findings are now guarded in code rather than assumed away:

* **The photodiode rails at exactly 2.5000 V** (`cfg.PD_RAIL_V`). On CAR-216
  pass 66, 220 of 2620 samples sit at precisely that value -- all in the gaps
  between exposures while the LED drive settles, **none inside any window**, and
  none inside a window across all 34 passes. A railed sample is clipped, not
  measured, so one inside a window would inflate `pd_raw` in the direction that
  looks like the lamp brightening. Counted per activity as `n_railed` and
  warned, never silently clipped.
* **The 10-minute pad reaches into the adjacent pass.** Trend passes run back to
  back: 59% of the pre-run pad and 60% of the post-run pad have an LED enabled,
  in states the run itself never visits. So contrary to the original rationale
  for raising `PD_PAD_MINUTES` from 5 to 10, the pad does *not* reliably supply
  quiet telemetry -- it is the dark's own off interval that supplies the
  pedestal. Preferring `dark_window` over `pooled_off` is therefore load-bearing,
  not cosmetic.

###### PD1 is a second monitor, not an inactive diode

`WFI_MCE_SRCS_PD1_V` was pulled as a free check that the right bank was assumed,
on the expectation that it would stay flat. **It does not.** PD1 is BANK1's own
*measurement* diode and sees the lamp at an amplitude comparable to PD2, so "PD1
is flat" was never the right check. The useful invariant is the *ratio* of the
two diodes' nets, which is a fixed per-LED number. Tabulated in **band order**,
with the hardware channel as a second row because the two numberings differ:

| band | 624 nm | 853 | 1039 | 1270 | 1481 | **1670** |
|---|---|---|---|---|---|---|
| hardware LED | 6 | 1 | 2 | 3 | 4 | **5** |
| PD1/PD2 net | 1.1350 | 1.0566 | 1.1639 | 1.1941 | 1.1676 | **0.2052** |
| reproducibility, 34 epochs | 675 ppm | 652 | 647 | 657 | 659 | 794 |

**This is the InGaAs cutoff.** PD1 is InGaAs and PD2 is HgCdTe. The ratio is
flat to +/-6% from 624 through 1481 nm and then collapses 5.7x at 1670 nm, the
longest band -- exactly the edge of lattice-matched In_0._53Ga_0._47As, which cuts
off near 1.7 um and moves shorter as it cools. PD2 reads a healthy 0.231 V on
that same LED.

> An earlier version of this table was keyed by hardware LED but labelled with
> band wavelengths, which put the `0.2052` under "1481 nm" and led this section
> to conclude the suppression was "not a detector cutoff." The mapping is
> `LED1->hw6, LED2->hw1, LED3->hw2, LED4->hw3, LED5->hw4, LED6->hw5`, verified on 40
> v3 epochs. Under the mislabelled reading the row was physically absurd -- a
> 5.7x dip at 1481 nm with full response restored at 1670 nm -- and that is what
> gives the corrected reading away. Wherever a hardware LED number appears in
> this pipeline it is now named as such.

The scatter is real and separate: it is the tightest of the six in fractional
terms (572 ppm), so one month at controlled temperature shows no instability
near the cutoff. That does not license extrapolating across a thermal excursion
with the diode sitting on a moving band edge.

Recorded as `pd_check_net` / `pd_check_ratio` and **never used in a
correction**. Its value is diagnostic: a real lamp change moves both diodes and
leaves the ratio alone, whereas a diode change or a window-to-lamp
misattribution moves the ratio -- including an MCE side swap, which no mnemonic
name reports. PD1 gets its own pedestal by the identical rule (adopting PD2's
for it inflated the scatter by a third); the two pedestals differ by a median
4.33 mV, and PD1's dark noise is ~18x lower. Why it is still only a check, and
what a side swap does to all of this: `PD_CORRECTION.md` Sec. 8.

###### LED turn-on: three of six lamps clip the photodiode for up to a minute

`plot_pd_sequence.py` writes one `plots/pd_sequence/<run_label>.png` per epoch
and a pooled `pd_settle_summary.ecsv`. It began as "plot the PD time stream
against the PD in the L2 file metadata" and the premise turned out to be wrong:

> **There is no photodiode value in the L2 metadata.** `meta.rcs` is
> `{active, bank, counts, electronics, led}` -- `counts: 1500` is commanded LED
> drive, not a reading -- and none of the 146 metadata leaves of a `*_cal.asdf`
> matches `photo|diode|_pd|pd_|current|volt|lamp|srcs`. The PD exists only in EDP
> housekeeping. What L2 contributes is the LED flag, the commanded drive and the
> exposure bracket, so the comparable quantity is the **in-exposure median of the
> stream** -- the value the L2 frame actually integrated against, and the one
> `rcs_corrections` consumes.

The LED enable interval is much longer than the exposure window, and what happens
in the lead time splits the six lamps into two groups. Measured over **39 passes
spanning CAR-190 (plans 2 and 3) and CAR-216**, 246 activities:

| hardware LED | clips? | clip duration | lead margin | in-exposure PD | pass-to-pass scatter |
|---|---|---|---|---|---|
| 1 | no | 0 s | 17 s | 0.3964 V | 196 ppm |
| 2 | no | 0 s | 17 s | 0.3544 V | 162 ppm |
| **3** | **yes** | **64-65 s** | 58 s | 0.3576 V | 3653 ppm |
| **4** | **yes** | **51-52 s** | 58 s | 0.3568 V | 2266 ppm |
| **5** | **yes** | **34-35 s** | 57 s | 0.3468 V | 1036 ppm |
| 6 | no | 0 s | 18 s | 0.3595 V | 605 ppm |

Hardware LEDs 3, 4 and 5 drive the PD into a **2.5 V clip** for tens of seconds
after enable, then drop to the exposure level as the forward voltage settles
(1.3111 V -> 0.9778 V for LED 3).

**2.5 V is readout saturation, not a physical plateau**, which is why the figure
refuses to interpret the level and reports only the duration. Proof: across the
64 s LED 3 spends there, 149 of 152 samples read 2.5000000 V to within one
telemetry quantum (2.98e-07 V) *while the forward voltage is still visibly
drifting*, 1.31113 -> 1.30647. An unclipped analog signal cannot hold the same LSB
for a minute while its own drive changes. The lone sample per step above 2.5 V
(3.81187 V on CAR-190 pass 1) is not headroom -- it lands exactly on the drive
step, where the forward voltage is also mid-transition at 1.17407, between
1.30647 and 0.97779, so it is one sample integrating across the switch.

Three things this establishes:

- **The sequence already compensates.** Lead time is 56-59 s for exactly the
  three LEDs that clip and 16-18 s for the three that do not. That is not a
  coincidence of timing; the observing sequence allocates the longer lead where
  the hardware needs one.
- **No exposure is contaminated.** `settle_margin_s` -- PD back on-scale to
  shutter open -- is **never negative in any of the 246 activities**, minimum 16 s.
  A negative margin would mean a frame integrating while its own PD denominator
  was off-scale, so this is checked and reported rather than assumed.
- **The scatter in the right-hand column is lamp behaviour, not settling.**
  Within-exposure drift is 12-48 ppm median with no systematic difference between
  the clipping and non-clipping groups, so the exposures are equally settled and
  that 1000-3700 ppm pass-to-pass variation is real lamp output -- exactly what
  the PD correction divides out.

Clip duration is stable to +/-1 s over 39 passes (slopes ~ 0.004 s/pass, i.e. a
quarter-second across the whole trend), so it is a fixed hardware characteristic
today. Having it in an ECSV is what makes a *change* in it detectable later: a
lamp taking longer to come off the clip is a degradation signature, and it is
invisible in every quantity the digests currently carry.

```bash
# the stream sidecars this needs: no imagery, seconds per pass
.venv/bin/python process_rcs_trending.py --pd-only --pass 1 \
  --program 1039 --execution-plan 2 --decon-cycle decon1 --use-plan \
  --staging-root /data/eswitzer/rcs_trend_v2_test/stage \
  --pd-dir /data/eswitzer/rcs_trend_v2_test/pd

# then the figures, offline and credential-free. The current set in plots/pd_sequence/
# is all 176 epochs, drawn from the v3 sidecars:
.venv/bin/python plot_pd_sequence.py \
  --in '/data/eswitzer/rcs_trend_v3/h5/pd/pd_*.h5' --out-dir plots/pd_sequence
```

`--pd-only` now also writes `pd_<label>.h5` holding just the `photodiode/` group
(~100 kB; the ECSV carries only the per-activity reduction, so the settle
structure cannot be recovered from it). `rcs_photodiode.read_photodiode_group` is
the inverse of the writer, so every PD diagnostic reads a stored stream instead of
re-querying the EDP.

##### Verified against real products

Streaming works end to end on flight data: `MastMissions.read_product()` on
`r0103902001001003001_0001_wfi05_dark_cal.asdf` returned a (4088, 4088) float32
frame, 99.94% finite. `meta.groundtest` is **absent**, as the design assumed,
and `meta.rcs` is present and populated:
`{'active': True, 'bank': '2', 'counts': 1500, 'electronics': 'A', 'led': '2'}`.

All 108 `_cal` products for pass 1 streamed and mosaicked in ~9 minutes
(~85 s per activity for its 18 SCAs), with no `403 Forbidden` retries triggered.

One MAST schema note: there is **no `exposure` column** on the Roman mission
interface (it warns `Column 'exposure' not found. Did you mean "exposure_type"?`
and drops it). The 4-digit Exposure Identifier is only available from
`fileSetName`, e.g. `r0103902001001001001_0001_wfi01_dark` -- hence
`_exposure_from_file_set`. Every other name in `SELECT_COLS` is honoured,
including `led`.

#### Token setup

Both halves of the flight path, the MAST query and the EDP telemetry, use one
token. Put it in `variables.env` in this directory (git-ignored) or export it:

```
MAST_API_TOKEN='...'      # from https://auth.mast.stsci.edu/info
```

**If your call isn't picking up the token:** `rcs_edp.edp_token()`
only looks for `./variables.env` relative to your **current working
directory**, not the script's directory, and it is not exported into the
environment otherwise. So if `variables.env` lives at the repo root
(`RST_commissioning/variables.env`) but you run
`python process_rcs_trending.py --pass 2` from inside
`activities/car-190-rcs-spectro-trending/`, that file is never found and the
run fails with `MAST_API_TOKEN is not set`. Fix by doing one of:

* run from the repo root: `python activities/car-190-rcs-spectro-trending/process_rcs_trending.py --pass 2`, or
* copy/symlink `variables.env` into this directory, or
* export it in your shell before running:
  ```bash
  export MAST_API_TOKEN='...'
  python process_rcs_trending.py --pass 2
  ```

#### Run labels and output layout

The activity repeats, so run identity is carried in both the directory and the
h5 name rather than a fixed path. The label is derived from MAST metadata:

```
CAR190_<program>_<execution_plan>_<pass>_<segment>_<YYYYMMDD>
e.g. CAR190_00123_01_008_002_20270314
```

That is the `PPPPPCCAAASSS` prefix of the Visit Identifier plus the start date:
the granularity at which the activity repeats, since the observation and visit
digits vary *within* one run. Output:

```
car190_flight_staging/<run_label>/activity_table.csv          (full provenance)
car190_flight_staging/<run_label>/stability_check/
    rcs_telemetry.csv                                         (compiler's input)
    mosaics/<staging_id>_act<N>_<key>_mosaic.fits
    mosaics/sca_id_map_r4.fits
car190_flight_derived/<run_label>.h5
```

`car190_flight_staging` and `car190_flight_derived` above are both rooted at
`RCS_TREND` (`/mnt/roman-science-east-2/eswitzer/RCS_trend`), which is just
the default. `--staging-root <dir>` overrides the staging root, and
`--out-dir <dir-or-s3-uri>` overrides where the compiled h5 is delivered:

```bash
python process_rcs_trending.py --pass 1 --out-dir s3://roman-science/rcs_trend/
```

`--staging-root` must stay a local path -- `compile_rcs_trend.py` globs
mosaics and opens FITS/CSV files directly and cannot read them from S3.
`--out-dir` may be local or `s3://`; when it is `s3://`, the h5 is still
compiled locally first (`h5py` can only write a real file) and then uploaded
with `publish_file`, since neither `annotate_h5` nor `load_from_hdf5` can
touch S3 directly either.

An existing run directory is never overwritten silently, you must pass `--force` or
`--run-label`.

#### Where the telemetry comes from

Flight L2 products have no `meta.groundtest`, which on TVAC was the source of
`activity_number`, `wfi_otp_targettype`, `led_bank2_approx_wlen` and the whole
~2500-key `hdf5_telemetry` blob that `read_per_sca.build_activity_table`
reconstructs the compiler's CSV from. On the flight path:

* the 15 `HK_COLUMNS` scalars and the 6 `BANK2SEL_LED*` enables come from the
  Engineering Data Portal (`rcs_edp.py`), queried once over the run's time
  window and then sampled per exposure. 12 of the 15 mnemonic names carry over
  from TVAC unchanged; the other three do not exist in the flight EDP and are
  redirected through `FLIGHT_MNEMONIC_ALIASES` -- see the live-data notes above,
  since two of those three are still unconfirmed.
* LED identity is recorded twice, in two different numberings: `meta.rcs.led`
  gives the **activity** order (mosaic header `ACTLED`) and the EDP `BANK2SEL`
  enables give the **hardware** LED (`HWLED`). These are expected to differ, and
  neither is load-bearing -- the compiler names its arrays by CSV row order. See
  [LED numbering](#led-numbering-metarcsled-counts-activities-the-edp-names-hardware).

`rcs_edp.py` reimplements the approach of
[notebooks/engineering_database_retrieval/](../../notebooks/engineering_database_retrieval/)
rather than importing it.

#### The 19-digit id trap

`compile_rcs_trend.process_trending_run` locates each CSV row's mosaic by
globbing `mosaics/{visit_number}*` and taking `fits_files[0]`, where
`visit_number` is the 19 digits its regex pulled from `exp_path_done`. But the
19-digit Visit Identifier `PPPPPCCAAASSSOOOVVV` is *visit*-level -- the 4-digit
Exposure Identifier is what varies within a visit.

In TVAC the seven activities were seven distinct **observations**
(`0077501056054<NNN>001`), so each had its own 19-digit id and the glob resolved
uniquely. If in flight they are instead seven **exposures within one visit**,
all seven share one id, the glob matches all seven mosaics, and `fits_files[0]`
hands back the same file for the dark and for every LED. This gives dark-subtracted
arrays of approximately zero, silently.

`process_rcs_trending.py` guards this through: (1) it substitutes the exposure
number into the low four digits when the true ids are not unique 
(2) it asserts the resulting ids are 19 digits and distinct
and (3) `check_compiler_globs` re-runs the compiler's own glob before
compiling and requires exactly one match per row. The true `fileSetName` and
exposure number are recorded in the mosaic headers (`FILESET`, `EXPNUM`,
`SYNTHID`) so a synthetic id is not mistaken for an archive identifier.

The compiler itself stays byte-for-byte unmodified, so the flight and TVAC cubes
are packaged by identical code and a comparison between them isolates the input
data.

### 2. (Optional) re-verify the SCA orientation convention

To check the orientation conventions of the input SCA data:

```bash
python calibrate_orientation.py --test cd
```

(`--test` also accepts `a`, `b`, `c`, `d`, `both`, or `all`; `cd` -- the two
decisive tests -- is the default.)

### 3. Run the three-way comparison

```bash
python compare_rcs_h5.py
```

Compares `1_original` (the pre-existing h5), `2_romancal_l2`, and
`3_ql_slope`. Writes ~110 figures under `plots/{mosaics,differences,ratios,
normalized,per_sca,trends,histograms,nonimage}/` and tables (CSV +
`summary.md`) under `plots/tables/`. Add `--tables-only` to skip the figures,
or `--plots-root <dir>` to write elsewhere.

# Work flows

## The full pipeline, end to end

Three stages, and the seam between them is deliberate. **Stage 1 is the only one
that touches the network**, so it is the only one that needs SLURM and a token;
stages 2 and 3 are local, fast, and reproducible from committed artifacts.

```
                                       what runs it            cost
L2 per-SCA products in MAST
  |   stage 1: stream, bin, write      batch/refresh.py pull   ~2 min/pass, 8-way
  |            raw per-SCA h5          (SLURM, the network step)
  v
*_raw.h5    (18, 256, 256) per LED, no corrections, ~17 MB/epoch
  |   stage 2: RECORD the per-epoch    calibrate_rcs_products.py   ~15 s, 16 jobs
  v            factors; apply none     (run_trend.py runs 2 and 3)
*_cal.h5    the SAME pixels + calibration/<step>/multiplier
  |   stage 3: apply them, ratio to    make_sca_digests.py     ~1 min
  |            reference, reduce per SCA,
  v            fit ACM + side bridges
time_series_SCA1..18.ecsv  +  figures  +  run_log.txt  +  rcs_bridge_solution.ecsv
  |   analysis                         fit_film_thickness.py
  v                                    fit_film_rank1.py
film thickness per SCA
```

Two artifacts run backwards through that diagram. `run_trend.py` does both in one call:

```
time_series_SCA1..18.ecsv  (the gain-free LED1..LED6 columns)
  |   the bridges, fitted at stage 3   make_sca_digests.py --solution-out
  |   the gain, fitted from the        fit_temperature_gain.py --model-out
  v   digests                          (~25 min, 16 processes)
rcs_bridge_solution.ecsv + tempgain_model.ecsv
  |   re-run STAGE 2 with              calibrate_rcs_products.py --force
  v   both                             --bridge-solution --tempgain-model
*_cal.h5 + calibration/{acm_bridge,side_bridge,tempgain}   recorded, NOT applied
  |   re-run STAGE 3                   make_sca_digests.py
  v                                    (checks the products carry its own fit)
```

**This is a bootstrap, not an iteration, and the distinction is load-bearing.**
The fit reads the canonical `LED1..LED6` digest columns, which are gain-free at
every stage and stay that way. The second stage-2 pass is purely additive --
proven, not asserted: 18 808 datasets and 2.05e9 float elements bit-identical
across the whole 176-product set. So the fit's own input is unchanged by its own
output, and the loop closes after one turn. Measured rather than argued: refitting
on the *gain-carrying* digests returns all 108 `alpha1`/`alpha2` identical to
every printed digit, with the same chi^2/dof and the same growth rate. That is the
regression gate.

Were the gain ever applied to the canonical columns, `fit_temperature_gain.py`
would become a fixed-point iteration on its own output -- which converges to
coefficients near zero and reads as a clean null result. `load_dataset` therefore
refuses a digest whose `tempgain_applied_to` meta does not name only the
`_tgcorr` columns, so the mistake cannot be made quietly.

The bridges follow the same reasoning. A bridge step is fitted from the epochs
on either side of an ACM move or a side swap, so it is not a property of one
epoch, and fitting it inside stage 2 would make stage 2 need the whole set and
stop being parallel. So stage 3 fits it and stage 2 records it on its second
pass. The bridges are fitted from photodiode- and ACM-corrected response, which
that pass does not change, so stage 3's refit is bit-identical and its
`bridge_solution_check` reads `current`.

Why stages 2 and 3 do not double-count: a calibrated product's arrays already
carry the scalars, and re-applying them in the digest would **square** each
factor. A 1.002 photodiode factor applied twice is 1.004 -- indistinguishable
from a real 0.2 % response change. `make_sca_digests.py` reads
`corrections_applied` back from the product's attributes and switches them off,
rather than trusting the CLI flags.

### One-shot recipe for a whole trend set

Set these once; everything below uses them.

```bash
cd activities/car-190-rcs-spectro-trending
ROOT=/mnt/smdc-rom-com-ops/rrn-ops/activities/car-190-rcs-spectro-trending/rcs_trend_v4   # rcs_trend_config.TREND_ROOT
TOKEN=../../variables.env            # holds MAST_API_TOKEN='...'
DIGESTS="$ROOT/digests/digests_v4_$(date +%m_%d_%y)"
```

```bash
# 0. the gate. Pure functions, no network, no credentials, ~20 s. Every module's
#    self-test runs here, including the photodiode denominator guard and the
#    run log's "does it actually say what it exists to say" checks.
.venv/bin/python process_rcs_trending.py --self-test

# 1. manifest from the archive (not the hand-maintained list). Both defaults
#    label only passes the manifest does not already hold, and are required as
#    soon as there are any -- confirm them first, and --relabel any that sit
#    across a boundary (DATA_PULL.md, steps 2-3).
.venv/bin/python batch/make_manifest.py --from-survey --dry-run \
    --default-decon-cycle decon2 --default-mce-side B   # diff only, writes nothing
.venv/bin/python batch/make_manifest.py --from-survey \
    --default-decon-cycle decon2 --default-mce-side B

# 2. STAGE 1 rung 1: plan every pass, 4-way, no downloads, minutes
sbatch --partition=cpu-lg --nodes=1 --ntasks-per-node=4 batch/submit_plan.sbatch \
    "$(pwd)" batch/run_manifest.csv "$TOKEN" "$ROOT/stage" "$ROOT/h5" -1

# 3. inspect coverage before committing to any download. A status file is named
#    <row>.<outcome> and holds only the detail string, so read it by name.
ls batch/status/*.planned  | wc -l       # plans cached (not products)
ls batch/status/*.degraded | wc -l       # passes MAST has not finished indexing
for f in batch/status/*.degraded; do     # ...and by how much
    printf '%-34s %s\n' "$(basename "$f" .degraded)" "$(cat "$f")"
done

# 4. STAGE 1 rung 2: stream from the cached plans, 8-way, ~2 min per pass
USE_PLAN=1 sbatch --partition=cpu-lg --nodes=1 --ntasks-per-node=8 \
    batch/submit_manifest.sbatch \
    "$(pwd)" batch/run_manifest.csv "$TOKEN" "$ROOT/stage" "$ROOT/h5" -1

# 5. did stage 1 actually produce complete products?
.venv/bin/python batch/triage_products.py "$ROOT/h5"
# relocate any short ones so rung 2 rebuilds them, then resubmit step 4:
.venv/bin/python batch/triage_products.py "$ROOT/h5" --move-degraded --apply

# 6-9. STAGES 2 AND 3, one call. Card -> stage 2 (photodiode + ACM recorded) ->
#      digests that fit the ACM and side bridges -> optionally the temperature
#      gain -> stage 2 again recording the bridges (and gain) -> final digests,
#      figures, run log -> stage-2 diagnostics. Prints every command it runs and
#      FAILS unless the bootstrap closes. ~2 min; ~30 with --fit-tempgain.
.venv/bin/python run_trend.py --root "$ROOT" --dry-run       # read the plan first
.venv/bin/python run_trend.py --root "$ROOT" --fit-tempgain

# 8. read the run log before reading the digests
less digests/digests_*_$(date +%m_%d_%y)/run_log.txt

#    the genuinely per-(SCA, LED) gain variant, for comparison only -- the model
#    run_trend.py fits is achromatic, because LED1's apparent excess is
#    film-model leakage
.venv/bin/python fit_temperature_gain.py --processes 16 --chromatic \
    --digest-dir "$ROOT/digests_pass1" --cal-dir "$ROOT/cal" \
    --model-out /tmp/tempgain_model_chromatic.ecsv

# 10. analysis
.venv/bin/python -u fit_film_thickness.py --digest-dir digests/<the set> \
    --out-dir plots/rate_inference --profile-all \
    --events example_events.yaml --extrapolate-hours 50
.venv/bin/python fit_film_rank1.py --out-dir plots/rank1_eps --exponent-spread
```

**Why stage 2 runs twice.** Calibrated products record every factor needed to
calibrate them and apply none (schema 2, [RCS_TREND_REFERENCE.md](RCS_TREND_REFERENCE.md)
Sec. 4). Two of those factors, the ACM bridge and the side bridge, are fitted from
the whole trend, which no per-file stage sees. So:

1. stage 3 fits them and writes `rcs_bridge_solution.ecsv`;
2. stage 2 records them in every product;
3. stage 3 refits and checks that the products carry what it fits.

The temperature gain follows the same path through `tempgain_model.ecsv`. It is
a bootstrap, not an iteration: the second stage-2 pass moves no pixel and no
per-file factor, so the refit sees bit-identical input. `run_trend.py` asserts
both consequences:
- `bridge_solution_check` reads `current`;
- `LED1...LED6` are bit-identical between the two digest passes.

**The gain stays provisional.** It is recorded in every product but left out of
`calibration/total_multiplier` and of the digests' `LED1...LED6`; it appears in
their `LEDx_tgcorr` columns. See `TEMPERATURE_GAIN.md` for why applying it
upstream of the thin-film fit would be worse than not having it: its error is
absorbed as a growth-rate bias, the one quantity that fit exists to measure.
`--fit-tempgain` writes the new model into the trend tree and leaves the
committed `tempgain_model.ecsv` alone; `run_trend.py` prints the `cp` to adopt it.

**All of the products or none of them.** For the gain and for the bridges, a set
where only some products carry the step puts a step of the correction's size at
the changeover. Stage 3 refuses it and names an offending epoch, and refuses
two different models or solutions in one set. That is why `run_trend.py` re-runs
stage 2 over the whole set with `--force` rather than topping up.

### Which steps need a human

Four, and they are the ones where the archive or the code cannot know the answer:

1. **`--default-decon-cycle` in step 1.** A decon cycle is operational knowledge
   the archive does not carry, and a wrong label propagates into every digest and
   silently joins two film-growth epochs that should not be joined.
   `make_manifest.py` lists which passes took the default -- check those against
   the decon schedule, or against the MPA temperature, which tops each
   decon's cooldown near 124 K. Every label is now checked that way, and
   the checks are recorded in [MANIFEST.md](MANIFEST.md); the 10 CAR-190 passes
   that took `decon2` by default on 2026-10-03 were confirmed on 2026-10-09.
   The labels define the film-growth *episodes* the digests record
   (`decon_episode_bounds`, `decon_time_hours`); the response is gauged globally
   rather than per episode, for the reasons in
   [PER_DECON_NORM.md](PER_DECON_NORM.md).
2. **`--default-mce-side` in step 1, and the manifest's `mce_side` column.**
   Nothing in the L2 metadata or the flight filename states the side, and the
   `_MCEA`/`_MCEB` marker that TVAC and SCIPA filenames carry does not exist on
   flight products. Every pre-2026-10-06 product records
   `mce_side_source='assumed:flight-side-A'`, which was right, but flight
   swapped to side B between CAR-190 plan-3 passes 57 and 71. A blank side on a
   later pass is now a mislabel. It would put the epoch on the wrong side of the
   side bridge (a chromatic step of up to 11 %) and gauge it to the wrong
   photodiode. The column's value is forwarded as `--mce-side`, which records
   `mce_side_source='cli'`: an operator assertion rather than telemetry.
   `batch/side_witness.py` checks it against the LED map and the photodiode
   witnesses, and `batch/refresh.py probe` proposes it -- see
   [DATA_PULL.md](DATA_PULL.md). The run log counts epochs by
   source for exactly this reason.
3. **Step 3's coverage inspection.** Whether to stream a partially-indexed pass
   now or wait for MAST is a judgement about schedule, not about data.
4. **Step 8, the run log.** It is the one artifact that states what the digest
   numbers are conditioned on: ACM moves and whether each step across them was
   *measured* (`bridge`) or *modelled* (`multiplier`), side provenance, refused
   photodiode readings, decon transitions, coverage. A `multiplier` step read as a
   measurement is a model mistaken for data.

### The nine figures to look at first

Everything else is per-SCA detail. These nine are the ones that answer "should I
trust this run at all", in the order worth reading them. The last is conditional --
it exists only if a temperature-gain model was ingested at step 9b. The paths
are relative to the trend tree, `$ROOT`, where `run_trend.py` writes them since
2026-10-12 (before that, the repo):

| figure | written by | the question it settles |
|---|---|---|
| `digest_plots/calibration_timeline.png` | step 7 | Were all these epochs calibrated the same way by the L2 pipeline, and if not, when did it change? A change here is upstream of every correction below, so read it first. Two bands: the audited grouping from `l2_calibration_audit.ecsv` (keyed on the *equivalence class*, so two CRDS contexts that resolve to identical reference files are one band), and what the products themselves record -- the hatching in the lower band is the extent to which the claim rests on a later query rather than on the products. |
| `plots/calibration/pd_trend_summary.png` | step 6b, **its own entry point** | The summary of the photodiode correction: `pd_net` per LED over its own median, the factor `reference_pd / pd_net` each epoch receives against a unity line, and `pd_valid_n`. A refused LED shows as a **gap**, not as a factor. Written by `calibrate_rcs_products.py --plot-pd-trend` and *not* by `calibration_plots.write_all`, so it is the one figure of the four that a `write_all` run alone does not refresh. Full chain in [PD_CORRECTION.md](PD_CORRECTION.md). |
| `plots/calibration/calibration_coverage.png` | step 6b | Is every epoch complete (18 SCAs), and is any `pd_net` near the `PD_MIN_NET` floor where it becomes a runaway denominator? The bottom band shows the run's ACM/decon structure. |
| `plots/calibration/calibration_factors.png` | step 6b | What did stage 2 multiply in, decomposed into photodiode / side / ACM? Each panel states whether that factor is achromatic; the PD one should *not* be. |
| `plots/calibration/pd_pedestal.png` | step 6b | Is the pedestal -- the subtrahend in `pd_net = pd_raw - pedestal`, and so under every photodiode factor -- sound? Which source each epoch used, whether a scalar describes it, and the differential test of whether an excursion was a real baseline shift or a bad off-window. |
| `digest_plots/run_structure.png` | step 7 | Why each ACM boundary was measured or modelled, quoting the fitter's own refusal reason, plus the closure test and **how much of a test it is** -- a closure composed partly of modelled steps cannot fail on those steps. |
| `digest_plots/decon_evidence.png` | step 7 | Are the `decon_cycle` labels the bridge now **refuses to fit across** confirmed by the data? A film reset is chromatic, an ACM move is not, so the spread across the six LEDs separates them. |
| `digest_plots/bridge_sensitivity*.png` | step 7 | Does the step survive the choice of fit window and polynomial degree, or is it model-limited? |
| `digest_plots/time_series_LEDx_all_scas_tgcorr.png` | step 9c, **only if a gain model was ingested** | How much of the trend is temperature gain rather than film? Drawn on **identical axes** to `time_series_LEDx_all_scas.png` so the two files can be *blinked* -- flipped between in one image viewer -- which is how a ~1 % change on 18 overlaid curves actually becomes visible. Same figure size, same colorbar, same y-limits by construction; the title and the footnote are the only intended differences. The footnote states the size of what was removed and that the gain is **recorded in the h5 products and not applied to them**. The delivered figure is written alongside it, never in place of it. |

Measured on the 176-epoch set as of 2026-10-04: 0 short products, 0 refused
photodiode epochs, worst total stage-2 correction 1.83 %, ACM piston factor
unity to 2e-6, and closure 0.067 %.

`decon_evidence.png` is the one that changed a standing open item into a
measurement. Ten CAR-190 passes (plan 2: 43-46, plan 3: 47-52) took `decon2` by
default rather than from a record, and the bridge guard made that default
load-bearing. The figure reports the one labelled transition at **6.1x** the
growth expected for its gap, standing **1.8x** clear of the detection floor, with
no unlabelled step anywhere near it -- a decon 54 % as strong would still have
been caught, and across passes 44-52 a decon-sized reset would have read 9-23x
louder than what is there. It also prints its own blind spot every time: at the
run's sparsest step (38.4 h) a chromatic reset below 0.029 would hide, against
0.054 for the loudest step actually seen. On a sparse set it says
`UNDERPOWERED` or `uncalibrated` instead of reporting a clean sheet, because a
test that cannot recover its own calibrator has nothing to say about the rest.
The bottom panel's control is the three ACM moves: all three land on the
achromatic axis (chromatic 0.0007-0.002) while spanning achromatic -0.035 to
+0.009, which is the figure's premise holding on data known to be geometric.

`pd_pedestal.png` exists because the pedestal is the one photodiode error that
leaves no trace anywhere else: it shifts all six LEDs by the same number of
volts, which is very nearly a common factor, and a common factor cancels in
every LED ratio downstream. The run turns out to contain a real test of it. The
pedestal is not a slow drift but a two-level affair -- passes 2-11 sit 299 uV
below everything after them -- and at that step `pd_raw` moves *with* the
pedestal, leaving only 17 uV in `pd_net` against a 16 uV resolution set by the
lamp's own per-epoch drift. So the diode's baseline genuinely moved and the
subtraction removed it; had the off-window been bad instead, the pedestal would
have moved alone and `pd_net` would have absorbed the whole 299 uV. That
distinction is the figure's second panel, and it has to be differential: the
lamp drifts ~2500 uV across the run, so on an absolute scale the pedestal's
entire 324 uV range is a flat line.

Two numbers from it are worth carrying into any reading of the photodiode
factor. The pedestal's range is 61 % and 67 % of the *whole* run-long `pd_net`
range of LED2 and LED3, so for those two the "lamp drift" the PD correction
removes is substantially pedestal -- while for LED4 it is 7 %, and LED4's drift
is real. And a common pedestal shift of that size induces a chromatic spread of
only 8.4e-5 across the LEDs, a tenth of even the quietest ACM control in
`decon_evidence.png`, so a pedestal error cannot imitate a decon. Separately,
the worst *within*-epoch pedestal drift is 293 uV across an epoch span (0.121 %
of `pd_net`, flagged on pass 51), which is the error a single scalar pedestal
leaves behind and the one place that approximation is visibly strained.

Two results in `calibration_factors.png` are worth knowing before reading a
trend. The photodiode factor splits into two chromatic families by sign -- LED1-3
rise by **0.1-0.5 %** while LED4-6 fall by **0.6-1.8 %**, a 2.2 % maximum
across-LED divergence -- so a response change common to all six LEDs is *not* what
the PD correction removes. Quote the per-LED range rather than a single number:
"LED1-3 rise to ~1.004" is true only of LED1 (1.00487), while LED2 and LED3 reach
only ~1.0015, and the ~0.982 extreme is LED4's alone (LED5 0.9871, LED6 0.9944).
And the decon transition does not reset that drift: LED4 and LED6 keep falling
through it to a minimum ~75 h later. That is the lamp, not the film, which is why
the decon guard is on the *bridge* and not on the photodiode correction. The full
acquisition-to-application chain is in [PD_CORRECTION.md](PD_CORRECTION.md).

### Smaller jobs

```bash
# one new pass by hand (batch/refresh.py pull prints these with the right flags)
.venv/bin/python process_rcs_trending.py --blank-dark --pass 22 \
    --decon-cycle decon2 --staging-root "$ROOT/stage" --out-dir "$ROOT/h5"

# re-calibrate one epoch against the existing card and bridge solution
.venv/bin/python calibrate_rcs_products.py --card "$ROOT/rcs_reference_card.ecsv" \
    --bridge-solution "$ROOT/rcs_bridge_solution.ecsv" \
    --in "$ROOT/h5/CAR190_01039_02_036_001_20260922_raw.h5" --out-dir "$ROOT/cal"

# look at what any calibrated product records, including every bridge step
.venv/bin/python rcs_trend_reader.py summary "$ROOT/cal/CAR190_01039_03_071_001_20261006_cal.h5"
.venv/bin/python rcs_trend_reader.py bridges "$ROOT/cal/CAR190_01039_03_071_001_20261006_cal.h5"

# the products are self-contained: rebuild every digest column and data-bearing
# meta key from them alone and diff against the digests (run_trend.py does this
# every run, and fails above 1e-9)
.venv/bin/python rcs_trend_reader.py compare "$ROOT/cal" "$ROOT/digests/digests_v4_<mm_dd_yy>"

# photodiode only: no imagery streamed, seconds per pass. ECSV + PNG land in
# <out-dir>/pd unless --pd-dir says otherwise.
.venv/bin/python process_rcs_trending.py --blank-dark --pass 36 \
    --decon-cycle decon2 --pd-only --pd-plot --out-dir "$ROOT"

# the legacy regression. Must print: worst response deviation 0.000e+00
.venv/bin/python make_sca_digests.py --data-root /data/eswitzer/rcs_trend \
    --stage legacy --assume-side A \
    --acm-move-min-delta 5000 --acm-require-sign-change \
    --compare-dir digests_9_29_26 --out-dir /tmp/regress --no-plots --quiet
```

### Knobs the sbatch scripts read from the environment

Both submissions take the same six positional arguments -- `<repo_root>
<manifest.csv> <token_file> <staging_root> <out_dir> [n_tasks]` -- and
`submit_manifest.sbatch` takes a 7th, `query_delay_seconds`. Everything else
arrives as an exported variable, so a tuning change is a submission change
rather than a file edit:

| variable | default | what it does |
|---|---|---|
| `USE_PLAN=1` | unset | stream from cached plans, issuing no listing calls. The recommended mode for rung 2; not the default only because it needs rung 1 first |
| `MIN_SCAS` | 18 | detectors required for a pass to count as complete. Screens the plan *before* streaming, and screens existing products when deciding whether to skip a row |
| `QUERY_LEASES` | 4 | concurrent MAST *listing* calls across all ranks sharing `STAGING_ROOT`. A second cap underneath `--ntasks-per-node`, and the one that holds when submissions overlap |
| `BIN_FACTOR` | 16 | superpixel bin for the per-SCA product. Must divide 4096 -- checked at parse time, before any pull. **Do not mix bin factors in one `OUT_DIR`**: per-SCA medians differ at 0.1 %, the size of the signal, and the digests assert a single value across the set |
| `AUX_L2_DIR` | unset | directory of a local L2 reprocessing that **supersedes MAST** for any pass it covers completely. See "Rebuilding passes from a local L2 reprocessing" below |
| `FORCE=1` | unset | rebuild every row in scope, ignoring existing products |

`submit_plan.sbatch` clears `USE_PLAN`, `BIN_FACTOR` and `FORCE`, and
`submit_manifest.sbatch` clears `PLAN_ONLY`, so a variable exported for one
submission cannot silently change what the other one does.

Bin 16, not the legacy 20, because `4096/20 = 204.8`: at r=20 every SCA block is
a ragged 204 or 205 pixels and superpixels straddle SCA edges and inter-SCA gaps
at the ~0.1 % level. At r=16 all 18 blocks are exactly 256x256 and in bounds, so
no superpixel straddles anything and footprint masks are not needed at all.

### Rebuilding passes from a local L2 reprocessing

MAST serves whatever each exposure was calibrated with *at the time it was
processed*, so re-pulling a pass cannot change its calibration -- only a
reprocessing can. When part of the archive has been reprocessed and part has
not, `--aux-l2-dir` lets a local L2 tree stand in for MAST:

```bash
# one pass by hand
.venv/bin/python process_rcs_trending.py \
    --program 1039 --execution-plan 2 --pass 1 --decon-cycle decon1 \
    --blank-dark --use-plan --force \
    --staging-root /data/eswitzer/rcs_trend_v3/stage \
    --out-dir /data/eswitzer/rcs_trend_v3/h5 \
    --aux-l2-dir /mnt/roman-s3-romcom/activities/CAR190

# what the aux tree covers, before committing to anything. Seconds; reads the
# directory listing only, never opens a file.
.venv/bin/python process_rcs_trending.py \
    --aux-inventory --aux-l2-dir /mnt/roman-s3-romcom/activities/CAR190
```

Three rules, and the middle one is the important one:

1. **A pass the aux tree covers completely is built entirely from it**, and the
   MAST handle is never opened -- so a covered pass can be rebuilt from a cached
   plan with no token and no archive access.
2. **A pass it covers only partly is refused**, with exit status 3
   (`degraded`), naming the missing frames. Half a pass on one flux calibration
   and half on another would put two per-SCA scales *inside one epoch* -- worse
   than the between-epoch step the override exists to cure, and invisible
   downstream, because nothing in the product would record it.
3. **A pass it does not touch comes from MAST as usual.** The decision is per
   pass, logged in a banner that cannot be switched off, and recorded in the
   product's root attributes (`l2_source`, `l2_source_dir`, `crds_context`,
   `cal_step_photom`, `ref_file_id`, `l2_provenance_frame`).

Running the whole covered range directly on a compute node -- this is exactly
the call `srun` would make, so there is no need to go through SLURM for 35
passes:

```bash
cd activities/car-190-rcs-spectro-trending
set -a; . ../../variables.env >/dev/null 2>&1; set +a   # EDP still needs the token
export AUX_L2_DIR=/mnt/roman-s3-romcom/activities/CAR190

# manifest restricted to the covered range (CAR-190 plan 2, passes 1-37)
head -1 batch/run_manifest.csv > batch/run_manifest_aux.csv
awk -F, 'NR==1{next} $1+0==1039 && $2+0==2 && $3+0<=37' \
    batch/run_manifest.csv >> batch/run_manifest_aux.csv

# seed the output directory from the existing set so the uncovered passes are
# kept, then rebuild only the covered ones in place
mkdir -p /data/eswitzer/rcs_trend_v3/{stage,h5}
cp -r /data/eswitzer/rcs_trend_v2/stage/plans /data/eswitzer/rcs_trend_v3/stage/
cp -a /data/eswitzer/rcs_trend_v2/h5/. /data/eswitzer/rcs_trend_v3/h5/

for r in 0 1 2 3 4 5 6 7; do
  .venv/bin/python batch/run_manifest_worker.py \
      --manifest batch/run_manifest_aux.csv --n-tasks -1 \
      --rank $r --world-size 8 \
      --staging-root /data/eswitzer/rcs_trend_v3/stage \
      --out-dir /data/eswitzer/rcs_trend_v3/h5 \
      --use-plan --force --aux-l2-dir "$AUX_L2_DIR" \
      > batch/logs_aux/rank$r.out 2>&1 &
done; wait
```

Measured: 35 passes in ~45 min at 8-way, reading ~790 GB off the mount.
Single-threaded one pass reads 22.5 GB at 132 MB/s (~3.5 min) -- faster than
MAST's 44 MB/s, so `QUERY_DELAY_SECONDS` is skipped automatically on the aux
path; it exists to space out listing calls and there are none.

For a SLURM run instead, export `AUX_L2_DIR` before `sbatch` and it is
forwarded through `worker_entrypoint.sh` to every rank.

#### Why this was needed here, and what it cures

The Roman reprocessing of 2026-09-24 (cal 1.0.1 -> 1.0.2, `photom` reference
0040 -> 0080) changed the per-SCA flux scale by **-2.28 % to +3.08 %, 1.787 %
rms**. Only CAR-190 pass 1 was reprocessed on MAST as a trial, which is what
made the step visible: pass 1 is served under `roman_0072.pmap` while passes
2-34 are still served under the older `roman_0061/0065/0066/0067`. The result
is a step at pass 1|2 (1.22 % rms) and another at the `0067`->`0072` changeover
(1.51 % rms), the second landing one epoch after an ACM move and exactly at a
decon label change -- which is why it read as physics.

It is a *flux calibration* change, not a film reset, and the discriminator is
chromaticity: the across-LED spread is 0.028 % against a 1.787 % per-SCA
amplitude, i.e. 64:1 achromatic. A film reset is chromatic, because each LED
sits at a different point on the fringe. That is also why decon *detection*
survives the contamination untouched while the decon step *magnitude* does not.

The aux tree at `/mnt/roman-s3-romcom/activities/CAR190` skips `photom` and
`flat_field` outright. Verified on pass 1, the one pass that exists both ways:
the pixel ratio aux/MAST has median `1.00000000` with 99.98 % of 16.7 M
illuminated pixels agreeing to better than 1e-6, and through the full pipeline
the per-SCA medians agree to **0.0007 % rms, 0.003 % worst**. So `photom` in
`roman_0072` is a no-op, skipping it is equivalent to applying it, and
rebuilding passes 1-37 from the aux tree leaves no step at the pass 37|38
handover to the un-reprocessed-but-current MAST epochs.

#### The flat field: skipped on *both* sides, and measured to be

Skipping `flat_field` sounds more alarming than skipping `photom`, since a flat
is a per-pixel map rather than a scalar per LED, and the trend divides
MAST-sourced epochs by an aux-sourced t=0 reference. It is not an aux
peculiarity: **neither source applies a flat field.** Both classes report
`cal_step_flat_field = SKIPPED` with `ref_file.flat = INCOMPLETE` -- the WFI flat
reference is not delivered in CRDS at all, so there is nothing for either
pipeline to apply.

The metadata is enough to say that, and `ref_file_id` is what pins it: the hash
covers the `ref_file` branch minus `crds`, and `ref_file.flat` is on that
branch, so a class's flat state is fixed by its id being what it is. That is
also why the audit ECSV has no `cal_step_flat_field` column -- it would be a
derived value a reader could not distinguish from a read one. The finding is
recorded in the file's `meta["flat_field_finding"]` instead, written by
`scripts/annotate_l2_audit_meta.py`.

Checked against the pixels independently of the metadata, on pass 1, the one
pass available both ways. A flat is multiplicative per pixel, so a differential
one cannot hide in a pixel ratio: over **46 M usable pixels across SCA 1, 9 and
18** the aux/MAST ratio has median `1.00000000`, rms `0.0000 %`, **100.000 %
within 1e-6**, and 64x64 block-median rms `0.0000 %` -- the block statistic being
the one a smooth low-spatial-frequency flat would show up in. So no per-pixel
correction of any kind differs between the two sources, and dividing MAST epochs
by the aux reference epoch is sound.

(The 99.98 % of 16.7 M quoted above and the 100.000 % of 46 M here are the same
pixel ratio under different masks -- one detector's worth of illuminated pixels
versus all finite, unflagged pixels on SCA 1, 9 and 18. Neither leaves a
residual; the looser figure is the tighter mask, not a disagreement.)

This is also what removed the *calibration* motivation for normalizing the
response per decon cycle; the residual motivation is physical, and is a view a
user can construct in post-processing. The decision, the recipe, and what a
pipeline mode would cost are recorded in
[PER_DECON_NORM.md](PER_DECON_NORM.md).

That equivalence is recorded -- with the measurement -- in
`rcs_trend_config.CALIBRATION_EQUIVALENCE`, and
`make_sca_digests.assert_homogeneous_calibration` refuses a digest set that
spans two classes unless `--allow-mixed-calibration` is passed. An unmeasured
`ref_file_id` is its own class, so a new calibration trips the guard rather
than passing silently; to clear it, divide one configuration's pixels by the
other's and add it to the table with the number. The bands are drawn in
`digest_plots/run_structure.png` alongside the ACM segments and decon episodes, with a
heavy rule at each class change.

Aux coverage as of 2026-10-05: CAR-190 plan 2 passes 1-37, except pass 12
(does not exist) and pass 25 (a genuinely short 5-observation sequence, missing
observation 7, absent from the MAST-built set too). That is all 34 old-family
epochs plus pass 1, with nothing left behind.

Measured after the rebuild, v2 (mixed) against v3 (homogeneous), per-SCA
achromatic shape across each boundary:

| boundary | v2 | v3 | note |
|---|---|---|---|
| pass 1\|2 | 1.217 % rms | **0.040 %** rms | 31x down; the v2 shape correlates -0.9995 with the measured `photom` vector |
| CAR-190 pass 37 \| CAR-216 pass 1 | 1.510 % rms | **0.510 %** rms | projection onto the `photom` shape falls 6.1 % -> 0.96 % |
| CAR-216 \| CAR-190 pass 38 | 0.006 % rms | 0.006 % rms | both sides were already current; unchanged, as it must be |

What did *not* move is as informative. Bridge factors shift by 0.009 % rms at
boundary 1 and are identical to five decimals at boundaries 2 and 3; the ACM
closure reads 0.067 % either way, and decon detection holds at 1.8x the noise
floor. The reason is structural: a bridge step is fitted from epochs on *both*
sides of an ACM boundary, so a calibration family that spans the boundary
cancels in the ratio, and the one boundary that did coincide with a family edge
(boundary 2) took the LVDT multiplier fallback, which reads no pixels at all.
The contamination could only ever have entered through a statistic that
compares epochs *across* a family edge -- which is exactly the decon step
magnitude, and that is the one that moved. The 0.510 % still standing at the
CAR-190|CAR-216 boundary is **not** calibration: that boundary is also ACM
boundary 2 (scalar multiplier, so per-SCA structure is expected to survive it)
and the decon1->decon2 reset, whose 5.5 % across-LED spread is chromatic and
therefore real.

#### `roman_0073`, and a bug in `ref_file_id` that it exposed

Auditing the epochs whose products predate `rcs_l2_source` turned up a third
context, `roman_0073.pmap`, on CAR-190 plan 3 passes 51-52 (from 2026-10-02).
It is benign, and the check is not a pixel measurement but a field-by-field
diff of the `ref_file` branch: `roman_0072` and `roman_0073` resolve to
**byte-identically the same 17 reference files**, `photom_0080` included. Only
the context string moved.

That tripped the guard anyway, because `ref_file_id` was hashing the whole
`ref_file` branch -- including the `crds` sub-dict holding the context. So a
pure relabelling read as a new calibration: the precise failure the hash exists
to prevent, in mirror image. `read_provenance` now excludes `crds` from the
hash and records the context separately, which is the right split, since the
context is **neither sufficient** (aux reports `roman_0067` while being
calibrated differently from MAST's `roman_0067`) **nor necessary** (`0072` and
`0073` differ in context and not in calibration). Two self-tests in
`rcs_l2_source.py` pin both directions.

Ids changed as a result, so `CALIBRATION_EQUIVALENCE` carries the three
superseded-hash values as aliases -- products written before 2026-10-05 hold
them, and a hash-definition change with no physical content must not trip a
guard about physics.

`l2_calibration_audit.ecsv` is the exhaustive result: one streamed L2 frame per
epoch for all 141 products that record nothing, filenames taken from the cached
query plans so it costs no listing calls. **All 176 epochs are one equivalence
class** -- 139 at `roman_0072`, 2 at `roman_0073`, 35 aux. The audit is
read-only; it does not write into any product, so `assert_homogeneous_calibration`
still warns that 141 epochs record nothing, and the ECSV rather than the
product attrs is the evidence. Note the caveat recorded in its `meta`: a
streamed frame describes the file MAST serves *now*, which is the file the
product was built from only if nothing was reprocessed in between.

#### `roman_0075`: one reference file changed, measured on the trend

CAR-190 plan 3 pass 75 and CAR-216 plan 4 (from 2026-10-09) came from MAST at
`roman_0075.pmap`, `ref_file_id` `5c871b249e2f6eaf`. Unlike `0073`, this one
is a new id, and stage 3 refused the 188-epoch set until it was measured.
Diffing the `ref_file` branch of the SCA01 provenance frame of passes 74 and 75
showed one change, **distortion 0027 -> 0053**. The other 16 files
(`photom_0080` included) and the whole `cal_step` branch are identical.
Distortion feeds `assign_wcs`, which attaches a WCS and does not touch the
data.

No exposure exists under both contexts: MAST still serves pass 74 at
`roman_0074`. So the measurement is on the trend instead. Each (SCA, LED) is
fitted over the seven B-side epochs with a step at 74|75, and the step's
per-SCA achromatic part (the old family's signature) is 0.0151 % rms for a
linear trend and 0.0085 % for a quadratic one. Null splits where nothing
changed read 0.0098-0.0169 % and 0.0040-0.0092 %. That is at the noise
floor, and more than 100x below the old family's 1.787 %. It is mapped to
`unity-photom`, with the numbers, in `CALIBRATION_EQUIVALENCE`. When MAST next
reprocesses an old pass at `0075`, the pixel-ratio test of `0072` becomes
possible and should replace this one.

`roman_0076` (CAR-216 p4 pass 4 on, 2026-10-10, `2dd418ec414b1196`) followed
the same path: distortion 0053 -> 0061 and nothing else. A quadratic over the
twelve B-side epochs puts a 0.0037 % per-SCA achromatic step at p4 3|4, against
0.0042-0.0074 % for null splits.

#### Keeping files ASCII: `ascii_tidy.py`

The repository rule is ASCII-only code and markdown, applied to a file when it
is worked on. `ascii_tidy.py check FILE...` reports non-ASCII characters (exit 1
if any), `fix FILE... [--dry-run]` rewrites the ones with an agreed spelling
(`-`, `--`, `->`, `+/-`, `x`, `deg`, `u` for micro, Greek spelled out, and
superscript runs as `^-4`), and leaves the rest in place with their line
numbers. `--git-changed` takes the modified and untracked `.py`/`.md` files from
a read-only `git status`. In a `.py` file `fix` names the lines it touched:
read them, since a non-ASCII character can be data, and run the module's
self-test. `table` prints the replacements.

#### Checking any change between passes: `trend_change_check.py`

The 0075 and 0076 checks, the pass-13 outlier and the enclosure and ACM
timings were all done with one tool. Every subcommand ends with a **Next:**
line, like `refresh.py`. `refdiff` and the two EDP subcommands need the token
(`set -a; . ../../variables.env >/dev/null 2>&1; set +a`). `steptest` and
`outliers` are local and read `$ROOT/cal`.

| subcommand | question | how |
|---|---|---|
| `refdiff A B [C...]` | which reference files moved? | streams the provenance frame each product recorded (`l2_provenance_frame`) and diffs `ref_file` and `cal_step` against the first pass; reports each id's equivalence class, and flags a pass MAST has reprocessed since staging (recorded id != served id: the pixel-ratio test is then possible) |
| `steptest --first --last [--at]` | does the trend step there? | per-(SCA, LED) polynomial plus a step, degrees 1 and 2; prints every split's per-SCA achromatic rms and focal-plane step, and the verdict against the null splits. Without `--at` it tests the window's one `ref_file_id` change. Refuses a window across a decon |
| `outliers --first --last [--exclude]` | is one epoch off? | leave-one-out residual from a quadratic through up to 3 neighbours a side, flagged above 3x the median; exclude a found outlier so it does not shadow its neighbours |
| `telemetry NAME... --start --end` | when did a mnemonic change? | medians on a grid plus step episodes (threshold 10x each series' own jitter; `--dropout 0` for the LVDT) |
| `mnemonics PATTERN...` | what is it called? | EDP dictionary substring search |

```bash
.venv/bin/python trend_change_check.py refdiff CAR216_01063_04_003 CAR216_01063_04_004
.venv/bin/python trend_change_check.py steptest --first CAR190_01039_03_071 --last CAR216_01063_04_007 --at CAR216_01063_04_004
.venv/bin/python trend_change_check.py outliers --first CAR190_01039_02_001 \
    --last CAR190_01039_02_015 --exclude CAR190_01039_02_013
.venv/bin/python trend_change_check.py telemetry WFI_MCE_HTR_SETPOINT_06 \
    WFI_MCE_LVDT_ACM_1 --start 2026-10-06T00:00 --end 2026-10-10T12:00 --dropout 0
```

The pieces are importable on their own:
- `rcs_l2_source.calibration_branches`, `diff_calibrations`, `provenance_frame`
  and `ref_file_id_of` for the L2 side;
- `rcs_step_tests.step_test`, `leave_one_out`, `load_window` and
  `window_problems` for the statistics. These take `(n_epoch, 6, 18)` log
  responses from anywhere;
- `rcs_edp.edp_series` and `find_steps` for telemetry.

The statistics are computed from the reader's `RcsTrend.series`, the digests'
reduction (the median of each SCA's pixel ratio to the first epoch). Their
self-tests run in `process_rcs_trending.py --self-test`.

#### Why the ECSV is the record, and what the other two options were

There were three ways to close the gap left by 141 products that record no L2
provenance. **Option 1 was taken.** The other two are written out here because
the choice is not obvious from the outcome, and because the reasons the
alternatives were declined are reasons that would still apply to re-opening
them.

**Option 1 -- keep the audit as a separate record (taken).**
*Cost:* nil; already built. One streamed frame per uncovered epoch, filenames
from the cached query plans, so no listing calls.
*Buys:* a complete per-epoch account of how all 176 epochs were calibrated, a
guard that can refuse on it, and `digest_plots/calibration_timeline.png`, which
draws the audited grouping and the product-recorded one as two bands so the gap
between them is visible rather than asserted.
*Risks:* `assert_homogeneous_calibration` goes on warning that 141 epochs record
nothing, and **that warning is correct** -- those products still cannot be
checked standalone, and the warning is the thing that would make someone look
for this section. And the audit's MAST rows describe what the archive serves
*now*; that caveat is in the file's `meta` and on the figure's footnote.

```bash
# the record as it stands, plus its flat-field annotation
.venv/bin/python scripts/annotate_l2_audit_meta.py --check
```

**Option 2 -- backfill the attrs into the products (declined).**
*Cost:* a new writer, and it must amend both the 141 `_cal.h5` *and* their
`_raw.h5` parents, or `calibrated_from_sha256` describes a file whose attrs no
longer match it.
*Buys:* the guard stops warning and the hatched band disappears; the products
become self-describing.
*Risk, the one that decided it:* it writes a later query's answer into a product
**as if it were contemporaneous**, with no attr able to say otherwise. That
destroys the `provenance_from = product | streamed` distinction in the one
direction that cannot be undone, and does it to the evidence itself. The
hatching in the lower band of `calibration_timeline.png` is not a blemish to be
removed -- it *is* the finding about what these products attest to.

**Option 3 -- re-stage those passes from MAST (declined).**
*Cost:* ~5 h of staging plus the whole ladder below, and it obsoletes the v3
reference card and the 176-product cal set.
*Buys:* the only genuinely contemporaneous record -- correct with no asterisk,
because the attrs would be read at the moment the product was written.
*Risk:* MAST serves what each exposure was calibrated with at processing time,
so a pass reprocessed since could come back *differently* calibrated. The
re-stage could create the inhomogeneity it was run to document, and there would
be no way to tell that from having found one. Hence: write to a new root, never
in place, so "did the calibration move?" is answerable by diff rather than by
recollection.

If ever run, it is the [batch ladder](#batch-processing-with-slurm) -- not a hand-run loop,
since it is 141 epochs across both CARs -- with every
`/data/eswitzer/rcs_trend_v2/...` path in it replaced by a **new** tree
(a fresh `--root`, never the deployed one), and `l2_calibration_audit.ecsv` kept as the
thing the new products' own attrs are then diffed against. A difference is the
answer, whichever way it comes out.

### Known constraint

`BridgeNoise.from_meta` raises `NotImplementedError` above 2 ACM segments: the
model carries **one** rank-one term, and several bridge steps are nested (step
*k* affects every later segment) so they are not orthogonal and need the
Woodbury form over a column matrix rather than Sherman-Morrison. It refuses
rather than modelling only the first step. The two downstream fits do **not**
behave the same way on a 4-segment digest set, and neither of them stops:

* **`fit_film_thickness.py` runs and reports no credible interval.** Its one
  call site catches the refusal (`fit_film_thickness.py:2214`) unless `--strict`
  is passed, prints `WARNING: no noise model for N SCA(s)`, and says those SCAs
  "report a best fit but no credible interval". So a thickness is still printed
  -- the error bar is what is missing, and the warning is the only thing that
  says so.
* **`fit_film_rank1.py` never builds a `BridgeNoise` at all**, so it is not
  refused and runs to completion. It has its own `_step_tau`, which takes the
  **max** over `bridge_step_errors` in quadrature with `bridge_systematic`, and
  it applies **one** achromatic nuisance step to every epoch after the *first*
  move (`TrendCube.post_move` is `acm_segment > min`). On this 3-move set that
  is one parameter standing in for three, so the step uncertainty is
  under-marginalized rather than rejected. Treat its interval as a lower bound
  until the Woodbury form lands.

Until it is extended, the digest set those fits consume is better built with
`--acm-move-min-delta 5000 --acm-require-sign-change`, which collapses the run
to 2 segments -- at the cost of an ACM correction extrapolated 86 % of the way
across a move. See
[DIGEST_TRENDS.md](DIGEST_TRENDS.md#acm-moves-and-the-bridge).

## When new data arrive

The procedure is **[DATA_PULL.md](DATA_PULL.md)**: seven steps, each one python
call that prints what it found and the command to run next, with what each
step prints, what to look for, and what to do when something is unusual. In
short:

```bash
cd ~/code/RST_commissioning/activities/car-190-rcs-spectro-trending
.venv/bin/python batch/refresh.py status     # 1. what is new
.venv/bin/python batch/refresh.py probe ...  # 2. the evidence for the labels
.venv/bin/python batch/refresh.py label ...  # 3. the labels (a person's decision)
.venv/bin/python batch/refresh.py pull --local 4   # 4. stage 1
.venv/bin/python batch/refresh.py check      # 5. did it work
.venv/bin/python run_trend.py                # 6. stages 2 and 3, in place
#                                              7. MANIFEST.md, and the commit
```

Everything reads and writes the shared trend tree, `rcs_trend_config.TREND_ROOT`
(`/mnt/smdc-rom-com-ops/rrn-ops/activities/car-190-rcs-spectro-trending/rcs_trend_v4`),
which is the deployment. DATA_PULL.md also covers stage 1 by hand and under
SLURM, the side swap, starting a new tree with `refresh.py seed`, and what can
be scheduled.

## Batch processing with SLURM

`batch/` runs many passes of `process_rcs_trending.py` in parallel across a
SLURM allocation, driven by a CSV manifest (`batch/run_manifest.csv`) rather
than by hand-editing scripts. Number of nodes and jobs-per-node are set at
submission time (`sbatch --nodes=... --ntasks-per-node=...`), not baked into
any file, and rows whose output product is already **complete** are skipped
automatically -- safe to resubmit after adding new rows or after a partial
failure. See [batch/README.md](batch/README.md) for how the
manifest/worker/status pieces fit together.

Complete, not merely present: the worker asks
`rcs_products.coverage_from_h5` how many of the 18 detectors are in an existing
product and skips the row only at `--min-scas` (default 18). A short one is
**moved** to `<out_dir>/degraded/` -- never deleted, since it is the record of
what the listing returned -- and the pass is rebuilt. The old check globbed for
the filename, under which a 2-SCA product written from a truncated listing
blocked its own retry forever.

Staging runs as a **two-rung ladder**: a narrow `--plan-only` sweep that
resolves MAST product names into cached plans, then a wider streaming pass that
reads those plans and issues no listing calls at all. The listing API -- one
request per matched dataset -- is what fails under concurrent load, not
bandwidth, so separating the two means the fragile step runs once per pass at
low concurrency. `rcs_trend_batch{,_run1}` were produced the old way, 32-way
and unplanned, and 79 of 91 of their products hold only 1-6 of 18 SCAs.

**1. Build the manifest from the archive**, not from the hand-maintained list:
```bash
cd activities/car-190-rcs-spectro-trending
.venv/bin/python batch/make_manifest.py --from-survey --dry-run \
    --default-decon-cycle decon2 --default-mce-side B   # diff only
.venv/bin/python batch/make_manifest.py --from-survey \
    --default-decon-cycle decon2 --default-mce-side B   # applies it
```
MANIFEST.md's *Current state* table says which passes that covers and why
any are absent. The tool lists which passes took the two defaults -- check
the decon cycle against the decon schedule and the side against
`batch/side_witness.py`, since both are operational knowledge the archive does
not carry and a wrong label propagates into every digest. A batch that
straddles a boundary takes the majority label here and `--relabel` for the rest;
the whole procedure is [DATA_PULL.md](DATA_PULL.md). `--init` still writes the old
hand-maintained list, but it lags the archive; prefer `--from-survey`.

**2. Local smoke test, no SLURM** (cheap check of auth/paths -- rank 0 of 1,
first 2 rows, planning only, so nothing downloads):
```bash
.venv/bin/python batch/run_manifest_worker.py \
    --manifest batch/run_manifest.csv --n-tasks 2 --rank 0 --world-size 1 \
    --plan-only \
    --staging-root "$ROOT/stage" --out-dir "$ROOT/h5"
```
Check `batch/logs/` and `batch/status/` for the two rows. Drop `--plan-only`
to let it stream for real.

**3. Rung 1 -- plan the whole manifest, 4-way.** No downloads; a few minutes.
```bash
sbatch --partition=cpu-lg --nodes=1 --ntasks-per-node=4 batch/submit_plan.sbatch \
    "$(pwd)" batch/run_manifest.csv ../../variables.env \
    "$ROOT/stage" "$ROOT/h5" -1
squeue -u "$USER"
```
The token file is the same `variables.env`-style file described in
[Token setup](#token-setup) (`MAST_API_TOKEN='...'`). Do not widen this past
4-way: it is the rung that touches the API that fails under load.

**4. Inspect coverage before committing to any download**:
```bash
ls batch/status/*.planned | wc -l            # plans cached (not products!)
ls batch/status/*.degraded | wc -l           # plans MAST has not filled yet
ls batch/status/*.failed | wc -l             # ~0 on a surveyed manifest

# and by how much. A status file is named <row>.<outcome> and its contents are
# just the detail string, so the row identity is in the name, not the body.
for f in batch/status/*.degraded; do
    printf '%-34s %s\n' "$(basename "$f" .degraded)" "$(cat "$f")"
done
```
A `degraded` row means its plan did not cover 18 SCAs on every lit activity;
nothing was streamed and no product was written, so it is a cheap retry later
rather than a 3.75 GB download that then blocks its own retry.

**5. Rung 2 -- stream, 8-way, from the cached plans**:
```bash
USE_PLAN=1 sbatch --partition=cpu-lg --nodes=1 --ntasks-per-node=8 \
    batch/submit_manifest.sbatch \
    "$(pwd)" batch/run_manifest.csv ../../variables.env \
    "$ROOT/stage" "$ROOT/h5" -1
```
**8-way, not the 32-way this step used to recommend.** Measured 2026-10-04 (job
8889): **1.92 min/pass wall-clock at 8-way**, so a 177-pass manifest takes about
**5.7 h**. `submit_manifest.sbatch` asks for 8 h for that reason -- it asked for 4
until that run was cancelled by the time limit with 59 rows untouched. If you
change `--ntasks-per-node`, re-check `#SBATCH --time` against
`rows * 2 min / ntasks`. `USE_PLAN=1` makes this rung issue no listing calls
whatsoever. If MAST still throttles the streaming, add a 7th positional arg to
raise the per-file delay (default 1s -- see
[batch/README.md](batch/README.md#throttling-mast)), e.g. `... -1 3` for 3s.

**A cancelled or failed rung 2 is resumable, not restartable.** Resubmit the
identical command: the coverage-aware skip rebuilds only rows whose product is
missing or short, so the 118 products already on disk are skipped in seconds.
Nothing needs cleaning up first, and rung 1 does not need re-running -- the
cached plans are still there.

**6. Check results / retry failures**:
```bash
ls batch/status/*.done | wc -l
ls batch/status/*.degraded       # incomplete plans; replan these later
ls batch/status/*.failed
cat batch/status/<stem>.failed   # returncode + stderr tail
cat batch/logs/<stem>.log        # full stdout+stderr for that row
.venv/bin/python batch/triage_products.py "$ROOT/h5"
```
`refresh.py check` prints the outcome of every row of the last `pull` and then
runs the triage, so it covers this list for a routine intake.
Just re-run step 5's command after fixing an issue -- the only thing gating a
rerun is whether `--out-dir` holds a product covering `--min-scas` detectors;
`batch/status/` and `batch/logs/` are bookkeeping, not inputs to that check, so
a `.failed` row reruns automatically, and so does a row whose product turned out
short. `triage_products.py` screens an existing directory on the same
`coverage_from_h5` the worker uses, so a product it calls degraded is exactly
one the worker will rebuild; `--move-degraded --apply` relocates them up front
instead of one at a time. Details in [batch/README.md](batch/README.md).

**7. Stages 2 and 3 -- `run_trend.py`. No SLURM, no network, ~2 minutes (~30 with
`--fit-tempgain`)**:
```bash
.venv/bin/python run_trend.py --dry-run     # the seven steps, commands only
.venv/bin/python run_trend.py               # run them over rcs_trend_config.TREND_ROOT
```
(`batch/run_calibration.sh` still runs the card and one stage-2 pass, without the
bridges; prefer `run_trend.py`.) The card comes first, and the order is the design. `--make-card` is the **only**
step that sees the entire set: metadata-only at ~0.1 s/file, it picks the
reference epoch, records that epoch's `pd_net` per LED, segments the run by ACM
LVDT and writes each segment's reference LVDT. Calibration is then strictly
per-file, because every number it needs is in the card -- which is a committed
ECSV artifact, so a calibration is reproducible from a file rather than from
whatever happened to be in the directory that day. That is also why this rung
is not an sbatch script: 33 MB in, 33 MB out, 1-2 s/file, no remote API to be
polite to, so a SLURM fan-out would queue longer than it computes.

The cross-epoch bridges (ACM moves, and the MCE side swap) are fitted at
stage 3, not stage 2. A bridge step comes from the epochs either side of a
boundary, so it is not a property of any one epoch, and a per-file stage cannot
see it. `run_trend.py` therefore runs stage 2 twice:
1. the first pass records the per-file steps (photodiode, linear ACM);
2. the digests fit the bridges and write `rcs_bridge_solution.ecsv`;
3. the second pass records the bridges too, so every product carries every
   factor.

Nothing is ever applied to the pixels; `bridge_applied=False`,
`bridge_recorded=True`.

Then the stage-2 diagnostics, which are not optional in practice. `run_trend.py`
runs them as its step 7; by hand they are:
```bash
.venv/bin/python -c "import calibration_plots as c; \
    c.write_all('$ROOT/cal', '$ROOT/plots/calibration')"
.venv/bin/python calibrate_rcs_products.py \
    --card "$ROOT/rcs_reference_card.ecsv" \
    --plot-pd-trend "$ROOT/plots/calibration"
.venv/bin/python plot_pd_sequence.py \
    --in "$ROOT/h5/pd/pd_*.h5" --out-dir "$ROOT/plots/pd_sequence"
.venv/bin/python housekeeping_trends.py \
    --cal-dir "$ROOT/cal" --out-dir "$ROOT/plots/housekeeping"

# the temperature-dependent gain, measured from the same housekeeping (~15 min;
# a free-standing analysis -- it writes nothing any other stage reads)
.venv/bin/python fit_temperature_gain.py --out-dir "$ROOT/plots/temperature_gain"
```
`calibration_factors.png` decomposes what was applied into photodiode / side /
ACM per LED, `calibration_coverage.png` puts SCA coverage and `pd_net` on the
run's ACM-and-decon structure, and `pd_pedestal.png` goes one level under the
photodiode factor to the pedestal it was formed from. All three read the
`calibration/` and `photodiode/` groups back out of the products rather than
recomputing, so they show what the products record, which is what every consumer
applies, rather than what should have been recorded. A schema-1 product
(`rcs_trend_v3/cal`) is read the same way. Note `write_all`'s first argument is a
directory of **calibrated** products, not a data root; pointed at a raw or legacy
directory it raises rather than drawing an empty figure.

The second command needs only the card (`pd_net` per LED per epoch lives in it),
so it reads no products and takes a second; passing `--in` as well would
recalibrate the whole set to draw one figure. It is a **separate** entry point
from `write_all`, so a `write_all` run alone leaves `pd_trend_summary.png` stale.
The third needs no network or credentials at all -- the full 1 Hz timestream is
embedded in every product and sidecar. See **The nine figures to look at first**
above, and [PD_CORRECTION.md](PD_CORRECTION.md) for the whole photodiode chain.

The fourth, `housekeeping_trends.py`, plots **every** float channel in the
products' own `housekeeping/` group over the trending period -- it *discovers*
the mnemonics rather than listing them, so a channel added upstream appears
without a code change, and a channel that is all-NaN is drawn and labelled
rather than dropped. `WFI_MCU_B_MPA_CSENS_FPSSEN_K` is all-NaN **by
construction**, not because the set was side A: stage 1 never queries it, and
its A twin is really `WFI_MCE_ADC_WTSM00` stored under the TVAC name
(`rcs_telemetry.FLIGHT_MNEMONIC_ALIASES`). It stays NaN after the swap, so do
not read it as a side witness. Like
`plot_pd_sequence.py` it needs no network: the housekeeping is embedded per
epoch. It also writes `housekeeping_trend.ecsv`, the long-format table every
downstream thermal analysis joins against. The reason it is here rather than in
`write_all` is the standing byte-identical test on the four
`plots/calibration/` figures recorded in Sec. 7 of
[PD_CORRECTION.md](PD_CORRECTION.md) -- a separate entry point cannot perturb it.
`WFI_MCU_A_MPA_CSENS_FPSSEN_K` is the channel that matters most here: it falls
from 124 K to a **89.5 K** asymptote with a ~10 h e-folding after each decon,
and that cooldown is a photometric effect, not just a thermal one -- the
detectors are **~1 % less responsive** at the top of it.

The fifth, `fit_temperature_gain.py`, measures that gain. It joins the per-SCA
digests to the housekeeping and fits the thermal gain and the film fringes
*jointly*, because the cooldown and the film growth are confounded -- both run
monotonically early in each decon episode, so a naive response-vs-temperature
regression reads one as the other. It is **free-standing**: it needs no network,
re-runs no stage, and writes nothing any other stage reads, so it cannot perturb
the byte-identical test either. **No stage applies a temperature gain today.**
The result, the four assumptions it was built to interrogate, and where the
correction belongs are in [TEMPERATURE_GAIN.md](TEMPERATURE_GAIN.md).

**8. Stage 3 -- digests, figures, and the run log** (run by `run_trend.py`; by hand,
after the second stage-2 pass):
```bash
DIGESTS="$ROOT/digests/digests_v4_$(date +%m_%d_%y)"
.venv/bin/python make_sca_digests.py \
    --data-root "$ROOT/cal" --out-dir "$DIGESTS" \
    --plot-dir "$ROOT/digest_plots" --report "$DIGESTS/run_log.txt"
less "$DIGESTS/run_log.txt"
```
Read the run log before the digests. It is the one artifact that states what the
numbers are conditioned on: every ACM move with its before/after LVDT, and
whether the step across it was **measured** (`bridge`) or **modelled**
(`multiplier`, predicted from the LVDT and the linear coefficient); which epochs
had a side that was recorded versus assumed; which photodiode readings were
refused; decon transitions; coverage. A `multiplier` step read as a measurement
is a model mistaken for data.

No correction flags are needed on a calibrated set. On schema 2 the digest
applies exactly the factors each product recorded, and never re-derives them;
on schema 1 it applies nothing, because they are already in the pixels. It
decides from the products' `calibration_schema`, not the CLI. Applying a factor
twice would **square** it, and a 1.002 photodiode factor applied twice is 1.004:
indistinguishable from a real 0.2 % response change. Full detail in
[DIGEST_TRENDS.md](DIGEST_TRENDS.md).

**9. Adding a new epoch later** -- `batch/refresh.py status`, then follow its
Next blocks ([DATA_PULL.md](DATA_PULL.md)). Stages 2 and 3 are
re-run over the whole set, not just the new epochs. The card's segmentation, the
per-side photodiode references and both bridges depend on which epochs exist, so
a new pass can move every earlier epoch's recorded bridge. That is why the
bridges are present-nominal and re-fitted every run.

## SCIPA processing
* `python make_sca_digests.py --data-root /data/eswitzer/rcs_trend_scipa/ --file-list scipa_rcs_trend.txt --out-dir digests_scipa --plot-dir digests_scipa_plots`
* `python -u fit_film_thickness.py --out-dir plots/rate_inference_scipa --profile-all --extrapolate-hours 100 --digest-dir digests_scipa`
* Using this as a prior `python -u fit_film_thickness.py --out-dir plots/rate_inference_prior --profile-all  --events example_events.yaml --digest-dir digests  --extrapolate-hours 100 --r-initial-prior plots/rate_inference_scipa/fitted_r_initial.ecsv`
* `python fit_initial_offset.py --prior plots/rate_inference_scipa/fitted_r_initial.ecsv --current plots/rate_inference/fitted_r_initial.ecsv --out-dir plots/`