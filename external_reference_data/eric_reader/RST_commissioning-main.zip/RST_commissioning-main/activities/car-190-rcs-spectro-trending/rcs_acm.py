"""ACM configuration segments and the bridge across reconfigurations.

The aperture cover mechanism changes the illumination geometry, so its position
enters the RCS response twice over:

* *within* one configuration, small LVDT excursions are handled by the linear
  correction in :mod:`rcs_corrections` (``1 + coef * fractional travel``), fit
  as a small perturbation;
* *across* a reconfiguration the linear form does not apply, and the
  multiplicative step has to be fitted jointly over LEDs against the real
  ongoing evolution -- the "bridge".

Detection used to require a stow -> deploy sign change in the LVDT plus a move of
at least 5000 units. The flight trend contains two further deployed-to-deployed
repositionings of about 2400 units, which that rule missed; the whole 10 000-unit
span then sat inside one segment and the linear correction was extrapolated to
86% fractional travel, folding roughly -0.86% of response into what reads as
film growth. :func:`find_acm_moves` tests ``|delta|`` alone.

Where a boundary has too few epochs on one side to fit a step,
:func:`multiplier_step` supplies the linear model's prediction instead of
silently leaving ``factor = 1``. That fallback is only offered for moves that
stay on the deployed side; across the deploy itself the linear form is not valid
in either direction and there is nothing honest to fall back to.

This module deliberately imports no plotting: ``digest_plots`` imports from here,
and the old arrangement (``digest_plots`` -> ``make_sca_digests`` -> deferred
``import digest_plots`` inside ``main``) was a cycle worked around at runtime.
"""
from dataclasses import dataclass

import numpy as np

from rcs_trend_config import (ACM_CLOSURE_LVDT_TOLERANCE, ACM_COEF_DEFAULT,
                             ACM_EXCURSION_NOTE, ACM_MOVE_MIN_DELTA,
                             ACM_TRAVEL_WARN, SCREEN_TOLERANCE,
                             WEIGHT_FLOOR, WEIGHT_ITERATIONS, normalize_side)

__all__ = [
    "AcmMove", "BridgeSpec", "BridgeStep", "SideBridgeSpec", "SideStep",
    "acm_segments", "boundary_floors", "bridge_factors", "bridge_sensitivity",
    "closure_checks", "decon_episodes", "find_acm_moves", "fit_bridge_step",
    "fit_side_step", "local_scatter", "multiplier_step",
    "report_acm_configuration", "screen_sensitivity", "segment_boundaries",
    "segment_noise_floors", "segment_reference_lvdt", "side_bridge_factors",
    "side_change_indices", "side_sensitivity",
]


@dataclass(frozen=True)
class BridgeSpec:
    """How to solve the step across an ACM reconfiguration.

    ``degree`` is the per-LED polynomial order describing the real evolution and
    ``window_hours`` the half-width of the time window around the boundary that
    the fit sees.

    The step itself is always solved in the *pre-move sense*: the earlier
    segments are scaled onto the later one, because the ACM ends the campaign
    deployed and the deployed configuration is the one worth preserving
    unscaled.  ``gauge`` is a separate and purely cosmetic choice of where to
    put the overall normalization afterwards:
      ``"reference"`` - renormalize so the reference epoch reads 1.0, making the
                        digest a variation-since-start curve
      ``"deployed"``  - leave the last segment at its measured scale, so the
                        reference epoch reads the composed step instead of 1.0
    Both describe the same corrected data; they differ by one constant per SCA.

    ``allow_multiplier`` lets a boundary that cannot be fitted fall back to the
    linear LVDT model (see :func:`multiplier_step`) rather than to unity.
    """
    enabled: bool = True
    degree: int = 2
    window_hours: float = 25.0
    gauge: str = "reference"
    allow_multiplier: bool = True


# ---------------------------------------------------------------------------
# Detecting ACM moves and labelling configuration segments
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class AcmMove:
    """One ACM reconfiguration between consecutive epochs, spanned by a bridge."""
    index: int            # epoch just after the move, i.e. the first in the new segment
    lvdt_before: float
    lvdt_after: float

    @property
    def delta(self):
        """Signed LVDT travel of the move."""
        return self.lvdt_after - self.lvdt_before

    @property
    def crosses_zero(self):
        """Stow <-> deploy, where the linear ACM model has no validity at all."""
        return (self.lvdt_before > 0.0) != (self.lvdt_after > 0.0)

    @property
    def is_deploy(self):
        """Stowed (positive LVDT) -> deployed (negative)."""
        return self.lvdt_before > 0.0 > self.lvdt_after

    @property
    def is_stow(self):
        """Deployed -> stowed, which the linear coefficient was never fit for."""
        return self.lvdt_after > 0.0 > self.lvdt_before

    # True when the break was asserted by hand rather than found in the LVDT.
    # It has to travel with the move: a manual break is a claim about the
    # instrument that the telemetry does not support, and every report that
    # names the move should say so rather than presenting it as a measurement.
    manual: bool = False
    # "A->B" when the break is an MCE side change rather than an ACM move. A
    # side break is asserted from the product labels, not the LVDT, but it is
    # not "manual" in the sense of an operator overriding the telemetry, and a
    # report that called it that would send a reader looking for a hand edit.
    side: str = ""

    @property
    def kind(self):
        if self.side:
            return "side"
        if self.manual:
            return "manual"
        return "deploy" if self.is_deploy else "stow" if self.is_stow else "reposition"

    def describe(self):
        if self.side:
            return (f"{'side':<10} MCE {self.side}; LVDT {self.lvdt_before:+9.1f}"
                    f" -> {self.lvdt_after:+9.1f} read by different "
                    f"electronics, so not an ACM move")
        if self.manual:
            return (f"{self.kind:<10} LVDT {self.lvdt_before:+9.1f} -> "
                    f"{self.lvdt_after:+9.1f}  delta {self.delta:+9.1f}  "
                    f"(asserted, not detected)")
        return (f"{self.kind:<10} LVDT {self.lvdt_before:+9.1f} -> "
                f"{self.lvdt_after:+9.1f}  delta {self.delta:+9.1f}")


def find_acm_moves(acm_lvdt, min_delta=ACM_MOVE_MIN_DELTA,
                   require_sign_change=False, extra_breaks=()):
    """Every ACM reconfiguration in a time-ordered sequence of epochs.

    A move is a consecutive-epoch LVDT change of at least ``min_delta`` units.
    The test is on magnitude only: a deployed-to-deployed reposition changes the
    illumination geometry exactly as much as a sign-changing one does, and two
    such moves in the flight trend were missed by the old sign rule.

    ``require_sign_change=True`` with ``min_delta=5000`` reproduces the historical
    ``find_acm_deploys`` behaviour exactly, for regression comparison.

    ``extra_breaks`` adds segment boundaries the LVDT does not show, as 0-based
    indices of the first epoch after each break.  It exists because the LVDT is
    evidence of a move, not the definition of one: a configuration change that
    leaves the position unchanged still breaks the trend, and without this the
    only way to express that would be to lower ``min_delta`` until noise
    manufactures boundaries everywhere.  Such moves are flagged ``manual`` so no
    report presents an asserted break as a detected one.  A break that
    coincides with a detected move is dropped rather than duplicated.
    """
    lvdt = np.asarray(acm_lvdt, dtype=float)
    moves = []
    for ind in range(1, len(lvdt)):
        before, after = float(lvdt[ind - 1]), float(lvdt[ind])
        if not np.isfinite(before) or not np.isfinite(after):
            continue
        if abs(after - before) < min_delta:
            continue
        if require_sign_change and not before > 0.0 > after:
            continue
        moves.append(AcmMove(index=ind, lvdt_before=before, lvdt_after=after))

    detected = {move.index for move in moves}
    for ind in sorted({int(b) for b in extra_breaks}):
        if ind in detected:
            continue
        if not 1 <= ind < len(lvdt):
            raise ValueError(
                f"segment break at epoch index {ind} is outside the set of "
                f"{len(lvdt)} epoch(s); a break is the index of the first "
                f"epoch after it, so it must be in 1..{len(lvdt) - 1}")
        moves.append(AcmMove(index=ind, lvdt_before=float(lvdt[ind - 1]),
                             lvdt_after=float(lvdt[ind]), manual=True))
    moves.sort(key=lambda move: move.index)
    return moves


# Historical alias. The old name promised something the new detector does not
# restrict itself to, so new code should say find_acm_moves.
def find_acm_deploys(acm_lvdt, min_delta=5000.0):
    """Deprecated: the pre-2026-10 sign-change detector. See ``find_acm_moves``."""
    return find_acm_moves(acm_lvdt, min_delta=min_delta, require_sign_change=True)


def acm_segments(n_epochs, moves):
    """Label each epoch with an ACM-configuration index.

    Takes an already-detected move list rather than the LVDT, so that detection
    happens once and its provenance reaches the log and the digest metadata.
    """
    segment = np.zeros(n_epochs, dtype=int)
    for move in moves:
        segment[move.index:] += 1
    return segment


def segment_boundaries(segment):
    """Indices of the first epoch of each segment after the first."""
    segment = np.asarray(segment)
    return [i for i in range(1, len(segment)) if segment[i] != segment[i - 1]]


def segment_reference_lvdt(acm_lvdt, segment, offsets=None):
    """``{segment: reference LVDT}``, taken from each segment's first epoch.

    ``offsets`` is the optional per-epoch electronics-side LVDT offset, so the
    reference is on the same footing as the ``epoch.acm_lvdt + epoch.acm_offset``
    that the linear correction divides by.
    """
    acm_lvdt = np.asarray(acm_lvdt, dtype=float)
    segment = np.asarray(segment)
    offsets = np.zeros_like(acm_lvdt) if offsets is None else np.asarray(offsets,
                                                                        dtype=float)
    return {int(seg): float(acm_lvdt[first] + offsets[first])
            for seg in range(int(segment.max()) + 1)
            for first in (int(np.flatnonzero(segment == seg)[0]),)}


def max_fractional_travel(acm_lvdt, segment, offsets=None, references=None):
    """Worst in-segment fractional LVDT travel, the quantity the linear
    correction actually multiplies by -- so the warning is about the correction
    applied rather than a proxy for it. NaN LVDT values are ignored rather than
    poisoning the whole run's metric."""
    acm_lvdt = np.asarray(acm_lvdt, dtype=float)
    segment = np.asarray(segment)
    offsets = np.zeros_like(acm_lvdt) if offsets is None else np.asarray(offsets,
                                                                        dtype=float)
    references = (segment_reference_lvdt(acm_lvdt, segment, offsets)
                  if references is None else references)
    travel = np.array([(acm_lvdt[ind] + offsets[ind]) / references[int(segment[ind])] - 1.0
                       for ind in range(len(acm_lvdt))])
    if not np.isfinite(travel).any():
        return float("nan")
    return float(np.nanmax(np.abs(travel)))


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------

def report_acm_configuration(moves, acm_lvdt, file_names, max_travel,
                             acm_applied=True, segment=None):
    """Loudly announce this trend set's ACM configuration history.

    How many configurations are present decides whether a bridge is solved at
    all, which changes both the response values and which ``bridge_*`` keys the
    digests carry, so it is stated as a banner rather than left to be inferred
    from a segment count. Reports the finding, not the action: whether the
    bridge is actually applied is ``BridgeSpec.enabled``, which ``apply_bridge``
    reports.
    """
    lvdt = np.asarray(acm_lvdt, dtype=float)
    rule = "-" * 70
    print(f"\n{rule}")

    if moves:
        print(f"{len(moves)} ACM RECONFIGURATION(S) DETECTED -- "
              f"{len(moves) + 1} configurations, each needs a bridge")
        for move in moves:
            print(f"  epoch {move.index + 1} of {len(lvdt)}: "
                  f"{file_names[move.index]}")
            print(f"    {move.describe()}")
            if move.crosses_zero:
                print("    crosses zero: the linear correction has no validity "
                      "here, only a fitted bridge")
        print("  The linear correction is referenced within each configuration; "
              "the steps")
        print("  between them cannot be predicted from the coefficient alone.")
    else:
        if np.all(lvdt < 0.0):
            side = "all on the deployed side"
        elif np.all(lvdt > 0.0):
            side = "all on the stowed side"
        else:
            side = "of mixed sign, but with no move above the detection threshold"
        print("NO ACM RECONFIGURATION IN THIS TREND SET -- no bridge applied")
        print(f"  {len(lvdt)} epochs, LVDT {np.nanmin(lvdt):.1f} .. "
              f"{np.nanmax(lvdt):.1f}, {side}")
        print("  One ACM configuration, so there is no step to solve; the "
              "digests carry")
        print("  no bridge_* metadata.")

    excursions = np.abs(np.diff(lvdt))
    excursions = excursions[np.isfinite(excursions)]
    smallest_move = min((abs(m.delta) for m in moves), default=np.inf)
    within = excursions[(excursions > ACM_EXCURSION_NOTE)
                        & (excursions < smallest_move)]
    if len(within):
        print(f"  NOTE: {len(within)} LVDT excursion(s) above "
              f"{ACM_EXCURSION_NOTE:.0f} units inside a configuration "
              f"(largest {within.max():.1f});")
        print("        below the move threshold -- handled by the linear "
              "ACM correction.")

    if np.isfinite(max_travel) and max_travel > ACM_TRAVEL_WARN and acm_applied:
        print(f"  WARNING: the linear ACM correction is extrapolated to "
              f"{100 * max_travel:.0f}% fractional travel.")
        print(f"        It was fit as a small perturbation; response "
              f"corrections reach "
              f"{100 * abs(ACM_COEF_DEFAULT) * max_travel:.2f}%.")
        print("        Either a move is going undetected (lower "
              "--acm-move-min-delta) or use --no-acm.")

    if not np.isfinite(lvdt).all():
        n_bad = int(np.sum(~np.isfinite(lvdt)))
        print(f"  WARNING: {n_bad} epoch(s) have a non-finite ACM LVDT; they "
              "are excluded from")
        print("        move detection and the travel metric, so segmentation "
              "around them is unverified.")

    if segment is not None:
        for seg, reference in segment_reference_lvdt(lvdt, segment).items():
            members = np.flatnonzero(np.asarray(segment) == seg)
            print(f"  segment {seg}: LVDT ~{reference:9.1f}  "
                  f"epochs {members[0] + 1}-{members[-1] + 1} ({len(members)})")

    print(rule)


def closure_checks(acm_lvdt, segment, tolerance=ACM_CLOSURE_LVDT_TOLERANCE):
    """Pairs of segments sitting at the same LVDT, which must bridge to unity.

    If the ACM effect is purely geometric then returning the mechanism to a
    position it held before must return the response with it, so the product of
    the intervening bridge steps has to be 1.0. That is a test of the model
    against the data rather than an internal consistency check, and it is free
    whenever a trend set revisits an LVDT -- the flight set does, at -2815.

    Returns ``[(early_segment, late_segment, lvdt_early, lvdt_late), ...]``.
    """
    references = segment_reference_lvdt(acm_lvdt, segment)
    pairs = []
    keys = sorted(references)
    for i, early in enumerate(keys):
        for late in keys[i + 1:]:
            if abs(references[early] - references[late]) <= tolerance:
                pairs.append((early, late, references[early], references[late]))
    return pairs


# ---------------------------------------------------------------------------
# The linear fallback step
# ---------------------------------------------------------------------------

def multiplier_step(lvdt_early, lvdt_late, gauge_lvdt, coefficient=ACM_COEF_DEFAULT):
    """Linear-model prediction of the step from one ACM position to another.

    Used where a boundary cannot be fitted -- too few epochs on one side -- so
    that a known geometric step is modelled rather than left in the output as
    ``factor = 1``.

    Both positions are referred to one shared ``gauge_lvdt`` rather than to each
    segment's own reference. That matters: with per-segment gauges the composed
    steps do not telescope, and a trend that returns the ACM to an earlier
    position fails to close by a few parts in a thousand. With one gauge the
    product over consecutive boundaries collapses to the ratio of the endpoints,
    so closure is exact by construction and
    :func:`closure_checks` tests the physics instead of the bookkeeping.
    """
    if not np.isfinite(gauge_lvdt) or gauge_lvdt == 0.0:
        raise ValueError(f"gauge LVDT {gauge_lvdt!r} is unusable")
    early = 1.0 + coefficient * (lvdt_early / gauge_lvdt - 1.0)
    late = 1.0 + coefficient * (lvdt_late / gauge_lvdt - 1.0)
    if early == 0.0:
        raise ValueError("linear ACM model is singular at this LVDT")
    return float(late / early)


def deployed_gauge_lvdt(acm_lvdt, segment):
    """Shared gauge for :func:`multiplier_step`: the first deployed segment's
    reference LVDT, or the first segment's if nothing is deployed."""
    references = segment_reference_lvdt(acm_lvdt, segment)
    for seg in sorted(references):
        if references[seg] < 0.0:
            return references[seg]
    return references[min(references)]


# ---------------------------------------------------------------------------
# Fitting the bridge
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class BridgeStep:
    """Multiplicative step across one ACM reconfiguration, for one SCA.

    ``value`` maps the earlier segment onto the later one: multiply the early
    side by ``value`` and the two segments join.

    The two residual scatters are kept apart because they are not comparable:
    the pre-move segment is intrinsically several times noisier than the
    post-move one, so a single pooled number hides which side is misfit.

    ``method`` records how the value was obtained -- ``"bridge"`` for the joint
    fit, ``"multiplier"`` for the linear fallback, ``"none"`` for unity -- so a
    digest consumer can tell a measured step from a modelled one.
    """
    boundary: int            # index of the first epoch on the later side
    boundary_time: float     # hours, midpoint of the cadence gap
    value: float
    stat_error: float
    per_led: np.ndarray      # independent single-LED estimates, for validation
    rms_early: float         # log-residual scatter, early side of the boundary
    rms_late: float          # log-residual scatter, late side
    n_epochs_used: int
    n_early: int
    n_late: int
    method: str = "bridge"
    note: str = ""

    @property
    def led_spread(self):
        """Range of the independent per-LED steps; tests the shared-scalar model."""
        if self.per_led is None or len(self.per_led) == 0:
            return float("nan")
        return float(np.ptp(self.per_led))

    @property
    def is_fitted(self):
        return self.method == "bridge"


def _design_matrix(times, is_early, degree, n_led):
    """Rows of the joint model: one polynomial per LED plus one shared step.

    Columns are ``[c_0..c_degree] x n_led`` then a single ``-log(step)`` column
    that is active only on the early side of the boundary.
    """
    n_time = len(times)
    n_par = n_led * (degree + 1) + 1
    design = np.zeros((n_led * n_time, n_par))
    powers = times[:, None] ** np.arange(degree + 1)[None, :]
    for led in range(n_led):
        rows = slice(led * n_time, (led + 1) * n_time)
        design[rows, led * (degree + 1):(led + 1) * (degree + 1)] = powers
        design[rows, -1] = np.where(is_early, -1.0, 0.0)
    return design


def _solve_step(times, response, is_early, degree):
    """Least-squares shared step for one SCA over the supplied epochs.

    ``response`` is ``(n_epoch, n_led)``.  Returns
    ``(step, stat_error, rms_early, rms_late)``.

    The fit is inverse-variance weighted with one variance per side of the
    boundary, estimated from the residuals themselves and iterated.
    The pre-move segment scatters several times more noisy than the post-move one.
    """
    n_led = response.shape[1]
    design = _design_matrix(times, is_early, degree, n_led)
    observed = np.log(response.T.ravel())  # LED-major, matching _design_matrix
    sides = np.tile(is_early, n_led)

    dof = len(observed) - design.shape[1]
    if dof < 1:
        raise ValueError(f"bridge fit has {dof} degrees of freedom; widen the "
                         "window or lower the degree")

    weight = np.ones(len(observed))
    for _ in range(WEIGHT_ITERATIONS):
        solution, *_ = np.linalg.lstsq(design * weight[:, None], observed * weight,
                                       rcond=None)
        residual = observed - design @ solution
        floor = WEIGHT_FLOOR * np.std(residual)
        for side in (sides, ~sides):
            weight[side] = 1.0 / max(np.std(residual[side]), floor, 1e-12)
        weight /= np.mean(weight)

    weighted = design * weight[:, None]
    solution, *_ = np.linalg.lstsq(weighted, observed * weight, rcond=None)
    residual = observed - design @ solution

    chi_square = float(np.sum((residual * weight) ** 2))
    covariance = (chi_square / dof) * np.linalg.pinv(weighted.T @ weighted)
    step = float(np.exp(solution[-1]))
    return (step,
            step * float(np.sqrt(covariance[-1, -1])),
            float(np.sqrt(np.mean(residual[sides] ** 2))),
            float(np.sqrt(np.mean(residual[~sides] ** 2))))


def decon_episodes(labels):
    """Contiguous runs of one decon cycle -- the film-growth episodes.

    Returns one dict per episode, ``{"key", "first", "last", "epochs", "n"}``
    with 0-based inclusive ``first``/``last``, matching the shape of
    :func:`make_sca_digests.calibration_families` so the two can be reported
    and drawn by the same code.

    Two choices here are not obvious and are load-bearing:

    **Contiguous, not label-identity.** An episode is a stretch of wall-clock
    time bounded by two decons, so the sequence ``decon1, decon2, decon1`` is
    *three* episodes, not two.  The third is not the first resumed -- the film
    was driven off in between -- so grouping by label would gauge it against a
    reference hundreds of hours and one decon in its past.  A ``groupby`` on the
    label is the wrong tool and gives an answer that looks reasonable.

    **Deliberately not the rule in** :func:`_same_decon_episode`.  That function
    governs a *fit window* and so keeps an unlabelled epoch, which is one whose
    cycle was never recorded rather than one known to differ; discarding it
    would throw away usable epochs on a guess.  Here an unlabelled run is its
    own episode, because the question is which epoch a block should be divided
    *by*, and a block of unknown provenance has no defensible t=0.  The two
    therefore answer ``decon1, "", decon1`` differently on purpose, and
    ``self_test`` asserts both answers side by side.
    """
    labels = list(labels)
    episodes = []
    for index, label in enumerate(labels):
        key = label if label else ""
        if episodes and episodes[-1]["key"] == key:
            episodes[-1]["epochs"].append(index)
            episodes[-1]["last"] = index
            episodes[-1]["n"] += 1
            continue
        episodes.append({"key": key, "first": index, "last": index,
                         "epochs": [index], "n": 1})
    return episodes


def _same_decon_episode(decon, boundary):
    """Mask of epochs in the same film-growth episode as ``boundary``.

    A decon removes the film, so film thickness resets across a decon
    transition.  The bridge's per-LED polynomial stands in for *ongoing* film
    evolution, which makes it meaningless across such a reset: fitted over a
    transition, the shared step stops measuring the ACM move and starts
    absorbing the offset between two unrelated growth episodes.  Measured on
    the 118-epoch flight set, letting the window reach across the
    decon1->decon2 transition degraded the segment-1/3 closure residual from
    0.058 % to 3.9 %, i.e. the "measurement" was ~67x worse than the linear
    model it displaced.

    Unknown (empty) labels are deliberately **not** treated as a distinct
    cohort.  An unannotated epoch is one whose cycle was never recorded, not
    one known to belong to a different cycle, and excluding it would discard
    usable epochs on a guess.  It is retained, which also keeps a fully
    unannotated set (the legacy 34-file regression) behaving exactly as before.
    """
    decon = np.asarray(decon, dtype=object)
    early, late = decon[boundary - 1], decon[boundary]

    if early and late and early != late:
        # Degenerate rather than merely hard: an ACM move coincident with a
        # decon transition has no fittable step, because a multiplicative ACM
        # scalar and a film reset are the same shape in the data. Refused so it
        # routes to the linear model, which at least does not pretend to have
        # measured the reset.
        raise ValueError(
            f"bridge at epoch {boundary + 1} spans a decon transition "
            f"({early} -> {late}); the ACM step and the film reset are "
            "degenerate, so no joint fit can separate them")

    episode = early or late
    if not episode:
        return np.ones(len(decon), dtype=bool)
    return np.array([not label or label == episode for label in decon])


def fit_bridge_step(response, time_hours, segment, boundary, spec, decon=None):
    """Common multiplicative step across one ACM reconfiguration, for one SCA.

    Jointly over LEDs, for epochs in a window around the boundary::

        log y[led, i] = P_led(t_i) - log(step) * [epoch i is on the early side]

    Each LED gets its own degree-``spec.degree`` polynomial ``P_led``, so every
    LED keeps its own evolution while a single ``step`` is shared by all six.

    ``decon`` is the per-epoch decon-cycle label.  When given, the fit is
    confined to one film-growth episode -- see :func:`_same_decon_episode`,
    which is where the reasoning lives.  It defaults to ``None`` (no
    constraint) only so the self-tests can build a bare response array; every
    pipeline caller passes it.
    """
    segment = np.asarray(segment)
    early_seg, late_seg = segment[boundary - 1], segment[boundary]
    boundary_time = 0.5 * (time_hours[boundary - 1] + time_hours[boundary])

    adjoining = np.isin(segment, (early_seg, late_seg))
    in_window = np.abs(time_hours - boundary_time) <= spec.window_hours
    # Partial SCA coverage (not every epoch has all 18 SCAs at L2) leaves this
    # SCA's response NaN at some epochs; log() would turn that into an SVD
    # failure in _solve_step, so drop those epochs for this SCA's fit rather
    # than letting one incomplete epoch anywhere in the window take down the
    # whole boundary.
    finite = np.all(np.isfinite(response), axis=1)
    selected = adjoining & in_window & finite
    if decon is not None:
        selected &= _same_decon_episode(decon, boundary)

    times = time_hours[selected]
    values = response[selected]
    is_early = segment[selected] == early_seg

    n_early, n_late = int(np.sum(is_early)), int(np.sum(~is_early))
    if min(n_early, n_late) < 2:
        raise ValueError(
            f"bridge at epoch {boundary + 1} has {n_early} early / {n_late} late "
            f"epochs inside +-{spec.window_hours} h; at least 2 of each are "
            "needed to separate the step from the trend")

    step, stat_error, rms_early, rms_late = _solve_step(
        times, values, is_early, spec.degree)
    per_led = np.array([
        _solve_step(times, values[:, [led]], is_early, spec.degree)[0]
        for led in range(values.shape[1])
    ])

    return BridgeStep(
        boundary=boundary, boundary_time=boundary_time, value=step,
        stat_error=stat_error, per_led=per_led,
        rms_early=rms_early, rms_late=rms_late,
        n_epochs_used=len(times), n_early=n_early, n_late=n_late,
        method="bridge",
    )


def fallback_step(acm_lvdt, time_hours, segment, boundary, moves,
                  gauge_lvdt=None, coefficient=ACM_COEF_DEFAULT, note=""):
    """Step for a boundary the joint fit could not solve.

    The linear model is used where it has some claim to validity -- a
    deployed-to-deployed reposition -- and unity where it has none, which is any
    move across zero: the coefficient was fit as a small perturbation about the
    deployed position and says nothing about stow.
    """
    acm_lvdt = np.asarray(acm_lvdt, dtype=float)
    segment = np.asarray(segment)
    boundary_time = 0.5 * (time_hours[boundary - 1] + time_hours[boundary])
    move = next((m for m in moves if m.index == boundary), None)

    blank = dict(boundary=boundary, boundary_time=boundary_time,
                 stat_error=float("nan"), per_led=np.array([]),
                 rms_early=float("nan"), rms_late=float("nan"),
                 n_epochs_used=0, n_early=0, n_late=0)

    if move is None or move.crosses_zero:
        reason = ("move crosses zero, where the linear coefficient has no "
                  "validity" if move is not None else "no detected move here")
        return BridgeStep(value=1.0, method="none",
                          note=f"{note}; {reason}".strip("; "), **blank)

    gauge = (deployed_gauge_lvdt(acm_lvdt, segment)
             if gauge_lvdt is None else gauge_lvdt)
    value = multiplier_step(move.lvdt_before, move.lvdt_after, gauge, coefficient)
    return BridgeStep(value=value, method="multiplier",
                      note=f"{note}; linear model gauged at LVDT "
                           f"{gauge:+.1f}".strip("; "), **blank)


def bridge_factors(segment, steps, gauge="reference"):
    """Per-epoch multiplicative factor that joins all segments onto one scale.

    Each earlier segment is scaled onto the last one, because the ACM ends the
    campaign deployed and that configuration is the one worth preserving
    unscaled. Gauge ``"reference"`` then divides the whole run by the first
    segment's factor, which renormalizes the reference epoch back to 1.0.
    Gauge ``"deployed"`` skips that last division.
    """
    segment = np.asarray(segment)
    n_segments = int(segment.max()) + 1
    if len(steps) != n_segments - 1:
        raise ValueError(f"{n_segments} segments need {n_segments - 1} steps, "
                         f"got {len(steps)}")

    # Segment j is scaled by the product of every step at or after it.
    by_segment = np.ones(n_segments)
    for j in range(n_segments - 2, -1, -1):
        by_segment[j] = by_segment[j + 1] * steps[j].value

    if gauge == "reference":
        by_segment /= by_segment[0]
    elif gauge != "deployed":
        raise ValueError(f"unknown bridge gauge {gauge!r}; "
                         "use 'reference' or 'deployed'")

    return by_segment[segment]


def closure_residuals(acm_lvdt, segment, steps, tolerance=ACM_CLOSURE_LVDT_TOLERANCE):
    """Composed step between every same-LVDT segment pair; 1.0 if the model holds.

    Returns ``[(early, late, lvdt_early, lvdt_late, product), ...]``.
    """
    results = []
    for early, late, lvdt_early, lvdt_late in closure_checks(acm_lvdt, segment,
                                                             tolerance):
        product = 1.0
        for seg in range(early, late):
            product *= steps[seg].value
        results.append((early, late, lvdt_early, lvdt_late, float(product)))
    return results


# ---------------------------------------------------------------------------
# Noise floors and fit-choice systematics
# ---------------------------------------------------------------------------

def local_scatter(response, time_hours):
    """Model-free log-space noise estimate for one SCA over one segment.

    Compares each epoch against the straight line through its two neighbours, so
    a smooth evolution of any amplitude cancels and only the epoch-to-epoch
    scatter survives; curvature biases this upward, never downward, which is the
    safe direction for a noise floor.  Pooled over LEDs, whose noise is
    comparable.  Needs at least three epochs.
    """
    response, time_hours = np.asarray(response), np.asarray(time_hours)
    if len(time_hours) < 3:
        return float("nan")

    log_response = np.log(response)
    inner = slice(1, -1)
    span = time_hours[2:] - time_hours[:-2]
    fraction = (time_hours[inner] - time_hours[:-2]) / span

    predicted = (log_response[:-2] * (1.0 - fraction)[:, None]
                 + log_response[2:] * fraction[:, None])
    # Variance of (observed - predicted) in units of the per-epoch variance.
    inflation = np.sqrt((1.0 - fraction) ** 2 + fraction ** 2 + 1.0)
    deviation = (log_response[inner] - predicted) / inflation[:, None]
    return float(np.std(deviation))


def segment_noise_floors(response, time_hours, segment):
    """Per-segment noise floor for one SCA, as ``{segment_index: scatter}``.

    Estimated over each whole segment rather than the bridge's fit window, which
    is too short to pin a scatter down.  The pre- and post-move segments differ
    by up to a factor of six (still cooling early), so they have to be carried
    separately.  A segment with fewer than three epochs has no estimate, which
    surfaces as NaN rather than as a misleadingly tight floor.
    """
    segment = np.asarray(segment)
    floors = {}
    for seg in range(int(segment.max()) + 1):
        members = segment == seg
        floors[seg] = local_scatter(response[members], time_hours[members])
    return floors


def bridge_sensitivity(response, time_hours, segment, spec,
                       degrees=(1, 2, 3),
                       windows=(15.0, 20.0, 25.0, 30.0, 40.0, None),
                       decon=None):
    """Bridge fits over a grid of ``(degree, window)`` choices, for one SCA.

    The bridge is an extrapolation into a cadence gap, so its systematic floor
    is the spread over *defensible* fit choices, not the least-squares error.
    ``None`` window means every epoch in the two adjoining segments.  Returns
    ``{(degree, window): [BridgeStep or None per boundary]}``; the full fits are
    kept rather than bare values so that :func:`screen_sensitivity` can throw out
    the choices the residuals disqualify.

    ``decon`` is passed straight through, and that matters most here: the widest
    windows in the default grid (and ``None``, meaning unbounded) are exactly the
    choices that would otherwise reach across a decon transition.  Without the
    constraint the quoted systematic would be inflated by fits that are not
    defensible at all, rather than by the range of ones that are.
    """
    scan = {}
    for degree in degrees:
        for window in windows:
            trial = BridgeSpec(degree=degree, gauge=spec.gauge,
                               window_hours=np.inf if window is None else window)
            fits = []
            for boundary in segment_boundaries(segment):
                try:
                    fits.append(fit_bridge_step(response, time_hours, segment,
                                                boundary, trial, decon=decon))
                except (ValueError, np.linalg.LinAlgError):
                    fits.append(None)
            scan[(degree, window)] = fits
    return scan


def boundary_floors(response, time_hours, segment, boundary):
    """Noise floors of the two segments adjoining ``boundary``, as (early, late)."""
    segment = np.asarray(segment)
    floors = segment_noise_floors(response, time_hours, segment)
    return floors[segment[boundary - 1]], floors[segment[boundary]]


def screen_sensitivity(scan, floors, boundary_index=0, tolerance=SCREEN_TOLERANCE):
    """
    If the fit for the ongoing evolution has order too low, it will have have
    systematic differences in the sections of data pre/post gap. Compare these
    differences to the segement_noise_floors and accept models within tolerance.

    The reference has to be that external floor rather than the best residual in
    the scan: the smallest residual is always turned in by the most flexible
    choice (high degree, narrow window) by overfitting.
    The two sides are also kept separate, since the pre-move segment's floor runs
    several times the post-move one and pooling them would let a fit hide a badly
    misfit quiet side behind a noisy one.

    Returns ``(accepted_keys, spread)``; ``spread`` is the full range of the
    surviving step values, or NaN if nothing.
    """
    fits = {key: value[boundary_index] for key, value in scan.items()
            if len(value) > boundary_index and value[boundary_index] is not None}
    if not fits:
        return [], float("nan")

    early_floor, late_floor = floors
    # A segment too short for a floor estimate cannot screen anything; keeping
    # every fit is the honest outcome, and the resulting spread is wide.
    if not np.isfinite(early_floor) or not np.isfinite(late_floor):
        return (list(fits),
                float(np.ptp([f.value for f in fits.values()])) if len(fits) > 1
                else float("nan"))

    accepted = [key for key, f in fits.items()
                if f.rms_early <= tolerance * early_floor
                and f.rms_late <= tolerance * late_floor]
    if not accepted:
        return [], float("nan")

    return accepted, float(np.ptp([fits[key].value for key in accepted]))


# ---------------------------------------------------------------------------
# The MCE side bridge
# ---------------------------------------------------------------------------
#
# A side swap is a discrete re-calibration like an ACM move, and it is bridged
# the same way -- a step fitted against the ongoing per-LED evolution on either
# side -- with the two constraints transposed:
#
#   ACM move   one step per SCA, shared by the six LEDs   (achromatic, per SCA)
#   side swap  one step per LED, shared by the 18 SCAs    (chromatic, SCA-common)
#
# The ACM changes the illumination geometry, so each SCA can move differently
# but every wavelength moves together. The swap changes the electronics and the
# photodiode behind the correction, which is chromatic (PD1/PD2 moved -5.8 to
# +0.5 % by LED at the 2026-10-06 swap) but has no business changing where the
# light lands on the focal plane. A per-SCA freedom at the swap would let it do
# exactly that, so there is none; the per-SCA residual is measured instead and
# reported as a test of the assumption (SideStep.pattern_*).
#
# The step absorbs everything that changes at the swap at once: the detector
# electronics' gain, the LED drive, and the photodiode. The photodiode has to
# be absorbed rather than corrected because the bridge connecting the A diode
# to the B diode is lost -- they are different devices behind one mnemonic --
# so the B-side PD factor is re-based to 1 at the first B epoch and this step
# carries the A->B ratio.


def label_side_moves(moves, sides):
    """``moves`` with each break at a side change labelled as one."""
    from dataclasses import replace

    sides = [normalize_side(side) for side in sides]
    changes = set(side_change_indices(sides))
    return [replace(move, side=f"{sides[move.index - 1]}->{sides[move.index]}")
            if move.index in changes else move for move in moves]


def side_change_indices(sides):
    """0-based indices of epochs whose MCE side differs from the previous one.

    The single definition of where a side boundary is, used by the reference
    card's segmentation and by the digests. It used to live only in
    ``make_sca_digests``, and the card did not apply it -- so the card gave the
    first B-side epochs the last A segment's reference LVDT, and the B
    electronics' LVDT readout offset (-172 to +205 by channel) reached the
    linear ACM term as a fake ~0.15 % correction.
    """
    sides = [normalize_side(side) for side in sides]
    return [index for index in range(1, len(sides))
            if sides[index] != sides[index - 1]]


@dataclass(frozen=True)
class SideBridgeSpec:
    """How to solve the chromatic step across an MCE side change.

    Its own window rather than ``BridgeSpec``'s, because a swap is not a
    cadence accident: it is followed by however many passes have run on the new
    side, and at the 2026-10-06 swap the ACM bridge's +-25 h held only two of
    them. ``degrees`` x ``windows`` is the grid :func:`side_sensitivity` scans for
    the systematic.
    """
    enabled: bool = True
    degree: int = 2
    window_hours: float = 50.0
    degrees: tuple = (1, 2)
    windows: tuple = (25.0, 35.0, 50.0, 75.0)


@dataclass
class SideStep:
    """The per-LED, SCA-common step across one side change.

    ``value`` scales the EARLY side onto the late one, exactly as
    :class:`BridgeStep` does, so the later side -- the one the instrument is
    expected to stay on -- is left at its measured scale. That is the gauge the
    user asked for: the constants that bring the old side up to the present.
    """
    boundary: int                 # first epoch on the later side
    boundary_time: float          # hours, midpoint of the gap
    transition: str               # e.g. "A->B"
    value: np.ndarray             # (n_led,) multiply the early side by this
    stat_error: np.ndarray        # (n_led,) from the joint fit's covariance
    empirical_error: np.ndarray   # (n_led,) per-SCA scatter / sqrt(n_sca)
    per_sca: np.ndarray           # (n_sca, n_led) independent per-SCA steps
    sca_names: list
    pattern_offset: np.ndarray    # (n_sca,) achromatic log deviation per SCA
    pattern_rms: float            # rms of pattern_offset across SCAs
    pattern_noise: float          # rms pattern_offset expected from noise alone
    rms_early: float
    rms_late: float
    n_early: int
    n_late: int
    n_sca: int
    degree: int
    window_hours: float
    systematic: np.ndarray = None  # (n_led,) spread over accepted fit choices
    n_choices: int = 0
    method: str = "side"
    note: str = ""

    @property
    def total_error(self):
        """Per LED: the larger of the two noise estimates, plus the systematic.

        The larger rather than both in quadrature, because the covariance and
        the SCA-to-SCA scatter are two estimates of the same noise; adding them
        would count it twice. The systematic is a different thing -- the choice
        of evolution model across the gap -- and is added in quadrature.
        """
        noise = np.fmax(self.stat_error, self.empirical_error)
        systematic = (np.zeros_like(noise) if self.systematic is None
                      else np.nan_to_num(self.systematic, nan=0.0))
        return np.sqrt(noise ** 2 + systematic ** 2)

    @property
    def pattern_ratio(self):
        """Measured over expected per-SCA scatter; ~1 if the pattern held."""
        if not (np.isfinite(self.pattern_noise) and self.pattern_noise > 0):
            return float("nan")
        return float(self.pattern_rms / self.pattern_noise)


def _solve_side(times, log_y, is_early, degree):
    """Shared per-LED steps over many SCAs, each (SCA, LED) with its own trend.

    ``log_y`` is ``(n_sca, n_time, n_led)``, NaN where missing. Returns
    ``(log_step, log_step_error, rms_early, rms_late)`` with the first two
    ``(n_led,)``. Weighted exactly as :func:`_solve_step`: one variance per side
    of the boundary, estimated from the residuals and iterated, because the two
    sides are not equally noisy.
    """
    n_sca, n_time, n_led = log_y.shape
    n_coef = degree + 1
    n_poly = n_sca * n_led * n_coef
    powers = times[:, None] ** np.arange(n_coef)[None, :]

    rows, observed, sides = [], [], []
    columns = n_poly + n_led
    for sca in range(n_sca):
        for led in range(n_led):
            finite = np.isfinite(log_y[sca, :, led])
            if finite.sum() < n_coef + 1:
                continue
            block = np.zeros((int(finite.sum()), columns))
            start = (sca * n_led + led) * n_coef
            block[:, start:start + n_coef] = powers[finite]
            block[:, n_poly + led] = np.where(is_early[finite], -1.0, 0.0)
            rows.append(block)
            observed.append(log_y[sca, finite, led])
            sides.append(is_early[finite])
    if not rows:
        raise ValueError("no (SCA, LED) series with enough epochs to fit")
    design = np.vstack(rows)
    observed = np.concatenate(observed)
    sides = np.concatenate(sides)

    # Columns no row touches (an SCA/LED skipped above) are dropped rather than
    # left to make the system singular.
    used = np.any(design != 0.0, axis=0)
    step_used = used[n_poly:]
    if not step_used.all():
        raise ValueError("an LED has no usable epochs on the early side; its "
                         "step cannot be separated from the trend")
    design = design[:, used]
    dof = len(observed) - design.shape[1]
    if dof < 1:
        raise ValueError(f"side bridge fit has {dof} degrees of freedom; widen "
                         f"the window or lower the degree")

    weight = np.ones(len(observed))
    for _ in range(WEIGHT_ITERATIONS):
        solution, *_ = np.linalg.lstsq(design * weight[:, None],
                                       observed * weight, rcond=None)
        residual = observed - design @ solution
        floor = WEIGHT_FLOOR * np.std(residual)
        for side in (sides, ~sides):
            if side.any():
                weight[side] = 1.0 / max(np.std(residual[side]), floor, 1e-12)
        weight /= np.mean(weight)

    weighted = design * weight[:, None]
    solution, *_ = np.linalg.lstsq(weighted, observed * weight, rcond=None)
    residual = observed - design @ solution
    chi_square = float(np.sum((residual * weight) ** 2))
    covariance = (chi_square / dof) * np.linalg.pinv(weighted.T @ weighted)

    log_step = solution[-n_led:]
    error = np.sqrt(np.diag(covariance)[-n_led:])
    return (log_step, error,
            float(np.sqrt(np.mean(residual[sides] ** 2))) if sides.any() else np.nan,
            float(np.sqrt(np.mean(residual[~sides] ** 2))) if (~sides).any() else np.nan)


def fit_side_step(responses, time_hours, sides, boundary, spec, decon=None):
    """The per-LED, SCA-common step across the side change at ``boundary``.

    ``responses`` is ``{sca: (n_epoch, n_led)}`` -- already ACM-bridged, so an
    ACM move elsewhere in the window cannot leak into it. Jointly over every
    SCA, for epochs in a window around the boundary::

        log y[s, l, i] = P_{s,l}(t_i) - log(step_l) * [epoch i is on the early side]

    108 polynomials and 6 steps. The window stops at any other side change and,
    via :func:`_same_decon_episode`, at a decon; a swap that coincides with a
    decon is degenerate (both are chromatic steps) and raises.
    """
    sides = [normalize_side(side) for side in sides]
    time_hours = np.asarray(time_hours, dtype=float)
    n_epoch = len(time_hours)
    boundary_time = 0.5 * (time_hours[boundary - 1] + time_hours[boundary])

    # The contiguous run of the early side and of the late side, so a second
    # swap (back, or onward) bounds the window rather than joining it.
    changes = [0] + side_change_indices(sides) + [n_epoch]
    position = changes.index(boundary)
    run = np.zeros(n_epoch, dtype=bool)
    run[changes[position - 1]:changes[position + 1]] = True

    selected = run & (np.abs(time_hours - boundary_time) <= spec.window_hours)
    if decon is not None:
        selected &= _same_decon_episode(decon, boundary)
    index = np.flatnonzero(selected)
    is_early = index < boundary
    n_early, n_late = int(is_early.sum()), int((~is_early).sum())
    if min(n_early, n_late) < 2:
        raise ValueError(
            f"side bridge at epoch {boundary + 1} has {n_early} early / "
            f"{n_late} late epochs inside +-{spec.window_hours} h; at least 2 "
            f"of each are needed to separate the step from the trend")

    names = sorted(responses, key=lambda name: int(str(name)[3:]))
    times = (time_hours[index] - boundary_time) / max(spec.window_hours, 1.0)
    with np.errstate(divide="ignore", invalid="ignore"):
        log_y = np.stack([np.log(np.asarray(responses[name], dtype=float)[index])
                          for name in names])
    log_y[~np.isfinite(log_y)] = np.nan

    log_step, log_error, rms_early, rms_late = _solve_side(
        times, log_y, is_early, spec.degree)
    value = np.exp(log_step)

    # Each SCA on its own, for the empirical error and the pattern test. Same
    # model with one SCA; an SCA too sparse to fit is NaN and simply not
    # counted.
    n_led = log_y.shape[2]
    per_sca = np.full((len(names), n_led), np.nan)
    per_sca_error = np.full((len(names), n_led), np.nan)
    for row in range(len(names)):
        try:
            step, error, _, _ = _solve_side(times, log_y[row:row + 1],
                                            is_early, spec.degree)
        except (ValueError, np.linalg.LinAlgError):
            continue
        per_sca[row], per_sca_error[row] = np.exp(step), error
    fitted = np.isfinite(per_sca).all(axis=1)
    n_fit = int(fitted.sum())
    empirical = (np.nanstd(np.log(per_sca[fitted]), axis=0, ddof=1)
                 / np.sqrt(n_fit) * value if n_fit > 2
                 else np.full(n_led, np.nan))

    # The illumination-pattern test. What the SCA-common constraint forbids is
    # a per-SCA achromatic offset at the swap, so that is what is measured: each
    # SCA's own steps against the common ones, averaged over LEDs.
    offset = np.full(len(names), np.nan)
    offset[fitted] = np.mean(np.log(per_sca[fitted] / value[None, :]), axis=1)
    expected = np.sqrt(np.nansum(per_sca_error[fitted] ** 2, axis=1)) / n_led
    pattern_rms = (float(np.sqrt(np.nanmean((offset[fitted]
                                             - np.nanmean(offset[fitted])) ** 2)))
                   if n_fit > 1 else float("nan"))
    pattern_noise = (float(np.sqrt(np.mean(expected ** 2)))
                     if n_fit else float("nan"))

    return SideStep(
        boundary=int(boundary), boundary_time=float(boundary_time),
        transition=f"{sides[boundary - 1]}->{sides[boundary]}",
        value=value, stat_error=value * log_error,
        empirical_error=np.asarray(empirical, dtype=float),
        per_sca=per_sca, sca_names=list(names),
        pattern_offset=offset, pattern_rms=pattern_rms,
        pattern_noise=pattern_noise,
        rms_early=rms_early, rms_late=rms_late,
        n_early=n_early, n_late=n_late, n_sca=n_fit,
        degree=int(spec.degree), window_hours=float(spec.window_hours))


def side_sensitivity(responses, time_hours, sides, boundary, spec, decon=None,
                     tolerance=SCREEN_TOLERANCE):
    """``(systematic, n_accepted, scan)`` over the spec's degree x window grid.

    The same reasoning as :func:`bridge_sensitivity`: the step is an
    extrapolation of each trend into the gap, so its systematic is the spread
    over defensible choices of that trend. A choice is accepted when both sides'
    residual rms is within ``tolerance`` of the scatter the widest window's own
    residuals show -- not of the best residual in the scan, which the most
    flexible choice always wins by overfitting.
    """
    scan = {}
    for degree in spec.degrees:
        for window in spec.windows:
            trial = SideBridgeSpec(degree=degree, window_hours=window)
            try:
                scan[(degree, window)] = fit_side_step(
                    responses, time_hours, sides, boundary, trial, decon=decon)
            except (ValueError, np.linalg.LinAlgError):
                scan[(degree, window)] = None
    fits = {key: fit for key, fit in scan.items() if fit is not None}
    if not fits:
        return None, 0, scan

    floor_early = np.median([f.rms_early for f in fits.values()])
    floor_late = np.median([f.rms_late for f in fits.values()])
    accepted = [f for f in fits.values()
                if f.rms_early <= tolerance * floor_early
                and f.rms_late <= tolerance * floor_late]
    if len(accepted) < 2:
        return None, len(accepted), scan
    values = np.array([f.value for f in accepted])
    return np.ptp(values, axis=0), len(accepted), scan


def side_bridge_factors(n_epoch, steps, gauge="present"):
    """``(n_epoch, n_led)`` multiplier joining every side onto the latest.

    ``gauge="present"`` leaves the epochs after the last side change at 1 and
    scales every earlier epoch by the product of the steps after it -- the gauge
    the h5 products record. ``"reference"`` divides by epoch 0's row, which is
    what a digest normalized to the reference epoch applies; the two describe
    the same corrected data and differ by one constant per LED.
    """
    if not steps:
        return np.ones((n_epoch, 0))
    n_led = len(steps[0].value)
    factor = np.ones((n_epoch, n_led))
    for step in steps:
        factor[:step.boundary] *= np.asarray(step.value, dtype=float)[None, :]
    if gauge == "reference":
        factor = factor / factor[0][None, :]
    elif gauge != "present":
        raise ValueError(f"unknown side gauge {gauge!r}; use 'present' or "
                         f"'reference'")
    return factor


# ---------------------------------------------------------------------------
# Self test
# ---------------------------------------------------------------------------

def self_test(verbose=True):
    """Detection, segmentation, the fallback's closure, and a synthetic bridge."""
    def report(name):
        if verbose:
            print(f"  ok  {name}")

    # The flight sequence, which is what motivated sign-independent detection.
    flight = np.array([7558.4] * 14 + [-2815.2] * 18 + [-5231.7] + [-2814.7])

    old = find_acm_moves(flight, min_delta=5000.0, require_sign_change=True)
    assert len(old) == 1, f"old rule should find only the deploy, found {len(old)}"
    old_travel = max_fractional_travel(flight, acm_segments(len(flight), old))
    assert old_travel > 0.8, old_travel

    moves = find_acm_moves(flight)
    assert len(moves) == 3, [m.describe() for m in moves]
    assert moves[0].is_deploy and moves[0].crosses_zero
    assert moves[0].kind == "deploy"
    assert not moves[1].crosses_zero and moves[1].kind == "reposition"
    assert not moves[2].crosses_zero
    segment = acm_segments(len(flight), moves)
    assert segment.max() == 3 and list(np.bincount(segment)) == [14, 18, 1, 1]
    travel = max_fractional_travel(flight, segment)
    assert travel < 0.01, travel
    report(f"sign-independent detection: 3 moves, 4 segments, "
           f"max travel {travel:.4f} (was {old_travel:.3f})")

    assert segment_boundaries(segment) == [14, 32, 33]
    references = segment_reference_lvdt(flight, segment)
    assert references[0] > 0 > references[1]
    report("segmentation and per-segment reference LVDT")

    # Closure: segments 1 and 3 sit at the same LVDT, so the composed step
    # across them must be unity. This is exact only because multiplier_step
    # refers both ends to one shared gauge.
    pairs = closure_checks(flight, segment)
    assert pairs and (1, 3) in [(e, l) for e, l, *_ in pairs], pairs
    gauge = deployed_gauge_lvdt(flight, segment)
    assert gauge < 0.0
    steps = [fallback_step(flight, np.arange(len(flight), dtype=float),
                           segment, boundary, moves)
             for boundary in segment_boundaries(segment)]
    assert steps[0].method == "none", steps[0].method   # the deploy
    assert steps[1].method == "multiplier" and steps[2].method == "multiplier"
    residuals = closure_residuals(flight, segment, steps)
    (_, _, _, _, product), = [r for r in residuals if r[0] == 1 and r[1] == 3]
    assert abs(product - 1.0) < 1e-4, f"closure product {product}"
    report(f"same-LVDT closure of the linear fallback: {product:.8f}")

    # Per-segment gauges would NOT close; this is the trap the shared gauge avoids.
    naive = (multiplier_step(references[1], references[2], references[2])
             * multiplier_step(references[2], references[3], references[3]))
    assert abs(naive - 1.0) > 1e-3, naive
    report(f"per-segment gauges miss closure by {100 * (naive - 1):.2f}% "
           "(why the gauge is shared)")

    # A synthetic bridge: smooth per-LED evolution plus a known step.
    rng = np.random.default_rng(3)
    n_epoch, n_led = 24, 6
    times = np.linspace(0.0, 48.0, n_epoch)
    two = (times >= 24.0).astype(int)
    truth = 1.0300
    base = np.exp(-0.0004 * times)[:, None] * (1.0 + 0.002 * np.arange(n_led))
    response = base * np.where(two[:, None] == 0, 1.0 / truth, 1.0)
    response *= 1.0 + rng.normal(scale=2e-5, size=response.shape)

    spec = BridgeSpec(degree=2, window_hours=25.0)
    step = fit_bridge_step(response, times, two, 12, spec)
    assert step.is_fitted and abs(step.value - truth) < 5e-4, step.value
    assert step.n_early >= 2 and step.n_late >= 2
    factors = bridge_factors(two, [step])
    assert np.isclose(factors[0], 1.0) and np.isclose(factors[-1], 1.0 / truth,
                                                      rtol=1e-3)
    report(f"synthetic bridge recovers {truth} as {step.value:.5f}")

    # Too few epochs on one side must raise, which is what triggers the fallback.
    lonely = np.array([0] * 10 + [1])
    try:
        fit_bridge_step(response[:11], times[:11], lonely, 10, spec)
        raise AssertionError("a one-epoch late side should have raised")
    except ValueError:
        pass
    report("a one-sided boundary raises, so the fallback engages")

    # The decon guard. Four cases, because the ways it can be wrong are not
    # symmetric: it must bite across a transition, must not bite within one,
    # and must not treat "unknown" as "different".
    one_cycle = ["decon1"] * n_epoch
    constrained = fit_bridge_step(response, times, two, 12, spec,
                                  decon=one_cycle)
    assert constrained.value == step.value, (constrained.value, step.value)
    assert constrained.n_early == step.n_early
    report("a single decon cycle leaves the fit bit-identical")

    # Unannotated epochs are retained, not quarantined: the 34-file legacy set
    # is mostly unlabelled and must keep reproducing its archived digests.
    partly = ["decon1"] * 13 + [""] * (n_epoch - 13)
    assert fit_bridge_step(response, times, two, 12, spec,
                           decon=partly).value == step.value
    assert fit_bridge_step(response, times, two, 12, spec,
                           decon=[""] * n_epoch).value == step.value
    report("unlabelled epochs are kept, so an unannotated set is unchanged")

    # A transition at the boundary itself is degenerate and must be refused
    # outright -- the ACM step and the film reset are the same shape.
    try:
        fit_bridge_step(response, times, two, 12, spec,
                        decon=["decon1"] * 12 + ["decon2"] * 12)
        raise AssertionError("a boundary on a decon transition should have raised")
    except ValueError as error:
        assert "decon transition" in str(error), error
    report("an ACM move coincident with a decon is refused as degenerate")

    # A transition away from the boundary trims the window instead. The step is
    # still recovered, from fewer epochs -- which is the point: the trimmed
    # epochs belonged to a different film, not to a noisier version of this one.
    trimmed = fit_bridge_step(response, times, two, 12, spec,
                              decon=["decon1"] * 18 + ["decon2"] * 6)
    assert trimmed.n_late == 6, trimmed.n_late
    assert abs(trimmed.value - truth) < 5e-4, trimmed.value
    report(f"a transition inside the window trims it to {trimmed.n_late} late "
           f"epochs and still recovers {trimmed.value:.5f}")

    # decon_episodes: contiguous runs, which is NOT a groupby on the label.
    assert decon_episodes([]) == []
    assert [e["n"] for e in decon_episodes(["decon1"])] == [1]
    assert [e["n"] for e in decon_episodes([""] * 7)] == [7]

    flight_decon = ["decon1"] * 35 + ["decon2"] * 141
    episodes = decon_episodes(flight_decon)
    assert [(e["key"], e["first"], e["last"]) for e in episodes] == [
        ("decon1", 0, 34), ("decon2", 35, 175)], episodes
    report(f"the flight labelling reads as {len(episodes)} episodes, "
           f"{episodes[0]['n']} + {episodes[1]['n']}")

    # The assertion that fails if someone "simplifies" this to a groupby: a
    # recurring label is a new episode, because the film was removed between.
    recur = decon_episodes(["decon1", "decon2", "decon1"])
    assert len(recur) == 3, recur
    assert [e["key"] for e in recur] == ["decon1", "decon2", "decon1"]
    report("a recurring decon label opens a new episode, not a resumed one")

    # The deliberate asymmetry against _same_decon_episode, asserted side by
    # side with the function that would break if either rule drifted.
    gapped = ["decon1", "", "decon1"]
    assert len(decon_episodes(gapped)) == 3, decon_episodes(gapped)
    assert _same_decon_episode(gapped, 1).tolist() == [True, True, True]
    report("an unlabelled run is its own episode here, yet stays inside the "
           "bridge window there -- the two rules differ on purpose")

    # Episodes must tile the epoch set exactly: no gap, no overlap, in order.
    for case in ([], ["a"], flight_decon, gapped,
                 ["x", "x", "y", "", "y", "y"]):
        tiled = [index for episode in decon_episodes(case)
                 for index in episode["epochs"]]
        assert tiled == list(range(len(case))), (case, tiled)
    report("episodes tile the epoch set with no gap or overlap")

    floors = boundary_floors(response, times, two, 12)
    assert all(np.isfinite(f) for f in floors), floors
    scan = bridge_sensitivity(response, times, two, spec, degrees=(1, 2),
                              windows=(20.0, None))
    accepted, spread = screen_sensitivity(scan, floors)
    assert np.isfinite(spread), (accepted, spread)
    report("noise floors and fit-choice screening")

    # NaN LVDT must not poison detection or the travel metric.
    holed = flight.copy()
    holed[20] = np.nan
    assert len(find_acm_moves(holed)) == 3
    assert np.isfinite(max_fractional_travel(holed, acm_segments(len(holed),
                                                                find_acm_moves(holed))))
    report("a NaN LVDT epoch is skipped, not propagated")

    _self_test_side_bridge(report)
    return True


def _self_test_side_bridge(report):
    """The side bridge on synthetic trends with a known answer."""
    rng = np.random.default_rng(20261006)
    sides = ["A"] * 10 + ["B"] * 4
    assert side_change_indices(sides) == [10]
    assert side_change_indices(["a", "A", "b"]) == [2]
    report("side_change_indices is the one definition of a side boundary")

    # Cadence like the real swap: A passes every ~12 h, then B passes at
    # +4, +15, +28, +44 h. Each (SCA, LED) gets its own smooth trend and the
    # swap multiplies the late side by a per-LED, SCA-COMMON factor. The step
    # that scales the early side onto the late one is therefore that factor
    # itself -- not its inverse, which is what a first draft of this test
    # asserted, and the fit's 0.910 = 0.954**2 on LED1 is what gave it away.
    times = np.concatenate([np.arange(-110.0, 0.0, 11.5)[-10:],
                            [4.0, 15.0, 28.0, 44.0]])
    n_led, names = 6, [f"SCA{i}" for i in range(1, 19)]
    swap = np.array([0.954, 0.972, 1.050, 1.003, 1.012, 1.021])
    noise = 3e-5
    clean, patterned = {}, {}
    pattern = rng.normal(0.0, 0.004, len(names))   # 0.4 % per-SCA achromatic
    for row, name in enumerate(names):
        base = (1.0 + rng.normal(0, 1e-3, n_led)[None, :]
                + rng.normal(-2e-5, 5e-6, n_led)[None, :] * times[:, None]
                + rng.normal(0, 2e-8, n_led)[None, :] * times[:, None] ** 2)
        late = (times > 0)[:, None]
        clean[name] = (base * np.where(late, swap[None, :], 1.0)
                       * np.exp(rng.normal(0, noise, base.shape)))
        patterned[name] = clean[name] * np.where(late, np.exp(pattern[row]), 1.0)

    spec = SideBridgeSpec(window_hours=60.0)
    step = fit_side_step(clean, times, sides, 10, spec)
    assert step.transition == "A->B" and step.n_late == 4, step
    assert np.max(np.abs(step.value / swap - 1.0)) < 1e-4, step.value / swap
    report(f"the SCA-common per-LED step is recovered to "
           f"{np.max(np.abs(step.value / swap - 1.0)):.1e} "
           f"(early side scaled onto the late)")
    assert np.all(np.isfinite(step.stat_error)) and np.all(step.stat_error > 0)
    assert np.all(np.isfinite(step.empirical_error))
    assert step.pattern_ratio < 3.0, step.pattern_ratio
    report(f"errors finite, and an unchanged pattern reads "
           f"{step.pattern_ratio:.2f}x its noise")

    flagged = fit_side_step(patterned, times, sides, 10, spec)
    assert flagged.pattern_ratio > 10.0, flagged.pattern_ratio
    report(f"a 0.4 % per-SCA achromatic offset at the swap is flagged at "
           f"{flagged.pattern_ratio:.0f}x noise, not absorbed")

    factors = side_bridge_factors(len(times), [step])
    assert np.allclose(factors[10:], 1.0) and np.allclose(factors[0], step.value)
    shown = side_bridge_factors(len(times), [step], gauge="reference")
    assert np.allclose(shown[0], 1.0) and np.allclose(shown[10], 1 / step.value)
    report("present gauge leaves the new side at 1; reference gauge pins "
           "epoch 0 at 1 instead")

    # Applied, the factors remove the swap: the joined series across the
    # boundary moves only by the trend, i.e. as the swap-free series would.
    joined = {name: clean[name] * factors for name in names}
    assert max(np.max(np.abs(np.log(joined[n][10] / joined[n][9])
                             - np.log(clean[n][10] / swap / clean[n][9])))
               for n in names) < 1e-3
    report("applied, the present-gauge factors remove the swap from the trend")
    systematic, n_accepted, _ = side_sensitivity(
        clean, times, sides, 10, SideBridgeSpec(windows=(40.0, 60.0, 120.0)))
    assert systematic is not None and n_accepted >= 2, n_accepted
    assert np.all(systematic < 5e-3), systematic
    report(f"fit-choice systematic over {n_accepted} accepted choices: "
           f"max {np.max(systematic):.1e}")

    try:
        fit_side_step(clean, times, sides, 10, SideBridgeSpec(window_hours=3.0))
    except ValueError:
        report("a window too narrow to see two epochs a side is refused")
    else:
        raise AssertionError("a 3 h window was not refused")


if __name__ == "__main__":
    print("rcs_acm self test")
    self_test()
    print("all checks passed")
