"""
Build MPA (Mosaic Plate Assembly) mosaics from per-SCA WFI frames.

Take the 18 4096x4096 SCA frames, bin them, orient them into the mosaic's science-frame
convention, and drop them onto a single focal-plane frame in physical
millimeter positions.

Two coordinate frames matter here and are easy to confuse:

* **Detector frame** -- native to the physical SCA, tied to its readout
  electronics. ``mosaic_plot_FPS.placeImages`` assumed its inputs were in this
  frame and flipped each SCA into place accordingly (see ``orient_frame``).
* **Science frame** -- the SOC convention used by both per-SCA product types
  handled here (romancal L2 ``_cal.asdf`` and quicklook ``_slope.fits.fz``):
  rows/columns are already oriented as they appear in the mosaic, so no flip
  is needed (``DEFAULT_ORIENTATION = "identity"``). This is a defined
  relationship between the two frames, not a coincidence -- the
  ``mosaic_plot_fps*`` orientations exist only so ``calibrate_orientation.py``
  can rule out the detector-frame convention by comparison; they should not be
  used to build products from these (science-frame) inputs.

The mosaic frame itself is the *view from the sky, looking down at the
detectors*: in this right-handed system, +Z points from the sky through the
detectors (the direction light travels), and the mosaic is drawn as that view
would appear, with FPA -X to the right and FPA +Y up (see ``sca_placement``).

Geometry, verified against the existing trend cube
``TVAC_HOB_OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA.h5``: a 17-SCA (all but WFI08)
mosaic at ``r=4`` rebinned 5x reproduces that file's NaN mask exactly, 0
mismatched pixels out of 1,260,000.

The ``r`` parameter is the pre-binning factor applied to each SCA before
placement: ``r=1`` gives a full-resolution (18000, 28000) mosaic, ``r=4`` gives
(4500, 7000) with 1024x1024 per-SCA blocks. It must divide 4096.
"""
import os

import numpy as np
from astropy.io import fits

from compile_rcs_trend import nan_superpixel

# Focal plane frame definition. These are the numbers from mosaic_plot_FPS.py,
# which agree with config/WFI_SCA_physical_centers.ecsv meta.
PIX_PER_MM = 100                      # 10 micron pixels
EXTENT_XMAX_MM = 140.0
EXTENT_XMIN_MM = -140.0
EXTENT_YMIN_MM = -110.0
EXTENT_YMAX_MM = 70.0

# Center of the frame in full-resolution pixels; 'i' is the row axis (y),
# 'j' the column axis (x). Always expressed at r=1.
MID_POINT = {"i": 11000, "j": 14000}

SCA_PIX = 4096                        # native SCA size after padding
SCA_WIDTH_MM = 40.88                  # physical SCA width, for plot labels

GEOMETRY_ECSV = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "..", "..", "config", "WFI_SCA_physical_centers.ecsv")


def load_geometry(ecsv=GEOMETRY_ECSV):
    """Read the canonical SCA center table.

    ``rotation_deg`` records the SCA's physical mounting rotation about the
    boresight, not an image-processing convention: SCAs 1, 2, 4, 5, 7, 8, 10,
    11, 13, 14, 16, 17 have their connecting side facing FPA +Y
    (``rotation_deg == 180``); the complementary six, 3, 6, 9, 12, 15, 18,
    have their connecting side facing FPA -Y (``rotation_deg == 0``). This
    physical fact is the basis for the two-class split that ``orient_frame``
    has to reason about when reproducing ``mosaic_plot_FPS``'s detector-frame
    flips.

    Returns
    -------
    dict
        ``{sca_number: (x_center_mm, y_center_mm, rotation_deg)}`` keyed by the
        1-18 MPA position, which is also the WFI detector number.
    """
    from astropy.table import Table

    table = Table.read(ecsv, format="ascii.ecsv")
    geom = {}
    for row in table:
        sca = int(str(row["label"]).replace("SCA", ""))
        geom[sca] = (float(row["x_center"]), float(row["y_center"]),
                     float(row["rotation"]))

    return geom


def mosaic_shape(r=1):
    """Shape of the mosaic frame at binning factor ``r``."""
    n_row = int((EXTENT_YMAX_MM - EXTENT_YMIN_MM) * PIX_PER_MM / r)
    n_col = int((EXTENT_XMAX_MM - EXTENT_XMIN_MM) * PIX_PER_MM / r)

    return (n_row, n_col)


def create_mosaic_frame(r=1, fill=np.nan, dtype=np.float32):
    """Empty (NaN-filled) mosaic frame."""
    return np.full(mosaic_shape(r), fill, dtype=dtype)


def pad_to_4096(frame):
    """NaN-pad a 4088x4088 science array out to the full 4096x4096 SCA size.

    The romancal L2 products have the 4 reference-pixel rows/columns per side
    trimmed off. Padding them back matters because 4088 does not divide by the
    binning factor, and because the placement math is defined on 4096.
    """
    n_row, n_col = frame.shape
    if (n_row, n_col) == (SCA_PIX, SCA_PIX):
        return frame

    if n_row != n_col or (SCA_PIX - n_row) % 2 != 0:
        raise ValueError(f"cannot symmetrically pad {frame.shape} to "
                         f"{SCA_PIX}x{SCA_PIX}")

    pad = (SCA_PIX - n_row) // 2

    return np.pad(frame.astype(np.float64), pad, mode="constant",
                  constant_values=np.nan)


def bin_frame(frame, r):
    """NaN-aware mean-bin an SCA frame down by ``r``."""
    if r == 1:
        return frame

    if SCA_PIX % r != 0:
        raise ValueError(f"binning factor r={r} does not divide {SCA_PIX}")

    return nan_superpixel(frame, r)


# Which array transform to apply to each SCA before placing it. Kept explicit
# and selectable because the correct choice depends on which coordinate frame
# the *input* product's rows/columns are stored in -- detector frame (native
# to the physical SCA, what mosaic_plot_FPS assumed) or science frame (the
# SOC convention, already in the mosaic's orientation) -- see orient_frame,
# which also documents the measurements that confirm it rather than assuming
# it.
ORIENTATIONS = ("identity", "mosaic_plot_fps", "mosaic_plot_fps_yflip",
                "fliplr", "flipud", "rot180")

# Both the quicklook and romancal L2 products are delivered in the SOC science
# frame, which by definition already matches the mosaic's orientation, so
# nothing is flipped. This is also independently confirmed, see orient_frame
# and plots/orientation_calibration.md.
DEFAULT_ORIENTATION = "identity"


def orient_frame(frame, rotation_deg, orientation=DEFAULT_ORIENTATION):
    """Flip an SCA frame into the mosaic's science-frame orientation.

    The default is ``identity`` -- no flip, for either mounting rotation. Both
    product types handled here (romancal L2 and quicklook) are delivered in
    the SOC *science* frame, which by definition already sits in the mosaic's
    orientation. ``mosaic_plot_FPS.placeImages``, by contrast, was written for
    the *detector* frame -- native to the physical SCA's readout electronics --
    and applies flips to convert it: mirror in x unconditionally, then mirror
    both axes when the SCA's connecting side faces FPA +Y (``rotation_deg ==
    180``; see ``load_geometry``). Applying those detector-frame flips to
    science-frame data would mirror every detector, which is exactly the
    failure mode the two measurements below caught.



    ``mosaic_plot_fps`` reproduces ``placeImages`` exactly: net, fliplr for the
    rot==0 SCAs (connecting side facing FPA -Y: 3, 6, 9, 12, 15, 18) and flipud
    for the other twelve (connecting side facing FPA +Y).
    ``mosaic_plot_fps_yflip`` is that with one further global flip in y, which
    reduces to identity for rot==180 and to a 180-degree rotation for rot==0.
    Both are kept so the calibration script can scan them, but neither should be
    used to build products from these science-frame inputs.
    """
    if orientation in ("mosaic_plot_fps", "mosaic_plot_fps_yflip"):
        out = frame[:, ::-1]
        if int(round(rotation_deg)) == 180:
            out = out[::-1, ::-1]
        if orientation == "mosaic_plot_fps_yflip":
            out = out[::-1, :]
        return out
    if orientation == "identity":
        return frame
    if orientation == "fliplr":
        return frame[:, ::-1]
    if orientation == "flipud":
        return frame[::-1, :]
    if orientation == "rot180":
        return frame[::-1, ::-1]

    raise ValueError(f"unknown orientation {orientation!r}; "
                     f"expected one of {ORIENTATIONS}")


def sca_placement(sca, r=1, geom=None):
    """Mosaic slice bounds ``(r1, r2, c1, c2)`` for one SCA at binning ``r``.

    The mosaic is the *view from the sky, looking down at the detectors*: in
    this right-handed system, +Z points from the sky through the detectors
    (the direction light travels), and the frame is drawn as that view would
    appear, with FPA -X to the right and FPA +Y up. Note the sign flip on x: since -X
    is to the right, increasing physical x runs toward *decreasing* column
    index; +y runs toward *increasing* row index, matching the
    ``origin="lower"`` display in ``plot_mpa_mosaic.py``.
    """
    geom = load_geometry() if geom is None else geom
    x_mm, y_mm, _ = geom[sca]

    row_offset = round(y_mm * PIX_PER_MM)
    col_offset = -round(x_mm * PIX_PER_MM)

    r1 = MID_POINT["i"] + row_offset - SCA_PIX // 2
    c1 = MID_POINT["j"] + col_offset - SCA_PIX // 2

    return int(r1 / r), int((r1 + SCA_PIX) / r), int(c1 / r), int((c1 + SCA_PIX) / r)


def build_mosaic(frames, r=4, geom=None, dtype=np.float32,
                 orientation=DEFAULT_ORIENTATION, prebinned=False):
    """Place per-SCA frames onto a single MPA mosaic.

    Parameters
    ----------
    frames : dict
        ``{sca_number: 2D array}``. Arrays may be 4088-trimmed or native 4096;
        they are padded and binned here. Missing SCAs simply stay NaN.
    r : int
        Binning factor. ``r=4`` reproduces the existing trend products.
    orientation : str
        See :func:`orient_frame`.
    prebinned : bool
        Set when ``frames`` already hold ``4096//r`` arrays, which lets a caller
        bin once and then place under several orientations cheaply.

    Returns
    -------
    ndarray
        Mosaic of shape ``mosaic_shape(r)``, NaN outside SCA footprints.
    """
    geom = load_geometry() if geom is None else geom
    mosaic = create_mosaic_frame(r, dtype=dtype)

    for sca, frame in sorted(frames.items()):
        if frame is None:
            continue
        if not prebinned:
            frame = bin_frame(pad_to_4096(frame), r)
        img = orient_frame(frame, geom[sca][2], orientation)
        r1, r2, c1, c2 = sca_placement(sca, r, geom)
        if img.shape != (r2 - r1, c2 - c1):
            raise ValueError(f"SCA {sca}: frame {img.shape} does not fit "
                             f"placement block {(r2 - r1, c2 - c1)}")
        mosaic[r1:r2, c1:c2] = img.astype(dtype)

    return mosaic


def build_sca_id_map(scas, r=4, geom=None):
    """Label array recording which SCA each mosaic pixel came from.

    Pixels outside every footprint are 0. Lets per-SCA statistics be computed
    on any mosaic (including the original h5, which carries no provenance).
    """
    geom = load_geometry() if geom is None else geom
    id_map = np.zeros(mosaic_shape(r), dtype=np.int16)

    for sca in sorted(scas):
        r1, r2, c1, c2 = sca_placement(sca, r, geom)
        id_map[r1:r2, c1:c2] = sca

    return id_map


def rebinned_block_slices(sca, rebin=5, r=4, geom=None, inset=2):
    """Row/column slices selecting one SCA's interior on a *rebinned* mosaic.

    The trend cubes are ``nan_superpixel(mosaic_r4, 5)`` -> (900, 1400), and the
    r=4 block bounds are not multiples of 5 (SCA 1 starts at row 2541, and
    2541/5 = 508.2). So the superpixels straddling a block edge mix two
    detectors, or mix a detector with the NaN gap. ``inset`` discards them:
    inset=2 costs 2 superpixels (~1 mm) per side and makes the remaining block
    unambiguously one SCA's.
    """
    r1, r2, c1, c2 = sca_placement(sca, r, geom)
    row0 = -(-r1 // rebin) + inset          # ceil division
    row1 = r2 // rebin - inset
    col0 = -(-c1 // rebin) + inset
    col1 = c2 // rebin - inset

    return slice(row0, row1), slice(col0, col1)


def mosaic_wcs(r=1):
    """A linear millimeter WCS for the mosaic frame.

    Purely descriptive -- nothing downstream depends on it -- but it makes the
    staged FITS files self-locating instead of bare pixel grids.
    """
    n_row, n_col = mosaic_shape(r)
    cdelt = r / PIX_PER_MM

    return {
        "WCSNAME": "MPA_mm",
        "CTYPE1": "MPAX-mm",
        "CTYPE2": "MPAY-mm",
        "CUNIT1": "mm",
        "CUNIT2": "mm",
        # x decreases with column: column 0 sits at EXTENT_XMAX_MM.
        "CRPIX1": 0.5,
        "CRVAL1": EXTENT_XMAX_MM,
        "CDELT1": -cdelt,
        "CRPIX2": 0.5,
        "CRVAL2": EXTENT_YMIN_MM,
        "CDELT2": cdelt,
    }


def write_mosaic_fits(mosaic, path, r=4, scas=(), meta=None, overwrite=True):
    """Write a mosaic with the image in HDU 1, EXTNAME='SCI'.

    The HDU layout matches what ``mosaic_plot_FPS.save_data_fits`` produced,
    because ``compile_rcs_trend.process_trending_run`` reads ``hdul[1].data``.
    Unlike the original we also record how the mosaic was built -- binning
    factor, pixel scale, and which SCAs contributed -- so the product can be
    audited without reference to the code that made it.
    """
    sci = fits.ImageHDU(np.asarray(mosaic, dtype=np.float32))
    sci.header["EXTNAME"] = "SCI"
    sci.header["MOSAIC_R"] = (int(r), "SCA pre-binning factor")
    sci.header["PIXMM"] = (r / PIX_PER_MM, "[mm] mosaic pixel scale")
    sci.header["NSCA"] = (len(scas), "number of SCAs placed")
    sci.header["SCALIST"] = (",".join(str(s) for s in sorted(scas)),
                             "MPA positions placed")
    for key, value in mosaic_wcs(r).items():
        sci.header[key] = value

    for key, value in (meta or {}).items():
        sci.header[key] = value

    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    fits.HDUList([fits.PrimaryHDU(), sci]).writeto(path, overwrite=overwrite)

    return path


def read_mosaic_fits(path):
    """Read back a mosaic written by :func:`write_mosaic_fits`."""
    with fits.open(path) as hdul:
        return np.array(hdul[1].data), dict(hdul[1].header)
