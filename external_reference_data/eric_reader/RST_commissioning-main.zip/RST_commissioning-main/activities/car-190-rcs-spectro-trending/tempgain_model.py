"""The temperature-dependent gain as a portable, form-named parameter file.

This module is the *interchange* between the free-standing thermal analysis and
the pipeline. It holds no fitting: ``fit_temperature_gain`` measures the gain,
writes one of these files once, and stage 2 reads it back to record a multiplier
in every calibrated product. Deliberately small, and depending only on numpy and
astropy, because both ends have to import it and neither may import the other --
``fit_temperature_gain`` pulls in scipy and the whole fit suite, which a stage-2
worker must not pay for.

The file names its own parametric form
--------------------------------------
Every model file carries ``form`` in its metadata, dispatched through
:func:`resolve_form` to an evaluator. An unknown form is a **refusal, not a
fallback**: silently defaulting would evaluate a future model's parameters
against today's polynomial and return multipliers that are wrong but entirely
plausible. The parameter *columns* are likewise named in the metadata rather
than assumed, so swapping in a better model means writing a new file and adding
an evaluator -- not editing the pipeline.

The one form that exists today, ``poly_pinned_v1``::

    G(T) = 1 + sum_k  alpha_k * ((T - t_nominal_k) / t_scale_k) ** power_k

with ``power_k`` read from ``param_powers``, never inferred from the column
name. That matters more than it looks: in ``fit_temperature_gain`` the in-memory
``alpha[g, j]`` multiplies ``u**(j+1)``, so the on-disk column ``alpha1``
multiplies ``u**1`` -- an off-by-one waiting to happen the first time a degree-3
file appears. Storing the exponent as data removes the question. Same reasoning
as ``optical_transformations.FPAAOIFit``, which stores its exponents as columns.

There is no constant term, by construction: the gain is **pinned to 1 at
``t_nominal_k``**, which is what makes it separable from the film amplitude
rather than degenerate with it. The arithmetic here is the same as
``fit_temperature_gain.gain_at``, which stays the fit suite's own evaluator; the
two are pinned together by a self-test assertion rather than by comment.

Evaluate at the LED's own temperature, never an epoch mean
----------------------------------------------------------
:meth:`TempGainModel.gain_grid` takes one temperature *per LED* and has no
mode that accepts a scalar for all six. An epoch is ~24 minutes, the six LEDs
are measured in sequence, and on a cooldown LED1 and LED6 are up to 0.8 K apart;
because sequence order is also wavelength order, an achromatic gain evaluated at
an epoch mean imprints a fake monotonic *chromatic* ramp. See
``housekeeping_trends`` module docstring.

Usage
-----
    import tempgain_model

    model = tempgain_model.TempGainModel.read("tempgain_model.ecsv")
    grid = model.gain_grid(temperature_per_led)      # (n_led, n_sca)
"""
import dataclasses
import datetime
import hashlib
import os

import numpy as np

import rcs_trend_config as cfg

# The only form implemented today. Named, not implicit, because the whole point
# of the file format is that a reader can tell which arithmetic to apply.
FORM_POLY_PINNED = "poly_pinned_v1"

# The nominal operating point and the unit scale of the polynomial argument.
# Defaults for reading an older file only -- a model file always carries its
# own, and the evaluator uses the file's values, never these.
DEFAULT_T_NOMINAL_K = 89.5
DEFAULT_T_SCALE_K = 10.0

GAIN_DEFINITION = ("G(T) = 1 + sum_k alpha_k * ((T - t_nominal_k)/t_scale_k)"
                   "**power_k, with power_k from param_powers. No constant "
                   "term: G(t_nominal_k) == 1 exactly, which is what makes the "
                   "gain separable from the thin-film fringe amplitude.")

# Fixed column order, so a file's columns do not depend on dict iteration.
AXIS_COLUMNS = ("sca", "led")
EXTRA_COLUMNS = ("derivation", "sigma_gain_hot")


def _eval_poly_pinned(params, powers, temperature, t_nominal, t_scale):
    """``1 + sum_k params[..., k] * u**powers[k]``, ``u = (T - t_nom)/scale``.

    ``params`` is ``(..., n_param)`` and ``temperature`` must broadcast against
    its leading shape, which is how one call evaluates the whole
    ``(n_led, n_sca)`` grid at six different temperatures.
    """
    params = np.asarray(params, float)
    unit = (np.asarray(temperature, float) - float(t_nominal)) / float(t_scale)
    out = np.ones(np.broadcast_shapes(params.shape[:-1], np.shape(unit)), float)
    for index, power in enumerate(powers):
        out = out + params[..., index] * unit ** float(power)

    return out


# name -> evaluator. Mirrors ``fit_film_thickness.D_BLOCKS``: a registry whose
# resolver names the legal values in its error, so a typo is a readable failure
# instead of a wrong number.
GAIN_FORMS = {FORM_POLY_PINNED: _eval_poly_pinned}


def resolve_form(name):
    """The evaluator a model file's ``form`` names.

    Refuses an unknown form rather than guessing. A model file whose form this
    build does not implement is not a file to be read approximately: its
    parameters mean something else.
    """
    if name in GAIN_FORMS:
        return GAIN_FORMS[name]

    raise ValueError(
        f"unknown temperature-gain form {name!r}; this build implements "
        f"{sorted(GAIN_FORMS)}. The form is refused rather than defaulted "
        f"because evaluating one model's parameters with another's arithmetic "
        f"returns plausible wrong multipliers.")


def file_sha256(path, chunk=1 << 20):
    """Hex sha256 of a file, read in chunks."""
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(chunk), b""):
            digest.update(block)

    return digest.hexdigest()


@dataclasses.dataclass
class TempGainModel:
    """A temperature-gain model as parameters per ``(SCA, LED)``, plus its form.

    The schema is per-(SCA, LED) even when the underlying fit was achromatic --
    then every LED in a row-block carries the same coefficients and the
    ``derivation`` column says so. Keeping the shape fixed means that improving
    the model from achromatic to genuinely chromatic changes a file, not any
    reader.

    ``params`` is ``(n_sca, n_led, n_param)`` in the order of ``param_names``,
    and ``param_powers`` gives each column's exponent. ``meta`` carries the
    whole file's metadata so provenance and caveats survive a round trip even
    for keys this class does not interpret.
    """

    sca_names: list                           # list[int], ascending
    led_names: list                           # list[str], cfg order
    params: np.ndarray                        # (n_sca, n_led, n_param)
    form: str = FORM_POLY_PINNED
    param_names: list = dataclasses.field(
        default_factory=lambda: ["alpha1", "alpha2"])
    param_powers: list = dataclasses.field(default_factory=lambda: [1, 2])
    t_nominal_k: float = DEFAULT_T_NOMINAL_K
    t_scale_k: float = DEFAULT_T_SCALE_K
    derivation: np.ndarray = None             # (n_sca, n_led) of str
    sigma_gain_hot: np.ndarray = None         # (n_sca, n_led)
    meta: dict = dataclasses.field(default_factory=dict)
    path: str = ""
    sha256: str = ""

    def __post_init__(self):
        self.sca_names = [int(v) for v in self.sca_names]
        self.led_names = [str(v) for v in self.led_names]
        self.params = np.asarray(self.params, float)
        shape = (len(self.sca_names), len(self.led_names),
                 len(self.param_names))
        if self.params.shape != shape:
            raise ValueError(f"params {self.params.shape} != {shape} "
                             f"(n_sca, n_led, n_param)")
        if len(self.param_powers) != len(self.param_names):
            raise ValueError(
                f"{len(self.param_names)} parameter name(s) but "
                f"{len(self.param_powers)} power(s); every parameter column "
                f"needs its exponent, which is what keeps alpha1 from being "
                f"read as the coefficient of u**0 or u**2")
        resolve_form(self.form)               # fail at construction, not at use
        if self.derivation is None:
            self.derivation = np.full(shape[:2], "unspecified", dtype=object)
        if self.sigma_gain_hot is None:
            self.sigma_gain_hot = np.full(shape[:2], np.nan)

    # ------------------------------------------------------------ evaluation

    @property
    def degree(self):
        """Number of free parameters per series (not necessarily a degree)."""
        return len(self.param_names)

    def _index(self, sca, led):
        try:
            row = self.sca_names.index(int(sca))
        except ValueError:
            raise KeyError(
                f"SCA {sca!r} is not in this model ({self.sca_names})") from None
        try:
            column = self.led_names.index(str(led))
        except ValueError:
            raise KeyError(
                f"{led!r} is not in this model ({self.led_names})") from None

        return row, column

    def gain(self, sca, led, temperature):
        """``G(T)`` for one detector and LED, at ``temperature`` in kelvin."""
        row, column = self._index(sca, led)
        evaluate = resolve_form(self.form)

        return evaluate(self.params[row, column], self.param_powers,
                        temperature, self.t_nominal_k, self.t_scale_k)

    def gain_grid(self, temperature, sca_names=None, led_names=None):
        """``(n_led, n_sca)`` of ``G(T_led)`` -- one temperature **per LED**.

        ``temperature`` is ``(n_led,)``: the temperature each LED was actually
        measured at. There is no scalar overload on purpose. Within one epoch
        the six LEDs span up to 0.8 K on a cooldown, and because sequence order
        is wavelength order, collapsing them to an epoch mean turns an
        achromatic gain into an apparent chromatic ramp.

        ``(n_led, n_sca)`` rather than the transpose to match the product's
        existing per-activity x per-SCA layout (``coverage/per_activity``).
        """
        leds = [str(v) for v in (led_names or self.led_names)]
        scas = [int(v) for v in (sca_names or self.sca_names)]
        temperature = np.asarray(temperature, float).ravel()
        if temperature.size != len(leds):
            raise ValueError(
                f"{temperature.size} temperature(s) for {len(leds)} LED(s). "
                f"The gain is evaluated at each LED's own temperature; an "
                f"epoch mean would imprint a fake chromatic ramp.")

        rows = [self._index(sca, leds[0])[0] for sca in scas]
        columns = [self._index(scas[0], led)[1] for led in leds]
        # (n_led, n_sca, n_param) against (n_led, 1) -> (n_led, n_sca)
        block = self.params[np.ix_(rows, columns)].transpose(1, 0, 2)
        evaluate = resolve_form(self.form)

        return evaluate(block, self.param_powers, temperature[:, None],
                        self.t_nominal_k, self.t_scale_k)

    # ---------------------------------------------------------------- the file

    def to_table(self):
        from astropy.table import Table

        n_sca, n_led = len(self.sca_names), len(self.led_names)
        table = Table()
        table["sca"] = np.repeat(self.sca_names, n_led)
        table["led"] = list(self.led_names) * n_sca
        for index, name in enumerate(self.param_names):
            table[name] = self.params[:, :, index].reshape(-1)
        table["derivation"] = [str(v) for v in
                               np.asarray(self.derivation).reshape(-1)]
        table["sigma_gain_hot"] = np.asarray(
            self.sigma_gain_hot, float).reshape(-1)

        meta = dict(self.meta)
        # Written last so the identifying keys always describe the arrays
        # actually in the table, whatever the caller put in ``meta``.
        meta.update(
            form=str(self.form),
            degree=int(self.degree),
            param_names=[str(n) for n in self.param_names],
            param_powers=[int(p) if float(p).is_integer() else float(p)
                          for p in self.param_powers],
            t_nominal_k=float(self.t_nominal_k),
            t_scale_k=float(self.t_scale_k),
            gain_definition=GAIN_DEFINITION,
        )
        meta.setdefault("comments", [])
        table.meta = meta

        return table

    def write(self, path):
        """Write the ECSV and record its sha256 on the model."""
        table = self.to_table()
        directory = os.path.dirname(os.path.abspath(path))
        os.makedirs(directory, exist_ok=True)
        table.write(path, format="ascii.ecsv", overwrite=True)
        self.path = str(path)
        self.sha256 = file_sha256(path)

        return path

    @classmethod
    def read(cls, path):
        """Read a model file back, including its own sha256.

        Metadata is read with defaults for the keys that could be absent from a
        file written by an earlier build, the same way ``ReferenceCard.read``
        does -- but *not* for ``form``, ``param_names`` or ``param_powers``.
        Those three are what the numbers mean, and a file that does not state
        them is not a file whose parameters can be evaluated.
        """
        from astropy.table import Table

        table = Table.read(path, format="ascii.ecsv")
        meta = dict(table.meta)
        for key in ("form", "param_names", "param_powers"):
            if key not in meta:
                raise ValueError(
                    f"{path!r} has no {key!r} in its metadata. A temperature-"
                    f"gain model file must state its parametric form and name "
                    f"its parameter columns and their exponents; without them "
                    f"the coefficients are unlabelled numbers.")

        param_names = [str(n) for n in meta["param_names"]]
        missing = [n for n in param_names if n not in table.colnames]
        if missing:
            raise ValueError(
                f"{path!r} names parameter column(s) {missing} in its metadata "
                f"that the table does not have (it has {table.colnames})")

        sca_names = sorted({int(v) for v in table["sca"]})
        led_names = []
        for value in table["led"]:
            if str(value) not in led_names:
                led_names.append(str(value))

        shape = (len(sca_names), len(led_names))
        params = np.full(shape + (len(param_names),), np.nan)
        derivation = np.full(shape, "unspecified", dtype=object)
        sigma = np.full(shape, np.nan)
        row_of = {sca: i for i, sca in enumerate(sca_names)}
        col_of = {led: j for j, led in enumerate(led_names)}
        for row in table:
            i, j = row_of[int(row["sca"])], col_of[str(row["led"])]
            params[i, j] = [float(row[n]) for n in param_names]
            if "derivation" in table.colnames:
                derivation[i, j] = str(row["derivation"])
            if "sigma_gain_hot" in table.colnames:
                sigma[i, j] = float(row["sigma_gain_hot"])
        if not np.all(np.isfinite(params)):
            n_bad = int(np.sum(~np.all(np.isfinite(params), axis=-1)))
            raise ValueError(
                f"{path!r} is missing parameters for {n_bad} (SCA, LED) "
                f"combination(s). The table must be complete over "
                f"{len(sca_names)} SCA(s) x {len(led_names)} LED(s); a hole "
                f"would silently become a NaN multiplier in every product.")

        return cls(
            sca_names=sca_names, led_names=led_names, params=params,
            form=str(meta["form"]), param_names=param_names,
            param_powers=[float(p) for p in meta["param_powers"]],
            t_nominal_k=float(meta.get("t_nominal_k", DEFAULT_T_NOMINAL_K)),
            t_scale_k=float(meta.get("t_scale_k", DEFAULT_T_SCALE_K)),
            derivation=derivation, sigma_gain_hot=sigma, meta=meta,
            path=str(path), sha256=file_sha256(path))

    # ------------------------------------------------------------ construction

    @classmethod
    def from_alpha(cls, alpha, sca_names, led_names=None, form=FORM_POLY_PINNED,
                   t_nominal_k=DEFAULT_T_NOMINAL_K,
                   t_scale_k=DEFAULT_T_SCALE_K, derivation="unspecified",
                   sigma_gain_hot=None, meta=None):
        """Build from a fitted ``alpha``, broadcasting an achromatic fit.

        ``alpha`` may be ``(n_sca, n_param)`` -- one achromatic coefficient set
        per detector, replicated across the LEDs -- or the full
        ``(n_sca, n_led, n_param)``. Replication is explicit here rather than
        implied by a missing axis downstream, and the ``derivation`` string is
        what records which of the two a given file holds.
        """
        led_names = list(led_names or cfg.LED_NAMES)
        alpha = np.asarray(alpha, float)
        if alpha.ndim == 2:
            params = np.repeat(alpha[:, None, :], len(led_names), axis=1)
        elif alpha.ndim == 3:
            params = alpha
        else:
            raise ValueError(f"alpha must be (n_sca, n_param) or "
                             f"(n_sca, n_led, n_param), got {alpha.shape}")

        n_param = params.shape[-1]
        names = [f"alpha{k + 1}" for k in range(n_param)]
        powers = [k + 1 for k in range(n_param)]
        shape = params.shape[:2]
        if np.isscalar(derivation) or isinstance(derivation, str):
            derivation = np.full(shape, str(derivation), dtype=object)
        if sigma_gain_hot is None:
            sigma = np.full(shape, np.nan)
        else:
            sigma = np.broadcast_to(
                np.asarray(sigma_gain_hot, float).reshape(-1, 1)
                if np.ndim(sigma_gain_hot) == 1 else
                np.asarray(sigma_gain_hot, float), shape).copy()

        return cls(sca_names=list(sca_names), led_names=led_names,
                   params=params, form=form, param_names=names,
                   param_powers=powers, t_nominal_k=float(t_nominal_k),
                   t_scale_k=float(t_scale_k), derivation=derivation,
                   sigma_gain_hot=sigma, meta=dict(meta or {}))


def utc_now():
    return datetime.datetime.now(
        datetime.timezone.utc).isoformat(timespec="seconds")


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------

def self_test(verbose=True):
    """No data, no credentials. Pins the five things a wrong file looks like."""
    import tempfile

    failures = []

    def check(name, condition, detail=""):
        if condition:
            if verbose:
                print(f"  ok   {name}")
        else:
            failures.append(name)
            print(f"  FAIL {name} {detail}")

    if verbose:
        print("  -- tempgain_model")

    # An unknown form must name the legal ones rather than default.
    try:
        resolve_form("quadratic")
        check("an unknown form is refused", False, "no exception")
    except ValueError as error:
        check("an unknown form is refused and names the legal ones",
              FORM_POLY_PINNED in str(error), str(error))

    rng = np.random.default_rng(4)
    sca_names = list(range(1, 19))
    alpha = rng.normal(0.0, 0.01, size=(18, 2))
    model = TempGainModel.from_alpha(alpha, sca_names,
                                     derivation="achromatic-per-sca")

    check("G is exactly 1 at the nominal point",
          model.gain(1, "LED1", model.t_nominal_k) == 1.0,
          str(model.gain(1, "LED1", model.t_nominal_k)))

    # The same arithmetic as the fitter's own evaluator, or the two have drifted.
    import fit_temperature_gain as tg

    want = float(tg.gain_at(dict(alpha=alpha[[3]],
                                 t_nominal=model.t_nominal_k), 124.0))
    got = float(model.gain(sca_names[3], "LED3", 124.0))
    check("matches fit_temperature_gain.gain_at to round-off",
          abs(got - want) < 1e-12, f"{got} vs {want}")

    # param_powers is data, not decoration: swapping them must change the
    # answer, which is what proves the exponent is read from the file.
    swapped = TempGainModel(
        sca_names=sca_names, led_names=list(cfg.LED_NAMES),
        params=model.params, param_names=["alpha1", "alpha2"],
        param_powers=[2, 1])
    check("param_powers is honoured, not inferred from the column name",
          abs(float(swapped.gain(sca_names[3], "LED3", 124.0))
              - got) > 1e-6)

    # The whole point of the grid API: six LEDs, six temperatures, six answers.
    temperature = np.array([124.0, 123.5, 123.0, 122.5, 122.0, 121.5])
    grid = model.gain_grid(temperature)
    check("gain_grid is (n_led, n_sca)", grid.shape == (6, 18),
          str(grid.shape))
    check("gain_grid evaluates each LED at its own temperature",
          len({round(float(v), 12) for v in grid[:, 0]}) == 6,
          str(grid[:, 0]))
    check("and agrees with the scalar accessor",
          abs(float(grid[2, 3]) - float(model.gain(sca_names[3], "LED3",
                                                         123.0))) < 1e-14)
    try:
        model.gain_grid(124.0)
        check("a scalar temperature is refused", False, "no exception")
    except ValueError as error:
        check("a scalar temperature is refused",
              "own temperature" in str(error), str(error))

    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "tempgain_model.ecsv")
        model.meta["provisional"] = True
        model.write(path)
        back = TempGainModel.read(path)
        check("round-trips 108 rows of parameters exactly",
              np.array_equal(back.params, model.params))
        check("round-trips the form, powers and pinning",
              (back.form, list(back.param_powers), back.t_nominal_k,
               back.t_scale_k) == (model.form, [1.0, 2.0],
                                   model.t_nominal_k, model.t_scale_k),
              f"{back.form} {back.param_powers}")
        check("round-trips the derivation column",
              set(np.asarray(back.derivation).reshape(-1))
              == {"achromatic-per-sca"})
        check("carries uninterpreted meta through unchanged",
              back.meta.get("provisional") is True)
        check("records its own sha256",
              back.sha256 == file_sha256(path) and len(back.sha256) == 64)
        check("the file has one row per (SCA, LED)",
              len(back.sca_names) * len(back.led_names) == 108)

        # A file that does not say what its numbers mean is not readable.
        from astropy.table import Table

        table = Table.read(path, format="ascii.ecsv")
        del table.meta["param_powers"]
        bare = os.path.join(tmp, "bare.ecsv")
        table.write(bare, format="ascii.ecsv", overwrite=True)
        try:
            TempGainModel.read(bare)
            check("a file without param_powers is refused", False, "no error")
        except ValueError as error:
            check("a file without param_powers is refused",
                  "param_powers" in str(error), str(error))

        # A hole in the table would become a NaN multiplier in every product.
        table = Table.read(path, format="ascii.ecsv")
        holed = os.path.join(tmp, "holed.ecsv")
        table[1:].write(holed, format="ascii.ecsv", overwrite=True)
        try:
            TempGainModel.read(holed)
            check("an incomplete table is refused", False, "no exception")
        except ValueError as error:
            check("an incomplete table is refused",
                  "missing parameters" in str(error), str(error))

    print(f"tempgain_model.self_test: "
          f"{'ok' if not failures else 'FAILED'} ({len(failures)} failure(s))")

    return not failures


if __name__ == "__main__":
    import sys

    sys.exit(0 if self_test() else 1)
