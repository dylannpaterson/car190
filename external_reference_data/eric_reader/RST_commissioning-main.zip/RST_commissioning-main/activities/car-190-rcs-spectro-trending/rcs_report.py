"""The text log of what a trend set actually contains.

Every number in a digest is conditioned on things that are not themselves in the
digest's columns: which CAR and decon cycle each epoch belongs to, where the ACM
moved and whether the step across it was fitted or modelled, which electronics
side ran, which photodiode readings were refused as denominators, and how many
detectors each product really holds.  Each of those is already printed somewhere
during a run, scattered through several hundred lines of progress output.  This
module writes them to one file so they can be read after the fact, diffed
between runs, and attached to a report.

Deliberately text only, and deliberately free of matplotlib: it is imported by
``make_sca_digests.py`` on the headless batch nodes where the figure path is
switched off, and an import of ``digest_plots`` there would be a hard failure for
the sake of a log file.  It also does not import ``make_sca_digests`` -- that
would be a cycle -- so the series object is read by attribute.

Every section returns ``list[str]``, so a caller can take one section without the
rest::

    print("\\n".join(rcs_report.acm_move_log(series)))

and ``write_report`` is just the composition of all of them.
"""
from datetime import datetime

import numpy as np

import rcs_fsutil
import rcs_trend_config as cfg
from rcs_acm import decon_episodes

LED_NAMES = cfg.LED_NAMES
N_SCAS = cfg.N_SCAS

RULE = "=" * 78
THIN = "-" * 78


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _heading(text):
    return [RULE, text, RULE]


def _stamp(value):
    """A timestamp as a fixed-width string, tolerating a missing one."""
    if value is None:
        return "(no timestamp)".ljust(19)
    try:
        return value.strftime("%Y-%m-%dT%H:%M")
    except AttributeError:
        return str(value)[:19]


def _label(value, absent="(unannotated)"):
    """A category name, with the empty string spelled out rather than blank.

    An unannotated epoch is a real state -- products written before
    ``annotate_h5`` existed carry no ``car_label`` or ``decon_cycle`` -- and an
    empty cell in a report reads as a formatting slip instead of as a fact about
    the input.
    """
    return value if value else absent


def _spread(values):
    """``min .. max`` over finite entries, or a note that there are none."""
    finite = np.asarray([v for v in np.ravel(values) if np.isfinite(v)],
                        dtype=float)
    if not len(finite):
        return "no finite values"
    if len(finite) == 1 or finite.min() == finite.max():
        return f"{finite[0]:.6f}"
    return f"{finite.min():.6f} .. {finite.max():.6f}"


# ---------------------------------------------------------------------------
# Sections
# ---------------------------------------------------------------------------

def inventory(series):
    """What is in this set: epochs per CAR, per decon cycle, and the time span.

    Grouped by ``(car_label, decon_cycle)`` because that pair, not either alone,
    is what a trend is comparable within: a decon resets the film, and the two
    CARs run different activity sequences and different ACM positions.
    """
    lines = _heading("INVENTORY")
    names = list(series.names)
    lines.append(f"{len(names)} epoch(s), stage {series.stage}, product_kind "
                 f"{series.product_kind}, bin_factor {series.bin_factor}")

    corrections = ", ".join(series.corrections_applied) or "none"
    lines.append(f"corrections in the numbers: {corrections} "
                 f"(applied at: {series.corrections_applied_at})")

    groups = {}
    for index, name in enumerate(names):
        key = (_label(series.car_labels[index]), _label(series.decon_cycles[index]))
        groups.setdefault(key, []).append(index)

    lines.append("")
    lines.append(f"{'CAR':<14} {'decon':<14} {'epochs':>7} {'passes':>13}  "
                 f"first .. last")
    for (car, decon), indices in sorted(groups.items()):
        passes = np.asarray([series.pass_numbers[i] for i in indices])
        finite = passes[np.isfinite(passes)] if passes.dtype.kind == "f" else passes
        span = (f"{int(finite.min())}-{int(finite.max())}" if len(finite)
                else "unknown")
        first = _stamp(series.timestamps[indices[0]])
        last = _stamp(series.timestamps[indices[-1]])
        lines.append(f"{car:<14} {decon:<14} {len(indices):>7} {span:>13}  "
                     f"{first} .. {last}")

    unannotated = sum(1 for index in range(len(names))
                      if not (series.car_labels[index] and series.decon_cycles[index]))
    if unannotated:
        lines.append("")
        lines.append(f"NOTE: {unannotated} epoch(s) carry no car_label and/or "
                     f"decon_cycle attribute.")
        lines.append("      Those predate annotate_h5; they are grouped as "
                     "(unannotated) above, which is")
        lines.append("      not the same as belonging to one cycle. Re-annotate "
                     "before splitting a trend on it.")

    span_hours = float(np.nanmax(series.time_hours) - np.nanmin(series.time_hours))
    lines.append("")
    lines.append(f"total span {span_hours:.1f} h ({span_hours / 24.0:.1f} d), "
                 f"LVDT {np.nanmin(series.acm_lvdt):.1f} .. "
                 f"{np.nanmax(series.acm_lvdt):.1f} over "
                 f"{series.n_segments} ACM configuration(s)")
    return lines


def acm_move_log(series):
    """Every ACM reconfiguration, and how the step across it was obtained.

    The method matters as much as the value.  A ``bridge`` step was measured from
    the epochs either side; a ``multiplier`` step was *predicted* from the LVDT
    and the linear coefficient, which is a model, not a measurement; a ``none``
    step is unity, i.e. a known discontinuity left in the output.  All three
    appear in real runs -- a segment with one epoch cannot be bridged -- so a
    reader has to be told which one produced each number.
    """
    lines = _heading("ACM RECONFIGURATIONS")
    names = list(series.names)
    moves = list(series.moves)

    lines.append(f"detection threshold |dLVDT| >= {series.move_min_delta:.0f} "
                 f"counts, sign-independent")
    lines.append(f"worst fractional LVDT travel from a segment reference: "
                 f"{series.max_fractional_travel:.6f} "
                 f"(warns above {cfg.ACM_TRAVEL_WARN:.2f})")

    if not moves:
        lines.append("")
        lines.append("No move above threshold: one ACM configuration, no step "
                     "to solve, and the")
        lines.append("digests carry no bridge_* metadata.")
        return lines

    for boundary, move in enumerate(moves):
        lines.append("")
        lines.append(THIN)
        index = move.index
        lines.append(f"boundary {boundary + 1} of {len(moves)}: at epoch "
                     f"{index + 1} of {len(names)}")
        lines.append(f"  {move.describe()}")
        if move.manual:
            lines.append("  ASSERTED, NOT DETECTED: the LVDT shows no move "
                         "here. A fitted step that comes")
            lines.append("  back at 1.0 is therefore a null test of the "
                         "fitter, not a measurement of the ACM.")
        elif move.crosses_zero:
            lines.append("  Crosses zero: the linear correction has no "
                         "validity across this move, only a")
            lines.append("  fitted bridge does.")
        lines.append(f"  last epoch before: {index:>4}  "
                     f"{_stamp(series.timestamps[index - 1])}  "
                     f"{names[index - 1]}")
        lines.append(f"  first epoch after: {index + 1:>4}  "
                     f"{_stamp(series.timestamps[index])}  {names[index]}")
        gap = float(series.time_hours[index] - series.time_hours[index - 1])
        lines.append(f"  cadence gap across the move: {gap:.2f} h")

        steps = [series.steps[sca][boundary] for sca in sorted(series.steps)
                 if len(series.steps[sca]) > boundary]
        if not steps:
            lines.append("  no bridge step recorded (bridging disabled, or no "
                         "per-SCA response available)")
            continue

        methods = {}
        for sca, step in zip(sorted(series.steps), steps):
            methods.setdefault(step.method, []).append(sca)
        for method, scas in sorted(methods.items()):
            values = [s.value for s in steps if s.method == method]
            lines.append(f"  method {method:<11} {len(scas):>2}/{len(steps)} "
                         f"SCA(s), step {_spread(values)}")
        note = next((s.note for s in steps if s.note), "")
        if note:
            lines.append(f"  note: {note}")

        fitted = [s for s in steps if s.is_fitted]
        if fitted:
            lines.append(f"  stat error {_spread([s.stat_error for s in fitted])}"
                         f", epochs used {min(s.n_epochs_used for s in fitted)}"
                         f"-{max(s.n_epochs_used for s in fitted)} "
                         f"({fitted[0].n_early} early, {fitted[0].n_late} late)")
            spread = [s.led_spread for s in fitted]
            lines.append(f"  per-LED spread {_spread(spread)}")
            # The spread is quoted in the digest metadata as a systematic to add
            # in quadrature, and on real data it has been one LED rather than
            # scatter over six -- which overstates the random part and hides the
            # systematic. Naming the LED is what makes that checkable here.
            worst = max(fitted, key=lambda s: s.led_spread
                        if np.isfinite(s.led_spread) else -np.inf)
            if np.isfinite(worst.led_spread) and worst.led_spread > 0:
                offsets = np.asarray(worst.per_led, dtype=float) - worst.value
                extreme = int(np.nanargmax(np.abs(offsets)))
                lines.append(f"  widest per-LED estimate is "
                             f"{LED_NAMES[extreme]} at {offsets[extreme]:+.4f} "
                             f"from the joint step; check whether the spread is "
                             f"one LED")
                lines.append("  before quoting it as an error bar.")
    return lines


def side_swap_log(series):
    """Which MCE side ran each epoch, and where it changed.

    This has its own section because of how it failed before: the side used to
    be read from an ``_MCEB`` marker in the filename, which flight products
    never carry, so every flight epoch was silently side A and the 1.5-6 %
    per-LED B-side corrections were never applied.  A set that is entirely one
    side is the normal case and is still worth stating, because the alternative
    -- a run that silently assumed it -- looks identical in the digests.
    """
    lines = _heading("MCE SIDE")
    sides = list(series.mce_sides) or ["A"] * len(series.names)
    names = list(series.names)
    sources = list(getattr(series, "mce_side_sources", []))
    distinct = sorted(set(sides))

    for side in distinct:
        count = sides.count(side)
        lines.append(f"side {side}: {count} epoch(s)")

    # Where the side came from, not just what it was: "A" from an attribute and
    # "A" from --assume-side give identical digests, and only one of them is a
    # measurement. This is the question the section exists to answer, so it is
    # answered here rather than deferred to "check the products".
    lines.append("")
    if sources:
        counts = {}
        for source in sources:
            counts[source or "(unrecorded)"] = counts.get(source or "(unrecorded)", 0) + 1
        for source, count in sorted(counts.items()):
            lines.append(f"  source {source:<28} {count:>4} epoch(s)")
        assumed = sum(count for source, count in counts.items()
                      if source.startswith("assumed") or source == "(unrecorded)")
        if assumed:
            lines.append("")
            lines.append(f"  {assumed} epoch(s) ASSUMED rather than recorded. "
                         f"The side decides which photodiode")
            lines.append("  reference an epoch is gauged to and which side of "
                         "the side bridge it sits on,")
            lines.append("  so a wrong label misplaces a chromatic step of "
                         "several percent. batch/side_witness.py")
            lines.append("  checks the labels against the LED map and the "
                         "photodiode witnesses.")
    else:
        lines.append("  the side's provenance was not carried into this series; "
                     "check mce_side_source")
        lines.append("  in the products before trusting the side.")

    if len(distinct) == 1:
        lines.append("")
        lines.append("One side throughout, so no per-LED discontinuity from a "
                     "side swap is possible")
        lines.append("inside this set.")
        return lines

    lines.append("")
    lines.append("SIDE CHANGES WITHIN THE SET, each bridged by one step per "
                 "LED common to every SCA:")
    for index in range(1, len(sides)):
        if sides[index] != sides[index - 1]:
            lines.append(f"  epoch {index + 1:>4}  {sides[index - 1]} -> "
                         f"{sides[index]}  "
                         f"{_stamp(series.timestamps[index])}  {names[index]}")
    steps = list(getattr(series, "side_steps", []) or [])
    if not steps:
        lines.append("  NOT BRIDGED in this run: the swap is in the output at "
                     "its full chromatic size.")
        return lines
    for step in steps:
        lines.append("")
        lines.append(f"  side bridge at epoch {step.boundary + 1} "
                     f"({step.transition}): method {step.method}"
                     + (f" -- {step.note}" if step.method != "side" else ""))
        if step.method != "side":
            continue
        lines.append(f"    fitted over +-{step.window_hours:g} h, degree "
                     f"{step.degree}, {step.n_early} early / {step.n_late} late "
                     f"epochs, {step.n_sca} SCAs; {step.n_choices} fit "
                     f"choice(s) accepted for the systematic")
        lines.append("    step (multiplies the EARLY side; the present side "
                     "is 1) and total error:")
        total = step.total_error
        lines.append("      " + "  ".join(
            f"{led} {step.value[i]:.5f}+-{total[i]:.5f}"
            for i, led in enumerate(LED_NAMES)))
        ratio = step.pattern_ratio
        lines.append(f"    illumination-pattern test: per-SCA achromatic offset "
                     f"rms {step.pattern_rms * 1e5:.1f}e-5 vs "
                     f"{step.pattern_noise * 1e5:.1f}e-5 from noise "
                     f"({ratio:.2f}x)"
                     + (" -- consistent with no pattern change"
                        if np.isfinite(ratio) and ratio < 3.0 else
                        " -- LARGER than noise; read side_bridge_this_sca_*"))
        lines.append("    it absorbs the electronics, LED drive and photodiode "
                     "at once (the photodiode is")
        lines.append("    re-based to 1 at each side's first epoch). The TVAC "
                     "B-side table is not applied;")
        lines.append("    in this gauge it would read " + "  ".join(
            f"{led} {1 / cfg.B_SIDE_CORRECTIONS[led]:.4f}" for led in LED_NAMES))
    return lines


def decon_log(series):
    """Decon-cycle transitions, which reset the film and so break a trend.

    A decon is not a calibration change, it is a change to the thing being
    measured: contaminant that accumulated on the cold optics is driven off, so
    film thickness restarts.  Fitting growth across a cycle boundary fits a
    sawtooth with a straight line.
    """
    lines = _heading("DECON CYCLES")
    cycles = list(series.decon_cycles)
    names = list(series.names)

    counts = {}
    for cycle in cycles:
        counts[_label(cycle)] = counts.get(_label(cycle), 0) + 1
    for cycle, count in sorted(counts.items()):
        lines.append(f"{cycle:<16} {count:>4} epoch(s)")

    # The label totals above and the episode count below are not the same
    # quantity, and only diverge in the case that matters: a decon label that
    # recurs after an intervening cycle owns two separate films, so "decon1:
    # 38 epochs" can mean two episodes that must never share a t=0. Both are
    # printed because the totals are what a reader has been quoting, and the
    # episode count is what a per-episode analysis has to use.
    episodes = decon_episodes(cycles)
    lines.append("")
    lines.append(f"{len(episodes)} film-growth episode(s) "
                 f"(contiguous runs, so a recurring label opens a new one):")
    for index, episode in enumerate(episodes, start=1):
        lines.append(f"  episode {index:>2}  {_label(episode['key']):<16} "
                     f"epochs {episode['first'] + 1}-{episode['last'] + 1} "
                     f"({episode['n']})  t=0 at {names[episode['first']]}")

    transitions = [index for index in range(1, len(cycles))
                   if cycles[index] != cycles[index - 1]]
    if not transitions:
        lines.append("")
        lines.append("No transition within the set: film growth may be fitted "
                     "across the whole span.")
        return lines

    lines.append("")
    lines.append("TRANSITIONS -- film growth must not be fitted across these:")
    for index in transitions:
        lines.append(f"  epoch {index + 1:>4}  "
                     f"{_label(cycles[index - 1])} -> {_label(cycles[index])}  "
                     f"{_stamp(series.timestamps[index])}  {names[index]}")
    return lines


def photodiode_log(series):
    """Where the photodiode denominators came from, and which were refused.

    ``pd_net`` divides into every response, so a collapsed one is not a small
    error: measured pedestal is ~0.1164 V against 0.347-0.396 V illuminated, so
    a bad pedestal leaves ``pd_net`` near the 0.01 V floor and a factor of tens
    -- indistinguishable from a real instrument event.  A refused reading is
    NaN in the digest by decision, and this section is what says so; without it
    the NaN reads as missing data.
    """
    lines = _heading("PHOTODIODE")
    lines.append(f"denominators read from: {series.photodiode_source}")
    flagged = list(series.photodiode_flagged)
    unflaggable = series.photodiode_source == "dictionary"

    if unflaggable:
        lines.append("")
        lines.append("The legacy positional mirror carries no validity flag, so "
                     "no reading here could be")
        lines.append("refused: these epochs are 'valid' only in the sense that "
                     "nothing contradicted them.")
        lines.append("Prefer the product's keyed photodiode/per_activity group "
                     "(the default).")

    if not flagged:
        lines.append("")
        if unflaggable:
            # Not "no epoch was flagged". The test could not run on this source,
            # and reporting a clean result for a check that never executed is
            # the specific way a log stops being evidence.
            lines.append(f"NOT CHECKED: a {cfg.PD_MIN_NET} V floor on pd_net is "
                         f"only enforced where the product")
            lines.append("reports validity, which this source does not. Absence "
                         "of flags here is absence of")
            lines.append("a check, not a clean result.")
        else:
            lines.append(f"No epoch had a pd_net the product flagged invalid "
                         f"(floor {cfg.PD_MIN_NET} V).")
        return lines

    lines.append("")
    lines.append(f"{len(flagged)} epoch(s) FLAGGED -- the affected LEDs are NaN "
                 f"in every SCA of the digest,")
    lines.append("not left uncorrected, because an uncorrected point inside a "
                 "corrected series is")
    lines.append("worse than a missing one:")
    for name in flagged:
        lines.append(f"  {name}")
    return lines


def coverage_log(paths, min_scas=None):
    """Per-product detector coverage, read from the products themselves.

    Separate from the rest because it is the one thing the series object does not
    carry: by the time a digest exists the arrays have already been reduced to
    per-SCA scalars, and an SCA that was never downloaded is indistinguishable
    from one that was downloaded and is NaN.  Takes paths, not a series, so it
    also works on a directory nothing has been digested from yet.
    """
    import rcs_products

    min_scas = cfg.MIN_SCAS if min_scas is None else int(min_scas)
    lines = _heading("COVERAGE")
    if not paths:
        lines.append("not inspected: no product paths were supplied.")
        return lines

    short, unreadable = [], []
    for path in paths:
        try:
            covered = int(np.sum(rcs_products.coverage_from_h5(path)))
        except (OSError, KeyError, ValueError) as error:
            unreadable.append((path, f"{type(error).__name__}: {error}"))
            continue
        if covered < min_scas:
            short.append((path, covered))

    lines.append(f"{len(paths)} product(s), {len(paths) - len(short) - len(unreadable)}"
                 f" with >= {min_scas} of {N_SCAS} SCAs")
    if short:
        lines.append("")
        lines.append("SHORT -- a listing truncated by MAST load streams what it "
                     "was given, and the")
        lines.append("product records nothing about being short. "
                     "batch/triage_products.py --move-degraded")
        lines.append("relocates these so the batch worker rebuilds them:")
        for path, covered in short:
            lines.append(f"  {covered:>3}/{N_SCAS}  {path}")
    for path, error in unreadable:
        lines.append(f"  UNREADABLE  {path}: {error}")
    return lines


# ---------------------------------------------------------------------------
# Composition
# ---------------------------------------------------------------------------

def report_lines(series, paths=(), min_scas=None, command=""):
    """Every section, in reading order."""
    lines = [RULE,
             "RCS TRENDING RUN LOG",
             RULE,
             f"written      {datetime.now().strftime('%Y-%m-%dT%H:%M:%S')}",
             f"schema       {cfg.SCHEMA_VERSION}"]
    if command:
        lines.append(f"command      {command}")
    lines.append("")
    lines.append("What is here is everything a digest's numbers are conditioned "
                 "on but does not")
    lines.append("itself contain: which CAR and decon cycle each epoch belongs "
                 "to, where the ACM")
    lines.append("moved and whether the step across it was measured or "
                 "modelled, which electronics")
    lines.append("side ran, which photodiode readings were refused, and how "
                 "many detectors each")
    lines.append("product holds.")
    lines.append("")

    for section in (inventory(series), acm_move_log(series),
                    side_swap_log(series), decon_log(series),
                    photodiode_log(series)):
        lines.extend(section)
        lines.append("")
    lines.extend(coverage_log(paths, min_scas=min_scas))
    lines.append("")
    return lines


def write_report(path, series, paths=(), min_scas=None, command=""):
    """Write the log, atomically, and return the path.

    Atomic like every other writer in this pipeline: a report half-written by an
    interrupted run is worse than no report, because it looks complete.
    """
    import os

    path = str(path)
    directory = os.path.dirname(os.path.abspath(path))
    os.makedirs(directory, exist_ok=True)
    temporary = f"{path}.tmp-{os.getpid()}"
    with open(temporary, "w") as handle:
        handle.write("\n".join(report_lines(series, paths=paths,
                                            min_scas=min_scas,
                                            command=command)))
        handle.write("\n")
    rcs_fsutil.replace(temporary, path)
    return path


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------

def self_test(verbose=True):
    """Check that the log reports the conditioning facts, not just formats them.

    The failure mode worth testing is a section that renders without error while
    omitting the thing it exists to say -- a modelled bridge step presented like
    a fitted one, a flagged photodiode epoch left out, an asserted segment break
    shown as a detected move.  Each of those reads as a clean report.
    """
    import types

    failures = []

    def check(name, condition):
        if not condition:
            failures.append(name)
        if verbose:
            print(f"  {'ok  ' if condition else 'FAIL'} {name}")

    class Step:
        def __init__(self, method, value, note=""):
            self.boundary = 2
            self.boundary_time = 50.0
            self.value = value
            self.stat_error = 0.001
            self.per_led = np.array([value + 0.004] + [value] * 5)
            self.rms_early = 0.01
            self.rms_late = 0.002
            self.n_epochs_used = 6
            self.n_early = 3
            self.n_late = 3
            self.method = method
            self.note = note

        @property
        def led_spread(self):
            return float(np.ptp(self.per_led))

        @property
        def is_fitted(self):
            return self.method == "bridge"

    class Move:
        def __init__(self, index, before, after, manual=False):
            self.index = index
            self.lvdt_before = before
            self.lvdt_after = after
            self.manual = manual

        @property
        def delta(self):
            return self.lvdt_after - self.lvdt_before

        @property
        def crosses_zero(self):
            return self.lvdt_before * self.lvdt_after < 0

        @property
        def kind(self):
            return "manual" if self.manual else (
                "deploy" if self.crosses_zero else "reposition")

        def describe(self):
            tail = "  (asserted, not detected)" if self.manual else ""
            return (f"{self.kind:<10} LVDT {self.lvdt_before:+9.1f} -> "
                    f"{self.lvdt_after:+9.1f}  delta {self.delta:+9.1f}{tail}")

    n_epoch = 5
    series = types.SimpleNamespace(
        names=[f"e{i}.h5" for i in range(n_epoch)],
        timestamps=[datetime(2026, 9, 10 + i) for i in range(n_epoch)],
        pass_numbers=np.arange(1, n_epoch + 1),
        car_labels=["CAR190", "CAR190", "", "CAR216", "CAR216"],
        decon_cycles=["decon1", "decon1", "decon1", "decon2", "decon2"],
        time_hours=np.arange(n_epoch, dtype=float) * 24.0,
        acm_lvdt=np.array([7559.0, 7559.0, -2815.0, -2815.0, -5232.0]),
        segment=np.array([0, 0, 1, 1, 2]),
        raw={}, moves=[Move(2, 7559.0, -2815.0), Move(4, -2815.0, -5232.0)],
        move_min_delta=500.0, max_fractional_travel=0.0005,
        reference_lvdt={}, steps={}, factors={}, scans={}, accepted={},
        systematic={}, product_kind="per_sca", stage="calibrated",
        bin_factor=16, mce_sides=["A", "A", "A", "B", "B"],
        mce_side_sources=["attribute", "attribute", "assumed", "attribute",
                          "attribute"],
        corrections_applied=("photodiode", "side", "acm"),
        corrections_applied_at="stage2",
        photodiode_source="photodiode/per_activity",
        photodiode_flagged=("e3.h5",),
        n_segments=3)
    series.steps = {f"SCA{i}": [Step("bridge", 1.037), Step("multiplier", 1.004,
                                note="fewer than 2 epochs inside the window")]
                    for i in range(1, 4)}

    text = "\n".join(report_lines(series))

    check("inventory splits the two CARs",
          "CAR190" in text and "CAR216" in text)
    check("an unannotated epoch is named, not left blank",
          "(unannotated)" in text and "predate annotate_h5" in text)
    # The decisive one: a modelled step must not be presentable as a measured
    # one. Both methods are in this series, so both names have to appear.
    check("the modelled boundary says 'multiplier'", "method multiplier" in text)
    check("the measured boundary says 'bridge'", "method bridge" in text)
    check("the multiplier's reason is carried through",
          "fewer than 2 epochs inside the window" in text)
    check("a zero-crossing move is called out",
          "Crosses zero" in text)
    check("the per-LED spread names its widest LED",
          "widest per-LED estimate is LED1" in text)
    check("the side change is listed", "A -> B" in text)
    check("an assumed side is distinguished from a recorded one",
          "source assumed" in text and "ASSUMED rather than recorded" in text)
    # The vacuous-clean-result check: the legacy photodiode mirror cannot be
    # validity-checked at all, so a report that says "none flagged" there is
    # reporting a check it never ran.
    series.photodiode_source, series.photodiode_flagged = "dictionary", ()
    check("an unrunnable photodiode check is not reported as clean",
          "NOT CHECKED" in "\n".join(photodiode_log(series)))
    series.photodiode_source = "photodiode/per_activity"
    check("a photodiode check that did run and found nothing says so",
          "No epoch had a pd_net" in "\n".join(photodiode_log(series)))
    series.photodiode_flagged = ("e3.h5",)
    check("the decon transition is listed", "decon1 -> decon2" in text)
    check("the flagged photodiode epoch is named",
          "e3.h5" in text and "FLAGGED" in text)
    check("coverage says it was not inspected when no paths are given",
          "no product paths were supplied" in text)

    # A manual break must read as an assertion, not a measurement: the fitted
    # step across one is a null test, and a reader who takes it for a real move
    # reads the fitter's noise floor as an ACM effect.
    series.moves = [Move(2, -2815.2, -2814.5, manual=True)]
    series.steps = {f"SCA{i}": [Step("bridge", 1.0002)] for i in range(1, 4)}
    manual_text = "\n".join(acm_move_log(series))
    check("a manual break is marked asserted",
          "ASSERTED, NOT DETECTED" in manual_text)
    check("and is named a null test", "null test" in manual_text)

    # No moves at all is the single-configuration case, not an error.
    series.moves, series.steps = [], {}
    check("no moves is reported, not raised",
          "no step" in "\n".join(acm_move_log(series)))

    if verbose:
        print(f"\nrcs_report self-test: "
              f"{'all passed' if not failures else f'{len(failures)} FAILED'}")
    return not failures


if __name__ == "__main__":
    raise SystemExit(0 if self_test() else 1)
