# RCS trending products: quick reference

- Root: `/mnt/smdc-rom-com-ops/rrn-ops/activities/car-190-rcs-spectro-trending/rcs_trend_v4/` 
- One epoch per RCS pass from 2026-09-12, ongoing, in time order (CAR-190 and CAR-216 interleave; execution-plan and pass numbers are scheduling labels that restart). `python rcs_trend_reader.py steps [DATA_ROOT]/cal` lists every epoch and the count
- MCE side A for the first 181 epochs, through CAR-190 plan 3 pass 57; **side B from 2026-10-06**, CAR-190 plan 3 pass 71 on
- CAR-216 plan 4 (from 2026-10-09) is a test with the **WFI enclosure about 1 K warmer**, from 05:11 UTC on 10-09; pass 1 is the last epoch before it. No step is seen at the 0.01 % level (`MANIFEST.md`)
- All at bin_factor = 16, per-SCA products
- Updated in place by a person as new passes arrive, following [DATA_PULL.md](DATA_PULL.md); the newest `digests/digests_v4_<mm_dd_yy>` set is current, and [MANIFEST.md](MANIFEST.md) records every event and label
- Several calibrations are required to use the trend data. The strategy is that these are all self-contained in the h5 files but not applied. This allows downstream users to choose which calibration to apply and `rcs_trend_reader.py` is a helper for loading the h5 an implementing this.

---

## 1. File types and where to find them

### Stage 1: Raw per-SCA products

- Path: `[DATA_ROOT]/h5/`
- Files:
  - `*_raw.h5`  (one per epoch, ~17 MB each for CAR-190, ~28 MB for CAR-216)
  - `h5/pd/pd_<run_label>.h5` (photodiode sidecar, full structure)
  - `h5/pd/pd_<run_label>.ecsv` (photodiode per-activity summary)

Use these when you want the L2 rates and full PD timestreams.

### Stage 2: Calibrated per-SCA products

- Path: `[DATA_ROOT]/cal/`
- Files:
  - `*_cal.h5` (one per epoch)
  - `[DATA_ROOT]/rcs_reference_card.ecsv` - the whole-set references
  - `[DATA_ROOT]/rcs_bridge_solution.ecsv` - the fitted ACM and side-swap bridges

The data arrays here are the same as Stage 1, but this file appends calibration metadata.

### Stage 3: Time-series digests (per SCA)

- Path: `[DATA_ROOT]/digests/digests_v4_<mm_dd_yy>/`, one set per processing
  run; the newest is the current one
- Files:
  - `time_series_SCA<n>.ecsv` for n = 1...18
  - `run_log.txt` - read this first

These are intended for convenience, and have all calibrations applied.

### Figures

- `[DATA_ROOT]/digest_plots/` - the trend figures, e.g.
  `time_series_LED1_all_scas_tgcorr.png`, and `side_bridge.png`
- `[DATA_ROOT]/digest_plots/last_<N>w/` - the same per-LED, all-SCA figures over
  the last N weeks of data, drawn from a digest set on request:
  `python digest_trend_plots.py --last-weeks N` (or `--since DATE`; `--digests
  DIR --out DIR` for any set). Same values and gauge as the full figures, a dot
  per epoch, and dated operations events (e.g. the AOM bump) as dashed lines
- `[DATA_ROOT]/plots/` - calibration, photodiode, housekeeping and gain-fit
  diagnostics

### Temperature-gain model

- `[DATA_ROOT]/tempgain_model.ecsv` - the fit used for v4 (the repo's
  `tempgain_model.ecsv` is the v3 fit, kept for comparison)

---

## 2. Basic conventions

- **LED naming**
  - Sequence names (what you see everywhere): `LED1...LED6`. These are the
    physical LEDs, and carry the wavelengths, on both MCE sides.
  - Hardware IDs: `hardware_led` attribute (1-6), the EDP `BANK2SEL` select
    line. **The B-side MCE numbers them differently** (section 5), so never key
    anything by hardware number across the swap.
  - Mapping:

    | LED | wavelength [nm] | WFI filter |
    |-----|-----------------|-----------|
    | 1   | 624             | F062      |
    | 2   | 853             | F087      |
    | 3   | 1039            | F106      |
    | 4   | 1270            | F129      |
    | 5   | 1481            | F158      |
    | 6   | 1670            | F184      |

- **NaN means "no data"**
  - Missing SCAs or activities are all-NaN planes.
  - An invalid photodiode reading gives a NaN multiplier, never 1.0.
  - Use `np.nan*` reducers (`nanmedian`, etc.).
- **Units**
  - Pixels: DN/s
  - Photodiodes and LED forward voltages: V
  - LVDT: raw counts
- **Time**
  - In h5: ISO-8601 strings for activity times; PD stream is int64 ns since Unix epoch.
  - In digests: `time_hours` relative to the reference epoch.
- **Ordering**
  - Do not use filename ordering; use timestamps or `run_label`.
- **Uniqueness**
  - `run_label` is the unique epoch ID (`CAR216_01063_03_012_001_20260927`).
  - `pass_number` is not unique (CAR216 plans 2 and 3 both start at pass 1).

---

## 3. The helper: `rcs_trend_reader.py`

One file, needing only `numpy` and `h5py` (`astropy` for ECSV output,
`matplotlib` for plots, both optional). Copy it into your own repo.

```bash
python rcs_trend_reader.py summary  [DATA_ROOT]/cal/CAR190_01039_03_071_001_20261006_cal.h5
python rcs_trend_reader.py factors  FILE --exclude tempgain     # the (SCA, LED) table
python rcs_trend_reader.py bridges  FILE                         # every fitted bridge step
python rcs_trend_reader.py steps    [DATA_ROOT]/cal              # what each file records
python rcs_trend_reader.py trend    [DATA_ROOT]/cal --ecsv my_digests --plot my_figures
python rcs_trend_reader.py compare  [DATA_ROOT]/cal [DATA_ROOT]/digests/digests_v4_<mm_dd_yy>
```

```python
from rcs_trend_reader import RcsProduct, RcsTrend

p = RcsProduct(path)
p.summary()                                   # side, segment, every step's values
m = p.multiplier(exclude=("tempgain",))       # (6, 18) on (LED, SCA)
led3 = p.stack("LED3", exclude=("tempgain",)) # (18, 256, 256), calibrated
raw3 = p.stack("LED3", raw=True)              # as stored
r = p.response(steps=("photodiode", "acm"))   # (6, 18) per-SCA medians, two steps only
rows, meta = p.bridge_solution()              # the whole bridge solution, from this file

t = RcsTrend("[DATA_ROOT]/cal")               # time-ordered
s = t.series(exclude=("tempgain",))           # {"SCA1": (n_epoch, 6), ...}, 1.0 at pass 1
d = t.digest("SCA4")                          # every digest column, digest names and gauges
meta = {**t.set_meta("SCA4"), **t.bridge_meta("SCA4")}   # the digest meta
t.plot_pair("LED1", "my_figures")             # time_series_LED1_all_scas{,_tgcorr}.png
```

**The calibrated products are self-contained.** `trend --ecsv` writes digest files.
`compare` checks them against the pipeline's digests, `trend --plot` writes summary figures.

---

## 4. Calibration

### Approach

Nothing is applied to `sca_arrays/`. Each step is recorded as

```text
calibration/<step>/multiplier     (6, 18)  on (led_name, sca)
calibrated = raw * multiplier
```

The axes are `calibration/led_name` and `calibration/sca`.

Calibration data available:
| step | removes | varies by | typical size |
|---|---|---|---|
| `photodiode` | lamp output drift; `pd_reference / pd_net` | LED | 0.1-2 % |
| `acm` | linear ACM-position response within a segment | - | ~0.1 % |
| `acm_bridge` | the step across each ACM reconfiguration | SCA | 0.5-1 % |
| `side_bridge` | the A to B side swap: electronics, LED drive and photodiode at once | LED | up to 11 % |
| `tempgain` | temperature-dependent detector gain, `1/G(T)`; **provisional** | LED, SCA | ~1 % warm |

`calibration/total_multiplier` is the product of every step except `tempgain`:
the combination the digests' `LED1...LED6` columns use.

```python
import h5py, numpy as np

with h5py.File(path, "r") as h5:
    cal = h5["calibration"]
    leds = [s.decode() for s in cal["led_name"][()]]
    total = cal["total_multiplier"][()]            # (6, 18)
    i = leds.index("LED3")
    led3 = h5["sca_arrays/LED3"][()] * total[i][:, None, None]

    # or choose the steps yourself, e.g. no bridges:
    m = cal["photodiode/multiplier"][()] * cal["acm/multiplier"][()]
```

### Gauge choices

The recorded multipliers are absolute:

- the photodiode is 1.0 at the **first epoch of each MCE side**;
- the bridges are 1.0 in the **present** configuration (side B, the latest ACM
  segment), and scale earlier epochs up to it because A side and ACM stow were not nominal.
- No dark subtraction (DARK is an all-NaN placeholder, no L2 darks).
- No flat field (both aux and MAST L2 sources skip it; no WFI flat in CRDS), but this divides out.
- No per-decon normalization (digests are gauged to the global reference epoch).

### Calibration parameters

Each `calibration/<step>` group carries its own attributes:

- `photodiode`: `pd_net`, `pd_reference` datasets; `pd_reference_mode`
  (`per-side`), `pd_reference_epoch`.
- `acm`: `acm_lvdt`, `acm_segment`, `acm_segment_reference_lvdt`,
  `acm_coefficient`, `acm_offset`.
- `acm_bridge`, `side_bridge`: `boundaries_after` (which boundaries this epoch
  precedes), `gauge`, `solution`, `solution_sha256`. `acm_bridge/error` (per
  SCA) and `side_bridge/error` (per LED) are the composed total errors, and
  `ground_b_side_corrections` is the TVAC table, for comparison only.
- `bridge_solution` It holds every step at every ACM move and side swap with its
  stat error, systematic, method, fallback note, LED spread and residual rms. It
  also holds the side bridge's error split and pattern test, and each SCA's own
  side estimate (rows with `kind = side_sca`, never applied). 
- `tempgain`: `temperature_k`, `temperature_rule`, `model`, `model_sha256`.

### Root attributes

- `calibration_schema = 2` (schema 1, `rcs_trend_v3/cal`, had the factors in the pixels)
- `corrections_applied = ""` - nothing is in the pixels
- `calibration_recorded` - the steps this file carries
- `calibration_in_total` - the steps in `total_multiplier`
- `mce_side`, `mce_side_source`
- `sequence_variant`, `sequence_signature` - which RCS sequence the pass ran (`car190`, `car216`, `car216_decon3`; MANIFEST.md, *Sequence variants*); empty on products staged before 2026-10-22 until they are re-staged
- `acm_segment`, `acm_segment_reference_lvdt`
- `reference_card_sha256`, `bridge_solution_sha256`, `tempgain_model_sha256`

---

## 5. The MCE side swap (2026-10-06)

The MCE swapped from side A to side B between CAR-190 plan 3 pass 57
(04:13 UTC) and pass 71 (11:54 UTC). Passes 58-70 were never executed. The instrument is expected to stay on side B.

What changed, and how each change is handled:

| | what happened | handling |
|---|---|---|
| photodiode | a different physical diode behind the same mnemonic: PD2 pedestal -1.92 mV, PD1 +1.06 mV, the two-diode ratio moved chromatically | PD factor re-based to 1.0 at the first B epoch; the A to B tie is carried by the side bridge |
| detector + LEDs | a chromatic response step, -10.7 % on LED1 to +3.2 % on LED3 | `side_bridge`: one step per LED, **common to every SCA** |
| LED select lines | renumbered: hardware map `612345` to `132465` | none needed: each sequence LED is the same physical LED (PD1's 1670 nm cutoff stays on LED6) |
| ACM LVDT | read by different electronics: -172 ... +205 per channel | the swap opens an ACM segment, so side B has its own reference LVDT; no ACM step across it |

The side bridge (A side scaled onto B; B is 1):

| LED1 | LED2 | LED3 | LED4 | LED5 | LED6 |
|---|---|---|---|---|---|
| 0.8933 | 0.9439 | 1.0322 | 0.9919 | 0.9911 | 1.0006 |

Errors are 1-13e-4 per LED (LED1 largest), systematic-dominated. It is fitted against each (SCA, LED)'s own trend over +/- 50 h: 3 epochs on side A, 4 on side B. The later B passes enter only the window scan that sets the systematic; see the run log.

The step is SCA-common by construction, so it cannot change the illumination pattern. The per-SCA achromatic offsets scatter 1.9x their noise expectation, under the 3x threshold. SCA8, 17 and 18 sit near -2e-4. See `digest_plots/side_bridge.png` and the run log.

The **side** is an operator label (`batch/run_manifest.csv`, `mce_side`); TODO: find an edp mnemonic that gives this. See `MANIFEST.md` for description of trend data sequence; Lane recommended  WFIF_ICDH_HPSM_MCE_OHPA/OHPB_STS but did not find these?

---

## 6. The reference card

File: `[DATA_ROOT]/rcs_reference_card.ecsv`.

- Per epoch: `run_label`, `timestamp`, `pass_number`, `car_label`,
  `decon_cycle`, `mce_side`, `mce_side_source`, `segment`,
  `pd_LED1...pd_LED6`, `pd_valid_n`.
- Meta:
  - `reference_run_label` - the response origin (A-side pass 1);
  - `pd_reference_mode = per-side` and `side_reference_pd` - each side's first
    epoch, the photodiode numerator;
  - `segment_reference_lvdt` - per ACM segment; a side change opens a segment;
  - `acm_moves`, `move_min_delta`.

Stage 2 stamps the card's sha256 into every calibrated file. Stage 3 refuses to
mix products calibrated against different cards, or against different bridge
solutions.

---

## 7. Time-series digests

Files: `[DATA_ROOT]/digests/digests_v4_<mm_dd_yy>/time_series_SCA<n>.ecsv` (the newest set), one per SCA,
one row per epoch.

| column | meaning |
|---|---|
| `time_hours` | hours since the reference epoch |
| `timestamp`, `pass_number`, `car_label`, `decon_cycle`, `decon_time_hours` | as before |
| `LED1...LED6` | relative response vs pass 1, with photodiode, ACM, ACM bridge and side bridge applied |
| `bridge_factor` | ACM bridge applied; divide to undo |
| `side_bridge_LED1...6` | side bridge applied, gauged to pass 1 (1.0 on side A, 1/step on side B); divide to undo |
| `acm_lvdt`, `acm_segment` | ACM position and segment |
| `LED1_tgcorr...`, `tempgain_LED1...` | as `LEDx` with the gain change since pass 1 divided out, and that factor |

Metadata adds the `side_bridge_*` family: steps, stat / SCA-scatter /
systematic / total errors, window, degree, the pattern test, and this SCA's own
independent reading. `bridge_solution_check` should read `current`.

