# Bringing new RCS passes into the trend

This is the procedure a person runs to pull new CAR-190 and CAR-216 passes from
MAST and carry them through to the digests. It is one python call per step.
Every call prints what it found and ends with a **Next:** block naming the exact
command to run after it, so after a break of weeks, run step 1 and follow its
directions.

Two records belong to the person running it: the labels (step 3) and
[MANIFEST.md](MANIFEST.md) (step 7). Everything else is produced by the commands.

## Before you start

```bash
cd ~/code/RST_commissioning/activities/car-190-rcs-spectro-trending
```

- **The venv.** Every command is `.venv/bin/python ...` from this directory
  ([README.md -> Environment setup](README.md#environment-setup)).
- **The MAST token.** `batch/refresh.py` reads `MAST_API_TOKEN` from
  `../../variables.env` (or the environment) and never prints it.
  `trend_change_check.py` (step 2's telemetry look, and the checks in step 6)
  needs it in the environment, once per shell:
  `set -a; . ../../variables.env >/dev/null 2>&1; set +a`.
- **The tree.** Everything reads and writes `rcs_trend_config.TREND_ROOT`,
  called `$ROOT` below:
  `/mnt/smdc-rom-com-ops/rrn-ops/activities/car-190-rcs-spectro-trending/rcs_trend_v4`.
  It is the shared deployment (group `romcom`): when step 6 closes, the shared
  copy is current. `--root` points one command elsewhere.
- **One intake at a time.** Two runs of `pull` or `run_trend.py` over the same
  tree overwrite each other's products and digests. Check that no other
  session or job is running them:

  ```bash
  ps aux | grep -E "refresh.py|run_trend.py|run_manifest_worker" | grep -v grep
  ```

- **Time.** Four CAR-190 passes took about 45 min end to end on 2026-10-17
  (`status` 13 min, `probe` 2, telemetry 2, `label` seconds, `pull` 12, `check`
  2, `run_trend.py` 14). Eleven passes, ten of them CAR-216, took about two
  hours on 2026-10-21 (`status` 23, `probe` 8, `pull --local 4` 71,
  `run_trend.py` 16). Seven, four of them CAR-216, took about 1.5 hours on
  10-25 (`status` 24, `probe` 10, `pull` 36, `run_trend.py` 17). Nine, one of
  them CAR-216, took about 1.5 hours on 10-30 (`status` 19, `probe` 5,
  telemetry 2, `pull --local 4` 41, `check` 2, `run_trend.py` 15). Ten, five
  of each, took about 1.5 hours on 11-09 (`status` 7, one two-program `probe`
  8, `pull --local 4` 47, `check` 2, `run_trend.py` 17). Six
  CAR-216 passes took about 70 min on 11-01 (`status` 10, `probe` 5, `pull` 34,
  `run_trend.py` 14). Steps 1, 4 and 6 are long enough to run under `nohup` or
  in their own terminal.

## The steps

| step | command | what it does | needs a person |
|---|---|---|---|
| 1 | `batch/refresh.py status` | what is new in the archive, missing from the tree, or stale | reading it |
| 2 | `batch/refresh.py probe` | photodiode-only evidence for the new passes; **proposes** the labels | **the labels** |
| 3 | `batch/refresh.py label` | writes the labels into `batch/run_manifest.csv` | **confirming them** |
| 4 | `batch/refresh.py pull --local 4` | stage 1: streams the new passes into `$ROOT/h5` | no |
| 5 | `batch/refresh.py check` | did stage 1 work, and do the labels match the witnesses | reading a WARNING |
| 6 | `run_trend.py` | stages 2 and 3: calibrated products, digests, figures, checks | reading the run log |
| 7 | MANIFEST.md, commit | record what happened | yes |

### Step 1: `status`, what is new

```bash
.venv/bin/python batch/refresh.py status
```

Surveys every program in the archive (CAR-190 and CAR-216) and compares it with
the manifest, the products in `$ROOT/h5`, the calibrated products and the
digests. It writes nothing in the tree. 13 min on 2026-10-17, 23 on 10-21 and
29 on 10-25, nearly all of it the paged MAST survey, and growing with the
archive.

The survey is cached in `/tmp/rcs_survey_$USER/` as soon as it arrives. If
`status` fails after that point, or you want its report again, rerun it
without paying for the survey:

```bash
.venv/bin/python batch/refresh.py status --reuse-survey      # a cache under 6 h old
.venv/bin/python batch/refresh.py status --reuse-survey 24   # under 24 h
```

A reused survey is the archive as it was then; for passes still indexing,
survey afresh.

It prints four blocks, then **Next:**

- **the archive vs the manifest**: each program and plan's pass range, any
  absent pass numbers and the sequence variants it ran (`[car216_decon3]`),
  then a table of passes the manifest does not yet hold, in time order, with
  start time, L1/L2 file counts, the **sequence** variant, and whether each is
  complete. Complete means every core LED flat (observations 2-7) is at L2 on
  all 18 SCAs: what a trend point needs. Aux exposures do not count, and some
  never reach L2.
- **the manifest vs the trend tree**: rows with no complete product, and the
  known-absent passes (`refresh.KNOWN_ABSENT`) that are never pulled.
- **stages 2 and 3**: the calibrated products, the latest digest set, and
  whether the calibration is current or stale.
- **side-status telemetry**: whether the EDP has started serving
  `WFIF_ICDH_HPSM_MCE_OHPA/OHPB_STS`.

What to look for:

- `MaxResultsWarning: Maximum results returned` lines are expected: the survey
  pages past MAST's 5000-row cap, and checks the pages add up.
- A pass marked `NOT YET -- MAST still indexing` is not finished at L2. Leave
  it and run `status` again later; nothing else in the batch has to wait.
- A sequence like `car216|car216_decon3?` means the pass's L1 so far is a
  registered layout with its tail missing: MAST is still indexing the aux
  observations, or the sequence stopped short. The core may well be complete
  (the `complete` column says), so the pass can be pulled; its product records
  the variant as not yet known, and a later re-plan fills it in. Variants are
  matched only within their program, so a CAR-216 pass missing its tail is
  never taken for the CAR-190 sequence.
- A sequence of `UNKNOWN` means the pass ran a layout not in
  `rcs_trend_config.SEQUENCE_VARIANTS`, and `status` prints its signature in a
  WARNING. Stop and work through [A new sequence variant](#a-new-sequence-variant)
  before pulling it: a new layout can break stage 1, as decon3's did.
- An absent pass number that will never be filled (a skipped pass, a short
  sequence) goes into `refresh.KNOWN_ABSENT` with the reason, and into
  MANIFEST.md, so `pull` stops trying it.
- **Next:** prints one `probe` command for every new complete pass, with
  plan-qualified pass lists (`--passes 3:78-81`, or `4:11,5:6` across an
  execution-plan boundary) and the other program's passes after `--also`
  (`--also 1039:3:94-98`), and lists any pass still indexing for a later
  intake. If nothing is new it says so and the intake is done.

### Step 2: `probe` and a telemetry look, the evidence

```bash
.venv/bin/python batch/refresh.py probe --program 1063 --passes 5:20-24 --also 1039:3:94-98
```

Use the command `status` printed. With new passes in both programs it is one
call with `--also`, so every new pass reads in one time order, across the
program switch. It streams no imagery: it writes
photodiode-only sidecars for the new passes and the two latest products in
time (the context), into `/tmp/rcs_probe_<date>/`, and reads the MPA
temperature from the EDP. About 2 min for four passes, 4-way. It writes nothing
in the tree.

It prints, in PD-stream time order:

- per epoch: the **LED map**, which side it reads, the two photodiode
  pedestals, and the two-diode ratio per LED. Side A reads map `612345`,
  side B `132465`; at a swap both pedestals step (PD2 by -1.92 mV and PD1 by
  +1.06 mV at the 2026-10-06 swap) and the ratio moves chromatically;
- `no LED map change in this set`, or the block describing one;
- the **MPA temperature** per epoch: 89.5 K on the plateau, near 124 K at the
  top of a decon cooldown, flagged above 95 K;
- the **proposed labels**, one run of passes per side and decon cycle, in time
  order. The cycle is the latest product's, until a warm pass: the first pass
  above 95 K opens the next cycle (`decon2` -> `decon3`), and it and every
  later pass in the batch take it, while the passes before it keep the old one.
  A cooldown stays warm for several passes (plan 6 on 2026-10-20: 121.5, 106.5,
  99.0, then 94.7 K);
- The context passes are the latest products already in `$ROOT/h5`. Probe both
  programs in one call (`--also`): run as two calls, the second's context is
  the latest staged products, not the first call's new passes, and the batch
  is never shown in one time order (2026-11-09 found this). The labels come
  from each pass's own witnesses either way.
- **Next:** one `label` command per run. Anything the evidence does not settle
  is printed as a placeholder (`--mce-side <A|B>`), with a note to fill it in:
  never run a command with a `<...>` in it.

Then look at the telemetry over the new passes' span, for anything the labels do
not capture (an ACM move, an enclosure setpoint change). The token has to be in
the environment for this one:

```bash
set -a; . ../../variables.env >/dev/null 2>&1; set +a
.venv/bin/python trend_change_check.py telemetry --preset intake \
    --start 2026-10-14T00:00 --end 2026-10-16T18:00 --every 12h
```

Set `--start` to about a day before the first new pass (so the gap before it
is covered) and `--end` to the last one. `--preset intake` is the six ACM LVDT
channels, the fourteen heater setpoints, the enclosure thermistors
(`WFI_MCE_ADC_WTSM10/11`, `CDHA_TCS_WTSC22P/24P`), `WFI_MCE_TEMP_CMU`, the
MPA, and the five telescope thermistors from README.md (AOM, AMS, TOMA, FMS, SM;
the `TCEA_TME_EXT_THERMISTOR_*` channel, labelled in the table: TCEB serves no
samples). Name more mnemonics after it to add them. About 2 min.

It prints a median table on the time grid, one line listing the mnemonics with
no step, and every step episode, placed between the passes around it:
`[after CAR190 p3.80, 16 min before CAR190 p3.81]`, measured to the pass's
product timestamp (its first lit exposure; the dark starts about 10 min
earlier). The placement only knows passes already in `$ROOT/h5`, so before step
4 a step among the new passes reads as "after" the last staged one: place it
against `status`'s start times, or rerun this after step 4. The six LVDT channels
move together and are reported once. A preset drops the LVDT's no-reading
zeros (`--dropout 0`), which otherwise read as moves. What the episodes mean:

- **an ACM staircase**: a run of steps of about 2500 counts over two to four
  hours that ends where it started. Since 2026-10-29 every one has gone out to
  about -7780, then up to +2290, then back (10-29, 11-06, 11-07). No pass sees
  it unless one falls inside; record it in MANIFEST.md.
- **an ACM move**: the channels shift together and stay shifted. Under 500
  counts it is covered by the linear in-segment ACM term and raises the travel
  warning in step 6; over 500 it opens a new ACM segment and a bridge.
- **a setpoint step**: an operations change. Setpoints 06-09 are the
  enclosure: 132 -> 139 on 2026-10-09 (the +1 K test), 139 -> 143 on 10-17
  and back on 10-20. Setpoint 04 going 130 -> 165 is the decon heater (10-20).
  Ask the operations team what each was, and record it.
- **an excursion** on a temperature channel: a level more than `--ramp` (1 K)
  from where the window starts, for over an hour, too slow to be a step. Listed
  under `excursions` with its size, the times it was 10, 50 and 90 % of the way
  there and back, and the staged passes inside it; "not back by the end" is a
  lasting change, or a window that opened during one (the LVDT and setpoints
  are not tested). The telescope bumps are the example: the AOM +5.16 K from
  2026-10-30 (50 % at 05:15) and the AMS +5.00 K from 11-02 (50 % at 02:00),
  both back from 11-05 (50 % at 10:15 and 07:00). A first version compared only
  the window's two ends and reported nothing once both were back: put the
  window's start before the bump when you want its rise. To time a command to
  the minute, look for a step episode of a few seconds that several
  thermistors share (10-30 01:48:06, 11-05 04:30:31); the response lags it
  (the AOM by about 50 min going down). Operations bump the telescope to see
  whether it changes the ice deposition rate: record each start, size and end
  in MANIFEST.md with the passes on the ramp and the plateau, and add it to
  `rcs_trend_config.TREND_EVENTS`. Its effect on the trend is a change in the
  film growth rate, which takes several passes to measure (the LED1 slope is
  the most sensitive).
- **a profile**: `--plot <file>.png` draws each named mnemonic in its own panel
  (15-min medians, its own y-scale, absolute values), each excursion's 50 %
  times as dashed lines, and a tick per staged pass along the bottom (CAR-190
  `|`, CAR-216 a triangle), so the passes on a ramp, a plateau or a baseline
  can be read off. Draw it after step 4, when the new passes are staged. The
  telescope-bump figures are in `$ROOT/plots/diagnostics/telescope_bumps_20261030/`.
- **a pass starting minutes after a move ends**: check that pass for settling
  with `trend_change_check.py outliers` after step 6.

### Step 3: `label`, the decision

```bash
.venv/bin/python batch/refresh.py label --program 1039 --passes 3:78-81 \
    --decon-cycle decon2 --mce-side B
```

The one step that is a decision. `decon_cycle` (when the instrument was warmed)
and `mce_side` (which MCE drove it) are operational knowledge that neither the
archive nor the telemetry carries; `probe` proposes them, and the person
confirms them against the operations record before running this. It backs up
`batch/run_manifest.csv` into `batch/manifest_backups/`, writes the rows, and
prints the MANIFEST.md row to add in step 7. Seconds.

- Run the command `probe` printed, unless the evidence or the operations record
  says otherwise. Edit the labels, not the pass list.
- A batch that crosses a boundary (a side swap, the first warm pass of a decon)
  takes one `label` per run of passes; `probe` prints one per run.
- A new decon cycle starts at its first warm pass. `probe` proposes the next
  name (`decon2` -> `decon3`); the person confirms it against the decon
  schedule.
- Running `label` over passes the manifest already holds relabels them. A
  relabelled pass that already has a product keeps its old labels in the h5
  until it is re-staged with `--force`.

### Step 4: `pull`, stage 1

```bash
.venv/bin/python batch/refresh.py pull --local 4
```

Writes `batch/run_manifest_new.csv`, the manifest rows with no complete product
in `$ROOT/h5` (never the known-absent ones), then stages them. Stage 1 is the
only stage that touches the network: it plans each pass (one MAST listing per
pass), then streams its L2 frames, bins them to 256 x 256 per SCA and writes
`$ROOT/h5/<run_label>_raw.h5` and the photodiode sidecars in `$ROOT/h5/pd/`.

Three ways, all running the same worker with the same rank split and status
files:

- **`--local N`**, for a handful of passes: plans with N ranks, streams with N
  ranks only if no plan failed, and waits. One log per rank in
  `batch/logs_local/`, followed live. Four CAR-190 passes at `--local 4` took
  12 min (2026-10-17); a CAR-216 pass, at 10 x 18 frames, takes about 21 min
  per rank. Nine passes took 41 min (2026-10-30). Run under `nohup` with its
  output to a file, the per-row lines below reach that file only as each rank
  finishes, so a quiet file for half an hour is normal: follow progress in
  `batch/logs_local/<stamp>_use-plan_rank*.log`.
- **`--submit`**, for many: submits the two SLURM rungs, plan 4-way and stream
  8-way, the second held until the first finishes with no failed row.
- **neither**: prints the by-hand `process_rcs_trending.py` commands for the
  first two rows and the two `sbatch` lines, and runs nothing.

It prints the rows it will stage, then, per rung, one line per row (`planned`,
`done`, `degraded`, `FAILED`) and one tally per rank:

```
--use-plan: 4 rank(s) running, logs batch/logs_local/<stamp>_use-plan_*
  done CAR190_01039_03_078_decon2
  rank 0/4 finished: 1 done, 0 planned, 0 skipped, 0 degraded, 0 failed
```

- `degraded` means MAST had not indexed every SCA of the pass when it was
  planned: nothing was streamed, and the row stays pending. Run `pull` again
  later.
- `FAILED` stops the streaming rung. `batch/status/<stem>.failed` holds the
  return code and the stderr tail, and `batch/logs/<stem>.log` the whole run.
  Rerun `pull` after fixing it: complete products are skipped, so it resumes.
- `pull` empties `run_manifest_new.csv` when nothing is pending, so a stale one
  cannot be resubmitted.

### Step 5: `check`, did stage 1 work

```bash
.venv/bin/python batch/refresh.py check
```

About 2 min. It prints, then **Next:**

- **the worker outcome** of every row of the last pull, from `batch/status/`;
  every one should read `done`;
- **the triage**: one line per product with the SCAs covered, ending `N
  product(s): N with >= 18 SCAs in every LED, 0 degraded or unreadable`. A
  short product is rebuilt by the next `pull`;
- **the readout**: the core LED flats' MA table of every product that records
  it (staged from 2026-10-30), each switch between consecutive products named
  (`switch 9010 -> 9008 between ... and ...: expect SCA18 to step about 0.8 %`),
  and a `WARNING` for a product whose MA table is not its variant's
  `ma_table` in `rcs_trend_config.SEQUENCE_VARIANTS`, or whose flats disagree.
  The warning is a new variant that the survey cannot see: same exposures,
  different readout. Treat it as [A new sequence variant](#a-new-sequence-variant)
  before running step 6. A named switch needs nothing but a MANIFEST.md line;
- **the side witnesses** for every product, in time order: LED map, the side it
  reads, the label it carries, pedestals and PD ratios. A label that contradicts
  its LED map makes `check` exit 2 and name the pass: fix the label with step
  3, and re-stage the pass with `--force`.

The `LED map change between ... CAR190_01039_03_071 ...` block at the end is
the 2026-10-06 side swap, and appears every time. A second such block is new
and is a key-period event.

### Step 6: `run_trend.py`, stages 2 and 3

```bash
.venv/bin/python run_trend.py --dry-run     # the seven steps, commands only
.venv/bin/python run_trend.py
```

Rebuilds the calibrated products and the digests over the whole tree, in place.
No network. About 14 min on the shared mount (2026-10-17). It prints every
command before running it, in seven numbered blocks:

1. **the reference card**, from every raw product's metadata: the reference
   epoch, the per-side photodiode references, the ACM segments. Read its ACM
   block: the segments, and `max fractional travel` (it warns above 0.10).
2. **stage 2, pass 1**: records the photodiode and linear ACM factors in
   `$ROOT/cal/*_cal.h5`; no pixel changes.
3. **stage 3, pass 1**: the digests that fit the ACM and side bridges, written
   to `$ROOT/rcs_bridge_solution.ecsv`. This is where a new L2 calibration
   stops the run (below).
4. the temperature-gain fit: skipped unless `--fit-tempgain`.
5. **stage 2, pass 2**: records the bridges and the gain model too.
6. **stage 3, final**: `$ROOT/digests/digests_v4_<mm_dd_yy>/` (a rerun the same
   day replaces it), the figures in `$ROOT/digest_plots/`, the run log, and the
   checks.
7. the stage-2 diagnostics in `$ROOT/plots/`.

It fails unless all three checks pass, printed after block 6:

```
  ok   LED1..LED6 in all 18 final digests are bit-identical to pass 1 ...
  ok   the products carry the bridge solution the final digests fit: current ...
worst over 102 columns and meta keys: 6.661e-16
```

The last is `rcs_trend_reader.py compare`, rebuilding every digest column from
the products alone. Warnings that appear on every run, and are understood:

- `this set mixes epochs that record their L2 calibration with 141 that do
  not`: the 141 epochs staged before L2 provenance was recorded; audited
  separately in `l2_calibration_audit.ecsv`.
- `the linear ACM correction is extrapolated to N% fractional travel`: the
  small ACM moves inside segment 4 (MANIFEST.md). It grows if another small
  move lands.
- `decon_evidence.png: N unlabelled step(s) exceed the chromatic floor (epoch(s)
  182, ...)`: epoch 182 is the 2026-10-06 side swap, which is chromatic by
  nature. The first step or two after a labelled decon can join it: the film
  regrows fastest just after a reset, and at a 5 h cadence one step carries
  enough of that to cross the floor (epoch 218, decon3 pass 2: a 1.07 %
  chromatic spread, then 0.48 and 0.33 % on the next two steps, against about
  0.2 %/h at the start of decon2 too). The floor is computed over the whole
  set, so a new intake can move it and flag an old epoch whose values did not
  change: on 2026-11-09 epoch 40 (CAR-216 p2.5, the third pass down the decon2
  cooldown) joined, after ten quiet epochs lowered the floor. If `regress`
  says the old epochs are unchanged and the new flag is an early-regrowth
  step, record it and move on. A flagged step anywhere else, or one the MPA
  does not show as a quiet cooldown, is a possible unrecorded decon.

**Read the run log's `L2 calibration` block even when the run passes.** It lists
the contiguous runs of one configuration (`cal 1.0.2 CRDS roman_0077 ...
ref_file_id=...`). A new run with the same `ref_file_id` but a new software
version does not stop anything, because the equivalence classes are keyed on
the reference files: romancal 1.0.2 -> 1.0.3 at CAR-216 p5.23 (2026-11-03)
showed only as the count going from six runs to seven. Code can change pixels
with no reference file changing, so measure it as you would a new class:
`refdiff <pass before> <first pass after>` (it names the software change and
says so), then `steptest --at <first pass after>` and `relative --sca 18 --at
<it>` (SCA18's read-1 correction is the most code-sensitive piece), and write
the numbers into the `CALIBRATION_EQUIVALENCE` comment beside the id. When
MAST later serves an old pass from the new software, `refdiff` on that pass
prints a NOTE: re-stage it into a scratch tree and divide, the pixel test.

**If it stops at block 3 with "this set spans N L2 calibration equivalence
classes"**, MAST has processed the new passes with reference files that have
not been measured. The message names the first epoch of the new class. Then:

```bash
set -a; . ../../variables.env >/dev/null 2>&1; set +a
.venv/bin/python trend_change_check.py refdiff <pass before> <first pass after>
.venv/bin/python trend_change_check.py steptest --first <a pass well before> \
    --last <the latest pass> --at <first pass after> --degree 2
```

When `steptest` reads a step above the nulls, look at which SCAs carry it (it
prints the three largest). **SCA18 alone, about 0.8 %, achromatic, at a switch
between `car216_decon3` and CAR-190 passes is expected**: the two read out with
different MA tables (`IM_DIAGNOSTIC`, every read, against `DROP_2_OF_3`), and
SCA18 is the one detector whose read-1 transient correction depends on which
reads there are (MANIFEST.md, 2026-10-22). Check its size and sign with
`relative` below (SCA18 reads lower on CAR-190), note it in MANIFEST.md, and
move on. `rcs_trend_reader.py summary` prints each product's MA table (products
staged before 2026-10-30 say `not recorded`). If one SCA carries any other
step, measure that SCA directly:

```bash
.venv/bin/python trend_change_check.py relative --sca 18 --at CAR190_01039_03_083 \
    --out $ROOT/plots/diagnostics/<name>/sca18_vs_rest_timeline.png
.venv/bin/python trend_change_check.py mosaic --pair <before>,<after> \
    --pair <a control pair> --out $ROOT/plots/diagnostics/<name>/ratio_mosaic.png
```

`relative --at` gives the SCA's step against the other 17, per LED, with each
side's own trend extrapolated to the middle of the gap. That separates a step
from fast growth better than `steptest`'s single quadratic across the gap,
which can read early-episode regrowth as a step. `mosaic` shows where on the
array and on the detector it is (`--zoom SCA` for one detector, with its
readout-channel profile). Compare against SCA17 alone and you mix two
detectors' drifts: on 2026-10-25 that read SCA18's 0.76 % step as regrowth,
and the median of the rest found it (MANIFEST.md); operations then traced it to
the readout mode. Keep figures for
an investigation in `$ROOT/plots/diagnostics/<name>/` with a README.

`refdiff` lists the reference files that changed (0075, 0076 and 0077 were each
the distortion file alone, which only sets the WCS). `steptest` reads the
per-SCA achromatic step at the change against the null splits. If it is inside
the null range, add the new `ref_file_id` to
`rcs_trend_config.CALIBRATION_EQUIVALENCE` **with the numbers and the command**,
in the comment above it, and rerun `run_trend.py`. With only one or two passes
after the change the test is weak, and LED1 in particular can read a step that
is its growth curvature at the window edge: record it as an open item and
re-test at the next intake, as 0077 was.

**If it stops with `FileNotFoundError` renaming a `*.tmp-<pid>` file** in
`$ROOT/cal/`, the shared NFS mount lost a RENAME reply. The rename happened, but
the client's retry found no source. That happened once, on 2026-10-25, in a
16-way stage-2 pass. `rcs_fsutil.replace` has treated it as success since then:
it checks the temporary is gone and the target is now its inode. If a rename
error still appears, rerun `run_trend.py`. Every product is whole, and stage 2
rewrites them all with `--force`. A tree left half on the old pass is never
published, because stage 3 refuses products calibrated against different
bridge solutions.

**Then look at the trend.** In order:

1. `$ROOT/digests/<set>/run_log.txt`: ACM moves and whether each step was
   measured or modelled, the side bridge, refused photodiode readings, decon
   transitions, coverage.
2. `$ROOT/digest_plots/side_bridge.png`, and
   `time_series_LED1_all_scas_tgcorr.png` with its `_tgcorr`-free pair. Grey
   bands are ACM moves and the side swap; pale blue bands, labelled
   `decon<N> starts` at the top, are decons. For the recent stretch, draw the
   same per-LED family over the last weeks of data:

   ```bash
   .venv/bin/python digest_trend_plots.py --last-weeks 1     # -> $ROOT/digest_plots/last_1w/
   .venv/bin/python digest_trend_plots.py --since 2026-10-30 # -> since_20261030/
   ```

   One file per LED (and its `_tgcorr` blink pair), all 18 SCAs, a dot per
   epoch, from the newest digest set alone, with the values of the full
   figures (gauged to pass 1, autoscaled to the window). Dashed lines are the
   dated operations events in `rcs_trend_config.TREND_EVENTS` (enclosure
   bumps, the AOM bump), which the digests do not carry: add an event there,
   with its time from `telemetry`, when one happens. About 10 s.
3. The earlier epochs, against the previous set:

   ```bash
   .venv/bin/python trend_change_check.py regress
   ```

   It matches the two newest digest sets on timestamp and compares every float
   column. The verdict is `identical` (the usual result), `round-off only`
   (differences under 1e-12; 2026-11-01 read 6.7e-16, from refitting with more
   epochs), or `CHANGED`, which after a routine intake is a finding: something
   (a bridge window reaching the new epochs, a refit, a code change) moved old
   values, and it needs explaining before the set is published.
4. The new passes against their neighbours:

   ```bash
   .venv/bin/python trend_change_check.py outliers \
       --first <a pass several before the new ones> --last <the latest pass>
   ```

   It flags an epoch whose per-SCA scatter is over 3x the median. The last
   epoch has no later neighbour and is not tested, and the one before it has
   only one: a flag there, just over the threshold, after a long gap, is the
   fit at its edge as often as the pass (CAR-216 p5.18 on 2026-11-01, 0.023 %
   against 0.021 %). Note it and re-test at the next intake; a pass that
   needed a settling check (step 2) is likewise checked then. Keep the window inside
   one decon episode: across a reset the neighbours are not a prediction, and
   a new episode needs about five passes before any of its epochs can be
   tested. The two epochs either side of a `car216_decon3` <-> CAR-190 switch
   are flagged with SCA18 alone (about +/-0.15 to 0.2 %): that is the readout
   step above, seen by the leave-one-out fit, not two outliers.

### Step 7: MANIFEST.md, and the commit

- Add the row `label` printed to MANIFEST.md's *Label decisions* table, with the
  evidence from `probe`.
- Extend the *Current state* table: each row is one contiguous run in time of
  one program and plan, so a new plan, or a plan resuming after another, is a
  new row.
- Add a timeline entry for anything that happened: an ACM move or staircase, a
  new L2 calibration, an operations event, an outlier, a refused reading. Give
  the numbers and the command that reproduces them.
- Add a short *Re-run* entry: `regress`'s verdict line, what the checks said,
  and anything open.
- The person commits `batch/run_manifest.csv`, MANIFEST.md and any config
  change. The trend tree is not in git; it is the deployment.

No document carries the size of the set: `refresh.py status` prints it, and
`.venv/bin/python rcs_trend_reader.py steps $ROOT/cal` lists every epoch. A
number in the docs is a dated measurement or a fixed event.

## When something is unusual

Step 7 covers the routine record. What else to update depends on what happened:

| what happened | how it shows | what to update |
|---|---|---|
| routine new passes | `status`, `probe` | MANIFEST.md, as above |
| a new L2 calibration | `run_trend.py` stops: the set "spans N L2 calibration equivalence classes" | `trend_change_check.py refdiff <pass before> <pass after>`, then `steptest`; if the step is inside the null range, add the `ref_file_id` **with the numbers** to `rcs_trend_config.CALIBRATION_EQUIVALENCE`, write a MANIFEST.md entry, and rerun `run_trend.py` ([Checking any change between passes](README.md#checking-any-change-between-passes-trend_change_checkpy)) |
| pass numbers that will never fill | `status` lists them as absent | `refresh.KNOWN_ABSENT`, with the reason, and a MANIFEST.md entry |
| a decon | `probe` flags a pass above 95 K and proposes the next cycle name from it on | label as proposed; MANIFEST.md, with the heater timing from `telemetry --preset intake` (setpoint 04 and the MPA). A new CAR-216 execution plan has often, but not always, followed a decon: judge by the MPA, not the plan number |
| a new sequence variant | `status` lists a pass as `UNKNOWN`, with its signature; or `check` warns that a product's MA table is not its variant's | [A new sequence variant](#a-new-sequence-variant), below: before pulling, or for a `check` warning before step 6 |
| an MCE side change | `probe`: the LED map changes and both pedestals step | label the side; the side bridge is fitted automatically ([Across a side swap](#across-a-side-swap)); MANIFEST.md |
| an ACM move | the run log's ACM RECONFIGURATIONS block; a move under 500 counts is linear in-segment and raises the travel warning | MANIFEST.md, with the time from `trend_change_check.py telemetry --preset acm` |
| an operations event (enclosure setpoint, power cycle) | the operations team; `trend_change_check.py telemetry --preset intake` | MANIFEST.md, with the telemetry and a `steptest` at the first pass after it (inside one decon) for any effect |
| one SCA (18) steps about 0.8 % at a program switch in decon3 | `steptest` names SCA18; `relative --sca 18 --at <first pass after>` reads -0.7 to -0.9 % in every LED going to CAR-190 (the other sign going to `car216_decon3`) | nothing to correct: it is the MA table (Step 6). A MANIFEST.md line with the measured step; investigate only if the size, the sign or the SCA differs |
| a telescope temperature bump (AOM, AMS) | the operations team; the `excursions` block of `telemetry --preset intake`, and its `--plot` | MANIFEST.md timeline, with the start and size; compare film growth before and after once several passes are in |
| new calibration software, same reference files | the run log's `L2 calibration` block gains a run with a new `cal` version and the same `ref_file_id`; nothing stops | `refdiff`, `steptest`, `relative --sca 18` at the first pass on it; the numbers in the `CALIBRATION_EQUIVALENCE` comment and a MANIFEST.md entry (romancal 1.0.3, 2026-11-03) |
| a deliberate gain refit | `run_trend.py --fit-tempgain` | TEMPERATURE_GAIN.md |

### A new sequence variant

Each pass's sequence is reduced to a signature, one token per observation,
`<obs>:<D|F><led>x<n exposures>@<seconds>`, e.g. `10:F3x5@70` for five 70 s
band-3 flats. `rcs_trend_config.SEQUENCE_VARIANTS` holds the known ones, and
`status` names each new pass's variant from the L1 survey it already makes.
Stage 1 assumes only one thing about the layout: observations 1-7 are the core
(obs 1 the dark, obs 2-7 the six LED flats); everything after is aux, stored
but never trended, and keyed by what it is (`AUX_DARK`, `AUX_PERSISTDARK`,
`AUX_LED3FLAT`, `AUX_LED3LOWFLUX`, ...; `rcs_activities.aux_key_base`). A
variant that keeps that core needs only registering. One that changes the core
needs code.

1. **See the layout**, exposure by exposure, with what reached L2:

   ```bash
   .venv/bin/python trend_change_check.py sequence --program 1063 --plan 6 --pass 1
   ```

   It prints each observation and exposure (type, LED, start, length, SCAs at
   L1 and L2, core or aux), then the signature and the variant.
2. **Check that observations 1-7 are still the core**: one 180 s dark, then
   LED1..LED6 flats one exposure each at about 41 s. If they are not, stop:
   `rcs_activities.CORE_OBSERVATIONS` and `group_activities` need changing, and
   the trend's continuity across the change needs thought.
3. **Plan one pass into scratch** and read the activity keys stage 1 would use:

   ```bash
   .venv/bin/python process_rcs_trending.py --program 1063 --execution-plan 6 --pass 1 \
       --decon-cycle decon3 --mce-side B --blank-dark --plan-only \
       --staging-root /tmp/rcs_seqtest --out-dir /tmp/rcs_seqtest/h5
   ```

   It should end `plan cached; nothing streamed`, with `DARK`, `LED1`..`LED6`
   and the aux keys. An aux exposure of a kind `aux_key_base` has no name for
   gets `AUX_LED<n>FLAT`; give it a proper base there if it matters.
4. **Register it** in `SEQUENCE_VARIANTS`, with the signature `sequence`
   printed, a description, and where it was first seen; add it to the table in
   MANIFEST.md (*Sequence variants*) and a timeline entry. Then carry on from
   step 2.

The signature sees exposure counts and lengths, not the readout: the MA table
lives only in each L2 frame's `meta.exposure`, and two variants with the same
signature could read out differently. Stage 1 records `ma_table_name`,
`ma_table_number` and `nresultants` on every activity's dataset (from
2026-10-30), and `rcs_trend_reader.py summary` prints the LED flats'. For a new
variant, read them off one product and add them to the registry's `readout`
field: a change of MA table moves SCA18 (Step 6).

Each registered variant also carries `ma_table`, the core flats' MA table
number, and `refresh.py check` (step 5) compares it with every product's
recorded table. That is how a readout-only variant shows up: CAR-216 plan 5
came back on 2026-10-29, inside decon3 and after plan 6, with the decon2
`car216` sequence and readout, so neither the plan number nor the decon tells
you which variant a pass ran; the signature and the MA table do.

Every product records its variant. Planning stores the signature in the query
plan (from the L1 listing it already makes, so no extra MAST calls), and stage 1
writes `sequence_variant`, `sequence_signature` and `sequence_source` into the
raw product; stage 2 carries them into `cal/`. `rcs_trend_reader.py summary`
prints them. Products staged from plans written before 2026-10-22 say `not
recorded`; rung 1 of a batch rerun re-plans every row, so the next full rerun
fills them in. A product staged before its variant was registered reads
`sequence_variant = UNKNOWN`, but its `sequence_signature` is still right:
`rcs_activities.classify_sequence(signature, cfg.SEQUENCE_VARIANTS)` names it
without re-staging, and the next re-stage rewrites the attribute.

The decon3 CAR-216 variant (plan 6 on, 2026-10-20) is the worked example. Its
core was unchanged, but its aux observations renumbered (obs 8 became a
persistence dark and the band-3 flats moved to obs 11). The old code keyed aux
activities by observation number, so `probe` and `pull` failed with
`expected exactly one dark exposure at L1 ... found 2` until aux keys were
assigned by content. Its 66 s low-flux flats (obs 10) never reach L2: they are 22
resultants, and L2 processing takes 16 or fewer. `status` no longer counts aux
exposures toward completeness, so it does not wait for them.

## Reference

### Why the labels need a person

Every manifest row carries two labels that **the archive cannot supply**:

- `decon_cycle`: when the instrument was warmed;
- `mce_side`: which MCE was driving it. Nothing in the L2 metadata or the
  telemetry MAST serves names it. `WFIF_ICDH_HPSM_MCE_OHPA/OHPB_STS` were
  candidates; they are not in the EDP, and `status` re-checks every run.

A blank side stages as `assumed:flight-side-A`, right before 2026-10-06 and
wrong after. The side selects the photodiode reference and the side of the side
bridge an epoch sits on, so a mislabel misplaces a step of several percent.
`probe` collects the evidence (step 2); the person confirms it (step 3).

### Stage 1 by hand, for one or two passes

`pull` prints these commands; they are here so the procedure is legible on its own.

```bash
.venv/bin/python process_rcs_trending.py --program 1039 --execution-plan 3 --pass 75 \
    --decon-cycle decon2 --mce-side B --blank-dark --plan-only \
    --staging-root "$ROOT/stage" --out-dir "$ROOT/h5"
#   ... then the same with --use-plan instead of --plan-only to stream
```

- **`--mce-side` is not optional on a B-side pass**, and `--decon-cycle` is
  never inferred.
- **`--staging-root` must be given.** The default is on the
  `/mnt/roman-science-east-2` S3 mount, where `os.replace` is unsupported: the
  run dies with `OSError: [Errno 38]` and leaves an undeletable `*.tmp*` behind.
  `$ROOT/stage` on the `/mnt/smdc-rom-com-ops` NFS mount is fine: atomic rename
  and HDF5 writes were checked there on 2026-10-12.
- `--plan-only` exits 3 (`DEGRADED:`) when MAST has not indexed every SCA yet.
- `--blank-dark` is permission, not a switch: it lets the run proceed when the
  dark activity's L2 products are absent, in which case row 0 becomes an all-NaN
  placeholder and the LED arrays are stored **without** dark subtraction. When
  the dark did arrive it changes nothing, so every manifest row carries it. It
  does not affect the photodiode pedestal, which comes from the dark-*period* PD
  time stream ([The photodiode](README.md#the-photodiode-a-time-stream-derivation-validated-against-all-34-good-products)).

### Stage 1 under SLURM

`pull --submit` is the same two rungs as `--local`, as SLURM jobs: rung 1
plans 4-way (wider than 4 overloads the MAST listing API), rung 2 streams
8-way and is held until rung 1 finishes with no failed row. Use it for many
passes, or for a rebuild. `pull` with neither flag prints both `sbatch` lines.
The worker forwards each row's `mce_side` as `--mce-side`; a blank cell forwards
nothing, so the pre-swap rows stage as they always have. Stage 1 is resumable:
rerun and complete products are skipped. `pull` empties `run_manifest_new.csv`
when nothing is pending, so a stale one cannot be resubmitted. The status
files, `--min-scas` and throttling are described in
[README.md -> Batch processing with SLURM](README.md#batch-processing-with-slurm).

### Where it lands

Everything is in the trend tree, `rcs_trend_config.TREND_ROOT`:

```
$ROOT = /mnt/smdc-rom-com-ops/rrn-ops/activities/car-190-rcs-spectro-trending/rcs_trend_v4
  h5/        raw products (stage 1) and h5/pd/ photodiode sidecars
  cal/       calibrated products (stage 2): same pixels, every factor recorded
  digests/   digests_v4_<mm_dd_yy>/  one set per run_trend.py day; a rerun the
             same day replaces that day's set
  digest_plots/, plots/                figures, replaced on every run;
             digest_plots/last_<N>w/ and since_<date>/ from digest_trend_plots.py,
             replaced when it is rerun
  rcs_reference_card.ecsv, rcs_bridge_solution.ecsv, tempgain_model.ecsv
  stage/     query plans; SEEDED_FROM.txt  where the tree was copied from
```

The tree is the deployment: it is on the shared mount, group `romcom`, so when
`run_trend.py` closes the shared copy is current. `--root` points one command
elsewhere, and `RCS_TREND_ROOT=...` a whole shell (a scratch copy, say). A new
tree generation starts as a verified copy of the last one, never in place:

```bash
.venv/bin/python batch/refresh.py seed --from <old tree> --root <new tree> --dry-run
.venv/bin/python batch/refresh.py seed --from <old tree> --root <new tree>
```

`seed` only fills an empty root, checks every file's size on arrival, and
appends what it copied to `SEEDED_FROM.txt`; `--resume` finishes an interrupted
copy. The tree was `/data/eswitzer/rcs_trend_v4` until 2026-10-12 (frozen there
as the seed source), and the digest sets and figures from before then are in the
repo's `digests/` and `digest_plots/`.

### Across a side swap

What the pipeline does, all automatic once the labels are right:

1. **Photodiode re-based** to 1.0 at each side's first epoch. The card's
   `--pd-reference per-side` is now the default, and a two-side card in `global`
   mode is refused.
2. **An ACM segment opened** at the swap, because the B electronics read the
   LVDT with a -172 to +205 count offset per channel.
3. **One step per LED, common to every SCA**, fitted across the swap against each
   (SCA, LED)'s own trend over +/-50 h. It absorbs the electronics, LED drive and
   photodiode together.
   - Gauge: side B is 1, and side A is multiplied by the step. The digests then
     divide by pass 1, so they stay 1.0 at A-side t=0.
   - A pattern test reports whether the swap changed the illumination pattern,
     which an SCA-common step cannot absorb.
   - At 2026-10-06: LED1 0.893, LED2 0.944, LED3 1.032, LED4 0.992, LED5 0.991,
     LED6 1.001, each +/-1-13x10^-4 (LED1 largest). Pattern test 1.90x noise.

The TVAC `B_SIDE_CORRECTIONS` table is no longer applied; it is recorded for
comparison.

### Automating it

The intake is run by a person for now. It can move to a schedule in two stages:

1. **Now safe to schedule: the read-only half.** `status` and `probe` write
   nothing outside scratch and `/tmp`, and together they answer "is there new
   data, and does it look like a boundary?". A daily entry running `status`
   and writing a log covers the routine case and leaves every write to a
   person. SLURM's `scrontab` is disabled on this cluster (checked 2026-10-14),
   so it is a user `crontab` on the login node, which lives only as long as that
   node does. `mkdir batch/logs_cron`, `crontab -e`, then:

   ```
   17 7 * * * cd $HOME/code/RST_commissioning/activities/car-190-rcs-spectro-trending && .venv/bin/python batch/refresh.py status >> batch/logs_cron/status.log 2>&1
   ```

   Read the log's latest **Next:** block and carry on by hand from there.

2. **Later, once the labelling has settled: the whole chain.** `pull` and
   `run_trend.py` are already safe to run unattended: the worker is idempotent,
   the coverage check refuses short products, stage 3 refuses a new L2
   calibration, and `run_trend.py` refuses a bootstrap that does not close.
   `label` is the only step that needs a person, and it becomes mechanical when
   every one of these holds for a batch:
   - `probe` proposes the same side and decon cycle as the latest product in
     time, from a recognised LED map, with no pass above 95 K;
   - every new pass is complete in `status`;
   - the operations record has no event in the batch's span.

   Under those conditions a scheduled job could run `label`, `pull --local`,
   `check` and `run_trend.py`, stopping at the first condition that fails and
   leaving it for a person. That job does not exist yet; the conditions are
   written here so it can be built against them, and MANIFEST.md would still
   need its entries from a person.
