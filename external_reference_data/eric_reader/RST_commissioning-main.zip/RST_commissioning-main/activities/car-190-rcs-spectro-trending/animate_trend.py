"""Animate the per-LED response-ratio trend across completed passes.

Generalizes the manual pass-by-pass comparison in ``plot_response_ratios.ipynb``:
globs the compiled h5 files for a run (``CAR190_<program>_<execution_plan>_<pass>_
<segment>_<date>.h5``), ratios every completed pass against pass 1 for each LED,
and writes one GIF animation per LED to ``plots/animations/``. The colorbar for
each LED's animation is fixed across its frames: vmin/vmax are the min/max of
each individual pass's own percentile range (matching "look at one pass's plot
in the notebook" rather than a percentile over all passes pooled together,
which dilutes whichever pass is the most extreme outlier). The frame title
reports the real elapsed time between pass N and pass 1 from the ``timestamp``
field stored in the h5 (rather than an approximate hand-typed offset).

GIF output only -- Pillow (a matplotlib dependency already) writes the animation,
so this needs no external tool like ffmpeg. Frames are rendered through the same
``bbox_inches="tight"`` savefig path plot_mpa_mosaic normally uses (via a temp
file) rather than grabbing the raw canvas, so they are cropped the same way a
single saved plot would be; frames are then padded to a common size (title
text width varies a little pass to pass) and dithered before the GIF's
unavoidable 256-color palette quantization, to keep the smooth colormap from
banding.
"""
import argparse
import glob
import os
import re
import tempfile

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from PIL import Image

import plot_mpa_mosaic as pm
import sca_geometry as sg
from compile_rcs_trend import load_from_hdf5
from compare_rcs_h5 import LEDS, WAVELENGTH_NM, ratio_map
from process_rcs_trending import FLIGHT_DERIVED_ROOT

RUN_LABEL_RE = re.compile(
    r"CAR190_(\d{5})_(\d{2})_(\d{3})_(\d{3})_(\d{8}|unknown)\.h5$")

PLOTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "plots", "animations")


def find_passes(derived_root):
    """Group completed run h5 files by (program, execution_plan, segment).

    Returns a dict keyed by that triple, each value a ``{pass_number: path}``
    dict -- the grouping the run label is constant over except for the pass
    digits, so within a group "pass 1" unambiguously means the reference run.
    """
    groups = {}
    for path in glob.glob(os.path.join(derived_root, "CAR190_*.h5")):
        match = RUN_LABEL_RE.search(os.path.basename(path))
        if not match:
            continue
        program, execution_plan, pass_num, segment, _date = match.groups()
        key = (program, execution_plan, segment)
        groups.setdefault(key, {})[int(pass_num)] = path

    return groups


def load_passes(paths_by_pass):
    """Load every pass's dictionary + LED arrays, keyed by pass number."""
    return {pass_num: load_from_hdf5(path)
            for pass_num, path in sorted(paths_by_pass.items())}


def elapsed_label(dictionary_n, dictionary_1):
    """Human-readable elapsed time from pass 1's timestamp to pass N's."""
    t1 = pd.to_datetime(dictionary_1["timestamp"], utc=True)
    tn = pd.to_datetime(dictionary_n["timestamp"], utc=True)
    hours = (tn - t1).total_seconds() / 3600.0

    return f"+{hours:.1f} hr" if hours >= 0 else f"{hours:.1f} hr"


def render_frame(ratio_arr, extent, sca_corners, title, vmin, vmax, dpi):
    """Render one frame with plot_mpa_mosaic's overlay plot, return a PIL Image.

    Saved through ``filename=`` rather than grabbed off the raw canvas, so it
    gets the same ``bbox_inches="tight"`` crop a normal saved plot gets.
    """
    fd, tmp_path = tempfile.mkstemp(suffix=".png")
    os.close(fd)
    try:
        fig, ax = pm.plot_with_sca_overlay(
            ratio_arr, extent, sca_corners=sca_corners,
            title=title, vmin=vmin, vmax=vmax,
            xlabel="FPA X [mm]", ylabel="FPA Y [mm]",
            cmap="viridis", colorbar_title="Response ratio", dpi=dpi,
            filename=tmp_path)
        plt.close(fig)
        image = Image.open(tmp_path).convert("RGB")
        image.load()
        return image
    finally:
        os.remove(tmp_path)


def pad_to_common_size(images):
    """Center each image on a shared white canvas sized to the largest frame.

    The tight crop's bbox shifts by a few pixels between frames (title text
    width varies with the elapsed-time string), which would otherwise give a
    GIF with a mismatched, jittering frame size.
    """
    max_w = max(image.width for image in images)
    max_h = max(image.height for image in images)
    padded = []
    for image in images:
        canvas = Image.new("RGB", (max_w, max_h), "white")
        offset = ((max_w - image.width) // 2, (max_h - image.height) // 2)
        canvas.paste(image, offset)
        padded.append(canvas)

    return padded


def animate_led(led, passes, reference_pass, extent, sca_corners,
                perc_min, perc_max, dpi, duration_ms, out_dir):
    """Build and save one LED's pass-ratio animation; return the output path."""
    ratios = {}
    for pass_num, (dictionary, led_arrays) in passes.items():
        if pass_num == reference_pass:
            continue
        ref_dictionary, ref_led_arrays = passes[reference_pass]
        ratios[pass_num] = (ratio_map(led_arrays[led], ref_led_arrays[led]),
                            elapsed_label(dictionary, ref_dictionary))

    if not ratios:
        return None

    # vmin/vmax are the widest of each pass's *own* percentile range, not a
    # percentile taken over all passes pooled together -- pooling dilutes
    # whichever pass has drifted the most, since its tail is a small share of
    # the combined pixel count once every other, less-drifted pass is mixed in.
    per_frame_bounds = [np.nanpercentile(ratio, [perc_min, perc_max])
                        for ratio, _label in ratios.values()]
    vmin = min(lo for lo, _hi in per_frame_bounds)
    vmax = max(hi for _lo, hi in per_frame_bounds)
    print(f"  {led}: colorbar vmin={vmin:.4f} vmax={vmax:.4f} "
         f"(min/max of each pass's own {perc_min:.0f}/{perc_max:.0f} percentile)")

    frames = []
    for pass_num in sorted(ratios):
        ratio_arr, label = ratios[pass_num]
        title = (f"{led} ({WAVELENGTH_NM[led]:.0f} nm)  "
                 f"pass {pass_num} / pass {reference_pass}  ({label})")
        frames.append(render_frame(ratio_arr, extent, sca_corners, title,
                                   vmin, vmax, dpi))

    frames = pad_to_common_size(frames)
    # GIF is limited to a 256-color palette; dithering hides the banding that
    # a smooth viridis gradient would otherwise show once quantized to it.
    dithered = [image.quantize(colors=256, dither=Image.Dither.FLOYDSTEINBERG)
               for image in frames]

    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, f"trend_ratio_{led}.gif")
    dithered[0].save(out_path, save_all=True, append_images=dithered[1:],
                     duration=duration_ms, loop=0)

    return out_path


def main():
    parser = argparse.ArgumentParser(
        description="Animate per-LED response-ratio trend across passes.")
    parser.add_argument("--derived-root", default=FLIGHT_DERIVED_ROOT,
                        help="Directory of compiled run h5 files to glob. "
                             f"Default: {FLIGHT_DERIVED_ROOT}")
    parser.add_argument("--out-dir", default=PLOTS_DIR,
                        help=f"Directory to write GIFs to. Default: {PLOTS_DIR}")
    parser.add_argument("--reference-pass", type=int, default=1,
                        help="Pass number to ratio every other pass against. "
                             "Default: 1")
    parser.add_argument("--perc-min", type=float, default=5.0)
    parser.add_argument("--perc-max", type=float, default=95.0)
    parser.add_argument("--dpi", type=int, default=150)
    parser.add_argument("--duration-ms", type=int, default=800,
                        help="Milliseconds each frame is shown. Default: 800")
    args = parser.parse_args()

    file_root = os.path.dirname(os.path.abspath(__file__)) + "/"
    sca_physical_centers, fpa_extent, sca_width = sg.read_sca_physical_centers(
        file_root=file_root)
    sca_physical_corners = sg.create_corner_coordinates(sca_physical_centers,
                                                         sca_width)

    groups = find_passes(args.derived_root)
    if not groups:
        raise SystemExit(f"No CAR190_*.h5 files found under {args.derived_root}")

    for key, paths_by_pass in sorted(groups.items()):
        if args.reference_pass not in paths_by_pass:
            print(f"skipping run {key}: no pass {args.reference_pass} "
                 f"(reference) among passes {sorted(paths_by_pass)}")
            continue

        print(f"\n----- run {key}: passes {sorted(paths_by_pass)} -----")
        passes = load_passes(paths_by_pass)
        for led in LEDS:
            out_path = animate_led(led, passes, args.reference_pass, fpa_extent,
                                   sca_physical_corners, args.perc_min,
                                   args.perc_max, args.dpi, args.duration_ms,
                                   args.out_dir)
            if out_path:
                print(f"  wrote {out_path}")


if __name__ == "__main__":
    main()
