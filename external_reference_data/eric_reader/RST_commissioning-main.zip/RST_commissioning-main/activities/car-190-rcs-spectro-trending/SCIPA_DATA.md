# Digest: OTP00775_RCSEChrmStbA_SCIPAc_R17 (SCIPA romancal L2 outputs)

Path: `/mnt/roman-science-internal/romancal_l2_outputs/tvac/scipa/ChromaticStability/OTP00775_RCSEChrmStbA_SCIPAc_R17`

TVAC ground-test data product from the **sRCS Chromatic Stability, Side A** test
(OTP00775, test script `OTP00775_RCSEChrmStbA_SCIPAc_R17.txt`, test phase
`TVAC_HOB`, test side `MCEA`, program/SUID `00775`, visit `0077501056054001001`).
Also internally labeled `WFI sRCS Thermal Stability`. These are `romancal`
Exposure-pipeline L2 (rate/cal) outputs produced from L1 uncal ramps, run via
`parallel_exppipe` on 2026-09-08 (per the log timestamps), with inputs staged
from `s3://roman-s3-romcom/SCIPA/OTP775/TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA/Activity_<N>/`.

## Top-level layout: 7 "Activities"

The dataset root contains 7 numbered subdirectories, `1` through `7`, one per
OTP **Activity** (`meta.groundtest.activity_number` matches the directory
name). Each activity is a single SRCS (Stimulated Reference Calibration
Source / LED) illumination setting, exercised across (nearly) all 18 WFI
detectors:

| Activity | `wfi_otp_targettype` | LED bank2 setting | Approx. wavelength | Exposure time | SCAs present |
|---|---|---|---|---|---|
| 1 | `DARK` (`wfi_otp_wfi_ewa: HOME_DARK`) | LED off (`srcs_led_current: 0`, band `[-99]`) | — (dark reference) | 180.26 s | 17 (no WFI08) |
| 2 | `sRCS-FLAT` | bank2 band 1, HIGH range | 625 nm | 44.28 s | 17 (no WFI08) |
| 3 | `sRCS-FLAT` | bank2 band 2, HIGH range | 880 nm | 44.27 s | 17 (no WFI08) |
| 4 | `sRCS-FLAT` | bank2 band 3, HIGH range | 1070 nm | 44.27 s | 17 (no WFI08) |
| 5 | `sRCS-FLAT` | bank2 band 4, HIGH range | 1300 nm | 44.27 s | 17 (no WFI08) |
| 6 | `sRCS-FLAT` | bank2 band 5, HIGH range | 1550 nm | 44.28 s | 16 (no WFI05, WFI08) |
| 7 | `sRCS-FLAT` | bank2 band 6, HIGH range | 1750 nm | 44.27 s | 17 (no WFI08) |

So Activity 1 is a dark/background reference exposure, and Activities 2-7 are
a sweep of the SRCS LED bank2 across 6 wavelength bands (625-1750 nm) used to
probe chromatic response stability. Start times run consecutively from
~06:07:40 to ~06:21:52 UTC on 2025-10-03 (roughly 2.5-3.5 min apart), i.e. all
7 activities were taken back-to-back in one continuous test block.

`WFI08` is absent from every activity (not part of this dataset at all), and
`WFI05` is additionally missing from Activity 6 only. No other gaps were
found, and no pipeline failures were logged (`grep`'d all `*.log` for
`'success': False` — none found; every processed file reports
`ExposurePipeline completed successfully`).

## Per-SCA structure within an Activity

Each activity directory is flat (no further subdirectories) and contains,
per SCA (`WFI01`-`WFI18`, e.g. `WFI18` &#8594; SCA 18), three files sharing a
common `SCIPA_TVACHOB_SRCSCH_<17-digit-timestamp>_WFI<NN>` prefix (the
timestamp is the exposure start time, matching `meta.exposure.start_time`):

- `..._WFI<NN>_cal.asdf` — the calibrated L2 `ImageModel` product
  (`roman:` tag `wfi_image-2.1.0`), by far the largest file (~275-285 MB
  apparent size per SCA; sums to ~25 GB apparent across the whole dataset,
  though actual disk usage on this mount is much smaller, likely due to
  filesystem-level dedup/compression on the backing store).
- `..._WFI<NN>_wcs.asdf` — a small (~35 KB) `wfi_wcs-2.1.0` companion holding
  just the GWCS distortion model (`wcs_l2`) and metadata, saved separately
  from the cal product.
- `..._WFI<NN>_uncal.log` — the full `parallel_exppipe`/`stpipe` processing
  log for that file (~26 KB, ~400 lines): S3 download of the uncal input and
  `tvac_config.asdf`, metadata parsing, then the `ExposurePipeline` step-by-step
  log, ending with a success summary (elapsed time, peak memory, group/frame
  counts).

51 files per activity (17 SCAs x 3 files) except Activity 6, which has 48
(16 SCAs x 3 files) due to the missing WFI05. 354 files total.

### Calibration steps applied (from `meta.cal_step` in the `cal.asdf` files)

Consistent across all activities/SCAs:

- `COMPLETE`: `dq_init`, `saturation`, `refpix`, `dark_decay`, `linearity`,
  `ramp_fit`, `dark`, `assign_wcs`
- `SKIPPED`: `flat_field`, `photom`, `source_catalog`, `tweakreg`
- `INCOMPLETE`: `flux`, `outlier_detection`, `skymatch`
- `N/A`: `wfi18_transient` (a WFI18-specific step, not applicable to other SCAs)

i.e. this is a ramp-to-rate/dark-and-linearity-corrected, WCS-tagged L2
product; flat-fielding, photometric calibration, source detection and
astrometric tweaking were intentionally skipped for this TVAC ground-test
processing.

### Other notable metadata (`meta.groundtest`, `meta.tvac`, `hdf5_meta`)

- `ma_table_name: 71_FULLMA510ALL` (MA table 510), read pattern with 57 groups
  / 1 frame for every file.
- Per-SCA detector telemetry is embedded (detector temperature ~92.3-92.6 K,
  SCE bias/reset voltages, readout column number, etc.), plus raw HDF5
  frame-header telemetry (`hdf5_meta.FrameHeaders`) and OTP/SUID/visit
  identifiers tying each file back to the original L1A HDF5 files under
  `/css/romanst/archive/SCIPA/TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA/...`.
- Many spacecraft-level fields (pointing, ephemeris, velocity aberration,
  guide star RA/Dec) are TVAC placeholders (`-999999.0` / `'?'`), as expected
  for ground testing with no real telescope pointing.
- Minor warnings seen in the logs (consistent across files): `AsdfPackageVersionWarning`
  for several CRDS reference files built with a newer `roman_datamodels`
  extension version than installed, an `overflow encountered in cast` warning
  during linearity/ramp-fit, and a handful of pixels flagged as
  "spurious values outside remotely plausible range" during linearity
  correction. None of these were fatal; all files completed successfully.

### Accessing metadata/parameters for analysis

- Open with `roman_datamodels`/`asdf` (not `astropy.io.fits`):
  ```python
  import roman_datamodels as rdm
  dm = rdm.open(".../SCIPA_TVACHOB_SRCSCH_<ts>_WFI11_cal.asdf")
  dm.meta.groundtest.activity_number   # 1-7
  dm.meta.groundtest.wfi_otp_targettype  # DARK / sRCS-FLAT
  dm.meta.groundtest.led_bank2_approx_wlen  # nm, the swept variable
  dm.meta.groundtest.wfi_mce_srcs_bank2_led_i  # LED drive current, A
  dm.meta.exposure.sca_number, dm.meta.exposure.start_time
  dm.meta.cal_step  # per-step COMPLETE/SKIPPED/INCOMPLETE
  dm.data, dm.dq, dm.err, dm.var_poisson  # 4088x4088 science arrays
  ```
  (plain `asdf.open(path).tree["roman"]["meta"]...` works too if
  `roman_datamodels` isn't installed; the tree is just nested dicts/YAML.)
- The wavelength/illumination sweep variable for this analysis is
  `meta.groundtest.led_bank2_approx_wlen` (nm) together with
  `meta.groundtest.wfi_otp_targettype` (`DARK` vs `sRCS-FLAT`) — that pair is
  what distinguishes the 7 activities. `activity_number` is a convenient
  proxy but is only meaningful in combination with a lookup of what each
  activity means (see table above); it is not itself a physical parameter.
- Per-SCA detector diagnostics (`detector_temp`, `sca_temp`, SCE bias
  voltages, `detector_id`) live under `meta.groundtest` too, one set per file
  (i.e. per SCA per activity) — useful for checking thermal/bias drift across
  the trend.
- `meta.cal_step` tells you what's safe to trust: `assign_wcs`/`dark`/
  `linearity`/`ramp_fit`/etc. are `COMPLETE`, but `flat_field`/`photom` are
  `SKIPPED`, so `dm.data` is in **DN/s-derived electron counts without flat
  or photometric calibration** — flux comparisons across activities are
  relative/uncalibrated-photometry, not absolute physical flux, unless you
  apply your own flat/photom correction.
- Caveat: `meta.groundtest.srcs_led_current`/`srcs_led_flux` are **always 0**,
  even in the LED-on activities (2-7) — they read as unpopulated placeholders
  in this dataset, not the real drive current. The actual LED current is
  `meta.groundtest.wfi_mce_srcs_bank2_led_i` (A) used in the table above;
  don't trust `srcs_led_current` for anything.
- There is no single manifest file listing all 354 files' metadata at once;
  to build a trend table you need to loop over files (per activity, per SCA)
  and pull the fields above out of each `cal.asdf` (or the much smaller
  `wcs.asdf`, which carries the same `meta` block minus `cal_step`/`groundtest`
  telemetry, if you only need WCS/pointing).

# Digest: ql_output/Program_00123 (quicklook slope products)

Path: `/mnt/roman-science-east-2/ql_output/Program_00123`

This is the **quicklook (QL)** pipeline's output for the *same* underlying
TVAC test as above — the `visit_id`/`guid`/`suid` values embedded in every
file (`0077501056054<NNN>001`) and `test_script` (`OTP00775_RCSEChrmStbA_SCIPAc_R17.txt`)
match OTP00775 exactly, just processed by a different, lighter-weight
pipeline under its own run label "Program_00123" (a QL job id, not a new OTP
program). QL was run on 2026-09-09, about a day before the SCIPA romancal L2
reprocessing of the same data (2026-09-08 per those logs — the QL run and the
L2 reprocessing are independent passes over the same archived L1A HDF5 files,
run in whichever order; there's no dependency between them).

## Top-level layout: 7 Activities, one dir + one PNG each

The root contains, per activity, one `<timestamp>_<33-digit-id>_slope_SCAs/`
directory plus a matching `<timestamp>_<33-digit-id>_slope.png`, and three
run-level files: `quicklook.log`, `quicklook_debug.log` (identical, 16
lines/7 activities), and `quicklook_output.csv` (7 rows, one per activity, 438
columns).

The 33-digit id (e.g. `00123010010010010010000000010000`) is a QL-side
SUID-like string; only its digit at position 15 (0-indexed) varies across the
7 entries and equals the activity number 1-7 (confirmed by diffing all 7
strings character-by-character) — everything else about the id is fixed
across the run. The leading `00123` is the QL "Program" id (`Program_00123` in
the path), unrelated to the `00775` OTP/SUID program id carried inside the
data. The directories are **not** listed/processed in activity order — they
were created in wall-clock processing order (1, 2, 4, 5, 6, 7, then 3 last),
visible from the leading `<timestamp>` prefix on each directory/PNG name.

Same 7 activities as the SCIPA dataset (dark reference + 6-band LED sweep),
confirmed via the FITS headers' `activity_number`/`wfi_otp_targettype`/
`start_time`/`exposure_time`, which match the SCIPA table above exactly,
activity-for-activity (the physical wavelength itself, `led_bank2_approx_wlen`,
isn't in the QL headers at all — see the metadata caveat below). Unlike the
SCIPA L2 set, **every** activity here has all 17 available SCAs — Activity 6
is not missing WFI05 in this quicklook set — so `WFI08` is the only SCA
missing anywhere in `Program_00123`.

## Per-activity structure

Each `..._slope_SCAs/` directory holds one file per SCA:

- `..._wfi<nn>_slope.fits.fz` — a single 4096x4096 `float64` **slope
  (rate) image**, GZIP-tile-fpacked (`ZCMPTYPE=GZIP_2`), units electrons/s.
  This is a rate image straight from the ramp, not a calibrated L2 product:
  no `dq`/`err`/variance arrays, and every `cal_step`-style FITS keyword
  (`ASSIGN_WCS`, `DARK`, `LINEARITY`, `RAMP_FIT`, `FLAT_FIELD`, `PHOTOM`, ...)
  reads `INCOMPLETE` in the header — quicklook only fits a slope, it doesn't
  run the calibration pipeline. ~14-16 MB per SCA, ~2 GB total (actual disk
  usage matches apparent size here — no dedup/compression quirk like the
  SCIPA mount).
- The companion `<activity>_slope.png` (one per activity, ~3-5 MB) is a
  rendered mosaic/quicklook display image of all 17 SCAs for that activity —
  for visual inspection, not for quantitative analysis.

## Metadata: FITS headers vs. `quicklook_output.csv`

Every `_slope.fits.fz` file carries most of the **same metadata set** as the
SCIPA `cal.asdf` `meta.groundtest`/`meta.exposure` tree, just stored as flat
FITS `HIERARCH` header cards instead of nested YAML — e.g. `activity_number`,
`wfi_otp_targettype`, `wfi_mce_srcs_bank2_led_range`, `sca_number`,
`detector_id`, `detector_temp`, a linear (non-celestial) display WCS
(`CRVAL1/2`, `CDELT1/2`, `WCSNAME=MPA_mm`), and the same raw MCE telemetry
blob (`HIERARCH hdf5_telemetry`) seen in the SCIPA files.

Two things it does **not** carry, checked directly by diffing the headers of
an Activity 1 (dark) and Activity 2 (625 nm LED) file:
- `led_bank2_approx_wlen` (the nm value used in the SCIPA table above) is
  **absent** from the QL headers/CSV entirely. To get the physical
  wavelength for a QL file you must join on `activity_number` against the
  SCIPA table (or re-derive it from the raw telemetry's
  `WFI_MCE_SRCS_BANK2SEL_LED<n>`/`WFI_MCE_SRCS_BANK2_LED_I` inside
  `hdf5_telemetry`).
- `FILTER_NAME`/`FILTER_WAVELENGTH`/`LED_ID` (`'HOME_DARK'`/`1550`/`'s180'`)
  do **not** change between the dark (Activity 1) and an LED-on activity
  (Activity 2) file — they're EWA/legacy fields unrelated to the SRCS LED
  sweep, despite the names looking relevant. Don't use them as an LED-band
  proxy. `srcs_led_current`/`srcs_led_flux` are also always 0 here, same
  placeholder issue as in the SCIPA metadata.

`quicklook_output.csv` is a per-activity (not per-SCA) flattening of one
representative file's header (SCA 1 in every row here) plus an
`output_filepath` column listing all 17 per-SCA `.fits.fz` paths for that
activity, semicolon-separated. It's convenient for a quick per-activity
lookup (`activity_number`, `wfi_otp_targettype`, `start_time`,
`exposure_time`, etc.) but **does not** carry per-SCA values like
`detector_temp`/`detector_id` for SCAs 2-18, and does not carry
`led_bank2_approx_wlen` either — for either of those you must open each SCA's
own FITS header and/or join against the SCIPA table.

`quicklook.log`/`quicklook_debug.log` additionally report, per activity, a
one-line `SLOPE MEDIAN FLUX: min/max/mean` in e/px/s across the mosaic — a
fast sanity-check number without opening any FITS file at all (e.g. Activity
1 (dark): mean 0.021 e/px/s; Activity 2 (625 nm LED): mean 489.4 e/px/s).
Note line 16 of the log is a duplicate re-report of Activity 3 rather than a
distinct 8th entry — there are only 7 activities.

### Accessing metadata/parameters for analysis

- Fastest path for an activity-level trend (7 points, one per wavelength):
  `pandas.read_csv("quicklook_output.csv")` and pull `activity_number`,
  `wfi_otp_targettype`, `start_time`; then join on `activity_number` against
  the SCIPA table above (or the SCIPA `cal.asdf` files directly) to get the
  physical `led_bank2_approx_wlen` — the CSV alone doesn't have it. No FITS
  I/O needed for this level.
- For a per-SCA trend (7 activities x 17 SCAs), you must open each
  `_slope.fits.fz` header individually, e.g.:
  ```python
  from astropy.io import fits
  hdr = fits.getheader(path, ext=1)  # metadata lives in the compressed-image extension, not the empty primary HDU
  hdr["SCA_NAME"], hdr["DETECTOR_TEMP"], hdr["ACTIVITY_NUMBER"], hdr["WFI_OTP_TARGETTYPE"]
  data = fits.getdata(path, ext=1)   # 4096x4096 float64 slope image, e-/s
  ```
  (`ext=1`/`fits.open(path)[1]`, since fpack stores an empty `BITPIX=8,
  NAXIS=0` primary HDU and puts the real image + all metadata in the first
  extension.)
- Because every `cal_step` keyword is `INCOMPLETE`, these slope images have
  **no dark/linearity/flat/photom correction** — the "SLOPE MEDIAN FLUX" and
  raw pixel values are uncalibrated ramp-fit rates. For anything beyond a
  quick relative trend/health check, prefer the SCIPA `cal.asdf` products
  (dark+linearity-corrected) over these QL slopes, or explicitly account for
  the missing corrections.
- Do **not** use `LED_ID`/`FILTER_NAME`/`FILTER_WAVELENGTH`/`srcs_led_current`
  as an LED-band proxy — verified by diffing an Activity 1 (dark) vs.
  Activity 2 (LED-on) header, `FILTER_NAME`/`FILTER_WAVELENGTH`/`LED_ID` stay
  at `'HOME_DARK'`/`1550`/`'s180'` in both, and `srcs_led_current` reads 0 in
  both. To confirm which physical LED band/current was actually enabled for a
  given file, use `wfi_mce_srcs_bank2_led_range` (LOW/HIGH) plus
  `WFI_MCE_SRCS_BANK2SEL_LED<n>`/`WFI_MCE_SRCS_BANK2_LED_I` inside the raw
  `hdf5_telemetry` string (band number vs. approx wavelength is then a
  lookup, matching the SCIPA table above), or just trust `activity_number`
  since it's a 1:1 stand-in for the LED-band setting in this test.

# Comparing the two datasets

Both digests above describe **the same 7-activity OTP00775 sRCS Chromatic
Stability (Side A) TVAC test** (dark + 6-band LED sweep, 625-1750 nm, SCAs
01-18 minus WFI08), processed twice by two different, independent pipelines:

| | SCIPA `romancal` L2 (first section) | QL `Program_00123` (second section) |
|---|---|---|
| Purpose | Full offline calibration pipeline reprocessing | Fast, real-time-style quicklook during/after TVAC |
| Product | `_cal.asdf` (calibrated `ImageModel`) + `_wcs.asdf` | `_slope.fits.fz` (raw ramp-fit rate image) + mosaic `.png` |
| Format | ASDF (nested YAML tree + binary blocks) | FITS (fpack-compressed, flat `HIERARCH` header) |
| Calibration state | `dq_init`/`saturation`/`refpix`/`dark_decay`/`linearity`/`ramp_fit`/`dark`/`assign_wcs` = `COMPLETE`; `flat_field`/`photom`/etc. = `SKIPPED` | *Every* cal step = `INCOMPLETE` (slope only, no correction at all) |
| Science array(s) | `data`, `dq`, `err`, `var_poisson`, `chisq`, `amp33`, border ref pixels (4088x4088, several arrays) | single `float64` image (4096x4096), no dq/err/variance |
| Per-file size | ~280 MB (`cal.asdf`) + ~35 KB (`wcs.asdf`) | ~15 MB (`.fits.fz`) |
| Missing SCAs | WFI08 (all activities) + **WFI05 in Activity 6 only** | WFI08 only (all 17 other SCAs present in every activity, including 6) |
| Bulk metadata access | none — must open each `cal.asdf`/`wcs.asdf` | `quicklook_output.csv`, one row/activity (but only SCA-1 values; per-SCA still requires opening each FITS header) |
| Directory naming | numbered `1`-`7` = `activity_number` directly | timestamp-prefixed ids in wall-clock processing order (not activity order); activity number is buried in a fixed-width id field, cross-checked against the FITS header's `ACTIVITY_NUMBER` |
| Run/job id in path | `OTP00775_RCSEChrmStbA_SCIPAc_R17` (the actual OTP name) | `Program_00123` (an unrelated QL run/job id — the real OTP id `00775` only shows up inside file metadata) |
| Run date (per logs) | 2026-09-08 | 2026-09-09 |

**Practical implications for CAR-190 trending analysis:**

- `activity_number`/`wfi_otp_targettype` are common to both datasets and
  agree exactly (both trace back to the same L1A HDF5 header), so
  `activity_number` is the safe join key between the two. The physical LED
  wavelength (`led_bank2_approx_wlen`) is **only** in the SCIPA `cal.asdf`
  metadata, not in QL's headers/CSV (see caveat above) — to label a QL file
  by wavelength, join it to the SCIPA table via `activity_number`, don't
  expect to find the nm value inside the QL file itself.
- The SCIPA L2 (`cal.asdf`) is the right source for **quantitative** chromatic
  stability analysis (has `linearity`/`dark`/`ramp_fit` correction applied,
  plus per-pixel `err`/`var_poisson`), at the cost of much larger files and no
  bulk CSV — expect to write a loop that opens all 354 files.
- The QL slopes are the right source for a **fast sanity check** (median flux
  per activity straight out of `quicklook.log`, or a quick per-activity CSV
  read) but are uncorrected — don't use QL median-flux numbers as your final
  chromatic-stability metric, only as a cross-check that the L2 numbers are
  in the right ballpark.
- Watch the WFI05/Activity-6 gap: it exists in the SCIPA L2 set but not in QL
  — if you're stitching a per-SCA trend across activities from the L2 set,
  Activity 6/WFI05 needs to be explicitly handled as missing (e.g. dropped or
  flagged) rather than assumed present; the QL set has no such gap since it
  still has the frame.
- Neither dataset's directory name alone can be trusted to line up 1:1 with
  activity number — SCIPA's directories are the activity number, but QL's are
  processing-order timestamps, so always key on the metadata field
  (`activity_number`), not the directory listing order, when joining the two.

# Digest: compiled trend product (`TVAC_HOB_OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA.h5`)

Path: `/mnt/roman-science-east-2/eswitzer/RCS_trend/TVAC_HOB_OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA.h5`

This file is the output of `activities/car-190-rcs-spectro-trending/compile_rcs_trend.py`
(`process_trending_run()` &#8594; `save_to_hdf5()`) for the **R17** run of the
`OTP00775_RCSEChrmStbA_SCIPAc` test — the same 7-activity dark+6-band LED
sweep documented in the two sections above, but this script reads from a
**third, different source tree** entirely: `root_data =
"/sdh/analysis/gs448wfi/ql_scipa_output/"`, under
`TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA/stability_check/`. That path
is not mounted on this host (`/sdh` doesn't exist here), so only the compiled
`.h5` output could be inspected directly — the source CSV and per-run mosaic
FITS files it was built from were not available to cross-check.

## What the script does

`process_trending_run()`:

1. Reads a single per-run telemetry CSV from `.../stability_check/*.csv`
   (one row per activity, 7 rows for activities 1-7 — this is presumably the
   engineering/quicklook HK CSV for the run, distinct from both the
   `quicklook_output.csv` and the `cal.asdf`/`.fits.fz` metadata already
   documented above).
2. Derives `LED_STATUS` per row from the `WFI_MCE_SRCS_BANK2SEL_LED<n>`
   columns (`'ENA'` &#8594; that LED's number, or `'DRK'` if none enabled) and a
   `Visit_ID` per row, regex-extracted from an `exp_path_done` column
   (`/(\d{19})/Science/` pattern &#8594; the 19-digit visit id, same style of id
   seen in the two datasets above).
3. Pulls scalar/vector housekeeping telemetry (medians across the run) into
   `meta_dict`: COBA/RCS-sphere/RCS-board/MPA-A/MPA-B temperatures, 6 ACM LVDT
   actuator positions, and — per activity (indexed by CSV row) — the SRCS
   bank2 LED forward voltage and photodiode reading (dark-baseline-subtracted:
   `pd_array -= pd_array[0]`).
4. For each activity, globs a **mosaic** FITS file (full-focal-plane
   quicklook mosaic, not a per-SCA file) out of `.../mosaics/` by matching
   the row's `Visit_ID`, opens extension 1, and rebins it into `rebin x rebin`
   (default 5x5) NaN-aware superpixels (`nan_superpixel()`, sum/count-based
   mean ignoring non-finite pixels).
5. Dark-subtracts each LED activity's rebinned mosaic against activity 1's
   rebinned mosaic (`subtract_dark=True` by default) and writes the six
   dark-subtracted, rebinned mosaics plus the metadata dict to the `.h5`
   file via `save_to_hdf5()`.

Note the `if __name__ == "__main__"` block's `run_list` currently only has
R19-R21 uncommented — the R17 entry (line 378, `#run_list.append("TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA")`)
is commented out now but was evidently run previously (uncommented) to
produce this existing `R17` `.h5` file; the script's current state doesn't
by itself regenerate it.

## HDF5 structure (verified with `h5py`, this file specifically)

Two top-level groups, matching `save_to_hdf5()`'s layout exactly:

- **`dictionary/`** — one dataset per scalar/vector metadata field:
  - `timestamp` (string, e.g. `'2025-10-03T06:11:07.026Z'`) — the run's `SC
    Timestamp`/`Timestamp` at CSV row `stamp_pos` (default 3, i.e. LED3/1070nm's
    row), **not** a per-activity timestamp array.
  - `COBA_temp`, `RCS_Sphere_temp`, `RCS_Board_temp`, `MPA_A_temp`,
    `MPA_B_temp` — scalars, run-median housekeeping temperatures (K; sphere
    and board temps have `+273.15` applied in the script, i.e. converted from
    &deg;C to K, so they're already in K here: e.g. `RCS_Sphere_temp=200.04`,
    `RCS_Board_temp=248.12`).
  - `ACM_LVDT` — shape `(6,)`, the 6 ACM actuator LVDT positions (run-median,
    one value per actuator, **not** per activity).
  - `RCS_forward_voltage`, `RCS_photodiode` — shape `(7,)` each, one value
    **per CSV row / activity** (index 0 = dark/activity 1, indices 1-6 =
    activities 2-7 / LED1-LED6). `RCS_photodiode[0]` is always exactly `0` by
    construction (`pd_array -= pd_array[0]`) — it's a dark-baseline-subtracted
    photodiode signal, not an absolute reading.
- **`led_arrays/`** — six datasets `LED1`...`LED6` (gzip level 9 + fletcher32
  checksum), each shape `(900, 1400)` `float64`. These correspond 1:1 to
  Activities 2-7 in the same wavelength order as the SCIPA table above
  (`LED1`=625nm ... `LED6`=1750nm) — **already dark-subtracted** (activity
  1's rebinned mosaic has been subtracted out) and **already rebinned**
  5x5-to-1 from whatever the source mosaic FITS resolution is. All six arrays
  share the same NaN footprint (43.1% NaN in this file) — that's the
  inter-chip-gap/no-detector mask of the mosaic geometry, identical across
  LEDs since the focal-plane layout doesn't change activity-to-activity.
  Typical finite-pixel medians in this R17 file run ~1400-1640 (dark-subtracted,
  arbitrary/DN-like units — not flux-calibrated; this mosaic pipeline is
  independent of both `cal_step` chains documented above, so no calibration
  state is directly comparable).

## Open gap to bridge (per-SCA &#8594; mosaic)

This `.h5` file operates one level of abstraction above the two datasets
digested earlier: those are organized **per-SCA, per-activity** (18 files x 7
activities), while this one is a single **whole-focal-plane mosaic array per
activity** (6 arrays, LED-only, already dark-subtracted and rebinned). The
mapping between the two — i.e. which pixel range of the `(900, 1400)` mosaic
corresponds to which SCA/amp from the SCIPA/QL per-SCA products — is not
recoverable from this `.h5` file alone (no SCA boundaries, WCS, or gap
geometry are stored in it), and the source mosaic FITS files it was built
from (`.../stability_check/mosaics/*.fits`, on the unmounted `/sdh` tree)
weren't available to inspect directly in this session. Establishing that
per-SCA-to-mosaic-pixel mapping (likely via the mosaic FITS file's own WCS/
extension structure, or by re-deriving the focal-plane layout from the SCIPA
`assign_wcs`-complete `cal.asdf` WCS models) is the next step mentioned by
the user and is not yet addressed by this document.
