# The photodiode correction: acquisition, storage, application

The RCS relative-calibration source lamp drifts. The photodiode correction divides that
drift out of every epoch before any film-growth number is extracted, using a diode that
watches the same lamp the detectors do:

```
pd_factor[LED] = reference_pd[LED] / pd_net[LED]          per LED, per epoch
pd_net[LED]    = pd_raw[LED] - pedestal                   per epoch, one scalar pedestal
```

This document is the single account of where `pd_raw` comes from, what the pedestal is and
how it is chosen, how both are stored, and how the factor reaches the pixels. It is written
to be read **before** quoting a trend number, because three of the choices below change what
a response change means.

Everything numeric was measured on the authoritative v3 set: 176 epochs in
`/data/eswitzer/rcs_trend_v3/` (CAR-190 + CAR-216, bin 16), its reference card
`rcs_reference_card_v3.ecsv`, and `digests/digests_v3_10_06_26/`.

**Status: applied, on all 176 epochs, with no refusals.** Every product carries
`corrections_applied = 'photodiode,side,acm'` (a string -- see
[sharp edges](#sharp-edges-and-known-inconsistencies)) and
`photodiode_source = 'pd_net (dark-window pedestal)'`; the card reports `pd_valid_n = 6` for
all 176 epochs with no NaN; the digests record
`photodiode_source = 'photodiode/per_activity'` (the keyed path, not the positional mirror)
and `photodiode_flagged_epochs = []`.


## The three things most likely to be got wrong

1. **The correction is chromatic, and must not be collapsed to a scalar.** Over the run the
   six factors span 0.98168-1.00487, and the maximum across-LED spread within a single epoch
   is **2.240 %**. Decomposed, the chromatic residual is **0.610 % rms** against only
   **0.170 %** common-mode. So a response change common to all six LEDs is *not* what this
   correction removes, and an achromatic stand-in for it is wrong by roughly the size of the
   effect.
2. **An unusable channel becomes NaN, never 1.0.** A silently *uncorrected* LED looks exactly
   like a real response excursion of whatever size the lamp drifted; a NaN propagates to the
   digest and is counted. The epoch is still written, with five good LEDs and one NaN.
3. **The logical LED names are not the hardware LED numbers.** The permutation is stable over
   all 176 epochs and is `LED1->hw6, LED2->hw1, LED3->hw2, LED4->hw3, LED5->hw4, LED6->hw5`.
   Anything indexed by hardware number (the turn-on clip behaviour, `CHECK_RATIO_NOMINAL`)
   must be permuted before it is compared to anything indexed by LED name.


## 1. Acquisition: one EngDB query per pass

**The photodiode value is not in the L2 products.** `meta.rcs` carries
`{active, bank, counts, electronics, led}` and none of the 146 metadata leaves of a
`*_cal.asdf` matches photo/diode/pd/current/volt/lamp/srcs. MAST supplies the pixels and the
activity timing; the diode comes from a different service entirely.

**Service.** The Engineering Data Portal, `https://mast.stsci.edu/edp/api/v0.1/mnemonics/spa/roman/data`
([rcs_edp.py:32](rcs_edp.py#L32)), over raw `urllib` with an `Authorization: token` header
and the same `MAST_API_TOKEN`. `result_format=csv`, 300 s timeout, 3 retries with a 2.0
backoff. A mnemonic that fails returns `None` rather than raising
([rcs_edp.py:118-120](rcs_edp.py#L118-L120)) -- a partial pull degrades rather than aborting
the pass.

**Mnemonics** ([rcs_photodiode.py:44-60](rcs_photodiode.py#L44-L60)), all in volts:

| constant | mnemonic | role |
|---|---|---|
| `PD_COLUMN` | `WFI_MCE_SRCS_PD2_V` | **the measurement** -- the active diode for BANK2 work |
| `PD_CHECK_COLUMN` | `WFI_MCE_SRCS_PD1_V` | second diode; a cross-check, not a dark reference (Sec. 3) |
| `FORWARD_COLUMN` | `WFI_MCE_SRCS_BANK2_LED_V` | LED forward/drive voltage |
| `LED_SELECT_COLUMNS` | `WFI_MCE_SRCS_BANK2SEL_LED1..6` | per-LED enable, string `ENA`/`DIS` |

`rcs_photodiode.LED_SELECT_COLUMNS` is a deliberate local copy of the same list in
`read_per_sca`, so the module stays numpy+pandas-only; `rcs_photodiode.self_test` asserts the
two still agree.

**One query spans the whole pass**, not one per activity -- 21 requests instead of 147.
`rcs_telemetry.build_telemetry_table` ([rcs_telemetry.py:78-89](rcs_telemetry.py#L78-L89))
takes the earliest activity start and the latest end from the MAST metadata and pads both
ends by `cfg.PD_PAD_MINUTES = 10.0` minutes (`--pd-pad-minutes`). It raises if no start times
survived the MAST query. The `series` dict it hands back
(`return_series=True`) is what the whole reduction rides on, so the EDP is hit exactly once
per pass.

> **The pad does not reliably buy quiet telemetry, and this is why `dark_window` is the
> preferred pedestal source.** Trend passes run back to back, so 10 minutes reaches into the
> adjacent pass: measured, **59 %** of the pre-run pad and **60 %** of the post-run pad have
> an LED enabled, in states this run never visits
> ([rcs_trend_config.py:126-133](rcs_trend_config.py#L126-L133)). The reasoning that
> motivated raising the pad from 5 to 10 minutes does not hold. Any pedestal rule that pools
> "everything off in the window" is therefore pooling across a pass boundary.

**Entry points.** `--pd-only` ([process_rcs_trending.py:1068-1073](process_rcs_trending.py#L1068-L1073))
does the metadata query, the EDP pull, the reduction, and writes the ECSV + `pd_<label>.h5`
sidecar while streaming **no pixels**. It is deliberately dispatched *ahead of*
`rcs_mast.check_plan_coverage`, so a pass with a short pixel listing still gets its diode
reduced. With `--use-plan` it reads a cached query plan and skips MAST entirely, making a
176-epoch PD sweep a seconds-per-pass job. `--pd-plot` adds the two per-epoch figures.
`--skip-telemetry` sets `series = None` and omits the `photodiode/` group altogether.


## 2. The dark subtraction

The pedestal is **not** a constant and **not** a separate dark exposure. It is the median of
PD samples during an all-LEDs-off interval of this pass's own telemetry, preferentially the
off interval overlapping the `DARK` activity's exposure window.

It is a large subtrahend, not a trim: on the v3 set the pedestal is **32.8 % of `pd_raw`**
(pedestal 0.116090-0.116414 V against illuminated `pd_raw` 0.3464-0.3968 V, giving `pd_net`
0.2302-0.2805 V).

### Step 1 -- a state timeline on the diode's own timestamps

`rcs_photodiode.led_state_timeline` ([rcs_photodiode.py:207-252](rcs_photodiode.py#L207-L252)).
The PD is **never resampled.** The six enable channels are step-interpolated
(last-value-at-or-before) onto the PD's sample times, because the PD is the measurement and
the enables are a slower *description of configuration*.

State codes ([rcs_trend_config.py:147-149](rcs_trend_config.py#L147-L149)): `-1` unknown,
`0` all off, `1..6` the single enabled hardware LED, `7` more than one enabled.

The load-bearing subtlety: **an enable channel with no sample yet is `UNKNOWN`, not `DIS`.**
Treating it as `DIS` would declare the head of the query window "all off" and let a pedestal
be adopted from an interval with no telemetry at all.

### Step 2 -- run-length encode, keeping the short runs flagged

`rcs_photodiode.state_intervals` ([rcs_photodiode.py:276-305](rcs_photodiode.py#L276-L305)).
Runs shorter than `cfg.MIN_INTERVAL_SAMPLES = 3` are **kept and flagged
`is_transition=True`**, not dropped and not merged. One flipped telemetry sample therefore
cannot manufacture a one-sample "all off" interval in the middle of an exposure and have it
adopted as the pedestal.

### Step 3 -- four sources, in a stated precedence

`rcs_photodiode.adopt_pedestal` ([rcs_photodiode.py:336-409](rcs_photodiode.py#L336-L409)).
Candidates are off intervals that are not transitions and have at least
`cfg.PEDESTAL_MIN_SAMPLES = 5` samples.

| order | `source` | rule |
|---|---|---|
| 1 | `dark_window` | candidates overlapping the `DARK` activity's exposure window (inclusive both ends) |
| 2 | `pooled_off` | **all** non-transition off intervals pooled; warns |
| 3 | `nearest_off` | every `state == OFF` sample, ignoring the run-length test; warns |
| 4 | `unavailable` | NaN, `n_samples = 0`, warns; `pd_net` cannot be formed |

The value is a **median** and the quoted `rms` is `1.4826 x MAD`, i.e. a robust sigma, not an
RMS. On the v3 set the adopted source is `dark_window` on **176/176 epochs** -- every fallback
is untaken, and `pd_pedestal.png` reports `0 fallback source(s)`. Median pedestal rms is
15.9 uV (max 21.7 uV).

**Drift is measured and reported, never corrected.** `_drift_v_per_hr` is a least-squares
slope through the per-off-interval medians and needs at least two of them; correcting it
would mean choosing a drift model from two or three points. Median `|drift|` is
1.08e-05 V/hr, worst 1.11e-03 V/hr. A warning fires when
`abs(drift) > max(3.0 * rms, 1e-3)` -- the `3.0` and the 1e-3 V/hr floor are hardcoded at
[rcs_photodiode.py:402](rcs_photodiode.py#L402) and documented nowhere else.

### Step 4 -- the subtraction, and the floor under the denominator

```python
pd_net = pd_raw - pedestal.value                              # one scalar pedestal per epoch
valid  = bool(np.isfinite(pd_net) and pd_net > pd_min_net)
```
([rcs_photodiode.py:493-499](rcs_photodiode.py#L493-L499))

`cfg.PD_MIN_NET = 0.01` V exists because **`pd_net` is a denominator**: a bad pedestal can
turn a ~0.24 V net into a few mV and produce a ~60x response factor that is
indistinguishable from a real instrument event
([rcs_trend_config.py:110-114](rcs_trend_config.py#L110-L114)). The self-tests assert the
counterfactual explicitly (`abs(0.25/0.004 - 62.5) < 1e-9`) so the guard cannot be removed
without a test naming what it was for. Zero of the 176 epochs come near it.

### PD1 gets its own pedestal

`reduce_photodiode` builds a **separate** interval table from the check-diode trace on the
*same* state partition and calls `adopt_pedestal` again
([rcs_photodiode.py:613-617](rcs_photodiode.py#L613-L617)). Reusing PD2's intervals would
have reported PD2's drift twice; adopting PD2's *pedestal* for PD1 inflated the check-ratio
scatter by a third.

It has to be separate, because **the two diodes' pedestals are genuinely different numbers.**
Measured over all 176 v3 epochs from the *same* dark window with identical `n_samples`
(176/176 agree on both counts):

| | PD2 (HgCdTe) | PD1 (InGaAs) |
|---|---|---|
| pedestal | 0.116090 - 0.116414 V | 0.111944 - 0.112078 V |
| median offset | -- | **4.326 mV below PD2** |
| robust sigma | 10.6 - 21.7 uV (med 15.9) | 0.44 - 0.88 uV (med 0.88) |
| `\|drift\|` | med 1.08e-05, max 1.11e-03 V/hr | med 9.18e-07, max 2.19e-04 V/hr |

So PD1 is the **quieter** device by a median factor of **18.1x** (range 14.5 - 47.5) -- which
is not a reason to prefer it, for reasons in [Sec. 8](#8-the-two-diodes-and-what-a-side-swap-does).
Its dark noise is in fact *bounded rather than measured*: both streams share a 2.98023e-07 V
telemetry quantum, and PD1's pedestal sigma takes exactly three values -- {1.0, 1.5, 2.0} quanta,
with 156 of 176 epochs at exactly 2 LSB -- while PD2's median is 36.0 quanta spread over 35
distinct values. PD1's dark performance is at the digitizer floor.

Both pedestals are derived per epoch from that epoch's own dark window, which is why **the
pedestal is the one part of the chain that is already side-swap-safe**: a different physical
diode is measured, not assumed. Only the *reference* is global. See [Sec. 8](#8-the-two-diodes-and-what-a-side-swap-does).


## 3. Per-LED aggregation

`rcs_photodiode.reduce_per_activity` ([rcs_photodiode.py:426-554](rcs_photodiode.py#L426-L554)),
one row per activity in write order.

**Window** is inclusive on both ends, deliberately matching `rcs_edp.sample_window` so the
legacy comparison is like-for-like. If no sample lands inside, the nearest sample to the
window midpoint is used and `rule` becomes `nearest`; if the stream is empty the row is
all-NaN with `rule = missing`.

**The on-LED window is the modal state, not the enable interval.** `_modal_state` takes the
state holding the most in-window samples, with **known states beating `UNKNOWN` however few
their samples** -- "we have no telemetry for part of this window" is not a competing
description of the hardware. `pd_raw` is the median over the modal-state samples only;
`pd_raw_all` is the median over all in-window samples and is kept solely to reproduce the
frozen compiler's rule. Nothing is sigma-clipped anywhere. `state_pure` records whether every
in-window sample agreed, and a non-dark activity with `state_fraction < 1.0` gets a
"window straddles an enable change" warning.

### The 2.5 V rail is counted, never clipped

`cfg.PD_RAIL_V = 2.5` V. A railed sample is *clipped, not measured*, so one inside an
exposure window would pull `pd_raw` up and inflate the factor **in the direction that looks
like the lamp brightening**. Clipping it would hide the condition; counting it makes the
condition auditable. The per-activity count is `n_railed` and the epoch sum is the
`photodiode/@n_railed_in_window` attribute.

Three of the six LEDs do rail, on turn-on, every epoch. Measured over all 176 epochs
(`plots/pd_sequence/pd_settle_summary.ecsv`):

| hardware LED | logical | seconds railed | settle margin (s) |
|---|---|---|---|
| hw1, hw2, hw6 | LED2, LED3, LED1 | 0 | 16 - 190 |
| hw3 | LED4 | 63 - 65 | 56 - 60 |
| hw4 | LED5 | 51 - 52 | 56 - 60 |
| hw5 | LED6 | 34 - 35 | 56 - 60 |

It is genuinely saturation and not a plateau: over the ~64 s hw LED3 sits at the rail, 149 of
152 samples read 2.5000000 V to within one telemetry quantum (2.98e-07 V) while the forward
voltage is still drifting. **The sequence's lead time already covers it**: `settle_margin_s`
(diode back on-scale -> shutter open) is never negative in any of the 1560 activities, minimum
16 s, and **0 activities exposed while the diode was railed.** So the clip is a fact about the
telemetry, not a contaminant in the measurement.

### The check diode is not a dark reference

PD1 sees the lamp. Its net is 1.03-1.20x PD2's for five LEDs and **0.205x for LED6
(hw LED5, 1670 nm)** -- that diode barely sees that lamp, because **1670 nm is past the InGaAs
cutoff** ([Sec. 8](#8-the-two-diodes-and-what-a-side-swap-does)). So the useful invariant is the
per-LED *ratio*, which is reproducible across all 176 epochs to 2-4e-3:

```
LED1 1.1346   LED2 1.0558   LED3 1.1631   LED4 1.1933   LED5 1.1668   LED6 0.2050
   624 nm        853 nm        1039 nm       1270 nm       1481 nm       1670 nm
```

Flat to +/-6% across five bands and then a cliff at the longest one. Note the ordering trap:
that list is in **sequence-name** order, which is also wavelength order, but
`CHECK_RATIO_NOMINAL` ([rcs_photodiode.py:1039](rcs_photodiode.py#L1039)) is keyed by
*hardware* LED and is used only by the synthetic self-test fixture. The map is
`LED1->hw6, LED2->hw1, LED3->hw2, LED4->hw3, LED5->hw4, LED6->hw5`, verified on 40 v3 epochs, and
reading a wavelength off a hardware number instead had previously inverted the physical
conclusion in `README.md`.

It is **recorded and never used in a correction.** Its diagnostic value is specifically that
it separates a lamp change from a *device* change: both diodes move together under the lamp
and the ratio holds, whereas a diode swap moves the ratio. That makes it one of the three
witnesses to an MCE side swap ([Sec. 8](#8-the-two-diodes-and-what-a-side-swap-does)).

### Three accounts of which LED was on, none of them silent

The state timeline's `hardware_led`, `rcs_edp.enabled_leds`' mode over the window, and an
optional `meta_led` are all reported; none silently wins. `meta.rcs.led` is **deliberately
not** offered as a third source, because it counts LEDs in *activity* order -- which is the
`(6,1,2,3,4,5)` permutation -- and so would disagree by construction on every activity.
`rcs_telemetry.report_led_order` asserts that permutation.


## 4. Storage: the same diode at three levels of reduction

Every pass carries its photodiode data three times over, at increasing levels of reduction.
Knowing which one a consumer reads is the difference between a guarded and an unguarded
number.

| level | location | what it is |
|---|---|---|
| raw stream | `photodiode/stream/` | every 1 Hz sample, ~2100-2600 per epoch |
| windowed median | `housekeeping/WFI_MCE_SRCS_PD2_V` | the old-style per-activity median, **no pedestal removed** |
| pedestal-subtracted net | `photodiode/per_activity/pd_net` | the quantity the correction uses |

Writer: `rcs_photodiode.write_photodiode_group`
([rcs_photodiode.py:719-820](rcs_photodiode.py#L719-L820)); reader `read_photodiode_group`.
It opens the file in append mode and deletes/recreates `photodiode/` if present, so it is
idempotent. On the per-SCA products it is called **after** the atomic `os.replace`, because it
opens the final path itself and no reader may observe a half-written group.

### `photodiode/stream/` -- `(n,)` each

`time` (int64, attr `units = "nanoseconds since 1970-01-01T00:00:00"`), `pd_v`, `pd_check_v`,
`forward_v` (float64 V), `state` (int8), `activity_index` (int8, `-1` for none). **Only
`time` carries a `units` attribute**; the voltage datasets do not.

This is why `plots/pd_sequence/` can be rebuilt from the products with no network access --
the full timestream is embedded in every epoch.

### `photodiode/intervals/` -- `(n_intervals,)` each

`state`, `t_begin`, `t_end`, `n_samples` (int64), `pd_median`, `pd_mad` (float64 V),
`is_transition` (bool). The stream indices `i_begin`/`i_end` are deliberately **not** stored;
they are recovered on read by `np.searchsorted`.

### `photodiode/pedestal/` and `photodiode/check_pedestal/` -- attributes only

`value`, `rms`, `drift_v_per_hr` (float, V and V/hr), `n_samples` (int), `source` (one of the
four in Sec. 2), `warnings` (array of str). **This is the provenance record for the pedestal
choice**, and it is what `pd_pedestal.png` reads back.

### `photodiode/per_activity/` -- one entry per activity, in write order

`activity_key`, `rule` (vlen str); `hardware_led`, `number`, `state_code`, `pd_n_samples`,
`n_railed` (int64, `hardware_led = -1` is the sentinel for dark/none); `pd_raw`,
`pd_raw_all`, **`pd_net`**, `pd_rms`, `forward_v`, `pd_check_v`, `pd_check_net`,
`pd_check_ratio`, `state_fraction` (float64); `pd_net_valid`, `state_pure`, `is_dark`,
`multiple_leds` (bool); and `pd_net_legacy` (the frozen compiler's
`pd_raw_all - pd_raw_all[dark]` rule, kept bit-for-bit so the 34-product regression still
holds).

### `photodiode/` group attributes

`pd_column`, `pd_check_column`, `forward_column`, `pd_min_net`, `pd_rail_v`,
`n_railed_in_window`, `dictionary_is_legacy`, `warnings`. On the v3 set
`n_railed_in_window = 0` and `warnings` is empty on all 176 epochs.

### The legacy positional mirror, `dictionary/RCS_photodiode`

A 7-element float64 array (dark + 6 LEDs, in activity order), and **its contents differ by
product kind on purpose**:

- **Legacy mosaic h5** -- untouched: `pd_array - pd_array[0]` from the frozen compiler, so
  `dictionary/` stays bit-exact against `/data/eswitzer/rcs_trend` and the old regression
  still means something. `write_photodiode_group` is attached *additively*.
- **Per-SCA raw h5** -- the substitution **is** made: the mirror holds `pd_net`. Verified on
  `CAR190_01039_02_001_001_20260912_raw.h5`, where `dictionary/RCS_photodiode` and
  `photodiode/per_activity/pd_net` are element-wise identical. Alignment is by activity order
  over the **core (non-aux) rows only**; a length mismatch falls back to the compiler rule
  rather than guessing, because the compiler takes its dark from `pd_array[0]` and CAR-216's
  four `AUX_LED3FLAT` rows would corrupt every scalar.
- **Per-SCA calibrated h5** -- `photodiode/` and `dictionary/` are copied **verbatim** from the
  raw parent, and a `calibration/` group is added (Sec. 5).

The root attribute **`photodiode_source`** is the discriminator: `'pd_net (dark-window
pedestal)'` or `'pd_raw - pd_raw[0] (compiler rule)'`. Use it, **not**
`photodiode/@dictionary_is_legacy`, which is written as `True` unconditionally and is false on
every per-SCA raw product (see [sharp edges](#sharp-edges-and-known-inconsistencies)).

### The `pd_<run_label>.h5` sidecars

`--pd-only` and the full staging path both write `pd_<label>.h5` + `pd_<label>.ecsv` into
`<out-dir>/pd/` (`--pd-dir`). Same writer, so the `photodiode/` group is structurally
identical to the in-product one; the file simply contains nothing else, and `run_label` *is*
set as a root attribute because these never get an `annotate_h5` pass. ~100 kB per epoch.

They are **strictly redundant** -- the in-product group is authoritative -- and exist so a
`--pd-only --use-plan` sweep leaves behind everything the turn-on diagnostics need without
staging any imagery. The ECSV alone is insufficient: it carries only the per-activity
reduction, so the settle structure, which lives in the stream, cannot be recovered from it.

The current set is `/data/eswitzer/rcs_trend_v3/h5/pd/` -- 176 h5 + 176 ECSV, complete.

### The ECSV sidecar's metadata keys

`pedestal_v`, `pedestal_rms_v`, `pedestal_n_samples`, `pedestal_source`,
`pedestal_drift_v_per_hr`, the four `check_pedestal_*` equivalents, `pd_column`,
`pd_check_column`, `pd_min_net`, `pd_rail_v`, `n_railed_in_window`, `n_pd_samples`,
`n_state_intervals`, `warnings`, plus `run_label` and `pd_pad_minutes` from the caller. Note
the spelling differs from the h5 group, which uses bare `value`/`rms`/`source` under
`photodiode/pedestal/` -- same facts, two conventions.


## 5. Application

### The reference card holds the numerator

`rcs_corrections.ReferenceCard` ([rcs_corrections.py:322](rcs_corrections.py#L322)), built by
`calibrate_rcs_products.py --make-card` from product *metadata* only -- no pixels.
PD-related columns are exactly `pd_LED1..pd_LED6` (the epoch's `pd_net`, volts) and
`pd_valid_n` (count of LEDs passing `isfinite & > PD_MIN_NET`). `meta["reference_pd"]` is the
reference epoch's six `pd_net` values and is the numerator of every factor; on the v3 card it
is

```
0.243815  0.280437  0.238316  0.241233  0.239608  0.230174
```

**The reference epoch is the earliest by the product's own `dictionary/timestamp`, never by
filename** -- lexicographic sort puts pass 100 before pass 36. The dark entry is already
dropped: `EpochMeta.from_product` slices `group["RCS_photodiode"][()][1:]`.

**Stage 2 reads PD only from the legacy positional mirror.** Grep confirms
`rcs_corrections.py` and `calibrate_rcs_products.py` touch `dictionary/RCS_photodiode`
([rcs_corrections.py:140-141](rcs_corrections.py#L140-L141)) and never
`photodiode/per_activity`. So the card and every stage-2 factor come from the positional
array and carry **no `pd_net_valid` flags**; stage 2's only PD guard is the `PD_MIN_NET`
floor, which it re-derives. The keyed, flagged path exists only in stage 3. The rich
`photodiode/` group is therefore provenance and diagnostics; the 7-element mirror is the
load-bearing path through stage 2.

### The factor

`rcs_corrections.led_scale_factors` ([rcs_corrections.py:227-285](rcs_corrections.py#L227-L285)):

```python
usable = (np.isfinite(epoch_net) and epoch_net > cfg.PD_MIN_NET
          and np.isfinite(ref_net) and ref_net > cfg.PD_MIN_NET)
pd_factor[index] = ref_net / epoch_net if usable else np.nan
total            = pd_factor * side_factor / acm_factor
```

Per LED, independently. The threshold is strict `>`, so `pd_net == PD_MIN_NET` exactly is
invalid. A bad **reference** `pd_net` invalidates that LED **set-wide**. An unusable channel
sets `valid[index] = False`, appends a note, and leaves the other five finite -- the epoch is
not refused, and `apply_factors` multiplies that LED's whole array by NaN rather than falling
back to 1.0.

Measured on the v3 card, per LED over 176 epochs:

| LED | min | max | excursion |
|---|---|---|---|
| LED1 | 1.00000 | 1.00487 | +0.49 % |
| LED2 | 0.99984 | 1.00172 | +0.19 % |
| LED3 | 0.99944 | 1.00146 | +0.20 % |
| LED4 | 0.98168 | 1.00171 | -1.83 % |
| LED5 | 0.98712 | 1.00000 | -1.29 % |
| LED6 | 0.99444 | 1.00000 | -0.56 % |

**The two chromatic families.** The sign splits cleanly as LED1-3 (factor > 1, those lamps
dimmed) against LED4-6 (factor < 1). State it with the per-LED numbers, not as a single
figure: LED1-3 rise by **0.1-0.5 %** while LED4-6 fall by **0.6-1.8 %**. (The familiar
"LED1-3 rise to ~1.004" is true only of LED1; LED2 and LED3 reach ~1.0015.) And **the decon
does not reset this drift** -- LED4 and LED6 keep falling through the transition to a minimum
~75 h later. That is the lamp, not the film, which is why the decon guard belongs on the
*bridge* and not here.

### Stage 2 multiplies it into the pixels

`calibrate_rcs_products.calibrate_one`
([calibrate_rcs_products.py:123-199](calibrate_rcs_products.py#L123-L199)) scales each LED's
stack by its total factor in float32 and records `applied_factor` and `calibration_valid` per
dataset. Non-LED activities (CAR-216's `AUX_LED3FLAT*`) get an explicit, recorded 1.0 rather
than being dropped. The per-LED vectors go into the product's own `calibration/` group as
`led_name, pd_factor, side_factor, acm_factor, total_factor, pd_net, pd_reference, valid`, and
the root attrs gain `corrections_applied`, `reference_card`, `reference_card_sha256`,
`reference_run_label`, and `calibrated_from{,_sha256}`.

### Stage 3 does not re-apply it

This is the dangerous failure mode of the two-stage split, because it is plausible: a factor
of 1.002 applied twice is 1.004, and the whole signal being measured is a fraction of a
percent per pass. `make_sca_digests._corrections_for_stage`
([make_sca_digests.py:757-805](make_sca_digests.py#L757-L805)) keys the decision on the
product's **`stage` attribute** -- a calibrated set returns an all-off `corr`, so the scalars
are not squared -- and reads `corrections_applied` only to label what was applied *somewhere*.
A set mixing raw and calibrated products is a hard `SystemExit`; a two-card set is refused by
`assert_homogeneous`. The override is printed, not silent.

The digest then reports from what it read back, not from the CLI flags: `corrections`,
`corrections_applied_at`, `photodiode_source`, `photodiode_flagged_epochs`. On the v3
digests these are `'photodiode, side, acm'`, `'calibration (stage 2)'`,
`'photodiode/per_activity'`, `[]`.

### Stage 3's own factor path, for raw sets, has a different guard

`make_sca_digests.led_scale_factors` ([make_sca_digests.py:620-643](make_sca_digests.py#L620-L643))
computes the same `reference / epoch` ratio with the same NaN-not-1.0 policy, but validity
comes **entirely from the product's `pd_net_valid` flags** -- `PD_MIN_NET` is never evaluated
there. With `--no-pd-from-product` (or on a legacy product) `photodiode_valid` is `None`, the
validity test is vacuously true, and **a collapsed 0.01 V `pd_net` would form a ~60x factor
with no floor to stop it**. The hole is reported rather than hidden:
`rcs_report.photodiode_log` prints `NOT CHECKED: ... Absence of flags here is absence of a
check, not a clean result.` The default `--pd-from-product` path is keyed by `activity_key`,
and an LED the group omits **keeps the mirror value but is marked invalid** -- a missing entry
is a reason to distrust the number, not to trust the mirror.


## 6. The choices, and why

| choice | alternative | why |
|---|---|---|
| **Chromatic, per-LED factor** | one scalar per epoch | the across-LED spread reaches 2.24 % within an epoch and the chromatic residual (0.610 % rms) is 3.6x the common-mode (0.170 %). A scalar would discard most of the correction while looking right. |
| **NaN for an unusable LED** | fall back to 1.0 | a silently uncorrected LED is a fake response excursion of exactly the size the lamp drifted. NaN propagates and is counted. The tempting middle option -- drop the PD term but keep ACM -- is worse still, because it leaves a *finite, non-unity* number: an uncorrected point inside a corrected series. A self-test asserts that specific case. |
| **Pedestal from a dark window of this pass** | a constant, or the query pad | the pedestal is 32.8 % of `pd_raw`, so it is not a trim; and the pad is 59-60 % illuminated by the adjacent pass, so it is not quiet. |
| **Median + 1.4826*MAD** | mean + RMS | nothing is sigma-clipped anywhere, so the statistic itself has to be robust. |
| **Drift measured, never corrected** | fit and remove it | the fit would come from two or three off-interval medians. It is reported instead, and panel 3 of `pd_pedestal.png` shows the residual a scalar pedestal leaves: worst 293 uV = 0.121 % of `pd_net`. |
| **Rail samples counted, never clipped** | clip at 2.5 V | a railed sample inside a window would bias `pd_raw` upward -- *i.e.* in the direction that looks like the lamp brightening. Clipping hides the condition. |
| **`PD_MIN_NET = 0.01` V floor** | no floor | `pd_net` is a denominator; the un-guarded failure is a 60x factor that reads as a real instrument event. |
| **Short state runs flagged, not dropped** | drop runs < 3 samples | dropping is fine; *merging* would let one flipped sample manufacture an off-interval mid-exposure. Flagging keeps the evidence and excludes it from candidacy. |
| **Unknown != off before first telemetry** | treat as `DIS` | would let a pedestal be adopted from a window with no telemetry. |
| **`stage` attribute decides re-application** | trust the CLI flags | flags describe the invocation; the attribute describes the file. A fully corrected digest labelled uncorrected (or worse, re-corrected) is the failure. |
| **Legacy mirror left alone on mosaics, substituted on per-SCA** | one rule everywhere | the mosaic path is a frozen regression against `/data/eswitzer/rcs_trend`; the per-SCA path is new and should carry the better number. `photodiode_source` records which. |
| **Check diode recorded, never corrected with** | use PD1 to correct PD2 | PD1 sees the lamp (0.205-1.193x PD2 net, LED-dependent), so it is a consistency check, not a dark. |
| **PD2 is the baseline, not PD1** | switch to PD1, which is 18x quieter in the dark | PD1 cannot see 1670 nm -- its InGaAs cutoff suppresses that band 5.7x, leaving one sixth of the sequence with 5.7x less margin against any additive error. A quieter diode that is blind in one band is a worse baseline than a noisier one that sees all six. PD1's dark advantage is also partly illusory: it is quantization-limited at 1-2 LSB, and in-band the gain is only 1.2-3.5x. [Sec. 8](#8-the-two-diodes-and-what-a-side-swap-does) |
| **PD reference re-based per MCE side (opt-in)** | one global `reference_pd` for all time | the diodes differ between sides, so a global reference injects the PD2_B/PD2_A responsivity ratio into every B-side factor as a *per-LED constant*. The ACM bridge fits a single shared step and cannot absorb a chromatic offset, so the residual would survive looking exactly like film growth. Default stays `global` because today's set is single-side and the default card must stay byte-identical. |
| **A decon must *not* re-base, a side swap *must*** | one rule for both | the distinguishing question is whether the *device* is continuous. Across a decon it is the same diode and the same lamp, and lamp drift continues through the transition, so re-basing would delete real signal ([PER_DECON_NORM.md](PER_DECON_NORM.md)). Across a side swap the diode is replaced, so not re-basing would keep a fiction. |
| **Side break at a swap, step reported not applied** | let the bridge stitch through it | the step across a swap mixes a real detector change with a diode change. Fitting it makes it measurable; applying it would silently adopt one interpretation. |
| **Side witness = persistent level shift, verdict conditioned on the label** | flag any epoch where all three witnesses step | tried, and it printed *"DEVICE change (MCE side swap)"* on the 176-epoch side-A set. Differencing neighbouring epochs reads the pass-1 lamp warm-up, and even with block medians there is a **real** coincident shift at epoch 11->12 that is a readout-chain change, not a swap. The rule is necessary, not sufficient; chromaticity is quoted because a replacement diode cannot be achromatic. [Sec. 8](#the-three-witnesses-and-making-mce_side-testable) |
| **`meta.rcs.led` not used as an LED source** | three-way vote | it counts in activity order, the `(6,1,2,3,4,5)` permutation, so it would disagree on every activity by construction. |


## 7. The figures

Four stage-2 figures in `plots/calibration/`, plus a per-epoch set in `plots/pd_sequence/`.
All five are current against the v3 set as of 2026-10-05.

| figure | reads | what it answers |
|---|---|---|
| `plots/calibration/pd_trend_summary.png` | **the card only** | the summary of the correction itself. Panel 1: `pd_net` per LED over its own median, so six different absolute levels are comparable. Panel 2: the factor each epoch receives, `reference_pd / pd_net`, against a unity line -- a NaN appears as a **gap**, not as a factor. Panel 3: `pd_valid_n` per epoch. |
| `plots/calibration/calibration_factors.png` | calibrated products | what stage 2 multiplied in, decomposed into photodiode / side / ACM / total. Each panel states whether that factor is achromatic; **the PD one should not be.** |
| `plots/calibration/calibration_coverage.png` | calibrated products | SCA completeness, and `pd_net` per LED in **volts** against the `PD_MIN_NET` line. Deliberately `pd_net` and not the factor: a ratio hides a common shift in both numerator and denominator, which is exactly the pedestal failure the floor exists for. |
| `plots/calibration/pd_pedestal.png` | calibrated products | whether the subtrahend is sound: which source each epoch used, the differential test of a real baseline shift against a bad off-window, the residual a scalar pedestal leaves, and each LED's `pd_net` range against the pedestal's own. Panel 1 also draws **PD1's own pedestal** on a twin axis, and panel 2 carries the side-witness reading (Sec. 8). |
| `plots/pd_sequence/<run_label>.png` (176) | the `pd_*.h5` sidecars | the raw timestream per epoch on a log axis, the settle shape per activity, and a Gantt row splitting each enable into railed / waiting / exposing. This is where the turn-on clip is legible. Plus the pooled `pd_settle_summary.ecsv`. |

`pd_trend_summary.png` is the "summary plot of the correction" and takes about a second,
because it reads the ~100 kB card rather than 5.5 GB of products. It is written by a
**different entry point** from the other three, which is the main reason it gets missed.

### Regenerating them

```bash
cd ~/code/RST_commissioning/activities/car-190-rcs-spectro-trending
ROOT=/data/eswitzer/rcs_trend_v3
CARD=$ROOT/rcs_reference_card_v3.ecsv

# three figures, from the calibrated products (note: write_all's first argument is a
# directory of stage-2 CALIBRATED products, and it raises if none match)
.venv/bin/python -c "import calibration_plots as c; \
    c.write_all('$ROOT/cal', 'plots/calibration')"

# the summary of the correction, from the card alone
.venv/bin/python calibrate_rcs_products.py \
    --card "$CARD" --plot-pd-trend plots/calibration

# the per-epoch raw timestreams, from the sidecars (no network, no credentials)
.venv/bin/python plot_pd_sequence.py \
    --in "$ROOT/h5/pd/pd_*.h5" --out-dir plots/pd_sequence
```

A useful property worth recording: regenerating the four `plots/calibration/` figures against
v3 reproduces the v2-era files **byte-identically** (same md5 on all four). The aux-L2
reprocessing changed the pixel calibration, and the photodiode is engineering telemetry from
a separate service, so no PD quantity could move -- `pd_net` is bit-identical between the two
cards (worst `|diff|` over 176 x 6 = `0.000e+00`). If a future rebuild *does* move these
figures, the photodiode acquisition itself changed.

That property was used as the test when Sec. 8's work added PD1 to `pd_pedestal.png`: of the three
`write_all` figures, `calibration_coverage.png` (`9538bb69...`) and `calibration_factors.png`
(`366e0a89...`) stayed byte-identical and **only** `pd_pedestal.png` moved
(`65cb5fd6...` -> `f726e922...`). An unchanged md5 on the other two is the cheap proof that reading
the new `photodiode/check_pedestal` attrs did not disturb the collector everything else shares.

### The self-tests

`process_rcs_trending.py --self-test` is the single no-credentials gate and chains
`rcs_photodiode`, `rcs_corrections`, `calibrate_rcs_products`, `calibration_plots`,
`make_sca_digests`, and `rcs_report`. The PD-relevant assertions worth knowing exist:
self-calibration gives exactly 1.0; `dim = 0.9 x nominal` gives `1/0.9`; a 0.004 V `pd_net`
gives NaN on that LED and finite on the other five, with the 62.5x counterfactual asserted;
a collapsed *reference* invalidates set-wide; the keyed lookup picks LED6 over an intervening
`AUX_LED3FLAT1`; `--no-photodiode` really leaves pixels at 100.0 *and* says so in
`corrections_applied`; `cal_epoch/cal_reference` reproduces the response ratio to 1e-6, which
is what licenses the two-stage split at all. `calibration_plots.self_test` plants a 0.004 V
`pd_net` and asserts both poles of the pedestal differential test -- a real baseline step
reads as removed, a bad off-window reads as leaked.

Sec. 8's work added these, all under the same gate:

- `rcs_photodiode` -- the **hardware<->sequence<->wavelength pin**: the suppressed channel is
  hardware LED 5 = sequence `LED6` = 1670 nm = the *longest* band, the five shorter bands are
  flat to <=1.2 in ratio, and the suppressed one is >=4x down. Verified to bite: monkey-patching
  `SEQUENCE_LED_FOR_HARDWARE` to the identity map produces exactly three failures. Plus PD1's
  pedestal is asserted *not* to equal PD2's, which the fixture previously only checked
  indirectly through the ratio.
- `rcs_corrections` Sec. 9 -- 13 checks: the three `assert_pd_reference_spans` cases; a two-side
  `per-side` card whose first B epoch factor is exactly 1.0 per LED with the A origin untouched;
  a `global`-mode numerator demonstrated to leak `1/diode_ratio` with std > 0.01; **bit-exactness**
  of `per-side` against `global` on a single-side set (`np.all(diff == 0.0)`);
  `"pd_reference_mode" not in base.to_table().meta`; and ECSV round-trips with and without the
  mode key.
- `make_sca_digests` -- 15 checks on the side break: `side_change_indices` for none, one and a
  swap-back; `side_boundaries == {6: "A->B"}`; `side_scale_per_led` pinned **B-nominal** (equal to
  the raw ratio, and >=1e-3 away from its reciprocal, so an inversion cannot pass); captured-stdout
  tests that `report_side_boundary` prints its three readings in order and says *"reported, never
  applied"*; digest-meta round-trip; and **a single-side digest carries no `side_*` keys at all**.
- `calibration_plots` -- six witness readings, including that a product with **no** PD1 pedestal
  reads as no witness at all rather than as a witness that did not step, that a single-epoch
  excursion in all three is not a level change, and that the joint signature *without* a side
  label is reported as a chain change rather than a swap.


## 8. The two diodes, and what a side swap does

Everything above treats the photodiode as a measurement. This section is about the two
*devices*, because the correction inherits their properties and one of those properties
changes when the MCE side changes.

### The devices

| | `WFI_MCE_SRCS_PD2_V` | `WFI_MCE_SRCS_PD1_V` |
|---|---|---|
| material | **HgCdTe** | **InGaAs** |
| role here | the measurement, and the baseline throughout | a check, recorded never corrected with |
| role in the instrument | BANK2's measurement diode | **BANK1's measurement diode** |
| band coverage | all six | **blind at 1670 nm** |
| dark pedestal | 0.11609 - 0.11641 V | 4.33 mV lower |
| dark noise | 36 telemetry LSB (resolved) | 1 - 2 LSB (**quantization-limited**) |

PD1 is the spare *only* because all flight trending is BANK2 -- `bank` is a hardcoded
`"BANK2"` at every flight call site, and `rcs_products.py:317-318` picks the diode from the
bank. On a BANK1 run the roles would reverse.

### The cutoff, and the mislabel it exposed

PD1's net relative to PD2's, in **band** order, with the hardware channel named because the
two numberings do not agree:

| band | 624 nm | 853 | 1039 | 1270 | 1481 | **1670** |
|---|---|---|---|---|---|---|
| sequence name | LED1 | LED2 | LED3 | LED4 | LED5 | **LED6** |
| hardware LED | 6 | 1 | 2 | 3 | 4 | **5** |
| PD1/PD2 net | 1.1350 | 1.0566 | 1.1639 | 1.1941 | 1.1676 | **0.2052** |

Flat to +/-6% across five bands, then a 5.7x collapse at the longest one. That is the InGaAs
band edge: lattice-matched In_0._53Ga_0._47As cuts off near 1.7 um, and the edge moves *shorter*
as the diode cools. PD2 reads a healthy 0.231 V on the same LED, as HgCdTe should.

> **This corrected a conclusion, not just a label.** `README.md` and
> `rcs_photodiode.py` previously read the wavelength off the *hardware* LED number against
> `cfg.LED_WAVELENGTHS`, which is keyed by the *sequence* names. That put the `0.2052` at
> 1481 nm and led the README to state the suppression was "not a detector cutoff." The map is
> `LED1->hw6, LED2->hw1, LED3->hw2, LED4->hw3, LED5->hw4, LED6->hw5`, verified on 40 v3 epochs with
> no exceptions. The mislabelled row was physically absurd -- a 5.7x dip at 1481 nm with full
> response restored at 1670 nm -- and that absurdity is what gives the correct reading away.
> A self-test now pins `hw5 <-> LED6 <-> 1670 nm`.

### Why PD1 stays a check, even though it is the quieter diode

PD1 is 18.1x quieter in the dark (median; range 14.5-47.5). That is a real advantage and it is
still not enough:

- **It is blind in one band.** 5.7x less signal at 1670 nm means 5.7x less margin against any
  additive error, on one sixth of the sequence. A baseline has to work for all six LEDs.
- **The dark advantage is partly an artifact.** PD1's dark sigma is *bounded, not measured*: it
  takes exactly three values -- 1, 1.5 or 2 telemetry quanta -- with 156/176 epochs at exactly
  2 LSB. The true dark noise is somewhere at or below the digitizer floor.
- **In-band the advantage shrinks to 1.2-3.5x.** Measured per hardware state over 10 epochs:
  hw1 2.14, hw2 3.49, hw3 2.04, hw4 1.81, hw5 1.24, hw6 1.22. Dark noise is not the limiting
  term in a `reference/epoch` ratio of illuminated nets.
- **Stability near a cutoff does not extrapolate.** Over 176 epochs LED6's check ratio is the
  *tightest* of the six in fractional terms (5.72e-05, against 6.2-7.7e-05 for the others), so
  there is no measured instability -- but the whole set is one month at one controlled
  temperature, with the diode sitting on a band edge whose position moves with temperature.
  Absence of scatter here is not evidence it would survive a thermal excursion.

A-side PD2 is noisier than B-side PD2, so the dark-noise term improves after the swap anyway.

### What a side swap does

**The diodes are different physical devices on the A and B sides.** So after a swap the PD
trending must be *re-established* rather than carrying the A-side t=0 PD as the ongoing basis.

**The trap: nothing in the telemetry announces the change.** Every RCS mnemonic is
bank-specific and none is side-specific -- there is no `_A`/`_B` or `MCEA`/`MCEB` variant of
`WFI_MCE_SRCS_PD2_V` anywhere. The same name returns a different diode. The only announcement
is the `mce_side` attribute, which on all 176 products reads `assumed:flight-side-A` -- an
assumption, not a measurement.

**Why a global reference is not merely untidy.** `meta["reference_pd"]` is one vector from the
earliest epoch set-wide, so with a global reference every B-side factor carries the
`PD2_B/PD2_A` responsivity ratio as a **per-LED constant**. That offset is chromatic, and the
ACM bridge cannot absorb it: `rcs_acm._design_matrix`
([rcs_acm.py:422-436](rcs_acm.py#L422-L436)) fits one polynomial per LED plus **a single
shared step column**, and `step = exp(solution[-1])` is one scalar. An achromatic step is
absorbable; a chromatic one is not. The surviving residual would be a per-LED multiplicative
offset at a known time -- **which is what film growth also looks like.** A diode swap
masquerading as film is the failure this section exists to prevent.

`bridge_led_spread` (`np.ptp` of `BridgeStep.per_led`) is what would show it. It is recorded
and has never gated acceptance anywhere; at a side boundary `report_side_boundary` now reads it
out loudly as three numbers (see *Two gauges* below). It is **not** a refusal there,
deliberately: a chromatic spread at the *first* B-side boundary is expected,
because that boundary is the measurement. The refusal lives where it is unambiguous and
actionable instead -- `assert_pd_reference_spans` refuses a multi-side card built in `global`
mode.

### The three witnesses, and making `mce_side` testable

A swap is loud in quantities the pipeline already stores every epoch:

| witness | stability over 176 A-side epochs | reads a swap as |
|---|---|---|
| `photodiode/pedestal/@value` (PD2) | ~0.32 mV total range | a persistent level shift |
| `photodiode/check_pedestal/@value` (PD1) | ~0.13 mV total range | a persistent level shift |
| `pd_check_ratio` per LED | 5.7-7.7e-05 fractional | a persistent level shift, per LED |

Against that stability a device change is glaring. But the first version of this test was
written as *"a step in both pedestals plus a step in the ratio is the device"*, and run against
the real 176-epoch v3 set that reading printed **"read as a DEVICE change (MCE side swap)"** on
a set labelled side A throughout. Two separate things were wrong, and both are worth recording
because each would have shipped a confident false verdict.

**1. A step is not a level change.** Standardising *neighbouring-epoch* differences puts the
reading wherever the largest single excursion is, and in this set that is the **pass-1 lamp
warm-up** (epoch 1->2, 299 uV) -- which moves all three witnesses at once and then relaxes. The
statistic is now a difference of **block medians**: median of the 5 epochs after a boundary
minus the median of the 5 before, over the pooled scatter about those two medians
(`_level_shift_sigmas` in [calibration_plots.py](calibration_plots.py)), NaN where either block
has fewer than 3 finite epochs. A one-epoch excursion scores near zero on it; that is a pinned
self-test. The scale is floored at the series' median |diff| because PD1's dark level is often
constant to the bit, and a zero scale makes every boundary infinitely significant.

**2. There is a real coincident three-witness shift in the flight record, on side A.** With the
persistence statistic the strongest coincident boundary in the v3 set is **epoch 11 -> 12**
(pass 11 -> pass 13; pass 12 is absent), reading 53x / 439x / 42x against local scatter:

| | shift at epoch 11->12 | persists |
|---|---|---|
| PD2 pedestal | **+307 uV** | all 164 later epochs |
| PD1 pedestal | **+131 uV** | all 164 later epochs |
| `pd_check_ratio` | **-0.14 %**, and only **23 % chromatic** across the six LEDs | all 164 later epochs |
| `pd_net` | unmoved | -- |

Both diodes' dark levels stepped and stayed stepped, while the *lit* nets did not move. That is
a change in the readout chain -- a bias, gain or offset change common to both banks -- not a lamp
event and not a swap. The cause is now known: a **WFI power cycle** between passes 11 and 13
(operations, 2026-10-10), which also lost pass 12. Pass 13 is a one-pass detector outlier as well,
+0.07-0.09 % nearly achromatic, with 0.08 % rms per-SCA scatter; see `MANIFEST.md`. **So the three-witness rule is necessary but not sufficient.**

**Chromaticity is the discriminator a swap cannot fake.** A replacement diode has a different
responsivity *curve*, enormously so across PD1's cutoff (see above: 1.14 at 624 nm against 0.21
at 1670 nm), so a genuine swap moves `pd_check_ratio` by a strongly LED-dependent amount. A
bias or offset change is achromatic. The real event's 23 % is in between and well below the
~600 % a modestly different diode pair produces in the self-test fixture, so the reading quotes
the number rather than thresholding on it.

**The verdict is therefore conditioned on the `mce_side` label, not a substitute for it.**
`_side_witness` reports one of four readings, and the figure and stdout both carry it:

| witnesses | `mce_side` changes there | reading |
|---|---|---|
| all three shift and persist | yes | the **labelled swap is corroborated**, with the chromaticity |
| all three shift and persist | no | a **photodiode-chain change, NOT a swap on these labels** -- what the v3 set actually says |
| one or two shift | no | named, and *"not the joint signature"* -- a baseline or off-window move |
| none shift | yes | the swap is **not corroborated**; *"only the label is load-bearing"* (closely matched diodes are allowed to be quiet) |

This is what converts `mce_side_source='assumed'` from an unverifiable assertion into a
testable one, and it is why `pd_pedestal.png` panel 1 now draws both diodes. Its reading is
printed under the figure's line in `write_all`, so it appears in the stage-2 log even when
nobody opens the PNG.

### The mechanism: `--pd-reference per-side`

`calibrate_rcs_products.py --make-card --pd-reference {global,per-side}`, default `global`.
In `per-side` mode the card gains `side_reference_pd`, a `{side: (6,)}` map holding **each
side's earliest epoch**, and `factors_for` selects the numerator by the epoch's `mce_side` --
mirroring `segment_reference_lvdt`, which already does exactly this per ACM segment. The first
B-side epoch's factor is then 1.0 per LED by construction, which is the "reset to unity at the
far side of the swap" the trend needs.

One refusal and one note, because the flag is easy to forget:

- **A card spanning more than one `mce_side` built in `global` mode is refused**, naming the
  chromatic-masquerade failure and pointing at the flag. `assert_pd_reference_spans` in
  [rcs_corrections.py](rcs_corrections.py) is a module function rather than inline in
  `ReferenceCard.build` precisely so it is testable without h5 products. This is the guard that
  makes the mechanism safe if nobody remembers the flag.
- **A B-side reference epoch with an A-nominal side correction is reported, not refused.**
  `led_scale_factors` applies `side_factor` to the epoch and never to the reference, so "on the
  A-side scale" is strictly coherent only with an A-side reference. The original intent here was
  a refusal; it was downgraded to a loud **NOTE** in `ReferenceCard.report()` because a
  **B-only** set is internally coherent -- `side_factor` then applies uniformly to every epoch and
  divides out of every ratio -- and a refusal would block a legitimate run for a gauge question.
  The note names the gauge rather than guessing the intent.

In `global` mode the new keys are **omitted from the ECSV entirely**, so the default card stays
byte-identical and no stage-2 re-run is needed. This is load-bearing: the card's sha256 is
recorded in all 176 products and `assert_homogeneous` refuses a mismatch.

### Two gauges, which must not be conflated

| | what it is | where it points |
|---|---|---|
| **response origin** | response == 1 at **t=0 on the A side**, the very beginning | unchanged by any of this; `time_hours` and every `boundary_time` keep their zero |
| **side gauge** | the number you multiply an A-side value by to read it on the B-side scale | **B-nominal**, because the instrument is expected to stay on B once it moves |

The side gauge is interpretive -- it says how to translate A and B numerically -- and the
pipeline **reports it and never applies it**. At a side boundary `BridgeStep.per_led` *is* that
chromatic A<->B vector, recorded as `side_scale_per_led` alongside the `side_factor` in force so
the composition stays recoverable. `B_SIDE_CORRECTIONS` today is the A-nominal ground-derived
SCA table; the flight replacement comes from bridging the detector trend across the swap,
cleanest from a `--no-side` run so the fit measures the raw ratio rather than a residual on top
of the ground numbers. The eventual flip to B-nominal is a change to that table and its
consumers, not to the response origin.

**The B-side bridging constraint itself is separate work and needs B-side data.** What exists
now is the segment break at the swap, the three-number `report_side_boundary` reading (a note,
not a gate -- see above), and the `side_scale_*` meta slot the number lands in.

### Resolved at the 2026-10-06 swap

The swap happened between CAR-190 plan 3 passes 57 and 71, and every witness above fired:
- PD2 pedestal -1.92 mV, PD1 +1.06 mV;
- the two-diode ratio moved -5.8, -1.5, +0.5, -0.9, -0.8, -8.2 % by LED, a chromatic
  8.7-point spread;
- with the ratio keyed by sequence slot, `pd_pedestal.png` reads "the LABELLED A->B swap is
  corroborated by all three witnesses", at 327x, 3571x and 1678x local scatter.

A fourth witness turned up that needs no baseline: the LED select map (sequence LED -> BANK2SEL
line) changed from `612345` to `132465`. It is a renumbering, not a wavelength change; PD1's
1670 nm cutoff stayed on sequence LED6. The ratio in `calibration_plots` was keyed by hardware
number until then, which would have compared different LEDs at four of six positions. It is now
keyed by sequence slot.

What was implemented, as planned here, with one change of design:

- **`--pd-reference per-side` is the card default.** The B-side PD factor is 1.0 at pass 71.
- **The side swap is bridged, not reported.** The step across it is now one step per LED,
  common to every SCA (`rcs_acm.fit_side_step`), fitted against each (SCA, LED)'s own trend.
  It is applied in the digests and recorded in every calibrated product as
  `calibration/side_bridge`. The per-SCA ACM bridge is no longer fitted at a side boundary. Its
  single shared step is what could not absorb a chromatic offset, the failure this section
  warned of; the side step is chromatic by design and SCA-common by constraint.
- **The step absorbs the photodiode swap** along with the electronics and the LED drive: with the
  PD re-based per side, nothing else ties the A diode to the B one. Measured (A scaled onto B):
  LED1 0.8933, LED2 0.9439, LED3 1.0322, LED4 0.9919, LED5 0.9911, LED6 1.0006, totals
  +/-1-13 x 10^-4 (188-201 epochs; +/-0.6-3 x 10^-4 at 185, the same values).
- **Gauge: B-nominal in the products, A-side t=0 in the digests**, as the "Two gauges" table
  above requires. `B_SIDE_CORRECTIONS` is no longer applied to calibrated products and is
  recorded on `side_bridge` for comparison. In this gauge it reads 0.941...0.986, unlike the flight
  step, because it covered the electronics alone.

See `DIGEST_TRENDS.md` (*The side bridge*) and `RCS_TREND_REFERENCE.md` Sec. 5 and Sec. 7.5.

**One standing record retired.** Sec. 7's byte-identity check on the four `plots/calibration/`
figures was against schema-1 products. The figures now read the schema-2 recorded multipliers,
and the photodiode panel is re-based at the swap, so they changed on purpose. The test that
replaces it is the v3 regression: schema-2 digests reproduce the schema-1 ones to <= 1.75 x 10^-7.


## Sharp edges and known inconsistencies

None of these affects a number on the v3 set. They are recorded because each would be
expensive to rediscover.

1. **`photodiode/@dictionary_is_legacy` is wrong on every per-SCA raw product.** It is written
   as `True` unconditionally ([rcs_photodiode.py:817](rcs_photodiode.py#L817)), including from
   `rcs_products.write_raw`, where the mirror holds `pd_net`. Verified directly: on
   `CAR190_01039_02_001_001_20260912_raw.h5` the attr says `True` while
   `dictionary/RCS_photodiode` is element-wise equal to `photodiode/per_activity/pd_net`. **Use
   the root attr `photodiode_source`.**
2. **`corrections_applied` has an unpinned type.** `calibrate_rcs_products.py:169` writes a
   comma-joined **string**; `rcs_products.self_test:1058` writes the same attribute as a
   **list**. Reproduced: a list-valued attr stringifies to `"['photodiode' 'side' 'acm']"`, so
   `str(applied).split(",")` yields one garbage token and `'photodiode' in carried` is
   `False`. The *pixels* stay safe, because `_corrections_for_stage` keys re-application on
   `stage` -- but `effective` would go all-False, labelling a fully calibrated digest
   uncorrected and un-suppressing the ACM fractional-travel warning on corrected data. All 176
   real products carry the string. No test pins the type.
3. **`_corrections_for_stage` has no test at all** -- the double-application guard, by its own
   docstring "the most dangerous failure mode of the two-stage split". Nothing asserts that a
   calibrated set returns an all-off `corr`, that a mixed set raises, or that a `--no-acm`
   stage-2 run is reflected in `effective`.
4. **`rcs_trend_plots.plot_pd_trend_summary` has no test**, so the figure whose docstring
   promises the NaN gap is visible is never rendered under the gate.
5. **`plot_pd_sequence.py:22` cites a flag that does not exist** -- `--pd-stream-h5`. Grep
   finds it on that one line only. `--pd-only` writes the sidecar unconditionally.
6. **Two `pd_net_valid` tests with different semantics**: `pd_net_valid` uses signed
   `pd_net > PD_MIN_NET` ([rcs_photodiode.py:494](rcs_photodiode.py#L494)) while
   `pd_check_ratio` gates on `abs(pd_net) > pd_min_net`
   ([rcs_photodiode.py:535](rcs_photodiode.py#L535)).
7. **The stored `pd_net_valid` array is never read by stage 2**, which re-derives validity from
   the threshold. The two code paths can drift apart without any test noticing.
8. **Three rail comparisons, two of them with a tolerance**: `>= cfg.PD_RAIL_V` exactly in
   `reduce_per_activity:506`, `>= rail - 1e-6` in `enable_runs:980` and
   `rcs_trend_plots.py:358`.
9. **`read_photodiode_group` is not schema-tolerant.** It reads `n_railed`, `pd_check_net` and
   `pd_check_ratio` unconditionally, so it raises `KeyError` on a group written before those
   fields existed. The graceful "returns `None` if absent" path does not extend to a partially
   schema'd group.
10. **The sidecar `pd_*.h5` is written non-atomically** (`os.remove` then append), unlike the
    products' `_AtomicH5`. An interrupted `--pd-only` can leave a truncated sidecar.
11. **`rcs_telemetry.build_telemetry_table` defaults `pad_minutes=5.0`** against
    `cfg.PD_PAD_MINUTES = 10.0`. Harmless today because every call site passes it explicitly;
    a new caller would silently get the old value.
12. **`pd_min_net` provenance is recorded from config, not from the effective argument.**
    `reduce_photodiode(pd_min_net=...)` can override it in-process, but
    [rcs_photodiode.py:707](rcs_photodiode.py#L707) and
    [:814](rcs_photodiode.py#L814) record `cfg.PD_MIN_NET`. No CLI exposes the override, so it
    cannot currently be wrong.
13. **Hardcoded constants outside `rcs_trend_config.py`**: the drift warning's `3.0` and
    1e-3 V/hr floor ([rcs_photodiode.py:402](rcs_photodiode.py#L402)); the `+ 1.0` s settle
    offset, which assumes a 1 Hz cadence ([:983](rcs_photodiode.py#L983)); the `leak <= 2 *
    resolution` verdict factor in `pd_pedestal.png`; the `spread < 1e-9` "achromatic"
    threshold in `calibration_plots.py:201`; and
    `plt.cm.Blues(0.3 + 0.17 * (seg % 4))`, which gives ACM segments 0 and 4 identical
    shading -- the v3 set has exactly 4 segments, so this is one reconfiguration from biting.

### When to re-base the reference, in one rule

The two cases look alike -- "an event happened, should the PD reference restart?" -- and have
opposite answers. The question that separates them is **whether the device is continuous.**

| | decon cycle | **MCE side swap** |
|---|---|---|
| the lamp | same lamp, drift continues straight through | same lamp |
| the diode | **same diode** | **different diode** |
| re-base the PD reference? | **No** | **Yes** |
| why | the factor corrects *lamp* drift, which a decon does not reset (LED4 and LED6 keep falling to a minimum ~75 h past the transition). Re-basing would inject a spurious step rather than remove one. | the numerator and denominator would come from two different detectors. Not re-basing keeps a fiction, as a chromatic per-LED offset indistinguishable from film growth. |

So: **re-basing is wrong when the hardware is continuous and mandatory when it is not.** A
decon is an event in the *film*; a side swap is an event in the *instrument*. Only the second
one invalidates the reference.

See also: `README.md` for the readings of `pd_pedestal.png` and `calibration_factors.png` in
the context of the full pipeline, `DIGEST_TRENDS.md` for what reaches stage 3, and
`PER_DECON_NORM.md` for the decon column of that table in full.
