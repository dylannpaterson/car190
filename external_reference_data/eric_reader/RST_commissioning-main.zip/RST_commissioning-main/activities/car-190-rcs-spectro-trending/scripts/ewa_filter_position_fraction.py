"""Fraction of time the EWA filter wheel spends in each position, binned.

Reads a ``WFI_MCE_EWA_FILTER_POS`` pull written by ``trend_housekeeping.py``
(e.g. ``plots/housekeeping/EWA.ecsv``) and, per ``--bin-hours`` window,
computes the time-weighted fraction spent in each of five categories:
``POS_1_GRISM`` and ``POS_6_PRISM`` on their own (the two non-imaging wheel
slots), ``HOME_DARK`` and ``POS_UNKNOWN`` on their own (the wheel's own state
labels), and every other ``POS_<N>_<filter>`` slot (the seven imaging
filters plus W146) lumped into ``WIM_FILTER`` -- which imaging filter is
loaded isn't the concern here, only whether one is.

Two panels, sharing a real datetime x-axis: the binned fraction as a stacked
bar chart on top, and the raw, un-binned, time-ordered state sequence as a
per-category timeline underneath -- so a bin's fraction can be checked
against the actual sample-level transitions it was computed from.

    python scripts/ewa_filter_position_fraction.py
    python scripts/ewa_filter_position_fraction.py --in-ecsv plots/housekeeping/EWA.ecsv --bin-hours 4
"""
import argparse
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from astropy.table import Table

IN_ECSV = "plots/housekeeping/EWA.ecsv"
OUT_PNG = "plots/housekeeping/EWA_position_fraction.png"
MNEMONIC = "WFI_MCE_EWA_FILTER_POS"

GRISM = "POS_1_GRISM"
PRISM = "POS_6_PRISM"
CATEGORY_ORDER = [GRISM, PRISM, "HOME_DARK", "POS_UNKNOWN", "WIM_FILTER"]
CATEGORY_COLOR = {
    GRISM: "#0072B2",
    PRISM: "#009E73",
    "HOME_DARK": "#2b2b2b",
    "POS_UNKNOWN": "#D55E00",
    "WIM_FILTER": "#8a8880",
}


def categorize(label):
    """Collapse a raw EWA position label to one of the five trend categories."""
    if label in (GRISM, PRISM, "HOME_DARK", "POS_UNKNOWN"):
        return label
    return "WIM_FILTER"


def load_positions(path):
    """Load a ``trend_housekeeping.py`` pull as a sorted ``time``/``value`` frame.

    Handles both a single-mnemonic ``--ecsv`` pull (no ``mnemonic`` column)
    and a multi-mnemonic pull (selects ``MNEMONIC`` out of it). ``value`` is
    kept as the raw string label, not ``value_numeric`` -- categorization
    here works off the label itself.
    """
    tab = Table.read(path, format="ascii.ecsv")
    if "mnemonic" in tab.colnames:
        tab = tab[np.asarray(tab["mnemonic"]) == MNEMONIC]
        if len(tab) == 0:
            raise SystemExit(f"{MNEMONIC!r} not in {path}")

    time = pd.to_datetime(tab["time"].datetime64)
    value = np.asarray(tab["value"], dtype=str)
    order = np.argsort(time)

    return pd.DataFrame({"time": time.to_numpy()[order],
                          "value": value[order]})


def _categorized(df):
    """Categorize and time-order ``df``, with each sample's hold duration.

    ``dt_s`` is the wall-clock time until the *next* sample, so the last
    sample (unknown duration) is dropped. Shared by :func:`fraction_by_bin`
    and :func:`state_runs` so both work off the same per-sample durations.
    """
    out = df.copy()
    out["category"] = out["value"].map(categorize)
    out["dt_s"] = (out["time"].shift(-1) - out["time"]).dt.total_seconds()

    return out.iloc[:-1]


def fraction_by_bin(df, bin_hours):
    """Time-weighted fraction of each category per ``bin_hours`` window.

    Durations are summed by category within each bin and normalized by the
    bin's total covered duration -- a bin with a data gap still sums to 1
    over what was actually sampled, not over the full ``bin_hours``.
    """
    cat_df = _categorized(df)
    cat_df["bin"] = cat_df["time"].dt.floor(f"{bin_hours:g}h")
    pivot = cat_df.pivot_table(index="bin", columns="category", values="dt_s",
                                aggfunc="sum", fill_value=0.0)
    for category in CATEGORY_ORDER:
        if category not in pivot.columns:
            pivot[category] = 0.0
    pivot = pivot[CATEGORY_ORDER]

    return pivot.div(pivot.sum(axis=1), axis=0)


def state_runs(df):
    """Collapse the time-ordered samples into contiguous per-category runs.

    Consecutive samples sharing a category are merged into one
    ``(category, start, end)`` row, so a state that holds for hours becomes
    one timeline segment instead of thousands of individual samples -- this
    is what the raw (unbinned) bottom panel draws.
    """
    cat_df = _categorized(df)
    end = cat_df["time"] + pd.to_timedelta(cat_df["dt_s"], unit="s")
    block = (cat_df["category"] != cat_df["category"].shift()).cumsum()
    runs = pd.DataFrame({"category": cat_df["category"].to_numpy(),
                         "start": cat_df["time"].to_numpy(),
                         "end": end.to_numpy(),
                         "block": block.to_numpy()})

    return runs.groupby("block").agg(
        category=("category", "first"), start=("start", "first"),
        end=("end", "last")).reset_index(drop=True)


def _date_axis(ax):
    """Space x-axis date ticks by an auto-picked interval instead of one per bin."""
    ax.xaxis.set_major_locator(mdates.AutoDateLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))


def plot_panels(frac, runs, out_path, bin_hours):
    """Two panels sharing a datetime x-axis: binned fraction, raw state timeline."""
    fig, (ax_frac, ax_state) = plt.subplots(
        2, 1, figsize=(11, 6), sharex=True,
        gridspec_kw={"height_ratios": [3, 1.4], "hspace": 0.08})

    bar_width = pd.Timedelta(hours=bin_hours * 0.9)
    bottom = np.zeros(len(frac))
    for category in CATEGORY_ORDER:
        ax_frac.bar(frac.index, frac[category], bottom=bottom, width=bar_width,
                    align="edge", color=CATEGORY_COLOR[category], label=category)
        bottom += frac[category].to_numpy()

    ax_frac.set_ylim(0, 1)
    ax_frac.set_ylabel("fraction of time")
    ax_frac.set_title(f"{MNEMONIC} -- {bin_hours:g}h occupancy fraction")
    ax_frac.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), frameon=False)
    ax_frac.grid(True, axis="y", alpha=0.3)

    levels = {category: i for i, category in enumerate(CATEGORY_ORDER)}
    for row in runs.itertuples():
        ax_state.hlines(levels[row.category], row.start, row.end,
                         color=CATEGORY_COLOR[row.category], linewidth=5)
    ax_state.set_yticks(list(levels.values()))
    ax_state.set_yticklabels(list(levels.keys()))
    ax_state.set_ylim(-0.5, len(levels) - 0.5)
    ax_state.set_ylabel("raw state")
    ax_state.grid(True, axis="x", alpha=0.3)

    _date_axis(ax_state)
    fig.autofmt_xdate()
    for ax in (ax_frac, ax_state):
        for spine in ("top", "right"):
            ax.spines[spine].set_visible(False)

    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--in-ecsv", default=IN_ECSV)
    parser.add_argument("--out", default=OUT_PNG)
    parser.add_argument("--bin-hours", type=float, default=4.0)
    args = parser.parse_args()

    df = load_positions(args.in_ecsv)
    frac = fraction_by_bin(df, args.bin_hours)
    runs = state_runs(df)

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    plot_panels(frac, runs, args.out, args.bin_hours)

    print(f"  {len(frac)} bin(s) of {args.bin_hours:g}h from {frac.index[0]} "
          f"to {frac.index[-1]}")
    print(frac.round(3).to_string())
    print(f"  {len(runs)} raw state run(s)")
    print(f"  wrote {args.out}")


if __name__ == "__main__":
    main()
