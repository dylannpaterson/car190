"""Record the flat-field finding in ``l2_calibration_audit.ecsv`` ``meta``.

The audit has no ``cal_step_flat_field`` column and deliberately should not get
one. ``ref_file_id`` is a sha256 over the ``ref_file`` branch of the L2 metadata
minus ``crds``, and ``ref_file.flat`` is on that branch, so each equivalence
class's flat state is already pinned by its id being what it is. A
``cal_step_flat_field`` column would be *derived*, and a reader could not tell
whether a given row had been read or inferred -- worse than no column, because a
later partial backfill would leave a mix of the two in one column with nothing to
distinguish them.

What the file was missing is the *finding*: that neither source applies a flat,
and that this was checked against the pixels and not only against the metadata.
That is a conclusion about the whole set, so it belongs in ``meta``, under a key
whose name says it is a finding rather than a per-row read.

This script exists so that edit is reproducible rather than a hand-patched ECSV
header. It is idempotent -- re-running replaces the key with the same text -- and
``--check`` asserts the annotation is present without writing.

    python scripts/annotate_l2_audit_meta.py [--audit PATH] [--check]
"""
import argparse
import sys
from pathlib import Path

from astropy.table import Table

HERE = Path(__file__).resolve().parent
DEFAULT_AUDIT = HERE.parent / "l2_calibration_audit.ecsv"

KEY = "flat_field_finding"

FINDING = (
    "Neither L2 source applies a flat field. Both calibration classes report "
    "cal_step_flat_field='SKIPPED' with ref_file.flat='INCOMPLETE'; the WFI flat "
    "reference is not delivered in CRDS at all. There is deliberately no "
    "cal_step_flat_field column here: ref_file_id is a sha256 over the ref_file "
    "branch minus crds, and ref_file.flat is on that branch, so each class's flat "
    "state is already pinned by its id, and a separate column would be a derived "
    "value indistinguishable from a read one. Cross-checked against the pixels "
    "independently of the metadata on pass 1, the one pass available from both "
    "sources: a flat is a per-pixel multiplicative map, so a differential one "
    "cannot hide in a pixel ratio, and 46 M usable pixels across SCA 1/9/18 give "
    "median ratio 1.00000000, rms 0.0000 %, 100.000 % of pixels within 1e-6, and "
    "64x64 block-median rms 0.0000 %. Consequence: dividing MAST-sourced epochs by "
    "the aux-sourced t=0 reference epoch introduces no per-pixel calibration "
    "ratio, which is what removed the calibration motivation for per-decon "
    "normalization. See PER_DECON_NORM.md."
)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--audit", type=Path, default=DEFAULT_AUDIT,
                        help=f"audit ECSV to annotate (default {DEFAULT_AUDIT})")
    parser.add_argument("--check", action="store_true",
                        help="verify the annotation is present; write nothing")
    args = parser.parse_args(argv)

    if not args.audit.exists():
        print(f"no audit at {args.audit}")
        return 1

    table = Table.read(args.audit, format="ascii.ecsv")
    present = table.meta.get(KEY)

    if args.check:
        if present == FINDING:
            print(f"{args.audit.name}: meta['{KEY}'] present and current "
                  f"({len(FINDING)} chars, {len(table)} rows)")
            return 0
        state = "absent" if present is None else "present but does not match"
        print(f"{args.audit.name}: meta['{KEY}'] {state}; "
              f"re-run without --check to annotate")
        return 1

    if present == FINDING:
        print(f"{args.audit.name}: meta['{KEY}'] already current; nothing written")
        return 0

    # Read-only on the rows: the annotation is about the set, so a change here
    # must never be able to move a per-epoch value. Checked after the write.
    before = [tuple(str(value) for value in row) for row in table]

    table.meta[KEY] = FINDING
    table.write(args.audit, format="ascii.ecsv", overwrite=True)

    reread = Table.read(args.audit, format="ascii.ecsv")
    after = [tuple(str(value) for value in row) for row in reread]
    if after != before or reread.colnames != table.colnames:
        print("ROWS MOVED in the round trip -- this script is supposed to be "
              "meta-only. Restore the file from git and investigate.")
        return 1
    if reread.meta.get(KEY) != FINDING:
        print("the annotation did not survive the round trip")
        return 1

    verb = "added" if present is None else "updated"
    print(f"{args.audit.name}: {verb} meta['{KEY}'] ({len(FINDING)} chars); "
          f"{len(reread)} rows and {len(reread.colnames)} columns unchanged")
    return 0


if __name__ == "__main__":
    sys.exit(main())
