"""Where an L2 frame comes from: MAST/S3, or a local reprocessing directory.

Why this module exists. The Roman L2 products MAST serves for CAR-190 are **not
uniformly calibrated**. Measured on the 176-epoch flight set, the program spans
six CRDS contexts and two cal-software versions, and the `photom` reference file
-- the per-SCA flux calibration -- changed across them. The signature is a
per-SCA, achromatic, multiplicative step:

* Pass 1's L2 was reprocessed on 2026-09-24 onto ``roman_0072.pmap``
  (cal 1.0.2, ``photom`` 0040 -> 0080) while passes 2-37 were left on
  ``roman_0061``/``0065``/``0066``/``0067``.
* The same exposures under the two calibrations differ by **-2.28 % to +3.08 %
  per SCA (1.79 % rms)**, with an across-LED spread of only 0.028 % -- i.e.
  achromatic at 64:1, which is what identifies it as a flux calibration and not
  an instrument event.
* Because the digest divides every epoch by a reference epoch, that step
  propagates as a constant per-SCA scale error over whole blocks of the trend,
  landing right where film growth is fastest.

Re-pulling from MAST cannot fix this: MAST serves whatever each exposure was
processed with at the time, so the inhomogeneity is baked into the archive until
STScI reprocesses the program. The remedy is to let a **local, uniformly
reprocessed** set of L2 products supersede MAST, which is what this module
arranges.

**The all-or-nothing rule is the whole safety argument.** A pass assembled from
some aux frames and some MAST frames would mix two calibrations *inside a single
epoch*, across SCAs or across LEDs -- strictly worse than the between-epoch step
it is meant to cure, and undetectable downstream because nothing in the h5 would
record it. So :func:`resolve_source` has exactly three outcomes: every frame the
plan names is in the aux directory (use aux), none of them is (use MAST), or
some are -- which raises before anything is streamed, in the spirit of
``rcs_mast.check_plan_coverage``.

**Provenance is recorded either way.** :func:`read_provenance` pulls the
calibration fingerprint off the L2 metadata itself -- cal software version, CRDS
context and version, which steps ran, and a hash over the whole ``ref_file``
branch -- so the product carries what it was built from. The hash matters
because the aux set uses custom ``run_for_record`` reference files that no CRDS
context names; a context string alone would call two different calibrations the
same. ``make_sca_digests.assert_homogeneous_calibration`` is what then refuses a
mixed set, so a calibration change can no longer produce a confident report.

Dependency-light on purpose: ``asdf`` and the standard library only. No
astroquery, so ``--self-test`` stays credential-free and this is importable on a
batch node.
"""
import dataclasses
import glob
import hashlib
import json
import os
import re
import sys

# The flight L2 naming MAST uses, which a local reprocessing is expected to
# mirror byte for byte -- it is the same archive filename, so the query plan's
# ``frames`` map is already the lookup key and no second resolution scheme is
# needed. Kept as a parse (rather than just a glob) so that a directory of
# unrelated files is reported as unparsed rather than silently ignored.
L2_NAME = re.compile(
    r"^r(?P<program>\d{5})(?P<execution_plan>\d{2})(?P<pass>\d{3})"
    r"(?P<segment>\d{3})(?P<observation>\d{3})(?P<visit>\d{3})"
    r"_(?P<exposure>\d{4})_wfi(?P<sca>\d{2})_(?P<suffix>\w+)_cal\.asdf$")

MAST = "mast"
AUX = "aux"

# The lit observations of one standard RCS sequence: obs 1 is the dark (never
# processed to L2) and obs 2-7 are the six LEDs. CAR-216's extra obs 8/9 are
# not here deliberately -- they are aux activities, no trend point depends on
# them, and a reprocessing that omits them is not thereby short.
LIT_OBSERVATIONS = (2, 3, 4, 5, 6, 7)


# ---------------------------------------------------------------------------
# Aux directory index
# ---------------------------------------------------------------------------


@dataclasses.dataclass(frozen=True)
class AuxIndex:
    """Filename -> absolute path over one local reprocessing directory.

    Built from a single ``os.listdir``, so indexing a 3870-file directory costs
    milliseconds and the per-frame lookup afterwards is a dict hit. That is the
    reason the gate can afford to check *every* frame of a pass before deciding,
    rather than discovering a missing file halfway through staging.
    """

    root: str
    by_name: dict
    unparsed: tuple = ()

    @classmethod
    def scan(cls, root):
        if not os.path.isdir(root):
            raise ValueError(
                f"aux L2 directory does not exist or is not a directory: "
                f"{root}")
        # Names only, no per-entry stat. The reprocessing lives on an s3fs-fuse
        # mount where a stat is a network round trip: over 3870 files that is
        # minutes, against milliseconds for the bare listing. The regex is
        # guard enough -- a *directory* named like a 19-digit L2 product with
        # an .asdf suffix is not a case worth paying for, and if one existed
        # asdf.open would say so on the spot.
        by_name, unparsed = {}, []
        for name in os.listdir(root):
            if L2_NAME.match(name):
                by_name[name] = os.path.join(root, name)
            elif name.endswith(".asdf"):
                unparsed.append(name)
        if not by_name:
            raise ValueError(
                f"aux L2 directory {root} holds no files matching the flight "
                f"L2 naming r<19 digits>_<exposure>_wfi<NN>_<suffix>_cal.asdf. "
                f"Nothing can be superseded from it, which is almost certainly "
                f"a wrong --aux-l2-dir rather than an empty reprocessing.")
        return cls(root=root, by_name=by_name,
                   unparsed=tuple(sorted(unparsed)))

    def __contains__(self, filename):
        return os.path.basename(filename) in self.by_name

    def path(self, filename):
        return self.by_name[os.path.basename(filename)]

    def passes(self):
        """``(program, execution_plan, pass)`` -> set of ``(observation, sca)``.

        The inventory used for the ``--aux-inventory`` report. Keyed the way the
        manifest and run labels are keyed so coverage can be read off against
        the set of epochs actually wanted.
        """
        out = {}
        for name in self.by_name:
            m = L2_NAME.match(name)
            key = (int(m.group("program")), int(m.group("execution_plan")),
                   int(m.group("pass")))
            out.setdefault(key, set()).add(
                (int(m.group("observation")), int(m.group("sca"))))
        return out


# ---------------------------------------------------------------------------
# Provenance off the L2 metadata
# ---------------------------------------------------------------------------

# What ``read_provenance`` reports as absent. The L2 schema writes the literal
# string "INCOMPLETE" for a reference file whose step did not run, so a missing
# ``photom`` is not an error -- in the aux set it is the *point*, since skipping
# photom is what removes the varying per-SCA flux calibration.
ABSENT = ("INCOMPLETE", "N/A", "", None)

PROVENANCE_FIELDS = (
    "calibration_software_version", "crds_context", "crds_version",
    "cal_step_photom", "cal_step_flat_field", "ref_file_id", "l2_file_date",
    "l2_provenance_frame",
)


def read_provenance(af, source=""):
    """Calibration fingerprint of one open L2 ``AsdfFile``.

    The ``ref_file_id`` is a short hash over the resolved reference *files* on
    the ``ref_file`` branch, which is what actually distinguishes two
    calibrations. The CRDS context string is neither necessary nor sufficient,
    which is why it is recorded but not hashed:

    * not sufficient -- the aux reprocessing reports ``roman_0067.pmap`` while
      sourcing gain, linearity, mask and readnoise from
      ``/teams/team-rtb/run_for_record_reffiles/`` and skipping photom and
      flat_field entirely, so it shares a context string with MAST's own
      ``roman_0067`` epochs and is calibrated differently;
    * not necessary -- ``roman_0072`` and ``roman_0073`` resolve to the same 17
      reference files, so the context moved while the calibration did not.

    ``source`` is recorded because gain, linearity, mask and readnoise are
    *per-detector* references, so the hash fingerprints one SCA's calibration,
    not the epoch's. That is fine for comparing epochs -- the caller always
    reads the first frame of the first lit activity, which is SCA01 whenever
    coverage is complete, and ``--min-scas 18`` makes it complete -- but only
    as long as it is the same SCA every time. Recording the frame is what makes
    an ``ref_file_id`` difference between two epochs auditable rather than
    merely alarming.
    """
    meta = af.tree["roman"]["meta"]
    ref_file = dict(meta.get("ref_file", {}) or {})
    crds = dict(ref_file.get("crds", {}) or {})
    cal_step = dict(meta.get("cal_step", {}) or {})
    file_date = meta.get("file_date")
    if isinstance(file_date, dict):
        file_date = file_date.get("value", "")

    # The hash covers the reference *files* and deliberately NOT the ``crds``
    # sub-dict, even though that sub-dict lives on the same branch. Measured:
    # roman_0072 -> roman_0073 changes the context string and nothing else --
    # all 17 reference files are identical, photom_0080 included -- so hashing
    # the context made a pure relabelling look like a new calibration and
    # tripped the homogeneity guard on epochs that are bit-identically
    # calibrated. That is the exact failure mode this hash exists to avoid, in
    # mirror image: the context is neither necessary nor sufficient, so it has
    # no business being in the fingerprint. It is still recorded separately as
    # ``crds_context``, so nothing is lost -- only the false positive.
    return {
        "calibration_software_version":
            str(meta.get("calibration_software_version", "") or ""),
        "crds_context": str(crds.get("context", "") or ""),
        "crds_version": str(crds.get("version", "") or ""),
        "cal_step_photom": str(cal_step.get("photom", "") or ""),
        "cal_step_flat_field": str(cal_step.get("flat_field", "") or ""),
        "ref_file_id": ref_file_id_of(ref_file),
        "l2_file_date": str(file_date or ""),
        "l2_provenance_frame": str(source or ""),
    }


def ref_file_id_of(ref_file):
    """The ``ref_file_id`` of one ``meta.ref_file`` branch: files only, no ``crds``.

    The one definition of the hash. :func:`read_provenance` stamps it into
    products at stage 1, and :func:`calibration_branches` recomputes it from a
    re-streamed frame, so the two can be compared to tell whether MAST has
    reprocessed a pass since it was staged.
    """
    ref_files_only = {key: value for key, value in dict(ref_file or {}).items()
                      if key != "crds"}
    blob = json.dumps(ref_files_only, sort_keys=True, default=str).encode()
    return hashlib.sha256(blob).hexdigest()[:16]


def empty_provenance():
    """All-absent provenance, for a product built without reading any L2.

    The blank-dark placeholder path and ``--skip-telemetry`` style partial runs
    land here. Recorded as empty strings rather than omitted so that the
    homogeneity guard sees "unknown" explicitly instead of inferring it from a
    missing attribute.
    """
    return {field: "" for field in PROVENANCE_FIELDS}


def describe_provenance(prov):
    """One-line human form of a provenance dict."""
    photom = prov.get("cal_step_photom") or "?"
    flat = prov.get("cal_step_flat_field") or "?"
    return (f"cal {prov.get('calibration_software_version') or '?'}  "
            f"CRDS {prov.get('crds_context') or '?'}"
            f"@{prov.get('crds_version') or '?'}  "
            f"photom={photom} flat_field={flat}  "
            f"ref_file_id={prov.get('ref_file_id') or '?'}")


def read_calibration_audit(path, run_labels=()):
    """Read an ``l2_calibration_audit.ecsv`` back, aligned to ``run_labels``.

    Returns ``(rows, meta, uncovered)``: ``rows`` is a list parallel to
    ``run_labels`` holding one dict per epoch or ``None`` where the audit has
    no row for it, ``meta`` the table metadata (the streamed-frame caveat lives
    there and has to travel with the rows), and ``uncovered`` the labels that
    were not found.

    **Matched on ``run_label``, never on the ``epoch`` column**, even though the
    file carries one.  That column is a position in whatever epoch list produced
    the audit, so positional matching would shift every label by the number of
    passes staged since -- and shifted calibration metadata is confidently wrong
    rather than visibly absent, which is the worse of the two failures by a long
    way.

    A missing file is not an error: the audit is supplementary evidence, so this
    returns ``(None, {}, list(run_labels))`` and lets the caller degrade.
    ``astropy`` is imported inside the function because this module is
    stdlib-only and sits on the streaming hot path.
    """
    labels = list(run_labels)
    if not path or not os.path.exists(path):
        return None, {}, labels

    from astropy.table import Table

    table = Table.read(path, format="ascii.ecsv")
    meta = dict(table.meta)

    by_label = {}
    for row in table:
        record = {name: row[name] for name in table.colnames}
        for name, value in list(record.items()):
            if hasattr(value, "item"):
                record[name] = value.item()
        by_label[str(record.get("run_label", ""))] = record

    if not labels:
        return list(by_label.values()), meta, []

    rows = [by_label.get(label) for label in labels]
    uncovered = [label for label, row in zip(labels, rows) if row is None]
    return rows, meta, uncovered


# ---------------------------------------------------------------------------
# Comparing two calibrations
# ---------------------------------------------------------------------------
#
# When a pass arrives with a ref_file_id nobody has measured, stage 3 refuses
# the set (make_sca_digests.assert_homogeneous_calibration). The first question
# is then *which* reference files changed, and the answer is a field-by-field
# diff of the ref_file branch. That is what cleared roman_0073 (no file moved),
# roman_0075 and roman_0076 (distortion only, which is WCS-only). The diff
# alone says what to measure; it does not say the pixels agree. See
# trend_change_check.py for the command line and the trend test that
# follows it.

def _plain(mapping):
    """A metadata branch as plain JSON types, the way the hash sees it."""
    return json.loads(json.dumps(dict(mapping or {}), sort_keys=True,
                                 default=str))


def calibration_branches(af):
    """The parts of one open L2 frame's metadata that define its calibration.

    Returns ``{"ref_file": {...}, "cal_step": {...}, "crds": {...},
    "software": str, "file_date": str, "ref_file_id": str}``. ``ref_file``
    excludes ``crds``, exactly as the hash does, and ``ref_file_id`` is
    :func:`ref_file_id_of` on it.
    """
    meta = af.tree["roman"]["meta"]
    ref_file = dict(meta.get("ref_file", {}) or {})
    file_date = meta.get("file_date")
    if isinstance(file_date, dict):
        file_date = file_date.get("value", "")
    return {
        "ref_file": _plain({k: v for k, v in ref_file.items() if k != "crds"}),
        "cal_step": _plain(meta.get("cal_step", {})),
        "crds": _plain(ref_file.get("crds", {})),
        "software": str(meta.get("calibration_software_version", "") or ""),
        "file_date": str(file_date or ""),
        "ref_file_id": ref_file_id_of(ref_file),
    }


def diff_calibrations(a, b):
    """``[(branch, key, value_a, value_b), ...]`` where two calibrations differ.

    ``a`` and ``b`` are :func:`calibration_branches` results. Branches are
    ``ref_file`` and ``cal_step`` (both bear on the pixels), then ``crds`` and
    ``software``, which are reported but not hashed: a context or version change
    with no ``ref_file`` row is a relabelling, as at roman_0072 -> roman_0073.
    """
    rows = []
    for branch in ("ref_file", "cal_step", "crds"):
        left, right = a.get(branch, {}), b.get(branch, {})
        for key in sorted(set(left) | set(right)):
            if left.get(key) != right.get(key):
                rows.append((branch, key, left.get(key), right.get(key)))
    if a.get("software") != b.get("software"):
        rows.append(("software", "calibration_software_version",
                     a.get("software"), b.get("software")))
    return rows


def provenance_frame(plan):
    """The L2 frame stage 1 reads a pass's provenance from.

    The first frame, by SCA, of the first activity that has frames, in plan
    order: the same frame ``process_rcs_trending`` hashes, which is SCA01 of
    the first LED whenever coverage is complete. ``plan`` is a
    ``rcs_mast.QueryPlan`` or its JSON dict. Raises if the plan names no frame.
    """
    activities = plan.activities if hasattr(plan, "activities") \
        else plan["activities"]
    for entry in activities:
        frames = entry.get("frames") or {}
        if frames:
            return frames[sorted(frames)[0]]
    raise ValueError("the plan names no L2 frame (every activity is a blank "
                     "dark?)")


# ---------------------------------------------------------------------------
# Source resolution
# ---------------------------------------------------------------------------


@dataclasses.dataclass(frozen=True)
class L2Source:
    """Resolved origin of every L2 frame for one pass.

    ``kind`` is :data:`AUX` or :data:`MAST` and applies to the *whole pass* --
    there is deliberately no per-activity or per-SCA variant, because a mixed
    pass is the failure mode this type exists to make unrepresentable.
    """

    kind: str
    root: str = ""
    index: object = None
    n_frames: int = 0

    @property
    def is_aux(self):
        return self.kind == AUX

    def open(self, missions, filename):
        """Open one L2 product, from the aux mount or from MAST/S3.

        Returns an open ``AsdfFile`` in both cases, which is what
        ``read_per_sca.read_streamed_l2`` consumes, so the staging loop below
        this is identical for the two sources.
        """
        if self.is_aux:
            import asdf
            return asdf.open(self.index.path(filename), lazy_load=True,
                             memmap=True)
        import rcs_mast
        return rcs_mast.stream_product(missions, filename)

    def nbytes(self, filename, planned=0):
        """Size of one frame, for the pull-rate report.

        From the filesystem on the aux path, where the planned size recorded by
        a MAST listing is not the right number for a locally reprocessed file.
        """
        if self.is_aux:
            try:
                return os.path.getsize(self.index.path(filename))
            except OSError:
                return 0
        return planned


def plan_frames(plan):
    """Every L2 filename one query plan names, lit activities only.

    The dark contributes nothing (``--blank-dark``: the RCS dark is not
    processed to L2 at all), and aux activities are included when present
    because a CAR-216 obs 8/9 frame is still a frame that has to come from one
    calibration or the other.
    """
    names = []
    for entry in plan.activities:
        if entry.get("dark_blank"):
            continue
        names.extend(entry.get("frames", {}).values())
    return names


def resolve_source(plan, aux_index, label=None):
    """Decide where this pass's frames come from. Three outcomes, no fourth.

    * every frame present in ``aux_index`` -> an :data:`AUX` source
    * no frame present -> a :data:`MAST` source, reported as normal
    * **some** frames present -> ``ValueError``, nothing streamed

    The third case is the one that matters. A pass built half from a local
    reprocessing and half from the archive carries two different per-SCA flux
    calibrations *within one epoch*; the per-SCA response it produces is then
    wrong in a way that no downstream statistic separates from real instrument
    behaviour, and no attribute in the h5 would record that it happened. Better
    to refuse the pass and say exactly which frames are missing.
    """
    label = label or getattr(plan, "label", "<plan>")
    if aux_index is None:
        return L2Source(kind=MAST)

    wanted = plan_frames(plan)
    if not wanted:
        return L2Source(kind=MAST)

    present = [n for n in wanted if n in aux_index]
    missing = [n for n in wanted if n not in aux_index]

    if not present:
        print(f"  L2 source: MAST/S3 (none of this pass's {len(wanted)} "
              f"frames are in the aux directory)")
        return L2Source(kind=MAST)

    if missing:
        shown = ", ".join(os.path.basename(n) for n in missing[:6])
        more = "" if len(missing) <= 6 else f", +{len(missing) - 6} more"
        raise ValueError(
            f"aux L2 directory {aux_index.root} covers {len(present)} of "
            f"{len(wanted)} frames for {label} -- a partial reprocessing. "
            f"Nothing has been streamed. Mixing aux and MAST frames inside one "
            f"pass would put two different per-SCA flux calibrations in a "
            f"single epoch, which is worse than the between-epoch step the aux "
            f"path exists to remove and is invisible downstream. Complete the "
            f"reprocessing for this pass, or drop --aux-l2-dir to build it "
            f"entirely from MAST. Missing: {shown}{more}")

    return L2Source(kind=AUX, root=aux_index.root, index=aux_index,
                    n_frames=len(present))


def announce(source, label=None):
    """The loud banner for an aux-sourced pass.

    Deliberately noisy and deliberately unconditional. A run that silently
    substituted a local reprocessing for the archive would be unreproducible by
    anyone reading the log, and the whole value of the aux path depends on being
    able to say later which epochs came from where.
    """
    if not source.is_aux:
        return
    label = label or ""
    print("  " + "=" * 68)
    print(f"  == AUX L2 REPROCESSING IN USE{(' for ' + label) if label else ''}")
    print(f"  == source     : {source.root}")
    print(f"  == frames     : {source.n_frames}, ALL from the aux directory "
          f"(MAST/S3 not contacted for pixels)")
    print(f"  == rationale  : MAST's CAR-190 L2 spans six CRDS contexts; this "
          f"supersedes them")
    print("  " + "=" * 68)


def aux_inventory_report(aux_index, stream=sys.stdout):
    """Print per-pass aux coverage. Read-only; the pre-flight for a run."""
    passes = aux_index.passes()
    print(f"aux L2 directory: {aux_index.root}", file=stream)
    print(f"  {len(aux_index.by_name)} parsed L2 files, "
          f"{len(aux_index.unparsed)} unparsed .asdf, "
          f"{len(passes)} pass(es)", file=stream)
    incomplete = []
    for key in sorted(passes):
        obs = sorted({o for o, _ in passes[key]})
        counts = {o: len([1 for oo, _ in passes[key] if oo == o]) for o in obs}
        flags = []
        # Two independent ways to be short, and the second one bit us: pass 25
        # of CAR-190 has five *complete* observations rather than six ragged
        # ones, so a per-observation SCA check alone called it healthy. The
        # gate refuses it either way, but a pre-flight that says "fine" about a
        # pass the run then rejects is worse than no pre-flight.
        ragged = sorted(o for o, n in counts.items() if n != 18)
        if ragged:
            flags.append(f"RAGGED obs {ragged} ({counts})")
        if tuple(obs) != LIT_OBSERVATIONS:
            missing = [o for o in LIT_OBSERVATIONS if o not in obs]
            extra = [o for o in obs if o not in LIT_OBSERVATIONS]
            detail = (f"missing obs {missing}" if missing else "") + \
                     (f" extra obs {extra}" if extra else "")
            flags.append(f"NON-STANDARD sequence: {detail.strip()}")
        flag = "" if not flags else "  <== " + "; ".join(flags)
        if flags:
            incomplete.append(key)
        print(f"  program {key[0]} plan {key[1]:02d} pass {key[2]:03d}: "
              f"{len(obs)} observation(s), {len(passes[key])} "
              f"frames{flag}", file=stream)
    if incomplete:
        print(f"  {len(incomplete)} pass(es) are not a complete standard "
              f"sequence and will be REFUSED rather than mixed with MAST "
              f"frames: {incomplete}", file=stream)
    else:
        print(f"  all {len(passes)} pass(es) are complete standard sequences",
              file=stream)
    return passes


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------


class _FakePlan:
    def __init__(self, activities, label="FAKE_PASS"):
        self.activities = activities
        self.label = label


def _fake_plan(n_lit=2, n_sca=18, stem="r0103902001001"):
    acts = [{"key": "DARK", "dark_blank": True, "frames": {}}]
    for obs in range(2, 2 + n_lit):
        frames = {
            str(s): f"{stem}{obs:03d}001_0001_wfi{s:02d}_dark_cal.asdf"
            for s in range(1, n_sca + 1)}
        acts.append({"key": f"LED{obs - 1}", "dark_blank": False,
                     "frames": frames})
    return _FakePlan(acts)


def self_test(verbose=True):
    """Exercise the three resolution outcomes and the index parse.

    The case worth protecting is the middle one: a plan whose frames are
    *partly* in the aux directory must raise. It is the only outcome that
    cannot be recovered from after the fact, because a mixed-calibration epoch
    leaves no trace in the product.
    """
    import tempfile
    failures = []

    def check(name, ok, detail=""):
        if not ok:
            failures.append(f"{name}: {detail}")
        if verbose:
            print(f"    {'ok  ' if ok else 'FAIL'} {name}"
                  f"{('  ' + detail) if detail and not ok else ''}")

    plan = _fake_plan(n_lit=2)
    wanted = plan_frames(plan)
    check("plan_frames skips the blank dark", len(wanted) == 36,
          f"got {len(wanted)}")

    with tempfile.TemporaryDirectory() as root:
        # No aux at all -> MAST, with no index.
        check("aux_index None -> MAST",
              resolve_source(plan, None).kind == MAST)

        # A directory with nothing recognisable must be refused outright, not
        # silently treated as "no coverage" -- that is the wrong-path case.
        open(os.path.join(root, "notes.txt"), "w").close()
        try:
            AuxIndex.scan(root)
            check("empty aux dir refused", False, "no ValueError")
        except ValueError:
            check("empty aux dir refused", True)

        # Complete coverage -> AUX.
        for name in wanted:
            open(os.path.join(root, name), "w").close()
        index = AuxIndex.scan(root)
        check("index parses flight L2 names", len(index.by_name) == 36,
              f"got {len(index.by_name)}")
        check("unparsed .asdf tracked separately", index.unparsed == ())
        src = resolve_source(plan, index)
        check("complete aux -> AUX source",
              src.kind == AUX and src.n_frames == 36,
              f"kind={src.kind} n={src.n_frames}")

        # Partial coverage -> raise. One missing frame out of 36 is enough.
        os.remove(os.path.join(root, wanted[7]))
        partial = AuxIndex.scan(root)
        try:
            resolve_source(plan, partial, label="PARTIAL")
            check("partial aux refused", False, "no ValueError raised")
        except ValueError as error:
            check("partial aux refused",
                  "partial reprocessing" in str(error)
                  and os.path.basename(wanted[7]) in str(error),
                  f"message did not name the missing frame: {error}")

        # A pass whose frames are entirely absent -> MAST, no raise. This is
        # the normal case for every epoch the reprocessing does not cover.
        other = _fake_plan(n_lit=1, stem="r0106302099001")
        check("disjoint pass -> MAST",
              resolve_source(other, partial).kind == MAST)

        # Inventory flags the ragged activity rather than hiding it.
        inv = partial.passes()
        key = (1039, 2, 1)
        check("inventory keys by program/plan/pass", key in inv,
              f"keys were {list(inv)}")

    prov = empty_provenance()
    check("empty provenance has every field",
          set(prov) == set(PROVENANCE_FIELDS))
    check("describe_provenance survives blanks",
          "?" in describe_provenance(prov))

    # The regression that matters for ref_file_id: a CRDS context bump that
    # resolves to the same reference files must NOT change the hash. Observed
    # for real on roman_0072 -> roman_0073, where all 17 files are identical;
    # hashing the context made two bit-identically calibrated halves of the
    # trend look like a flux step and tripped the homogeneity guard.
    class _Fake:
        def __init__(self, context):
            self.tree = {"roman": {"meta": {
                "ref_file": {"crds": {"context": context, "version": "14.0.0"},
                             "photom": "roman_wfi_photom_0080.asdf",
                             "gain": "roman_wfi_gain_0044.asdf"},
                "cal_step": {"photom": "COMPLETE", "flat_field": "SKIPPED"},
                "calibration_software_version": "1.0.2",
                "file_date": "2026-10-02"}}}

    same = read_provenance(_Fake("roman_0072.pmap"))
    bumped = read_provenance(_Fake("roman_0073.pmap"))
    check("a context bump alone does not change ref_file_id",
          same["ref_file_id"] == bumped["ref_file_id"],
          f"{same['ref_file_id']} != {bumped['ref_file_id']}")
    check("the context is still recorded, just not hashed",
          same["crds_context"] == "roman_0072.pmap"
          and bumped["crds_context"] == "roman_0073.pmap")

    # ...and the converse: a genuine reference-file change must still show up,
    # or the hash would be useless.
    changed = _Fake("roman_0072.pmap")
    changed.tree["roman"]["meta"]["ref_file"]["photom"] = \
        "roman_wfi_photom_0040.asdf"
    check("a reference-file change does change ref_file_id",
          read_provenance(changed)["ref_file_id"] != same["ref_file_id"])

    # The diff that cleared roman_0075: one ref_file row, a crds row that is
    # reported but does not count, and the hash recomputed from the branches
    # agreeing with the one stage 1 stamps.
    before = calibration_branches(_Fake("roman_0074.pmap"))
    after_fake = _Fake("roman_0075.pmap")
    after_fake.tree["roman"]["meta"]["ref_file"]["distortion"] = \
        "roman_wfi_distortion_0053.asdf"
    before_fake = _Fake("roman_0074.pmap")
    before_fake.tree["roman"]["meta"]["ref_file"]["distortion"] = \
        "roman_wfi_distortion_0027.asdf"
    before, after = (calibration_branches(before_fake),
                     calibration_branches(after_fake))
    rows = diff_calibrations(before, after)
    check("diff_calibrations names the one file that moved, plus the context",
          [(r[0], r[1]) for r in rows] == [("ref_file", "distortion"),
                                           ("crds", "context")], str(rows))
    check("calibration_branches hashes as read_provenance does",
          before["ref_file_id"] == read_provenance(before_fake)["ref_file_id"])
    check("a relabelling diffs on crds only",
          [r[0] for r in diff_calibrations(
              calibration_branches(_Fake("roman_0072.pmap")),
              calibration_branches(_Fake("roman_0073.pmap")))] == ["crds"])
    check("provenance_frame takes the first SCA of the first lit activity",
          provenance_frame(plan) == plan.activities[1]["frames"][
              sorted(plan.activities[1]["frames"])[0]])

    # read_calibration_audit. A missing file degrades rather than raising:
    # the audit is supplementary evidence, not an input.
    rows, meta, uncovered = read_calibration_audit("/nonexistent.ecsv",
                                                   ["A", "B"])
    check("a missing audit returns None without raising",
          rows is None and meta == {} and uncovered == ["A", "B"])

    from astropy.table import Table

    with tempfile.TemporaryDirectory() as root:
        audit_path = os.path.join(root, "audit.ecsv")
        # The `epoch` column is deliberately offset from the position each
        # label occupies in the query below. Matching on it would still
        # "work" against an in-order file, so the offset is what makes this
        # assertion able to fail.
        written = Table({
            "epoch": [100, 101, 102],
            "run_label": ["EP_A", "EP_B", "EP_C"],
            "calibration_class": ["unity-photom", "unity-photom", "other"],
            "ref_file_id": ["aaaa", "bbbb", "cccc"],
        })
        written.meta["description"] = "caveat that must survive the round trip"
        written.write(audit_path, format="ascii.ecsv")

        rows, meta, uncovered = read_calibration_audit(
            audit_path, ["EP_C", "EP_A", "EP_MISSING"])
        check("the audit matches on run_label, not on the epoch index",
              [None if r is None else r["ref_file_id"] for r in rows]
              == ["cccc", "aaaa", None],
              str([None if r is None else r["ref_file_id"] for r in rows]))
        check("an absent label is reported as uncovered",
              uncovered == ["EP_MISSING"], str(uncovered))
        check("the streamed-frame caveat survives in meta",
              meta.get("description", "").startswith("caveat"))
        check("rows carry plain Python values, not numpy scalars",
              all(type(rows[0][name]).__module__ == "builtins"
                  for name in ("epoch", "run_label")),
              str([type(rows[0][n]) for n in ("epoch", "run_label")]))

        everything, _, _ = read_calibration_audit(audit_path)
        check("no labels asked for returns the whole table",
              len(everything) == 3)

    if verbose:
        print(f"  rcs_l2_source.self_test: "
              f"{'OK' if not failures else str(len(failures)) + ' FAILURE(S)'}")
    for failure in failures:
        print(f"    {failure}")
    return not failures


if __name__ == "__main__":
    sys.exit(0 if self_test() else 1)
