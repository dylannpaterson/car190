"""Is there a step in the trend here, or an outlier epoch? Two small tests.

Both questions came up for the same reason: something changed upstream of the
pipeline -- a CRDS context (roman_0075, roman_0076), an enclosure setpoint, a
WFI power cycle -- and nothing in the products measures its effect directly.
These tests measure it from the trend itself, against the trend's own noise.

**The step test** (:func:`step_test`). Every (SCA, LED) gets a polynomial in
time plus a step at the boundary, fitted jointly in log response. What is
reported from the 108 fitted steps is split two ways:

* the **focal-plane step** per LED, the median over SCAs. Lamp drift, a missed
  photodiode correction, an ACM move or a common thermal effect lands here;
* the **per-SCA achromatic step**: subtract the focal-plane step, average over
  LEDs, and take the rms over SCAs. A per-SCA flux-calibration change (a new
  ``photom`` or flat reference) lands here. The old MAST photom family read
  1.787 % on this statistic, which is why it is the one a CRDS change is
  judged by.

A number on its own is meaningless, so the same fit is repeated at every other
admissible boundary in the window (the **null splits**, where nothing is known
to change). The verdict is the tested value against the null range.

**The outlier test** (:func:`leave_one_out`). Each epoch is predicted by a
polynomial through its nearest neighbours, leaving it (and any epochs named in
``exclude``) out, and the residual is split the same two ways. That is how pass
13, just after the 2026-09 WFI power cycle, was found: +0.07-0.09 % focal plane
and 0.080 % per-SCA rms, against 0.005-0.013 % for its neighbours.

**Neither test knows about film physics.** Within a decon episode the film
grows smoothly, so a degree-2 polynomial over a few days absorbs it. Across a
decon it does not, so a window must not span one; :func:`window_problems` says
so, and the CLI (``trend_change_check.py``) refuses unless told otherwise.
LED1 carries the film's strongest curvature, so a degree-1 fit leaves an LED1
focal-plane residual that is growth, not a step -- read degree 2 first.

Inputs are ``(n_epoch, 6, 18)`` log responses and hours, so the tests are
independent of where the numbers come from. :func:`load_window` builds them
from schema-2 ``*_cal.h5`` products via ``rcs_trend_reader``, and the default
(every recorded step but the temperature gain) is the digests' ``LEDx``.
"""
import dataclasses
import sys

import numpy as np

# The per-SCA achromatic step the old MAST photom family (cal 1.0.1, photom
# reference 0040) applied against roman_0072 -- the effect a CRDS change is
# being screened for. rcs_trend_config.CALIBRATION_EQUIVALENCE has the
# measurement.
OLD_PHOTOM_FAMILY_RMS = 0.01787


@dataclasses.dataclass
class StepFit:
    """One fitted step, split into its focal-plane and per-SCA parts.

    All values are fractional (log response). ``focal_plane`` is per LED,
    ``per_sca`` per SCA; ``achromatic_rms`` is ``per_sca``'s population std.
    """

    index: int                 # first epoch on the late side
    degree: int
    focal_plane: np.ndarray    # (n_led,)
    per_sca: np.ndarray        # (n_sca,)

    @property
    def achromatic_rms(self):
        return float(np.nanstd(self.per_sca))

    @property
    def achromatic_max(self):
        return float(np.nanmax(np.abs(self.per_sca)))


def _split(steps):
    """``(n_led, n_sca)`` steps -> (focal-plane per LED, per-SCA achromatic)."""
    focal_plane = np.nanmedian(steps, axis=1)
    per_sca = np.nanmean(steps - focal_plane[:, None], axis=0)
    return focal_plane, per_sca


def _design(hours, degree, extra=None):
    """Polynomial columns in centred, scaled time (conditioning), plus extras."""
    span = max(float(np.ptp(hours)), 1.0)
    u = (hours - hours.mean()) / span
    columns = [u ** j for j in range(degree + 1)]
    if extra is not None:
        columns.append(extra)
    return np.column_stack(columns)


def _solve(design, y):
    """Least squares column by column of ``y`` (n, m), skipping NaN rows.

    One batched solve when ``y`` is complete, which is the usual case; per
    column only where some (SCA, LED) is missing an epoch. A column with too
    few finite rows to be determined comes back NaN rather than as a guess.
    """
    n_par = design.shape[1]
    finite = np.isfinite(y)
    if finite.all():
        beta, *_ = np.linalg.lstsq(design, y, rcond=None)
        return beta
    beta = np.full((n_par, y.shape[1]), np.nan)
    for j in range(y.shape[1]):
        rows = finite[:, j]
        if rows.sum() > n_par:
            beta[:, j], *_ = np.linalg.lstsq(design[rows], y[rows, j],
                                             rcond=None)
    return beta


def fit_step(log_response, hours, index, degree=2):
    """The step at ``index`` (first late-side epoch) under one shared model.

    ``log_response`` is ``(n_epoch, n_led, n_sca)``. Every (LED, SCA) gets its
    own polynomial of ``degree`` and its own step; the split into focal-plane
    and per-SCA parts is :func:`_split`.
    """
    y = np.asarray(log_response, dtype=float)
    hours = np.asarray(hours, dtype=float)
    n, n_led, n_sca = y.shape
    if not 1 <= index <= n - 1:
        raise ValueError(f"step index {index} leaves a side empty (n={n})")
    late = (np.arange(n) >= index).astype(float)
    beta = _solve(_design(hours, degree, late), y.reshape(n, -1))
    focal_plane, per_sca = _split(beta[-1].reshape(n_led, n_sca))
    return StepFit(index=index, degree=degree, focal_plane=focal_plane,
                   per_sca=per_sca)


def step_test(log_response, hours, index, degree=2, min_side=2):
    """The step at ``index`` against every null split in the same window.

    Returns ``(tested, nulls)``: a :class:`StepFit` and the list of them at
    each other boundary leaving at least ``min_side`` epochs a side. A model
    needs ``degree + 2`` epochs to have a residual at all; fewer raise.
    """
    n = len(hours)
    if n < degree + 3:
        raise ValueError(f"{n} epochs cannot separate a step from a degree-"
                         f"{degree} trend; widen the window")
    tested = fit_step(log_response, hours, index, degree)
    nulls = [fit_step(log_response, hours, k, degree)
             for k in range(min_side, n - min_side + 1) if k != index]
    return tested, nulls


def verdict(tested, nulls):
    """One line: where the tested per-SCA step sits in the null range."""
    if not nulls:
        return "no null splits in this window; widen it"
    values = np.array([fit.achromatic_rms for fit in nulls])
    low, high = values.min(), values.max()
    ratio = tested.achromatic_rms / OLD_PHOTOM_FAMILY_RMS
    inside = tested.achromatic_rms <= high
    return (f"per-SCA achromatic step {100 * tested.achromatic_rms:.4f} % rms "
            f"vs null splits {100 * low:.4f}-{100 * high:.4f} % "
            f"({'inside' if inside else 'ABOVE'} the null range); "
            f"{ratio:.3f} of the old photom family's "
            f"{100 * OLD_PHOTOM_FAMILY_RMS:.3f} %")


@dataclasses.dataclass
class Residual:
    """One epoch's leave-one-out residual, split like a step."""

    index: int
    neighbours: tuple
    focal_plane: np.ndarray    # (n_led,)
    per_sca: np.ndarray        # (n_sca,)

    @property
    def achromatic_rms(self):
        return float(np.nanstd(self.per_sca))


def leave_one_out(log_response, hours, half_width=3, degree=2, exclude=(),
                  interpolate_only=True):
    """Every epoch's residual from a polynomial through its neighbours.

    The neighbours of epoch ``i`` are up to ``half_width`` epochs on each side,
    nearest first, never ``i`` itself nor any index in ``exclude``. Excluding a
    suspect matters: left in, a real outlier drags the prediction for its
    neighbours, and they then read as outliers of the opposite sign -- pass 13
    made passes 11 and 14 look bad until it was excluded. An epoch with fewer
    than ``degree + 2`` usable neighbours is skipped, and so, with
    ``interpolate_only``, is one with no neighbour on one side: at a window's
    edge the prediction is an extrapolation and its residual reads as an
    outlier that is not there.
    """
    y = np.asarray(log_response, dtype=float)
    hours = np.asarray(hours, dtype=float)
    n, n_led, n_sca = y.shape
    banned = set(exclude)
    out = []
    for i in range(n):
        before = [j for j in range(i - 1, -1, -1) if j not in banned][:half_width]
        after = [j for j in range(i + 1, n) if j not in banned][:half_width]
        rows = sorted(before + after)
        if len(rows) < degree + 2 or (interpolate_only
                                      and not (before and after)):
            continue
        shifted = hours[rows] - hours[i]
        beta = _solve(_design(shifted, degree), y[rows].reshape(len(rows), -1))
        # _design centres time, so evaluate the polynomial at t_i explicitly.
        at_i = _design(np.append(shifted, 0.0), degree)[-1]
        predicted = (at_i @ beta).reshape(n_led, n_sca)
        focal_plane, per_sca = _split(y[i] - predicted)
        out.append(Residual(index=i, neighbours=tuple(rows),
                            focal_plane=focal_plane, per_sca=per_sca))
    return out


def window_problems(labels, decon_cycles=(), sides=(), segments=()):
    """Human-readable reasons a window is unsafe for these tests.

    A decon resets the film, which no polynomial follows: refuse. A side change
    or an ACM segment change is bridged in the recorded factors, so it is a
    warning (``(reason, fatal)`` pairs), not a refusal.
    """
    problems = []
    for name, values, fatal in (("decon episode", decon_cycles, True),
                                ("MCE side", sides, False),
                                ("ACM segment", segments, False)):
        values = list(values)
        for k in range(1, len(values)):
            if values[k] != values[k - 1]:
                problems.append((f"{name} changes {values[k - 1]} -> "
                                 f"{values[k]} at {labels[k]}", fatal))
    return problems


def load_window(cal_dir, first=None, last=None, steps=None,
                exclude=("tempgain",)):
    """``(log_response, hours, products)`` for a time-ordered window.

    ``first`` and ``last`` are run-label prefixes (``CAR216_01063_04_001``),
    inclusive; ``None`` means the start or end of the set. The response is the
    reader's ``RcsTrend.series`` for ``steps`` / ``exclude``, so the default is
    the digests' ``LEDx``. Only the window's products are opened for pixels.
    """
    import glob
    import os

    from rcs_trend_reader import RcsProduct, RcsTrend

    products = sorted((RcsProduct(p) for p in
                       glob.glob(os.path.join(cal_dir, "*_cal.h5"))),
                      key=lambda p: p.timestamp)
    if not products:
        raise ValueError(f"no *_cal.h5 products in {cal_dir}")

    def find(prefix, default):
        if prefix is None:
            return default
        hits = [k for k, p in enumerate(products)
                if p.run_label.startswith(prefix)]
        if len(hits) != 1:
            raise ValueError(f"{prefix!r} matches {len(hits)} products; give "
                             f"a longer run-label prefix")
        return hits[0]

    lo, hi = find(first, 0), find(last, len(products) - 1)
    if hi <= lo:
        raise ValueError(f"{last!r} is not after {first!r}")
    trend = RcsTrend([p.path for p in products[lo:hi + 1]])
    series = trend.series(steps=steps, exclude=exclude)
    with np.errstate(divide="ignore", invalid="ignore"):
        log_response = np.log(np.stack([series[sca] for sca in trend.sca_names],
                                       axis=2))
    return log_response, trend.hours, trend.products


def self_test(verbose=True):
    """Injected steps and outliers are recovered, and nulls stay null."""
    failures = []

    def check(name, ok, detail=""):
        if not ok:
            failures.append(f"{name}: {detail}")
        if verbose:
            print(f"    {'ok  ' if ok else 'FAIL'} {name}"
                  f"{('  ' + detail) if detail and not ok else ''}")

    rng = np.random.default_rng(7)
    n, n_led, n_sca = 12, 6, 18
    hours = np.sort(rng.uniform(0, 100, n))
    hours[0] = 0.0
    u = hours / 100.0
    # Smooth per-(LED, SCA) growth, curved like LED1, plus 5e-5 noise.
    growth = (rng.normal(0, 0.01, (n_led, n_sca))[None] * u[:, None, None]
              + rng.normal(0, 0.01, (n_led, n_sca))[None] * u[:, None, None] ** 2)
    noise = rng.normal(0, 5e-5, (n, n_led, n_sca))
    base = growth + noise

    flux = rng.normal(0, 0.002, n_sca)          # a per-SCA photom change
    lamp = np.linspace(0.001, 0.003, n_led)      # a focal-plane chromatic step
    k = 6
    stepped = base.copy()
    stepped[k:] += flux[None, None, :] + lamp[None, :, None]
    tested, nulls = step_test(stepped, hours, k, degree=2)
    check("the per-SCA step is recovered",
          np.allclose(tested.per_sca, flux - np.median(flux), atol=1e-4),
          f"worst {np.abs(tested.per_sca - flux + np.median(flux)).max():.2e}")
    check("the focal-plane step is recovered per LED",
          np.allclose(tested.focal_plane, lamp + np.median(flux), atol=2e-4),
          str(tested.focal_plane - lamp))
    clean, clean_nulls = step_test(base, hours, k, degree=2)
    null_high = max(f.achromatic_rms for f in clean_nulls)
    check("with nothing injected, the tested split looks like the nulls",
          clean.achromatic_rms < 3 * null_high and null_high < 1e-4,
          f"{clean.achromatic_rms:.2e} vs {null_high:.2e}")
    check("an injected 0.2 % rms step sits far above the null range",
          tested.achromatic_rms > 10 * null_high
          and "ABOVE" in verdict(tested, clean_nulls))
    check("the null splits skip the tested boundary",
          all(f.index != k for f in nulls) and len(nulls) == n - 4)

    bumped = base.copy()
    bumped[5] += 8e-4 + rng.normal(0, 8e-4, n_sca)[None, :]
    rows = {r.index: r for r in leave_one_out(bumped, hours)}
    worst = max(rows.values(), key=lambda r: r.achromatic_rms)
    check("leave_one_out finds the injected outlier", worst.index == 5,
          f"found {worst.index}")
    check("leave_one_out reads its focal-plane offset",
          np.allclose(np.median(rows[5].focal_plane), 8e-4, atol=3e-4),
          str(rows[5].focal_plane))
    shadow = rows[4].achromatic_rms
    rows_ex = {r.index: r for r in leave_one_out(bumped, hours, exclude=(5,))}
    check("excluding the outlier clears its neighbours",
          rows_ex[4].achromatic_rms < 0.5 * shadow,
          f"{rows_ex[4].achromatic_rms:.2e} vs {shadow:.2e}")

    holes = stepped.copy()
    holes[3, 2, 4] = np.nan
    check("a missing (epoch, LED, SCA) cell does not poison the fit",
          np.isfinite(fit_step(holes, hours, k).per_sca).all())

    problems = window_problems(list("abcd"), ["d1", "d1", "d2", "d2"],
                               ["A", "B", "B", "B"])
    check("a decon in the window is fatal, a side change is a warning",
          [fatal for _, fatal in problems] == [True, False], str(problems))
    try:
        step_test(base[:4], hours[:4], 2, degree=2)
        check("too few epochs refused", False, "no ValueError")
    except ValueError:
        check("too few epochs refused", True)

    if verbose:
        print(f"  rcs_step_tests.self_test: "
              f"{'OK' if not failures else str(len(failures)) + ' FAILURE(S)'}")
    for failure in failures:
        print(f"    {failure}")
    return not failures


if __name__ == "__main__":
    sys.exit(0 if self_test() else 1)
