"""
Display helpers for MPA mosaics, distilled from ``mosaic_plot_FPS.plot_mosaic``.

The parts worth keeping from that function are the frame conventions, which are
easy to get subtly wrong and which make every mosaic figure in this activity
directly comparable:

* ``extent=[140, -140, -110, 70]`` with ``origin='lower'`` -- so the x axis runs
  *right to left* in millimeters. That is deliberate: the mosaic is the view
  from the sky, looking down at the detectors (+Z, in this right-handed
  system, points from the sky through the detectors -- the direction light
  travels), with FPA -X to the right and +Y up. It is the display-side
  counterpart of the minus sign on x in :func:`form_mpa_mosaic.sca_placement`.
* Per-SCA MPA-position labels placed just outside each detector, below for the
  bottom row (3, 6, 9, 12, 15, 18) and above for the rest.
* Percentile clipping rather than min/max, because a few surviving hot pixels
  otherwise flatten the whole image.

Departures from the original: limits are computed on the mosaic itself instead of
on the stack of input SCAs (we often only have the mosaic), signed maps get a
symmetric diverging scale, and figures are written and closed rather than
returned, since this activity produces on the order of a hundred of them.
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import form_mpa_mosaic as fm

from matplotlib.patches import Polygon
import matplotlib.colors as mcolors
from mpl_toolkits.axes_grid1 import make_axes_locatable
import astropy.units as u
from matplotlib.collections import LineCollection

# Mosaic display extent, matching mosaic_plot_FPS: x runs high-to-low.
EXTENT = [fm.EXTENT_XMAX_MM, fm.EXTENT_XMIN_MM,
          fm.EXTENT_YMIN_MM, fm.EXTENT_YMAX_MM]
SEMI_WIDTH_MM = fm.SCA_WIDTH_MM / 2.0
BOTTOM_ROW_SCAS = (3, 6, 9, 12, 15, 18)

FIG_SIZE = (13.33, 6.5)
DPI = 110


def robust_limits(image, perc=2.0):
    """Symmetric-free percentile limits, ignoring NaNs."""
    finite = np.isfinite(image)
    if not finite.any():
        return 0.0, 1.0
    low, high = np.nanpercentile(image[finite], [perc, 100.0 - perc])
    if low == high:
        low, high = low - 1.0, high + 1.0

    return float(low), float(high)


def symmetric_limits(image, perc=2.0):
    """Limits symmetric about zero, for signed maps (differences, residuals)."""
    finite = np.isfinite(image)
    if not finite.any():
        return -1.0, 1.0
    span = float(np.nanpercentile(np.abs(image[finite]), 100.0 - perc))
    if span == 0:
        span = 1.0

    return -span, span


def label_scas(ax, geom=None, scas=range(1, 19), color="black", fontsize=8):
    """Annotate each SCA footprint with its MPA position."""
    geom = fm.load_geometry() if geom is None else geom
    for sca in scas:
        if sca not in geom:
            continue
        x_mm, y_mm, _ = geom[sca]
        if sca in BOTTOM_ROW_SCAS:
            ax.text(x_mm, y_mm - SEMI_WIDTH_MM, str(sca), ha="center",
                    va="top", color=color, fontsize=fontsize)
        else:
            ax.text(x_mm, y_mm + SEMI_WIDTH_MM, str(sca), ha="center",
                    va="bottom", color=color, fontsize=fontsize)


def show_mosaic(ax, image, vmin=None, vmax=None, cmap="gray", geom=None,
                labels=True, title=None, cbar_label=None, perc=2.0,
                diverging=False):
    """Draw one mosaic into an existing axis, in millimeter coordinates."""
    if vmin is None or vmax is None:
        limits = (symmetric_limits(image, perc) if diverging
                  else robust_limits(image, perc))
        vmin = limits[0] if vmin is None else vmin
        vmax = limits[1] if vmax is None else vmax
    if diverging and cmap == "gray":
        cmap = "RdBu_r"

    mappable = ax.imshow(image, vmin=vmin, vmax=vmax, extent=EXTENT,
                         cmap=cmap, origin="lower", interpolation="nearest")
    ax.set_xlabel("FPA X axis (mm)")
    ax.set_ylabel("FPA Y axis (mm)")
    ax.grid(False)
    if labels:
        label_scas(ax, geom=geom)
    if title:
        ax.set_title(title, fontsize=10)
    if cbar_label is not None:
        plt.colorbar(mappable, ax=ax, fraction=0.046, pad=0.04,
                     label=cbar_label)

    return mappable


def save_mosaic(image, path, title=None, cbar_label="Counts", **kwargs):
    """Single-panel mosaic figure written to ``path``."""
    fig, ax = plt.subplots(figsize=FIG_SIZE)
    show_mosaic(ax, image, title=title, cbar_label=cbar_label, **kwargs)
    _write(fig, path)

    return path


def save_mosaic_grid(images, path, suptitle=None, cbar_label="Counts",
                     ncol=3, shared_scale=True, perc=2.0, diverging=False,
                     **kwargs):
    """Grid of mosaics from an ordered ``{title: image}`` mapping.

    ``shared_scale`` puts every panel on one colour scale derived from all the
    panels together, which is what makes a six-LED grid readable as a sequence
    rather than six separately-stretched images.
    """
    titles = list(images)
    nrow = int(np.ceil(len(titles) / ncol))
    vmin = vmax = None
    if shared_scale and titles:
        stacked = np.concatenate([np.asarray(images[t]).ravel() for t in titles])
        vmin, vmax = (symmetric_limits(stacked, perc) if diverging
                      else robust_limits(stacked, perc))

    fig, axes = plt.subplots(nrow, ncol, figsize=(6.0 * ncol, 4.2 * nrow),
                             squeeze=False)
    for index, axis in enumerate(axes.ravel()):
        if index >= len(titles):
            axis.axis("off")
            continue
        title = titles[index]
        show_mosaic(axis, images[title], vmin=vmin, vmax=vmax, title=title,
                    cbar_label=cbar_label, perc=perc, diverging=diverging,
                    labels=False, **kwargs)
    if suptitle:
        fig.suptitle(suptitle, fontsize=12)
    _write(fig, path)

    return path


def save_heatmap(matrix, path, row_labels, col_labels, title=None,
                 cbar_label="", cmap="viridis", diverging=False, perc=2.0,
                 annotate=False, fmt="{:.3g}"):
    """Labelled matrix figure, used for the per-SCA x LED tables."""
    matrix = np.asarray(matrix, dtype=float)
    vmin, vmax = (symmetric_limits(matrix, perc) if diverging
                  else robust_limits(matrix, perc))
    if diverging and cmap == "viridis":
        cmap = "RdBu_r"

    fig, ax = plt.subplots(figsize=(1.1 * len(col_labels) + 3.0,
                                    0.34 * len(row_labels) + 2.0))
    mappable = ax.imshow(matrix, aspect="auto", cmap=cmap, vmin=vmin,
                         vmax=vmax, interpolation="nearest")
    ax.set_xticks(range(len(col_labels)), col_labels)
    ax.set_yticks(range(len(row_labels)), row_labels)
    if annotate:
        for i in range(matrix.shape[0]):
            for j in range(matrix.shape[1]):
                if np.isfinite(matrix[i, j]):
                    ax.text(j, i, fmt.format(matrix[i, j]), ha="center",
                            va="center", fontsize=6.5, color="black")
    if title:
        ax.set_title(title, fontsize=10)
    plt.colorbar(mappable, ax=ax, fraction=0.046, pad=0.04, label=cbar_label)
    _write(fig, path)

    return path


def save_lines(series, path, xlabel, ylabel, title=None, xticks=None,
               logy=False, axhline=None):
    """Overlay several labelled ``(x, y)`` series -- the trend-vs-wavelength plots."""
    fig, ax = plt.subplots(figsize=(7.5, 5.0))
    for label, (xvalues, yvalues) in series.items():
        ax.plot(xvalues, yvalues, marker="o", label=label)
    if axhline is not None:
        ax.axhline(axhline, color="0.5", lw=0.8, ls="--")
    if logy:
        ax.set_yscale("log")
    if xticks is not None:
        ax.set_xticks(xticks)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    if title:
        ax.set_title(title, fontsize=10)
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=8)
    _write(fig, path)

    return path


def save_histograms(samples, path, xlabel, title=None, bins=200, logy=True,
                    range_perc=1.0):
    """Overlaid histograms on a common range, for difference distributions."""
    fig, ax = plt.subplots(figsize=(7.5, 5.0))
    pooled = np.concatenate([np.asarray(v).ravel() for v in samples.values()])
    pooled = pooled[np.isfinite(pooled)]
    span = np.nanpercentile(pooled, [range_perc, 100.0 - range_perc])
    for label, values in samples.items():
        values = np.asarray(values).ravel()
        ax.hist(values[np.isfinite(values)], bins=bins, range=tuple(span),
                histtype="step", label=label)
    if logy:
        ax.set_yscale("log")
    ax.set_xlabel(xlabel)
    ax.set_ylabel("superpixels")
    if title:
        ax.set_title(title, fontsize=10)
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)
    _write(fig, path)

    return path


def _write(fig, path):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, dpi=DPI)
    plt.close(fig)

# ---- newer form of mosaic plotter:
def plot_with_sca_overlay(arr, extent, title=None, sca_corners=None, show_sca_labels=True,
                          vmin=None, vmax=None, perc_min=None, perc_max=None,
                          interpolation="bilinear", vcenter=None, filename=None,
                          xlabel="X", ylabel="Y", cmap='viridis', figsize=(10, 10), dpi=300,
                          colorbar_title='Amplitude'):
    """
    Plot an array with optional Roman SCA footprint overlays.
    
    Parameters
    ----------
    array : numpy.ndarray
        The 2D array to be plotted
    extent : list or tuple
        The extent of the plot [xmin, xmax, ymin, ymax]
    title : str, optional
        Plot title
    sca_corners : dict, optional
        Dictionary with keys 'SCA1' through 'SCA18', each containing
        corner coordinates as (N,2) array
    show_sca_labels : bool, optional
        Whether to show SCA labels in polygon centers (default: True)
    vmin/vmax : float, optional
        limit the vertical axis/colorbar range
    perc_min/perc_max : float, optional
        limit the vertical axis/colorbar range based on percentile
    interpolation : str, optional (default: "bilinear")
        interpolation used in imshow
    vcenter : float, optional
        center the color bar range on specific value (useful for coolwarm)
    filename : str, optional
        if given a filename, save 
    xlabel, ylabel : str, optional
        X and Y axis labels
    cmap : str, optional
        Matplotlib colormap name (default: 'viridis')
        coolwarm is good for comparing quantities around zero
    figsize : list or tuple
        Figsize to give matplotlib
    dpi : int
        DPI for the plot
    colorbar_title : str, optional
        Title for the colorbar (default: 'Amplitude')
    
    Returns
    -------
    fig, ax : tuple
        Figure and axis objects
    """
    # Create figure
    fig, ax = plt.subplots(1, 1, figsize=figsize, dpi=dpi)

    if vmin is None:
        if perc_min is None:
            perc_min = 0.

        vmin = np.nanpercentile(arr, perc_min)

    if vmax is None:
        if perc_max is None:
            perc_max = 100.

        vmax = np.nanpercentile(arr, perc_max)

    # Scale the colorbar over the vmin/vmax range
    # with optional center
    norm = mcolors.Normalize(vmin=vmin, vmax=vmax)
    if vcenter is not None:
        norm = mcolors.TwoSlopeNorm(vmin=vmin, vcenter=0, vmax=vmax)

    im = plt.imshow(arr, extent=extent, origin="lower",
                    interpolation=interpolation,
                    norm=norm, cmap=cmap)

    # adjust fonts and labels
    plt.rcParams.update({'font.size': 14})
    ax.tick_params(axis='both', which='major', labelsize=14)

    # Add SCA footprints if provided
    if sca_corners is not None:
        for sca_name, corners in sca_corners.items():
            polygon = Polygon(corners,
                            fill=False,
                            edgecolor='red',
                            linewidth=2)
            ax.add_patch(polygon)

            # Add SCA label in center if requested
            if show_sca_labels:
                center = corners.mean(axis=0)
                sca_index = sca_name.split("SCA")[-1]
                t = ax.text(center[0], center[1], sca_index,
                        horizontalalignment='center',
                        verticalalignment='center',
                        color='black',
                        fontsize=16,
                        fontweight="normal")

                t.set_bbox(dict(facecolor='white', alpha=0.5, edgecolor=None))

    plt.xlabel(xlabel, fontsize=16)
    plt.ylabel(ylabel, fontsize=16)
    plt.xlim(extent[0:2])
    plt.ylim(extent[2:4])
    ax.set_aspect('equal')

    # Add title if provided
    if title is not None:
        ax.set_title(title, fontsize=16)

    #cbar = plt.colorbar(im, fraction=0.03, pad=0.04)

    divider = make_axes_locatable(ax)
    cax = divider.append_axes("right", size="5%", pad=0.1)
    cbar = plt.colorbar(im, cax=cax)
    cbar.ax.tick_params(labelsize=14)
    cbar.set_label(colorbar_title, size=16)
    #cbar.set_label(cbar_label, rotation=90)

    if filename is not None:
        plt.savefig(filename, bbox_inches="tight", dpi=dpi)

    return fig, ax