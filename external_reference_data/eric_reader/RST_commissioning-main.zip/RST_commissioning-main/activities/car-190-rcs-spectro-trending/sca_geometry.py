from importlib import resources
import os
import numpy as np
from astropy.table import Table, QTable, Column
import astropy.units as u


def get_data_path():
    """
    Return the correct path to data
    When running locally (uninstalled) use data/
    When installed via pip, use resource path
    
    Returns:
        str: full path to the data
    """
    if os.path.exists(os.path.join(os.path.dirname(__file__), "data")):
        path = os.path.join(os.path.dirname(__file__), "data")
    else:
        path = str(resources.files("rst_model").joinpath("data"))

    return path


def read_sca_sky_corners(filename="../../config/WFI_SCA_sky_corners.ecsv",
                         file_root=None):
    """
    Read SCA corners from ECSV file and return dictionary
    
    Parameters
    ----------
    file_root : str
        Path to directory containing file
    filename : str
        Input ECSV filename
    
    Returns
    -------
    dict
        Dictionary with keys 'SCA1' through 'SCA18', each containing
        corner coordinates as (4,2) array. Coordinates are in arcseconds.
    
    Examples
    --------
    >>> corners = read_sca_sky_corners()
    >>> corners['SCA1'][0]
    array([ 19.13332142, -92.64453493])
    >>> corners['SCA18'][1]
    array([-1000.66429159,  -752.29527269])
    """
    if file_root is None:
        file_root = get_data_path()

    file_path = file_root + filename
    coord = QTable.read(file_path, format='ascii.ecsv')

    corners_dict = {}
    for row in coord:
        corners = np.array([[row[f'x{i+1}'].to('arcsec').value,
                           row[f'y{i+1}'].to('arcsec').value]
                          for i in range(4)])
        corners_dict[row['label']] = corners

    return corners_dict


def get_sca_sky_corners(rsiaf):
    """
    Calculate SCA corner sky coordinates using SIAF.
    
    Parameters
    ----------
    rsiaf : pysiaf.Siaf
        Roman SIAF object: rsiaf = pysiaf.Siaf('Roman')
    output_file : str, optional
        If provided, write corners to this ECSV file
    
    Returns
    -------
    dict
        Dictionary with keys 'SCA1' through 'SCA18', each containing
        corner coordinates.
    """
    wfi_cen = rsiaf['WFI_CEN']
    corners_dict = {}

    for i in range(1, 19):
        corners_v2, corners_v3 = rsiaf[f'WFI{i:02d}_FULL'].corners(to_frame='tel')
        corners_xidl, corners_yidl = wfi_cen.tel_to_idl(corners_v2, corners_v3)
        corners_dict[f'SCA{i}'] = np.array([corners_xidl, corners_yidl]).T

    return corners_dict


def write_sca_corners_to_ecsv(corners_dict, filename):
    """
    Write SCA corners to ECSV file.
    
    Parameters
    ----------
    corners_dict : dict
        Dictionary with SCA corners, each containing (4,2) array of corner coordinates
    filename : str
        Output filename
    """
    # Create table
    output = Table()
    output['label'] = list(corners_dict.keys())

    # Convert corners to columns more efficiently
    corners_array = np.array([corners for corners in corners_dict.values()])

    for i in range(4):
        output[f'x{i+1}'] = Column(corners_array[:, i, 0], unit=u.arcsec)
        output[f'y{i+1}'] = Column(corners_array[:, i, 1], unit=u.arcsec)

    # Add metadata
    output.meta['description'] = 'Roman WFI SCA corner coordinates in sky projection'
    output.meta['coordinate_system'] = 'sky projection (arcsec)'
    output.write(filename, format='ascii.ecsv', overwrite=True)


def read_sca_physical_centers(filename="../../config/WFI_SCA_physical_centers.ecsv",
                              file_root=None):
    """
    Read SCA centers and extent from ECSV file.
    
    Parameters
    ----------
    filename : str
        Input ECSV filename
    
    Returns
    -------
    centers_dict : dict
        Dictionary with keys 'SCA1' through 'SCA18', each containing
        center coordinates as (2,) array in mm
    extent : list
        [xlow, xhigh, ylow, yhigh] in mm
    width : float
        SCA width in mm
        
    >>> centers, extent, width = read_sca_physical_centers()
    >>> centers['SCA1']
    array([-22.14,  12.15])
    >>> centers['SCA18']
    array([112.64, -51.06])
    >>> extent
    [140.0, -140.0, -110.0, 70.0]
    >>> width
    40.88
    """
    if file_root is None:
        file_root = get_data_path()

    file_path = file_root + filename

    t = QTable.read(file_path, format='ascii.ecsv')

    centers_dict = {}
    for row in t:
        centers_dict[str(row['label'])] = np.array([
            row['x_center'].to(u.mm).value,
            row['y_center'].to(u.mm).value
        ])

    extent = [
        t.meta['extent_xlow_mm'],
        t.meta['extent_xhigh_mm'],
        t.meta['extent_ylow_mm'],
        t.meta['extent_yhigh_mm']
    ]

    width = t.meta['width']

    return centers_dict, extent, width


def create_corner_coordinates(center_dict, width):
    """
    Creates a dictionary of corner coordinates for squares centered at given points.
    
    This can take a dictionary of SCA centers and return the coordinates of the corners (in physical coordinates)

    Args:
        center_dict (dict): Dictionary with names as keys and numpy arrays of (x,y) center coordinates as values
        width (float): Width of the square

    Returns:
        dict: Dictionary with names as keys and numpy arrays of 4 corner coordinates as values

    >>> import numpy as np
    >>> centers = {
    ...     'A': np.array([0, 0]),
    ...     'B': np.array([5, 5]),
    ...     'C': np.array([-2, 3])
    ... }
    >>> result = create_corner_coordinates(centers, 2)
    >>> for name in sorted(result.keys()):
    ...     print(f"{name}:\\n{result[name]}")
    A:
    [[-1. -1.]
     [ 1. -1.]
     [ 1.  1.]
     [-1.  1.]]
    B:
    [[4. 4.]
     [6. 4.]
     [6. 6.]
     [4. 6.]]
    C:
    [[-3.  2.]
     [-1.  2.]
     [-1.  4.]
     [-3.  4.]]
    """
    result = {}
    half_width = width / 2

    for name, center in center_dict.items():
        x, y = center
        corners = np.array([
            [x - half_width, y - half_width],  # bottom left
            [x + half_width, y - half_width],  # bottom right
            [x + half_width, y + half_width],  # top right
            [x - half_width, y + half_width]   # top left
        ])
        result[name] = corners

    return result
