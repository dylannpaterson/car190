#!/usr/bin/env python
"""Stage 2: RAW per-SCA products -> CALIBRATED per-SCA products.

No network, no MAST credentials, ~33 MB in and ~33 MB out per epoch at a second
or two each. That is the whole point of the two-stage split: re-calibrating the
full trend after a correction changes is a five-minute single-machine job
instead of a re-download of the archive.

Two steps, and the split between them is the design:

``--make-card``
    The *only* step that looks at the whole set, and it reads no pixels -- just
    the ``dictionary/`` group of each product, ~0.1 s per file. It resolves the
    three things a single epoch cannot know on its own: which epoch is the
    reference, that epoch's per-LED photodiode level, and each ACM segment's
    reference LVDT. Writes them to a committed ECSV.

``--card CARD --in ...``
    Per-file and parallel. Reads the card, evaluates the per-epoch factors and
    RECORDS them -- never applies them -- in ``<run_label>_cal.h5`` under
    ``calibration/<step>/multiplier``; the pixels are copied from the raw
    product bit for bit (schema 2, see :func:`calibrate_one`). Records the
    card's sha256 in the product, so a later digest run can assert its entire
    input set was calibrated against one card rather than against whatever
    happened to be in the directory on the day each file was written. With
    ``--bridge-solution`` the cross-epoch ACM and side bridges a digest run
    fitted are recorded too, and with ``--tempgain-model`` the temperature gain,
    so a product carries everything needed to calibrate it.

**Why the card is an artifact and not a computation.** If the reference epoch
and the segment LVDTs were re-derived at calibration time, a product's numbers
would depend on which other products were present. Adding one pass could
silently shift every factor in the set. With a card, calibration is a pure
function of (product, card) and the card's hash is in the output.

**Recorded, not applied; absolute, not relative.** The pixels are the raw
product's. The recorded multipliers normalize them to each side's photodiode
reference, each segment's reference ACM position, and -- with a bridge solution
-- the present instrument configuration. They are deliberately not the ratio to
the reference epoch's *arrays*: that would make every parallel worker read the
reference product's pixels. The ratio stays in ``make_sca_digests.py``, and
because every factor here is a scalar per SCA plane the composition is exact
either way -- the digests computed from schema-2 products agree with those from
schema-1 (factors multiplied in) to float32 rounding.

Usage
-----
    ./calibrate_rcs_products.py --make-card --raw-dir /data/.../h5_persca \\
        --card rcs_reference_card.ecsv
    ./calibrate_rcs_products.py --card rcs_reference_card.ecsv \\
        --in /data/.../h5_persca --out-dir /data/.../h5_cal --jobs 8
    ./calibrate_rcs_products.py --card rcs_reference_card.ecsv \\
        --plot-pd-trend plots/pd/
    ./calibrate_rcs_products.py --self-test
"""

import argparse
import glob
import os
import sys

import numpy as np

import rcs_bridge_solution
import rcs_corrections as corrections
import rcs_products
import rcs_trend_config as cfg

SCHEMA_STAGES = ("raw", "calibrated", "legacy")

# Schema 2: nothing is applied to the pixels; every factor is recorded under
# calibration/<step>/multiplier. Schema 1 products (rcs_trend_v3/cal and older)
# had photodiode/side/ACM multiplied in and are still readable by the digests.
CALIBRATION_SCHEMA = 2
# Every step a schema-2 product can record, in composition order. Order does not
# change the product (the steps are scalars per SCA plane and commute) but it is
# the order every report lists them in.
STEPS = ("photodiode", "acm", "acm_bridge", "side_bridge", "tempgain")
# Recorded but left out of calibration/total_multiplier, the combination the
# digests' canonical LED columns use: the gain is provisional, and the gain fit
# reads those columns, so putting it in would make the fit read its own output.
EXCLUDED_FROM_TOTAL = ("tempgain",)

# Fallback only, for a model file that does not name its own thermal channel.
# Duplicated from housekeeping_trends rather than imported: that module pulls
# in matplotlib, which a stage-2 worker has no reason to pay for. A model file
# written by fit_temperature_gain always carries temperature_mnemonic, so this
# is reached only by a hand-made file.
TEMPGAIN_MNEMONIC = "WFI_MCU_A_MPA_CSENS_FPSSEN_K"


def discover_products(target, stage="raw", recursive=False):
    """Every product under ``target`` at the requested stage, time-ordered.

    ``target`` may be one file or a directory. Selection is by the ``stage``
    **attribute**, not by the filename suffix: a product renamed by hand is
    still classified correctly, and a directory holding raw, calibrated and
    legacy files side by side resolves without the caller having to keep them
    apart. ``stage="any"`` takes everything.

    Ordering is by the ``dictionary/timestamp`` in each file. Filenames sort
    lexicographically, which puts pass 100 before pass 36 and would hand the
    reference-card builder the wrong reference epoch.
    """
    if os.path.isfile(target):
        candidates = [target]
    else:
        pattern = "**/*.h5" if recursive else "*.h5"
        candidates = sorted(glob.glob(os.path.join(target, pattern),
                                      recursive=recursive))

    found = []
    for path in candidates:
        if path.endswith(".tmp") or ".tmp-" in os.path.basename(path):
            continue
        try:
            meta = rcs_products.read_metadata(path)
        except Exception as error:                    # noqa: BLE001
            print(f"  skip {os.path.basename(path)}: unreadable ({error})")
            continue
        if stage != "any" and meta["stage"] != stage:
            continue
        found.append(path)

    return found


def make_card(raw_dir, card_path, stage="raw", assume_side=None,
              move_min_delta=cfg.ACM_MOVE_MIN_DELTA, recursive=False,
              verbose=True, pd_reference=corrections.PD_REFERENCE_PER_SIDE):
    """Build and write the reference card over a product set."""
    paths = discover_products(raw_dir, stage=stage, recursive=recursive)
    if not paths:
        raise SystemExit(
            f"no stage={stage!r} products under {raw_dir!r}. Discovery keys on "
            f"the h5 'stage' attribute, so check the products were written by "
            f"process_rcs_trending.py 2.0 and not the legacy mosaic path "
            f"(those are stage='legacy').")

    print(f"building a reference card from {len(paths)} product(s) in "
          f"{raw_dir}")
    card = corrections.ReferenceCard.build(
        paths, assume_side=assume_side, move_min_delta=move_min_delta,
        verbose=verbose, pd_reference=pd_reference)
    card.write(card_path)
    print(f"  wrote {card_path}")
    print(f"  sha256 {card.sha256}")

    return card


def _tempgain_block(path, model, verbose=True):
    """``(datasets, attrs)`` for the ``tempgain/`` reference group.

    The product carries the *evaluated multiplier*, not the model. That is what
    makes the block model-agnostic: it answers exactly one question -- what is
    the multiplier for this LED, this SCA, at this one trend point -- and
    nothing in it presumes a polynomial. The coefficients are deliberately
    absent; if they were here a reader would re-evaluate them and the file
    would carry two answers to the same question. ``tempgain_model_sha256`` is
    the one-way pointer back to the parametric form.

    The multiplier is evaluated at each LED's OWN activity temperature. Within
    one epoch the six LEDs are measured in sequence over ~24 minutes and can
    span 0.8 K on a cooldown; because sequence order is wavelength order, an
    epoch mean would turn this achromatic gain into an apparent chromatic ramp.
    """
    temperature, rules = rcs_products.read_led_temperatures(
        path, model.meta.get("temperature_mnemonic", TEMPGAIN_MNEMONIC),
        led_names=model.led_names)

    # NaN where the temperature is not a measurement of that activity, never
    # 1.0: a silently-uncorrected value that looks corrected is exactly the
    # failure mode the photodiode factor already refuses to produce.
    valid = np.isfinite(temperature) & (rules != "missing")
    grid = np.full((len(model.led_names), cfg.N_SCAS), np.nan)
    if valid.any():
        safe = np.where(valid, temperature, model.t_nominal_k)
        # Inverted here, deliberately and in exactly one place. The model
        # evaluates G(T), the gain the detector HAD at that temperature; the
        # product records 1/G, the factor a consumer MULTIPLIES BY to remove
        # it. Both are near 1 and differ only in the sign of a ~1 % term, so
        # shipping the wrong one is a 2 %-of-signal error in the wrong
        # direction with nothing in the file to notice -- which is why the
        # model's accessor is named gain_grid rather than multiplier_grid and
        # why the dataset's attrs state the definition.
        grid = 1.0 / model.gain_grid(safe)
        grid[~valid, :] = np.nan

    datasets = {
        "led_name": np.array(model.led_names, dtype=object),
        "sca": np.array(model.sca_names, dtype=int),
        "multiplier": grid,
        "temperature_k": temperature,
        "temperature_rule": rules.astype(object),
        "valid": valid,
    }
    attrs = {
        "applied": False,
        "applied_note": (
            "RECORDED, NEVER APPLIED. The sca_arrays/ pixels do NOT include "
            "this factor. To apply it: stack * multiplier[led, sca]."),
        "quantity": ("the multiplicative factor for a given LED and SCA at "
                     "this one trend point"),
        "multiplier_definition": (
            "multiplier = 1 / G(T), where G is the model's gain and "
            "G(t_nominal) == 1 exactly"),
        "axes": "multiplier is (led_name, sca)",
        "model": os.path.basename(model.path),
        "model_sha256": model.sha256,
        "model_form": model.form,
        "model_t_nominal_k": float(model.t_nominal_k),
        "model_t_scale_k": float(model.t_scale_k),
        "temperature_mnemonic": str(
            model.meta.get("temperature_mnemonic", TEMPGAIN_MNEMONIC)),
        "temperature_note": (
            "one temperature per LED activity, not an epoch mean: the six "
            "LEDs can span 0.8 K within one epoch and sequence order is "
            "wavelength order, so an epoch mean imprints a fake chromatic "
            "ramp on an achromatic gain"),
        "n_invalid": int((~valid).sum()),
        "coverage_note": (
            "a finite multiplier is a property of the model and the "
            "temperature, not evidence that this detector has data; see "
            "coverage/per_sca"),
        "provisional_note": str(model.meta.get("caveat", "")),
    }
    if verbose and not valid.all():
        bad = [model.led_names[i] for i in np.flatnonzero(~valid)]
        print(f"      tempgain: no in-product temperature for "
              f"{','.join(bad)}; multiplier left NaN")
    elif verbose and (rules != "window").any():
        near = [model.led_names[i] for i in np.flatnonzero(rules != "window")]
        print(f"      tempgain: temperature extrapolated (not in-window) for "
              f"{','.join(near)}")
    return datasets, attrs


def _grid(per_led):
    """``(n_led,)`` -> ``(n_led, n_sca)``: a step that is the same on every SCA."""
    return np.repeat(np.asarray(per_led, dtype=float)[:, None], cfg.N_SCAS,
                     axis=1)


def _side_reference_label(card, side):
    """The run label of the epoch a side's photodiode reference was taken at."""
    for row in card.epochs:
        if cfg.normalize_side(row["mce_side"]) == cfg.normalize_side(side):
            return str(row["run_label"])
    return ""


def calibrate_one(path, card, out_dir, corr=corrections.Corrections(),
                  assume_side=None, overwrite=False, verbose=True,
                  tempgain=None, solution=None):
    """Calibrate one RAW product. Returns ``(out_path, factors)``.

    **Calibrating no longer changes a pixel.** ``sca_arrays/`` are copied from
    the raw product bit for bit, and every factor a consumer needs is RECORDED
    under ``calibration/<step>/multiplier`` -- the model the temperature gain
    introduced, now applied to every correction. It is then the consumer's
    choice which steps to apply: the digests apply all of them, and
    ``rcs_trend_reader.py`` applies whichever a user names. Before schema 2 the
    photodiode, side and ACM factors were multiplied in here, which left a user
    who wanted, say, everything but the ACM term no way to get it without
    undoing the composition by hand.

    Each step is a ``(6, 18)`` multiplier on ``(led_name, sca)`` with one rule:
    **calibrated = raw * multiplier**. A step that does not vary by SCA is
    broadcast rather than stored as ``(6,)``, so every step has the same shape
    and a consumer needs one line of arithmetic, not five.

    ``solution`` is an optional :class:`rcs_bridge_solution.BridgeSolution`;
    with it the ACM and side bridges are recorded as ``acm_bridge`` and
    ``side_bridge``. ``tempgain`` is an optional
    :class:`tempgain_model.TempGainModel`. A step whose input was not given is
    **absent**, never present-and-unity, so a consumer that needs it fails on a
    missing key instead of carrying an uncorrected 1.0 onward.
    """
    meta = rcs_products.read_metadata(path)
    if meta["product_kind"] != "per_sca":
        raise ValueError(
            f"{meta['name']} is product_kind={meta['product_kind']!r}. "
            f"Calibration writes per-SCA stacks; a legacy r=20 mosaic has to "
            f"go through the old make_sca_digests path instead (its "
            f"superpixels straddle SCA edges, which is what this product "
            f"shape exists to fix).")

    epoch = corrections.EpochMeta.from_product(path, assume_side=assume_side)
    row = card.row_for(epoch.run_label)
    # side=False always: the ground-derived B_SIDE_CORRECTIONS are no longer a
    # step. The side swap is bridged from flight data (side_bridge below), and
    # that bridge absorbs the electronics, the LED drive and the photodiode at
    # once, so applying the ground table as well would count the swap twice.
    factors = card.factors_for(epoch, corr=corrections.Corrections(
        photodiode=corr.photodiode, side=False, acm=corr.acm))

    out_path = rcs_products.product_path(out_dir, epoch.run_label,
                                         stage="calibrated")
    if os.path.exists(out_path) and not overwrite:
        if verbose:
            print(f"  skip {epoch.run_label}: {os.path.basename(out_path)} "
                  f"exists (use --force)")
        return out_path, factors

    # Read and written back untouched. Not even re-cast: a float32 round trip
    # is the identity, but asserting that bit-identity in the self-test is only
    # meaningful if this line never does arithmetic.
    arrays = rcs_products.read_activity_arrays(
        path, drop=("n_sca", "scas_present"))

    steps, step_attrs = {}, {}
    common = {"applied": False, "axes": "multiplier is (led_name, sca)",
              "rule": "calibrated = raw * multiplier"}

    segment = int(row["segment"])
    segment_lvdt = float(card.segment_reference_lvdt[segment])
    if corr.photodiode:
        reference_label = (_side_reference_label(card, epoch.mce_side)
                           if card.pd_reference_mode
                           == corrections.PD_REFERENCE_PER_SIDE
                           else card.reference_run_label)
        steps["photodiode"] = {
            "multiplier": _grid(factors.pd_factor),
            "pd_net": np.asarray(factors.pd_net, dtype=float),
            "pd_reference": np.asarray(factors.pd_reference, dtype=float),
            "valid": np.isfinite(factors.pd_factor),
        }
        step_attrs["photodiode"] = {
            **common,
            "definition": ("multiplier = pd_reference / pd_net per LED; the "
                           "same on every SCA"),
            "quantity": "lamp output drift, per LED",
            "pd_reference_mode": card.pd_reference_mode,
            "pd_reference_epoch": reference_label,
            "gauge": ("1.0 at the earliest epoch of this epoch's MCE side. "
                      "The A and B photodiodes are different devices behind "
                      "one mnemonic, so the trend is re-based at a swap and "
                      "the A->B ratio is carried by side_bridge"
                      if card.pd_reference_mode
                      == corrections.PD_REFERENCE_PER_SIDE
                      else "1.0 at the reference epoch"),
            "invalid_policy": ("NaN where pd_net <= PD_MIN_NET, never 1.0: an "
                               "uncorrected LED inside a corrected set looks "
                               "like a real response excursion"),
        }
    if corr.acm:
        acm = np.asarray(factors.acm_factor, dtype=float)
        steps["acm"] = {"multiplier": _grid(1.0 / acm),
                        "valid": np.isfinite(acm)}
        step_attrs["acm"] = {
            **common,
            "definition": (
                "multiplier = 1 / (1 + acm_coefficient * ((acm_lvdt + "
                "acm_offset) / acm_segment_reference_lvdt - 1)); the "
                "reciprocal is stored so that every step multiplies"),
            "quantity": "linear ACM response within this ACM segment",
            "acm_lvdt": float(epoch.acm_lvdt),
            "acm_segment": segment,
            "acm_segment_reference_lvdt": segment_lvdt,
            "acm_coefficient": float(cfg.acm_coefficient_for(epoch.mce_side)),
            "acm_offset": float(cfg.acm_offset_for(epoch.mce_side)),
            "validity": ("a small-perturbation model, valid only inside one "
                         "segment; across a move see acm_bridge"),
        }
    if solution is not None:
        after = [b for b in solution.boundaries("acm")
                 if rcs_bridge_solution._utc(b[0]) > epoch.timestamp]
        steps["acm_bridge"] = {
            "multiplier": np.repeat(
                solution.acm_multiplier(epoch.timestamp, cfg.SCA_NAMES)[None, :],
                cfg.N_LEDS, axis=0),
            "error": solution.acm_error(epoch.timestamp, cfg.SCA_NAMES),
            "valid": np.ones(cfg.N_LEDS, dtype=bool),
        }
        step_attrs["acm_bridge"] = {
            **common,
            "definition": ("product of the fitted per-SCA achromatic steps at "
                           "every ACM boundary after this epoch"),
            "quantity": "the step across ACM reconfigurations, per SCA",
            "gauge": rcs_bridge_solution.GAUGE,
            "boundaries_after": [f"{b[2]} ({b[3]})" for b in after] or ["none"],
            "error_note": ("error is (n_sca,): the total errors of the "
                           "composed steps, fractional, in quadrature"),
            "solution": os.path.basename(solution.path),
            "solution_sha256": solution.sha256,
            "details": "calibration/bridge_solution has every step",
        }
        side_after = [b for b in solution.boundaries("side")
                      if rcs_bridge_solution._utc(b[0]) > epoch.timestamp]
        side = solution.side_multiplier(epoch.timestamp, cfg.LED_NAMES)
        steps["side_bridge"] = {
            "multiplier": _grid(side),
            "error": solution.side_error(epoch.timestamp, cfg.LED_NAMES),
            "valid": np.isfinite(side),
        }
        step_attrs["side_bridge"] = {
            **common,
            "definition": ("product of the fitted per-LED, SCA-common steps "
                           "at every MCE side change after this epoch"),
            "quantity": ("everything that changed at a side swap -- detector "
                         "electronics, LED drive and photodiode -- as one "
                         "chromatic step that does not change the "
                         "illumination pattern"),
            "gauge": ("the present side is 1; earlier sides are scaled up to "
                      "it, because the instrument is not expected to return. "
                      + rcs_bridge_solution.GAUGE),
            "boundaries_after": ([f"{b[2]} ({b[3]})" for b in side_after]
                                 or ["none"]),
            "error_note": ("total error per LED of the composed step: the "
                           "larger of the fit and SCA-scatter estimates, plus "
                           "the fit-choice systematic, in quadrature"),
            # An array, not a list: _set_attrs stores a list as strings.
            "ground_b_side_corrections": np.array(
                [cfg.B_SIDE_CORRECTIONS[led] for led in cfg.LED_NAMES],
                dtype=float),
            "ground_note": (
                "the TVAC ground table, for comparison only and NOT a step: it "
                "multiplies a B-side value to read on the A scale, the "
                "opposite gauge, and covers the detector electronics alone"),
            "solution": os.path.basename(solution.path),
            "solution_sha256": solution.sha256,
        }
    if tempgain is not None:
        payload, attrs = _tempgain_block(path, tempgain, verbose=verbose)
        steps["tempgain"] = {key: value for key, value in payload.items()
                             if key not in ("led_name", "sca")}
        step_attrs["tempgain"] = attrs

    in_total = [name for name in STEPS
                if name in steps and name not in EXCLUDED_FROM_TOTAL]
    total = np.ones((cfg.N_LEDS, cfg.N_SCAS))
    for name in in_total:
        total = total * steps[name]["multiplier"]

    calibration = {"led_name": list(cfg.LED_NAMES),
                   "sca": np.arange(1, cfg.N_SCAS + 1, dtype=int),
                   "total_multiplier": total,
                   "total_valid": np.isfinite(total)}
    groups = {f"calibration/{name}": payload
              for name, payload in steps.items()}
    group_attrs = {f"calibration/{name}": attrs
                   for name, attrs in step_attrs.items()}
    if solution is not None:
        # The whole solution, not only this epoch's composed multiplier: every
        # step at every boundary with its errors, method, fallback note, LED
        # spread, residual rms, and the side bridge's pattern test with each
        # SCA's own estimate. ~200 rows. Without it a product could say what
        # was applied to it but not how well it is known, which used to be
        # recorded only in the digests' bridge_* meta.
        groups["calibration/bridge_solution"] = solution.as_columns()
        meta = {key: (np.asarray(value) if isinstance(value, (list, tuple))
                      and value and not isinstance(value[0], str) else value)
                for key, value in solution.meta.items()}
        group_attrs["calibration/bridge_solution"] = {
            **meta,
            "applied": False,
            "solution": os.path.basename(solution.path),
            "solution_sha256": solution.sha256,
            "rows": ("kind=acm: (boundary, SCA), an achromatic step per SCA; "
                     "kind=side: (boundary, LED), the step common to every "
                     "SCA; kind=side_sca: (boundary, SCA, LED), that SCA's own "
                     "estimate for the illumination-pattern test, NOT "
                     "applied. value multiplies every epoch before "
                     "boundary_utc"),
            "reader": "rcs_bridge_solution.BridgeSolution.from_columns",
        }
    group_attrs["calibration"] = {
        "calibration_schema": CALIBRATION_SCHEMA,
        "applied": False,
        "rule": ("calibrated = raw * calibration/<step>/multiplier, each "
                 "(led_name, sca); compose any subset by multiplying"),
        "steps_recorded": [name for name in STEPS if name in steps],
        "total_multiplier_steps": in_total,
        "total_multiplier_note": (
            "every recorded step except " + ", ".join(EXCLUDED_FROM_TOTAL)
            + ": the combination the digests' canonical LED columns use. The "
            "temperature gain is provisional, and is applied only to the "
            "digests' _tgcorr columns"),
        "pixels": ("sca_arrays/ are bit-identical to calibrated_from; nothing "
                   "here has been applied to them"),
        "trend_gauge_note": (
            "the photodiode is 1 at the start of each MCE side and the bridges "
            "are 1 in the present configuration. A time series normalized to "
            "its first epoch divides that epoch's multiplier out, which is how "
            "the digests read 1.0 at pass 1."),
        "helper": "rcs_trend_reader.py applies any chosen subset",
    }

    recorded = [name for name in STEPS if name in steps]
    os.makedirs(out_dir, exist_ok=True)
    rcs_products.write_calibrated(
        out_path, source=path, arrays=arrays,
        calibration=calibration,
        groups=groups, group_attrs=group_attrs,
        root_attrs={
            "calibration_schema": CALIBRATION_SCHEMA,
            # Nothing is in the pixels; the steps are named separately. The
            # empty string, not the old "photodiode,side,acm", is what tells
            # a schema-1 reader that applying nothing would be wrong.
            "corrections_applied": "",
            "calibration_recorded": ",".join(recorded),
            "calibration_in_total": ",".join(in_total),
            # Overwritten, not inherited. The stage-1 text says "No
            # corrections applied", which would now be true and still
            # misleading: everything needed to apply them is here.
            "provenance": (
                "Calibrated per-SCA RCS trend product, schema 2. NOTHING is "
                "applied to the pixels; the factors for "
                + (", ".join(recorded) or "nothing")
                + " are recorded under calibration/<step>/multiplier. L2 "
                "inputs are identified by calibrated_from, ref_file_id and "
                "crds_context."),
            "calibration_direction": "calibrated = raw * multiplier",
            **({} if tempgain is None else {
                "tempgain_recorded": True,
                "tempgain_applied": False,
                "tempgain_model": os.path.basename(tempgain.path),
                "tempgain_model_sha256": tempgain.sha256,
                "tempgain_form": tempgain.form,
                "tempgain_t_nominal_k": float(tempgain.t_nominal_k),
                "tempgain_t_scale_k": float(tempgain.t_scale_k),
                "tempgain_note": (
                    "RECORDED, NEVER APPLIED, like every step in a schema-2 "
                    "product: calibration/tempgain/multiplier."),
            }),
            **({} if solution is None else {
                "bridge_solution": os.path.basename(solution.path),
                "bridge_solution_sha256": solution.sha256,
            }),
            "bridge_applied": False,
            "bridge_recorded": solution is not None,
            "acm_mode": "linear",
            "reference_card": os.path.basename(card.path),
            "reference_card_sha256": card.sha256,
            "reference_run_label": card.reference_run_label,
            "pd_reference_mode": card.pd_reference_mode,
            # Not the reference epoch's LVDT. The photodiode factor is gauged
            # against reference_run_label, but the linear ACM correction is
            # gauged within this epoch's own segment, so these two attributes
            # describe different epochs and the name has to say so -- the
            # reference epoch usually sits in a different segment entirely.
            "acm_segment_reference_lvdt": segment_lvdt,
            "acm_segment": segment,
            "acm_move_min_delta": float(card.move_min_delta),
            "mce_side": epoch.mce_side,
            "mce_side_source": epoch.mce_side_source,
            "calibrated_from": os.path.basename(path),
            "calibrated_from_sha256": corrections.file_sha256(path),
        })

    if verbose:
        flag = "" if factors.all_valid else \
            f"  <-- {int((~factors.valid).sum())} invalid LED(s)"
        median = np.nanmedian(total, axis=1)
        print(f"  {epoch.run_label}: segment {segment}, side "
              f"{epoch.mce_side}, recorded {'+'.join(recorded)}; total "
              "(SCA median) " + " ".join(f"{v:.6f}" for v in median) + flag)
        for note in factors.notes:
            print(f"      {note}")

    return out_path, factors


def calibrate_set(target, card, out_dir, corr=corrections.Corrections(),
                  assume_side=None, overwrite=False, jobs=1, stage="raw",
                  recursive=False, tempgain=None, solution=None):
    """Calibrate every product under ``target``. Returns the written paths.

    Parallelism is by process, not by thread: h5py releases the GIL for the
    read but gzip decompression of a (18,256,256) stack does not, and the work
    is almost entirely compress/decompress. ``--jobs 1`` stays in-process so a
    traceback is a traceback and not a pickled one.
    """
    paths = discover_products(target, stage=stage, recursive=recursive)
    if not paths:
        raise SystemExit(f"no stage={stage!r} products under {target!r}")

    recorded = [name for name, on in (
        ("photodiode", corr.photodiode), ("acm", corr.acm),
        ("acm_bridge", solution is not None),
        ("side_bridge", solution is not None),
        ("tempgain", tempgain is not None)) if on]
    print(f"calibrating {len(paths)} product(s) -> {out_dir}: RECORDING "
          f"{', '.join(recorded) or 'nothing'}; no pixel is changed")

    written, invalid = [], []
    if jobs <= 1:
        for path in paths:
            out_path, factors = calibrate_one(
                path, card, out_dir, corr=corr, assume_side=assume_side,
                overwrite=overwrite, tempgain=tempgain, solution=solution)
            written.append(out_path)
            if not factors.all_valid:
                invalid.append(os.path.basename(path))
    else:
        import concurrent.futures as futures

        worker = _Worker(card, out_dir, corr, assume_side, overwrite,
                         tempgain_path=None if tempgain is None
                         else tempgain.path,
                         solution_path=None if solution is None
                         else solution.path)
        with futures.ProcessPoolExecutor(max_workers=jobs) as pool:
            for path, out_path, valid, message in pool.map(worker, paths):
                print(message, end="")
                written.append(out_path)
                if not valid:
                    invalid.append(os.path.basename(path))

    print(f"calibrated {len(written)} product(s)")
    if invalid:
        print(f"WARNING: {len(invalid)} product(s) have at least one invalid "
              f"per-LED factor, recorded as a NaN multiplier: {invalid[:10]}")
        print("         A NaN here is deliberate -- an uncorrected LED would "
              "look like a real response excursion. See rcs_report.")

    return written


class _Worker:
    """Picklable closure for the process pool; captures stdout per file."""

    def __init__(self, card, out_dir, corr, assume_side, overwrite,
                 tempgain_path=None, solution_path=None):
        self.card_path = card.path
        self.out_dir = out_dir
        self.corr = corr
        self.assume_side = assume_side
        self.overwrite = overwrite
        # Paths, not the loaded objects, for the same reason the card is a
        # path: every worker then validates the same file for itself, and a
        # stale object cannot be carried across the pool boundary.
        self.tempgain_path = tempgain_path
        self.solution_path = solution_path
        self._card = None
        self._tempgain = None
        self._solution = None

    def __call__(self, path):
        import io
        import contextlib

        if self._card is None:
            self._card = corrections.ReferenceCard.read(self.card_path)
        if self.tempgain_path and self._tempgain is None:
            import tempgain_model
            self._tempgain = tempgain_model.TempGainModel.read(
                self.tempgain_path)
        if self.solution_path and self._solution is None:
            self._solution = rcs_bridge_solution.BridgeSolution.read(
                self.solution_path)
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            out_path, factors = calibrate_one(
                path, self._card, self.out_dir, corr=self.corr,
                assume_side=self.assume_side, overwrite=self.overwrite,
                tempgain=self._tempgain, solution=self._solution)

        return path, out_path, factors.all_valid, buffer.getvalue()


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------

def self_test(verbose=True):
    """End-to-end on synthetic products, schema 2.

    1. Calibrating changes NO pixel: every stack is bit-identical to the raw.
    2. The recorded photodiode multiplier is ``reference_pd / epoch_pd`` by
       hand, and applying it gives what schema 1 used to put in the pixels.
    3. A bridge solution is recorded present-nominal: epochs before a boundary
       carry its step, epochs after it carry 1.

    Checked on real written products, not on the arithmetic alone -- that is
    covered by ``rcs_corrections.self_test``; what is unproven here is that the
    factors reach the file under the documented names and shapes.
    """
    import tempfile

    failures = []

    def check(name, condition, detail=""):
        if condition:
            if verbose:
                print(f"  ok   {name}")
        else:
            failures.append(name)
            print(f"  FAIL {name} {detail}")

    if not corrections.self_test(verbose=False):
        failures.append("rcs_corrections.self_test")
    if verbose:
        print("  -- calibrate_rcs_products")

    with tempfile.TemporaryDirectory() as tmp:
        raw_dir = os.path.join(tmp, "raw")
        cal_dir = os.path.join(tmp, "cal")
        os.makedirs(raw_dir)

        # Two synthetic epochs at the same ACM position, the second with its
        # lamp 10% down on LED2 only. Both sides A, so only the photodiode
        # term can move -- which makes the expected factor exact and known.
        pd_reference = np.array([0.0, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25])
        pd_second = pd_reference.copy()
        pd_second[2] *= 0.9                     # entry 2 == LED2
        made = []
        for index, (label, stamp, pd) in enumerate((
                ("SYN_00001_01_001_001_20260101", "2026-01-01T00:00:00.000000",
                 pd_reference),
                ("SYN_00001_01_002_001_20260102", "2026-01-02T00:00:00.000000",
                 pd_second))):
            arrays = [rcs_products.ActivityArray(
                key=led,
                stack=np.full((cfg.N_SCAS, 8, 8), 100.0, dtype=np.float32),
                attrs={"activity_led": led, "hardware_led": 1,
                       "visit_id": f"000010100{index+1:03d}001001001"})
                for led in cfg.LED_NAMES]
            path = rcs_products.product_path(raw_dir, label, stage="raw")
            rcs_products.write_raw(
                path, arrays, bin_factor=cfg.SCA_PIX // 8,
                root_attrs={"run_label": label, "car_label": "SYN",
                            "decon_cycle": "decon1", "mce_side": "A",
                            "mce_side_source": "test", "pass_number": index + 1},
                dictionary={"timestamp": stamp,
                            "ACM_LVDT": np.full(6, -2815.0),
                            "RCS_photodiode": pd,
                            "RCS_forward_voltage": np.full(7, 1.3)})
            made.append(path)

        check("both synthetic raw products were written",
              all(os.path.exists(p) for p in made))
        check("discovery finds them by the stage attribute",
              len(discover_products(raw_dir, stage="raw")) == 2)
        check("discovery does not mistake them for calibrated",
              discover_products(raw_dir, stage="calibrated") == [])

        card = make_card(raw_dir, os.path.join(tmp, "card.ecsv"),
                         verbose=False)
        check("the earlier epoch is the reference",
              card.reference_run_label.startswith("SYN_00001_01_001"),
              card.reference_run_label)
        check("the reference pd drops the dark entry",
              len(card.reference_pd) == cfg.N_LEDS
              and np.allclose(card.reference_pd, 0.25),
              str(card.reference_pd))
        check("one ACM segment, no spurious move",
              card.n_segments == 1 and not card.moves)

        paths = calibrate_set(raw_dir, card, cal_dir, jobs=1)
        check("both products calibrated", len(paths) == 2)

        # 1. Calibrating changes no pixel, bit for bit -- the whole point of
        #    schema 2. Compared against the raw product, not against 100.0, so
        #    a cast or a multiply-by-one that rounds would also fail.
        first = rcs_products.read_stacks(paths[0])
        second = rcs_products.read_stacks(paths[1])
        raw_second = rcs_products.read_stacks(made[1])
        check("every pixel is bit-identical to the raw product",
              all(np.array_equal(second[k], raw_second[k], equal_nan=True)
                  and second[k].dtype == raw_second[k].dtype
                  for k in raw_second),
              str([k for k in raw_second
                   if not np.array_equal(second[k], raw_second[k],
                                         equal_nan=True)]))
        check("no applied_factor attribute survives from schema 1",
              _dataset_attr(paths[1], "LED2", "applied_factor") is None)

        # 2. The recorded photodiode multiplier is ref_pd / epoch_pd by hand,
        #    and is the same on every SCA.
        expected = 0.25 / (0.25 * 0.9)
        pd_mult = _group_data(paths[1], "calibration/photodiode", "multiplier")
        check("photodiode/multiplier is (6, 18), one value per LED",
              pd_mult.shape == (cfg.N_LEDS, cfg.N_SCAS)
              and np.all(np.ptp(pd_mult, axis=1) == 0.0), str(pd_mult.shape))
        check("LED2's recorded multiplier is ref_pd/epoch_pd",
              abs(pd_mult[1, 0] - expected) < 1e-12,
              f"{pd_mult[1, 0]} vs {expected}")
        check("the other five LEDs record exactly 1.0",
              np.all(pd_mult[[0, 2, 3, 4, 5]] == 1.0))
        total = _group_data(paths[1], "calibration", "total_multiplier")
        check("total_multiplier is photodiode * acm, the recorded steps",
              np.allclose(total, pd_mult * _group_data(
                  paths[1], "calibration/acm", "multiplier"),
                          rtol=0, atol=1e-15))
        check("applying it gives what schema 1 put in the pixels",
              np.allclose(second["LED2"] * total[1][:, None, None],
                          100.0 * expected, rtol=0, atol=1e-4))

        meta = rcs_products.read_metadata(paths[1])
        attrs = meta["attrs"]
        check("the calibrated product records the card's sha256",
              attrs["reference_card_sha256"] == card.sha256)
        check("and which raw product it came from",
              attrs["calibrated_from"].startswith("SYN_00001_01_002"),
              str(attrs.get("calibrated_from")))
        check("stage is calibrated, schema 2",
              meta["stage"] == "calibrated"
              and int(attrs["calibration_schema"]) == CALIBRATION_SCHEMA)
        check("corrections_applied is EMPTY -- nothing is in the pixels",
              attrs["corrections_applied"] == "",
              str(attrs.get("corrections_applied")))
        check("and calibration_recorded names what is recorded instead",
              attrs["calibration_recorded"] == "photodiode,acm",
              str(attrs.get("calibration_recorded")))
        check("no bridge recorded without a solution, and none applied",
              not bool(attrs["bridge_recorded"])
              and not bool(attrs["bridge_applied"])
              and not _has_group(paths[1], "calibration/side_bridge"))

        # The composition that makes the two-stage split exact: the response
        # ratio is the pixel ratio times the multiplier ratio.
        ratio = (np.nanmedian(second["LED2"]) / np.nanmedian(first["LED2"])
                 * total[1, 0]
                 / _group_data(paths[0], "calibration", "total_multiplier")[1, 0])
        check("raw ratio x multiplier ratio reproduces the response ratio",
              abs(ratio - expected) < 1e-12, f"{ratio} vs {expected}")

        # Leaving a step out has to change the record, or the flag is
        # decorative.
        off_dir = os.path.join(tmp, "cal_nopd")
        calibrate_set(raw_dir, card, off_dir,
                      corr=corrections.Corrections(photodiode=False), jobs=1)
        off_path = rcs_products.product_path(
            off_dir, "SYN_00001_01_002_001_20260102", stage="calibrated")
        check("--no-photodiode leaves the photodiode step ABSENT, not unity",
              not _has_group(off_path, "calibration/photodiode"))
        check("and says so in calibration_recorded",
              rcs_products.read_metadata(off_path)["attrs"][
                  "calibration_recorded"] == "acm")

        # ---- the temperature-gain reference block ----
        # A fresh raw product, because this one needs a housekeeping/ group:
        # the multiplier is evaluated at each LED's own activity temperature,
        # read out of the product itself.
        import pandas as pd
        import tempgain_model as tgm

        hot = np.array([120.0, 121.0, 122.0, 123.0, 124.0, 125.0])
        hk_label = "SYN_00001_01_003_001_20260103"
        table = pd.DataFrame({
            "h5_key": ["DARK"] + list(cfg.LED_NAMES) + ["AUX_LED3FLAT1"],
            "activity_number": np.arange(8),
            "SC Timestamp": ["2026-01-03T00:00:00.000000"] * 8,
            "end_time": ["2026-01-03T00:10:00.000000"] * 8,
            "is_aux": [False] * 7 + [True],
            TEMPGAIN_MNEMONIC: [99.0] + list(hot) + [126.0],
            f"rule_{TEMPGAIN_MNEMONIC}": ["window"] * 8,
        })
        hk_arrays = [rcs_products.ActivityArray(
            key=led,
            stack=np.full((cfg.N_SCAS, 8, 8), 100.0, dtype=np.float32),
            attrs={"activity_led": led, "hardware_led": 1,
                   "visit_id": "000010100003001001001"})
            for led in cfg.LED_NAMES]
        hk_raw = rcs_products.product_path(raw_dir, hk_label, stage="raw")
        rcs_products.write_raw(
            hk_raw, hk_arrays, bin_factor=cfg.SCA_PIX // 8,
            root_attrs={"run_label": hk_label, "car_label": "SYN",
                        "decon_cycle": "decon1", "mce_side": "A",
                        "mce_side_source": "test", "pass_number": 3},
            table=table, hk_columns=[TEMPGAIN_MNEMONIC],
            led_columns=[],
            dictionary={"timestamp": "2026-01-03T00:00:00.000000",
                        "ACM_LVDT": np.full(6, -2815.0),
                        "RCS_photodiode": pd_reference,
                        "RCS_forward_voltage": np.full(7, 1.3)})

        check("the per-LED temperature reader keys, never slices",
              np.allclose(rcs_products.read_led_temperatures(
                  hk_raw, TEMPGAIN_MNEMONIC)[0], hot),
              str(rcs_products.read_led_temperatures(hk_raw,
                                                     TEMPGAIN_MNEMONIC)[0]))
        check("and refuses a mnemonic the product does not carry",
              rcs_products._raises(KeyError,
                                   rcs_products.read_led_temperatures,
                                   hk_raw, "WFI_NOT_A_CHANNEL"))

        card3 = make_card(raw_dir, os.path.join(tmp, "card3.ecsv"),
                          verbose=False)
        plain_dir = os.path.join(tmp, "cal_nogain")
        calibrate_set(hk_raw, card3, plain_dir, jobs=1, overwrite=True)
        plain = rcs_products.product_path(plain_dir, hk_label,
                                          stage="calibrated")
        check("with no model the tempgain step is ABSENT, not empty",
              not _has_group(plain, "calibration/tempgain")
              and not _has_group(plain, "tempgain"))
        check("and no tempgain_* root attr appears",
              not [k for k in rcs_products.read_metadata(plain)["attrs"]
                   if k.startswith("tempgain_")])

        # An all-zero model: the inert case. G == 1 everywhere, so the
        # multiplier must be exactly 1.0 and nothing can hide behind rounding.
        inert = tgm.TempGainModel.from_alpha(
            np.zeros((cfg.N_SCAS, 2)), sca_names=list(range(1, cfg.N_SCAS + 1)),
            led_names=list(cfg.LED_NAMES), derivation="self-test inert")
        inert.write(os.path.join(tmp, "inert.ecsv"))
        inert_dir = os.path.join(tmp, "cal_inert")
        calibrate_set(hk_raw, card3, inert_dir, jobs=1, overwrite=True,
                      tempgain=inert)
        inert_path = rcs_products.product_path(inert_dir, hk_label,
                                               stage="calibrated")
        check("a zero-coefficient model gives multiplier exactly 1.0",
              np.all(_group_data(inert_path, "calibration/tempgain",
                                 "multiplier") == 1.0))

        # A non-trivial model, with a DIFFERENT coefficient per detector so a
        # transposed (led, sca) grid cannot pass.
        alpha = np.zeros((cfg.N_SCAS, 2))
        alpha[:, 0] = -0.01 * (1.0 + 0.1 * np.arange(cfg.N_SCAS))
        model = tgm.TempGainModel.from_alpha(
            alpha, sca_names=list(range(1, cfg.N_SCAS + 1)),
            led_names=list(cfg.LED_NAMES), derivation="self-test",
            meta={"temperature_mnemonic": TEMPGAIN_MNEMONIC})
        model.write(os.path.join(tmp, "model.ecsv"))
        gain_dir = os.path.join(tmp, "cal_gain")
        calibrate_set(hk_raw, card3, gain_dir, jobs=1, overwrite=True,
                      tempgain=model)
        gain_path = rcs_products.product_path(gain_dir, hk_label,
                                              stage="calibrated")

        want = 1.0 / model.gain_grid(hot)
        check("the multiplier is 1/G at each LED's OWN temperature",
              np.allclose(_group_data(gain_path, "calibration/tempgain",
                                      "multiplier"),
                          want, rtol=0, atol=1e-12))
        # The direction, pinned separately from the value. This model has
        # alpha1 < 0 so G < 1 above nominal, and the recorded multiplier --
        # the factor that UNDOES it -- must therefore be greater than 1. The
        # two candidates differ only in the sign of a 1 % term, so an equality
        # test against the right array is not enough on its own: a sign flip
        # in gain_grid would flip both sides of it together.
        check("and it is a correction factor, not the gain: G < 1 hot, so "
              "1/G > 1",
              float(np.min(model.gain_grid(hot))) < 1.0
              and float(np.min(want)) > 1.0)
        check("and it is not a transposed grid",
              np.ptp(want, axis=1).min() > 0 and np.ptp(want, axis=0).min() > 0)
        check("the group says it was not applied",
              _group_attr(gain_path, "calibration/tempgain", "applied")
              in (False, 0, np.False_))
        check("and the gain is left OUT of total_multiplier",
              np.allclose(_group_data(gain_path, "calibration",
                                      "total_multiplier"),
                          _group_data(gain_path, "calibration/photodiode",
                                      "multiplier")
                          * _group_data(gain_path, "calibration/acm",
                                        "multiplier"), rtol=0, atol=1e-15))
        check("and so does the root, where homogeneity checks read",
              rcs_products.read_metadata(gain_path)["attrs"]["tempgain_applied"]
              in (False, 0, np.False_))
        check("the model's sha256 travels with the product",
              rcs_products.read_metadata(
                  gain_path)["attrs"]["tempgain_model_sha256"] == model.sha256)

        # THE assertion this whole block exists for: recording the gain must
        # not move a single pixel.
        before = rcs_products.read_stacks(plain)
        after = rcs_products.read_stacks(gain_path)
        check("recording the gain changes NO pixel, bit for bit",
              all(np.array_equal(before[k], after[k], equal_nan=True)
                  for k in before),
              str([k for k in before
                   if not np.array_equal(before[k], after[k],
                                         equal_nan=True)]))

        check("the calibration group states the rule and what is recorded",
              "raw * calibration" in str(_group_attr(gain_path, "calibration",
                                                     "rule"))
              and "tempgain" in list(np.asarray(_group_attr(
                  gain_path, "calibration", "steps_recorded")).astype(str)))
        check("and the ACM step carries the coefficient it used",
              abs(float(_group_attr(gain_path, "calibration/acm",
                                    "acm_coefficient"))
                  - cfg.acm_coefficient_for("A")) < 1e-12)
        check("provenance says nothing is applied",
              "NOTHING is applied" in str(rcs_products.read_metadata(
                  gain_path)["attrs"]["provenance"]))

        # ---- the bridge solution, recorded present-nominal ----
        # A side step between epochs 2 and 3, and an ACM step between 1 and 2.
        # Epoch 1 is before both, epoch 2 before the side step only, epoch 3
        # after both -- so the three products must carry, respectively, both
        # steps, the side step alone, and exactly 1.0.
        side_value = np.array([0.95, 0.97, 1.05, 1.00, 1.01, 1.02])
        rows = [{"kind": "acm", "boundary_index": 2,
                 "boundary_run_label": "SYN_00001_01_002_001_20260102",
                 "boundary_utc": "2026-01-01T12:00:00+00:00",
                 "transition": "reposition", "sca": sca, "led": "ALL",
                 "value": 1.0 + 0.001 * sca, "stat_error": 1e-4,
                 "systematic": 0.0, "total_error": 1e-4, "method": "bridge",
                 "n_early": 2, "n_late": 2, "note": ""}
                for sca in range(1, cfg.N_SCAS + 1)]
        rows += [{"kind": "side", "boundary_index": 3,
                  "boundary_run_label": hk_label,
                  "boundary_utc": "2026-01-02T12:00:00+00:00",
                  "transition": "A->B", "sca": 0, "led": led,
                  "value": float(side_value[i]), "stat_error": 1e-4,
                  "systematic": 2e-4, "total_error": 3e-4, "method": "side",
                  "n_early": 2, "n_late": 2, "note": ""}
                 for i, led in enumerate(cfg.LED_NAMES)]
        solution = rcs_bridge_solution.BridgeSolution(
            rows=rows, meta={"reference_card_sha256": card3.sha256})
        solution.write(os.path.join(tmp, "solution.ecsv"))
        bridged_dir = os.path.join(tmp, "cal_bridged")
        bridged = calibrate_set(raw_dir, card3, bridged_dir, jobs=1,
                                overwrite=True, solution=solution)
        side_rec = [_group_data(p, "calibration/side_bridge", "multiplier")
                    for p in bridged]
        acm_rec = [_group_data(p, "calibration/acm_bridge", "multiplier")
                   for p in bridged]
        check("an epoch before the side swap carries the per-LED step on "
              "every SCA",
              np.allclose(side_rec[0], side_value[:, None])
              and np.allclose(side_rec[1], side_value[:, None]))
        check("an epoch after it carries exactly 1.0 -- the present is nominal",
              np.all(side_rec[2] == 1.0))
        check("the ACM step is per SCA, the same for every LED, and only "
              "before its boundary",
              np.allclose(acm_rec[0][0], 1.0 + 0.001 * np.arange(1, 19))
              and np.all(np.ptp(acm_rec[0], axis=0) == 0.0)
              and np.all(acm_rec[1] == 1.0))
        check("total_multiplier now includes both bridges",
              np.allclose(_group_data(bridged[0], "calibration",
                                      "total_multiplier"),
                          _group_data(bridged[0], "calibration/photodiode",
                                      "multiplier")
                          * _group_data(bridged[0], "calibration/acm",
                                        "multiplier")
                          * acm_rec[0] * side_rec[0]))
        check("the solution's sha256 is recorded on the product",
              rcs_products.read_metadata(bridged[0])["attrs"][
                  "bridge_solution_sha256"] == solution.sha256)
        import h5py

        with h5py.File(bridged[0], "r") as handle:
            group = handle["calibration/bridge_solution"]
            embedded = rcs_bridge_solution.BridgeSolution.from_columns(
                {key: group[key][()] for key in group},
                meta=dict(group.attrs))
            not_a_step = "multiplier" not in group
        check("the WHOLE solution is embedded, and evaluates like the file",
              len(embedded.rows) == len(solution.rows)
              and np.allclose(embedded.side_multiplier(
                  "2026-01-01T00:00:00", cfg.LED_NAMES), side_value)
              and not_a_step)
        check("and the ACM step carries its composed per-SCA error",
              _group_data(bridged[0], "calibration/acm_bridge",
                          "error").shape == (cfg.N_SCAS,))
        check("and the pixels are STILL the raw ones",
              all(np.array_equal(v, rcs_products.read_stacks(made[0])[k],
                                 equal_nan=True)
                  for k, v in rcs_products.read_stacks(bridged[0]).items()))

        # Round trip through stage 3's own reader, for the two product shapes
        # it branches on. The gain-carrying one is the case a variable reused
        # inside that branch once broke -- on every gain product and no other,
        # so a self-test of the stage-2 side alone could never see it.
        import make_sca_digests

        epoch = make_sca_digests.Epoch.metadata_only(gain_path)
        check("stage 3 reads a gain-carrying schema-2 product",
              epoch.calibration_schema == 2
              and np.allclose(epoch.tempgain, want)
              and np.isfinite(epoch.acm_lvdt))
        epoch = make_sca_digests.Epoch.metadata_only(bridged[0])
        check("and a bridge-carrying one, with every step on canonical axes",
              {"photodiode", "acm", "acm_bridge", "side_bridge"}
              <= set(epoch.steps)
              and np.allclose(epoch.steps["side_bridge"], side_value[:, None]))

        # ---- a side change opens a card segment ----
        # The B electronics read the ACM with a per-channel offset, so the
        # first B epoch must start its own segment with its own reference
        # LVDT, or that offset reaches the linear ACM term.
        sided_dir = os.path.join(tmp, "raw_sided")
        os.makedirs(sided_dir)
        for index, (side, lvdt) in enumerate((("A", -2815.0), ("A", -2815.0),
                                              ("B", -2880.0))):
            label = f"SYN_00001_01_{index + 10:03d}_001_2026011{index}"
            rcs_products.write_raw(
                rcs_products.product_path(sided_dir, label, stage="raw"),
                [rcs_products.ActivityArray(
                    key=led, stack=np.full((cfg.N_SCAS, 8, 8), 100.0,
                                           dtype=np.float32),
                    attrs={"activity_led": led, "hardware_led": 1,
                           "visit_id": "000010100010001001001"})
                 for led in cfg.LED_NAMES],
                bin_factor=cfg.SCA_PIX // 8,
                root_attrs={"run_label": label, "car_label": "SYN",
                            "decon_cycle": "decon1", "mce_side": side,
                            "mce_side_source": "test",
                            "pass_number": index + 10},
                dictionary={"timestamp": f"2026-01-1{index}T00:00:00.000000",
                            "ACM_LVDT": np.full(6, lvdt),
                            "RCS_photodiode": pd_reference,
                            "RCS_forward_voltage": np.full(7, 1.3)})
        sided = make_card(sided_dir, os.path.join(tmp, "sided.ecsv"),
                          verbose=False)
        check("a side change opens an ACM segment on the card, even with no "
              "LVDT move",
              sided.n_segments == 2
              and [r["segment"] for r in sided.epochs] == [0, 0, 1],
              str([r["segment"] for r in sided.epochs]))
        check("and the card is per-side by default, re-based at the first B "
              "epoch",
              sided.pd_reference_mode == corrections.PD_REFERENCE_PER_SIDE
              and sorted(sided.side_reference_pd) == ["A", "B"])

        # A model naming a channel the product does not carry must refuse,
        # not silently fall back to a different thermometer.
        wrong = tgm.TempGainModel.from_alpha(
            alpha, sca_names=list(range(1, cfg.N_SCAS + 1)),
            led_names=list(cfg.LED_NAMES),
            meta={"temperature_mnemonic": "WFI_NOT_A_CHANNEL"})
        check("a model naming an absent thermal channel is refused",
              rcs_products._raises(KeyError, _tempgain_block, hk_raw, wrong,
                                   False))

        # A collapsed pedestal must NaN the channel rather than scale it 60x.
        bad = pd_reference.copy()
        bad[2] = 0.004
        # Both numerators: a per-side card (the default) reads
        # side_reference_pd, a global one reference_pd, and the guard must
        # hold whichever is in force.
        card.reference_pd = np.asarray(bad, dtype=float)[1:]
        card.side_reference_pd = {"A": np.asarray(bad, dtype=float)[1:]}
        factors = card.factors_for(
            corrections.EpochMeta.from_product(made[0]))
        check("a collapsed reference pd invalidates that LED, set-wide",
              np.isnan(factors.total_factor[1]) and not factors.valid[1],
              str(factors.total_factor))

    print(f"calibrate_rcs_products.self_test: "
          f"{'ok' if not failures else 'FAILED'} ({len(failures)} failure(s))")

    return not failures


def _dataset_attr(path, key, name, group="sca_arrays"):
    import h5py

    with h5py.File(path, "r") as handle:
        return handle[group][key].attrs.get(name)


def _has_group(path, name):
    import h5py

    with h5py.File(path, "r") as handle:
        return name in handle


def _group_data(path, group, name):
    import h5py

    with h5py.File(path, "r") as handle:
        return handle[group][name][...]


def _group_attr(path, group, name):
    import h5py

    with h5py.File(path, "r") as handle:
        return handle[group].attrs.get(name)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser():
    parser = argparse.ArgumentParser(
        description=__doc__.split("\n\n")[0],
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Two steps: --make-card once over the whole set, then "
               "--card/--in per file (parallel).")

    mode = parser.add_argument_group("mode")
    mode.add_argument("--make-card", action="store_true",
                      help="build the reference card (metadata only, no pixels)")
    mode.add_argument("--plot-pd-trend", metavar="DIR",
                      help="write the set-wide photodiode trend plots")
    mode.add_argument("--self-test", action="store_true",
                      help="run every self-test; no data, no credentials")

    inputs = parser.add_argument_group("inputs")
    inputs.add_argument("--raw-dir", help="product directory for --make-card")
    inputs.add_argument("--card", default="rcs_reference_card.ecsv",
                        help="reference card ECSV (read, or written by "
                             "--make-card)")
    inputs.add_argument("--in", dest="inputs", metavar="FILE_OR_DIR",
                        help="product(s) to calibrate")
    inputs.add_argument("--out-dir", help="where calibrated products go")
    inputs.add_argument("--stage", default="raw",
                        choices=list(SCHEMA_STAGES) + ["any"],
                        help="which stage to select on discovery "
                             "(default: raw)")
    inputs.add_argument("--recursive", action="store_true",
                        help="search subdirectories for products")

    # Its own group, deliberately NOT beside --no-photodiode/--no-acm. This is
    # not a correction: nothing it does changes a pixel. Listing it among the
    # correction switches would invite exactly the misreading the whole design
    # exists to prevent.
    reference = parser.add_argument_group(
        "cross-epoch inputs (recorded, like every step, never applied)")
    reference.add_argument("--tempgain-model", metavar="PATH",
                           help="temperature-gain model ECSV from "
                                "fit_temperature_gain.py --model-out. Its "
                                "evaluated per-LED, per-SCA multipliers are "
                                "recorded in calibration/tempgain/. Omit it "
                                "and the step is absent rather than unity")
    reference.add_argument("--bridge-solution", metavar="PATH",
                           help="bridge solution ECSV from make_sca_digests.py "
                                "--solution-out: the fitted ACM steps (per "
                                "SCA) and side-swap steps (per LED, common to "
                                "every SCA), recorded as calibration/"
                                "acm_bridge/ and calibration/side_bridge/. "
                                "Omit it and both are absent")

    switches = parser.add_argument_group("steps to record")
    switches.add_argument("--no-photodiode", dest="photodiode",
                          action="store_false",
                          help="do not record the per-LED lamp-output step")
    switches.add_argument("--no-side", dest="side", action="store_false",
                          help="accepted for old command lines and ignored: "
                               "the ground B-side table is no longer a step; "
                               "the swap is bridged from flight data instead "
                               "(see --bridge-solution)")
    switches.add_argument("--no-acm", dest="acm", action="store_false",
                          help="do not record the linear ACM-position step")
    switches.add_argument("--assume-side", choices=["A", "B"],
                          help="electronics side for products that record "
                               "none. Without this the run refuses rather "
                               "than defaulting to A -- the B-side per-LED "
                               "corrections are 1.5-6%%, the size of the "
                               "signal")
    switches.add_argument("--pd-reference",
                          choices=list(corrections.PD_REFERENCE_MODES),
                          default=corrections.PD_REFERENCE_PER_SIDE,
                          help="how to gauge the photodiode numerator on "
                               "--make-card (default: %(default)s, since the "
                               "2026-10-06 swap). 'per-side' re-bases at each "
                               "MCE side, because the A and B photodiodes are "
                               "different physical devices behind the same "
                               "mnemonic; on a one-side set it is bit-exact "
                               "with 'global'. A set spanning both sides is "
                               "refused in 'global' mode. See PD_CORRECTION.md "
                               "section 8")
    switches.add_argument("--acm-move-min-delta", type=float,
                          default=cfg.ACM_MOVE_MIN_DELTA,
                          help="LVDT units that count as an ACM move "
                               "(default: %(default)s; pass 5000 to approximate "
                               "the pre-2026-10 segmentation, which missed two "
                               "same-sign repositions)")

    run = parser.add_argument_group("run")
    run.add_argument("--jobs", type=int, default=1,
                     help="parallel worker processes (default: 1)")
    run.add_argument("--force", action="store_true",
                     help="overwrite existing calibrated products")
    run.add_argument("--quiet", action="store_true")

    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)

    if args.self_test:
        return 0 if self_test(verbose=not args.quiet) else 1

    corr = corrections.Corrections(photodiode=args.photodiode,
                                   side=args.side, acm=args.acm)

    card = None
    if args.make_card:
        if not args.raw_dir:
            raise SystemExit("--make-card needs --raw-dir")
        card = make_card(args.raw_dir, args.card, stage=args.stage,
                         assume_side=args.assume_side,
                         move_min_delta=args.acm_move_min_delta,
                         recursive=args.recursive, verbose=not args.quiet,
                         pd_reference=args.pd_reference)

    if args.inputs:
        if not args.out_dir:
            raise SystemExit("calibrating needs --out-dir")
        if card is None:
            if not os.path.exists(args.card):
                raise SystemExit(
                    f"no reference card at {args.card!r}. Build one first:\n"
                    f"  {sys.argv[0]} --make-card --raw-dir DIR "
                    f"--card {args.card}")
            card = corrections.ReferenceCard.read(args.card)
            print(f"read {args.card}: {len(card.epochs)} epoch(s), "
                  f"{card.n_segments} ACM segment(s), reference "
                  f"{card.reference_run_label}")

        # Read once here, before any product is written, so a malformed model
        # file fails on line one rather than after eighty files.
        tempgain = None
        if args.tempgain_model:
            import tempgain_model

            tempgain = tempgain_model.TempGainModel.read(args.tempgain_model)
            print(f"read {args.tempgain_model}: form={tempgain.form} "
                  f"degree={tempgain.degree} "
                  f"t_nominal={tempgain.t_nominal_k:g} K  "
                  f"sha256 {tempgain.sha256[:12]}")
            print("  RECORDED, NOT APPLIED -- the pixels are unchanged by it")
            # A stale model is a documentation error, not a data error, because
            # it is not applied. Loud, but not fatal.
            stale = str(tempgain.meta.get("source_reference_card_sha256", ""))
            if stale and stale != card.sha256:
                print("  WARNING: this model was fitted from digests built "
                      "against a different reference card; its coefficients "
                      "describe a different calibration than this one")

        solution = None
        if args.bridge_solution:
            solution = rcs_bridge_solution.BridgeSolution.read(
                args.bridge_solution)
            print(solution.describe())
            fitted_card = str(solution.meta.get("reference_card_sha256", ""))
            if fitted_card and fitted_card != card.sha256:
                # Unlike the gain model this is not a documentation error: the
                # steps were fitted to response formed with the OTHER card's
                # photodiode and ACM factors, and recording them beside this
                # card's would join two calibrations at every boundary.
                raise SystemExit(
                    f"{args.bridge_solution} was fitted from products "
                    f"calibrated against card {fitted_card[:12]}, not "
                    f"{card.sha256[:12]}. Re-run the digests on products "
                    f"from this card first (run_trend.py does both).")

        calibrate_set(args.inputs, card, args.out_dir, corr=corr,
                      assume_side=args.assume_side, overwrite=args.force,
                      jobs=args.jobs, stage=args.stage,
                      recursive=args.recursive, tempgain=tempgain,
                      solution=solution)

    if args.plot_pd_trend:
        if card is None:
            card = corrections.ReferenceCard.read(args.card)
        import rcs_trend_plots

        written = rcs_trend_plots.plot_pd_trend_summary(card,
                                                        args.plot_pd_trend)
        for path in written:
            print(f"  wrote {path}")

    if not any((args.make_card, args.inputs, args.plot_pd_trend)):
        build_parser().print_help()

        return 2

    return 0


if __name__ == "__main__":
    sys.exit(main())
