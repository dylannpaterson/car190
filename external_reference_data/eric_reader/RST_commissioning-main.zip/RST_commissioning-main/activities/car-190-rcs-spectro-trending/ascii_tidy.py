#!/usr/bin/env python
"""Keep code and markdown ASCII: report non-ASCII characters, and replace the
ones with an agreed ASCII spelling.

The repository rule (AGENTS.md) is ASCII-only code and markdown, applied to
files as they are worked on rather than as one sweep. So the usual call names
the files being edited:

    .venv/bin/python ascii_tidy.py check README.md batch/refresh.py
    .venv/bin/python ascii_tidy.py fix   README.md batch/refresh.py --dry-run
    .venv/bin/python ascii_tidy.py fix   README.md batch/refresh.py
    .venv/bin/python ascii_tidy.py fix   --git-changed     # what `git status` lists
    .venv/bin/python ascii_tidy.py table                   # the replacement table

``check`` exits 1 if any listed file has a non-ASCII character, so it can gate
a commit. ``fix`` rewrites only characters in :data:`REPLACEMENTS` and leaves
the rest in place, reported with their line and code point: a character with
no agreed spelling (an accented name, an emoji) is a decision for a person,
not for a table. ``--git-changed`` reads ``git status --porcelain`` (read-only)
and keeps the ``.py`` and ``.md`` files among the modified and untracked ones.

**Superscripts and subscripts are runs, not characters.** ``10^-4`` written
with superscripts is one run of two characters, so a run becomes ``^`` plus its
plain form (``10^-4``, ``chi^2``), and a subscript run ``_`` plus its plain form.
Doing it per character would give ``10^-^4``.

**In code, check what a string is for before fixing it.** Text that is printed,
or a comment, is safe to change. A non-ASCII character that is *data* -- a
unit symbol a parser matches, a label written into a product -- changes
behaviour; ``fix`` reports which lines of a ``.py`` file it touched so they can
be read, and the module's self-test is the check. Library use:
:func:`tidy_text` and :func:`find_non_ascii` take and return strings.
"""
import argparse
import collections
import os
import subprocess
import sys
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))

# One ASCII spelling per character. Chosen to read naturally in prose and in
# code comments; physics names are spelled out (lambda, sigma) rather than
# abbreviated, matching how the code names its variables.
REPLACEMENTS = {
    # dashes, minus and hyphens
    "\u2212": "-",      # minus sign
    "\u2013": "-",      # en dash
    "\u2014": "--",     # em dash
    "\u2011": "-",      # non-breaking hyphen
    "\u2010": "-",      # hyphen
    "\u2012": "-",      # figure dash
    # spaces
    "\u00a0": " ", "\u202f": " ", "\u2009": " ", "\u2002": " ", "\u2003": " ",
    "\u200b": "",       # zero-width space
    # quotes and punctuation
    "\u2018": "'", "\u2019": "'", "\u201c": '"', "\u201d": '"',
    "\u2026": "...", "\u2022": "*", "\u00b7": "*", "\u00a7": "Sec. ",
    # arrows
    "\u2192": "->", "\u2190": "<-", "\u2194": "<->", "\u21d2": "=>",
    "\u2191": "^", "\u2193": "v",
    # mathematics
    "\u00d7": "x", "\u00b1": "+/-", "\u2248": "~", "\u2243": "~",
    "\u2264": "<=", "\u2265": ">=", "\u2260": "!=", "\u2261": "==",
    "\u221a": "sqrt", "\u221d": "propto", "\u221e": "inf", "\u2211": "sum",
    "\u2208": "in", "\u2202": "d", "\u2207": "grad", "\u00f7": "/",
    "\u226a": "<<", "\u226b": ">>",
    # units
    "\u00b0": " deg", "\u00b5": "u", "\u03bc": "u", "\u00c5": "Angstrom",
    "\u2126": "Ohm",
    # Greek, spelled out
    "\u03b1": "alpha", "\u03b2": "beta", "\u03b3": "gamma", "\u03b4": "delta",
    "\u0394": "Delta", "\u03b5": "eps", "\u03b7": "eta", "\u03b8": "theta",
    "\u03bb": "lambda", "\u039b": "Lambda", "\u03c0": "pi", "\u03c1": "rho",
    "\u03c3": "sigma", "\u03a3": "Sigma", "\u03c4": "tau", "\u03c6": "phi",
    "\u03a6": "Phi", "\u03c7": "chi", "\u03c9": "omega", "\u03a9": "Omega",
    "\u03bd": "nu", "\u03ba": "kappa",
    "\u27e8": "<", "\u27e9": ">",            # angle brackets (averages)
    "\u2295": "(+)",                          # sum in quadrature
    "\u0304": "bar",                          # combining macron: x-bar -> xbar
    # marks
    "\u2713": "ok", "\u2714": "ok", "\u2717": "x", "\u2718": "x",
}

SUPERSCRIPT = dict(zip("\u2070\u00b9\u00b2\u00b3\u2074\u2075\u2076\u2077"
                       "\u2078\u2079\u207b\u207a\u207f",
                       "0123456789-+n"))
SUBSCRIPT = dict(zip("\u2080\u2081\u2082\u2083\u2084\u2085\u2086\u2087"
                     "\u2088\u2089\u208b\u208a",
                     "0123456789-+"))


def find_non_ascii(text):
    """``[(line, column, char), ...]``, 1-based, for every non-ASCII char."""
    out = []
    for number, line in enumerate(text.splitlines(), start=1):
        for column, char in enumerate(line, start=1):
            if ord(char) > 127:
                out.append((number, column, char))
    return out


def tidy_text(text):
    """``(new_text, unmapped)``: replacements applied, the rest counted.

    ``unmapped`` is a ``Counter`` of the non-ASCII characters left in place.
    """
    out, unmapped, i = [], collections.Counter(), 0
    while i < len(text):
        char = text[i]
        for table, mark in ((SUPERSCRIPT, "^"), (SUBSCRIPT, "_")):
            if char in table:
                j = i
                while j < len(text) and text[j] in table:
                    j += 1
                out.append(mark + "".join(table[c] for c in text[i:j]))
                i = j
                break
        else:
            if ord(char) <= 127:
                out.append(char)
            elif char in REPLACEMENTS:
                # " deg" after a space would double it: "89.5 deg", not "89.5  deg"
                rep = REPLACEMENTS[char]
                if rep.startswith(" ") and out and out[-1].endswith(" "):
                    rep = rep.lstrip()
                # "Sec. " before a space would double it too: "Sec. 8"
                if rep.endswith(" ") and text[i + 1:i + 2] == " ":
                    rep = rep.rstrip()
                out.append(rep)
            else:
                out.append(char)
                unmapped[char] += 1
            i += 1
    return "".join(out), unmapped


def _name(char):
    return unicodedata.name(char, f"U+{ord(char):04X}")


def git_changed(root=HERE):
    """Modified and untracked ``.py``/``.md`` files under ``root`` (read-only)."""
    result = subprocess.run(["git", "status", "--porcelain", "--", "."],
                            cwd=root, capture_output=True, text=True, check=True)
    files = []
    top = subprocess.run(["git", "rev-parse", "--show-toplevel"], cwd=root,
                         capture_output=True, text=True, check=True).stdout.strip()
    for line in result.stdout.splitlines():
        path = line[3:].split(" -> ")[-1].strip()
        full = os.path.join(top, path)
        if os.path.isdir(full):
            for directory, _, names in os.walk(full):
                files += [os.path.join(directory, n) for n in names
                          if n.endswith((".py", ".md"))]
        elif full.endswith((".py", ".md")) and os.path.exists(full):
            files.append(full)
    return sorted(set(f for f in files if "/.venv/" not in f))


def _files(args):
    paths = list(args.files)
    if args.git_changed:
        paths += git_changed()
    if not paths:
        raise SystemExit("name the files to check, or pass --git-changed")
    return paths


def cmd_check(args):
    dirty = 0
    for path in _files(args):
        with open(path, encoding="utf-8") as handle:
            found = find_non_ascii(handle.read())
        if not found:
            continue
        dirty += 1
        counts = collections.Counter(char for _, _, char in found)
        mappable = sum(n for c, n in counts.items()
                       if c in REPLACEMENTS or c in SUPERSCRIPT or c in SUBSCRIPT)
        print(f"{os.path.relpath(path)}: {len(found)} non-ASCII character(s), "
              f"{mappable} with an ASCII spelling")
        for char, n in counts.most_common(args.top):
            print(f"    {n:5d}  U+{ord(char):04X}  {_name(char)}")
    print(f"{dirty} file(s) with non-ASCII characters")
    return 1 if dirty else 0


def cmd_fix(args):
    left = 0
    for path in _files(args):
        with open(path, encoding="utf-8") as handle:
            text = handle.read()
        new, unmapped = tidy_text(text)
        if new == text:
            continue
        changed = [n for n, (a, b) in enumerate(
            zip(text.splitlines(), new.splitlines()), start=1) if a != b]
        print(f"{os.path.relpath(path)}: {len(changed)} line(s) changed"
              + (f" (lines {changed[:12]}{' ...' if len(changed) > 12 else ''}"
                 f" -- read these in a .py file)" if path.endswith(".py")
                 else ""))
        for char, n in unmapped.most_common():
            lines = [ln for ln, _, c in find_non_ascii(new) if c == char][:5]
            print(f"    left in place: {n} x U+{ord(char):04X} "
                  f"{_name(char)}, lines {lines}")
            left += n
        if not args.dry_run:
            with open(path, "w", encoding="utf-8") as handle:
                handle.write(new)
    if args.dry_run:
        print("[dry run] nothing written")
    if left:
        print(f"{left} character(s) have no agreed spelling; edit them by hand "
              f"or add them to REPLACEMENTS")
    return 0


def cmd_table(args):
    for char, rep in sorted(REPLACEMENTS.items(), key=lambda kv: ord(kv[0])):
        print(f"  U+{ord(char):04X}  {rep!r:12s} {_name(char)}")
    print("  superscript runs -> '^' + plain; subscript runs -> '_' + plain")
    return 0


def self_test():
    text = ("a \u2212 b \u2014 c \u2192 d, 10\u207b\u2074, \u03c7\u00b2, "
            "89.5 \u00b0, 5\u00b0, \u00b11.2 \u00b5V, H\u2082O \u00e9")
    new, unmapped = tidy_text(text)
    assert new == ("a - b -- c -> d, 10^-4, chi^2, 89.5 deg, 5 deg, +/-1.2 uV, "
                   "H_2O \u00e9"), new
    assert unmapped == collections.Counter({"\u00e9": 1})
    assert tidy_text("\u00a78 and \u00a7 8")[0] == "Sec. 8 and Sec. 8"
    assert find_non_ascii("ok\nx\u2212y") == [(2, 2, "\u2212")]
    assert tidy_text("plain ascii") == ("plain ascii", collections.Counter())
    print("ascii_tidy self-test: ok")
    return True


def main(argv=None):
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--self-test", action="store_true")
    sub = parser.add_subparsers(dest="command")
    for name, func in (("check", cmd_check), ("fix", cmd_fix)):
        p = sub.add_parser(name)
        p.add_argument("files", nargs="*")
        p.add_argument("--git-changed", action="store_true",
                       help="add the modified/untracked .py and .md files")
        p.set_defaults(func=func)
        if name == "check":
            p.add_argument("--top", type=int, default=8,
                           help="characters listed per file")
        else:
            p.add_argument("--dry-run", action="store_true")
    sub.add_parser("table").set_defaults(func=cmd_table)
    args = parser.parse_args(argv)
    if args.self_test:
        return 0 if self_test() else 1
    if not args.command:
        parser.print_help()
        return 2
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
