"""Diagnostic figures for the per-SCA RCS trend digests.

Driven by ``make_sca_digests.py``. Products:

``bridge_summary.png``      the bridge per SCA, and its focal-plane gradient
``bridge_sensitivity.png``  how the bridge moves with the fit window and degree
``run_structure.png``       ACM segments against decon episodes, and why each
                            boundary was measured or modelled
``decon_evidence.png``      whether the decon labels the bridge now relies on
                            are confirmed by the response's own colour
``time_series_all_scas.png`` every SCA at once, laid out on the focal plane
``time_series_<SCA>.png``   one SCA, as measured above and bridged below
``time_series_<LED>_all_scas.png`` one LED, all 18 SCAs overlaid, vs calendar date
``time_series_<LED>_all_scas_tgcorr.png`` the same, with the provisional
                            temperature gain divided out. Written only when the
                            products carry a gain block, and deliberately drawn
                            on IDENTICAL axes to the figure above so the two can
                            be blinked -- see :func:`plot_led_all_scas`.

``digest_trend_plots.py`` draws the two per-LED families again from a digest
set alone, over the full period (byte-identical to these) or the last N weeks.
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np

# Imported from the shared modules rather than from make_sca_digests, which
# imports this module: that was an import cycle worked around by a deferred
# `import digest_plots` inside make_sca_digests.main().
from rcs_acm import (boundary_floors, bridge_sensitivity, closure_residuals,
                     decon_episodes, screen_sensitivity, segment_boundaries)
from rcs_sca_grid import read_sca_geometry, sorted_scas
from rcs_trend_config import B_SIDE_CORRECTIONS, LED_NAMES, N_SCAS

# Slots 1-6 in documented order -> LED1..LED6, which also
# happens to be increasing wavelength.  Never reorder or cycle these.
LED_COLORS = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300"]

SURFACE = "#ffffff"
INK = "#0b0b0b"
INK_SECONDARY = "#52514e"
INK_MUTED = "#8a8983"
GRID = "#e2e1dc"
GAP_FILL = "#f0efec"
# A decon gap: a pale blue, recessive like GAP_FILL but distinguishable from it,
# because a decon resets the film and an ACM move or side swap does not.
DECON_FILL = "#e2ebf6"

LINE_WIDTH = 2.6
MARKER_SIZE = 5.5


def _style_axes(ax, xlabel=None, ylabel=None, title=None):
    """Recessive grid and axes; ink tokens for all text."""
    ax.set_facecolor(SURFACE)
    ax.grid(True, color=GRID, linewidth=1.0, zorder=0)
    ax.set_axisbelow(True)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(GRID)
    ax.tick_params(colors=INK_SECONDARY, labelsize=10, length=3)
    if xlabel:
        ax.set_xlabel(xlabel, color=INK_SECONDARY, fontsize=12)
    if ylabel:
        ax.set_ylabel(ylabel, color=INK_SECONDARY, fontsize=12)
    if title:
        ax.set_title(title, color=INK, fontsize=13, loc="left")


def _new_figure(figsize):
    fig = plt.figure(figsize=figsize, facecolor=SURFACE)
    return fig


def _boundary_label(series, boundary):
    """What a segment boundary is: an ACM move, or an MCE side change.

    A side change is a segment boundary too (the linear ACM term is referenced
    within each side) but it is bridged by a different step, and calling it an
    ACM move on a figure would send a reader looking for an LVDT step that is
    not there.
    """
    side = getattr(series, "side_boundaries", {}).get(boundary)
    return f"MCE {side}" if side else "ACM move"


def _decon_starts(series):
    """``[(first epoch index, cycle)]`` for every decon episode after the first.

    Each is the first epoch after a decon, so the cadence gap before it is
    where the film was driven off. From the series' own ``decon_cycles``, the
    labels the digests' episodes come from.
    """
    cycles = getattr(series, "decon_cycles", None)
    if cycles is None or not len(cycles):
        return []
    return [(episode["first"], episode["key"] or "unlabelled")
            for episode in decon_episodes(cycles)[1:]]


def _mark_decons(ax, starts_and_ends, label=True):
    """Shade and label each decon gap; ``starts_and_ends`` are axis values."""
    for start, end, cycle in starts_and_ends:
        ax.axvspan(start, end, color=DECON_FILL, zorder=1, linewidth=0)
        if label:
            mid = start + (end - start) / 2
            # Above the traces, on the surface colour: a decon falls where
            # the curves are steepest, and an unbacked label is lost in them.
            ax.annotate(f"{cycle} starts", xy=(mid, 0.98),
                        xycoords=("data", "axes fraction"), ha="center",
                        va="top", fontsize=9, color=INK_MUTED, rotation=90,
                        zorder=6, bbox=dict(boxstyle="square,pad=0.15",
                                            facecolor=SURFACE, alpha=0.85,
                                            edgecolor="none"))


def _mark_reconfigurations(ax, series, label=True):
    """Shade each cadence gap that contains an ACM reconfiguration, a side swap
    or a decon. Decons are labelled from the top of the axes, so a decon next to
    an ACM move (2026-09-23/24) does not stack its label on the move's."""
    _mark_decons(ax, [(series.time_hours[i - 1], series.time_hours[i], cycle)
                      for i, cycle in _decon_starts(series) if i > 0], label)
    for boundary in segment_boundaries(series.segment):
        start = series.time_hours[boundary - 1]
        end = series.time_hours[boundary]
        ax.axvspan(start, end, color=GAP_FILL, zorder=1, linewidth=0)
        if label:
            ax.annotate(_boundary_label(series, boundary),
                        xy=(0.5 * (start + end), 0.02),
                        xycoords=("data", "axes fraction"), ha="center",
                        va="bottom", fontsize=9, color=INK_MUTED, rotation=90)


def _mark_reconfigurations_dates(ax, series, label=True):
    """Date-axis counterpart of ``_mark_reconfigurations``, for plots vs calendar date."""
    _mark_decons(ax, [(series.timestamps[i - 1], series.timestamps[i], cycle)
                      for i, cycle in _decon_starts(series) if i > 0], label)
    for boundary in segment_boundaries(series.segment):
        start = series.timestamps[boundary - 1]
        end = series.timestamps[boundary]
        ax.axvspan(start, end, color=GAP_FILL, zorder=1, linewidth=0)
        if label:
            mid = start + (end - start) / 2
            ax.annotate(_boundary_label(series, boundary), xy=(mid, 0.02),
                        xycoords=("data", "axes fraction"),
                        ha="center", va="bottom", fontsize=9, color=INK_MUTED,
                        rotation=90)


def _direct_labels(ax, times, response, x_pad):
    """Label each trace at its right end, nudged apart so they do not collide."""
    order = np.argsort(-response[-1, :])
    positions = {}
    limits = ax.get_ylim()
    min_gap = 0.028 * (limits[1] - limits[0])
    previous = None
    for led in order:
        y = response[-1, led]
        if previous is not None and previous - y < min_gap:
            y = previous - min_gap
        positions[led] = y
        previous = y
    for led, y in positions.items():
        ax.annotate(LED_NAMES[led], xy=(times[-1] + x_pad, y), xycoords="data",
                    va="center", ha="left", fontsize=10, color=LED_COLORS[led])


def _plot_traces(ax, times, response, marker="o"):
    for led in range(response.shape[1]):
        ax.plot(times, response[:, led], color=LED_COLORS[led],
                linewidth=LINE_WIDTH, marker=marker, markersize=MARKER_SIZE,
                markeredgecolor=SURFACE, markeredgewidth=1.0, zorder=3,
                label=LED_NAMES[led])


# ---------------------------------------------------------------------------
# Focal-plane layout
# ---------------------------------------------------------------------------

def focal_plane_layout():
    """Grid position of each SCA as ``{sca: (row, col)}``.

    The 18 SCAs sit on a clean 3x6 grid of physical centers, so columns follow
    x_center ascending and rows follow y_center descending.  
    
    TODO: revisit or remove
    """
    centers, _, _ = read_sca_geometry()
    xs = sorted({round(c[0] / 10.0) for c in centers.values()})
    ys = sorted({round(c[1] / 10.0) for c in centers.values()}, reverse=True)
    return {sca: (ys.index(round(c[1] / 10.0)), xs.index(round(c[0] / 10.0)))
            for sca, c in centers.items()}, len(ys), len(xs)


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------

def plot_single_sca(series, sca, out_path):
    """As-measured and bridged response for one SCA, sharing a time axis."""
    times = series.time_hours
    x_pad = 0.012 * np.ptp(times)

    fig = _new_figure((9.0, 7.0))
    axes = fig.subplots(2, 1, sharex=True)

    for ax, response, title in (
        (axes[0], series.raw[sca],
         f"{sca} relative response, as measured "
         f"(ACM step of ~{100 * (1 - series.factors[sca][0] / series.factors[sca][-1]):.1f}% "
         "left in)"),
        (axes[1], series.response(sca),
         f"{sca} relative response, bridged across the ACM reconfiguration"),
    ):
        _style_axes(ax, ylabel="response / reference epoch", title=title)
        _mark_reconfigurations(ax, series, label=(ax is axes[0]))
        _plot_traces(ax, times, response)
        ax.set_xlim(times[0] - x_pad, times[-1] + 9 * x_pad)
        _direct_labels(ax, times, response, x_pad)

    steps = series.steps[sca]
    if steps:
        first = steps[0]
        half_width = _window_of(series, sca)
        if half_width:
            for ax in axes:
                for edge in (first.boundary_time - half_width,
                             first.boundary_time + half_width):
                    ax.axvline(edge, color=INK_MUTED, linewidth=1.2,
                               linestyle=(0, (4, 3)), zorder=2)
        if first.is_fitted:
            note = (
                f"bridge {first.value:.5f} $\\pm$ {first.stat_error:.5f} (stat)\n"
                f"per-LED spread {first.led_spread:.5f}\n"
                f"residual scatter {first.rms_early * 1e5:.0f}e-5 pre-move, "
                f"{first.rms_late * 1e5:.0f}e-5 post\n"
                f"fit window (dashed): {first.n_early} early + "
                f"{first.n_late} late epochs")
        else:
            # Say so rather than printing a row of NaNs: the value is modelled,
            # not measured, and the caveat belongs on the figure.
            note = (f"bridge {first.value:.5f} from the {first.method} model, "
                    f"not fitted\n{first.note}")
        axes[1].annotate(note, xy=(0.02, 0.04), xycoords="axes fraction",
                         fontsize=10, color=INK_SECONDARY, va="bottom",
                         linespacing=1.5)

    axes[1].set_xlabel("hours since reference epoch", color=INK_SECONDARY, fontsize=12)
    handles, labels = axes[0].get_legend_handles_labels()
    legend = fig.legend(handles, labels, loc="upper center", ncol=6, frameon=False,
                        fontsize=10, bbox_to_anchor=(0.5, 1.0))
    for text in legend.get_texts():
        text.set_color(INK_SECONDARY)

    fig.tight_layout(rect=(0, 0, 1, 0.955))
    fig.savefig(out_path, dpi=150, facecolor=SURFACE)
    plt.close(fig)
    return out_path


def _window_of(series, sca):
    """Half-width actually used by the bridge fit, recovered from the epochs used.

    Zero for a step that was not fitted: ``n_epochs_used`` is 0 there, and
    indexing the sorted distances by ``-1`` would silently return the widest
    separation in the whole run.
    """
    steps = series.steps[sca]
    if not steps or not steps[0].is_fitted or steps[0].n_epochs_used < 1:
        return 0.0
    first = steps[0]
    used = np.abs(series.time_hours - first.boundary_time)
    return float(np.sort(used)[first.n_epochs_used - 1])


def plot_all_scas(series, out_path):
    """Bridged response for every SCA, panels laid out on the focal plane."""
    layout, n_rows, n_cols = focal_plane_layout()

    fig = _new_figure((16.0, 1.15 * n_rows + 1.5))
    axes = fig.subplots(n_rows, n_cols, sharex=True, sharey=True)
    times = series.time_hours

    for sca, (row, col) in layout.items():
        ax = axes[row, col]
        _style_axes(ax)
        _mark_reconfigurations(ax, series, label=False)
        _plot_traces(ax, times, series.response(sca), marker=None)
        ax.annotate(sca, xy=(0.03, 0.06), xycoords="axes fraction", fontsize=12,
                    color=INK, va="bottom")
        if series.steps[sca]:
            ax.annotate(f"B = {series.steps[sca][0].value:.4f}",
                        xy=(0.97, 0.06), xycoords="axes fraction", fontsize=10,
                        color=INK_MUTED, va="bottom", ha="right")
        if row == n_rows - 1:
            ax.set_xlabel("hours", color=INK_SECONDARY, fontsize=12)
        if col == 0:
            ax.set_ylabel("response", color=INK_SECONDARY, fontsize=12)

    handles, labels = axes[0, 0].get_legend_handles_labels()
    legend = fig.legend(handles, labels, loc="upper center", ncol=6, frameon=False,
                        fontsize=12, bbox_to_anchor=(0.5, 0.995))
    for text in legend.get_texts():
        text.set_color(INK_SECONDARY)
    fig.suptitle("Bridged relative RCS response, panels in focal-plane position "
                 "(columns: x ascending, rows: y descending)",
                 color=INK, fontsize=14, x=0.008, ha="left", y=0.972)
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    fig.savefig(out_path, dpi=140, facecolor=SURFACE)
    plt.close(fig)
    return out_path


def _shared_response_ylim(series, scas, led_index, margin=0.05):
    """The y-limits BOTH figures of a blink pair use, or ``None``.

    ``None`` when the series carries no gain block: there is then no second
    figure to blink against, and leaving matplotlib's autoscale alone is what
    keeps ``time_series_<LED>_all_scas.png`` byte-identical to a build from
    before this feature existed.

    Otherwise the limits span the union of the as-delivered and the corrected
    curves. The union rather than the as-delivered frame alone, which is the
    tempting shortcut because it would leave the delivered figure untouched in
    every case: measured on the 176-epoch set, the corrected curves fall
    *below* the as-delivered autoscale on LED3 and LED6, by 5.7 % and 9.1 % of
    the frame height. Reusing the delivered limits would have silently clipped
    two of the six comparisons at the bottom edge.

    ``margin`` reproduces matplotlib's own default 0.05 autoscale padding, so a
    shared frame still looks like an autoscaled one.
    """
    if not series.tempgain:
        return None
    values = np.concatenate(
        [series.response(sca)[:, led_index] for sca in scas]
        + [series.response_tgcorr(sca)[:, led_index] for sca in scas])
    if not np.isfinite(values).any():
        return None
    low, high = float(np.nanmin(values)), float(np.nanmax(values))
    pad = margin * (high - low) or margin
    return low - pad, high + pad


def _mark_events(ax, events):
    """Dashed line and a top label for each ``(datetime, label)`` in ``events``.

    Operations events the digests do not carry (a heater bump, a power cycle),
    from ``rcs_trend_config.TREND_EVENTS``. Drawn only on request, so the
    default figures do not change when an event is registered.
    """
    for when, label in events:
        ax.axvline(when, color=INK_SECONDARY, linewidth=1.2, linestyle="--",
                   zorder=2)
        ax.annotate(label, xy=(when, 0.98), xycoords=("data", "axes fraction"),
                    xytext=(-3, 0), textcoords="offset points", ha="right",
                    va="top", fontsize=9, color=INK_SECONDARY, rotation=90,
                    zorder=6, bbox=dict(boxstyle="square,pad=0.15",
                                        facecolor=SURFACE, alpha=0.85,
                                        edgecolor="none"))


def plot_led_all_scas(series, led_index, out_path, corrected=False,
                      markers=False, title_note="", events=()):
    """Bridged response for one LED, every SCA overlaid, against calendar date.

    SCAs are colored by number on a single viridis ramp rather than 18 discrete
    categorical hues, since 18 series is well past where hue identity holds up;
    the colorbar carries the SCA number instead of a legend box.

    ``corrected=True`` draws the identical figure from the gain-corrected
    response instead of the as-delivered one, into its own file. Deliberately
    the SAME single-panel geometry, because the two files are meant to be
    **blinked** -- flipped between in one image viewer -- and a blink resolves a
    ~1 % change on 18 overlaid curves far better than two stacked panels, where
    the eye has to carry a shape across a few centimetres of whitespace.

    What a blink requires is that everything except the curves be identical, so
    that flipping shows the data moving and not the frame. Hence the one shared
    figure size, the one colorbar call, and the y-limits forced to a common
    range by :func:`_shared_response_ylim` rather than autoscaled per file. The
    title and the footnote are the only intended differences.

    ``markers``, ``title_note`` and ``events`` are for a time window cut from a
    digest set (``digest_trend_plots.py --last-weeks N``): a dot per epoch,
    since a week holds a few dozen rather than hundreds, the window in the
    title, and dated operations events. All three default off, which keeps
    the full-period figures exactly as they were.
    """
    scas = sorted_scas(series.raw)
    dates = series.timestamps
    led = LED_NAMES[led_index]
    n = len(scas)
    cmap = plt.get_cmap("viridis")

    if corrected and not series.tempgain:
        raise ValueError(
            "corrected=True needs a temperature-gain block; this series "
            "carries none, and drawing a figure identical to the delivered "
            "one would read as a correction of zero rather than as an absent "
            "model")

    fig = _new_figure((11.0, 6.0))
    ax = fig.subplots()

    if corrected:
        accessor = series.response_tgcorr
        title = (f"{led} relative response, all {n} SCAs -- provisional "
                 f"temperature gain removed ({series.tempgain_form})")
    else:
        accessor = series.response
        title = f"{led} relative response, all {n} SCAs"
    if title_note:
        # On its own line, in both members of a blink pair: appended, it ran
        # the corrected title off the figure, and a two-line title on one file
        # only would shift its axes against the other's.
        title = f"{title}\n{title_note}"

    _style_axes(ax, ylabel="response / reference epoch", title=title)
    _mark_reconfigurations_dates(ax, series)
    _mark_events(ax, events)
    style = (dict(marker="o", markersize=4.0, markeredgecolor=SURFACE,
                  markeredgewidth=0.8) if markers else {})
    for ind, sca in enumerate(scas):
        ax.plot(dates, accessor(sca)[:, led_index],
                color=cmap(ind / max(n - 1, 1)), linewidth=2.2, zorder=3,
                **style)

    frame = _shared_response_ylim(series, scas, led_index)
    if frame is not None:
        ax.set_ylim(frame)

    locator = mdates.AutoDateLocator()
    ax.xaxis.set_major_locator(locator)
    ax.xaxis.set_major_formatter(mdates.ConciseDateFormatter(locator))
    ax.set_xlabel("date (UTC)", color=INK_SECONDARY, fontsize=12)

    sm = plt.cm.ScalarMappable(cmap=cmap, norm=plt.Normalize(vmin=1, vmax=n))
    sm.set_array([])
    # A single Axes, not a one-element list: passing a list makes matplotlib
    # take the geometry from the group rather than from the one axes, which
    # shifts the figure by a few pixels. Both members of the blink pair go
    # through this same call for that reason.
    cbar = fig.colorbar(sm, ax=ax, pad=0.015)
    cbar.set_label("SCA", color=INK_SECONDARY, fontsize=12)
    cbar.set_ticks(range(1, n + 1))
    cbar.ax.tick_params(colors=INK_SECONDARY, labelsize=9)
    cbar.outline.set_visible(False)

    fig.tight_layout()
    if corrected:
        # After tight_layout, and as figure text rather than an in-axes
        # annotation, for two separate reasons: tight_layout does not manage
        # fig.text, so adding this cannot nudge the axes and break the blink;
        # and the only clear space inside the axes is taken by the ACM move
        # labels. The size of what was removed belongs on the figure because a
        # reader blinking two near-identical images should not have to
        # eyeball-integrate a 1 % effect to find out how big it was.
        ratio = np.concatenate([series.tempgain_ratio(sca)[:, led_index]
                                for sca in scas])
        span = ""
        if np.isfinite(ratio).any():
            lo, hi = np.nanmin(ratio), np.nanmax(ratio)
            span = (f"gain applied: {100 * (lo - 1):+.2f}% to "
                    f"{100 * (hi - 1):+.2f}%; ")
        # One line, and kept short enough to fit 11 inches at this size: the
        # first draft ran off the right edge, which is easy to miss because
        # matplotlib neither wraps nor warns.
        fig.text(0.008, 0.008,
                 f"{span}blink against time_series_{led}_all_scas.png, "
                 f"identical axes; RECORDED in the h5 products, NOT applied",
                 fontsize=8, color=INK_SECONDARY, va="bottom", ha="left")
    fig.savefig(out_path, dpi=150, facecolor=SURFACE)
    plt.close(fig)
    return out_path


def plot_bridge_summary(series, out_path, boundary_index=0):
    """The bridge per SCA, and the same values against focal-plane y position.

    A step the joint fit could not solve carries no per-LED estimates and no
    statistical error, so it is drawn as a value alone. Dropping those SCAs
    instead would hide exactly the ones whose bridge is modelled rather than
    measured.
    """
    scas = [s for s in sorted_scas(series.raw)
            if len(series.steps.get(s, ())) > boundary_index]
    steps = [series.steps[s][boundary_index] for s in scas]
    values = np.array([s.value for s in steps])
    errors = np.array([s.stat_error for s in steps])
    n_led = max((len(s.per_led) for s in steps), default=0)
    per_led = np.full((len(steps), max(n_led, 1)), np.nan)
    for ind, step in enumerate(steps):
        if len(step.per_led) == n_led and n_led:
            per_led[ind] = step.per_led
    centers, _, _ = read_sca_geometry()

    fig = _new_figure((14.0, 5.8))
    left, right = fig.subplots(1, 2)

    # Left: value per SCA, with the independent per-LED estimates behind it.
    x = np.arange(len(scas))
    methods = "+".join(sorted({s.method for s in steps}))
    boundary = steps[0].boundary if steps else 0
    _style_axes(left, ylabel="bridge factor B",
                title=f"Bridge per SCA (joint over LEDs), with\n"
                      f"independent single-LED estimates\n"
                      f"boundary at epoch {boundary + 1}, method {methods}")
    for led in range(per_led.shape[1]):
        if not np.isfinite(per_led[:, led]).any():
            continue  # no per-LED estimate exists; a legend entry for an
            # undrawn curve would advertise data this boundary does not have
        left.plot(x, per_led[:, led], linestyle="none", marker="_",
                  markersize=11, markeredgewidth=1.6, color=LED_COLORS[led],
                  zorder=2, label=LED_NAMES[led])
    left.errorbar(x, values, yerr=errors, linestyle="none", marker="o",
                  markersize=7, color=INK, ecolor=INK, elinewidth=1.8,
                  capsize=4, markeredgecolor=SURFACE, markeredgewidth=1.0,
                  zorder=4, label="joint")
    left.set_xticks(x)
    left.set_xticklabels([s.replace("SCA", "") for s in scas], fontsize=10)
    left.set_xlabel("SCA", color=INK_SECONDARY, fontsize=12)
    if left.get_legend_handles_labels()[1]:
        # Below the axes: the per-LED marks spread over the full height of the
        # panel, so an in-axes legend lands on the data, and the title above it
        # is three lines deep.
        legend = left.legend(loc="upper center", bbox_to_anchor=(0.5, -0.12),
                             ncol=7, frameon=False, fontsize=9,
                             borderaxespad=0.0, handletextpad=0.5,
                             columnspacing=1.4)
        for text in legend.get_texts():
            text.set_color(INK_SECONDARY)

    # Right: the physical gradient the ACM move imprinted -- but only a fitted
    # boundary that is a real move has one. The linear fallback gives every SCA
    # the same number, and a manual break is an asserted boundary where the
    # telemetry shows no move at all, so its bridge is a null test whose answer
    # should be 1.0. Calling either a "position gradient" invites reading a
    # construction or a null as a result.
    fitted = any(step.is_fitted for step in steps)
    moves = getattr(series, "moves", ())
    manual = (boundary_index < len(moves)
              and getattr(moves[boundary_index], "manual", False))
    if manual:
        title = ("Against focal-plane y: this boundary was asserted, not\n"
                 "detected -- no move happened, so 1.0 is the null result")
    elif fitted:
        title = ("The same bridge against focal-plane y: the ACM\n"
                 "move left a position gradient")
    else:
        title = ("Against focal-plane y: flat by construction -- this\n"
                 "boundary is modelled, so every SCA shares one value")
    y_center = np.array([centers[s][1] for s in scas])
    _style_axes(right, xlabel="SCA y center (mm)", ylabel="bridge factor B",
                title=title)
    right.errorbar(y_center, values, yerr=errors, linestyle="none", marker="o",
                   markersize=7, color=INK, ecolor=INK, elinewidth=1.8, capsize=4,
                   markeredgecolor=SURFACE, markeredgewidth=1.0, zorder=3)
    for sca, xv, yv in zip(scas, y_center, values):
        right.annotate(sca.replace("SCA", ""), xy=(xv, yv), xytext=(0, 8),
                       textcoords="offset points", ha="center", fontsize=9,
                       color=INK_MUTED)

    fig.tight_layout(w_pad=3.0)
    # bbox_inches="tight": the legend sits outside the axes, so the default
    # bounding box would clip it.
    fig.savefig(out_path, dpi=150, facecolor=SURFACE, bbox_inches="tight")
    plt.close(fig)
    return out_path


def plot_bridge_sensitivity(series, spec, out_path, boundary_index=0,
                            degrees=(1, 2, 3),
                            windows=(15.0, 20.0, 25.0, 30.0, 40.0, None)):
    """Bridge value against fit window, one panel per polynomial degree.

    Choices the data reject (a low degree or a wide are drawn faint and excluded
    from the quoted systematic.
    """
    scas = [s for s in sorted_scas(series.raw)
            if len(series.steps.get(s, ())) > boundary_index]
    adopted = {sca: series.steps[sca][boundary_index].value for sca in scas}
    boundary = segment_boundaries(series.segment)[boundary_index]

    # The pipeline normally scans and screens already, on its way to the
    # per-SCA systematic in the digest metadata; only redo it if it did not.
    # ``accepted``/``systematic`` are keyed by boundary epoch, since a fit choice
    # the residuals accept at one boundary can be rejected at another.
    if series.scans:
        scans = series.scans
        screened = {sca: (series.accepted[sca].get(boundary, []),
                          series.systematic[sca].get(boundary, float("nan")))
                    for sca in scas}
    else:
        scans = {sca: bridge_sensitivity(series.raw[sca], series.time_hours,
                                         series.segment, spec, degrees, windows,
                                         decon=series.decon_cycles)
                 for sca in scas}
        screened = {
            sca: screen_sensitivity(
                scans[sca],
                boundary_floors(series.raw[sca], series.time_hours,
                                series.segment, boundary),
                boundary_index)
            for sca in scas
        }
    windows = sorted({key[1] for key in next(iter(scans.values()))},
                     key=lambda w: np.inf if w is None else w)
    degrees = sorted({key[0] for key in next(iter(scans.values()))})

    x = np.arange(len(windows))
    labels = ["all" if w is None else f"{w:.0f}" for w in windows]

    def delta(sca, degree, window):
        fit = scans[sca][(degree, window)][boundary_index]
        return np.nan if fit is None else fit.value - adopted[sca]

    fig = _new_figure((13.0, 4.6))
    axes = fig.subplots(1, len(degrees), sharey=True)
    for panel, degree in zip(np.atleast_1d(axes), degrees):
        _style_axes(panel, xlabel="fit window half-width (h)",
                    title=f"degree {degree}")
        panel.axhline(0.0, color=INK_MUTED, linewidth=1.3, zorder=2)
        for sca in scas:
            accepted = set(screened[sca][0])
            deltas = np.array([delta(sca, degree, w) for w in windows])
            # Faint continuous line for context, opaque markers only where the
            # residuals accept the choice: the eye should not average over models
            # that are already known to be wrong.
            panel.plot(x, deltas, color=LED_COLORS[0], linewidth=0.9, alpha=0.18,
                       zorder=3)
            keep = np.array([(degree, w) in accepted for w in windows])
            panel.plot(np.where(keep, x, np.nan), np.where(keep, deltas, np.nan),
                       color=LED_COLORS[0], linestyle="none", marker="o",
                       markersize=3.5, alpha=0.55, zorder=4)
        panel.set_xticks(x)
        panel.set_xticklabels(labels, fontsize=10)

    # Scale to the accepted choices. The rejected corners fail by an order of
    # magnitude, and letting them set the range would squash the spread that the
    # systematic is actually drawn from into a flat line.
    kept = [delta(sca, degree, window) for sca in scas
            for degree, window in screened[sca][0]]
    if kept:
        span = max(np.nanmax(np.abs(kept)), 1e-6)
        np.atleast_1d(axes)[0].set_ylim(-1.6 * span, 1.6 * span)

    first = np.atleast_1d(axes)[0]
    first.set_ylabel("B - adopted B", color=INK_SECONDARY, fontsize=12)

    # An SCA with nothing accepted is a real result, not a value to skip over:
    # it would mean no fit choice describes that SCA to within its own noise.
    unscreened = [sca for sca in scas if not screened[sca][0]]
    spreads = {sca: screened[sca][1] for sca in scas if screened[sca][0]}
    spread = max(spreads.values()) if spreads else float("nan")
    worst = max(spreads, key=spreads.get) if spreads else "none"
    caveat = (f" No fit accepted for {', '.join(unscreened)}." if unscreened else "")
    fig.suptitle(
        f"Bridge sensitivity to the fit choice; each thin line is one SCA, dots "
        f"where the residuals accept the fit (rejected choices run off scale).\n"
        f"Boundary at epoch {boundary + 1}. "
        f"Adopted: degree {spec.degree}, window {spec.window_hours:.0f} h. "
        f"Systematic over accepted choices: {spread:.5f} "
        f"({100 * spread:.3f}%), worst at {worst}.{caveat}",
        color=INK, fontsize=13, x=0.008, ha="left")
    fig.tight_layout(rect=(0, 0, 1, 0.87))
    fig.savefig(out_path, dpi=150, facecolor=SURFACE)
    plt.close(fig)

    return out_path, spread, unscreened


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def plot_side_bridge(series, step, out_path):
    """The step across one MCE side change, and the test that it is SCA-common.

    Three panels, each answering one question:

    1. What is the step? One per LED, with its total error, and each SCA's own
       independent estimate behind it. The TVAC ground table is drawn in the
       same gauge for comparison only; it covers the electronics alone.
    2. Did the swap change the illumination pattern? Each SCA's achromatic
       offset from the common step, against the band noise alone predicts. The
       step is constrained to be SCA-common, so a real pattern change would
       show here rather than being absorbed.
    3. Is the swap gone? The median over SCAs of each LED's response around
       the swap, before (dashed) and after (solid) the side bridge.
    """
    figure = _new_figure((11.0, 12.0))
    top, middle, bottom = figure.subplots(3, 1)
    x = np.arange(len(LED_NAMES))
    total = step.total_error

    for row in range(step.per_sca.shape[0]):
        top.plot(x + 0.12, step.per_sca[row], "o", ms=3, color=INK_MUTED,
                 alpha=0.6, zorder=2,
                 label="per-SCA estimate" if row == 0 else None)
    top.errorbar(x, step.value, yerr=total, fmt="none", ecolor=INK_SECONDARY,
                 elinewidth=1.5, capsize=4, zorder=3)
    for ind in range(len(LED_NAMES)):
        top.plot(x[ind], step.value[ind], "o", ms=9, color=LED_COLORS[ind],
                 zorder=4)
    ground = np.array([1.0 / B_SIDE_CORRECTIONS[led] for led in LED_NAMES])
    top.plot(x - 0.12, ground, "D", ms=7, mfc="none", mec=INK_SECONDARY,
             zorder=3, label="TVAC ground table (electronics only), same gauge")
    top.axhline(1.0, color=INK_MUTED, linewidth=0.8, zorder=1)
    top.set_xticks(x, LED_NAMES)
    _style_axes(top, ylabel="step (multiplies the early side)",
                title=f"MCE side bridge {step.transition} at epoch "
                      f"{step.boundary + 1}: one step per LED, common to "
                      f"{step.n_sca} SCAs")
    top.legend(loc="best", fontsize=8, frameon=False)

    scas = list(step.sca_names)
    offset = np.asarray(step.pattern_offset, dtype=float) * 1e5
    centre = np.nanmean(offset)
    middle.axhspan((centre - 3 * step.pattern_noise * 1e5),
                   (centre + 3 * step.pattern_noise * 1e5),
                   color=GAP_FILL, zorder=1, linewidth=0,
                   label="+-3x the scatter noise alone predicts")
    middle.bar(np.arange(len(scas)), offset - centre, color=INK_SECONDARY,
               zorder=2, width=0.7)
    middle.set_xticks(np.arange(len(scas)),
                      [name.replace("SCA", "") for name in scas])
    ratio = step.pattern_ratio
    _style_axes(middle, xlabel="SCA",
                ylabel="achromatic offset [1e-5]",
                title=f"illumination-pattern test: rms {step.pattern_rms * 1e5:.1f}"
                      f"e-5 vs {step.pattern_noise * 1e5:.1f}e-5 from noise "
                      f"({ratio:.2f}x)")
    middle.legend(loc="best", fontsize=8, frameon=False)

    window = np.abs(series.time_hours - step.boundary_time) <= max(
        step.window_hours, 1.0)
    hours = series.time_hours[window] - step.boundary_time
    before = np.nanmedian(np.stack(
        [series.raw[sca] * series.factors[sca][:, None]
         for sca in sorted_scas(series.raw)]), axis=0)[window]
    after = np.nanmedian(np.stack(
        [series.response(sca) for sca in sorted_scas(series.raw)]), axis=0)[window]
    for ind, led in enumerate(LED_NAMES):
        bottom.plot(hours, before[:, ind] / before[0, ind], "--", lw=1.2,
                    color=LED_COLORS[ind], alpha=0.7)
        bottom.plot(hours, after[:, ind] / after[0, ind], "-o", lw=2.0, ms=4,
                    color=LED_COLORS[ind], label=led)
    bottom.axvline(0.0, color=INK_MUTED, linewidth=1.0, linestyle=":")
    _style_axes(bottom, xlabel="hours from the swap",
                ylabel="response / first epoch shown",
                title="median over SCAs: dashed = before the side bridge, "
                      "solid = after")
    bottom.legend(loc="best", fontsize=8, ncol=3, frameon=False)

    figure.tight_layout()
    figure.savefig(out_path, dpi=150, facecolor=SURFACE)
    plt.close(figure)
    return out_path


def _label_runs(values):
    """Contiguous runs of equal labels, as ``[(label, first, last), ...]``."""
    runs = []
    for index, value in enumerate(values):
        if runs and runs[-1][0] == value:
            runs[-1][2] = index
        else:
            runs.append([value, index, index])
    return [(label, first, last) for label, first, last in runs]


def _draw_calibration_band(axis, hours, series, y_centre=0.195, height=0.27,
                           label_offset=-0.30, step_offset=-0.12):
    """Bands of epochs sharing one L2 calibration, on an existing structure axis.

    Draws nothing but a note when the products record no provenance, which is
    the state of every product built before ``rcs_l2_source`` existed. An empty
    band would read as "one calibration throughout"; the note says the opposite,
    that the question was not asked.

    The geometry keywords exist so :func:`plot_calibration_timeline` can place
    this same band at a different height without duplicating any of the three
    behaviours that matter here -- the unrecorded note, the
    stable-by-first-appearance fill, and the leader line for a single-epoch
    family.  The defaults are the position this band occupies in
    :func:`plot_run_structure`, so that caller passes nothing.  Both callers set
    ``ylim`` to ``(0, 1)``, which is what lets the ``axvline`` extent be derived
    from ``y_centre``/``height`` in the same units.  ``label_offset`` and
    ``step_offset`` are below-axis text positions and so depend on what else the
    host axis has room for; they are not derived.
    """
    bottom = y_centre - 0.5 * height
    top = y_centre + 0.5 * height

    families = list(getattr(series, "calibration_families", ()) or [])
    recorded = [f for f in families if f.get("key") is not None]
    if not recorded:
        axis.text(hours.min(), y_centre,
                  "  not recorded in these products -- an upstream "
                  "reference-file change would be invisible",
                  ha="left", va="center", fontsize=7.5, style="italic",
                  color=INK_MUTED)
        return

    # One fill per equivalence class, assigned in order of first appearance so
    # the earliest family is always the lightest -- stable across runs, unlike
    # a dict iteration order.
    classes = []
    for family in recorded:
        if family["klass"] not in classes:
            classes.append(family["klass"])

    for family in families:
        first, last = family["first"], family["last"]
        span = hours[last] - hours[first]
        if family["key"] is None:
            axis.add_patch(plt.Rectangle(
                (hours[first], bottom), span, height, facecolor=SURFACE,
                edgecolor=INK_MUTED, linewidth=0.6, hatch="///"))
            label = f"unrecorded\n{family['n']} epochs"
            # Hatching runs straight through the glyphs, and this is the label
            # a reader most needs to be able to read -- it is the one saying
            # the set cannot be checked.
            label_bbox = dict(facecolor="white", edgecolor="none",
                              alpha=0.85, pad=1.5)
        else:
            index = classes.index(family["klass"])
            axis.add_patch(plt.Rectangle(
                (hours[first], bottom), span, height,
                facecolor=plt.cm.Greens(0.20 + 0.20 * (index % 4)),
                edgecolor="white", linewidth=0.8))
            context = family["ref_file_id"][:8]
            origin = family["source"] or "mast"
            label = (f"{family['klass']}\n{origin} {context}\n"
                     f"{family['n']} epochs")
            label_bbox = None
        # A span of one epoch is zero hours wide, so the label would sit on a
        # patch with no area. Annotate it outside instead of letting it
        # disappear, because a single-epoch family is the interesting case --
        # it is a pass that was reprocessed alone.
        if span <= 0:
            axis.annotate(label, xy=(hours[first], y_centre),
                          xytext=(hours[first], label_offset),
                          textcoords="data", ha="center", va="top",
                          fontsize=6.5, color=INK_SECONDARY,
                          arrowprops=dict(arrowstyle="-", color=INK_MUTED,
                                          linewidth=0.6),
                          annotation_clip=False)
            axis.plot([hours[first]], [y_centre], "|", color=INK, ms=10,
                      zorder=4)
        else:
            axis.text(0.5 * (hours[first] + hours[last]), y_centre, label,
                      ha="center", va="center", fontsize=7, color=INK,
                      bbox=label_bbox)

    # The heavy rules: every point where the equivalence class changes, which
    # is every point at which a per-SCA achromatic step enters the trend.
    for earlier, later in zip(recorded, recorded[1:]):
        if earlier["klass"] == later["klass"]:
            continue
        edge = hours[later["first"]]
        axis.axvline(edge, bottom - 0.04, top + 0.04, color="#eb6834",
                     linewidth=1.8, zorder=5)
        axis.annotate("flux step", xy=(edge, bottom - 0.015),
                      xytext=(edge, step_offset),
                      textcoords="data", ha="center", va="top", fontsize=7,
                      color="#eb6834", annotation_clip=False)


def plot_run_structure(series, out_path):
    """Why each ACM boundary was measured or modelled, against the run's episodes.

    The bridge's per-boundary choice is recorded in the digest metadata as a
    one-word ``bridge_method``, which is not enough to tell whether a
    ``multiplier`` was a reasonable call or a missed opportunity. The answer is
    almost always structural: an ACM move too close to a decon transition, or
    too close to a cadence gap, has no epochs to fit from.

    So this draws the two kinds of boundary on one axis and distinguishes them,
    because they are not the same kind of thing:

    * an **ACM segment boundary** is a step the bridge tries to *measure*;
    * a **decon transition** is a film reset the bridge must not fit across,
      and which therefore *removes* epochs from a nearby boundary's window.

    Returns ``(path, worst_closure_departure)``; the closure departure is NaN
    when no two segments share an LVDT, which is the honest value -- the test is
    unavailable, not passed.
    """
    boundaries = segment_boundaries(series.segment)
    scas = sorted_scas(series.raw)
    hours = np.asarray(series.time_hours)

    figure, axes = plt.subplots(
        2, 1, figsize=(13, 8.4), sharex=True,
        gridspec_kw={"height_ratios": (1.0, 1.5), "hspace": 0.12})
    figure.patch.set_facecolor(SURFACE)

    # --- top: the run's structure as two independent bands --------------
    structure = axes[0]
    structure.set_facecolor(SURFACE)
    for segment_id, first, last in _label_runs(list(series.segment)):
        structure.add_patch(plt.Rectangle(
            (hours[first], 0.70), hours[last] - hours[first], 0.27,
            facecolor=plt.cm.Blues(0.25 + 0.16 * (segment_id % 4)),
            edgecolor="none"))
        structure.text(0.5 * (hours[first] + hours[last]), 0.835,
                       f"ACM segment {segment_id}\n{last - first + 1} epochs",
                       ha="center", va="center", fontsize=8, color=INK)

    # One patch per film-growth *episode*, from the shared helper rather than a
    # grouping spelled out here: an episode is a contiguous run, so a decon
    # label that recurs later opens a new band rather than extending the old
    # one. Drawing it any other way would merge two different films into one
    # patch and hide the reset between them.
    for index, episode in enumerate(decon_episodes(series.decon_cycles)):
        first, last = episode["first"], episode["last"]
        structure.add_patch(plt.Rectangle(
            (hours[first], 0.385), hours[last] - hours[first], 0.27,
            facecolor=plt.cm.Reds(0.22 + 0.18 * index), edgecolor="none"))
        structure.text(0.5 * (hours[first] + hours[last]), 0.52,
                       f"{episode['key'] or 'unlabelled'}\n"
                       f"{episode['n']} epochs",
                       ha="center", va="center", fontsize=8, color=INK)

    # The third band is a different kind of claim from the two above it. ACM
    # segments and decon episodes are things the instrument did; an L2
    # calibration family is a thing the *ground system* did, upstream of every
    # correction in this pipeline, and it enters the trend as a per-SCA
    # multiplicative step that none of them removes. It is drawn here, on the
    # same axis, precisely because the 0067->0072 changeover landed one epoch
    # after an ACM move and exactly at a decon label change -- three bands
    # whose edges nearly coincide, which is why the step read as physics for as
    # long as it did.
    #
    # Fill encodes the *equivalence class*, not the configuration: two
    # configurations measured to produce identical pixels get the same fill and
    # a thin divider, and only a class change gets the heavy rule, because only
    # a class change is a step.
    _draw_calibration_band(structure, hours, series)

    # The gaps between the bands are the point: a white stripe in the decon row
    # is a stretch with no epochs, which is where the film reset happened and
    # where a boundary has nothing to fit.
    structure.set_xlim(hours.min() - 8, hours.max() + 8)
    structure.set_ylim(0, 1)
    structure.set_yticks([0.195, 0.52, 0.835])
    structure.set_yticklabels(["L2\ncalibration", "decon\nepisode",
                               "ACM\nsegment"], fontsize=8,
                              color=INK_SECONDARY)
    for spine in structure.spines.values():
        spine.set_visible(False)
    structure.tick_params(length=0)
    structure.set_title(
        "run structure: the bridge measures across ACM boundaries, and refuses "
        "to fit across decon transitions",
        fontsize=9.5, color=INK_SECONDARY, loc="left")

    # --- bottom: per-boundary step values, by method --------------------
    detail = axes[1]
    _style_axes(detail, xlabel=f"hours since {series.names[0]}",
                ylabel="bridge step (early x step = late)")

    legended = set()
    for index, boundary in enumerate(boundaries):
        steps = [series.steps[sca][index] for sca in scas
                 if len(series.steps.get(sca, ())) > index]
        if not steps:
            continue
        values = np.array([step.value for step in steps])
        methods = {step.method for step in steps}
        time = steps[0].boundary_time
        # A boundary is one method for all 18 SCAs in every case seen so far,
        # but it does not have to be -- a sparse SCA can fall back alone -- so
        # the marker is driven by the set, not by the first SCA.
        method = "/".join(sorted(methods))
        style = {"bridge": ("o", "#1baf7a"), "multiplier": ("s", "#eda100"),
                 "none": ("x", INK_MUTED)}.get(method, ("D", "#eb6834"))
        marker, color = style
        label = method if method not in legended else None
        legended.add(method)
        detail.plot(np.full(len(values), time), values, marker, color=color,
                    ms=MARKER_SIZE, mfc="none" if marker == "s" else color,
                    label=label, zorder=3)

        # A modelled step has no independent per-LED estimates, so its spread is
        # NaN by construction rather than small; printing "nan" invites it to be
        # read as a missing measurement, so the line is simply omitted.
        spread = max(step.led_spread for step in steps)
        spread_line = f"\nper-LED spread {spread:.4f}" if np.isfinite(spread) else ""
        note = steps[0].note
        # The note is where the refusal reason lives -- it is the message the
        # fitter raised -- so it is quoted rather than summarised.
        reason = ""
        if note:
            reason = "\n" + "\n".join(_wrap(note, 46))
        detail.annotate(
            f"boundary {index + 1} @ epoch {boundary + 1}\n"
            f"{method}, {values.mean():.5f}{spread_line}{reason}",
            xy=(time, values.mean()),
            xytext=(6, -14 if index % 2 else 14), textcoords="offset points",
            fontsize=6.6, color=INK_SECONDARY, va="center",
            bbox=dict(boxstyle="round,pad=0.3", fc=GAP_FILL, ec=GRID, lw=0.6))

    # Only a transition between two *labelled* cycles is enforced: an epoch
    # whose cycle was never recorded is not known to be from a different one,
    # so the guard lets it through. Drawing both the same way would claim a
    # constraint the fitter does not apply.
    raw_runs = _label_runs(list(series.decon_cycles))
    for (before, _, _), (_, first, _) in zip(raw_runs, raw_runs[1:]):
        after = series.decon_cycles[first]
        enforced = bool(before) and bool(after)
        detail.axvline(
            0.5 * (hours[first - 1] + hours[first]),
            color="#d62728" if enforced else INK_MUTED,
            lw=1.4 if enforced else 1.0,
            ls="-" if enforced else ":",
            alpha=0.65, zorder=1,
            label=("decon transition (bridge refuses to cross)" if enforced
                   else "label change, one side unlabelled (not enforced)"))
    detail.axhline(1.0, color=INK_MUTED, lw=1.0, zorder=1)

    closure = closure_residuals(series.acm_lvdt, series.segment,
                                series.steps[scas[0]]) if scas else []
    worst = float("nan")
    if closure:
        departures = []
        for early, late, _, _, _ in closure:
            products = [np.prod([series.steps[sca][seg].value
                                 for seg in range(early, late)])
                        for sca in scas]
            departures.extend(abs(np.asarray(products) - 1.0))
        worst = float(np.max(departures))
        pairs = ", ".join(f"{early}&{late}" for early, late, _, _, _ in closure)
        verdict = (f"CLOSURE: segment pair(s) {pairs} share an LVDT, so the "
                   f"composed bridge must read 1.0 -- worst departure "
                   f"{100 * worst:.3f}%")
        # How much of a test this is depends on how many of the composed steps
        # were measured, and the three cases are genuinely different: all
        # modelled closes by construction and is arithmetic; all fitted is a
        # clean test of the geometric-ACM assumption; mixed tests only the
        # fitted factors, with the modelled ones along for the ride.
        composed = [series.steps[scas[0]][seg]
                    for early, late, _, _, _ in closure
                    for seg in range(early, late)]
        n_fitted = sum(step.is_fitted for step in composed)
        if n_fitted == 0:
            verdict += ("\n(NOT a test: every composed step came from the "
                        "shared linear gauge, so it closes by construction)")
        elif n_fitted < len(composed):
            verdict += (f"\n(partial test: {n_fitted} of {len(composed)} "
                        "composed steps were fitted; the modelled one(s) "
                        "cannot fail this check)")
    else:
        verdict = ("CLOSURE: unavailable -- no two ACM segments sit at the same "
                   "LVDT in this set")
    detail.set_title(verdict, fontsize=8.5, color=INK, loc="left")
    detail.legend(fontsize=8, loc="best", frameon=True)

    n_unlabelled = sum(1 for cycle in series.decon_cycles if not cycle)
    labelled = len({c for c in series.decon_cycles if c})
    figure.suptitle(
        f"{len(series.names)} epochs, {len(set(series.segment.tolist()))} ACM "
        f"segment(s), {labelled} labelled decon cycle(s)"
        + (f" + {n_unlabelled} unlabelled epoch(s)" if n_unlabelled else "")
        + f", {len(boundaries)} boundary/ies",
        fontsize=11, color=INK)
    # subplots_adjust, not tight_layout: the structure axis is drawn from
    # patches rather than data, which tight_layout cannot size and warns about.
    figure.subplots_adjust(left=0.085, right=0.985, top=0.905, bottom=0.075)
    figure.savefig(out_path, dpi=140, facecolor=SURFACE)
    plt.close(figure)
    return Path(out_path), worst


def _audit_families(rows, hours):
    """Contiguous runs of one audited L2 configuration, as drawable families.

    Run-length encodes over the whole configuration tuple, not just the
    equivalence class, so a CRDS context bump that changed nothing still shows
    as a divider -- the figure's job is to show what the ground system did, and
    "it was relabelled but the pixels are identical" is a finding, not noise.
    An epoch the audit does not cover breaks a run: a gap in the evidence is
    not something to interpolate across.
    """
    keys = ("calibration_class", "ref_file_id", "crds_context", "cal_version",
            "cal_step_photom", "cal_step_flat_field")
    families = []
    for index, row in enumerate(rows):
        key = None if row is None else tuple(
            str(row.get(name, "") or "") for name in keys)
        # Plain equality, so a run of un-audited epochs coalesces into one
        # hatched family (``None == None``) rather than one zero-width patch
        # each -- while a gap still breaks a real run, since no tuple equals
        # ``None``. Drawn per-epoch it reads as a rendering fault instead of
        # as the hole in the evidence that it is.
        if families and families[-1]["key"] == key:
            families[-1]["last"] = index
            families[-1]["n"] += 1
            continue
        families.append({
            "key": key, "first": index, "last": index, "n": 1,
            "row": row or {},
            "klass": "" if row is None else str(
                row.get("calibration_class", "") or "?"),
        })
    return families


def plot_calibration_timeline(series, out_path, audit=None):
    """Two independent accounts of how this set's L2 inputs were calibrated.

    The question this answers is "did the ground system change the flux scale
    under us, and when" -- which ``run_structure.png`` only hints at, in one
    band among three.  A change here is upstream of every correction in this
    pipeline and none of them removes it, so it enters the trend as a per-SCA
    achromatic step that reads exactly like physics.

    Two bands, deliberately **not** reconciled into one, because the gap between
    them is itself the finding:

    * the **upper** band is the audit (``l2_calibration_audit.ecsv``), which
      covers every epoch but whose MAST rows were read from a frame streamed
      *later* -- so it describes what the archive serves now;
    * the **lower** band is what the products themselves recorded at staging
      time, which is contemporaneous but incomplete.

    The hatched stretch in the lower band is therefore the extent to which this
    set's calibration is attested by a later query rather than by the evidence
    it was built from.

    The upper band's fill keys on ``calibration_class``, not on
    ``ref_file_id``.  On the flight set the aux rows carry a superseded hash
    (they were read from products written before the hash definition was fixed)
    while the streamed rows carry the current one, and both resolve to the same
    class -- so keying on the raw id would paint two colours over epochs that
    are calibrated bit-identically.  A configuration change still gets a thin
    divider; only a *class* change gets the heavy rule, because only a class
    change is a step in the data.

    Returns ``(path, n_audit_classes, uncovered)``.  ``n_audit_classes`` is the
    same quantity ``assert_homogeneous_calibration`` refuses on, so the figure
    and the guard agree or one of them is broken.
    """
    hours = np.asarray(series.time_hours, dtype=float)
    names = list(series.names)
    rows, meta, uncovered = (audit if audit is not None
                             else (None, {}, list(names)))

    figure, axes = plt.subplots(
        2, 1, figsize=(13, 6.2),
        gridspec_kw={"height_ratios": (1.0, 0.62), "hspace": 0.34})
    figure.patch.set_facecolor(SURFACE)
    band, detail = axes
    band.set_facecolor(SURFACE)
    total_span = max(float(hours.max() - hours.min()), 1e-9)

    # --- upper band: the audit -------------------------------------------
    families = []
    if rows is None:
        band.text(hours.min(), 0.70,
                  "  no calibration audit supplied (--l2-audit) -- only what "
                  "the products themselves recorded is shown below",
                  ha="left", va="center", fontsize=8, style="italic",
                  color=INK_MUTED)
    else:
        families = _audit_families(rows, hours)
        classes = []
        for family in families:
            if family["key"] is not None and family["klass"] not in classes:
                classes.append(family["klass"])

        for family in families:
            first, last = family["first"], family["last"]
            span = hours[last] - hours[first]
            if family["key"] is None:
                band.add_patch(plt.Rectangle(
                    (hours[first], 0.565), max(span, 0.0), 0.27,
                    facecolor=SURFACE, edgecolor=INK_MUTED, linewidth=0.6,
                    hatch="\\\\\\"))
                label = f"not audited\n{family['n']} epochs"
                bbox = dict(facecolor="white", edgecolor="none", alpha=0.85,
                            pad=1.5)
            else:
                index = classes.index(family["klass"])
                band.add_patch(plt.Rectangle(
                    (hours[first], 0.565), max(span, 0.0), 0.27,
                    facecolor=plt.cm.Purples(0.18 + 0.20 * (index % 4)),
                    edgecolor="white", linewidth=0.8))
                row = family["row"]
                label = (f"{family['klass']}\n"
                         f"{row.get('crds_context') or 'context n/r'}\n"
                         f"{family['n']} epochs")
                bbox = None
            # A family too narrow to hold its own label gets a leader line
            # above the band instead. On the flight set the last family is two
            # epochs out of 176, and a centred label there both overflows the
            # axis and reads as belonging to the 139-epoch family beside it --
            # which is the opposite of what a short family is telling you.
            if span <= 0.06 * total_span:
                band.annotate(label, xy=(0.5 * (hours[first] + hours[last]),
                                         0.84),
                              xytext=(0.5 * (hours[first] + hours[last]),
                                      1.10),
                              textcoords="data", ha="center", va="bottom",
                              fontsize=6.5, color=INK_SECONDARY,
                              arrowprops=dict(arrowstyle="-", color=INK_MUTED,
                                              linewidth=0.6),
                              annotation_clip=False)
                if span <= 0:
                    band.plot([hours[first]], [0.70], "|", color=INK, ms=10,
                              zorder=4)
            else:
                band.text(0.5 * (hours[first] + hours[last]), 0.70, label,
                          ha="center", va="center", fontsize=7.5, color=INK,
                          bbox=bbox)

        # A thin divider at every configuration change, a heavy rule only
        # where the equivalence class changes. The distinction is the whole
        # point of the figure: the first is bookkeeping, the second is a step.
        for earlier, later in zip(families, families[1:]):
            edge = hours[later["first"]]
            if (earlier["key"] is not None and later["key"] is not None
                    and earlier["klass"] != later["klass"]):
                band.axvline(edge, 0.52, 0.88, color="#eb6834",
                             linewidth=1.8, zorder=5)
                band.annotate("flux step", xy=(edge, 0.55),
                              xytext=(edge, 1.10), textcoords="data",
                              ha="center", va="bottom", fontsize=7,
                              color="#eb6834", annotation_clip=False)
            else:
                band.axvline(edge, 0.54, 0.86, color=INK_MUTED,
                             linewidth=0.9, linestyle=":", zorder=5)

    # --- lower band: what the products recorded --------------------------
    # The same helper plot_run_structure uses, so the unrecorded note, the
    # stable fill and the single-epoch leader line cannot diverge between the
    # two figures.
    _draw_calibration_band(band, hours, series, y_centre=0.235, height=0.27,
                           label_offset=-0.10, step_offset=-0.02)

    band.set_xlim(hours.min() - 0.02 * total_span,
                  hours.max() + 0.02 * total_span)
    band.set_ylim(0, 1)
    band.set_yticks([0.235, 0.70])
    band.set_yticklabels(["recorded in\nthe products", "audited\n(streamed)"],
                         fontsize=8, color=INK_SECONDARY)
    for spine in band.spines.values():
        spine.set_visible(False)
    band.tick_params(length=0)
    band.set_xlabel("hours since reference epoch", fontsize=8.5,
                    color=INK_SECONDARY)

    n_classes = len({f["klass"] for f in families if f["key"] is not None})
    band.set_title(
        "L2 calibration against time: a change here is upstream of every "
        "correction in this pipeline",
        fontsize=9.5, color=INK_SECONDARY, loc="left")

    # --- detail panel ----------------------------------------------------
    detail.set_facecolor(SURFACE)
    detail.axis("off")
    lines = [f"{'epochs':>12}  {'n':>4}  {'from':<9}  {'cal':<9}  "
             f"{'CRDS context':<18}  {'photom':<9}  {'flat':<9}  "
             f"{'ref_file_id':<17}  class"]
    for family in families:
        row = family["row"]
        span = f"{family['first'] + 1}-{family['last'] + 1}"
        if family["key"] is None:
            lines.append(f"{span:>12}  {family['n']:>4}  "
                         f"{'(not in the audit)':<9}")
            continue
        lines.append(
            f"{span:>12}  {family['n']:>4}  "
            f"{str(row.get('provenance_from') or '?'):<9}  "
            f"{str(row.get('cal_version') or '?'):<9}  "
            f"{str(row.get('crds_context') or '?'):<18}  "
            f"{str(row.get('cal_step_photom') or '?'):<9}  "
            f"{str(row.get('cal_step_flat_field') or 'not in audit'):<9}  "
            f"{str(row.get('ref_file_id') or '?')[:16]:<17}  "
            f"{family['klass']}")
    if not families:
        lines.append("  (no audit rows)")

    detail.text(0.0, 1.0, "\n".join(lines), ha="left", va="top",
                fontsize=7.2, family="monospace", color=INK,
                transform=detail.transAxes)

    # The caveat is always drawn, including when it is reassuring: it is the
    # limitation of the band above it, and a reader who does not know the MAST
    # rows were streamed later cannot judge what "audited" is worth.
    footnote = meta.get("description", "") if rows is not None else (
        "No audit supplied: the unrecorded span above is unverified, not clean.")
    # Anchored to the bottom of the panel rather than offset below the table:
    # the table's height depends on how many configurations the set has, so any
    # computed offset overlaps it for some input, and this panel is the one
    # that has to stay readable.
    detail.text(0.0, 0.0, "\n".join(_wrap(str(footnote), 160)),
                ha="left", va="bottom", fontsize=7, style="italic",
                color=INK_MUTED, transform=detail.transAxes)

    covered = len(names) - len(uncovered)
    figure.suptitle(
        f"{len(names)} epochs, {len(families)} audited L2 configuration(s), "
        f"{n_classes} equivalence class(es), {covered}/{len(names)} audited",
        fontsize=11, color=INK)
    # subplots_adjust, not tight_layout: these bands are patches, which
    # tight_layout cannot size and warns about.
    figure.subplots_adjust(left=0.105, right=0.985, top=0.885, bottom=0.05)
    figure.savefig(out_path, dpi=140, facecolor=SURFACE)
    plt.close(figure)
    return Path(out_path), n_classes, list(uncovered)


def decon_evidence(series):
    """Test the per-epoch decon labels against the response itself.

    The bridge now refuses to fit across a decon transition, so the
    ``decon_cycle`` labels have become load-bearing: a decon that happened but
    was never annotated is a film reset the fitter will cheerfully absorb into
    an ACM step.  The labels come from the staging CLI, not from the data, so
    they need an independent check -- and the data supplies one, because the two
    effects have different colour:

    * a **decon** removes the film, so the interference thickness resets.  The
      response change is strongly **chromatic**: each LED sits at a different
      point in the fringe.
    * an **ACM move** changes the source-to-focal-plane distance, which is
      geometric and therefore **achromatic** -- it is the same factor for all
      six LEDs, and so contributes nothing to the spread across them.

    So the discriminator is the scatter of the per-LED log step across the six
    LEDs, which an achromatic step leaves untouched by construction.

    Film growth is chromatic too, so the step has to be judged against how much
    growth the elapsed gap allows.  Dividing by the gap is the obvious way and
    it is **wrong**: a decon is an instantaneous reset, so its signature does
    not scale with elapsed time, and dividing suppresses exactly the thing being
    looked for.  Measured: the same decon reads 0.00141/h across the flight
    set's 38.4 h gap but only 0.00075/h across the legacy set's 63.6 h gap, and
    the second falls *below* the detection floor.  So instead the gap dependence
    of ordinary growth is fitted, as a power law in log-log with high outliers
    trimmed one-sidedly (a reset must not be allowed to define the baseline it
    is being compared against), and the statistic is the ratio of the observed
    step to that prediction.

    The prediction is ``sqrt(noise^2 + (a * gap^p)^2)``, not the bare power law:
    measurement noise does not scale with the gap, so a growth-only model
    under-predicts the shortest steps and reports them as resets.  Both extra
    pieces are needed and each was arrived at by a failure:

    * the noise term is estimated from the gaps where noise is still at least a
      tenth of the step in quadrature, and from the **untrimmed** set.  Masking
      that pool by the one-sided trim is self-reinforcing -- short steps ride
      high against a growth-only model, so the trim removes exactly the points
      that measure the noise, and the fit converges on having no noise term.
    * the 5-sigma floor is calibrated on the **noisiest** of the two gap
      regimes, because the ratio's own scatter depends on the gap.  Where growth
      dominates, the 18 SCAs see one film and the ratio is tight (2.5 % on the
      synthetic); where noise dominates it is a std over six LEDs and four times
      looser.  One floor fitted to the many quiet long gaps is far too tight for
      the few short ones.  This costs real power (the flight margin goes 2.2x ->
      1.9x) and that is the right trade: a false positive here sends the
      operator to doubt a decon label that is in fact correct.

    Returns ``(hours, ratio, chromatic, achromatic, floor, suspects, power)``.
    ``power`` is the detectability diagnostic and is the part worth reading:
    ``(slope, worst_gap, worst_hideable)``, where ``worst_hideable`` is the
    largest chromatic step that could sit below the floor anywhere in the run.
    A reset smaller than that is invisible to this test *at that cadence*.

    **The test loses power quickly as the cadence gap grows, and that is
    physical, not a defect in the statistic.** A spread across six LEDs
    saturates: once a reset has scrambled the fringe phase the six land
    effectively at random, so a reset cannot read arbitrarily loud, while
    predicted growth keeps rising with the gap.  At a 38 h gap the measured
    decon stands 6.5x above predicted growth; at 63.6 h, only 2.2x.  Hence the
    test confirms the labels on the dense flight set -- the set the bridge guard
    actually runs on -- and is **underpowered on sparse sets**, which is why
    ``power`` is returned rather than a bare pass/fail.
    """
    scas = sorted_scas(series.raw)
    chromatic, achromatic = [], []
    for sca in scas:
        step = np.diff(np.log(np.asarray(series.raw[sca], dtype=float)), axis=0)
        chromatic.append(np.nanstd(step, axis=1))
        achromatic.append(np.nanmean(step, axis=1))
    # Median over SCAs, not mean: a single SCA with a bad epoch should not set
    # the focal-plane answer, and 18 SCAs see the same film.
    chromatic = np.nanmedian(np.asarray(chromatic), axis=0)
    achromatic = np.nanmedian(np.asarray(achromatic), axis=0)

    hours = np.asarray(series.time_hours, dtype=float)
    gap = np.diff(hours)

    # A step is "labelled" when the two epochs it joins carry different known
    # cycles. Unknown is not known-different -- the same rule the fitter uses,
    # so the figure cannot claim a transition the guard does not enforce.
    cycles = list(series.decon_cycles)
    labelled = np.array([bool(cycles[i]) and bool(cycles[i + 1])
                         and cycles[i] != cycles[i + 1]
                         for i in range(len(gap))])

    usable = np.isfinite(chromatic) & (chromatic > 0) & (gap > 0)
    if usable.sum() < 4:
        # Too few steps to fit a trend, let alone a scatter about one. Returning
        # a NaN floor makes every step un-flaggable, which is the right answer:
        # the test is unavailable, not passed.
        nan = np.full(len(gap), np.nan)
        return hours, nan, chromatic, achromatic, np.nan, [], (np.nan,) * 3

    logs = np.log(gap[usable])
    logc = np.log(chromatic[usable])
    # A run at uniform cadence gives log(gap) no spread, so the exponent is
    # unconstrained: polyfit would return a meaningless slope (-1.46 on a
    # synthetic 10 h-cadence set) behind a RankWarning. Degree 0 is the honest
    # model there -- with one gap there is nothing to extrapolate to, and the
    # ratio reduces to "this step against the typical step", which is exactly
    # the right comparison when every gap is the same.
    degree = 1 if np.ptp(logs) > 1e-6 else 0

    # The model is pred^2 = noise^2 + (a * gap^p)^2, not a bare power law.
    # Measurement noise does not scale with the gap, so a pure power law
    # systematically under-predicts the shortest steps and they ride high: on a
    # 40-epoch synthetic with three gaps under 5 h, those three -- and only
    # those three -- were flagged as resets at 1.03-1.29x the floor. The flight
    # set hid this, because 114 of its 167 steps sit at the same 0.4 h cadence
    # and so set the scatter themselves rather than standing out against it.
    # The exponent is fitted on the LONGER half of the gaps only. Fitting it to
    # every step and then solving for the noise term does not work: starting
    # from noise = 0 the growth term absorbs the whole step, the residual is
    # ~0, and the iteration has a fixed point at noise = 0 that it can never
    # leave. Long gaps are growth-dominated, so they pin the exponent cleanly.
    squared = chromatic[usable] ** 2
    short = logs <= np.median(logs)
    long_enough = (~short) & ~labelled[usable]
    if long_enough.sum() < degree + 2:
        long_enough = ~labelled[usable]
    # Which gaps carry information about the noise is not known in advance, so
    # it is solved for alongside it. A fixed fraction does not work: a quartile
    # of this synthetic reaches 10 h, where noise is 3 % of the step in
    # quadrature but the growth fit's own scatter is 10 %, so the excess there
    # is mostly fit error of either sign and the median of it came out 40 % low.
    # Starting pool is the sparsest quartile, then narrowed to the gaps where
    # the noise is still at least a tenth of the predicted step in quadrature
    # (growth <= 3 * noise). Measured on the synthetic: the quartile gives
    # 1.63e-7, the narrowed pool 2.65-2.80e-7, and the truth is 2.8e-7.
    order = np.argsort(logs)
    unlabelled = ~labelled[usable]
    shortest = np.zeros(len(logs), dtype=bool)
    shortest[order[:max(3, int(round(0.25 * len(logs))))]] = True
    sensitive = shortest

    keep = unlabelled.copy()
    for _ in range(6):
        fitting = long_enough & keep
        if fitting.sum() < degree + 2:
            fitting = long_enough
        coef = np.polyfit(logs[fitting], logc[fitting], degree)
        growth = np.exp(np.polyval(coef, logs))
        # Now the noise term is whatever the extrapolated growth leaves over at
        # the shortest gaps, where growth is smallest and the noise shows.
        #
        # Note what this pool is NOT masked by: `keep`. The one-sided trim below
        # is there to keep resets out of the *scatter*, but short-gap steps are
        # noise-dominated and therefore ride high against any growth-only model,
        # so the trim removes exactly the points that measure the noise. Letting
        # it do so is self-reinforcing and was the actual bug: the pool went
        # 10 -> 3 -> 2 points while noise_sq slid 1.63e-7 -> 1.01e-7, i.e. the
        # model converged on having no noise term at all. The median is robust
        # enough on its own here -- a single reset among three or more short
        # steps does not move it -- and labelled transitions are excluded.
        quiet_short = sensitive & unlabelled
        if not quiet_short.any():
            quiet_short = shortest
        excess = float(np.median(squared[quiet_short]
                                 - growth[quiet_short] ** 2))
        noise_sq = max(excess, 0.0)
        sensitive = growth ** 2 <= 9 * noise_sq
        if (sensitive & unlabelled).sum() < 3:
            sensitive = shortest
        predicted_u = np.sqrt(noise_sq + growth ** 2)
        residual = logc - np.log(predicted_u)
        centre = np.median(residual[keep])
        scatter = 1.4826 * np.median(np.abs(residual[keep] - centre))
        # One-sided: only steps *louder* than the trend are candidate resets, so
        # only those are trimmed. Trimming quiet steps too would inflate the
        # scatter with the very points that constrain it.
        updated = (residual < centre + 3 * scatter) & unlabelled
        if updated.sum() >= degree + 2:
            keep = updated

    predicted = np.full(len(gap), np.nan)
    predicted[usable] = predicted_u
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio = chromatic / predicted

    # The ratio's own scatter depends on the gap, and ignoring that is the whole
    # false-positive mechanism. Where growth dominates, chromatic is nearly
    # deterministic -- the 18 SCAs see one film -- so the ratio is tight (2.5 %
    # on the synthetic); where noise dominates it is a std over 6 LEDs and the
    # ratio is four times looser. A floor calibrated on the many quiet long gaps
    # is therefore far too tight for the few short ones, which is exactly where
    # the earlier version invented resets at 1.03-1.29x the floor.
    #
    # The floor is set by the *noisiest* regime the test is applied to. That
    # costs real power at the long gaps, deliberately: a false positive here
    # means telling the operator to go doubt a decon label that is in fact
    # right, and the power actually retained is reported rather than assumed.
    quiet = ratio[usable][keep]
    centre = np.median(quiet)
    scatters = [1.4826 * np.median(np.abs(quiet[regime[keep]] - centre))
                for regime in (short, ~short) if regime[keep].sum() >= 3]
    floor = centre + 5 * (max(scatters) if scatters else
                          1.4826 * np.median(np.abs(quiet - centre)))
    suspects = [index for index in range(len(gap))
                if not labelled[index] and np.isfinite(ratio[index])
                and ratio[index] > floor]

    # The blind spot, stated in the same units as the data: at the run's
    # sparsest step, a reset smaller than floor*predicted hides completely.
    hideable = floor * predicted
    worst = int(np.nanargmax(hideable))
    power = (coef[0] if degree else 0.0, gap[worst], hideable[worst])
    return hours, ratio, chromatic, achromatic, floor, suspects, power


def plot_decon_evidence(series, out_path):
    """Draw :func:`decon_evidence`; returns ``(path, suspects, margin)``.

    ``margin`` is the weakest labelled decon's ratio divided by the detection
    floor -- how much weaker a decon could have been and still been caught.  It
    is NaN when the run has no labelled transition, which is the honest value:
    with nothing to calibrate against, the figure can show the quiet level but
    cannot say what a decon would have looked like.  A margin below 1 means the
    test does not even recover the decon that *is* labelled, and the figure says
    so rather than reporting a clean sheet.
    """
    (hours, ratio, chromatic, achromatic, floor,
     suspects, power) = decon_evidence(series)
    slope, worst_gap, worst_hideable = power
    cycles = list(series.decon_cycles)
    labelled = [i for i in range(len(hours) - 1)
                if cycles[i] and cycles[i + 1] and cycles[i] != cycles[i + 1]]
    mid = 0.5 * (hours[:-1] + hours[1:])

    # Deliberately NOT sharex: the top panel's x is time, the bottom panel's is
    # the achromatic part of the step. Sharing them squashes the scatter onto
    # x=0 and labels it with hours, which is worse than useless.
    figure, (top, bottom) = plt.subplots(
        2, 1, figsize=(13.0, 9.0),
        gridspec_kw={"height_ratios": [1.25, 1.0], "hspace": 0.30})
    figure.patch.set_facecolor(SURFACE)

    top.axhline(floor, color="#d62728", lw=1.3, ls="--", alpha=0.8,
                label=f"5$\\sigma$ detection floor ({floor:.2f}x)")
    top.axhline(1.0, color=INK_MUTED, lw=0.9, ls=":", alpha=0.8,
                label=f"fitted growth trend (gap$^{{{slope:.2f}}}$)")
    top.plot(mid, ratio, "-", color=INK_MUTED, lw=1.0, alpha=0.7, zorder=2)
    top.plot(mid, ratio, "o", color=INK, ms=3.4, zorder=3,
             label="chromatic step / growth expected for its gap")
    for index in labelled:
        top.plot(mid[index], ratio[index], "o", ms=11, mfc="none",
                 mec="#d62728", mew=2.0, zorder=4,
                 label=(f"labelled decon ({cycles[index]} "
                        f"$\\rightarrow$ {cycles[index + 1]})"))
    for index in suspects:
        top.annotate(f"epoch {index + 2}", (mid[index], ratio[index]),
                     textcoords="offset points", xytext=(0, 9), ha="center",
                     fontsize=8, color="#d62728")
    _style_axes(top, xlabel="hours from the reference epoch",
                ylabel="chromatic step, relative to the\ngrowth its gap allows",
                title="Is every decon labelled?  A film reset is chromatic; "
                      "an ACM move is not")
    top.set_yscale("log")
    # Headroom for the legend. Without it, a run whose floor sits above every
    # point (i.e. an underpowered one, which is when the floor most needs
    # reading) autoscales the dashed line right under the legend text.
    low, high = top.get_ylim()
    top.set_ylim(low, high * 3.0)
    _dedupe_legend(top, loc="upper left", fontsize=8.5)

    # The decomposition itself, so the claim is visible rather than asserted:
    # a geometric ACM step moves along the x axis only.
    # The ACM boundaries are drawn here because they are the control: the claim
    # is that a geometric step is achromatic, and these are the steps already
    # known to be geometric. If one of them showed up with a decon-sized
    # chromatic part, the premise of this whole figure would be wrong.
    acm = [b - 1 for b in segment_boundaries(series.segment)
           if 0 <= b - 1 < len(mid)]
    # An ACM boundary only serves as a control if nothing else happened there.
    # Note the asymmetry with `labelled` above, which is deliberate: to claim a
    # transition you need both cycles known and different, but to claim a clean
    # control you need to know no transition happened, so an unknown -> known
    # change disqualifies it. The legacy 34-file set has exactly this case -- its
    # last ACM boundary coincides with the '' -> decon2 change and reads
    # chromatic 0.045, and drawing it as a clean geometric step would argue the
    # opposite of what this figure claims.
    dirty = [i for i in acm if cycles[i] != cycles[i + 1]]
    acm = [i for i in acm if i not in dirty]
    special = set(labelled) | set(suspects) | set(acm) | set(dirty)
    ordinary = [i for i in range(len(mid)) if i not in special]
    bottom.axhline(0, color=INK_MUTED, lw=0.8, alpha=0.6)
    bottom.axvline(0, color=INK_MUTED, lw=0.8, alpha=0.6)
    bottom.plot(np.asarray(achromatic)[ordinary], np.asarray(chromatic)[ordinary],
                "o", color=INK_MUTED, ms=4, alpha=0.65, label="ordinary epoch")
    for index in acm:
        bottom.plot(achromatic[index], chromatic[index], "^", color="#2a78d6",
                    ms=9, mfc="none", mew=1.8,
                    label="ACM move (known geometric: should be achromatic)")
    for index in dirty:
        bottom.plot(achromatic[index], chromatic[index], "v", color="#8c8c8c",
                    ms=9, mfc="none", mew=1.8,
                    label="ACM move at a cycle change: not a clean control")
    for index in labelled:
        bottom.plot(achromatic[index], chromatic[index], "D", color="#d62728",
                    ms=9, label="labelled decon")
    for index in suspects:
        bottom.plot(achromatic[index], chromatic[index], "s", color="#eda100",
                    ms=8, label="above the floor, unlabelled")
    _style_axes(bottom, xlabel="achromatic part: mean $\\Delta\\ln$ response "
                               "(a pure ACM step lands here, on the axis)",
                ylabel="chromatic part: spread of\n$\\Delta\\ln$ response "
                       "across LEDs")
    _dedupe_legend(bottom, loc="upper left", fontsize=8.5)

    if labelled:
        margin = min(ratio[index] for index in labelled) / floor
        if margin >= 1.0:
            verdict = (f"{len(labelled)} labelled decon transition(s); the "
                       f"weakest stands {margin:.1f}x clear of the detection "
                       f"floor, so a decon {100 / margin:.0f}% as strong would "
                       f"still have been caught")
        else:
            # The calibrator itself fell below the floor. Reporting "no
            # suspects" here would be a clean sheet obtained by being blind.
            verdict = (f"UNDERPOWERED: the labelled decon reads only "
                       f"{margin:.2f}x the floor, i.e. this set cannot even "
                       f"recover the transition it is annotated with, so a "
                       f"clean result below means nothing")
    else:
        margin = np.nan
        verdict = ("no labelled decon transition in this set, so there is "
                   "nothing to calibrate the floor against: the quiet level is "
                   "shown, but not what a decon would look like")
    outcome = (f"{len(suspects)} unlabelled step(s) above the floor: epoch(s) "
               f"{', '.join(str(i + 2) for i in suspects)} -- check these "
               f"against the decon schedule" if suspects else
               "no unlabelled step exceeds the floor, so the annotation is "
               "consistent with the response")
    # The blind spot, always stated: "no suspects" is only as strong as the
    # smallest reset the run's sparsest gap could have hidden.
    loudest = max(chromatic)
    blind = (f"Detection limit set by cadence: at the sparsest step "
             f"({worst_gap:.1f} h) a chromatic reset below {worst_hideable:.4f} "
             f"would hide, against {loudest:.4f} for the loudest step "
             f"seen here.")
    if worst_hideable > loudest:
        # Worth spelling out rather than leaving to the reader's arithmetic:
        # the limit is above the largest step the run contains, so that step
        # could not have been detected there at all.
        blind += (" That limit is above every step in this run, so at that "
                  "cadence no reset of any size seen here would be caught.")
    # Wrapped per sentence, not over the group: _wrap re-splits on all
    # whitespace, so handing it an embedded newline silently loses the break.
    caption = _wrap(verdict, 150) + _wrap(outcome, 150) + _wrap(blind, 150)
    figure.text(0.5, 0.012, "\n".join(caption), ha="center",
                va="bottom", fontsize=9, color=INK_SECONDARY)

    figure.subplots_adjust(left=0.085, right=0.985, top=0.93, bottom=0.145)
    figure.savefig(out_path, dpi=140, facecolor=SURFACE)
    plt.close(figure)
    return Path(out_path), suspects, margin


def _dedupe_legend(ax, **kwargs):
    """Legend with repeated labels collapsed; several loops label every point."""
    handles, labels = ax.get_legend_handles_labels()
    seen = {}
    for handle, label in zip(handles, labels):
        seen.setdefault(label, handle)
    if seen:
        legend = ax.legend(seen.values(), seen.keys(), frameon=False, **kwargs)
        for text in legend.get_texts():
            text.set_color(INK_SECONDARY)


def _wrap(text, width):
    """Minimal word wrap; avoids a textwrap import for one call site."""
    lines, current = [], ""
    for word in text.split():
        if current and len(current) + 1 + len(word) > width:
            lines.append(current)
            current = word
        else:
            current = f"{current} {word}".strip()
    if current:
        lines.append(current)
    return lines


def self_test(verbose=True):
    """Assert the decon test fires on a planted reset and stays quiet otherwise.

    Only :func:`decon_evidence` is covered, because it is the one function here
    that returns a number someone acts on: a false negative silently licenses
    the bridge to fit across a film reset.  The other figures are judged by
    looking at them.
    """
    import tempfile
    import warnings
    from dataclasses import dataclass
    from datetime import datetime, timedelta

    def report(message):
        if verbose:
            print(f"  ok  {message}")

    @dataclass
    class _Series:
        time_hours: np.ndarray
        raw: dict
        decon_cycles: list
        segment: np.ndarray
        names: list = None
        calibration_families: list = None
        # Only the before/after figure needs these; defaulted so every
        # existing ``build`` call is unchanged. They mirror the real
        # TrendSeries API rather than being ad-hoc, because the point of the
        # test is that the figure's two panels differ by exactly the gain
        # ratio, and a stub that computed the ratio its own way would not test
        # that.
        timestamps: list = None
        tempgain: dict = None
        tempgain_form: str = "poly_pinned_v1"

        def response(self, sca):
            return self.raw[sca]

        def tempgain_ratio(self, sca):
            multiplier = self.tempgain[sca]
            return multiplier / multiplier[0, :][None, :]

        def response_tgcorr(self, sca):
            return self.response(sca) * self.tempgain_ratio(sca)

    def build(hours, reset_at=None, cycles=None):
        rng = np.random.default_rng(11)
        n = len(hours)
        raw = {f"SCA{i}": 1 + 5e-4 * rng.standard_normal((n, 6))
               for i in range(1, N_SCAS + 1)}
        # Steady chromatic growth: each LED drifts at its own rate, so the
        # across-LED spread accumulates with elapsed time exactly as film growth
        # does. This is what the gap power law has to absorb.
        pace = np.array([1.0, -1.0, 0.6, -0.6, 0.3, -0.3]) * 3e-4
        for key in raw:
            raw[key] *= np.exp(np.outer(hours - hours[0], pace))
            if reset_at is not None:
                raw[key][reset_at:] *= np.array([1.03, .97, 1.02, .96, 1.04, .98])
        return _Series(np.asarray(hours, float), raw,
                       cycles or [""] * n, np.zeros(n, int),
                       names=[f"EP_{i:03d}" for i in range(n)])

    ok = True
    with warnings.catch_warnings():
        # A meaningless polynomial fit must not be reachable, so promote the
        # warning that would announce one into a failure.
        warnings.simplefilter("error", np.RankWarning if hasattr(np, "RankWarning")
                              else np.exceptions.RankWarning)

        # 1. Too few epochs: the test must be unavailable, not passing.
        for n in (2, 3, 4):
            *_, floor, suspects, _ = decon_evidence(build(np.arange(n) * 10.0))
            assert not np.isfinite(floor), (n, floor)
            assert suspects == [], (n, suspects)
        report("a set too short to fit reports an unavailable floor, not a pass")

        # 2. Uniform cadence leaves log(gap) with no spread, so the exponent is
        # unconstrained; degree 0 must be used rather than a fitted nonsense
        # slope (this raised RankWarning and returned -1.46 before the guard).
        *_, suspects, power = decon_evidence(build(np.arange(40) * 10.0))
        assert power[0] == 0.0, power
        assert suspects == [], suspects
        report("uniform cadence falls back to a flat model and flags nothing")

        # 3. Irregular cadence, steady growth, no reset: still nothing.
        rng = np.random.default_rng(3)
        hours = np.concatenate([[0.0], np.cumsum(rng.uniform(2, 30, 39))])
        *_, suspects, power = decon_evidence(build(hours))
        assert suspects == [], suspects
        # Growth proportional to elapsed time means chromatic step ~ gap^1; the
        # flight set measures 0.98, so a wrong exponent here is a real defect.
        assert 0.7 < power[0] < 1.3, power
        report(f"steady growth at irregular cadence recovers exponent "
               f"{power[0]:.2f} (~1) and flags nothing")

        # 4. The one that matters: a planted reset must be found, and only it.
        _, ratio, _, _, floor, suspects, _ = decon_evidence(
            build(hours, reset_at=20))
        assert suspects == [19], suspects
        assert ratio[19] > 3 * floor, (ratio[19], floor)
        report(f"a planted chromatic reset is the sole detection, at "
               f"{ratio[19] / floor:.0f}x the floor")

        # 5. Labelling that reset must keep it out of the suspects *and* make it
        # the calibrator -- the margin is what the figure quotes.
        cycles = ["decon1"] * 20 + ["decon2"] * 20
        series = build(hours, reset_at=20, cycles=cycles)
        *_, suspects, _ = decon_evidence(series)
        assert suspects == [], suspects
        with tempfile.TemporaryDirectory() as tmp:
            path, drawn, margin = plot_decon_evidence(
                series, Path(tmp) / "decon_evidence.png")
            assert path.stat().st_size > 10000, path.stat().st_size
            assert drawn == [], drawn
            assert margin > 1.0, margin
        report(f"the same reset, once labelled, calibrates the floor instead "
               f"(margin {margin:.1f}x) and the figure draws")

        # 6. The calibration band's two awkward branches, which no amount of
        # looking at the flight figure would exercise: a family of exactly one
        # epoch is a zero-width patch whose label would vanish, and a set with
        # no recorded provenance must say so rather than draw one wide band
        # that reads as "one calibration throughout".
        figure, axis = plt.subplots()
        try:
            families = [
                {"key": ("mast",) * 6, "first": 0, "last": 0, "n": 1,
                 "ref_file_id": "1aa8a84bc016ea68", "klass": "unity-photom",
                 "source": "mast", "describe": "d"},
                {"key": ("mast",) * 6, "first": 1, "last": 19, "n": 19,
                 "ref_file_id": "0040ancientphotom", "klass": "old-photom",
                 "source": "mast", "describe": "d"},
                {"key": ("aux",) * 6, "first": 20, "last": 39, "n": 20,
                 "ref_file_id": "57375af18e138f28", "klass": "unity-photom",
                 "source": "aux", "describe": "d"},
            ]
            series.calibration_families = families
            _draw_calibration_band(axis, series.time_hours, series)
            assert len(axis.patches) == 3, len(axis.patches)
            # Two class changes (unity -> old -> unity), so two heavy rules,
            # each annotated. The count is the assertion that matters: a band
            # that drew the patches but not the rules would look complete.
            marks = [text for text in axis.texts
                     if "flux step" in text.get_text()]
            assert len(marks) == 2, [t.get_text() for t in axis.texts]
        finally:
            plt.close(figure)
        report("the calibration band draws a single-epoch family and marks "
               "both class changes as flux steps")

        figure, axis = plt.subplots()
        try:
            series.calibration_families = []
            _draw_calibration_band(axis, series.time_hours, series)
            assert not axis.patches, len(axis.patches)
            assert any("not recorded" in text.get_text()
                       for text in axis.texts)
        finally:
            plt.close(figure)
        report("an unrecorded set draws no band and says the question was "
               "not asked")

        # 7. The band's geometry keywords must be a pure generalisation: the
        # defaults have to reproduce the position plot_run_structure relies on,
        # or that figure's three bands silently overlap.
        figure, axis = plt.subplots()
        try:
            series.calibration_families = families
            _draw_calibration_band(axis, series.time_hours, series)
            default_rect = [(p.get_y(), p.get_height()) for p in axis.patches]
            assert default_rect == [(0.06, 0.27)] * 3, default_rect
        finally:
            plt.close(figure)
        figure, axis = plt.subplots()
        try:
            _draw_calibration_band(axis, series.time_hours, series,
                                   y_centre=0.5, height=0.4)
            moved = [(round(p.get_y(), 6), p.get_height())
                     for p in axis.patches]
            assert moved == [(0.3, 0.4)] * 3, moved
        finally:
            plt.close(figure)
        report("the band's default geometry is unchanged and y_centre/height "
               "move it as a whole")

        # 8. plot_calibration_timeline. The class count is the number the
        # figure shares with assert_homogeneous_calibration, so each case
        # asserts on it rather than only on the file existing.
        with tempfile.TemporaryDirectory() as tmp:
            n = len(series.time_hours)
            labels = list(series.names)

            def audit_rows(klass_of, **fixed):
                rows = []
                for index in range(n):
                    row = {"run_label": labels[index],
                           "provenance_from": "streamed",
                           "cal_version": "0.18.0",
                           "crds_context": "roman_0072.pmap",
                           "cal_step_photom": "COMPLETE",
                           "calibration_class": klass_of(index),
                           "ref_file_id": f"id{klass_of(index)}"}
                    row.update(fixed)
                    rows.append(row)
                return rows

            # Two classes: exactly one class edge, so exactly one heavy rule.
            two = audit_rows(lambda i: "unity-photom" if i < 20 else "old")
            path, n_classes, uncovered = plot_calibration_timeline(
                series, Path(tmp) / "two.png", audit=(two, {"description": "d"}, []))
            assert n_classes == 2, n_classes
            assert uncovered == [], uncovered
            assert path.stat().st_size > 10000, path.stat().st_size

            # The flight shape: one class but two different raw ref_file_ids,
            # which is the case that would draw two colours and one spurious
            # "flux step" if the fill keyed on the id instead of the class.
            mixed = audit_rows(lambda i: "unity-photom")
            for index, row in enumerate(mixed):
                row["ref_file_id"] = ("fb7be0c9d705b6ae" if index < 20
                                      else "1aa8a84bc016ea68")
                row["provenance_from"] = "product" if index < 20 else "streamed"
            path, n_classes, _ = plot_calibration_timeline(
                series, Path(tmp) / "mixed.png",
                audit=(mixed, {"description": "d"}, []))
            assert n_classes == 1, n_classes
            report("two raw ref_file_ids resolving to one class read as one "
                   "class, not as a flux step")

            # No audit: must not report zero classes as "clean".
            path, n_classes, uncovered = plot_calibration_timeline(
                series, Path(tmp) / "none.png", audit=None)
            assert n_classes == 0, n_classes
            assert len(uncovered) == n, len(uncovered)

            # Partial coverage: the uncovered epochs must be counted, and the
            # gap must break the run rather than be interpolated over.
            partial = audit_rows(lambda i: "unity-photom")
            rows = [None if 10 <= index < 15 else row
                    for index, row in enumerate(partial)]
            path, n_classes, uncovered = plot_calibration_timeline(
                series, Path(tmp) / "partial.png",
                audit=(rows, {"description": "d"}, labels[10:15]))
            assert n_classes == 1, n_classes
            assert len(uncovered) == 5, uncovered
            assert len(_audit_families(rows, series.time_hours)) == 3, \
                _audit_families(rows, series.time_hours)
            report("a gap in the audit breaks the run into three families and "
                   "is reported as 5 uncovered epochs")

            # A single-epoch family goes through the leader-line branch of the
            # shared band, inside the new figure -- which is what proves the
            # geometry refactor did not break that branch at a new height.
            series.calibration_families = families
            path, _, _ = plot_calibration_timeline(
                series, Path(tmp) / "leader.png",
                audit=(partial, {"description": "d"}, []))
            assert path.stat().st_size > 10000, path.stat().st_size
            report("the timeline draws both bands, including a single-epoch "
                   "product family at the relocated height")

            # 9. The temperature-gain comparison figure. It must differ from
            # the delivered figure by exactly the gain RATIO, which is the one
            # thing here that can be wrong while still looking right: a figure
            # drawn from the absolute multiplier is smooth, plausible, and off
            # by a constant.
            series.timestamps = [datetime(2026, 9, 1)
                                 + timedelta(hours=float(h))
                                 for h in series.time_hours]
            rng9 = np.random.default_rng(9)
            gain = {sca: 0.99 + 0.004 * rng9.standard_normal(
                        (len(series.time_hours), 6))
                    for sca in series.raw}
            series.tempgain = gain

            lines_plain = plot_led_all_scas(
                series, 0, Path(tmp) / "plain.png")
            assert Path(lines_plain).stat().st_size > 10000
            path = plot_led_all_scas(series, 0,
                                     Path(tmp) / "tgcorr.png", corrected=True)
            assert Path(path).stat().st_size > 10000, path

            sca0 = sorted_scas(series.raw)[0]
            ratio = series.tempgain_ratio(sca0)
            assert np.allclose(ratio[0, :], 1.0), ratio[0, :]
            assert np.allclose(series.response_tgcorr(sca0),
                               series.response(sca0) * ratio)
            report("the corrected figure draws and its ratio is exactly 1.0 "
                   "at the reference epoch")

            # The pair is meant to be BLINKED, so the frame must not move
            # between the two files -- otherwise flipping between them shows
            # the axes rescaling and the 1 % effect is lost in it. Same
            # rendered pixel size is the cheap half of that.
            from PIL import Image
            with Image.open(lines_plain) as a, Image.open(path) as b:
                assert a.size == b.size, (a.size, b.size)
            report("the blink pair renders at identical pixel dimensions")

            # And the other half: the shared frame must contain BOTH series.
            # Reusing the delivered figure's own autoscale is the tempting
            # shortcut, and on the real set it clips the corrected curves off
            # the bottom of LED3 and LED6. This gain is built to push the
            # corrected curves well outside the delivered range so that a
            # regression to the uncorrected-only frame fails here.
            scas9 = sorted_scas(series.raw)
            drift = {sca: np.linspace(1.0, 1.25,
                                      len(series.time_hours))[:, None]
                          * np.ones((1, 6))
                     for sca in series.raw}
            series.tempgain = drift
            frame = _shared_response_ylim(series, scas9, 0)
            assert frame is not None
            plain_vals = np.concatenate([series.response(s)[:, 0]
                                         for s in scas9])
            corr_vals = np.concatenate([series.response_tgcorr(s)[:, 0]
                                        for s in scas9])
            both = np.concatenate([plain_vals, corr_vals])
            assert frame[0] <= np.nanmin(both) and np.nanmax(both) <= frame[1], (
                frame, np.nanmin(both), np.nanmax(both))
            # the guard is only meaningful if the corrected curves really do
            # escape the delivered range, so assert that the fixture does that
            assert np.nanmax(corr_vals) > np.nanmax(plain_vals), (
                "fixture no longer exercises the clipping case")
            report("the shared blink frame contains both series, including "
                   "corrected curves outside the delivered range")

            # The trap, pinned: a gain that is CONSTANT in time is entirely
            # absorbed by the gauge, so the corrected series must come back
            # bit-identical. Forgetting the /m[0] would rescale every point by
            # that constant instead -- a uniform, invisible error.
            flat = {sca: np.full((len(series.time_hours), 6), 0.97)
                    for sca in series.raw}
            series.tempgain = flat
            assert np.array_equal(series.response_tgcorr(sca0),
                                  series.response(sca0))
            report("a time-constant gain leaves the corrected series "
                   "bit-identical: the gauge absorbs it, as it must")

            # And the refusal: with no block the corrected file would be
            # identical to the delivered one, which blinks as a measured null
            # rather than as an absent model.
            series.tempgain = None
            try:
                plot_led_all_scas(series, 0, Path(tmp) / "nope.png",
                                  corrected=True)
            except ValueError as exc:
                assert "carries none" in str(exc), exc
            else:                                         # pragma: no cover
                ok = False
                print("  FAIL  corrected=True accepted a series with no "
                      "temperature-gain block")
            report("corrected=True refuses a series with no gain block")

            # With no block there is also no blink partner, so the delivered
            # figure must keep matplotlib's own autoscale -- that is what makes
            # it byte-identical to a build from before this feature existed.
            assert _shared_response_ylim(series, sorted_scas(series.raw),
                                         0) is None
            report("with no gain block the delivered figure keeps its "
                   "autoscale, so it stays byte-identical")

    return ok


def write_all(series, spec, plot_dir, audit=None):
    """Every figure for one pipeline run; returns the paths written."""
    plot_dir = Path(plot_dir)
    plot_dir.mkdir(parents=True, exist_ok=True)

    written = [plot_all_scas(series, plot_dir / "time_series_all_scas.png")]
    for sca in sorted_scas(series.raw):
        written.append(plot_single_sca(series, sca,
                                       plot_dir / f"time_series_{sca}.png"))
    for ind, led in enumerate(LED_NAMES):
        written.append(plot_led_all_scas(
            series, ind, plot_dir / f"time_series_{led}_all_scas.png"))
        # Only when a model is in play, and never in place of the figure
        # above: that one is the delivered series and keeps its filename and
        # its meaning. The _tgcorr file is the comparison, drawn on the same
        # axes so the pair can be blinked. Note the ordering dependence: both
        # calls derive their shared y-limits from the series, not from each
        # other, so the two files do not have to be written together or in
        # this order to end up on the same frame.
        if series.tempgain:
            written.append(plot_led_all_scas(
                series, ind,
                plot_dir / f"time_series_{led}_all_scas_tgcorr.png",
                corrected=True))

    # One pair of bridge figures per ACM boundary. The single-boundary filenames
    # stay as they were so existing links and notebooks keep resolving; a set
    # with several moves gets a suffix per boundary.
    # Outside the `if series.steps` block below for the same reason as
    # decon_evidence, and more so: an upstream calibration step is one of the
    # commonest reasons a bridge fit comes out wrong, so this figure is most
    # wanted exactly when there is no bridge to plot.
    path, n_classes, uncovered = plot_calibration_timeline(
        series, plot_dir / "calibration_timeline.png", audit=audit)
    written.append(path)
    if n_classes > 1:
        print(f"  WARNING: calibration_timeline.png: {n_classes} L2 "
              f"equivalence class(es) in this set; an achromatic per-SCA step "
              f"at each class edge is calibration, not film")
    elif n_classes == 1 and not uncovered:
        print(f"  calibration_timeline.png: one L2 equivalence class over all "
              f"{len(series.names)} epochs, fully audited")
    elif n_classes == 1:
        print(f"  calibration_timeline.png: one L2 equivalence class, but "
              f"{len(uncovered)} epoch(s) are not in the audit")
    elif audit is None:
        print("  calibration_timeline.png: no audit supplied, so only the "
              "product-recorded provenance is drawn")
    else:
        # Distinct from the line above: an audit that was read but matched
        # nothing is a label mismatch, not an absent file, and reporting the
        # two the same way sends the reader to look for a missing file.
        print(f"  WARNING: calibration_timeline.png: an audit was supplied but "
              f"matched no epoch of this set; nothing is attested")

    # Outside the `if series.steps` block below, deliberately: this figure
    # checks the labels the bridge *depends* on, so it is most wanted exactly
    # when the bridge produced nothing to plot.
    if len(series.time_hours) > 2:
        path, suspects, margin = plot_decon_evidence(
            series, plot_dir / "decon_evidence.png")
        written.append(path)
        if suspects:
            print(f"  WARNING: decon_evidence.png: {len(suspects)} unlabelled "
                  f"step(s) exceed the chromatic floor (epoch(s) "
                  f"{', '.join(str(i + 2) for i in suspects)}); an unrecorded "
                  f"decon would let the bridge fit across a film reset")
        elif np.isfinite(margin) and margin < 1.0:
            # Not "consistent": the test failed to recover its own calibrator,
            # so it has no power to say anything about unlabelled epochs.
            print(f"  decon_evidence.png: UNDERPOWERED at this cadence -- the "
                  f"labelled decon itself reads only {margin:.2f}x the floor, "
                  f"so the absence of suspects is not evidence")
        elif np.isfinite(margin):
            print(f"  decon_evidence.png: labels consistent; the weakest "
                  f"labelled decon stands {margin:.1f}x clear of the floor")
        else:
            print("  decon_evidence.png: no labelled decon transition, so the "
                  "floor is uncalibrated; suspects are indicative only")

    boundaries = segment_boundaries(series.segment)
    if any(series.steps.values()):
        path, worst = plot_run_structure(series, plot_dir / "run_structure.png")
        written.append(path)
        if np.isfinite(worst):
            print(f"  run_structure.png: worst closure departure "
                  f"{100 * worst:.3f}%")
        for index, boundary in enumerate(boundaries):
            suffix = "" if len(boundaries) == 1 else f"_boundary{index + 1}"
            if boundary in series.side_boundaries:
                # No per-SCA ACM step is fitted at a side change, so the ACM
                # figures would draw eighteen fixed 1.0s. The side bridge has
                # its own figure, written below.
                continue
            written.append(plot_bridge_summary(
                series, plot_dir / f"bridge_summary{suffix}.png",
                boundary_index=index))
            path, spread, unscreened = plot_bridge_sensitivity(
                series, spec, plot_dir / f"bridge_sensitivity{suffix}.png",
                boundary_index=index)
            written.append(path)
            # Two different things look the same here: a boundary where fits
            # exist but none survive the noise-floor screen, and one where the
            # scan could not fit anything at all (a segment with too few
            # epochs). Only the first is "model-limited".
            fittable = any(len(s) > index and s[index].is_fitted
                           for s in series.steps.values())
            if unscreened and fittable:
                print(f"  WARNING: boundary {index + 1} (epoch {boundary + 1}): "
                      f"no fit choice reaches the noise floor for "
                      f"{', '.join(unscreened)}; their bridge is model-limited")
            elif unscreened:
                print(f"  boundary {index + 1} (epoch {boundary + 1}): no fit "
                      f"choice is solvable for any SCA, so the sensitivity "
                      f"panel is empty; the step came from the linear model")

    fitted = [s for s in getattr(series, "side_steps", []) if s.method == "side"]
    for number, step in enumerate(fitted, start=1):
        name = "side_bridge.png" if len(fitted) == 1 else f"side_bridge_{number}.png"
        written.append(plot_side_bridge(series, step, plot_dir / name))

    return written
