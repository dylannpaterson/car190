"""Build the per-SCA RCS trend digests (``time_series_SCA*.ecsv``) from mosaics.
    mosaic HDF5  ->  ratio to the reference epoch
                 ->  photodiode / side / ACM scalar corrections
                 ->  nanmedian inside each SCA footprint
                 ->  bridge across ACM reconfigurations
                 ->  one ECSV per SCA (timestamps, time_hours, LED1..LED6)

The first file in the list is the reference epoch, so ``time_hours`` is measured
from it and its ratio is 1.0 by construction.

The ACM is deployed after pass 15 and repositioned twice more on the deployed
side; every such move is detected here. Each ACM configuration is a "segment",
and the scalar linear ACM correction is only valid inside one, so the steps
between them are bridged. The bridge is a scalar per SCA, assuming the effect is
achromatic and produced by the geometry. There is ongoing evolution and each move
is bridged by a finite time, so the solution cannot just fix post=pre. Each LED
has its own evolution, which also helps differentiate a common mode shift. Solve
least squares in log space with inverse variance weights. Where a segment has too
few epochs to fit a step, the linear LVDT multiplier stands in; where two segments
sit at the same LVDT, the composed bridge between them must read 1.0 and that is
checked.
"""
import argparse
import collections
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from pathlib import Path
import re
import sys

import astropy.units as u
import h5py
import numpy as np
from astropy.table import Table
from astropy.time import Time

# Instrument configuration lives in rcs_trend_config, the single constants
# source already imported by the film-fitting scripts; the ACM segmentation and
# bridge live in rcs_acm; the per-SCA/mosaic geometry in rcs_sca_grid.  Pulling
# them out of here is also what lets digest_plots import the shared names
# directly instead of from this module, which used to be an import cycle worked
# around by a deferred `import digest_plots` inside main().
from rcs_trend_config import (ACM_COEF_DEFAULT, ACM_COEF_MCEB,
                             ACM_DEPLOY_MIN_DELTA, ACM_MOVE_MIN_DELTA,
                             ACM_TRAVEL_WARN, B_SIDE_CORRECTIONS, LED_NAMES,
                             MCEB_ACM_OFFSET, MEASURED_SOFTWARE_CHANGES,
                             N_SCAS, SCA_NAMES,
                             SCREEN_TOLERANCE, SIDE_LED_SPREAD_WARN,
                             acm_coefficient_for, acm_offset_for,
                             b_side_correction_for, calibration_class,
                             normalize_side)
from rcs_acm import (AcmMove, BridgeSpec, BridgeStep, SideBridgeSpec,
                     SideStep, acm_segments,
                     boundary_floors, bridge_factors, bridge_sensitivity,
                     closure_checks, closure_residuals, decon_episodes,
                     deployed_gauge_lvdt,
                     fallback_step, find_acm_deploys, find_acm_moves,
                     fit_bridge_step, fit_side_step, local_scatter,
                     max_fractional_travel as acm_max_travel,
                     multiplier_step, report_acm_configuration,
                     screen_sensitivity, segment_boundaries,
                     segment_noise_floors, segment_reference_lvdt,
                     side_bridge_factors, side_sensitivity)
from rcs_acm import label_side_moves, side_change_indices as _side_changes
import rcs_bridge_solution
from rcs_sca_grid import (SCA_GEOMETRY_FILE, median_per_sca, per_sca_reduce,
                          read_sca_geometry, sca_footprint_masks, sca_name,
                          sorted_scas)
import rcs_products
import rcs_l2_source
import digest_plots

_HERE = Path(__file__).resolve().parent

DEFAULT_DATA_ROOT = Path("/data/eswitzer/rcs_trend")
DEFAULT_OUT_DIR = _HERE / "digests"
DEFAULT_PLOT_DIR = _HERE / "digest_plots"
# Defaulted rather than opt-in: the file is the record of how these epochs were
# calibrated, and a figure that silently omits its primary band because a flag
# was forgotten is the failure mode worth designing out. A missing file
# degrades to the product-recorded band alone.
DEFAULT_L2_AUDIT = _HERE / "l2_calibration_audit.ecsv"


@dataclass(frozen=True)
class Corrections:
    """Which per-epoch scalar corrections to fold into the response ratio."""
    photodiode: bool = True
    side: bool = True
    acm: bool = True


# ---------------------------------------------------------------------------
# Reading epochs
# ---------------------------------------------------------------------------

# Timestamp and epoch-identity parsing now live in rcs_products, which owns the
# h5 schema: reading the pass number or the electronics side out of a product is
# schema knowledge, and keeping it here would mean rcs_corrections had to import
# this module while this module imports rcs_corrections.  Re-exported under the
# old names for one release so nothing downstream breaks mid-refactor.
parse_timestamp = rcs_products.parse_timestamp


def parse_pass_number(name, sequence_number=None, attrs=None):
    """Deprecated: see :func:`rcs_products.pass_number_from`.

    The old implementation read the pass only from the filename.  The products
    now carry a ``pass_number`` attribute, which is preferred, because a product
    renamed or re-dated by hand would otherwise silently take the wrong pass and
    the digests order and label by it.
    """
    return rcs_products.pass_number_from(name, attrs,
                                         sequence_number=sequence_number)


@dataclass(frozen=True)
class Epoch:
    """One compiled RCS observation and the metadata the corrections need.

    Carries **either** per-SCA stacks or a mosaic, never both, and
    ``product_kind`` says which.  The two shapes reduce to per-SCA numbers by
    different routes -- ``per_sca_reduce`` over a stack plane, or a footprint
    median over a mosaic -- and only the first is uncontaminated: at the legacy
    net bin of 20, ``4096/20 = 204.8``, so mosaic superpixels straddle SCA edges
    and inter-SCA gaps at the ~0.1 % level, which is the size of the film-growth
    signal being measured.  Measured on CAR-190 pass 36: the per-SCA and
    footprint medians differ by 0.007-0.017 % typical, 0.058 % worst.  That
    difference is the contamination, not an error in either.
    """
    name: str
    timestamp: datetime
    pass_number: int
    photodiode: np.ndarray  # one entry per LED, dark frame already dropped
    acm_lvdt: float         # nanmean LVDT position over the exposures
    mosaics: dict           # led_name -> 2D mosaic  (product_kind "mosaic")
    stacks: dict = field(default_factory=dict)   # led -> (18,n,n) ("per_sca")
    car_label: str = ""     # "CAR190"/"CAR216", from process_rcs_trending's annotate_h5
    decon_cycle: str = ""   # e.g. "decon1"/"decon2", same source; "" if not annotated
    mce_side: str = "A"
    mce_side_source: str = ""
    stage: str = "legacy"
    product_kind: str = "mosaic"
    bin_factor: int = 20
    orientation: str = ""
    dq_applied: bool = True
    # Per-LED validity of ``photodiode``, and where the values came from.  The
    # dictionary mirror carries no validity information, so an epoch read from
    # it is "valid" only in the sense that nothing contradicted it.
    photodiode_valid: np.ndarray = None
    photodiode_source: str = "dictionary"
    # Which reference card stage 2 calibrated against.  Empty for raw and
    # legacy products, which were never calibrated per-file.
    reference_card: str = ""
    reference_card_sha256: str = ""
    # How the *L2 input* was calibrated, which is upstream of everything this
    # pipeline does and invisible to it.  Empty for products built before
    # ``rcs_l2_source`` existed; see :func:`assert_homogeneous_calibration`.
    l2_source: str = ""
    l2_calibration: dict = field(default_factory=dict)
    # The temperature-gain reference block, or ``None`` when the product
    # carries none (which is every product calibrated without a gain model,
    # and every raw or legacy one). ``tempgain`` is ``(n_led, n_sca)`` in
    # ``LED_NAMES`` x ``SCA_NAMES`` order -- the product's own axis order,
    # reordered on read so a model written with a different one cannot be
    # silently transposed. NOT applied to ``stacks``, and not applied to the
    # canonical digest columns either; see
    # :meth:`TrendSeries.response_tgcorr`.
    tempgain: np.ndarray = None
    tempgain_valid: np.ndarray = None
    tempgain_temperature: np.ndarray = None
    tempgain_model: str = ""
    tempgain_model_sha256: str = ""
    tempgain_form: str = ""
    tempgain_mnemonic: str = ""
    # A calibrated product's schema. 2 records every factor under
    # calibration/<step>/multiplier and applies none; 1 had photodiode, side
    # and ACM multiplied into the pixels; 0 is a raw or legacy product.
    calibration_schema: int = 0
    # Schema 2 only: {step: (n_led, n_sca)} in LED_NAMES x SCA_NAMES order.
    # The digest applies photodiode x acm per epoch, and reads the recorded
    # bridges only to check them against its own fit.
    steps: dict = field(default_factory=dict)
    bridge_solution_sha256: str = ""

    @property
    def calibration_key(self):
        """Hashable identity of the L2 calibration, or ``None`` if unrecorded.

        Two epochs sharing this key were produced by the same calibration
        configuration; two that differ may carry different per-SCA flux scales,
        which is a step in the trend rather than a feature of the film.
        """
        prov = self.l2_calibration or {}
        if not prov.get("ref_file_id"):
            return None
        return (str(self.l2_source or "mast"),
                str(prov.get("calibration_software_version", "")),
                str(prov.get("crds_context", "")),
                str(prov.get("cal_step_photom", "")),
                str(prov.get("cal_step_flat_field", "")),
                str(prov.get("ref_file_id", "")))

    @property
    def pd_all_valid(self):
        """True when every LED's ``pd_net`` may be used as a denominator."""
        if self.photodiode_valid is None:
            return True
        return bool(np.all(self.photodiode_valid))

    @property
    def is_b_side(self):
        """B-side (MCEB) electronics, which need their own scale and LVDT offset.

        **This used to be ``"MCEB" in self.name``, and that was a latent bug.**
        Flight filenames carry no such marker, so every flight epoch was
        silently classified side A and the per-LED B-side corrections -- 1.5 to
        6 %, the size of the signal -- were never applied if the instrument ran
        on B.  The side now comes from the product's ``mce_side`` attribute via
        :func:`rcs_products.mce_side_from`, which falls back to the TVAC/SCIPA
        ``_MCE[AB]`` filename marker and otherwise *raises* rather than
        defaulting.
        """
        return str(self.mce_side).upper() == "B"

    @property
    def acm_offset(self):
        """LVDT readout offset for this epoch's electronics side."""
        return acm_offset_for(self.mce_side)

    @property
    def acm_coefficient(self):
        """Linear response coefficient in fractional LVDT travel."""
        return acm_coefficient_for(self.mce_side)

    @property
    def arrays(self):
        """Whichever of ``stacks``/``mosaics`` this product kind populated."""
        return self.stacks if self.product_kind == "per_sca" else self.mosaics

    @classmethod
    def from_hdf5(cls, path, sequence_number=None, assume_side=None,
                  arrays=True, pd_from_product=True):
        """Read one epoch, per-SCA or mosaic, classified from its attributes.

        ``arrays=False`` is the cheap metadata-only pass: it opens the file,
        reads the ``dictionary/`` group and the root attributes, and touches no
        pixels.  That is what makes the ACM segmentation pass over a 168-epoch
        set affordable, and it is the same reader either way so the two passes
        cannot disagree about an epoch's identity.
        """
        path = Path(path)
        meta = rcs_products.read_metadata(str(path))
        attrs = meta["attrs"]
        kind = meta["product_kind"]

        with h5py.File(path, "r") as h5:
            group = h5["dictionary"]
            # Photodiode entry 0 is the dark frame; entries 1..6 track LED1..LED6.
            photodiode = np.asarray(group["RCS_photodiode"][()],
                                    dtype=float)[1:]
            pd_valid, pd_source = None, "dictionary"
            if pd_from_product and "photodiode/per_activity" in h5:
                # The mirror is positional and flag-free; this group is keyed by
                # activity and carries pd_net_valid.  That matters because
                # pd_net is a *denominator*: a collapsed one near the 0.01 V
                # floor is a 60x factor that reads as a real instrument event,
                # and only this path can tell the digest not to form it.
                photodiode, pd_valid = _pd_from_group(h5["photodiode/per_activity"],
                                                      fallback=photodiode)
                pd_source = "photodiode/per_activity"
            # Absent on every raw product and on every calibrated one built
            # without --tempgain-model, which is why it defaults to None
            # rather than to ones: "no model was in play" and "the model says
            # unity" are different statements and only one of them licenses a
            # corrected column.
            tempgain = tg_valid = tg_temperature = None
            tg_attrs = {}
            schema = int(attrs.get("calibration_schema", 0) or 0)
            steps = {}
            if schema >= 2 and "calibration" in h5:
                # Schema 2: every step under calibration/, the temperature
                # gain included. The same reorder-and-assert as the schema-1
                # tempgain block, for every step.
                steps = _steps_from_group(h5["calibration"])
                if "tempgain" in h5["calibration"]:
                    # Its own name: ``group`` is the dictionary/ group, read
                    # again below for the LVDT and the timestamp. Reusing it
                    # here made every gain-carrying schema-2 product fail on
                    # 'ACM_LVDT' -- and only those, so a run without a model
                    # never saw it.
                    tg_group = h5["calibration"]["tempgain"]
                    order = _led_order(h5["calibration"])
                    tempgain = steps["tempgain"]
                    tg_valid = np.asarray(tg_group["valid"][()],
                                          dtype=bool)[order]
                    tg_temperature = np.asarray(tg_group["temperature_k"][()],
                                                dtype=float)[order]
                    tg_attrs = {key: tg_group.attrs[key] for key in tg_group.attrs}
            elif "tempgain" in h5:
                (tempgain, tg_valid, tg_temperature,
                 tg_attrs) = _tempgain_from_group(h5["tempgain"])
            # nanmean, not mean: one NaN LVDT channel used to NaN the whole
            # epoch's position, which silently disabled both the ACM correction
            # and the travel warning that would have reported it.  Two products
            # in the overloaded batch set had exactly that.
            lvdt = np.asarray(group["ACM_LVDT"][()], dtype=float)
            timestamp = rcs_products.parse_timestamp(group["timestamp"][()])
            stacks, mosaics = {}, {}
            if arrays and kind == "per_sca":
                stacks = {led: np.asarray(h5["sca_arrays"][led][:], dtype=float)
                          for led in LED_NAMES}
            elif arrays:
                mosaics = {led: h5["led_arrays"][led][:] for led in LED_NAMES}

        side, side_source = rcs_products.mce_side_from(path.name, attrs,
                                                       assume=assume_side)

        return cls(
            name=path.name,
            timestamp=timestamp,
            pass_number=rcs_products.pass_number_from(
                path.name, attrs, sequence_number=sequence_number),
            photodiode=photodiode,
            acm_lvdt=(float(np.nanmean(lvdt)) if np.isfinite(lvdt).any()
                      else float("nan")),
            mosaics=mosaics,
            stacks=stacks,
            car_label=str(attrs.get("car_label", "")),
            decon_cycle=str(attrs.get("decon_cycle", "")),
            mce_side=side,
            mce_side_source=side_source,
            stage=meta["stage"],
            product_kind=kind,
            bin_factor=int(meta["bin_factor"]),
            orientation=str(attrs.get("orientation", "")),
            dq_applied=bool(attrs.get("dq_applied", True)),
            photodiode_valid=pd_valid,
            photodiode_source=pd_source,
            reference_card=str(attrs.get("reference_card", "")),
            reference_card_sha256=str(attrs.get("reference_card_sha256", "")),
            l2_source=str(attrs.get("l2_source", "")),
            l2_calibration={field: str(attrs.get(field, ""))
                            for field in rcs_l2_source.PROVENANCE_FIELDS},
            tempgain=tempgain,
            tempgain_valid=tg_valid,
            tempgain_temperature=tg_temperature,
            tempgain_model=str(tg_attrs.get("model", "")),
            tempgain_model_sha256=str(tg_attrs.get("model_sha256", "")),
            tempgain_form=str(tg_attrs.get("model_form", "")),
            tempgain_mnemonic=str(tg_attrs.get("temperature_mnemonic", "")),
            calibration_schema=(schema if meta["stage"] == "calibrated"
                                and schema else
                                1 if meta["stage"] == "calibrated" else 0),
            steps=steps,
            bridge_solution_sha256=str(attrs.get("bridge_solution_sha256", "")),
        )

    @classmethod
    def metadata_only(cls, path, sequence_number=None, assume_side=None,
                      pd_from_product=True):
        """Same as ``from_hdf5`` but skips the pixels, for a cheap first pass."""
        return cls.from_hdf5(path, sequence_number=sequence_number,
                             assume_side=assume_side, arrays=False,
                             pd_from_product=pd_from_product)


def _pd_from_group(group, fallback):
    """``pd_net`` and its validity per LED, looked up by activity key.

    Keyed, not positional: the group also holds DARK and the CAR-216
    ``AUX_LED3FLAT*`` activities, so taking entries 1..6 by position would pick
    up an aux flat on any pass whose activity order differs.  An LED the group
    does not mention keeps its mirror value and is marked invalid, because a
    missing entry is a reason to distrust the number, not to trust the mirror.
    """
    keys = np.asarray(group["activity_key"][()]).astype(str)
    net = np.asarray(group["pd_net"][()], dtype=float)
    flags = np.asarray(group["pd_net_valid"][()], dtype=bool)
    by_key = {key: (net[ind], flags[ind]) for ind, key in enumerate(keys)}

    values = np.array(fallback, dtype=float)
    valid = np.zeros(len(LED_NAMES), dtype=bool)
    for ind, led in enumerate(LED_NAMES):
        if led in by_key:
            values[ind], valid[ind] = by_key[led]
    return values, valid


def _reorder_grid(grid, led_names, sca_labels, what):
    """``grid`` on its stored axes -> ``(n_led, n_sca)`` in canonical order.

    By label, never as stored: the axes are 6 and 18 long and the values are
    percent-level corrections, so a transposed or permuted grid is a smooth,
    plausible, wrong series with nothing anywhere to notice.
    """
    grid = np.asarray(grid, dtype=float)
    if grid.shape != (len(led_names), len(sca_labels)):
        raise SystemExit(
            f"{what} is {grid.shape} but its axis labels are "
            f"{len(led_names)} LEDs x {len(sca_labels)} SCAs; the product's "
            f"axes attribute says (led_name, sca)")
    missing = ([led for led in LED_NAMES if led not in led_names]
               + [sca for sca in SCA_NAMES if sca not in sca_labels])
    if missing:
        raise SystemExit(
            f"{what} does not cover {','.join(missing)}; a partially covered "
            f"step would leave those series uncorrected inside a corrected "
            f"digest")
    return grid[np.ix_([led_names.index(led) for led in LED_NAMES],
                       [sca_labels.index(sca) for sca in SCA_NAMES])]


def _axis_labels(group):
    led_names = [str(name) for name in
                 np.asarray(group["led_name"][()]).astype(str)]
    sca_labels = [f"SCA{int(value)}" for value in
                  np.asarray(group["sca"][()]).astype(int)]
    return led_names, sca_labels


def _led_order(group):
    led_names, _ = _axis_labels(group)
    return [led_names.index(led) for led in LED_NAMES]


def _steps_from_group(calibration):
    """``{step: (n_led, n_sca)}`` from a schema-2 ``calibration/`` group."""
    led_names, sca_labels = _axis_labels(calibration)
    return {name: _reorder_grid(calibration[name]["multiplier"][()],
                                led_names, sca_labels,
                                f"calibration/{name}/multiplier")
            for name in calibration
            if isinstance(calibration[name], h5py.Group)
            and "multiplier" in calibration[name]}


def _tempgain_from_group(group):
    """The ``tempgain/`` reference block, reordered to canonical axes.

    Returns ``(multiplier, valid, temperature, attrs)`` with ``multiplier``
    ``(n_led, n_sca)`` in :data:`LED_NAMES` x :data:`SCA_NAMES` order.

    Reordered by label rather than taken as stored, because the block's two
    axes have nearly the same length in no version of this pipeline but its
    *values* are a ~1 % correction: a transposed or permuted grid produces a
    smooth, plausible, wrong series with nothing anywhere to notice. The
    product's ``axes`` attribute says ``(led_name, sca)``; this asserts it
    rather than trusting it.

    An LED the product marked invalid keeps its NaN. NaN propagates into the
    corrected column and is counted, which is the same policy the photodiode
    denominator follows and for the same reason -- a 1.0 there would be an
    uncorrected point inside a corrected series.
    """
    led_names = [str(name) for name in
                 np.asarray(group["led_name"][()]).astype(str)]
    sca_labels = [f"SCA{int(value)}" for value in
                  np.asarray(group["sca"][()]).astype(int)]
    grid = np.asarray(group["multiplier"][()], dtype=float)
    if grid.shape != (len(led_names), len(sca_labels)):
        raise SystemExit(
            f"tempgain/multiplier is {grid.shape} but its axis labels are "
            f"{len(led_names)} LEDs x {len(sca_labels)} SCAs; the product's "
            f"axes attribute says (led_name, sca)")

    missing = ([led for led in LED_NAMES if led not in led_names]
               + [sca for sca in SCA_NAMES if sca not in sca_labels])
    if missing:
        raise SystemExit(
            f"tempgain/ does not cover {','.join(missing)}; a partially "
            f"covered block would leave those series uncorrected inside a "
            f"corrected digest")

    led_order = [led_names.index(led) for led in LED_NAMES]
    sca_order = [sca_labels.index(sca) for sca in SCA_NAMES]
    multiplier = grid[np.ix_(led_order, sca_order)]

    valid = np.asarray(group["valid"][()], dtype=bool)[led_order]
    temperature = np.asarray(group["temperature_k"][()],
                             dtype=float)[led_order]
    multiplier[~valid, :] = np.nan

    attrs = {key: group.attrs[key] for key in group.attrs}
    return multiplier, valid, temperature, attrs


def assert_homogeneous(epochs, allow_mixed_product_kind=False):
    """Refuse a set whose products were not made the same way.

    Mixing reductions inside one digest puts a step in the trend at the point
    where the set changes over, and it is a step of exactly the size being
    measured: per-SCA and mosaic medians differ at ~0.1 %, and so does a
    different ``bin_factor`` or ``orientation``.  A trend with a 0.1 % step in
    the middle of it is worse than no trend, because it looks like a result.
    """
    def values(field_name):
        return sorted({getattr(epoch, field_name) for epoch in epochs})

    kinds = values("product_kind")
    if len(kinds) > 1:
        message = (f"this set mixes product_kind {kinds}. Per-SCA and mosaic "
                   f"medians differ by ~0.1 % -- the size of the film-growth "
                   f"signal -- so mixing them puts a step in the trend at the "
                   f"changeover. Re-stage, or pass "
                   f"--allow-mixed-product-kind if you intend it.")
        if not allow_mixed_product_kind:
            raise SystemExit(message)
        print(f"  WARNING: {message}")

    for field_name, what in (("bin_factor", "superpixel size"),
                             ("orientation", "SCA orientation"),
                             ("dq_applied", "data-quality masking"),
                             ("stage", "calibration stage")):
        found = values(field_name)
        if len(found) > 1:
            print(f"  WARNING: this set mixes {field_name} {found} "
                  f"({what}); per-SCA medians are not comparable across that "
                  f"change and any step at the changeover is an artifact")

    # The reference card is what makes stage 2 reproducible: it fixes the
    # reference epoch, that epoch's pd_net per LED, and the per-segment
    # reference LVDT. Two cards built over different raw sets can therefore
    # disagree about every factor, and because stage 2 multiplies those factors
    # *into* the arrays, mixing them leaves nothing in the numbers to notice.
    #
    # Found the way these things are found: re-running run_calibration.sh over a
    # grown raw directory rebuilds the card but *skips* the epochs that already
    # have a product, so the set quietly ended up holding three cards --
    # 118 + 50 + 8 products -- and the digest built from it without comment.
    cards = sorted({e.reference_card_sha256 for e in epochs
                    if e.reference_card_sha256})
    if len(cards) > 1:
        counts = collections.Counter(e.reference_card_sha256 for e in epochs)
        raise SystemExit(
            f"this set was calibrated against {len(cards)} different reference "
            f"cards: "
            + ", ".join(f"{sha[:12]} ({counts[sha]} epoch(s))" for sha in cards)
            + ". Stage 2 multiplies the card's factors into the arrays, so the "
              "disagreement is not recoverable from the products. Re-run "
              "batch/run_calibration.sh with --force over the whole raw set.")

    # The temperature-gain block has exactly three legal states across a set:
    # every epoch carries none (the digest then has no corrected columns at
    # all), every epoch carries the same model, or the set is broken. A
    # *partial* set is the dangerous one -- it would give a corrected series
    # whose first epochs are corrected and whose last are not, which is a step
    # of the correction's own size at the changeover and reads as an
    # instrument event. Two *different* models are the same failure with a
    # smaller step.
    with_gain = [e for e in epochs if e.tempgain is not None]
    if with_gain and len(with_gain) != len(epochs):
        without = [e.name for e in epochs if e.tempgain is None]
        raise SystemExit(
            f"{len(with_gain)} of {len(epochs)} epoch(s) carry a tempgain/ "
            f"block and {len(without)} do not (e.g. {without[0]}). A "
            f"part-corrected series has a step the size of the correction at "
            f"the changeover. Re-run stage 2 over the whole set with the same "
            f"--tempgain-model, or over none of it.")
    gain_models = sorted({e.tempgain_model_sha256 for e in with_gain})
    if len(gain_models) > 1:
        counts = collections.Counter(e.tempgain_model_sha256
                                     for e in with_gain)
        raise SystemExit(
            "this set carries " + str(len(gain_models)) + " different "
            "temperature-gain models: "
            + ", ".join(f"{sha[:12] or '<unrecorded>'} ({counts[sha]} "
                        f"epoch(s))" for sha in gain_models)
            + ". Re-run stage 2 with --force over the whole set.")

    # Schema 1 has photodiode/side/ACM multiplied into the pixels and schema 2
    # has nothing in them, so one set of both would be reduced under one
    # policy and be wrong for half of it -- by exactly the factors, which is
    # the size of what is being measured.
    schemas = sorted({e.calibration_schema for e in epochs
                      if e.stage == "calibrated"})
    if len(schemas) > 1:
        raise SystemExit(
            f"this set mixes calibrated-product schemas {schemas}: schema 1 "
            f"has the factors in its pixels, schema 2 records them instead. "
            f"Re-run stage 2 with --force over the whole set.")

    # The recorded bridges follow the gain's three legal states. They are
    # only checked here, never applied -- the digest fits its own -- but a
    # set that carries some is a set someone will apply them to.
    with_bridge = [e for e in epochs if "side_bridge" in e.steps
                   or "acm_bridge" in e.steps]
    if with_bridge and len(with_bridge) != len(epochs):
        raise SystemExit(
            f"{len(with_bridge)} of {len(epochs)} epoch(s) carry recorded "
            f"bridges and the rest do not. Re-run stage 2 over the whole set "
            f"with the same --bridge-solution, or over none of it.")
    solutions = sorted({e.bridge_solution_sha256 for e in with_bridge})
    if len(solutions) > 1:
        raise SystemExit(
            f"this set carries {len(solutions)} different bridge solutions. "
            f"Re-run stage 2 with --force over the whole set.")

    assumed = [e.name for e in epochs
               if str(e.mce_side_source).startswith("assumed")]
    if assumed:
        print(f"  NOTE: {len(assumed)} epoch(s) have an assumed, not a "
              f"recorded, MCE side; the per-LED B-side corrections are 1.5-6 %")

    return kinds[0] if len(kinds) == 1 else "mixed"


def calibration_families(epochs):
    """Group ``epochs`` by L2 calibration, in time order.

    Returns a list of dicts, one per contiguous run of epochs sharing a
    :attr:`Epoch.calibration_key`.  Contiguous, not merely grouped, because
    what matters downstream is *where in time* the configuration changes: that
    is the index at which a per-SCA step appears, and a family that recurs
    after an interruption produces two steps, not none.
    """
    families = []
    for position, epoch in enumerate(epochs):
        key = epoch.calibration_key
        if families and families[-1]["key"] == key:
            families[-1]["epochs"].append(epoch)
            families[-1]["last"] = position
            continue
        families.append({"key": key, "first": position, "last": position,
                         "epochs": [epoch]})
    for family in families:
        prov = family["epochs"][0].l2_calibration or {}
        family["n"] = len(family["epochs"])
        family["ref_file_id"] = str(prov.get("ref_file_id", ""))
        family["klass"] = (calibration_class(family["ref_file_id"])
                           if family["key"] is not None else None)
        family["describe"] = (rcs_l2_source.describe_provenance(prov)
                              if family["key"] is not None
                              else "calibration not recorded in the product")
        family["source"] = str(family["epochs"][0].l2_source or "")
    return families


def assert_homogeneous_calibration(epochs, allow_mixed=False):
    """Refuse a set whose L2 inputs were flux-calibrated differently.

    This is the one inhomogeneity the rest of the pipeline cannot see.  Every
    correction here is applied *to* the L2 rates, so a change in how those
    rates were produced passes straight through into the trend, and it does so
    as a per-SCA multiplicative step -- the same shape as a real instrument
    event, at a comparable size.

    Measured on this dataset: the 2026-09-24 Roman reprocessing changed the
    ``photom`` reference from 0040 to 0080, and the resulting per-SCA step is
    -2.28 % to +3.08 %, 1.787 % rms.  It lands at CAR-190 pass 1|2 (1.23 % rms)
    and again at the 0067->0072 changeover (1.55 % rms, one epoch after an ACM
    move and exactly at a decon label change, which is what made it look like
    physics).  Its signature is that it is *achromatic*: across-LED spread
    0.028 % against a 1.787 % per-SCA amplitude, 64:1.  A film reset is
    chromatic, because each LED sits at a different point on the fringe.

    An epoch whose product predates provenance recording has no key at all.
    Those are reported but never refused -- refusing them would reject every
    product built before ``rcs_l2_source`` existed, including the regression
    set this pipeline is checked against.
    """
    families = calibration_families(epochs)
    unrecorded = [f for f in families if f["key"] is None]
    recorded = [f for f in families if f["key"] is not None]

    if not recorded:
        print(f"  NOTE: no epoch records its L2 calibration "
              f"({len(epochs)} epoch(s)); a reference-file change upstream "
              f"would be invisible here. Re-stage to record it.")
        return families

    classes = sorted({f["klass"] for f in recorded})
    print(f"  L2 calibration: {len(recorded)} recorded "
          f"configuration-run(s) in {len(classes)} equivalence class(es)"
          + (f", {sum(f['n'] for f in unrecorded)} epoch(s) unrecorded"
             if unrecorded else ""))
    for family in families:
        span = (f"epoch {family['first'] + 1}"
                if family["n"] == 1
                else f"epochs {family['first'] + 1}-{family['last'] + 1}")
        origin = f" [{family['source']}]" if family["source"] else ""
        print(f"    {span:>16s} ({family['n']:3d}){origin}  "
              f"{family['describe']}")

    # A software change under the same reference files is in one class by
    # construction (the classes are keyed on the reference files), so nothing
    # below would mention it. romancal 1.0.2 -> 1.0.3 at CAR-216 p5.23
    # (2026-11-03) arrived that way; code can move pixels on its own.
    for before, after in zip(recorded, recorded[1:]):
        old = str((before["epochs"][0].l2_calibration or {}).get(
            "calibration_software_version", ""))
        new = str((after["epochs"][0].l2_calibration or {}).get(
            "calibration_software_version", ""))
        if not (before["ref_file_id"] == after["ref_file_id"] and old and new
                and old != new):
            continue
        measured = MEASURED_SOFTWARE_CHANGES.get(
            (after["ref_file_id"], old, new))
        if measured:
            print(f"  L2 software {old} -> {new} at epoch {after['first'] + 1} "
                  f"under the same reference files: {measured}")
        else:
            print(f"  NOTE: L2 software {old} -> {new} at epoch "
                  f"{after['first'] + 1} ({after['epochs'][0].name}) with the "
                  f"same reference files ({after['ref_file_id']}): no class "
                  f"change, but code can change pixels. Measure it once "
                  f"(DATA_PULL.md, 'Read the run log's L2 calibration "
                  f"block'), then record it in "
                  f"rcs_trend_config.MEASURED_SOFTWARE_CHANGES.")

    if unrecorded and recorded:
        print(f"  WARNING: this set mixes epochs that record their L2 "
              f"calibration with {sum(f['n'] for f in unrecorded)} that do "
              f"not, so homogeneity cannot be established for the whole set. "
              f"Re-stage the unrecorded epochs.")

    if len(classes) == 1:
        if len(recorded) > 1:
            print(f"  all recorded configurations are in declared equivalence "
                  f"class '{classes[0]}' (see "
                  f"rcs_trend_config.CALIBRATION_EQUIVALENCE), so the "
                  f"changeovers carry no flux step")
        return families

    # The boundary, not the count, is the actionable part: it is the index at
    # which the artifact step sits, and it is what a reader of the trend plot
    # needs in order to not believe it.
    boundaries = []
    for earlier, later in zip(recorded, recorded[1:]):
        if earlier["klass"] != later["klass"]:
            boundaries.append(
                f"{later['epochs'][0].name} (epoch {later['first'] + 1}, "
                f"{later['epochs'][0].timestamp:%Y-%m-%dT%H:%M}): "
                f"{earlier['klass']} -> {later['klass']}")
    message = (
        f"this set spans {len(classes)} L2 calibration equivalence classes, "
        f"changing over at:\n    " + "\n    ".join(boundaries)
        + "\n  Each changeover puts a per-SCA achromatic step in the trend "
          "(measured at 1.2-1.8 % rms on this dataset) that no correction "
          "here removes, because it is upstream of all of them. If an id is "
          "new rather than a known-different family, find out what moved and "
          "whether the trend sees it: 'trend_change_check.py refdiff <pass "
          "before> <pass after>', then 'steptest' (README.md, 'roman_0075'). "
          "Otherwise re-stage the older epochs from a reprocessing that "
          "matches -- see README.md, 'Rebuilding passes from a local L2 "
          "reprocessing' -- or pass --allow-mixed-calibration to proceed with "
          "a known step in the output.")
    if not allow_mixed:
        raise SystemExit(f"  {message}")
    print(f"  WARNING: {message}")
    return families


def assert_chronological(epochs):
    """Refuse a set whose epochs are not in time order.

    Every cross-epoch quantity in this file is positional: ``find_acm_moves``
    differences neighbouring LVDTs, ``acm_segments`` turns those differences
    into configurations, and the bridge fits each boundary from the epochs
    adjoining it.  Hand it the same epochs in a different order and it answers a
    different question without saying so.

    This is not hypothetical and the failure is not small.  ``discover_h5_files``
    sorts by timestamp, but a caller who reaches for ``sorted(os.listdir(...))``
    instead gets *alphabetical* order, which separates CAR190 from CAR216 --
    and the two programs interleave in time.  On the 176-epoch flight set that
    turns the real LVDT sequence (one deploy, two repositions, 4 segments) into
    an apparent 4 moves and 5 segments, and ``decon_evidence`` then goes from
    "the labelled decon stands 1.8x clear of the floor" to "nothing in this run
    clears the floor".  Both runs print a full, confident report.
    """
    stamps = [e.timestamp for e in epochs]
    backwards = [index for index in range(1, len(stamps))
                 if stamps[index] < stamps[index - 1]]
    if not backwards:
        return
    first = backwards[0]
    raise SystemExit(
        f"this set is not in time order: epoch {first + 1} "
        f"({epochs[first].name}, {stamps[first]}) precedes epoch {first} "
        f"({epochs[first - 1].name}, {stamps[first - 1]}), and "
        f"{len(backwards)} such inversion(s) are present. Every ACM move, "
        f"segment and bridge step here is found by differencing neighbouring "
        f"epochs, so a mis-ordered set yields a different segmentation and a "
        f"different answer, reported just as confidently. Use "
        f"discover_h5_files(), which sorts by timestamp; alphabetical filename "
        f"order is not time order once CAR190 and CAR216 are both present.")


def read_file_list(path):
    """Epoch filenames from a list file, ignoring blanks and ``#`` comments."""
    lines = Path(path).read_text().splitlines()
    names = [line.strip() for line in lines]
    return [n for n in names if n and not n.startswith("#")]


#: ``--stage`` values and the h5 ``stage`` attribute each selects. ``cal`` is
#: the default because a calibrated product's arrays already carry the per-LED
#: scalars, so a digest built from them is reproducible from the product alone
#: without re-deriving a reference card.
STAGE_CHOICES = {"cal": "calibrated", "raw": "raw", "legacy": "legacy",
                 "auto": None}


def discover_h5_files(data_root, stage="auto", quiet=False, assume_side=None):
    """Every matching ``*.h5`` directly under ``data_root``, time-ordered.

    Used when ``--file-list`` is not given: ``process_rcs_trending.py`` and the
    SLURM batch harness (``batch/``) write one h5 per run straight into a
    shared output directory, named for provenance (program/pass/date) rather
    than for order, and CAR-190 and CAR-216 runs can land in the same
    directory. So, exactly like the hand-curated file-list case, the actual
    epoch order comes from each file's own timestamp, not its name -- read
    with a metadata-only pass so this stays cheap even for a large directory.
    The earliest becomes the reference epoch, same convention as the file list.

    Selection is on the ``stage`` **attribute**, never the filename suffix: a
    product renamed by hand must still be classified correctly, and one
    directory can legitimately hold raw, calibrated and legacy files side by
    side. ``stage="auto"`` takes whichever single stage is present and refuses
    a directory holding more than one -- silently picking would mix reductions
    that differ at the size of the signal.
    """
    wanted = STAGE_CHOICES.get(stage, stage)
    paths = sorted(Path(data_root).glob("*.h5"))
    found = []
    for ind, path in enumerate(paths):
        try:
            meta = rcs_products.read_metadata(str(path))
        except Exception as error:                        # noqa: BLE001
            if not quiet:
                print(f"  skip {path.name}: unreadable ({error})")
            continue
        found.append((meta["stage"], path, ind))

    present = sorted({stage_name for stage_name, _, _ in found})
    if wanted is None:
        if len(present) > 1:
            raise SystemExit(
                f"{data_root} holds more than one product stage {present}. "
                f"Pass --stage explicitly: mixing a calibrated with a raw or "
                f"legacy product would put a step in the trend the size of "
                f"the corrections themselves.")
        wanted = present[0] if present else None

    selected = [(path, ind) for stage_name, path, ind in found
                if stage_name == wanted]
    if not selected and present:
        raise SystemExit(
            f"{data_root} holds no stage={wanted!r} products; it holds "
            f"{present}. Discovery keys on the h5 'stage' attribute.")

    dated = [(Epoch.metadata_only(path, sequence_number=ind + 1,
                                  assume_side=assume_side).timestamp,
              path.name) for path, ind in selected]
    dated.sort(key=lambda pair: pair[0])

    return [name for _, name in dated]


# ---------------------------------------------------------------------------
# Corrections and per-epoch response
# ---------------------------------------------------------------------------

def acm_correction(epoch, reference_lvdt, corr):
    """Response change from ACM moves about its configuration's mean position.

    ``reference_lvdt`` must come from the same ACM configuration as ``epoch``;
    the linear form is not valid across a reconfiguration.
    """
    if not corr.acm:
        return 1.0
    travel = (epoch.acm_lvdt + epoch.acm_offset) / reference_lvdt - 1.0
    return 1.0 + epoch.acm_coefficient * travel


def led_scale_factors(epoch, reference, reference_lvdt, corr):
    """Scalar applied to each LED's raw mosaic ratio, keyed by LED name.

    An LED whose ``pd_net`` the product marked invalid gets NaN, not a skipped
    photodiode correction.  ``pd_net`` is the denominator here: a collapsed one
    near the 0.01 V floor produces a factor of tens, and leaving the correction
    off instead would quietly emit an uncorrected point in a corrected series.
    NaN propagates into the digest and is counted; 1.0 would not be.
    """
    acm = acm_correction(epoch, reference_lvdt, corr)
    epoch_valid = epoch.photodiode_valid
    reference_valid = reference.photodiode_valid
    factors = {}
    for ind, led in enumerate(LED_NAMES):
        factor = 1.0 / acm
        if corr.photodiode:
            usable = ((epoch_valid is None or epoch_valid[ind])
                      and (reference_valid is None or reference_valid[ind]))
            factor *= (reference.photodiode[ind] / epoch.photodiode[ind]
                       if usable else np.nan)
        if corr.side and epoch.is_b_side:
            factor *= B_SIDE_CORRECTIONS[led]
        factors[led] = factor
    return factors


def relative_response(epoch, reference, reference_lvdt, masks, corr,
                      recorded=None):
    """Corrected per-SCA response of ``epoch`` relative to ``reference``.

    Returns ``{led_name: {sca_name: value}}``.  The corrections are per-LED
    scalars, so they commute with the median and can be applied to the ratio
    array before reducing it -- which is also why a schema-1 *calibrated*
    product, whose arrays already carry the scalar, gives the identical answer.

    ``recorded`` is the schema-2 path: ``(n_led, n_sca)`` of this epoch's
    recorded per-file multiplier divided by the reference epoch's, applied to
    each SCA plane of the ratio before the median. A per-SCA scalar commutes
    with that plane's median exactly as a per-LED one does, so this equals
    the schema-1 answer to float32 rounding -- the multiplier was applied to
    float32 pixels there and to a float64 ratio here.

    ``masks`` is used only for a mosaic product and may be ``None`` for a
    per-SCA one: each plane of a stack already holds exactly one detector, so
    there are no footprints to derive and no straddling superpixels to inset.
    """
    factors = led_scale_factors(epoch, reference, reference_lvdt, corr)

    if epoch.product_kind == "per_sca":
        if recorded is not None:
            return {
                led: per_sca_reduce(
                    epoch.stacks[led] / reference.stacks[led]
                    * factors[led] * recorded[ind][:, None, None],
                    np.nanmedian)
                for ind, led in enumerate(LED_NAMES)
            }
        return {
            led: per_sca_reduce(
                epoch.stacks[led] / reference.stacks[led] * factors[led],
                np.nanmedian)
            for led in LED_NAMES
        }

    return {
        led: median_per_sca(
            epoch.mosaics[led] / reference.mosaics[led] * factors[led], masks
        )
        for led in LED_NAMES
    }


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------

@dataclass
class TrendSeries:
    """Per-SCA response for every epoch, before and after bridging."""
    names: list
    timestamps: list
    pass_numbers: np.ndarray                # (n_epoch,)
    car_labels: list                        # (n_epoch,) "CAR190"/"CAR216"/"" per epoch
    decon_cycles: list                      # (n_epoch,) "decon1"/"decon2"/"" per epoch
    time_hours: np.ndarray                  # (n_epoch,)
    acm_lvdt: np.ndarray                    # (n_epoch,)
    segment: np.ndarray                     # (n_epoch,) ACM configuration index
    raw: dict                               # sca -> (n_epoch, n_led)
    moves: list = field(default_factory=list)  # list[AcmMove], one per reconfiguration
    move_min_delta: float = ACM_MOVE_MIN_DELTA  # |dLVDT| that opened a new segment
    max_fractional_travel: float = 0.0      # worst LVDT travel from a segment ref
    reference_lvdt: dict = field(default_factory=dict)  # segment -> reference LVDT
    steps: dict = field(default_factory=dict)    # sca -> list[BridgeStep], one per boundary
    factors: dict = field(default_factory=dict)  # sca -> (n_epoch,)
    scans: dict = field(default_factory=dict)    # sca -> bridge_sensitivity grid
    accepted: dict = field(default_factory=dict)  # sca -> {boundary: surviving scan keys}
    systematic: dict = field(default_factory=dict)  # sca -> {boundary: step spread}
    # How the inputs were made. Recorded because the per-SCA and mosaic
    # reductions differ by ~0.1 %, so a digest is only comparable to another
    # digest built from the same product shape at the same bin.
    product_kind: str = "mosaic"
    stage: str = "legacy"
    bin_factor: int = 20
    mce_sides: list = field(default_factory=list)   # (n_epoch,) "A"/"B"
    # (n_epoch,) "attribute" / "filename:_MCE[AB]" / "assumed" / ...  The side
    # is only as good as where it came from, and the two are indistinguishable
    # downstream unless both travel together.
    mce_side_sources: list = field(default_factory=list)
    # Which scalars are in the numbers, wherever they were applied -- here for
    # a raw/legacy set, at stage 2 for a calibrated one. What the digest
    # reports has to be this, not the CLI flags, or a calibrated set would be
    # labelled uncorrected.
    corrections_applied: tuple = ()
    corrections_applied_at: str = "digest"
    # Which photodiode path produced the denominators, and which epochs the
    # product flagged. The flagged list is part of the digest's meaning: those
    # LEDs are NaN by decision, not by absence of data.
    photodiode_source: str = "dictionary"
    photodiode_flagged: tuple = ()
    # Contiguous runs of epochs sharing one L2 calibration, from
    # ``calibration_families``. Carried on the series rather than recomputed by
    # each consumer because it is the only record of an inhomogeneity that is
    # upstream of every correction here, and the bands in
    # digest_plots.plot_run_structure are drawn from it.
    calibration_families: list = field(default_factory=list)
    # The recorded-not-applied temperature-gain multipliers, ``sca ->
    # (n_epoch, n_led)``, or an empty dict when no product carried a block.
    # Empty is the signal everything downstream branches on: no corrected
    # columns, no corrected figure, no meta family -- rather than a family of
    # unity columns that would be indistinguishable from a model that happened
    # to fit a flat gain.
    tempgain: dict = field(default_factory=dict)
    tempgain_model: str = ""
    tempgain_model_sha256: str = ""
    tempgain_form: str = ""
    tempgain_mnemonic: str = ""
    # The MCE side bridge: one SideStep per side change, and the resulting
    # (n_epoch, n_led) multiplier in the PRESENT gauge (the latest side is 1).
    # None until apply_side_bridge runs, and None for a one-side set -- which
    # response() then treats as unity, so a one-side digest is unchanged.
    side_steps: list = field(default_factory=list)
    side_factors: np.ndarray = None
    side_spec: object = None
    # Schema 2 with a bridge solution recorded: {"acm": {sca: (n_epoch,)},
    # "side": (n_epoch, n_led), "sha256": str}. Read only to check the
    # products against this run's own fit; the fit is what is applied.
    recorded_bridges: dict = field(default_factory=dict)
    bridge_solution_check: str = ""
    calibration_schema: int = 0
    # The card every product was calibrated against (assert_homogeneous
    # refuses more than one), recorded in a bridge solution so stage 2 can
    # refuse to record steps fitted under a different card.
    reference_card_sha256: str = ""

    @property
    def side_display(self):
        """``(n_epoch, n_led)`` side multiplier gauged to the reference epoch.

        The products record the side bridge present-nominal (side B is 1, side
        A is scaled up to it). The digest is a variation-since-pass-1 curve,
        so it divides epoch 0's row out: side A reads 1, side B reads
        ``1 / step``. Same corrected data, one constant per LED apart.
        """
        if self.side_factors is None or self.side_factors.size == 0:
            return np.ones((len(self.time_hours), len(LED_NAMES)))
        return self.side_factors / self.side_factors[0][None, :]

    @property
    def n_segments(self):
        return int(self.segment.max()) + 1

    @property
    def boundaries(self):
        """Epoch index of the first epoch of each segment after the first."""
        return segment_boundaries(self.segment)

    @property
    def side_boundaries(self):
        """Boundaries that are MCE side changes, as ``{boundary: "A->B"}``.

        Derived from ``mce_sides`` rather than stored, so it cannot disagree
        with the sides the digest reports. A side boundary is read differently
        from an ACM boundary: the step across it mixes a real detector change
        with a photodiode swap, so a large per-LED spread there is evidence of
        the swap rather than of fit noise.
        """
        if not self.mce_sides:
            return {}
        sides = [normalize_side(side) for side in self.mce_sides]

        return {int(b): f"{sides[b - 1]}->{sides[b]}"
                for b in self.boundaries
                if 0 < b < len(sides) and sides[b] != sides[b - 1]}

    @property
    def deploys(self):
        """Backwards-compatible view: only the moves that cross zero.

        The ACM also repositions within the deployed side, and those moves need
        bridging just as much, so ``moves`` is what the pipeline works from.
        """
        return [m for m in self.moves if m.crosses_zero]

    def response(self, sca):
        """Bridged response for one SCA, ``(n_epoch, n_led)``.

        Both bridges: the per-SCA achromatic ACM factor and the per-LED,
        SCA-common side factor, each gauged so the reference epoch reads 1.
        """
        return self.raw[sca] * self.factors[sca][:, None] * self.side_display

    def tempgain_ratio(self, sca):
        """The gain factor actually applied to the corrected column.

        ``(n_epoch, n_led)``, equal to ``m[i] / m[0]`` -- the *ratio* of this
        epoch's multiplier to the reference epoch's, not the multiplier
        itself.

        The ratio, not the multiplier, because the digest's gauge is already
        set: :func:`relative_response` divides every epoch by epoch 0, so the
        canonical column is exactly 1.0 at pass 1 by construction. Dividing
        out the absolute gain would move pass 1 off 1.0 and rescale the whole
        series by a constant -- which is the hardest kind of error to see,
        because the result is smooth, plausible and wrong by a flat factor
        everywhere. Carrying the ratio keeps the gauge where the rest of the
        digest puts it, and the absolute multiplier is still in the
        ``tempgain_reference_multiplier`` meta for anyone who wants to re-gauge.

        A consequence worth stating: this removes the *change* in gain since
        pass 1, and pass 1's own gain offset is left in, exactly as the
        canonical column leaves pass 1's film state in.
        """
        multiplier = self.tempgain[sca]
        return multiplier / multiplier[0, :][None, :]

    def response_tgcorr(self, sca):
        """Bridged response with the modelled gain change divided out.

        Exactly 1.0 at pass 1, for the same reason :meth:`response` is.
        """
        return self.response(sca) * self.tempgain_ratio(sca)

    def bridge_methods(self, sca):
        """How each boundary's step was obtained, for one SCA."""
        return [step.method for step in self.steps.get(sca, [])]


def _corrections_for_stage(paths, epochs, corr):
    """``(apply_here, effective)`` -- don't re-apply what the product carries.

    A calibrated product's arrays have the photodiode/side/ACM factors
    multiplied in already, so applying them again here would **square** each
    one. That is the most dangerous failure mode of the two-stage split because
    the result looks entirely plausible: a photodiode factor of 1.002 applied
    twice is 1.004, and the whole signal being measured is a fraction of a
    percent per pass. So the product's ``stage`` decides, and the override is
    announced rather than silent.

    ``effective`` is what was applied *somewhere*, read back from the product's
    ``corrections_applied`` attribute rather than assumed. The distinction
    matters for reporting: a set calibrated with ``--no-acm`` must not be
    described as ACM-corrected, because that is what suppresses the
    fractional-travel warning on data that genuinely needs it.

    What the digest still does for a calibrated product is the cross-epoch work
    no per-file stage can: the ratio to the reference epoch, and the bridge
    across ACM reconfigurations.
    """
    stages = {epoch.stage for epoch in epochs}
    if "calibrated" not in stages:
        return corr, corr

    if len(stages) > 1:
        raise SystemExit(
            f"this set mixes {sorted(stages)}. A calibrated product carries "
            f"the per-epoch scalars in its pixels and a raw one does not, so "
            f"one set cannot be reduced under one correction policy. Pass "
            f"--stage to pick one.")

    if {epoch.calibration_schema for epoch in epochs} == {2}:
        # Schema 2: nothing is in the pixels, and corrections_applied is
        # empty on purpose. What this digest applies is what every product
        # recorded, and it applies it here -- in relative_response, from the
        # products' own multipliers, never re-derived.
        recorded = set.intersection(*[{name for name in ("photodiode", "acm")
                                       if name in epoch.steps}
                                      for epoch in epochs])
        print(f"  stage='calibrated', schema 2: applying the recorded "
              f"{', '.join(sorted(recorded)) or 'no'} step(s) from each "
              f"product; the bridges are fitted here, as always, and the "
              f"products' recorded bridges are only checked against them.")
        return (Corrections(photodiode=False, side=False, acm=False),
                Corrections(photodiode="photodiode" in recorded, side=False,
                            acm="acm" in recorded))

    carried = set()
    for path in paths:
        applied = rcs_products.read_metadata(str(path))["attrs"].get(
            "corrections_applied", "")
        carried |= {name for name in str(applied).split(",") if name}
    effective = Corrections(photodiode="photodiode" in carried,
                            side="side" in carried, acm="acm" in carried)

    print(f"  stage='calibrated': the {', '.join(sorted(carried)) or 'no'} "
          f"scalar(s) are already in the arrays and are NOT re-applied here. "
          f"Applying one twice squares it, and a photodiode factor of 1.002 "
          f"applied twice is indistinguishable from a real 0.2 % response "
          f"change.")
    print("  the digest still does the cross-epoch work no per-file stage "
          "can: the ratio to the reference epoch and the ACM bridge.")

    return Corrections(photodiode=False, side=False, acm=False), effective


def side_change_indices(meta):
    """0-based indices of epochs whose MCE side differs from the previous one.

    Positional, like every other cross-epoch quantity in this file, so the
    caller must already have the epochs in time order. A thin wrapper over
    :func:`rcs_acm.side_change_indices`, which the reference card also uses,
    so the two stages agree on where a configuration starts.

    This is a segment boundary even though the LVDT does not move: the B
    electronics read the ACM with a different offset per channel, so the
    linear ACM term must be referenced within the side. The step across it is
    NOT an ACM step -- it is bridged by the per-LED, SCA-common side step
    (:func:`apply_side_bridge`), and the ACM step there is fixed at 1.
    """
    return _side_changes([epoch.mce_side for epoch in meta])


def build_series(data_root, file_names, corr, verbose=True,
                 move_min_delta=ACM_MOVE_MIN_DELTA, require_sign_change=False,
                 assume_side=None, allow_mixed_product_kind=False,
                 pd_from_product=True, segment_breaks=(),
                 allow_mixed_calibration=False):
    """Load every epoch and reduce it to per-SCA response, before bridging.

    A cheap metadata-only first pass finds every ACM reconfiguration, so each
    epoch's linear ACM correction can be referenced to its own configuration
    rather than extrapolated across a move.

    Several moves are expected, not an error: the flight trend deploys the ACM
    once and then repositions it twice more on the deployed side.  Pass
    ``move_min_delta=ACM_DEPLOY_MIN_DELTA, require_sign_change=True`` to
    reproduce the pre-2026-10 single-deploy segmentation.
    """
    data_root = Path(data_root)
    paths = [data_root / name for name in file_names]

    meta = [Epoch.metadata_only(p, sequence_number=ind + 1,
                                assume_side=assume_side,
                                pd_from_product=pd_from_product)
            for ind, p in enumerate(paths)]
    kind = assert_homogeneous(
        meta, allow_mixed_product_kind=allow_mixed_product_kind)
    assert_chronological(meta)
    # After the time-order check, because the families it reports are
    # *contiguous runs* and that is only meaningful once the epochs are in
    # order; out of order, one configuration would be reported as several.
    cal_families = assert_homogeneous_calibration(
        meta, allow_mixed=allow_mixed_calibration)
    corr, effective = _corrections_for_stage(paths, meta, corr)
    acm_lvdt = np.array([e.acm_lvdt for e in meta])
    acm_offsets = np.array([e.acm_offset for e in meta])

    # 1-based on the CLI, 0-based here: every report in this file numbers epochs
    # from 1, so the flag does too, and the conversion happens once.
    extra = [int(n) - 1 for n in segment_breaks]
    # An MCE side change is a segment boundary even though the LVDT never moves.
    # It has to be, because the photodiode behind the correction is a different
    # physical device on each side: bridging straight through would stitch a
    # chromatic diode offset into the trend, where it is indistinguishable from
    # film growth. See PD_CORRECTION.md section 8.
    side_breaks = side_change_indices(meta)
    for index in side_breaks:
        print(f"  MCE SIDE CHANGE at epoch {index + 1}: "
              f"{normalize_side(meta[index - 1].mce_side)} -> "
              f"{normalize_side(meta[index].mce_side)}; a segment break so "
              f"the linear ACM term is referenced within the side, and the "
              f"step across it goes to the side bridge, not the ACM bridge")
    extra = sorted(set(extra) | set(side_breaks))
    moves = label_side_moves(
        find_acm_moves(acm_lvdt, min_delta=move_min_delta,
                       require_sign_change=require_sign_change,
                       extra_breaks=extra),
        [e.mce_side for e in meta])
    segment = acm_segments(len(meta), moves)
    references = segment_reference_lvdt(acm_lvdt, segment, acm_offsets)
    max_travel = acm_max_travel(acm_lvdt, segment, acm_offsets, references)

    # Not gated on `verbose`: --quiet suppresses per-epoch output, but how many
    # ACM configurations were found changes what the digests mean, so it is
    # always announced.
    # ``effective``, not ``corr``: for a calibrated set the ACM correction was
    # applied at stage 2, and reporting it as absent would make the
    # fractional-travel warning fire on data that is already corrected.
    report_acm_configuration(moves, acm_lvdt, file_names, max_travel,
                             acm_applied=effective.acm, segment=segment)

    for early, late, lvdt_early, lvdt_late in closure_checks(acm_lvdt, segment):
        print(f"  CLOSURE TEST available: segments {early} and {late} sit at "
              f"the same LVDT ({lvdt_early:+.1f}, {lvdt_late:+.1f});")
        print(f"        the composed bridge across them must read 1.0 if the "
              f"ACM effect is purely geometric.")

    reference = Epoch.from_hdf5(paths[0], sequence_number=1,
                                assume_side=assume_side,
                                pd_from_product=pd_from_product)
    if verbose:
        print(f"\nreference epoch {reference.name} at "
              f"{reference.timestamp.isoformat()}")

    # Footprint masks are a mosaic-only construct, and deriving them is also the
    # expensive part of a legacy run (a point-in-polygon test over 1.26 M mosaic
    # pixels x 18 SCAs). A per-SCA product skips it entirely.
    masks = None
    if kind == "per_sca":
        side = reference.stacks[LED_NAMES[0]].shape[-1]
        scas = [sca_name(ind) for ind in range(N_SCAS)]
        if verbose:
            print(f"per-SCA stacks, {N_SCAS} x {side} x {side} at bin "
                  f"{reference.bin_factor}; no footprints needed")
    else:
        mosaic_shape = reference.mosaics[LED_NAMES[0]].shape
        if verbose:
            print(f"mosaic shape {mosaic_shape}, building SCA footprints")
        masks = sca_footprint_masks(mosaic_shape)
        scas = list(masks)

    # Schema 2: the per-file steps each product recorded, as (n_led, n_sca),
    # divided by the reference epoch's. Taken from the metadata pass, which
    # reads the calibration/ group without touching a pixel.
    schema2 = bool(meta) and all(e.calibration_schema == 2 for e in meta)
    per_file = None
    if schema2:
        per_file = []
        for e in meta:
            grid = np.ones((len(LED_NAMES), N_SCAS))
            for name in ("photodiode", "acm"):
                if getattr(effective, name):
                    grid = grid * e.steps[name]
            per_file.append(grid)
        with np.errstate(divide="ignore", invalid="ignore"):
            per_file = [grid / per_file[0] for grid in per_file]

    rows = {sca: [] for sca in scas}
    for ind, path in enumerate(paths):
        epoch = reference if ind == 0 else Epoch.from_hdf5(
            path, sequence_number=ind + 1, assume_side=assume_side,
            pd_from_product=pd_from_product)
        response = relative_response(
            epoch, reference, references[int(segment[ind])], masks, corr,
            recorded=None if per_file is None else per_file[ind]
        )
        for sca in scas:
            rows[sca].append([response[led][sca] for led in LED_NAMES])
        if verbose:
            print(f"  {epoch.name}  seg {segment[ind]}  "
                  f"t = {(epoch.timestamp - reference.timestamp).total_seconds() / 3600.:8.3f} h"
                  f"  SCA1 = {' '.join(f'{v:.5f}' for v in rows['SCA1'][-1])}")

    unannotated = [e.name for e in meta if not e.car_label or not e.decon_cycle]
    if unannotated:
        print(f"  WARNING: {len(unannotated)} epoch(s) have no car_label/"
              f"decon_cycle h5 attribute (pre-dates process_rcs_trending's "
              f"annotate_h5, or a non-flight source), e.g. {unannotated[0]!r}")

    # Always announced, like the ACM configuration count: an epoch with a
    # flagged pd_net has NaN for that LED in every SCA, and a reader who did not
    # know why would see it as missing data rather than as a rejected
    # correction.  Only the keyed photodiode group can report this at all.
    flagged = [(e.name, [LED_NAMES[i] for i in range(len(LED_NAMES))
                         if e.photodiode_valid is not None
                         and not e.photodiode_valid[i]]) for e in meta]
    flagged = [(name, leds) for name, leds in flagged if leds]
    # ``effective``, not ``corr``: on a schema-2 set ``corr`` is all-off (the
    # factors come from the products) but the photodiode IS applied, and its
    # NaNs are exactly what this warning exists to explain.
    if flagged and (corr.photodiode or effective.photodiode):
        print(f"  WARNING: {len(flagged)} epoch(s) have a photodiode reading "
              f"the product flagged invalid; those LEDs are NaN here, not "
              f"left uncorrected:")
        for name, leds in flagged[:5]:
            print(f"    {name}: {', '.join(leds)}")
    pd_sources = sorted({e.photodiode_source for e in meta})
    if verbose and pd_sources != ["dictionary"]:
        print(f"  photodiode read from {', '.join(pd_sources)}")

    # Assembled from the metadata pass, not from the pixel loop: the block is
    # 108 floats and is read by both passes, so taking it here keeps it beside
    # the homogeneity check that validated it. ``assert_homogeneous`` has
    # already refused a partial or multi-model set, so this is all-or-nothing
    # and the empty dict is a reliable "no model was in play" signal.
    tempgain = {}
    if meta[0].tempgain is not None:
        # [:, ind] of an (n_led, n_sca) grid, stacked over epochs, gives the
        # (n_epoch, n_led) that matches the shape of raw[sca] -- so the ratio
        # multiplies the response elementwise with no broadcasting to get
        # wrong.
        tempgain = {sca: np.array([e.tempgain[:, ind] for e in meta],
                                  dtype=float)
                    for ind, sca in enumerate(SCA_NAMES) if sca in scas}
        if verbose:
            print(f"  temperature-gain block present: "
                  f"{meta[0].tempgain_form} from "
                  f"{meta[0].tempgain_model} "
                  f"({meta[0].tempgain_model_sha256[:12]}); recorded in the "
                  f"products, applied here to the _tgcorr columns only")

    # Recorded bridges, for the check against this run's own fit. The ACM
    # step is achromatic, so row 0 of its (n_led, n_sca) grid is the step;
    # the side step is SCA-common, so column 0 is.
    recorded_bridges = {}
    if schema2 and all("acm_bridge" in e.steps and "side_bridge" in e.steps
                       for e in meta):
        recorded_bridges = {
            "acm": {sca: np.array([e.steps["acm_bridge"][0, SCA_NAMES.index(sca)]
                                   for e in meta]) for sca in scas},
            "side": np.array([e.steps["side_bridge"][:, 0] for e in meta]),
            "sha256": meta[0].bridge_solution_sha256,
        }
        if verbose:
            print(f"  bridge solution recorded in the products "
                  f"({meta[0].bridge_solution_sha256[:12]}); it will be "
                  f"checked against this run's fit, not applied in its place")

    return TrendSeries(
        recorded_bridges=recorded_bridges,
        reference_card_sha256=str(meta[0].reference_card_sha256),
        calibration_schema=2 if schema2 else (
            1 if reference.stage == "calibrated" else 0),
        names=list(file_names),
        timestamps=[e.timestamp for e in meta],
        pass_numbers=np.array([e.pass_number for e in meta]),
        car_labels=[e.car_label for e in meta],
        decon_cycles=[e.decon_cycle for e in meta],
        time_hours=np.array([(e.timestamp - reference.timestamp).total_seconds() / 3600.
                             for e in meta]),
        acm_lvdt=acm_lvdt,
        segment=segment,
        raw={sca: np.array(values, dtype=float) for sca, values in rows.items()},
        moves=moves,
        move_min_delta=float(move_min_delta),
        max_fractional_travel=max_travel,
        reference_lvdt=references,
        product_kind=kind,
        stage=reference.stage,
        bin_factor=int(reference.bin_factor),
        mce_sides=[e.mce_side for e in meta],
        # Carried beside the side itself because the side alone cannot be
        # audited: "A" from an attribute and "A" from --assume-side produce
        # identical digests, and only one of them is a measurement.
        mce_side_sources=[e.mce_side_source for e in meta],
        corrections_applied=tuple(
            name for name, on in (("photodiode", effective.photodiode),
                                  ("side", effective.side),
                                  ("acm", effective.acm)) if on),
        corrections_applied_at=(
            "digest, from the factors each product recorded (schema 2)"
            if schema2 else "calibration (stage 2)"
            if reference.stage == "calibrated" else "digest"),
        photodiode_source=", ".join(pd_sources),
        photodiode_flagged=tuple(name for name, _ in flagged),
        calibration_families=cal_families,
        tempgain=tempgain,
        tempgain_model=meta[0].tempgain_model,
        tempgain_model_sha256=meta[0].tempgain_model_sha256,
        tempgain_form=meta[0].tempgain_form,
        tempgain_mnemonic=meta[0].tempgain_mnemonic,
    )


def apply_bridge(series, spec, verbose=True):
    """Solve and apply the bridge for every SCA, filling ``steps`` and ``factors``.

    Every boundary is handled independently.  A boundary the joint fit cannot
    solve -- too few epochs on one side, which is the normal case for a segment
    the trend only visits once -- falls back to the linear LVDT multiplier
    rather than to unity, so a known geometric step is modelled instead of being
    left in the output.  ``BridgeStep.method`` records which happened.
    """
    boundaries = series.boundaries

    if not spec.enabled or not boundaries:
        if boundaries:
            # Not gated on `verbose`: leaving known steps in the response is too
            # consequential to report only in the chatty mode.
            print(f"\nWARNING: {len(boundaries)} ACM reconfiguration(s) were "
                  "found but bridging is disabled; those steps are left in the "
                  "output")
        for sca in series.raw:
            series.steps[sca] = []
            series.factors[sca] = np.ones(len(series.time_hours))
        return series

    gauge_lvdt = deployed_gauge_lvdt(series.acm_lvdt, series.segment)

    if verbose:
        normalization = ("reference epoch renormalized to 1.0"
                         if spec.gauge == "reference"
                         else "deployed segment left at its measured scale")
        print(f"\nbridging {len(boundaries)} ACM reconfiguration(s) onto the "
              f"deployed scale, degree {spec.degree}, "
              f"window +-{spec.window_hours} h")
        print(f"  gauge '{spec.gauge}': {normalization}")
        print(f"  linear fallback gauged at LVDT {gauge_lvdt:+.1f}"
              if spec.allow_multiplier else
              "  linear fallback disabled; unfittable boundaries stay at 1.0")

    fell_back = {boundary: [] for boundary in boundaries}
    side_boundaries = series.side_boundaries
    for sca in sorted_scas(series.raw):
        steps = []
        for boundary in boundaries:
            if boundary in side_boundaries:
                # Not an ACM step. A side change is a segment boundary only so
                # the linear ACM term is referenced within the side (the B
                # electronics read the LVDT with a per-channel offset). The
                # step across it is chromatic and SCA-common, and is fitted by
                # apply_side_bridge; a per-SCA freedom here would let the swap
                # change the illumination pattern, and would double-count.
                boundary_time = 0.5 * (series.time_hours[boundary - 1]
                                       + series.time_hours[boundary])
                steps.append(BridgeStep(
                    boundary=boundary, boundary_time=boundary_time, value=1.0,
                    stat_error=0.0, per_led=np.array([]),
                    rms_early=float("nan"), rms_late=float("nan"),
                    n_epochs_used=0, n_early=0, n_late=0, method="side",
                    note=(f"MCE side change {side_boundaries[boundary]}: "
                          f"bridged by the per-LED SCA-common side step, "
                          f"not per SCA")))
                continue
            try:
                steps.append(fit_bridge_step(series.raw[sca], series.time_hours,
                                             series.segment, boundary, spec,
                                             decon=series.decon_cycles))
            except (ValueError, np.linalg.LinAlgError) as error:
                # Three distinct causes, all routed here: a segment with fewer
                # than two epochs (nothing to separate step from trend); an
                # SCA with no usable epochs on one side at all (sparse SCA
                # downlink coverage in the earliest passes); and a window that
                # a decon transition trims below two epochs a side, or a
                # boundary sitting on a transition, which is degenerate. None
                # is a reason to abandon this SCA's other boundaries, and the
                # raised message becomes the recorded note either way.
                step = fallback_step(
                    series.acm_lvdt, series.time_hours, series.segment,
                    boundary, series.moves, gauge_lvdt=gauge_lvdt,
                    note=str(error))
                if not spec.allow_multiplier and step.method == "multiplier":
                    step = replace(step, value=1.0, method="none",
                                   note=f"{step.note}; multiplier disabled")
                steps.append(step)
                fell_back[boundary].append(sca)
        series.steps[sca] = steps
        series.factors[sca] = bridge_factors(series.segment, steps, spec.gauge)

    for index, boundary in enumerate(boundaries):
        report_boundary(series, boundaries, index, fell_back[boundary],
                        verbose=verbose)

    report_closure(series)
    return series


def report_closure(series):
    """Composed bridge across every same-LVDT segment pair; 1.0 if the model holds.

    A test of the geometric-ACM assumption against the data, not an internal
    consistency check -- but only where at least one of the intervening steps was
    actually fitted. Where every step came from the linear model closure is exact
    by construction (one shared gauge), so it is reported as such rather than
    passed off as a measurement.
    """
    scas = [sca for sca in sorted_scas(series.raw) if series.steps.get(sca)]
    if not scas:
        return
    for index, (early, late, lvdt_early, _) in enumerate(
            closure_checks(series.acm_lvdt, series.segment)):
        products, fitted = [], False
        for sca in scas:
            results = closure_residuals(series.acm_lvdt, series.segment,
                                        series.steps[sca])
            products.append(results[index][4])
            fitted |= any(series.steps[sca][seg].is_fitted
                          for seg in range(early, late))
        products = np.array(products)
        if not np.isfinite(products).any():
            continue
        print(f"\nCLOSURE: segments {early} and {late} are both at LVDT "
              f"~{lvdt_early:+.1f}, so the composed bridge across them must "
              f"read 1.0")
        print(f"         measured {np.nanmin(products):.5f}-"
              f"{np.nanmax(products):.5f} across {len(scas)} SCA(s), worst "
              f"departure {100 * np.nanmax(np.abs(products - 1.0)):.3f}%")
        if not fitted:
            print("         (every intervening step came from the linear model "
                  "on one shared gauge, so this closes by construction and "
                  "tests nothing yet; it becomes a real test once a segment "
                  "between them has 2+ epochs)")


def report_boundary(series, boundaries, index, fell_back, verbose=True):
    """One summary block for a single ACM boundary, across all SCAs."""
    boundary = boundaries[index]
    move = next((m for m in series.moves if m.index == boundary), None)
    kind = move.kind if move is not None else "unknown"
    steps = {sca: series.steps[sca][index] for sca in sorted_scas(series.raw)
             if len(series.steps[sca]) > index}
    methods = sorted({step.method for step in steps.values()})

    print(f"\n  boundary {index + 1}/{len(boundaries)} at epoch {boundary + 1} "
          f"({series.names[boundary]}): {kind}, method(s) {'+'.join(methods)}")
    if fell_back:
        print(f"    {len(fell_back)} of {len(steps)} SCA(s) could not be "
              f"fitted: {', '.join(fell_back)}")
        example = steps[fell_back[0]]
        print(f"      -> {example.method} {example.value:.5f} ({example.note})")

    fitted = {sca: step for sca, step in steps.items() if step.is_fitted}
    if not fitted:
        return
    values = [step.value for step in fitted.values()]
    worst_spread = max(step.led_spread for step in fitted.values())
    print(f"    fitted {min(values):.5f}-{max(values):.5f} across "
          f"{len(fitted)} SCA(s), worst per-LED spread "
          f"{worst_spread:.5f}")
    print(f"    residual scatter: early side "
          f"{min(s.rms_early for s in fitted.values()) * 1e5:.0f}-"
          f"{max(s.rms_early for s in fitted.values()) * 1e5:.0f}e-5, late side "
          f"{min(s.rms_late for s in fitted.values()) * 1e5:.0f}-"
          f"{max(s.rms_late for s in fitted.values()) * 1e5:.0f}e-5")
    if verbose:
        print(f"    {'SCA':>6} {'bridge':>9} {'stat':>9} {'rms early/1e5':>14} "
              f"{'rms late/1e5':>13} {'LED spread':>11} {'n':>4}")
        for sca, step in steps.items():
            print(f"    {sca:>6} {step.value:9.5f} {step.stat_error:9.5f} "
                  f"{step.rms_early * 1e5:14.1f} {step.rms_late * 1e5:13.1f} "
                  f"{step.led_spread:11.5f} {step.n_epochs_used:4d}"
                  f"  {'' if step.is_fitted else step.method}")


def _unbridged_side_step(series, boundary, note):
    """A side step left at 1.0 because it could not be fitted, saying why."""
    n_led, n_sca = len(LED_NAMES), len(series.raw)
    nan = np.full(n_led, np.nan)
    sides = [normalize_side(side) for side in series.mce_sides]
    return SideStep(
        boundary=int(boundary),
        boundary_time=float(0.5 * (series.time_hours[boundary - 1]
                                   + series.time_hours[boundary])),
        transition=f"{sides[boundary - 1]}->{sides[boundary]}",
        value=np.ones(n_led), stat_error=nan, empirical_error=nan,
        per_sca=np.full((n_sca, n_led), np.nan),
        sca_names=sorted_scas(series.raw),
        pattern_offset=np.full(n_sca, np.nan), pattern_rms=float("nan"),
        pattern_noise=float("nan"), rms_early=float("nan"),
        rms_late=float("nan"), n_early=0, n_late=0, n_sca=0,
        degree=0, window_hours=0.0, method="none", note=note)


def apply_side_bridge(series, spec, verbose=True):
    """Fit and apply the per-LED, SCA-common step at every MCE side change.

    Run after :func:`apply_bridge`: the input is the ACM-bridged response, so an
    ACM move elsewhere in the window cannot leak into the side step. The
    photodiode in that input is re-based to 1 at the first epoch of each side
    (the card's per-side reference), so the step absorbs the photodiode swap
    along with the electronics and the LED drive -- the A diode cannot be tied
    to the B diode any other way, they are different devices.

    A side change the fit cannot solve is left at 1.0, method ``"none"``, and
    announced unconditionally: the swap is then still in the output at its
    full chromatic size.
    """
    series.side_spec = spec
    side_boundaries = series.side_boundaries
    if not side_boundaries:
        series.side_steps, series.side_factors = [], None
        return series
    if not spec.enabled:
        print(f"\nWARNING: {len(side_boundaries)} MCE side change(s) found but "
              f"the side bridge is disabled; the swap is left in the output")
        series.side_steps = [_unbridged_side_step(series, b, "disabled")
                             for b in sorted(side_boundaries)]
        series.side_factors = side_bridge_factors(
            len(series.time_hours), series.side_steps)
        return series

    bridged = {sca: series.raw[sca] * series.factors[sca][:, None]
               for sca in series.raw}
    steps = []
    for boundary in sorted(side_boundaries):
        try:
            step = fit_side_step(bridged, series.time_hours, series.mce_sides,
                                 boundary, spec, decon=series.decon_cycles)
            systematic, n_accepted, _ = side_sensitivity(
                bridged, series.time_hours, series.mce_sides, boundary, spec,
                decon=series.decon_cycles)
            step.systematic = systematic
            step.n_choices = int(n_accepted)
        except (ValueError, np.linalg.LinAlgError) as error:
            print(f"\nWARNING: the side change at epoch {boundary + 1} "
                  f"({series.names[boundary]}) could not be bridged: {error}. "
                  f"It is left at 1.0, so the swap stays in the output at its "
                  f"full chromatic size.")
            step = _unbridged_side_step(series, boundary, str(error))
        steps.append(step)

    series.side_steps = steps
    series.side_factors = side_bridge_factors(len(series.time_hours), steps)
    for step in steps:
        report_side_bridge(series, step, verbose=verbose)
    return series


def report_side_bridge(series, step, verbose=True):
    """The side step, its errors, and the illumination-pattern test."""
    print(f"\n  MCE SIDE BRIDGE {step.transition} at epoch {step.boundary + 1} "
          f"({series.names[step.boundary]}): method {step.method}")
    if step.method != "side":
        print(f"    not fitted ({step.note}); the swap is in the output")
        return
    print(f"    one step per LED, common to all {step.n_sca} SCAs, fitted "
          f"against each (SCA, LED)'s own degree-{step.degree} trend over "
          f"+-{step.window_hours:g} h ({step.n_early} early / {step.n_late} "
          f"late epochs)")
    print("    gauge: the present side is 1, and the early side is MULTIPLIED "
          "by the step; the digest shows it divided by its pass-1 value")
    print(f"    {'LED':>6} {'step':>9} {'stat':>9} {'SCA scat':>9} "
          f"{'syst':>9} {'total':>9} {'ground 1/B':>11}")
    total = step.total_error
    systematic = (step.systematic if step.systematic is not None
                  else np.full(len(LED_NAMES), np.nan))
    for ind, led in enumerate(LED_NAMES):
        print(f"    {led:>6} {step.value[ind]:9.5f} {step.stat_error[ind]:9.5f} "
              f"{step.empirical_error[ind]:9.5f} {systematic[ind]:9.5f} "
              f"{total[ind]:9.5f} {1.0 / B_SIDE_CORRECTIONS[led]:11.5f}")
    print(f"    systematic from {step.n_choices} accepted fit choice(s) of "
          f"degree x window; 'ground 1/B' is the TVAC table in this gauge, "
          f"for comparison only -- it covers the detector electronics alone, "
          f"while this step also carries the LED drive and the photodiode")
    ratio = step.pattern_ratio
    verdict = ("consistent with no change in the illumination pattern"
               if np.isfinite(ratio) and ratio < 3.0 else
               "LARGER than noise: the swap may have changed the "
               "illumination pattern, which an SCA-common step cannot absorb"
               if np.isfinite(ratio) else "not testable")
    print(f"    pattern test: per-SCA achromatic offset rms "
          f"{step.pattern_rms * 1e5:.1f}e-5 against "
          f"{step.pattern_noise * 1e5:.1f}e-5 expected from noise "
          f"({ratio:.2f}x) -- {verdict}")
    if verbose:
        worst = np.argsort(-np.abs(np.nan_to_num(step.pattern_offset)))[:3]
        print("    largest per-SCA offsets: " + ", ".join(
            f"{step.sca_names[i]} {step.pattern_offset[i] * 1e5:+.1f}e-5"
            for i in worst))


def check_recorded_bridges(series, tolerance=1e-9):
    """Do the products carry the bridges this run fitted? Sets the verdict.

    The second stage-2 pass records a solution without moving a pixel or
    changing a per-file factor, so a digest built from those products fits
    bit-identical input and must return the same steps. Compared in the
    reference gauge on both sides -- each normalized by its own epoch 0 --
    so the check does not depend on --bridge-gauge.
    """
    recorded = series.recorded_bridges
    if not recorded:
        series.bridge_solution_check = (
            "absent" if series.calibration_schema == 2 else "not applicable")
        return series.bridge_solution_check

    worst = 0.0
    for sca in series.raw:
        mine = series.factors[sca] / series.factors[sca][0]
        theirs = recorded["acm"][sca] / recorded["acm"][sca][0]
        worst = max(worst, float(np.nanmax(np.abs(theirs / mine - 1.0))))
    side = recorded["side"] / recorded["side"][0][None, :]
    worst = max(worst,
                float(np.nanmax(np.abs(side / series.side_display - 1.0))))

    sha = recorded["sha256"][:12]
    if worst <= tolerance:
        series.bridge_solution_check = f"current ({sha}, max |diff| {worst:.1e})"
        print(f"\n  bridge solution check: the products carry the solution "
              f"this run fits ({sha}; max |relative difference| {worst:.1e})")
    else:
        series.bridge_solution_check = f"STALE ({sha}, max |diff| {worst:.2e})"
        print(f"\nWARNING: the products carry a bridge solution ({sha}) that "
              f"differs from this run's fit by up to {worst:.2e}. The digests "
              f"use this run's fit; re-run stage 2 with --bridge-solution from "
              f"this run's --solution-out so the products match "
              f"(run_trend.py does both).")
    return series.bridge_solution_check


def bridge_solution(series, spec, side_spec):
    """This run's bridges as a :class:`rcs_bridge_solution.BridgeSolution`."""
    rows = []
    stamps = series.timestamps
    moves = {m.index: m for m in series.moves}
    for sca in sorted_scas(series.raw):
        number = int(sca[3:])
        for step in series.steps.get(sca, []):
            b = int(step.boundary)
            systematic = float(series.systematic.get(sca, {}).get(b, np.nan))
            # NaN kept, as the digest's bridge_step_errors keeps it: a
            # fallback step has no fit error, which is not the same as zero.
            stat = float(step.stat_error)
            rows.append({
                "kind": rcs_bridge_solution.KIND_ACM, "boundary_index": b + 1,
                "boundary_run_label": series.names[b],
                "boundary_utc": rcs_bridge_solution.midpoint(stamps[b - 1],
                                                             stamps[b]),
                "transition": (series.side_boundaries[b]
                               if b in series.side_boundaries
                               else moves[b].kind if b in moves else ""),
                "sca": number, "led": "ALL", "value": float(step.value),
                "stat_error": stat, "systematic": systematic,
                "total_error": float(np.hypot(np.nan_to_num(stat),
                                              np.nan_to_num(systematic))),
                "method": step.method, "n_early": int(step.n_early),
                "n_late": int(step.n_late), "note": step.note or "",
                "led_spread": float(step.led_spread),
                "rms_early": float(step.rms_early),
                "rms_late": float(step.rms_late),
                "lvdt_before": (float(moves[b].lvdt_before) if b in moves
                                else float("nan")),
                "lvdt_after": (float(moves[b].lvdt_after) if b in moves
                               else float("nan"))})
    for step in series.side_steps:
        b = int(step.boundary)
        utc = rcs_bridge_solution.midpoint(stamps[b - 1], stamps[b])
        systematic = (step.systematic if step.systematic is not None
                      else np.full(len(LED_NAMES), np.nan))
        total = step.total_error
        for ind, led in enumerate(LED_NAMES):
            rows.append({
                "kind": rcs_bridge_solution.KIND_SIDE, "boundary_index": b + 1,
                "boundary_run_label": series.names[b], "boundary_utc": utc,
                "transition": step.transition, "sca": 0, "led": led,
                "value": float(step.value[ind]),
                "stat_error": float(step.stat_error[ind]),
                "systematic": float(systematic[ind]),
                "total_error": float(np.nan_to_num(total[ind])),
                "method": step.method, "n_early": int(step.n_early),
                "n_late": int(step.n_late), "note": step.note or "",
                "sca_scatter_error": float(step.empirical_error[ind]),
                "rms_early": float(step.rms_early),
                "rms_late": float(step.rms_late),
                "pattern_rms": float(step.pattern_rms),
                "pattern_noise": float(step.pattern_noise)})
        # Each SCA's own reading, for the pattern test. Not applied.
        for row, name in enumerate(step.sca_names):
            for ind, led in enumerate(LED_NAMES):
                rows.append({
                    "kind": rcs_bridge_solution.KIND_SIDE_SCA,
                    "boundary_index": b + 1,
                    "boundary_run_label": series.names[b], "boundary_utc": utc,
                    "transition": step.transition, "sca": int(name[3:]),
                    "led": led, "value": float(step.per_sca[row, ind]),
                    "method": "pattern_test",
                    "note": "this SCA's own step; NOT applied",
                    "pattern_offset": float(step.pattern_offset[row])})
    return rcs_bridge_solution.BridgeSolution(rows=rows, meta={
        "source": "make_sca_digests.py --solution-out",
        "reference_card_sha256": series.reference_card_sha256,
        "n_epochs": len(series.names),
        "first_epoch": series.names[0], "last_epoch": series.names[-1],
        "acm_bridge_degree": int(spec.degree),
        "acm_bridge_window_hours": float(spec.window_hours),
        "acm_bridge_gauge_in_digests": str(spec.gauge),
        "acm_move_min_delta_lvdt": float(series.move_min_delta),
        "side_bridge_degree": int(side_spec.degree),
        "side_bridge_window_hours": float(side_spec.window_hours),
        # Per side change, so a reader of one product can quote how many fit
        # choices backed the systematic.
        "side_bridge_n_choices": [int(s.n_choices) for s in series.side_steps],
    })


def estimate_systematics(series, spec, verbose=True,
                         degrees=(1, 2, 3),
                         windows=(15.0, 20.0, 25.0, 30.0, 40.0, None)):
    """Per-SCA bridge systematic from the spread over accepted fit choices.

    The least-squares error only covers the noise at the epochs used,
    nothing about having picked the wrong evolution model to extrapolate across
    the gap. 
    """
    boundaries = series.boundaries
    if not spec.enabled or not boundaries:
        return series

    for sca in sorted_scas(series.raw):
        scan = bridge_sensitivity(series.raw[sca], series.time_hours,
                                  series.segment, spec, degrees, windows,
                                  decon=series.decon_cycles)
        series.scans[sca] = scan
        series.accepted[sca] = {}
        series.systematic[sca] = {}
        for index, boundary in enumerate(boundaries):
            if boundary in series.side_boundaries:
                # No ACM step is fitted there (it is fixed at 1); its
                # systematic is the side bridge's, carried on the SideStep.
                series.accepted[sca][boundary] = []
                series.systematic[sca][boundary] = float("nan")
                continue
            # A fit choice that fails at one boundary can succeed at another, so
            # each boundary is screened against its own noise floors rather than
            # the first boundary's.
            accepted, spread = screen_sensitivity(
                scan,
                boundary_floors(series.raw[sca], series.time_hours,
                                series.segment, boundary),
                boundary_index=index)
            series.accepted[sca][boundary] = accepted
            series.systematic[sca][boundary] = spread

    if verbose:
        n_choices = len(degrees) * len(windows)
        print(f"\nbridge systematic from the fit-choice scan, per boundary "
              f"(of {n_choices} choices):")
        for index, boundary in enumerate(boundaries):
            if boundary in series.side_boundaries:
                print(f"  boundary {index + 1} (epoch {boundary + 1}): MCE "
                      f"side change, no ACM step; see the side bridge")
                continue
            values = [series.systematic[s][boundary] for s in series.systematic
                      if np.isfinite(series.systematic[s].get(boundary, np.nan))]
            counts = [len(series.accepted[s].get(boundary, ()))
                      for s in series.accepted]
            fitted = [s[index] for s in series.steps.values()
                      if len(s) > index and s[index].is_fitted]
            label = (f"  boundary {index + 1} (epoch {boundary + 1}): "
                     f"{min(counts)}-{max(counts)} choices survive")
            if values and fitted:
                print(f"{label}; systematic {min(values):.5f}-{max(values):.5f} "
                      f"({100 * max(values):.3f}% of response at worst), "
                      f"vs stat {max(f.stat_error for f in fitted):.5f}")
            elif not fitted:
                print(f"{label}; no SCA was fitted here (linear fallback), so "
                      "the scan has nothing to spread over")
            else:
                print(f"{label}; no SCA had an accepted fit choice, see the "
                      "per-SCA WARNINGs above")
            starved = [s for s in sorted_scas(series.accepted)
                       if not series.accepted[s].get(boundary)]
            if starved and fitted:
                print(f"    WARNING: no fit choice reaches the noise floor for "
                      f"{', '.join(starved)}; their bridge is model-limited")
    return series


# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------

def write_digests(series, out_dir, corr, spec, data_root):
    """One ``time_series_<SCA>.ecsv`` per SCA, with provenance in the metadata."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # From the series, not from ``corr``: for a calibrated product the scalars
    # were applied at stage 2 and ``corr`` here is all-off, so reading the CLI
    # flags would label a fully corrected digest as uncorrected.
    applied = list(series.corrections_applied) or [
        name for name, on in (("photodiode", corr.photodiode),
                              ("side", corr.side),
                              ("acm", corr.acm)) if on]
    created = datetime.now(timezone.utc).isoformat()
    # astropy's isot format carries no offset; the utc scale records the zone.
    stamps = Time([t.replace(tzinfo=None).isoformat() for t in series.timestamps],
                  format="isot", scale="utc")

    # The decon episodes, from the shared helper so the digest, the run
    # structure figure and the run log cannot disagree about where one film
    # ends and the next begins. Contiguous runs, not a grouping by label: a
    # label that recurs after an intervening decon is a new film.
    episodes = decon_episodes(series.decon_cycles)
    hours = np.asarray(series.time_hours, dtype=float)
    decon_time = np.empty(len(hours), dtype=float)
    for episode in episodes:
        decon_time[episode["epochs"]] = (
            hours[episode["epochs"]] - hours[episode["first"]])

    written = []
    for sca in sorted_scas(series.raw):
        response = series.response(sca)
        factors = series.factors[sca]

        table = Table()
        table["time_hours"] = series.time_hours * u.hour
        table["time_hours"].description = "Hours since the reference epoch"
        table["timestamp"] = stamps
        table["pass_number"] = series.pass_numbers
        table["pass_number"].description = (
            "RCS pass number parsed from the epoch filename, or the file's "
            "1-based position in the list if the filename carries no pass field")
        table["car_label"] = series.car_labels
        table["car_label"].description = (
            "CAR190 or CAR216, from process_rcs_trending's annotate_h5; empty "
            "for epochs that predate that annotation")
        table["decon_cycle"] = series.decon_cycles
        table["decon_cycle"].description = (
            "decon cycle (e.g. decon1/decon2) passed to process_rcs_trending "
            "for this epoch; empty for epochs that predate that annotation")
        # Hours since this epoch's own decon episode began. A convenience
        # origin for per-episode film-growth work (see PER_DECON_NORM.md);
        # time_hours is deliberately left on the global reference epoch,
        # because every bridge_* quantity in this metadata is measured in it.
        table["decon_time_hours"] = decon_time * u.hour
        table["decon_time_hours"].description = (
            "Hours since the first epoch of this epoch's decon episode; "
            "equals time_hours within the first episode. Convenience origin "
            "only -- the response columns are still gauged to the global "
            "reference epoch, not to each episode's t=0")
        for ind, led in enumerate(LED_NAMES):
            table[led] = response[:, ind]
            table[led].description = f"Bridged relative response for {led}"
        # Conditional, so a digest built from products with no gain block is
        # byte-identical to one written before this family existed. The
        # canonical LED columns above stay gain-free on purpose: every fit in
        # this activity reads them, including the temperature-gain fit itself,
        # which would otherwise be reading its own output.
        if series.tempgain:
            corrected = series.response_tgcorr(sca)
            ratio = series.tempgain_ratio(sca)
            for ind, led in enumerate(LED_NAMES):
                table[f"{led}_tgcorr"] = corrected[:, ind]
                table[f"{led}_tgcorr"].description = (
                    f"{led} with the modelled temperature-gain CHANGE since "
                    f"the reference epoch divided out; equals "
                    f"{led} * tempgain_{led} exactly")
            for ind, led in enumerate(LED_NAMES):
                table[f"tempgain_{led}"] = ratio[:, ind]
                table[f"tempgain_{led}"].description = (
                    f"Gain factor applied to {led}_tgcorr: the ratio "
                    f"m[i]/m[0] of this epoch's recorded multiplier to the "
                    f"reference epoch's, so it is exactly 1.0 in row 0. "
                    f"Multiply tempgain_reference_multiplier to recover the "
                    f"absolute 1/G(T) this epoch was assigned")
        table["bridge_factor"] = factors
        table["bridge_factor"].description = (
            "ACM bridge applied to this epoch; divide to recover the raw ratio")
        # Conditional, like the gain family: a one-side set has no side
        # bridge and gets no columns, so its digest keeps its old layout.
        if series.side_steps:
            display = series.side_display
            for ind, led in enumerate(LED_NAMES):
                table[f"side_bridge_{led}"] = display[:, ind]
                table[f"side_bridge_{led}"].description = (
                    f"MCE side bridge applied to {led}, gauged to the "
                    f"reference epoch (1.0 on the reference epoch's side); "
                    f"divide to undo. The same on every SCA")
        table["acm_lvdt"] = series.acm_lvdt
        table["acm_lvdt"].description = "Mean ACM LVDT position for the epoch"
        table["acm_segment"] = series.segment
        table["acm_segment"].description = (
            "ACM configuration index; increments at every detected ACM move, "
            "not only at the stowed->deployed deploy")

        table.meta["description"] = f"Time series of relative RCS response for {sca}"
        table.meta["sca_name"] = sca
        table.meta["n_epochs"] = len(series.time_hours)
        table.meta["time_range_hours"] = [float(series.time_hours[0]),
                                          float(series.time_hours[-1])]
        table.meta["data_root"] = str(data_root)
        table.meta["reference_epoch"] = series.names[0]
        table.meta["epoch_files"] = list(series.names)
        # The two product shapes reduce by different routes and their medians
        # differ at ~0.1 %, so which one produced a digest is part of the
        # digest's meaning, not provenance trivia: two digests are only
        # comparable if these three agree.
        table.meta["product_kind"] = series.product_kind
        table.meta["product_stage"] = series.stage
        table.meta["bin_factor"] = int(series.bin_factor)
        table.meta["processing"] = (
            "Per-SCA nanmedian of the per-SCA stack ratio to the reference "
            "epoch (one stack plane per detector, no footprints)"
            if series.product_kind == "per_sca" else
            "Per-SCA nanmedian inside each SCA footprint of the mosaic ratio "
            "to the reference epoch")
        table.meta["corrections"] = ", ".join(applied) if applied else "none"
        table.meta["corrections_applied_at"] = series.corrections_applied_at
        table.meta["photodiode_source"] = series.photodiode_source
        table.meta["photodiode_flagged_epochs"] = list(series.photodiode_flagged)
        table.meta["mce_sides_present"] = sorted(
            {side for side in series.mce_sides if side})
        table.meta["n_acm_segments"] = series.n_segments
        table.meta["car_labels_present"] = sorted(
            {label for label in series.car_labels if label})
        table.meta["decon_cycles_present"] = sorted(
            {cycle for cycle in series.decon_cycles if cycle})
        # The episode bounds, recorded so that anyone re-gauging a decon cycle
        # onto its own t=0 in post-processing does not have to re-derive them --
        # and, more to the point, does not derive them by grouping on the label,
        # which merges two different films whenever a cycle name recurs. 1-based
        # inclusive, matching acm_move_epoch_indices. See PER_DECON_NORM.md.
        table.meta["decon_n_episodes"] = len(episodes)
        table.meta["decon_episode_bounds"] = [
            [int(e["first"] + 1), int(e["last"] + 1)] for e in episodes]
        table.meta["decon_episode_labels"] = [
            e["key"] or "unlabelled" for e in episodes]
        # Keyed by position, not by label: under contiguous-run semantics a
        # label can own more than one episode, so a label->epoch dict would
        # silently drop all but one of them.
        table.meta["decon_reference_epochs"] = [
            series.names[e["first"]] for e in episodes]
        table.meta["decon_episode_note"] = (
            "Episodes are contiguous runs of one decon_cycle label, so a label "
            "that recurs after an intervening decon opens a new episode rather "
            "than extending the earlier one. The response columns are gauged "
            "to reference_epoch throughout, NOT per episode; to re-gauge, "
            "divide each episode's LED columns by its own first row "
            "(decon_reference_epochs). See PER_DECON_NORM.md.")

        # Whether the set spans a move decides whether a bridge exists at all, so
        # it is recorded explicitly rather than left implied by n_acm_segments.
        # The deploy keys are kept, now as the subset of moves that cross zero,
        # so an existing consumer keeps reading what it read before.
        table.meta["acm_deploy_detected"] = bool(series.deploys)
        table.meta["acm_n_moves"] = len(series.moves)
        table.meta["acm_move_min_delta_lvdt"] = float(series.move_min_delta)
        # Kept so digests written before and after the multi-boundary change
        # carry the same keys, but it is history, not configuration: a deploy is
        # now the move that crosses zero, whatever its size, and the threshold
        # this run actually used is acm_move_min_delta_lvdt above. Do not read
        # this one as "the detection threshold" -- it no longer selects anything.
        table.meta["acm_deploy_min_delta_lvdt"] = float(ACM_DEPLOY_MIN_DELTA)
        table.meta["acm_deploy_min_delta_note"] = (
            "Historical threshold only; deploys are now classified by the zero "
            "crossing. See acm_move_min_delta_lvdt for this run's threshold.")
        table.meta["acm_max_fractional_travel"] = float(series.max_fractional_travel)
        table.meta["acm_segment_reference_lvdt"] = [
            float(series.reference_lvdt[seg])
            for seg in sorted(series.reference_lvdt)]
        if series.moves:
            table.meta["acm_move_epochs"] = [series.names[m.index]
                                             for m in series.moves]
            table.meta["acm_move_epoch_indices"] = [int(m.index + 1)
                                                    for m in series.moves]
            table.meta["acm_move_kinds"] = [m.kind for m in series.moves]
            # A manual break is an assertion about the instrument that the
            # telemetry does not support, so it is recorded as such: a reader
            # must be able to tell which boundaries the LVDT actually showed.
            table.meta["acm_move_manual"] = [bool(m.manual)
                                             for m in series.moves]
            table.meta["acm_move_lvdt_before"] = [float(m.lvdt_before)
                                                  for m in series.moves]
            table.meta["acm_move_lvdt_after"] = [float(m.lvdt_after)
                                                 for m in series.moves]
            table.meta["acm_move_delta_lvdt"] = [float(m.delta)
                                                 for m in series.moves]
        else:
            table.meta["acm_move_note"] = (
                "No ACM move in this trend set, so all epochs are one ACM "
                "configuration and no bridge was solved or applied; the "
                "bridge_* keys are absent rather than zero")
        if series.deploys:
            deploy = series.deploys[0]
            table.meta["acm_deploy_epoch"] = series.names[deploy.index]
            table.meta["acm_deploy_epoch_index"] = int(deploy.index + 1)
            table.meta["acm_deploy_lvdt_before"] = float(deploy.lvdt_before)
            table.meta["acm_deploy_lvdt_after"] = float(deploy.lvdt_after)
            table.meta["acm_deploy_delta_lvdt"] = float(deploy.delta)
        if series.max_fractional_travel > ACM_TRAVEL_WARN:
            table.meta["acm_travel_note"] = (
                "The linear ACM correction is extrapolated beyond the small "
                "perturbation it was fit as; see acm_max_fractional_travel")

        steps = series.steps[sca]
        # A step of method "none" is a boundary left at 1.0, which is exactly
        # "no bridge applied" -- so it must not flip this flag to True.
        table.meta["bridge_applied"] = bool(
            spec.enabled and any(s.method != "none" for s in steps))
        if steps:
            table.meta["bridge_gauge"] = spec.gauge
            table.meta["bridge_degree"] = spec.degree
            table.meta["bridge_window_hours"] = float(spec.window_hours)
            table.meta["bridge_steps"] = [float(s.value) for s in steps]
            # Per boundary, so a consumer can tell a measured step from one the
            # linear LVDT model supplied where the joint fit had too few epochs.
            table.meta["bridge_method"] = [s.method for s in steps]
            table.meta["bridge_method_note"] = (
                "bridge = joint log-space fit; multiplier = linear LVDT model "
                "on the shared deployed gauge; none = left at 1.0")
            # Why, not just what. A 'multiplier' has several possible causes and
            # they do not license the same interpretation: too few epochs in the
            # window is a cadence accident that more data may fix, whereas a
            # decon transition at the boundary is degenerate in principle and
            # never will be. The note is the message the fitter raised, so it
            # cannot drift out of step with the reason the fallback happened.
            table.meta["bridge_notes"] = [s.note or "" for s in steps]
            # The fit-quality keys only exist for a fitted step. If this SCA had
            # none fitted they are omitted entirely rather than written as NaN,
            # so a consumer that needs them (bridge_noise.py) fails on the
            # missing key instead of quietly carrying a NaN error bar through.
            if any(s.is_fitted for s in steps):
                table.meta["bridge_step_errors"] = [float(s.stat_error) for s in steps]
                table.meta["bridge_led_spread"] = [float(s.led_spread) for s in steps]
                table.meta["bridge_rms_pre"] = [float(s.rms_early) for s in steps]
                table.meta["bridge_rms_post"] = [float(s.rms_late) for s in steps]
            # The ACM step at a side boundary is fixed at 1 (method "side");
            # the swap itself is bridged by the side_bridge_* family below.
            if any(s.is_fitted for s in steps) and series.systematic.get(sca):
                spreads = [float(series.systematic[sca].get(s.boundary, np.nan))
                           for s in steps]
                # bridge_systematic stays a scalar because bridge_noise.py and
                # fit_film_rank1.py both do float(meta["bridge_systematic"]);
                # it is the worst boundary, with the per-boundary list alongside.
                table.meta["bridge_systematic"] = (
                    float(np.nanmax(spreads)) if np.isfinite(spreads).any()
                    else float("nan"))
                table.meta["bridge_systematic_per_boundary"] = spreads
                table.meta["bridge_systematic_note"] = (
                    "Spread of the step over fit choices the residuals accept; "
                    "add in quadrature with bridge_step_errors. The scalar is "
                    "the worst boundary. NaN has TWO causes and they are not "
                    "interchangeable: either the boundary took the linear "
                    "fallback (bridge_method 'multiplier'), which has no "
                    "fit-choice spread to quote, or it was fitted and NO fit "
                    "choice survived screening, so the step is model-limited "
                    "and its uncertainty is unquantified rather than small. "
                    "Read bridge_method to tell them apart, and treat "
                    "bridge_method 'bridge' with a NaN systematic as the less "
                    "trustworthy of the two")
            table.meta["bridge_boundary_epochs"] = [series.names[s.boundary]
                                                    for s in steps]
        # The side bridge. Present only when the set spans a side change.
        if series.side_steps:
            fitted = [s for s in series.side_steps if s.method == "side"]
            table.meta["side_bridge_applied"] = bool(fitted)
            table.meta["side_bridge_epoch_indices"] = [
                int(s.boundary + 1) for s in series.side_steps]
            table.meta["side_bridge_epochs"] = [
                series.names[s.boundary] for s in series.side_steps]
            table.meta["side_bridge_transitions"] = [
                s.transition for s in series.side_steps]
            table.meta["side_bridge_method"] = [
                s.method for s in series.side_steps]
            table.meta["side_bridge_led_names"] = list(LED_NAMES)

            def _per_led(values):
                return [float(v) for v in np.asarray(values, dtype=float)]

            table.meta["side_bridge_steps"] = [
                _per_led(s.value) for s in series.side_steps]
            table.meta["side_bridge_stat_errors"] = [
                _per_led(s.stat_error) for s in series.side_steps]
            table.meta["side_bridge_sca_scatter_errors"] = [
                _per_led(s.empirical_error) for s in series.side_steps]
            table.meta["side_bridge_systematic"] = [
                _per_led(s.systematic if s.systematic is not None
                         else np.full(len(LED_NAMES), np.nan))
                for s in series.side_steps]
            table.meta["side_bridge_total_errors"] = [
                _per_led(s.total_error) for s in series.side_steps]
            table.meta["side_bridge_n_early"] = [
                int(s.n_early) for s in series.side_steps]
            table.meta["side_bridge_n_late"] = [
                int(s.n_late) for s in series.side_steps]
            table.meta["side_bridge_degree"] = [
                int(s.degree) for s in series.side_steps]
            table.meta["side_bridge_window_hours"] = [
                float(s.window_hours) for s in series.side_steps]
            table.meta["side_bridge_pattern_rms"] = [
                float(s.pattern_rms) for s in series.side_steps]
            table.meta["side_bridge_pattern_noise"] = [
                float(s.pattern_noise) for s in series.side_steps]
            # This SCA's own reading at each swap: its independent per-LED
            # steps and how far its achromatic level sits from the common
            # step. The common step is what is applied; these are the test.
            row = {name: i for i, name in enumerate(series.side_steps[0].sca_names)}
            table.meta["side_bridge_this_sca_steps"] = [
                _per_led(s.per_sca[row[sca]]) if sca in row
                else _per_led(np.full(len(LED_NAMES), np.nan))
                for s in series.side_steps]
            table.meta["side_bridge_this_sca_pattern_offset"] = [
                float(s.pattern_offset[row[sca]]) if sca in row else float("nan")
                for s in series.side_steps]
            table.meta["side_bridge_ground_inverse_b_side"] = _per_led(
                [1.0 / B_SIDE_CORRECTIONS[led] for led in LED_NAMES])
            table.meta["side_bridge_note"] = (
                "One multiplicative step per LED, common to every SCA, across "
                "each MCE side change, fitted jointly over all SCAs against "
                "each (SCA, LED)'s own polynomial trend. It absorbs everything "
                "that changed at the swap: the detector electronics, the LED "
                "drive, and the photodiode (re-based to 1 at the first epoch "
                "of each side, since the A and B diodes are different "
                "devices). side_bridge_steps multiply the EARLY side onto the "
                "late one (present-nominal, as the h5 products record it); "
                "the side_bridge_LEDx columns are that, divided by the "
                "reference epoch's value, so LEDx stays 1.0 in row 0. "
                "total_errors = max(stat, sca_scatter) (+) systematic. "
                "pattern_rms vs pattern_noise tests that the swap did not "
                "change the illumination pattern; ground_inverse_b_side is "
                "the TVAC table in this gauge, for comparison only.")
        table.meta["calibration_schema"] = int(series.calibration_schema)
        if series.calibration_schema == 2:
            table.meta["bridge_solution_check"] = series.bridge_solution_check

        # Omitted entirely when no product carried a block, following the
        # bridge_step_errors precedent above: a consumer that needs the
        # correction then fails on a missing key rather than reading a unity
        # column it cannot distinguish from a model that fitted a flat gain.
        if series.tempgain:
            multiplier = series.tempgain[sca]
            table.meta["tempgain_model"] = series.tempgain_model
            table.meta["tempgain_model_sha256"] = series.tempgain_model_sha256
            table.meta["tempgain_form"] = series.tempgain_form
            table.meta["tempgain_mnemonic"] = series.tempgain_mnemonic
            table.meta["tempgain_applied_to"] = (
                "the LEDx_tgcorr columns only; LED1..LED6 are gain-free")
            table.meta["tempgain_led_names"] = list(LED_NAMES)
            # The absolute 1/G(T) at the reference epoch, which is the one
            # number the ratio columns divide out and therefore the one number
            # needed to re-gauge them onto any other origin.
            table.meta["tempgain_reference_multiplier"] = [
                float(v) for v in multiplier[0, :]]
            table.meta["tempgain_gauge"] = (
                "ratio to the reference epoch, matching bridge_gauge; "
                "LEDx_tgcorr is exactly 1.0 in row 0 by construction")
            # Order matters and is not free to choose. The bridge steps were
            # solved on gain-carrying response, so the gain can only be
            # removed after bridging -- removing it first would change the
            # steps, and then LED1..LED6 would no longer be the columns every
            # other fit in this activity reads.
            table.meta["tempgain_order_note"] = (
                "The gain ratio is applied AFTER the ACM bridge, necessarily: "
                "the bridge steps were fitted on the gain-carrying response, "
                "so LEDx_tgcorr = LEDx * tempgain_LEDx uses the same bridge "
                "factor as LEDx. It is not a re-reduction.")
            table.meta["tempgain_note"] = (
                "Provisional. The temperature gain is recorded in the "
                "calibrated h5 products but NOT applied to their pixels, and "
                "NOT applied to the canonical LED1..LED6 columns here -- "
                "every fit in this activity reads those, including the "
                "temperature-gain fit itself, which would otherwise read its "
                "own output. The _tgcorr columns are a convenience view. See "
                "TEMPERATURE_GAIN.md.")
        table.meta["created"] = created

        path = out_dir / f"time_series_{sca}.ecsv"
        table.write(path, format="ascii.ecsv", overwrite=True)
        written.append(path)

    return written


def compare_to_reference_digests(series, compare_dir, use_raw=False):
    """Largest deviation of each SCA from an existing digest set, for validation."""
    compare_dir = Path(compare_dir)
    label = "raw" if use_raw else "bridged"
    print(f"\ncomparing {label} response against {compare_dir}")
    worst = 0.0
    for sca in sorted_scas(series.raw):
        path = compare_dir / f"time_series_{sca}.ecsv"
        if not path.exists():
            print(f"  {sca}: no digest to compare")
            continue
        old = Table.read(path, format="ascii.ecsv")
        old_data = np.column_stack([np.asarray(old[led], dtype=float)
                                    for led in LED_NAMES])
        new_data = series.raw[sca] if use_raw else series.response(sca)
        n_common = min(len(old_data), len(new_data))
        d_time = np.max(np.abs(np.asarray(old["time_hours"], dtype=float)[:n_common]
                               - series.time_hours[:n_common]))
        d_data = np.max(np.abs(old_data[:n_common] - new_data[:n_common]))
        worst = max(worst, d_data)
        note = "" if n_common == len(new_data) else f"  (first {n_common} epochs)"
        print(f"  {sca}: max |dt| = {d_time:.3e} h, "
              f"max |dresponse| = {d_data:.3e}{note}")
    print(f"worst response deviation over all SCAs: {worst:.3e}")
    return worst


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--data-root", type=Path, default=DEFAULT_DATA_ROOT,
                        help="directory holding the per-SCA or mosaic HDF5 files")
    parser.add_argument("--file-list", type=Path, default=None,
                        help="text file listing the epochs, reference epoch "
                             "first; overrides auto-detection. Default: every "
                             "*.h5 directly under --data-root, chronologically "
                             "ordered")
    parser.add_argument("--stage", choices=sorted(STAGE_CHOICES),
                        default="auto",
                        help="which product stage to read, by the h5 'stage' "
                             "attribute rather than the filename: 'cal' "
                             "(corrections already in the arrays), 'raw' "
                             "(corrections applied here), 'legacy' (the r=20 "
                             "mosaic product), or 'auto' (default: whichever "
                             "single stage the directory holds, refusing a "
                             "mixed one)")
    parser.add_argument("--allow-mixed-product-kind", action="store_true",
                        help="permit per-SCA and mosaic products in one set. "
                             "Their medians differ at ~0.1 %%, the size of the "
                             "film-growth signal, so this puts a step in the "
                             "trend at the changeover")
    parser.add_argument("--allow-mixed-calibration", action="store_true",
                        help="permit epochs whose L2 inputs were flux-"
                             "calibrated differently. Measured on this "
                             "dataset the step is 1.2-1.8 %% rms per-SCA and "
                             "achromatic (across-LED spread 0.028 %%), which "
                             "is upstream of every correction applied here "
                             "and so survives all of them")
    parser.add_argument("--assume-side", choices=("A", "B"), default=None,
                        help="MCE electronics side for products that record "
                             "none. Without it such a set is refused rather "
                             "than defaulted to A: the per-LED B-side "
                             "corrections are 1.5-6 %%, and classifying the "
                             "side from an '_MCEB' filename marker (which "
                             "flight files never carry) silently made every "
                             "flight epoch side A")
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT_DIR,
                        help="output directory for the per-SCA ECSV digests")
    parser.add_argument("--report", type=Path, default=None,
                        help="write the text log of ACM moves, side swaps, "
                             "decon cycles and CAR-190/216 inventory here")
    parser.add_argument("--no-photodiode", action="store_true",
                        help="skip the photodiode normalization")
    parser.add_argument("--no-pd-from-product", dest="pd_from_product",
                        action="store_false",
                        help="read the photodiode from the legacy positional "
                             "dictionary/RCS_photodiode mirror instead of the "
                             "product's keyed photodiode/per_activity group. "
                             "The mirror carries no validity flag, so a "
                             "collapsed pd_net -- a denominator, worth tens as "
                             "a factor -- reaches the digest unannounced. Only "
                             "for reproducing a pre-2026-10 digest")
    parser.add_argument("--no-side", action="store_true",
                        help="skip the A/B side (MCEB) scale correction")
    parser.add_argument("--no-acm", action="store_true",
                        help="skip the linear ACM move correction")
    parser.add_argument("--no-bridge", action="store_true",
                        help="leave the ACM reconfiguration step in the output")
    parser.add_argument("--acm-segment-breaks", type=int, nargs="+",
                        default=(), metavar="EPOCH",
                        help="extra segment boundaries the LVDT does not show, "
                             "as 1-based epoch numbers; each names the first "
                             "epoch after the break. For a configuration change "
                             "that left the ACM position unchanged, where the "
                             "alternative is lowering --acm-move-min-delta "
                             "until LVDT noise invents boundaries. These are "
                             "reported as 'manual', never as detected")
    parser.add_argument("--acm-move-min-delta", type=float,
                        default=ACM_MOVE_MIN_DELTA,
                        help=f"|dLVDT| that opens a new ACM segment (default "
                             f"{ACM_MOVE_MIN_DELTA:g}). Within-segment scatter "
                             f"is <200 and the smallest real move ~2400. Pass "
                             f"{ACM_DEPLOY_MIN_DELTA:g} with "
                             f"--acm-require-sign-change to reproduce the "
                             f"pre-2026-10 single-deploy segmentation")
    parser.add_argument("--acm-require-sign-change", action="store_true",
                        help="only count moves that cross LVDT zero, i.e. the "
                             "deploy. Legacy behaviour; misses the two deployed-"
                             "to-deployed repositions in the flight trend")
    parser.add_argument("--no-bridge-multiplier", action="store_true",
                        help="where the joint fit cannot solve a boundary, leave "
                             "it at 1.0 instead of using the linear LVDT model")
    parser.add_argument("--bridge-degree", type=int, default=2,
                        help="per-LED polynomial order for the evolution (default 2)")
    parser.add_argument("--bridge-window", type=float, default=25.0,
                        help="half-width in hours of the fit window (default 25)")
    parser.add_argument("--bridge-gauge", choices=("reference", "deployed"),
                        default="reference",
                        help="where to put the overall normalization: 'reference' "
                             "keeps the first epoch at 1.0 (default); 'deployed' "
                             "keeps the deployed-ACM segment at its measured scale")
    parser.add_argument("--no-side-bridge", action="store_true",
                        help="leave the MCE side swap step in the output")
    parser.add_argument("--side-bridge-degree", type=int, default=2,
                        help="per-(SCA, LED) polynomial order across a side "
                             "swap (default 2)")
    parser.add_argument("--side-bridge-window", type=float, default=50.0,
                        help="half-width in hours of the side-bridge fit "
                             "window (default 50; the ACM bridge's 25 holds "
                             "only two passes after the 2026-10-06 swap)")
    parser.add_argument("--solution-out", type=Path, default=None,
                        help="write this run's fitted ACM and side bridges as "
                             "a bridge-solution ECSV, for "
                             "calibrate_rcs_products.py --bridge-solution to "
                             "record in the products")
    parser.add_argument("--plot-dir", type=Path, default=DEFAULT_PLOT_DIR,
                        help="output directory for diagnostic figures")
    parser.add_argument("--no-plots", action="store_true", help="skip the figures")
    parser.add_argument("--l2-audit", type=Path, default=DEFAULT_L2_AUDIT,
                        help="L2 calibration audit ECSV for "
                             "calibration_timeline.png; a missing file draws "
                             "only what the products themselves recorded")
    parser.add_argument("--compare-dir", type=Path, default=None,
                        help="existing digest directory to diff the result against")
    parser.add_argument("--compare-raw", action="store_true",
                        help="compare the pre-bridge response instead of the bridged")
    parser.add_argument("--quiet", action="store_true", help="suppress per-epoch output")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    corr = Corrections(
        photodiode=not args.no_photodiode,
        side=not args.no_side,
        acm=not args.no_acm,
    )
    spec = BridgeSpec(
        enabled=not args.no_bridge,
        degree=args.bridge_degree,
        window_hours=args.bridge_window,
        gauge=args.bridge_gauge,
        allow_multiplier=not args.no_bridge_multiplier,
    )

    if args.file_list is not None:
        file_names = read_file_list(args.file_list)
        if not file_names:
            raise SystemExit(f"no epochs listed in {args.file_list}")
        print(f"{len(file_names)} epochs from {args.file_list}")
    else:
        file_names = discover_h5_files(args.data_root, stage=args.stage,
                                       quiet=args.quiet,
                                       assume_side=args.assume_side)
        if not file_names:
            raise SystemExit(f"no *.h5 files found in {args.data_root}")
        print(f"{len(file_names)} epochs auto-detected in {args.data_root} "
              f"(stage {args.stage})")

    series = build_series(args.data_root, file_names, corr,
                          verbose=not args.quiet,
                          move_min_delta=args.acm_move_min_delta,
                          require_sign_change=args.acm_require_sign_change,
                          assume_side=args.assume_side,
                          allow_mixed_product_kind=args.allow_mixed_product_kind,
                          pd_from_product=args.pd_from_product,
                          segment_breaks=args.acm_segment_breaks,
                          allow_mixed_calibration=args.allow_mixed_calibration)
    side_spec = SideBridgeSpec(enabled=not args.no_side_bridge,
                               degree=args.side_bridge_degree,
                               window_hours=args.side_bridge_window)
    apply_bridge(series, spec, verbose=not args.quiet)
    apply_side_bridge(series, side_spec, verbose=not args.quiet)
    estimate_systematics(series, spec, verbose=not args.quiet)
    check_recorded_bridges(series)

    written = write_digests(series, args.out_dir, corr, spec, args.data_root)
    print(f"\nwrote {len(written)} digests to {args.out_dir}")

    if args.solution_out is not None:
        solution = bridge_solution(series, spec, side_spec)
        solution.write(args.solution_out)
        print(f"wrote the bridge solution to {args.solution_out} "
              f"(sha256 {solution.sha256[:12]}); record it with "
              f"calibrate_rcs_products.py --bridge-solution")

    if args.report is not None:
        # Imported here, not at module scope, only because nothing else in this
        # file needs it; rcs_report is text-only and matplotlib-free, so it is
        # safe to import on a headless node where --no-plots is in force.
        import rcs_report

        rcs_report.write_report(
            args.report, series,
            paths=[Path(args.data_root) / name for name in file_names],
            command=" ".join(sys.argv))
        print(f"wrote the run log to {args.report}")

    if not args.no_plots:
        # Read here rather than inside the figure so the outcome is announced
        # on the console: "the audit was not found" and "the audit says one
        # class" are very different results and must not look alike.
        audit = None
        if args.l2_audit is not None:
            # series.names are product *filenames*; the audit keys on run
            # labels. Strip the stage suffix rather than comparing the two
            # directly, which matches nothing at all and reads as "the audit
            # does not cover this set".
            labels = [rcs_products.run_label_of(name) for name in series.names]
            rows, audit_meta, uncovered = rcs_l2_source.read_calibration_audit(
                str(args.l2_audit), labels)
            if rows is None:
                print(f"  no L2 calibration audit at {args.l2_audit}; "
                      f"calibration_timeline.png will show only the "
                      f"provenance the products recorded")
            else:
                audit = (rows, audit_meta, uncovered)
                print(f"  read the L2 calibration audit from "
                      f"{args.l2_audit}: {len(labels) - len(uncovered)}"
                      f"/{len(labels)} epochs covered")
                if len(uncovered) == len(labels):
                    print(f"  WARNING: the audit covers none of these epochs "
                          f"-- it describes a different set, or the labels do "
                          f"not match (e.g. {labels[0]!r})")

        figures = digest_plots.write_all(series, spec, args.plot_dir,
                                         audit=audit)
        print(f"wrote {len(figures)} figures to {args.plot_dir}")

    if args.compare_dir is not None:
        compare_to_reference_digests(series, args.compare_dir, args.compare_raw)


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------

def self_test(verbose=True):
    """Check the photodiode denominator guard and the keyed photodiode read.

    These two are tested here rather than left to a data run because both
    failure modes are silent: an invalid ``pd_net`` used as a denominator
    produces a large, plausible-looking response excursion, and a positional
    read of the photodiode group picks up a CAR-216 aux flat without
    complaining.  Neither shows up as an error, only as a wrong number.
    """
    failures = []

    def check(name, condition):
        failures.append(name) if not condition else None
        if verbose:
            print(f"  {'ok  ' if condition else 'FAIL'} {name}")

    import contextlib
    import io

    def software_epoch(version):
        return Epoch(name=f"cal{version}.h5", timestamp=datetime(2026, 11, 3),
                     pass_number=1, photodiode=np.ones(6), acm_lvdt=-2795.0,
                     mosaics={}, l2_source="mast",
                     l2_calibration={"ref_file_id": "2c8d2de83f5ace81",
                                     "calibration_software_version": version,
                                     "crds_context": "roman_0077.pmap"})

    report = io.StringIO()
    with contextlib.redirect_stdout(report):
        assert_homogeneous_calibration(
            [software_epoch(v) for v in ("1.0.2", "1.0.3", "9.9.9")])
    text = report.getvalue()
    check("a software change under the same reference files is reported: "
          "a measured one with its result, a new one as a NOTE",
          "1.0.2 -> 1.0.3 at epoch 2 under the same reference files: measured"
          in text and "NOTE: L2 software 1.0.3 -> 9.9.9" in text)

    def epoch(pd, valid=None, side="A", lvdt=-2815.0):
        return Epoch(name="t.h5", timestamp=datetime(2026, 9, 1),
                     pass_number=1, photodiode=np.asarray(pd, dtype=float),
                     acm_lvdt=lvdt, mosaics={}, mce_side=side,
                     photodiode_valid=(None if valid is None
                                       else np.asarray(valid, dtype=bool)))

    nominal = [0.2428, 0.2800, 0.2380, 0.2422, 0.2411, 0.2307]
    corr = Corrections(photodiode=True, side=True, acm=False)
    reference = epoch(nominal, [True] * 6)

    # The 60x failure: pd_net collapses to the noise floor and the ratio becomes
    # an instrument event that never happened.
    collapsed = list(nominal)
    collapsed[3] = 0.004
    bad = epoch(collapsed, [True, True, True, False, True, True])
    factors = led_scale_factors(bad, reference, -2815.0, corr)
    check("a flagged pd_net gives NaN, not a factor of tens",
          np.isnan(factors["LED4"]))
    check("and the factor it would have formed was indeed huge",
          nominal[3] / collapsed[3] > 50.0)
    check("the other five LEDs are untouched",
          all(abs(factors[f"LED{i}"] - 1.0) < 1e-12
              for i in (1, 2, 3, 5, 6)))
    # The tempting alternative is to drop just the photodiode term and keep the
    # rest, which leaves a finite number: here the ACM-only factor. That is the
    # dangerous outcome -- an uncorrected point sitting inside a corrected
    # series, indistinguishable from a real one. Assert it did not happen.
    with_acm = Corrections(photodiode=True, side=True, acm=True)
    moved = epoch(collapsed, [True, True, True, False, True, True],
                  lvdt=-2900.0)
    acm_only = 1.0 / acm_correction(moved, -2815.0, with_acm)
    factors_moved = led_scale_factors(moved, reference, -2815.0, with_acm)
    check("the ACM-only factor it would have fallen back to is finite "
          "and not 1.0",
          np.isfinite(acm_only) and abs(acm_only - 1.0) > 1e-9)
    check("and the guard returns NaN instead of silently keeping it",
          np.isnan(factors_moved["LED4"]))

    # A bad *reference* invalidates that LED for every epoch, not just itself.
    bad_reference = epoch(nominal, [True, False, True, True, True, True])
    factors = led_scale_factors(epoch(nominal, [True] * 6), bad_reference,
                                -2815.0, corr)
    check("a flagged reference pd invalidates that LED set-wide",
          np.isnan(factors["LED2"]))

    # Unflagged products (legacy, no photodiode group) must behave exactly as
    # before, or the bit-exact regression against the 34-file set would move.
    factors = led_scale_factors(epoch(nominal), epoch(nominal), -2815.0, corr)
    check("photodiode_valid=None keeps the legacy path unchanged",
          all(abs(factors[led] - 1.0) < 1e-12 for led in LED_NAMES))

    # Keyed, not positional: entries 1..6 of this group are LED1..LED5 and an
    # aux flat, so a positional read would hand LED6 the aux value.
    class _Group(dict):
        # ``attrs`` so the same stub serves the tempgain reader below, which
        # takes the group's attributes as well as its datasets.
        attrs = {}

        def __getitem__(self, key):
            return _Field(super().__getitem__(key))

    class _Field:
        def __init__(self, value):
            self.value = value

        def __getitem__(self, _):
            return self.value

    keys = ["DARK", "LED1", "LED2", "LED3", "LED4", "LED5",
            "AUX_LED3FLAT1", "LED6"]
    net = [0.0, 0.11, 0.12, 0.13, 0.14, 0.15, 0.99, 0.16]
    group = _Group({"activity_key": np.array(keys, dtype=object),
                    "pd_net": np.array(net),
                    "pd_net_valid": np.array([False] + [True] * 7)})
    values, valid = _pd_from_group(group, fallback=np.zeros(6))
    check("the photodiode group is read by key, not by position",
          abs(values[5] - 0.16) < 1e-12 and 0.99 not in list(values))
    check("and the dark is never one of the six",
          abs(values[0] - 0.11) < 1e-12)

    group = _Group({"activity_key": np.array(["LED1"], dtype=object),
                    "pd_net": np.array([0.11]),
                    "pd_net_valid": np.array([True])})
    values, valid = _pd_from_group(group, fallback=np.full(6, 0.5))
    check("an LED the group omits is marked invalid, not trusted",
          valid[0] and not valid[1:].any() and abs(values[1] - 0.5) < 1e-12)

    # The two set-level guards. Both are SystemExit paths that no data run
    # reaches once the set is correct, which is exactly why they are tested
    # here: the conditions they catch produce a complete, confident report with
    # the wrong numbers in it, so a guard that stopped firing would look like
    # nothing at all.
    def carded(sha, stamp=datetime(2026, 9, 1), name="t.h5"):
        return Epoch(name=name, timestamp=stamp, pass_number=1,
                     photodiode=np.asarray(nominal, dtype=float),
                     acm_lvdt=-2815.0, mosaics={}, mce_side="A",
                     reference_card_sha256=sha)

    try:
        assert_homogeneous([carded("aaaa"), carded("bbbb")])
        check("a two-card set is refused", False)
    except SystemExit as exit_message:
        check("a two-card set is refused, naming both cards",
              "aaaa" in str(exit_message) and "bbbb" in str(exit_message))
    try:
        assert_homogeneous([carded("aaaa"), carded("aaaa"), carded("")])
        check("one card plus an uncarded legacy epoch is allowed", True)
    except SystemExit:
        check("one card plus an uncarded legacy epoch is allowed", False)

    # The calibration guard, exercised with the two real ref_file_ids plus an
    # invented third. The declared pair must pass and the undeclared one must
    # not: an unmeasured configuration defaulting to "probably the same" is the
    # exact failure this guard exists to prevent.
    def calibrated(ref_file_id, day=1, source="mast"):
        prov = dict.fromkeys(rcs_l2_source.PROVENANCE_FIELDS, "")
        prov["ref_file_id"] = ref_file_id
        prov["crds_context"] = "roman_0072.pmap"
        prov["cal_step_photom"] = "COMPLETE"
        return Epoch(name=f"c{day}.h5", timestamp=datetime(2026, 9, day),
                     pass_number=day,
                     photodiode=np.asarray(nominal, dtype=float),
                     acm_lvdt=-2815.0, mosaics={}, mce_side="A",
                     l2_source=source, l2_calibration=prov)

    aux_id, mast_id = "57375af18e138f28", "1aa8a84bc016ea68"
    try:
        assert_homogeneous_calibration(
            [calibrated(aux_id, 1, "aux"), calibrated(mast_id, 2)])
        check("the two measured-equivalent configurations are allowed", True)
    except SystemExit:
        check("the two measured-equivalent configurations are allowed", False)
    try:
        assert_homogeneous_calibration(
            [calibrated(mast_id, 1), calibrated("0040ancientphotom", 2)])
        check("an undeclared configuration is refused", False)
    except SystemExit as exit_message:
        check("an undeclared configuration is refused, naming the boundary "
              "epoch where the step lands",
              "c2.h5" in str(exit_message) and "epoch 2" in str(exit_message))
    try:
        assert_homogeneous_calibration(
            [calibrated(mast_id, 1), calibrated("0040ancientphotom", 2)],
            allow_mixed=True)
        check("--allow-mixed-calibration downgrades the refusal", True)
    except SystemExit:
        check("--allow-mixed-calibration downgrades the refusal", False)
    try:
        assert_homogeneous_calibration([carded("aaaa"), carded("aaaa")])
        check("epochs recording no calibration are reported, never refused",
              True)
    except SystemExit:
        check("epochs recording no calibration are reported, never refused",
              False)
    # Contiguity, not grouping: a configuration that recurs after an
    # interruption is two runs and two steps, and reporting it as one family
    # would hide the second.
    runs = calibration_families([calibrated(mast_id, 1), calibrated(aux_id, 2),
                                 calibrated(mast_id, 3)])
    check("a configuration that recurs is reported as two contiguous runs",
          len(runs) == 3 and [f["n"] for f in runs] == [1, 1, 1])

    ordered = [carded("a", datetime(2026, 9, day), f"e{day}.h5")
               for day in (1, 2, 3)]
    try:
        assert_chronological(ordered)
        check("a time-ordered set passes", True)
    except SystemExit:
        check("a time-ordered set passes", False)
    try:
        assert_chronological([ordered[0], ordered[2], ordered[1]])
        check("an out-of-order set is refused", False)
    except SystemExit as exit_message:
        # The message has to name the offending pair: the caller's mistake is
        # upstream (usually sorted(os.listdir)), so "not in time order" alone
        # does not tell them which set they handed over.
        check("an out-of-order set is refused, naming the inverted pair",
              "e2.h5" in str(exit_message) and "e3.h5" in str(exit_message))

    # The decon episode metadata, round-tripped through a real write. The
    # labelling deliberately makes "decon1" recur, which is the case where a
    # grouping by label would report two episodes instead of three and hand a
    # post-processing re-gauge the wrong t=0 for the last block.
    import tempfile

    cycles = ["decon1"] * 3 + ["decon2"] * 4 + ["decon1"] * 3
    n = len(cycles)
    hours = np.arange(n, dtype=float) * 10.0
    series = TrendSeries(
        names=[f"EP_{i:02d}.h5" for i in range(n)],
        timestamps=[datetime(2026, 9, 1 + i) for i in range(n)],
        pass_numbers=np.arange(1, n + 1),
        car_labels=["CAR190"] * n, decon_cycles=cycles, time_hours=hours,
        acm_lvdt=np.full(n, -2815.0), segment=np.zeros(n, int),
        raw={"SCA1": np.ones((n, 6))},
        factors={"SCA1": np.ones(n)}, steps={"SCA1": []},
        mce_sides=["A"] * n, mce_side_sources=["attribute"] * n)

    with tempfile.TemporaryDirectory() as tmp:
        written = write_digests(series, Path(tmp), corr,
                                BridgeSpec(), Path(tmp))
        table = Table.read(written[0], format="ascii.ecsv")

        bounds = table.meta["decon_episode_bounds"]
        check("a recurring decon label is three episodes, not two",
              table.meta["decon_n_episodes"] == 3)
        check("the episode bounds tile the epoch set with no gap or overlap",
              [tuple(b) for b in bounds] == [(1, 3), (4, 7), (8, 10)])
        check("each episode names its own reference epoch, by position",
              table.meta["decon_reference_epochs"]
              == ["EP_00.h5", "EP_03.h5", "EP_07.h5"])
        check("a label owning two episodes is listed twice, not collapsed",
              table.meta["decon_episode_labels"]
              == ["decon1", "decon2", "decon1"])

        # decon_time_hours is zero at each episode's start and agrees with
        # time_hours only inside the first episode -- if it agreed everywhere
        # the column would be a copy and the re-gauge origin would be wrong.
        decon_hours = np.asarray(table["decon_time_hours"])
        check("decon_time_hours is zero at every episode's first epoch",
              all(decon_hours[first - 1] == 0.0 for first, _ in bounds))
        check("decon_time_hours equals time_hours in the first episode only",
              np.allclose(decon_hours[:3], np.asarray(table["time_hours"])[:3])
              and not np.allclose(decon_hours[3:],
                                  np.asarray(table["time_hours"])[3:]))
        check("the response columns are still gauged globally, not per episode",
              "NOT per episode" in table.meta["decon_episode_note"])

    # The MCE side change. Three things have to hold: it becomes a segment
    # boundary even though the LVDT never moves, the step across it is read in
    # the B-nominal direction, and a single-side set is completely unaffected
    # -- that last one is why every key here is conditional.
    sides = ["A"] * 6 + ["B"] * 4
    check("a side change is found positionally, by difference not by label",
          side_change_indices([epoch(nominal, side=s) for s in sides]) == [6])
    check("a single-side set has no side break at all",
          side_change_indices([epoch(nominal, side="A")] * 5) == [])
    check("a swap back is two breaks, not one",
          side_change_indices([epoch(nominal, side=s)
                               for s in ["A", "A", "B", "B", "A"]]) == [2, 4])

    # The swap, applied. A chromatic, SCA-common step is planted on the late
    # side of 18 SCAs that each have their own smooth trend; the ACM bridge
    # must leave it alone (step fixed at 1 there) and the side bridge must
    # find and remove it, without moving pass 1 off 1.0.
    import contextlib
    import io

    n_side = len(sides)
    rng = np.random.default_rng(1006)
    swap = np.array([0.954, 0.972, 1.050, 1.003, 1.012, 1.021])
    side_hours = np.arange(n_side, dtype=float) * 10.0
    late = (np.arange(n_side) >= 6)[:, None]
    side_raw = {}
    for name in SCA_NAMES:
        trend = (1.0 + rng.normal(0, 1e-3, 6)[None, :]
                 + rng.normal(-2e-5, 5e-6, 6)[None, :] * side_hours[:, None])
        # Divided by its own row 0 last, as the digest's ratio to the
        # reference epoch is, so row 0 is exactly 1 noise included.
        noisy = (trend * np.where(late, swap, 1.0)
                 * np.exp(rng.normal(0, 2e-5, (n_side, 6))))
        side_raw[name] = noisy / noisy[0]
    swapped = TrendSeries(
        names=[f"EP_{i:02d}.h5" for i in range(n_side)],
        timestamps=[datetime(2026, 9, 1 + i, tzinfo=timezone.utc)
                    for i in range(n_side)],
        pass_numbers=np.arange(1, n_side + 1),
        car_labels=["CAR190"] * n_side, decon_cycles=["decon2"] * n_side,
        time_hours=side_hours,
        acm_lvdt=np.full(n_side, -2815.0),
        segment=np.array([0] * 6 + [1] * 4),
        raw=side_raw,
        mce_sides=sides, mce_side_sources=["attribute"] * n_side,
        corrections_applied=("photodiode", "acm"), calibration_schema=2)
    check("the segment boundary at the swap is read as a side boundary",
          swapped.side_boundaries == {6: "A->B"})
    check("an ACM-only boundary is not mistaken for one",
          replace(swapped, mce_sides=["A"] * n_side).side_boundaries == {})

    with contextlib.redirect_stdout(io.StringIO()):
        apply_bridge(swapped, BridgeSpec())
        apply_side_bridge(swapped, SideBridgeSpec(window_hours=50.0))
    check("the ACM step at a side boundary is fixed at 1, method 'side'",
          all(s[0].method == "side" and s[0].value == 1.0
              for s in swapped.steps.values()))
    step = swapped.side_steps[0]
    check("the side bridge recovers the planted per-LED, SCA-common step",
          step.method == "side"
          and np.max(np.abs(step.value / swap - 1.0)) < 2e-4)
    check("and every LED has a finite error, with the systematic scanned",
          np.all(np.isfinite(step.total_error)) and step.n_choices >= 2)
    check("an unchanged illumination pattern passes the pattern test",
          step.pattern_ratio < 3.0)
    joined = swapped.response("SCA4")
    check("the bridged response is 1.0 at pass 1 and has no step at the swap",
          np.allclose(joined[0], 1.0)
          and np.max(np.abs(np.log(joined[6] / joined[5])
                            - np.log(side_raw["SCA4"][6] / swap
                                     / side_raw["SCA4"][5]))) < 2e-4)
    check("in the digest gauge side B reads x 1/step, side A exactly 1",
          np.allclose(swapped.side_display[:6], 1.0)
          and np.allclose(swapped.side_display[6:], 1.0 / step.value))

    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        report_side_bridge(swapped, step)
    text = buffer.getvalue()
    check("the report states the gauge and runs the pattern test",
          "MULTIPLIED" in text and "pattern test" in text
          and "no change in the illumination pattern" in text)

    # The recorded-solution check: what stage 2 would record is the present
    # gauge (side B = 1, side A = step). Equal -> current; perturbed -> stale.
    present = side_bridge_factors(n_side, swapped.side_steps)
    swapped.recorded_bridges = {
        "acm": {sca: np.ones(n_side) for sca in swapped.raw},
        "side": present, "sha256": "f" * 64}
    with contextlib.redirect_stdout(io.StringIO()):
        verdict = check_recorded_bridges(swapped)
    check("a recorded solution equal to the fit reads 'current'",
          verdict.startswith("current"))
    swapped.recorded_bridges["side"] = present * 1.001
    swapped.recorded_bridges["side"][6:] = 1.0
    with contextlib.redirect_stdout(io.StringIO()):
        verdict = check_recorded_bridges(swapped)
    check("one that differs reads 'STALE', with the size",
          verdict.startswith("STALE"))
    swapped.recorded_bridges = {}

    solution = bridge_solution(swapped, BridgeSpec(), swapped.side_spec)
    side_rows = [r for r in solution.rows if r["kind"] == "side"]
    check("the solution carries six side rows, one per LED, keyed by time",
          len(side_rows) == 6
          and np.allclose([r["value"] for r in side_rows], step.value)
          and side_rows[0]["boundary_index"] == 7)
    check("and evaluates present-nominal at an A-side and a B-side epoch",
          np.allclose(solution.side_multiplier(swapped.timestamps[2],
                                               LED_NAMES), step.value)
          and np.allclose(solution.side_multiplier(swapped.timestamps[8],
                                                   LED_NAMES), 1.0))

    with tempfile.TemporaryDirectory() as tmp:
        written = write_digests(swapped, Path(tmp), corr, BridgeSpec(),
                                Path(tmp))
        digest = Table.read(written[0], format="ascii.ecsv")
        meta = digest.meta
        check("the digest records the side bridge 1-based, like every other "
              "epoch index it prints",
              meta["side_bridge_epoch_indices"] == [7]
              and meta["side_bridge_transitions"] == ["A->B"]
              and meta["side_bridge_applied"] is True)
        check("with the per-LED steps and errors under their LED names",
              np.allclose(meta["side_bridge_steps"][0], step.value)
              and list(meta["side_bridge_led_names"]) == list(LED_NAMES)
              and np.all(np.isfinite(meta["side_bridge_total_errors"][0])))
        check("and the side_bridge_LEDx columns, 1.0 on side A",
              np.allclose(digest["side_bridge_LED1"][:6], 1.0)
              and np.allclose(digest["side_bridge_LED1"][6:],
                              1.0 / step.value[0]))
        check("and this SCA's own independent reading, for the pattern test",
              len(meta["side_bridge_this_sca_steps"][0]) == 6)

        # The no-op half: the single-side digest written earlier must carry
        # none of these keys. A key that appears unconditionally would change
        # every existing digest's bytes for a case that cannot occur in it.
        single = Table.read(
            write_digests(series, Path(tmp), corr, BridgeSpec(),
                          Path(tmp))[0], format="ascii.ecsv").meta
        check("a single-side digest carries no side keys at all",
              not [k for k in single if k.startswith("side_")],
              )
        check("and no temperature-gain keys or columns either",
              not [k for k in single if k.startswith("tempgain")]
              and not [c for c in Table.read(
                  write_digests(series, Path(tmp), corr, BridgeSpec(),
                                Path(tmp))[0],
                  format="ascii.ecsv").colnames if "tgcorr" in c])

    # The temperature-gain column family. Every check here is on a quantity
    # that is wrong-but-smooth if the gauge slips, which is why none of them
    # is left to a data run.
    rng = np.random.default_rng(5)
    growth = np.exp(np.outer(hours - hours[0],
                             np.full(6, -2e-5)))            # (n, 6)
    gain = 1.0 + 0.004 * rng.standard_normal((n, 6))
    geared = TrendSeries(
        names=series.names, timestamps=series.timestamps,
        pass_numbers=series.pass_numbers, car_labels=series.car_labels,
        decon_cycles=series.decon_cycles, time_hours=hours,
        acm_lvdt=series.acm_lvdt, segment=series.segment,
        raw={"SCA1": growth}, factors={"SCA1": np.ones(n)},
        steps={"SCA1": []}, mce_sides=["A"] * n,
        mce_side_sources=["attribute"] * n,
        tempgain={"SCA1": gain}, tempgain_model="tempgain_model.ecsv",
        tempgain_model_sha256="f" * 64, tempgain_form="poly_pinned_v1",
        tempgain_mnemonic="WFI_MCU_A_MPA_CSENS_FPSSEN_K")

    ratio = geared.tempgain_ratio("SCA1")
    check("the applied gain is the ratio to the reference epoch, exactly 1.0 "
          "in row 0",
          np.allclose(ratio[0, :], 1.0)
          and np.allclose(ratio, gain / gain[0, :][None, :]))
    # The trap: a gain constant in time is wholly absorbed by the gauge. If
    # the /m[0] were dropped the corrected series would be rescaled by that
    # constant everywhere -- smooth, plausible, and uniformly wrong.
    flat = replace(geared, tempgain={"SCA1": np.full((n, 6), 0.97)})
    check("a time-constant gain leaves the corrected series bit-identical",
          np.array_equal(flat.response_tgcorr("SCA1"),
                         flat.response("SCA1")))
    check("and the corrected series is the response times that ratio, nothing "
          "else",
          np.allclose(geared.response_tgcorr("SCA1"),
                      geared.response("SCA1") * ratio))

    with tempfile.TemporaryDirectory() as tmp:
        geared_table = Table.read(
            write_digests(geared, Path(tmp), corr, BridgeSpec(), Path(tmp))[0],
            format="ascii.ecsv")
        check("the digest carries all six corrected columns and all six "
              "ratios",
              all(f"{led}_tgcorr" in geared_table.colnames for led in LED_NAMES)
              and all(f"tempgain_{led}" in geared_table.colnames
                      for led in LED_NAMES))
        check("LED1_tgcorr is exactly 1.0 in row 0, like LED1",
              abs(float(geared_table["LED1_tgcorr"][0]) - 1.0) < 1e-12)
        check("LED1_tgcorr / LED1 is the recorded ratio g[0]/g[i]",
              np.allclose(np.asarray(geared_table["LED1_tgcorr"])
                          / np.asarray(geared_table["LED1"]),
                          np.asarray(geared_table["tempgain_LED1"])))
        check("the canonical LED1 column is untouched by the gain",
              np.allclose(np.asarray(geared_table["LED1"]), growth[:, 0]))
        check("the meta names the corrected columns as the only ones carrying "
              "it, which is what keeps the gain fit off its own output",
              "LED1..LED6 are gain-free"
              in geared_table.meta["tempgain_applied_to"])
        check("and records the reference epoch's absolute multiplier, so the "
              "ratio can be re-gauged",
              np.allclose(geared_table.meta["tempgain_reference_multiplier"],
                          gain[0, :]))
        check("and says the correction follows the bridge, not precedes it",
              "AFTER the ACM bridge"
              in geared_table.meta["tempgain_order_note"])

    # The set-level guard. A part-corrected set puts a step the size of the
    # correction at the changeover, which reads as an instrument event.
    def gained(sha, multiplier=True, day=1):
        return Epoch(name=f"g{day}.h5", timestamp=datetime(2026, 9, day),
                     pass_number=day,
                     photodiode=np.asarray(nominal, dtype=float),
                     acm_lvdt=-2815.0, mosaics={}, mce_side="A",
                     tempgain=(np.ones((6, N_SCAS)) if multiplier else None),
                     tempgain_model_sha256=sha)

    try:
        assert_homogeneous([gained("aa", True, 1), gained("aa", False, 2)])
        check("a part-corrected set is refused", False)
    except SystemExit as exit_message:
        check("a part-corrected set is refused, naming an uncorrected epoch",
              "g2.h5" in str(exit_message))
    try:
        assert_homogeneous([gained("aa", True, 1), gained("bb", True, 2)])
        check("a two-model set is refused", False)
    except SystemExit as exit_message:
        check("a two-model set is refused, naming both models",
              "aa" in str(exit_message) and "bb" in str(exit_message))
    try:
        assert_homogeneous([gained("aa", True, 1), gained("aa", True, 2)])
        check("one model throughout is allowed", True)
    except SystemExit:
        check("one model throughout is allowed", False)
    try:
        assert_homogeneous([gained("", False, 1), gained("", False, 2)])
        check("a set with no model at all is allowed", True)
    except SystemExit:
        check("a set with no model at all is allowed", False)

    # The axis reorder. Two axes of different length cannot be transposed
    # here, but they can be permuted, and a permuted grid hands SCA1 another
    # detector's 1 % correction with nothing to notice.
    grid = np.arange(6 * N_SCAS, dtype=float).reshape(6, N_SCAS)
    shuffled_leds = ["LED3", "LED1", "LED2", "LED6", "LED4", "LED5"]
    order = [shuffled_leds.index(led) for led in LED_NAMES]
    group = _Group({
        "led_name": np.array(shuffled_leds, dtype=object),
        "sca": np.arange(1, N_SCAS + 1),
        "multiplier": grid,
        "temperature_k": np.full(6, 110.0),
        "valid": np.ones(6, dtype=bool),
    })
    multiplier, valid, temperature, _ = _tempgain_from_group(group)
    check("the tempgain block is reordered to LED_NAMES by label, not taken "
          "as stored",
          np.array_equal(multiplier, grid[order, :]))
    check("and an invalid LED's row is NaN, never 1.0",
          np.isnan(_tempgain_from_group(_Group({
              "led_name": np.array(LED_NAMES, dtype=object),
              "sca": np.arange(1, N_SCAS + 1),
              "multiplier": np.ones((6, N_SCAS)),
              "temperature_k": np.full(6, 110.0),
              "valid": np.array([True, True, False, True, True, True]),
          }))[0][2, :]).all())
    try:
        _tempgain_from_group(_Group({
            "led_name": np.array(LED_NAMES[:5], dtype=object),
            "sca": np.arange(1, N_SCAS + 1),
            "multiplier": np.ones((5, N_SCAS)),
            "temperature_k": np.full(5, 110.0),
            "valid": np.ones(5, dtype=bool),
        }))
        check("a block missing an LED is refused", False)
    except SystemExit as exit_message:
        check("a block missing an LED is refused, naming it",
              "LED6" in str(exit_message))

    print(f"make_sca_digests.self_test: "
          f"{'ok' if not failures else 'FAILED'} "
          f"({len(failures)} failure(s))")
    return not failures


if __name__ == "__main__":
    if "--self-test" in (sys.argv[1:] or []):
        raise SystemExit(0 if self_test() else 1)
    main()
