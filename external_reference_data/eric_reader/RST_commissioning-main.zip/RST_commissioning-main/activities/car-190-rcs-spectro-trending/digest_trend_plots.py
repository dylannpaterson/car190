#!/usr/bin/env python
"""The per-LED, all-SCA trend figures, drawn from a digest set.

``run_trend.py`` writes the full-period family into ``$ROOT/digest_plots/``:
one file per LED, all 18 SCAs overlaid (``time_series_<LED>_all_scas.png``),
plus the ``_tgcorr`` blink pair when the set carries a temperature gain. This
draws the same family from the digests alone, over the whole period or the
last N weeks, so a recent stretch can be looked at without squinting at the
right edge of a two-month plot:

    # the last week of the newest digest set -> $ROOT/digest_plots/last_1w/
    .venv/bin/python digest_trend_plots.py --last-weeks 1

    # the last three weeks, or everything since a date
    .venv/bin/python digest_trend_plots.py --last-weeks 3
    .venv/bin/python digest_trend_plots.py --since 2026-10-20

    # the full period, from a named set, somewhere else
    .venv/bin/python digest_trend_plots.py --digests $ROOT/digests/digests_v4_11_01_26 \\
        --out /tmp/full

The window ends at the newest epoch in the set, not at the wall clock, so
"the last week" is the last week of data. The values are the digests' own
(``LEDx`` and ``LEDx_tgcorr``, gauged to the reference epoch, pass 1); only the
time axis is cut, and each figure autoscales to its window. A windowed figure
adds a dot per epoch, the window in its title, and the dated operations events
of ``rcs_trend_config.TREND_EVENTS`` (``--no-events`` to leave them off); the
full-period figures it draws are identical to ``run_trend.py``'s.

Reads only the ECSVs and their meta: no h5 products, no MAST.
"""
import argparse
import glob
import os
import sys
from datetime import datetime, timedelta, timezone

import numpy as np

import rcs_trend_config as cfg
from rcs_trend_config import LED_NAMES

HERE = os.path.dirname(os.path.abspath(__file__))


def _utc(value):
    """A tz-aware UTC datetime from an ISO string or an astropy Time element."""
    text = value.isot if hasattr(value, "isot") else str(value)
    stamp = datetime.fromisoformat(text.replace("Z", ""))
    return stamp.replace(tzinfo=timezone.utc) if stamp.tzinfo is None else stamp


class DigestSeries:
    """What the per-LED figures need of a series, read back from a digest set.

    Mirrors the attributes :func:`digest_plots.plot_led_all_scas` uses on
    ``make_sca_digests.Series``: ``raw`` (keyed by SCA name), ``timestamps``,
    ``response``/``response_tgcorr``/``tempgain_ratio`` per SCA, ``segment``,
    ``decon_cycles``, ``side_boundaries`` and the gain's ``tempgain_form``.
    The response is read, not recomputed: the digest's ``LEDx`` is already
    the bridged response, and ``LEDx_tgcorr = LEDx * tempgain_LEDx``.
    """

    def __init__(self, digest_dir):
        from astropy.table import Table

        self.digest_dir = os.path.abspath(digest_dir)
        self.name = os.path.basename(self.digest_dir.rstrip("/"))
        paths = sorted(glob.glob(os.path.join(digest_dir, "time_series_SCA*.ecsv")))
        if not paths:
            raise SystemExit(f"no time_series_SCA*.ecsv in {digest_dir}")
        tables = {os.path.basename(p)[len("time_series_"):-len(".ecsv")]:
                  Table.read(p) for p in paths}
        first = next(iter(tables.values()))
        stamps = [str(v) for v in first["timestamp"]]
        for sca, table in tables.items():
            if [str(v) for v in table["timestamp"]] != stamps:
                raise SystemExit(f"{sca}'s epochs differ from the other "
                                 f"SCAs'; this is not one digest set")
        self.timestamps = [_utc(v) for v in first["timestamp"]]
        self.segment = np.asarray(first["acm_segment"], dtype=int)
        self.decon_cycles = [str(v) for v in first["decon_cycle"]]
        meta = first.meta
        # The meta's epoch indices are 1-based (make_sca_digests writes
        # boundary + 1); the series' boundaries are 0-based segment starts.
        self.side_boundaries = dict(zip(
            [int(i) - 1 for i in meta.get("side_bridge_epoch_indices", [])],
            [str(t) for t in meta.get("side_bridge_transitions", [])]))
        self.tempgain_form = str(meta.get("tempgain_form", ""))

        def columns(table, template):
            return np.column_stack([np.asarray(table[template.format(led)],
                                               dtype=float)
                                    for led in LED_NAMES])

        self.raw = {sca: columns(t, "{}") for sca, t in tables.items()}
        gain = all(f"tempgain_{LED_NAMES[0]}" in t.colnames
                   for t in tables.values())
        self.tempgain = ({sca: columns(t, "tempgain_{}")
                          for sca, t in tables.items()} if gain else {})

    def response(self, sca):
        return self.raw[sca]

    def tempgain_ratio(self, sca):
        # Already the ratio to the reference epoch (the digest's gauge), so
        # it is used as it is, not re-divided by its own first row: a window
        # whose first epoch is not pass 1 must still show pass 1's gauge.
        return self.tempgain[sca]

    def response_tgcorr(self, sca):
        return self.raw[sca] * self.tempgain_ratio(sca)

    def window(self, start):
        """A copy holding only the epochs at or after ``start`` (a datetime)."""
        keep = np.array([t >= start for t in self.timestamps])
        if not keep.any():
            raise SystemExit(f"no epoch of {self.name} at or after "
                             f"{start:%Y-%m-%d %H:%M}")
        index = np.flatnonzero(keep)
        out = object.__new__(DigestSeries)
        out.digest_dir, out.name = self.digest_dir, self.name
        out.timestamps = [self.timestamps[i] for i in index]
        out.segment = self.segment[index]
        out.decon_cycles = [self.decon_cycles[i] for i in index]
        offset = int(index[0])
        out.side_boundaries = {i - offset: t
                               for i, t in self.side_boundaries.items()
                               if i - offset > 0}
        out.tempgain_form = self.tempgain_form
        out.raw = {sca: a[index] for sca, a in self.raw.items()}
        out.tempgain = {sca: a[index] for sca, a in self.tempgain.items()}
        return out


def newest_digest_set(root):
    """The most recently written digest set under ``root/digests``."""
    sets = [s for s in glob.glob(os.path.join(root, "digests", "digests_*"))
            if os.path.basename(s) != "digests_pass1"
            and glob.glob(os.path.join(s, "time_series_SCA*.ecsv"))]
    if not sets:
        raise SystemExit(f"no digest sets under {root}/digests")
    return max(sets, key=os.path.getmtime)


def events_in(series, events=cfg.TREND_EVENTS):
    """The registered events that fall inside the series' time span."""
    first, last = series.timestamps[0], series.timestamps[-1]
    out = []
    for when, label in events:
        stamp = _utc(when)
        if first <= stamp <= last:
            out.append((stamp, label))
    return out


def write_family(series, out_dir, windowed, events=(), leds=LED_NAMES):
    """Every per-LED figure (and its ``_tgcorr`` pair) for one series."""
    import digest_plots

    os.makedirs(out_dir, exist_ok=True)
    note = ""
    if windowed:
        first, last = series.timestamps[0], series.timestamps[-1]
        note = (f"{first:%Y-%m-%d} to {last:%Y-%m-%d} "
                f"({len(series.timestamps)} epochs)")
    written = []
    for led in leds:
        index = LED_NAMES.index(led)
        options = dict(markers=windowed, title_note=note, events=events)
        written.append(digest_plots.plot_led_all_scas(
            series, index,
            os.path.join(out_dir, f"time_series_{led}_all_scas.png"),
            **options))
        if series.tempgain:
            written.append(digest_plots.plot_led_all_scas(
                series, index,
                os.path.join(out_dir, f"time_series_{led}_all_scas_tgcorr.png"),
                corrected=True, **options))
    return written


def main(argv=None):
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--root", default=cfg.TREND_ROOT)
    parser.add_argument("--digests", help="a digest set (default: the newest "
                        "under ROOT/digests)")
    window = parser.add_mutually_exclusive_group()
    window.add_argument("--last-weeks", type=float,
                        help="only the last N weeks of data (N may be "
                             "fractional: 0.5 is 3.5 days)")
    window.add_argument("--since", help="only epochs at or after this UTC "
                        "date or time, e.g. 2026-10-20 or 2026-10-30T01:48")
    parser.add_argument("--leds", nargs="+", choices=LED_NAMES,
                        default=list(LED_NAMES))
    parser.add_argument("--out", help="default: ROOT/digest_plots/last_<N>w "
                        "or since_<date>; required for the full period")
    parser.add_argument("--no-events", action="store_true",
                        help="leave TREND_EVENTS off a windowed figure")
    args = parser.parse_args(argv)
    if args.self_test:
        return 0 if self_test() else 1

    digests = args.digests or newest_digest_set(args.root)
    series = DigestSeries(digests)
    last = series.timestamps[-1]
    if args.last_weeks is not None:
        if args.last_weeks <= 0:
            raise SystemExit("--last-weeks must be positive")
        start = last - timedelta(weeks=args.last_weeks)
        label = f"last_{args.last_weeks:g}w"
    elif args.since:
        start = _utc(args.since)
        label = f"since_{start:%Y%m%d}"
    else:
        start, label = None, None
    if start is None and not args.out:
        raise SystemExit("the full-period figures are run_trend.py's, in "
                         "ROOT/digest_plots; name --out to draw them again "
                         "elsewhere, or ask for --last-weeks/--since")
    windowed = start is not None
    if windowed:
        series = series.window(start)
    out = args.out or os.path.join(args.root, "digest_plots", label)
    events = [] if (args.no_events or not windowed) else events_in(series)

    print(f"digests {series.name}: {len(series.timestamps)} epoch(s), "
          f"{series.timestamps[0]:%Y-%m-%d %H:%M} .. {last:%Y-%m-%d %H:%M} UTC"
          + (f" ({label})" if windowed else " (full period)"))
    if events:
        print("events drawn: " + "; ".join(
            f"{when:%m-%d %H:%M} {text}" for when, text in events))
    written = write_family(series, out, windowed, events, args.leds)
    print(f"wrote {len(written)} figure(s) to {out}")
    print("\nNext:\n  blink time_series_<LED>_all_scas.png against its _tgcorr "
          "pair; the full period is in ROOT/digest_plots/")
    return 0


def self_test(verbose=True):
    """A synthetic set: the adapter, the window cut and the gauge it keeps."""
    import tempfile

    from astropy.table import Table

    with tempfile.TemporaryDirectory() as tmp:
        stamps = [f"2026-10-{d:02d}T12:00:00.000" for d in range(1, 21)]
        for number in (1, 2):
            table = Table({"timestamp": stamps,
                           "acm_segment": [0] * 5 + [1] * 15,
                           "decon_cycle": ["decon2"] * 12 + ["decon3"] * 8})
            for i, led in enumerate(LED_NAMES):
                table[led] = 1.0 + 0.001 * np.arange(20) * (i + number)
                table[f"tempgain_{led}"] = np.linspace(1.0, 1.01, 20)
            table.meta["side_bridge_epoch_indices"] = [6]     # 1-based
            table.meta["side_bridge_transitions"] = ["A->B"]
            table.meta["tempgain_form"] = "test"
            table.write(os.path.join(tmp, f"time_series_SCA{number}.ecsv"))
        series = DigestSeries(tmp)
        cut = series.window(_utc("2026-10-14T00:00"))
        checks = {
            "the set reads back with its boundaries":
                len(series.timestamps) == 20 and series.side_boundaries == {5: "A->B"},
            "a window keeps the digest's gauge, not its own first epoch":
                len(cut.timestamps) == 7
                and np.isclose(cut.response("SCA1")[0, 0], 1.013)
                and np.isclose(cut.tempgain_ratio("SCA1")[0, 0],
                               series.tempgain_ratio("SCA1")[13, 0]),
            "a boundary before the window is dropped, one inside is kept":
                cut.side_boundaries == {}
                and series.window(_utc("2026-10-03T00:00")).side_boundaries
                == {3: "A->B"},
            "events are kept only inside the span":
                [t for _, t in events_in(cut, (("2026-10-15T00:00", "in"),
                                               ("2026-10-02T00:00", "out")))]
                == ["in"],
        }
        written = write_family(cut, os.path.join(tmp, "plots"), True,
                               events_in(cut, (("2026-10-15T00:00", "e"),)),
                               leds=["LED1"])
        checks["a windowed LED1 and its tgcorr pair are written"] = (
            len(written) == 2 and all(os.path.getsize(p) > 0 for p in written))
    for text, ok in checks.items():
        if verbose:
            print(f"    {'ok  ' if ok else 'FAIL'} {text}")
    ok = all(checks.values())
    if verbose:
        print(f"  digest_trend_plots.self_test: {'OK' if ok else 'FAILED'}")
    return ok


if __name__ == "__main__":
    sys.exit(main())
