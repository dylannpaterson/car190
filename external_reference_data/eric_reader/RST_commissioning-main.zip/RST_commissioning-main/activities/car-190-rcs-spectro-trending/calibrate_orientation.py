"""
Measure, rather than assume, how each per-SCA product must be flipped before
it is placed into an MPA mosaic.

Why this exists: ``mosaic_plot_FPS.placeImages`` applies a specific flip
convention, but that convention is only correct if the input arrays store rows
the way that script assumed. The quicklook slope files carry
``CDELT2 = -0.01`` with ``WCSNAME = 'MPA_mm'``, i.e. their rows run in the
*opposite* sense to the mosaic frame's, which suggests the flips may already be
baked in. Guessing wrong silently mirrors every SCA, so we pin it down against
two independent references.

Test A (absolute, vs the existing product)
    Rebuild LED1 and LED6 mosaics from quicklook data under each candidate
    orientation, dark-subtract and rebin exactly as ``compile_rcs_trend`` does,
    then correlate each SCA's own block against the same block of the existing
    trend cube. Correlation is scale-free, so the unexplained case1/case3
    normalisation factor cannot influence the outcome. Because this script runs
    the identical build+rebin path, the (900,1400) blocks line up by
    construction -- no ad-hoc ``//5`` alignment.

Test B (relative, romancal vs quicklook)
    The same exposure of the same detector processed by two pipelines: compare
    a quicklook SCA against its romancal counterpart under each transform. Same
    photons and same pixels, so the correct transform should stand out sharply.

Tests A and B are retained but **superseded** -- they are kept because their
failure mode is instructive. Both lean on LED flux, and the SRCS illumination is
a smooth, near-x-symmetric gradient, so a mirrored frame correlates almost as
well as the right one (test B, SCA 2: fliplr +0.81 vs identity +0.72). Test A
additionally reports a per-rotation-class median, and reading only the rot==0
class from the noisier quicklook data points at the wrong answer. Tests C and D
are the ones the default orientation rests on.

Test C (absolute, high signal-to-noise: romancal vs the existing product)
    Same idea as test A, but against romancal rather than quicklook, and
    operating on the *staged r=4 mosaics* rather than re-reading per-SCA files:
    each candidate transform is applied to each SCA's 1024x1024 block in place,
    then the whole mosaic is rebinned by 5 and correlated block by block. That
    is exactly equivalent to transforming the frame before placement (the block
    is precisely the SCA footprint), and it makes a six-way scan cheap. romancal
    is a far better spatial match to the existing cube than quicklook is
    (rho ~0.95 vs ~0.6), which is what gives this test its discriminating power.

Test D (relative, bad-pixel footprints)
    Jaccard overlap of the quicklook and romancal DQ masks for the same
    exposure, under each transform, for every SCA. Bad pixels are a
    high-frequency, asymmetric, per-detector fingerprint -- the opposite of
    smooth illumination -- so this is the test that can actually see a flip. It
    settles the quicklook-vs-romancal relative question that test B could not.
"""
import argparse
import os
import sys

import numpy as np

import form_mpa_mosaic as fm
import read_per_sca as rps
from compile_rcs_trend import load_from_hdf5, nan_superpixel

QL_ROOT = "/mnt/roman-science-east-2/ql_output/Program_00123"
SCIPA_ROOT = ("/mnt/roman-science-internal/romancal_l2_outputs/tvac/scipa/"
              "ChromaticStability/OTP00775_RCSEChrmStbA_SCIPAc_R17")
ORIGINAL_H5 = ("/mnt/roman-science-east-2/eswitzer/RCS_trend/"
               "TVAC_HOB_OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA.h5")

REBIN = 5
R = 4
# Activity -> the h5 key process_trending_run would give it (activity index).
ACTIVITY_TO_LED = {2: "LED1", 3: "LED2", 4: "LED3",
                   5: "LED4", 6: "LED5", 7: "LED6"}
# SCAs with enough illumination structure for a correlation test to mean
# anything; the focal-plane corners see very little SRCS light. Both mounting
# rotations must be represented: the mosaic_plot_FPS convention reduces to
# flipud for rot==180 and to fliplr for rot==0, so a sample drawn from one
# rotation class alone cannot distinguish it from a single fixed flip.
STRUCTURED_SCAS_ROT180 = (1, 2, 4, 5, 10, 11, 13, 14, 16, 17)
STRUCTURED_SCAS_ROT0 = (3, 12, 15, 18)
STRUCTURED_SCAS = STRUCTURED_SCAS_ROT180 + STRUCTURED_SCAS_ROT0


def robust_corr(a, b, min_pix=200):
    """Pearson correlation over pixels finite in both, after outlier trimming."""
    good = np.isfinite(a) & np.isfinite(b)
    if good.sum() < min_pix:
        return np.nan, int(good.sum())
    x, y = a[good], b[good]
    # A handful of surviving hot pixels can manufacture a correlation on their
    # own; trim the extreme 1% of each before correlating.
    keep = ((x > np.percentile(x, 0.5)) & (x < np.percentile(x, 99.5)) &
            (y > np.percentile(y, 0.5)) & (y < np.percentile(y, 99.5)))
    x, y = x[keep], y[keep]
    if x.size < min_pix or np.std(x) == 0 or np.std(y) == 0:
        return np.nan, int(x.size)

    return float(np.corrcoef(x, y)[0, 1]), int(x.size)


def block_slices(sca, rebin=REBIN, r=R, geom=None, inset=2):
    """Slices selecting one SCA's interior on the rebinned mosaic grid.

    ``inset`` drops superpixels at the block edge, which are contaminated
    because the r=4 block bounds are not multiples of ``rebin`` (SCA1 starts at
    row 2541, and 2541/5 = 508.2), so edge superpixels mix two SCAs or mix an
    SCA with the NaN gap.
    """
    r1, r2, c1, c2 = fm.sca_placement(sca, r, geom)
    row0 = -(-r1 // rebin) + inset
    row1 = r2 // rebin - inset
    col0 = -(-c1 // rebin) + inset
    col1 = c2 // rebin - inset

    return slice(row0, row1), slice(col0, col1)


def load_ql_activity(activity, scas=None, apply_dq=True, r=R, verbose=True):
    """Read one quicklook activity and return per-SCA arrays pre-binned to 4096/r."""
    activities = rps.discover_activities(QL_ROOT, "ql")
    if activity not in activities:
        raise KeyError(f"activity {activity} not found under {QL_ROOT}")
    frames_paths = activities[activity]["frames"]

    binned = {}
    for sca in sorted(frames_paths):
        if scas is not None and sca not in scas:
            continue
        frame, _, _ = rps.read_ql_sca(frames_paths[sca], apply_dq=apply_dq)
        binned[sca] = fm.bin_frame(fm.pad_to_4096(frame), r)
    if verbose:
        print(f"  QL activity {activity}: {len(binned)} SCAs binned to {r}x")

    return binned


def test_a_absolute(orientations=fm.ORIENTATIONS, activities=(2, 7),
                    apply_dq=True):
    """Correlate rebuilt quicklook mosaics against the existing trend cube."""
    geom = fm.load_geometry()
    _, original = load_from_hdf5(ORIGINAL_H5)

    print("Reading quicklook dark (activity 1) and", list(activities))
    dark = load_ql_activity(1, apply_dq=apply_dq)
    signal = {act: load_ql_activity(act, apply_dq=apply_dq) for act in activities}

    results = []
    for orientation in orientations:
        dark_mosaic = fm.build_mosaic(dark, r=R, geom=geom, dtype=np.float64,
                                      orientation=orientation, prebinned=True)
        dark_rebin = nan_superpixel(dark_mosaic, REBIN)

        for act in activities:
            led = ACTIVITY_TO_LED[act]
            mosaic = fm.build_mosaic(signal[act], r=R, geom=geom,
                                     dtype=np.float64,
                                     orientation=orientation, prebinned=True)
            rebuilt = nan_superpixel(mosaic, REBIN) - dark_rebin
            reference = original[led]

            per_sca = {}
            for sca in STRUCTURED_SCAS:
                rows, cols = block_slices(sca, geom=geom)
                rho, npix = robust_corr(rebuilt[rows, cols],
                                        reference[rows, cols])
                per_sca[sca] = rho
            values = np.array([v for v in per_sca.values() if np.isfinite(v)])
            whole, n_whole = robust_corr(rebuilt, reference)

            def class_median(members):
                vals = [per_sca[s] for s in members
                        if s in per_sca and np.isfinite(per_sca[s])]
                return float(np.median(vals)) if vals else np.nan

            rot180 = class_median(STRUCTURED_SCAS_ROT180)
            rot0 = class_median(STRUCTURED_SCAS_ROT0)
            results.append({"orientation": orientation, "led": led,
                            "whole_rho": whole, "n_whole": n_whole,
                            "median_sca_rho": float(np.median(values)),
                            "min_sca_rho": float(values.min()),
                            "rot180_rho": rot180, "rot0_rho": rot0,
                            "per_sca": per_sca})
            print(f"  {orientation:16s} {led}  whole={whole:+.4f}  "
                  f"median={np.median(values):+.4f}  "
                  f"rot180={rot180:+.4f}  rot0={rot0:+.4f}")

    return results


def test_b_relative(activity=2, scas=(2, 5, 14, 16), apply_dq=True):
    """Compare romancal vs quicklook for the same exposures, per SCA.

    Reported as the transform that must be applied to the *romancal* array to
    match the quicklook array. If that is ``identity``, the two products store
    rows and columns the same way and a single orientation serves both.
    """
    ql_acts = rps.discover_activities(QL_ROOT, "ql")
    scipa_acts = rps.discover_activities(SCIPA_ROOT, "scipa")
    transforms = {
        "identity": lambda a: a,
        "fliplr": lambda a: a[:, ::-1],
        "flipud": lambda a: a[::-1, :],
        "rot180": lambda a: a[::-1, ::-1],
    }

    rows = []
    for sca in scas:
        if sca not in scipa_acts[activity]["frames"]:
            print(f"  SCA {sca}: absent from romancal activity {activity}, skipping")
            continue
        ql, _, _ = rps.read_ql_sca(ql_acts[activity]["frames"][sca],
                                   apply_dq=apply_dq)
        sc, _, _ = rps.read_scipa_sca(scipa_acts[activity]["frames"][sca],
                                      apply_dq=apply_dq)
        sc = fm.pad_to_4096(sc)
        # Bin before correlating: it suppresses per-pixel noise and read
        # artefacts, so the comparison reflects the illumination pattern.
        ql_b = fm.bin_frame(ql, 8)
        scores = {}
        for name, fn in transforms.items():
            rho, npix = robust_corr(ql_b, fm.bin_frame(fn(sc), 8))
            scores[name] = rho
        order = sorted(scores, key=lambda k: -(scores[k] if np.isfinite(scores[k]) else -9))
        best, runner = order[0], order[1]
        rows.append({"sca": sca, "best": best,
                     "best_rho": scores[best],
                     "margin": scores[best] - scores[runner], **scores})
        print(f"  SCA {sca:2d}: " +
              "  ".join(f"{k}={scores[k]:+.4f}" for k in transforms) +
              f"   -> best={best} (margin {scores[best]-scores[runner]:+.4f})")

    return rows


STAGED_MOSAICS = ("/mnt/roman-science-east-2/eswitzer/RCS_trend/car190_staging/"
                  "{case}/TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA/"
                  "stability_check/mosaics")
# Transforms applied on top of whatever orientation the staged mosaics used.
BLOCK_TRANSFORMS = {"identity": lambda a: a,
                    "fliplr": lambda a: a[:, ::-1],
                    "flipud": lambda a: a[::-1, :],
                    "rot180": lambda a: a[::-1, ::-1]}
ALL_SCAS = tuple(s for s in range(1, 19) if s != 8)


def _staged_mosaic(case, activity):
    """Read one staged r=4 mosaic, located by activity number."""
    import glob

    pattern = os.path.join(STAGED_MOSAICS.format(case=case),
                           f"*_act{activity}_*_mosaic.fits")
    matches = glob.glob(pattern)
    if len(matches) != 1:
        raise FileNotFoundError(f"expected exactly one match for {pattern}, "
                                f"found {len(matches)}")
    mosaic, header = fm.read_mosaic_fits(matches[0])

    return mosaic.astype(np.float64), header


def test_c_block_transforms(case="scipa", activities=(2, 7),
                            transforms=BLOCK_TRANSFORMS):
    """Scan per-SCA block transforms on the staged mosaics against the original.

    Reported per transform as the median correlation within each rotation class.
    The transform is applied *on top of* the orientation the mosaics were staged
    with, which the header records as ``ORIENT``; ``identity`` therefore means
    "as staged". Composing the two gives the absolute convention.
    """
    geom = fm.load_geometry()
    _, original = load_from_hdf5(ORIGINAL_H5)
    dark, header = _staged_mosaic(case, 1)
    staged_with = str(header.get("ORIENT", "unknown"))
    print(f"  staged with ORIENT={staged_with}; "
          f"'identity' below means 'as staged'")

    results = []
    for activity in activities:
        led = ACTIVITY_TO_LED[activity]
        signal, _ = _staged_mosaic(case, activity)
        difference = signal - dark
        for name, transform in transforms.items():
            mosaic = difference.copy()
            for sca in range(1, 19):
                r1, r2, c1, c2 = fm.sca_placement(sca, R, geom)
                mosaic[r1:r2, c1:c2] = transform(mosaic[r1:r2, c1:c2])
            rebinned = nan_superpixel(mosaic, REBIN)

            per_sca = {}
            for sca in ALL_SCAS:
                rows, cols = fm.rebinned_block_slices(sca, REBIN, R, geom)
                per_sca[sca], _ = robust_corr(rebinned[rows, cols],
                                              original[led][rows, cols])
            finite = np.array([v for v in per_sca.values() if np.isfinite(v)])

            def class_median(members):
                values = [per_sca[s] for s in members
                          if s in per_sca and np.isfinite(per_sca[s])]
                return float(np.median(values)) if values else np.nan

            whole, _ = robust_corr(rebinned, original[led])
            results.append({
                "case": case, "led": led, "staged_with": staged_with,
                "extra_transform": name, "whole_rho": whole,
                "median_rho": float(np.median(finite)),
                "min_rho": float(finite.min()),
                "n_positive": int((finite > 0).sum()), "n_sca": int(finite.size),
                "rot180_rho": class_median(STRUCTURED_SCAS_ROT180),
                "rot0_rho": class_median(STRUCTURED_SCAS_ROT0),
                "per_sca": per_sca})
            print(f"  {name:10s} {led}  median={np.median(finite):+.4f}  "
                  f"min={finite.min():+.4f}  "
                  f"positive={int((finite > 0).sum())}/{finite.size}  "
                  f"rot180={class_median(STRUCTURED_SCAS_ROT180):+.4f}  "
                  f"rot0={class_median(STRUCTURED_SCAS_ROT0):+.4f}")

    return results


def test_d_dq_footprints(activity=2, transforms=BLOCK_TRANSFORMS):
    """Match quicklook and romancal bad-pixel footprints under each transform.

    Jaccard overlap of the two DQ masks. The outer 8-pixel ring is excluded so
    that the NaN padding used to take romancal's 4088 array up to 4096 cannot
    contribute, and so reference-pixel bookkeeping differences between the two
    pipelines stay out of the comparison.
    """
    from astropy.io import fits
    import asdf

    rps._quiet_asdf_extension_warnings()
    geom = fm.load_geometry()
    ql_acts = rps.discover_activities(QL_ROOT, "ql")
    scipa_acts = rps.discover_activities(SCIPA_ROOT, "scipa")
    interior = (slice(8, -8), slice(8, -8))

    rows = []
    shared = sorted(set(ql_acts[activity]["frames"])
                    & set(scipa_acts[activity]["frames"]))
    for sca in shared:
        with fits.open(ql_acts[activity]["frames"][sca]) as hdul:
            ql_dq = np.asarray(hdul["DQ"].data) != 0
        with asdf.open(scipa_acts[activity]["frames"][sca], lazy_load=True,
                       memmap=False) as af:
            scipa_dq = np.asarray(af.tree["roman"]["dq"]) != 0
        scipa_dq = np.pad(scipa_dq, 4, constant_values=False)

        reference = ql_dq[interior]
        scores = {}
        for name, transform in transforms.items():
            candidate = transform(scipa_dq)[interior]
            union = (reference | candidate).sum()
            scores[name] = float((reference & candidate).sum() / union) if union else np.nan
        order = sorted(scores, key=lambda k: -scores[k])
        best, runner = order[0], order[1]
        rows.append({"sca": sca, "rotation": int(geom[sca][2]),
                     "n_ql_flagged": int(reference.sum()),
                     "n_scipa_flagged": int(scipa_dq[interior].sum()),
                     "best": best,
                     "margin": scores[best] / max(scores[runner], 1e-12),
                     **scores})
        print(f"  SCA {sca:2d} (rot {int(geom[sca][2]):3d}): " +
              "  ".join(f"{k}={scores[k]:.4f}" for k in transforms) +
              f"   -> {best} ({scores[best] / max(scores[runner], 1e-12):.1f}x)")

    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--test", choices=("a", "b", "c", "d", "cd", "both",
                                           "all"), default="cd")
    parser.add_argument("--no-dq", action="store_true",
                        help="skip DQ masking (diagnostic only)")
    parser.add_argument("--report", default="plots/orientation_calibration.md")
    args = parser.parse_args()
    apply_dq = not args.no_dq

    lines = ["# Orientation calibration", "",
             f"DQ masking: {'on' if apply_dq else 'OFF'}", ""]

    if args.test in ("a", "both", "all"):
        print("== Test A: rebuilt quicklook mosaics vs existing trend cube ==")
        results = test_a_absolute(apply_dq=apply_dq)
        lines += ["## Test A -- absolute, vs existing h5", "",
                  "| orientation | LED | whole rho | median per-SCA rho | "
                  "rot180 SCAs | rot0 SCAs |",
                  "|---|---|---|---|---|---|"]
        for row in results:
            lines.append(f"| {row['orientation']} | {row['led']} | "
                         f"{row['whole_rho']:+.4f} | {row['median_sca_rho']:+.4f} | "
                         f"{row['rot180_rho']:+.4f} | {row['rot0_rho']:+.4f} |")
        best = max(results, key=lambda d: d["median_sca_rho"])
        lines += ["", f"Best: **{best['orientation']}** "
                      f"(median per-SCA rho {best['median_sca_rho']:+.4f})", ""]
        print(f"\n  => Test A favours: {best['orientation']}")

    if args.test in ("b", "both", "all"):
        print("\n== Test B: romancal vs quicklook, same exposures ==")
        rows = test_b_relative(apply_dq=apply_dq)
        lines += ["## Test B -- romancal relative to quicklook", "",
                  "| SCA | identity | fliplr | flipud | rot180 | best | margin |",
                  "|---|---|---|---|---|---|---|"]
        for row in rows:
            lines.append(f"| {row['sca']} | {row['identity']:+.4f} | "
                         f"{row['fliplr']:+.4f} | {row['flipud']:+.4f} | "
                         f"{row['rot180']:+.4f} | {row['best']} | "
                         f"{row['margin']:+.4f} |")
        verdict = {}
        for row in rows:
            verdict[row["best"]] = verdict.get(row["best"], 0) + 1
        lines += ["", f"Verdict by majority: **{max(verdict, key=verdict.get)}** "
                      f"({verdict})", ""]
        print(f"\n  => Test B verdict: {max(verdict, key=verdict.get)} ({verdict})")

    if args.test in ("c", "cd", "all"):
        print("\n== Test C: staged romancal mosaics vs existing trend cube ==")
        results = test_c_block_transforms()
        staged_with = results[0]["staged_with"] if results else "unknown"
        lines += ["## Test C -- romancal blocks vs existing h5", "",
                  f"Staged with `ORIENT={staged_with}`; the transform column is "
                  "applied *on top of* that, so `identity` means 'as staged'. "
                  "Compose the two to get the absolute convention.", "",
                  "| extra transform | LED | median rho | min rho | positive | "
                  "rot180 SCAs | rot0 SCAs |",
                  "|---|---|---|---|---|---|---|"]
        for row in results:
            lines.append(f"| {row['extra_transform']} | {row['led']} | "
                         f"{row['median_rho']:+.4f} | {row['min_rho']:+.4f} | "
                         f"{row['n_positive']}/{row['n_sca']} | "
                         f"{row['rot180_rho']:+.4f} | {row['rot0_rho']:+.4f} |")
        best = max(results, key=lambda d: d["median_rho"])
        lines += ["", f"Best extra transform: **{best['extra_transform']}** "
                      f"(median rho {best['median_rho']:+.4f}, "
                      f"{best['n_positive']}/{best['n_sca']} SCAs positive)",
                  "", "A correct convention is positive for *both* rotation "
                      "classes at once. Any transform that is strong for one "
                      "class and negative for the other is mirroring half the "
                      "focal plane.", ""]
        print(f"\n  => Test C favours extra transform: {best['extra_transform']} "
              f"on top of {staged_with}")

    if args.test in ("d", "cd", "all"):
        print("\n== Test D: DQ bad-pixel footprints, quicklook vs romancal ==")
        rows = test_d_dq_footprints()
        lines += ["## Test D -- bad-pixel footprints (Jaccard overlap)", "",
                  "Transform applied to the *romancal* mask to match quicklook. "
                  "`identity` means the two products share a convention.", "",
                  "| SCA | rot | n flagged QL | n flagged romancal | identity | "
                  "fliplr | flipud | rot180 | best | margin |",
                  "|---|---|---|---|---|---|---|---|---|---|"]
        for row in rows:
            lines.append(f"| {row['sca']} | {row['rotation']} | "
                         f"{row['n_ql_flagged']} | {row['n_scipa_flagged']} | "
                         f"{row['identity']:.4f} | {row['fliplr']:.4f} | "
                         f"{row['flipud']:.4f} | {row['rot180']:.4f} | "
                         f"{row['best']} | {row['margin']:.1f}x |")
        verdict = {}
        for row in rows:
            verdict[row["best"]] = verdict.get(row["best"], 0) + 1
        winner = max(verdict, key=verdict.get)
        lines += ["", f"Verdict: **{winner}** for {verdict[winner]}/{len(rows)} "
                      f"SCAs ({verdict})", ""]
        print(f"\n  => Test D verdict: {winner} ({verdict})")

    os.makedirs(os.path.dirname(args.report) or ".", exist_ok=True)
    with open(args.report, "w") as handle:
        handle.write("\n".join(lines) + "\n")
    print(f"\nWrote {args.report}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
