"""Carry a CAR-94 RCS LED flat of one SCA from one pass to another with the ice response
model, and compare with the flat measured at the second pass.

    python car94_flat_transfer.py --sca 1 --passes 12 16 [--model v2] [--no-gray]
        [--data-root s3://roman-s3-romcom/... /mnt/roman-s3-romcom/...] [--out-dir DIR]
        [--write-predicted]

**The data.** The CAR-94 science monitor's interim reference flats,
``interim_refflats/roman_flat_{wfiNN}_{filter}[_pass{P}].asdf``, read directly from
``s3://roman-s3-romcom/activities/CAR-94-Science-Monitor`` or, failing that (no boto3,
no credentials, no network), its mount ``/mnt/roman-s3-romcom/...``.

* They are RCS LED flats: the LED-illuminated detector through the DARK element, one per
  LED band, named for the nearest filter: LED1 F062, LED2 F087, LED3 F106, LED4 F129,
  LED5 F158, LED6 F184. Pass 11 (the first) has no ``_pass`` suffix.
* They carry no time. Each LED's time in a pass is the mean midpoint of that pass's
  exposures of the SCA with that LED, from the L2 exposures (``L2_flats/``; only the
  start of each file, its metadata, is read).

**The transfer.** Per LED band j, on the model's superpixel grid (16 x 16 pixels for
release v2):

    T_j = L_j(t_B) / L_j(t_A),    predicted flat_B = flat_A x T_j

* ``L_j`` is ``IceResponseModel.band_response`` with the model's own LED band
  quadrature, weighted by each superpixel's no-ice transmission, i.e. the band integral
  the model was fitted with (``led_band_response``), at that LED's own exposure times.
* The flats are binned to the same grid: cell (r, c) covers detector pixels
  [px r, px r + px) x [px c, px c + px) of the 4096 frame (science frame). The flats hold
  the 4088 science pixels (detector pixel = science pixel + 4); pixels with ``dq != 0``
  are left out.
* The flats are not normalized to one, so the comparison is of shapes: each map divided
  by its median over the SCA.

**Outputs** (``--out-dir``, default ``./car94_flat_transfer_SCA{NN}_pass{A}_to_pass{B}``):

* ``transfer.h5``: per band (6, N, N), ``flat_a``, ``flat_b``, ``transfer``, ``ratio``
  (``flat_b / flat_a``) and ``residual`` (``flat_b / (flat_a T)``); the model's
  ``reportable`` and ``quality_mask``; the ice thickness at both passes; the times;
* ``{filter}.png``: four maps, ``flat_B / flat_A``, ``T`` and ``flat_B / (flat_A T)`` on
  one colour scale, and the last on its own;
* ``summary.png``, ``summary.json``: the robust rms of each map within the SCA, and the
  slope and correlation of the measured shape on the model's;
* with ``--write-predicted``, ``predicted_flat_pass{B}.h5``: the full-resolution
  (4088 x 4088) flats of pass A times the transfer, per band.

A time after the model's last epoch is an extrapolation at the last fitted deposition
rate (it is flagged). Needs ``ice_response_model.py`` beside this file, numpy, h5py,
matplotlib, asdf and lz4 (to read the flats), PyYAML (comes with asdf), and boto3 for
s3:// (optional: without it the mount is used).
"""
from __future__ import annotations

import argparse
import io
import json
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np

try:                                       # part of the package (the fitting repo)
    from . import ice_response_model as irm
except ImportError:                        # run as a script, or copied beside it
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import ice_response_model as irm  # noqa: E402

CAR94_ROOTS = ("s3://roman-s3-romcom/activities/CAR-94-Science-Monitor",
               "/mnt/roman-s3-romcom/activities/CAR-94-Science-Monitor")
FLATS, L2 = "interim_refflats", "L2_flats"
LED_FILTERS = ("F062", "F087", "F106", "F129", "F158", "F184")       # LED1..LED6
FIRST_PASS = 11                    # its flats have no _pass suffix
SCA_PIX, SCI_PIX = 4096, 4088
BORDER = (SCA_PIX - SCI_PIX) // 2
HEADER_BYTES = 1 << 16             # an L2 file's metadata tree is its first ~21 KB


# --------------------------------------------------------------------------- #
# the data
# --------------------------------------------------------------------------- #
def flat_name(sca: int, filt: str, pass_: int) -> str:
    suffix = "" if int(pass_) == FIRST_PASS else f"_pass{int(pass_)}"
    return f"roman_flat_wfi{int(sca):02d}_{filt}{suffix}.asdf"


def _yaml_tree(head: bytes) -> dict:
    """An ASDF file's YAML tree from its first bytes, every custom tag read as plain
    YAML (the arrays' blocks are not needed for the metadata)."""
    import yaml

    class Loader(yaml.SafeLoader):
        pass

    def any_tag(loader, suffix, node):
        if isinstance(node, yaml.MappingNode):
            return loader.construct_mapping(node, deep=True)
        if isinstance(node, yaml.SequenceNode):
            return loader.construct_sequence(node, deep=True)
        return loader.construct_scalar(node)

    Loader.add_multi_constructor("", any_tag)
    end = head.find(b"\n...")
    if end < 0:
        raise ValueError("the YAML tree does not end within the bytes read")
    return yaml.load(head[:end].decode("utf-8", "replace"), Loader=Loader)


def _when(v) -> np.datetime64:
    v = v.get("value", v) if isinstance(v, dict) else v
    return np.datetime64(str(v).replace("Z", "")[:23], "ms")


def pass_times(root, sca: int, pass_: int, n_thread: int = 16) -> dict:
    """``{led: dict(start_utc, end_utc, mid_utc, n)}`` from the pass's L2 exposures of
    the SCA (file names ``r{visit id}_{exposure}_wfi{NN}_...``; the visit id's digits
    8-10 are the pass)."""
    names = [n for n in irm.list_names(irm.join(root, L2), "r")
             if n[8:11] == f"{int(pass_):03d}" and f"_wfi{int(sca):02d}_" in n]
    if not names:
        raise FileNotFoundError(f"no L2 exposures of pass {pass_}, SCA {sca} under "
                                f"{irm.join(root, L2)}")

    def one(name):
        head = irm.read_bytes(irm.join(root, L2, name), 0, HEADER_BYTES)
        try:
            m = _yaml_tree(head)["roman"]["meta"]
        except ValueError:                       # a longer tree: read more
            m = _yaml_tree(irm.read_bytes(irm.join(root, L2, name), 0, 1 << 20))["roman"]["meta"]
        ok = (int(m["observation"]["pass"]) == int(pass_)
              and str(m["rcs"]["active"]).lower() == "true")
        return (int(m["rcs"]["led"]), _when(m["exposure"]["start_time"]),
                _when(m["exposure"]["end_time"])) if ok else None

    with ThreadPoolExecutor(n_thread) as ex:
        rows = [r for r in ex.map(one, names) if r is not None]
    out = {}
    for led in sorted({r[0] for r in rows}):
        t0 = np.array([r[1] for r in rows if r[0] == led], "datetime64[ms]")
        t1 = np.array([r[2] for r in rows if r[0] == led], "datetime64[ms]")
        mid = (t0.astype(np.int64) + t1.astype(np.int64)) / 2.0
        out[led] = dict(start_utc=str(t0.min()), end_utc=str(t1.max()),
                        mid_utc=str(np.datetime64(int(round(mid.mean())), "ms")), n=int(t0.size))
    if sorted(out) != list(range(1, 7)):
        raise ValueError(f"pass {pass_}, SCA {sca}: exposures found for LEDs {sorted(out)}")
    return out


def read_flat(root, sca: int, filt: str, pass_: int):
    """``(data, dq, err)`` (4088 x 4088) of one flat, read whole into memory."""
    import asdf
    where = irm.join(root, FLATS, flat_name(sca, filt, pass_))
    with asdf.open(io.BytesIO(irm.read_bytes(where)), lazy_load=False, memmap=False) as f:
        r = f.tree["roman"]
        det = str(r["meta"]["instrument"]["detector"]).upper()
        if det != f"WFI{int(sca):02d}":
            raise ValueError(f"{where}: detector {det}")
        return (np.asarray(r["data"], np.float64), np.asarray(r["dq"]),
                np.asarray(r["err"], np.float64))


def bin_flat(data, dq, err, n_bin: int):
    """``(mean, sem, n_good)`` of a 4088 x 4088 flat on the ``n_bin`` grid of the 4096
    frame: reference pixels and ``dq != 0`` left out."""
    full = np.full((SCA_PIX, SCA_PIX), np.nan)
    e2 = np.full((SCA_PIX, SCA_PIX), np.nan)
    good = (np.asarray(dq) == 0) & np.isfinite(data) & np.isfinite(err)
    s = slice(BORDER, BORDER + SCI_PIX)
    full[s, s] = np.where(good, data, np.nan)
    e2[s, s] = np.where(good, err ** 2, np.nan)
    r = SCA_PIX // n_bin
    blk = full.reshape(n_bin, r, n_bin, r)
    n = np.isfinite(blk).sum(axis=(1, 3))
    with np.errstate(invalid="ignore", divide="ignore"):
        mean = np.nansum(blk, axis=(1, 3)) / n
        sem = np.sqrt(np.nansum(e2.reshape(n_bin, r, n_bin, r), axis=(1, 3))) / n
    mean[n == 0] = sem[n == 0] = np.nan
    return mean, sem, n


def upsample(cells, n_bin: int):
    """A (n_bin, n_bin) map on the 4088 x 4088 science pixels (each pixel its cell's)."""
    idx = (np.arange(SCI_PIX) + BORDER) // (SCA_PIX // n_bin)
    return np.asarray(cells)[np.ix_(idx, idx)]


# --------------------------------------------------------------------------- #
# the transfer
# --------------------------------------------------------------------------- #
def transfer_map(m, sca: int, t_a, t_b, gray: bool = True) -> np.ndarray:
    """``T`` (6, N, N): each LED band's response at ``t_b[j]`` over that at ``t_a[j]``,
    on the model's grid for one SCA."""
    n = m.n_bin
    px = SCA_PIX // n
    r, c = np.meshgrid(np.arange(n), np.arange(n), indexing="ij")
    x, y = (c * px + px // 2).ravel(), (r * px + px // 2).ravel()
    out = np.empty((6, n * n))
    for j in range(6):
        L = m.band_response(int(sca), x, y, [t_a[j], t_b[j]], m.led_nodes_nm[j],
                            m.led_weight[j], gray=gray, no_ice_weight=True)
        out[j] = L[:, 1] / L[:, 0]
    return out.reshape(6, n, n)


def shape(a, sel):
    """``a / median over the selected cells - 1``, per band."""
    a = np.asarray(a, float)
    med = np.array([np.nanmedian(a[j][sel]) for j in range(a.shape[0])])
    return a / med[:, None, None] - 1.0


def robust_rms(v):
    v = np.asarray(v)[np.isfinite(v)]
    return float(1.4826 * np.median(np.abs(v - np.median(v)))) if v.size else float("nan")


def run(sca: int, pass_a: int, pass_b: int, model=None, roots=CAR94_ROOTS, gray=True,
        out_dir=None, write_predicted=False, say=print) -> dict:
    """The transfer analysis of one SCA between two passes; returns the summary."""
    import h5py

    m = irm.IceResponseModel(model, say=say)
    if m.led_weight is None:
        raise SystemExit(f"{m.path.name} has no led_bands; use release v2 or later")
    say(str(m))
    root = irm.first_root(roots, irm.join(FLATS, flat_name(sca, LED_FILTERS[0], pass_a)), say=say)
    n_bin = m.n_bin
    times = {p: pass_times(root, sca, p) for p in (pass_a, pass_b)}
    t_a = [times[pass_a][j + 1]["mid_utc"] for j in range(6)]
    t_b = [times[pass_b][j + 1]["mid_utc"] for j in range(6)]
    for p, ts in ((pass_a, t_a), (pass_b, t_b)):
        if not np.all(m.valid(ts)):
            raise SystemExit(f"pass {p} ({ts[0][:16]}) is outside the model (before "
                             f"{m.t0_utc[:16]} or in a decon warm-up)")
    h_last = m.hours([m.t_last_utc])[0]
    extrap = [f"pass {p}" for p, ts in ((pass_a, t_a), (pass_b, t_b))
              if np.any(m.hours(ts) > h_last)]
    say(f"SCA {sca}: pass {pass_a} ({t_a[0][:16]} UTC) -> pass {pass_b} ({t_b[0][:16]} UTC)"
        + (f"; model extrapolated at {', '.join(extrap)} (after {m.t_last_utc[:16]})"
           if extrap else ""))

    # the flats, read in parallel, binned as they arrive
    jobs = [(j, p) for j in range(6) for p in (pass_a, pass_b)]
    binned, full_a = {}, {}

    def load(job):
        j, p = job
        d, q, e = read_flat(root, sca, LED_FILTERS[j], p)
        keep = (d, q) if (write_predicted and p == pass_a) else None
        return job, bin_flat(d, q, e, n_bin), keep

    with ThreadPoolExecutor(4) as ex:
        for job, b, keep in ex.map(load, jobs):
            binned[job] = b
            if keep is not None:
                full_a[job[0]] = keep
    fa = np.stack([binned[(j, pass_a)][0] for j in range(6)])
    fb = np.stack([binned[(j, pass_b)][0] for j in range(6)])
    na = np.stack([binned[(j, pass_a)][2] for j in range(6)])
    nb = np.stack([binned[(j, pass_b)][2] for j in range(6)])
    min_good = (SCA_PIX // n_bin) ** 2 // 2
    ok = (na >= min_good) & (nb >= min_good)
    fa, fb = np.where(ok, fa, np.nan), np.where(ok, fb, np.nan)

    T = transfer_map(m, sca, t_a, t_b, gray=gray)
    r, c = np.meshgrid(np.arange(n_bin), np.arange(n_bin), indexing="ij")
    px = SCA_PIX // n_bin
    q = m.quality(int(sca), (c * px + px // 2).ravel(), (r * px + px // 2).ravel())
    rep = q["reportable"].reshape(n_bin, n_bin).astype(bool)
    d = m.thickness(int(sca), (c * px + px // 2).ravel(), (r * px + px // 2).ravel(),
                    [t_a[2], t_b[2]]).reshape(n_bin, n_bin, 2)
    ratio, resid = fb / fa, fb / (fa * T)
    sel = rep & np.all(ok, axis=0)
    sh = {k: np.where(sel[None], shape(v, sel), np.nan)
          for k, v in (("ratio", ratio), ("transfer", T), ("residual", resid))}

    out_dir = Path(out_dir or f"car94_flat_transfer_SCA{int(sca):02d}_pass{pass_a}_to_pass{pass_b}")
    out_dir.mkdir(parents=True, exist_ok=True)
    summ = dict(sca=int(sca), pass_a=pass_a, pass_b=pass_b, model=str(m.path),
                model_release=str(m.version), data_root=str(root), gray_applied=gray,
                extrapolated=extrap, times={f"pass{pass_a}": times[pass_a],
                                            f"pass{pass_b}": times[pass_b]},
                n_cells_compared=int(sel.sum()), bands={})
    for j, filt in enumerate(LED_FILTERS):
        x, y = sh["transfer"][j][sel], sh["ratio"][j][sel]
        k = np.isfinite(x) & np.isfinite(y)
        summ["bands"][filt] = dict(
            led=j + 1, rms_without_ppm=robust_rms(1e6 * sh["ratio"][j]),
            rms_with_ppm=robust_rms(1e6 * sh["residual"][j]),
            rms_model_ppm=robust_rms(1e6 * sh["transfer"][j]),
            slope_measured_on_model=float(np.sum(x[k] * y[k]) / np.sum(x[k] ** 2)),
            corr=float(np.corrcoef(x[k], y[k])[0, 1]),
            median_transfer=float(np.nanmedian(T[j][sel])),
            median_ratio=float(np.nanmedian(ratio[j][sel])))

    kw = dict(compression="gzip", compression_opts=4, shuffle=True)
    with h5py.File(out_dir / "transfer.h5", "w") as f:
        f.attrs.update(sca=int(sca), pass_a=pass_a, pass_b=pass_b, n_bin=n_bin,
                       model=str(m.path), model_release=str(m.version), data_root=str(root),
                       gray_applied=gray, extrapolated=", ".join(extrap) or "none",
                       note="cell (r, c) covers detector pixels [px r, px r + px) x [px c, "
                            "px c + px) of the 4096 frame; ratio = flat_b / flat_a, residual "
                            "= flat_b / (flat_a transfer); cells with fewer than half their "
                            "pixels good in either flat are NaN")
        for k_, v in (("flat_a", fa), ("flat_b", fb), ("transfer", T), ("ratio", ratio),
                      ("residual", resid)):
            f.create_dataset(k_, data=v.astype(np.float32), **kw)
        f.create_dataset("reportable", data=rep, **kw)
        f.create_dataset("quality_mask", data=np.asarray(q["quality_mask"]).reshape(n_bin, n_bin), **kw)
        f.create_dataset("thickness_nm", data=d.astype(np.float32), **kw)
        f["mid_utc_a"], f["mid_utc_b"] = np.asarray(t_a, "S"), np.asarray(t_b, "S")
        f["filter"] = np.asarray(LED_FILTERS, "S")
    if write_predicted:
        with h5py.File(out_dir / f"predicted_flat_pass{pass_b}.h5", "w") as f:
            f.attrs.update(sca=int(sca), pass_a=pass_a, pass_b=pass_b, model=str(m.path),
                           note=f"pass {pass_a}'s flat (science pixels, 4088 x 4088) times the "
                                f"ice transfer to pass {pass_b}'s epoch, per LED band; dq is pass "
                                f"{pass_a}'s")
            for j, filt in enumerate(LED_FILTERS):
                dat, dq = full_a[j]
                g = f.create_group(filt)
                g.create_dataset("data", data=(dat * upsample(T[j], n_bin)).astype(np.float32),
                                 chunks=(512, 512), **kw)
                g.create_dataset("dq", data=dq, chunks=(512, 512), **kw)
    (out_dir / "summary.json").write_text(json.dumps(summ, indent=1))
    _figures(sh, T, sel, summ, t_a, t_b, out_dir)
    say(f"wrote {out_dir}/: transfer.h5, {{filter}}.png, summary.png, summary.json"
        + (f", predicted_flat_pass{pass_b}.h5" if write_predicted else ""))
    say("   band  rms within the SCA (ppm):  flat_B/flat_A  flat_B/(flat_A T)   slope  corr")
    for filt, b in summ["bands"].items():
        say(f"   {filt}  {b['rms_without_ppm']:33.0f} {b['rms_with_ppm']:18.0f}   "
            f"{b['slope_measured_on_model']:5.3f}  {b['corr']:5.3f}")
    return summ


# --------------------------------------------------------------------------- #
# figures
# --------------------------------------------------------------------------- #
def _figures(sh, T, sel, summ, t_a, t_b, out_dir: Path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import LinearSegmentedColormap

    irm._style()
    div = LinearSegmentedColormap.from_list("div", ["#0d366b", "#f0efec", "#8c1d1d"])
    div.set_bad("#9a9994")
    sca, pa, pb = summ["sca"], summ["pass_a"], summ["pass_b"]
    ext = f"; model extrapolated at {', '.join(summ['extrapolated'])}" if summ["extrapolated"] else ""
    for j, filt in enumerate(LED_FILTERS):
        b = summ["bands"][filt]
        lim = float(np.nanpercentile(np.abs(100 * sh["ratio"][j]), 99.0))
        lim4 = float(np.nanpercentile(np.abs(1e6 * sh["residual"][j]), 99.0))
        panels = [(100 * sh["ratio"][j], lim, "%", f"flat_B / flat_A: rms {b['rms_without_ppm']:.0f} ppm"),
                  (100 * sh["transfer"][j], lim, "%", f"model transfer T: rms {b['rms_model_ppm']:.0f} ppm"),
                  (100 * sh["residual"][j], lim, "%", f"flat_B / (flat_A T): rms {b['rms_with_ppm']:.0f} ppm"),
                  (1e6 * sh["residual"][j], lim4, "ppm", "flat_B / (flat_A T), own scale")]
        fig, ax = plt.subplots(1, 4, figsize=(22, 6.2))
        for a, (v, l_, unit, title) in zip(ax, panels):
            im = a.imshow(v, origin="lower", interpolation="nearest", cmap=div, vmin=-l_, vmax=l_)
            a.set_title(title, fontsize=10)
            a.set_xlabel("superpixel column (x // px)")
            a.grid(False)
            fig.colorbar(im, ax=a, fraction=0.046, pad=0.03, label=f"{unit} (SCA median removed)")
        ax[0].set_ylabel("superpixel row (y // px)")
        fig.suptitle(f"SCA {sca}, LED{j + 1} ({filt}): pass {pa} ({t_a[j][:16]}) -> pass {pb} "
                     f"({t_b[j][:16]} UTC); slope {b['slope_measured_on_model']:.3f}, r "
                     f"{b['corr']:.3f}{ext}", fontsize=11)
        fig.tight_layout()
        fig.savefig(out_dir / f"{filt}.png", dpi=110)
        plt.close(fig)

    fig, ax = plt.subplots(1, 7, figsize=(26, 4.4), gridspec_kw=dict(width_ratios=[1.6] + [1] * 6))
    xs = np.arange(6)
    ax[0].bar(xs - 0.2, [summ["bands"][f]["rms_without_ppm"] for f in LED_FILTERS], 0.4,
              color=irm._COLORS[1], label="without transfer")
    ax[0].bar(xs + 0.2, [summ["bands"][f]["rms_with_ppm"] for f in LED_FILTERS], 0.4,
              color=irm._COLORS[0], label="with transfer")
    ax[0].set_xticks(xs, LED_FILTERS)
    ax[0].set_yscale("log")
    ax[0].set_ylabel("robust rms within the SCA (ppm)")
    ax[0].legend(fontsize=8)
    for j, filt in enumerate(LED_FILTERS):
        a = ax[j + 1]
        x, y = 100 * sh["transfer"][j][sel], 100 * sh["ratio"][j][sel]
        k = np.isfinite(x) & np.isfinite(y)
        l_ = np.nanpercentile(np.abs(np.r_[x[k], y[k]]), 99.5)
        a.hist2d(x[k], y[k], bins=120, range=[[-l_, l_], [-l_, l_]], cmap="Greys",
                 norm=matplotlib.colors.LogNorm())
        a.plot([-l_, l_], [-l_, l_], "-", lw=1, color=irm._COLORS[0])
        s_ = summ["bands"][filt]["slope_measured_on_model"]
        a.plot([-l_, l_], [-l_ * s_, l_ * s_], "--", lw=1, color=irm._COLORS[1])
        a.set_title(f"{filt}: slope {s_:.3f}", fontsize=10)
        a.set_xlabel("model T shape (%)")
        a.set_aspect("equal")
    ax[1].set_ylabel("measured flat_B / flat_A shape (%)")
    fig.suptitle(f"SCA {sca}: pass {pa} -> {pb}, {summ['n_cells_compared']:,} reportable "
                 f"superpixels{ext}", fontsize=11)
    fig.tight_layout()
    fig.savefig(out_dir / "summary.png", dpi=110)
    plt.close(fig)


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--sca", type=int, required=True, help="SCA (detector) 1-18")
    p.add_argument("--passes", type=int, nargs=2, required=True, metavar=("A", "B"),
                   help="carry pass A's flat to pass B's epoch (passes 11, 12, 13, 14, 16, 17 as of 2026-10-30)")
    p.add_argument("--model", default=None,
                   help="model h5, s3:// URI or release version (default $ICE_RESPONSE_MODEL, "
                        "else the current release)")
    p.add_argument("--data-root", nargs="+", default=list(CAR94_ROOTS),
                   help="the CAR-94 area, tried in order (s3:// or a path)")
    p.add_argument("--no-gray", action="store_true",
                   help="the ice alone, without the model's per-decon gray (which matters "
                        "only across a decon)")
    p.add_argument("--out-dir", default=None)
    p.add_argument("--write-predicted", action="store_true",
                   help="also write pass A's full-resolution flats times the transfer")
    a = p.parse_args(argv)
    run(a.sca, a.passes[0], a.passes[1], model=a.model, roots=a.data_root,
        gray=not a.no_gray, out_dir=a.out_dir, write_predicted=a.write_predicted)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
