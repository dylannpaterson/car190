"""The RCS trending h5 product schema -- the only module that writes or names it.

Three product shapes exist, and this module is the single place that knows how
to tell them apart or build them:

==============  ==================  ==============  =====================
``stage``       ``product_kind``    arrays at       bin factor
==============  ==================  ==============  =====================
``raw``         ``per_sca``         ``sca_arrays/`` 16 (``cfg.DEFAULT_BIN``)
``calibrated``  ``per_sca``         ``sca_arrays/`` inherited from the raw
``legacy``      ``mosaic``          ``led_arrays/`` 20, in two stages (4x5)
==============  ==================  ==============  =====================

**Why the per-SCA layout exists.** The legacy product stores one
``(900, 1400)`` MPA mosaic per LED at a net bin of 20 native pixels. But
``4096 / 20 = 204.8``, so at r=20 every SCA block is a ragged 204 or 205 pixels
and the superpixels on a block's trailing edge straddle both the SCA boundary
and the inter-SCA gap. Every per-SCA number then has to be recovered downstream
by re-deriving footprints from the physical geometry
(:func:`rcs_sca_grid.sca_footprint_masks`), and the straddling pixels contaminate
it at the ~0.1 % level -- which is the size of the film-growth signal the whole
trend exists to measure. At r=16 all 18 blocks are exactly 256x256 and in
bounds, so a per-SCA stack is both exact and cheaper to reduce.

**The mosaic is a view, never a stored product.** :func:`rcs_sca_grid.stack_to_mosaic`
builds one for display on demand. Nothing in this module writes one except the
legacy path, which is frozen.

**Writes are atomic.** Every writer builds into ``<path>.tmp-<pid>`` and
``os.replace``\\ s it into place. The failure this guards against is the one
that motivated the whole coverage-tracking design: a product truncated by a
degraded MAST listing or a killed batch rank used to sit on disk looking
complete, and ``batch/run_manifest_worker.py``'s ``_already_done`` would skip it
forever. A half-written file is now never visible under its final name, so the
only incomplete products are the ones that record their own incompleteness in
``coverage/``.

**On ``dictionary/``.** The RAW product carries a byte-compatible mirror of the
frozen compiler's ``dictionary/`` group, so every reader of the scalar
housekeeping -- ``make_sca_digests.py``, ``compare_rcs_h5.py`` -- works on a
per-SCA product unchanged. The *image* half does not come for free:
``compile_rcs_trend.load_from_hdf5`` does an unconditional ``f['led_arrays']``
and so raises ``KeyError`` on a per-SCA product. That is deliberate rather than
papered over with an empty group -- a reader handed ``led_arrays == {}`` would
compute NaN statistics and say nothing, which is the silent-degradation failure
this whole refactor exists to remove. :func:`load_legacy_view` is the migration
path: it returns the same ``(dictionary, led_arrays)`` pair with the mosaics
built on demand from the stacks, which keeps "the mosaic is a view" true.

One ``dictionary/`` field differs from the compiler by design:
``RCS_photodiode`` comes from ``pd_net`` (the dark-window pedestal subtraction)
rather than the compiler's ``pd_raw - pd_raw[0]``. See
:func:`rcs_photodiode.write_photodiode_group` for the measurement behind that
split -- the two agree to 26 telemetry quanta as a *common* offset, which
cancels in the LED ratios, so the legacy product keeps the old array as a
bit-exact regression anchor and the new product, which has no such obligation,
carries the better one.
"""

import dataclasses
import datetime
import os
import re

import numpy as np

import rcs_fsutil
import rcs_sca_grid as grid
import rcs_trend_config as cfg

__all__ = [
    "ActivityArray", "PRODUCT_SUFFIX", "coverage_from_h5", "legacy_dictionary",
    "load_legacy_view", "mce_side_from", "parse_timestamp", "pass_number_from",
    "product_path", "read_activity_arrays", "read_metadata", "read_stack",
    "read_stacks", "run_label_of", "self_test", "write_calibrated", "write_raw",
]

# Discovery filters on the ``stage`` *attribute*, never on these -- a product
# renamed by hand must still be classified correctly. They exist so a directory
# listing is readable by a human.
PRODUCT_SUFFIX = {"raw": "_raw.h5", "calibrated": "_cal.h5", "legacy": ".h5"}

# gzip-4 rather than the legacy gzip-9: measured on a real (18, 256, 256) stack
# the two land within 2 % of each other in size, and level 4 writes ~5x faster.
# shuffle helps because float32 superpixel values in a flat field share their
# exponent byte across almost the whole array.
_COMPRESSION = dict(compression="gzip", compression_opts=4, shuffle=True,
                    fletcher32=True)

PIPELINE_VERSION = "rcs-trending/2.0"


@dataclasses.dataclass
class ActivityArray:
    """One activity's per-SCA stack plus the provenance that belongs with it.

    ``stack`` is ``(18, n, n)`` float32 with NaN for any SCA that was not
    downlinked, so the array's own finiteness pattern *is* the coverage record
    and the two cannot drift apart.
    """

    key: str
    stack: np.ndarray
    attrs: dict = dataclasses.field(default_factory=dict)

    def coverage(self):
        """``(18,)`` bool: which SCAs hold any finite pixel."""
        return grid.stack_coverage(self.stack)

    def fraction(self):
        """``(18,)`` float32: finite-pixel fraction per SCA."""
        return grid.coverage_fraction(self.stack)


def empty_stack(bin_factor=cfg.DEFAULT_BIN, dtype=np.float32):
    """An all-NaN ``(18, n, n)`` stack to accumulate streamed SCAs into.

    NaN rather than zero: a missing SCA and an SCA that read exactly zero are
    different facts, and every reduction downstream is a ``nan*`` reduction that
    depends on the distinction.
    """
    side = cfg.SCA_PIX // cfg.validate_bin(bin_factor)

    return np.full((cfg.N_SCAS, side, side), np.nan, dtype=dtype)


def product_path(directory, run_label, stage="raw"):
    """Where a product for ``run_label`` goes, by stage."""
    if stage not in PRODUCT_SUFFIX:
        raise ValueError(f"unknown stage {stage!r}; "
                         f"expected one of {sorted(PRODUCT_SUFFIX)}")

    return os.path.join(directory, f"{run_label}{PRODUCT_SUFFIX[stage]}")


def run_label_of(name):
    """The run label behind a product filename -- the inverse of
    :func:`product_path`.

    Reads the suffixes from ``PRODUCT_SUFFIX`` rather than respelling them, so
    a new stage cannot be understood by one direction and not the other. The
    longest matching suffix wins, since ``".h5"`` is a suffix of every other
    one and would otherwise claim them all.
    """
    base = os.path.basename(name)
    for suffix in sorted(PRODUCT_SUFFIX.values(), key=len, reverse=True):
        if base.endswith(suffix):
            return base[:-len(suffix)]
    return base


# ---------------------------------------------------------------------------
# Writing
# ---------------------------------------------------------------------------

def _string_array(values):
    """``h5py`` variable-length utf-8 dataset payload for a list of strings."""
    import h5py

    return np.array([("" if v is None else str(v)) for v in values],
                    dtype=h5py.string_dtype())


def _set_attrs(target, attrs):
    """Assign root/dataset attributes, coercing the types h5py refuses.

    ``None`` becomes an empty string rather than being dropped: an attribute
    that is present and empty says "this run had no value for it", while an
    absent one is indistinguishable from "this product predates the field".
    """
    import h5py

    for name, value in sorted(attrs.items()):
        if value is None:
            target.attrs[name] = ""
        elif isinstance(value, (list, tuple)):
            target.attrs[name] = np.array([str(v) for v in value],
                                          dtype=h5py.string_dtype())
        elif isinstance(value, np.bool_):
            target.attrs[name] = bool(value)
        elif isinstance(value, (np.integer,)):
            target.attrs[name] = int(value)
        elif isinstance(value, (np.floating,)):
            target.attrs[name] = float(value)
        else:
            target.attrs[name] = value


def _write_coverage(handle, arrays):
    """The ``coverage/`` group: per activity, per SCA, and the finite fraction.

    ``per_sca`` is the logical AND over activities that hold *any* data, not the
    union. The question it answers is "can this product support an 18-SCA
    trend", and one activity missing SCA 11 is enough to make the answer no.
    Activities with zero coverage are excluded from the AND rather than zeroing
    it: the blank dark placeholder (no L2 exists for the dark, ever) is all-NaN
    by construction, and including it would mark every product degraded.
    """
    per_activity = np.array([a.coverage() for a in arrays], dtype=bool)
    fractions = np.array([a.fraction() for a in arrays], dtype=np.float32)

    populated = per_activity[per_activity.any(axis=1)]
    per_sca = (populated.all(axis=0) if len(populated)
               else np.zeros(cfg.N_SCAS, dtype=bool))

    group = handle.create_group("coverage")
    group.create_dataset("activity_key", data=_string_array(
        [a.key for a in arrays]))
    group.create_dataset("per_activity", data=per_activity)
    group.create_dataset("per_sca", data=per_sca)
    group.create_dataset("fraction", data=fractions)
    group["per_sca"].attrs["rule"] = (
        "logical AND over activities with any coverage; "
        "all-NaN placeholders excluded")

    return per_sca


def _write_housekeeping(handle, table, hk_columns, led_columns):
    """One row per activity of the EDP telemetry that the digests may want.

    Stored per activity rather than reduced to the medians the legacy
    ``dictionary/`` holds, because the reduction throws away exactly what the
    ACM work needs: ``dictionary/ACM_LVDT`` is a single nanmedian over the whole
    run, so an ACM move *during* a pass is invisible in it. Keeping the per
    activity values makes that detectable without another EDP query.
    """
    group = handle.create_group("housekeeping")
    group.create_dataset("activity_key", data=_string_array(table["h5_key"]))
    group.create_dataset("activity_number",
                         data=np.asarray(table["activity_number"], dtype=np.int32))
    group.create_dataset("start_time", data=_string_array(table["SC Timestamp"]))
    group.create_dataset("end_time", data=_string_array(table["end_time"]))
    group.create_dataset("is_aux",
                         data=np.asarray(table["is_aux"], dtype=bool)
                         if "is_aux" in table else
                         np.zeros(len(table), dtype=bool))

    for column in hk_columns:
        if column in table:
            group.create_dataset(column, data=np.asarray(table[column],
                                                         dtype=np.float64))
        rule = f"rule_{column}"
        if rule in table:
            group.create_dataset(rule, data=_string_array(table[rule]))

    for position, column in enumerate(led_columns, start=1):
        if column in table:
            group.create_dataset(f"led_select_{position}",
                                 data=_string_array(table[column]))

    # Per-channel, not per-run: two products in the overloaded batch set had a
    # single NaN LVDT channel, which NaNs the whole run's travel metric under a
    # plain np.mean and silently disables the ACM_TRAVEL_WARN check.
    lvdt_columns = [c for c in hk_columns if c.startswith("WFI_MCE_LVDT_ACM_")]
    valid = np.array([bool(np.isfinite(np.asarray(table[c], dtype=np.float64)).any())
                      if c in table else False for c in lvdt_columns], dtype=bool)
    group.create_dataset("ACM_LVDT_valid", data=valid)

    return valid


def legacy_dictionary(table, photodiode=None, hk_columns=None,
                      stamp_pos=3, bank="BANK2"):
    """Rebuild the frozen compiler's ``dictionary/`` payload from the table.

    An independent reimplementation of ``compile_rcs_trend.process_trending_run``'s
    metadata block, deliberately *not* a call into it: the compiler reads a CSV
    off disk, globs mosaics and writes its own file, so it cannot be used to
    annotate a product it did not create. The reductions here match it exactly
    (``np.nanmedian`` per column, ``+273.15`` on the two Celsius sphere/board
    channels) so a per-SCA product and a legacy product of the same pass agree
    on every scalar.

    ``table`` must already be restricted to the compiler's own rows -- CAR-216's
    aux activities excluded -- because the compiler takes ``np.nanmedian`` over
    the *entire* column and ``pd_array[0]`` as the dark, so leaving them in both
    shifts every scalar and lengthens ``RCS_photodiode`` past 7.

    ``photodiode`` is ``pd_net`` from :mod:`rcs_photodiode`, aligned to those
    rows. The compiler's own ``pd_raw - pd_raw[0]`` is what the legacy products
    hold; this is the dark-window-pedestal version, which is the one correction
    stage 2 should divide by. Both have the dark at exactly 0, so the ``[1:]``
    slice every existing reader applies stays valid.
    """
    import read_per_sca as rps

    hk_columns = list(hk_columns if hk_columns is not None else rps.HK_COLUMNS)

    def median(column, offset=0.0):
        if column not in table:
            return np.nan
        values = np.asarray(table[column], dtype=np.float64)

        return float(np.nanmedian(values) + offset) \
            if np.isfinite(values).any() else np.nan

    row = min(int(stamp_pos), max(len(table) - 1, 0))
    timestamps = list(table["SC Timestamp"])
    forward_column = f"WFI_MCE_SRCS_{bank}_LED_V"

    dictionary = {
        "timestamp": str(timestamps[row]) if timestamps else "",
        "COBA_temp": median("WFI_COBA_WTSC10P_K"),
        "RCS_Sphere_temp": median("WFI_MCE_SRCS_SPHERE_T", 273.15),
        "RCS_Board_temp": median("WFI_MCE_SRCS_BOARD_T", 273.15),
        "MPA_A_temp": median("WFI_MCU_A_MPA_CSENS_FPSSEN_K"),
        "MPA_B_temp": median("WFI_MCU_B_MPA_CSENS_FPSSEN_K"),
        "ACM_LVDT": np.array([median(f"WFI_MCE_LVDT_ACM_{i}")
                              for i in range(1, 7)], dtype=np.float64),
        "RCS_forward_voltage": (
            np.asarray(table[forward_column], dtype=np.float64)
            if forward_column in table
            else np.full(len(table), np.nan)),
    }

    if photodiode is None:
        pd_column = "WFI_MCE_SRCS_PD1_V" if bank == "BANK1" \
            else "WFI_MCE_SRCS_PD2_V"
        raw = (np.asarray(table[pd_column], dtype=np.float64)
               if pd_column in table else np.full(len(table), np.nan))
        photodiode = raw - raw[0] if len(raw) else raw
    dictionary["RCS_photodiode"] = np.asarray(photodiode, dtype=np.float64)

    return dictionary


def _write_dictionary(handle, dictionary):
    """The legacy mirror, in ``save_to_hdf5``'s exact layout.

    ``original_type`` attributes included: ``load_from_hdf5`` reads them to
    decide whether a dataset comes back as a tuple, a list, an array or a
    scalar, so omitting them would change what existing readers get.
    """
    import h5py

    group = handle.create_group("dictionary")
    for key, value in dictionary.items():
        if isinstance(value, str):
            group.create_dataset(key, data=value,
                                 dtype=h5py.string_dtype(encoding="utf-8"))
        elif isinstance(value, np.ndarray):
            group.create_dataset(key, data=value, fletcher32=True)
            group[key].attrs["original_type"] = "numpy_array"
        elif isinstance(value, (tuple, list)):
            group.create_dataset(key, data=np.array(value), fletcher32=True)
            group[key].attrs["original_type"] = \
                "tuple" if isinstance(value, tuple) else "list"
        else:
            group.create_dataset(key, data=np.array(value))
            group[key].attrs["original_type"] = "scalar"


def _write_stacks(handle, arrays, bin_factor, group_name="sca_arrays"):
    """``sca_arrays/<key>`` for every activity, with its per-dataset provenance."""
    side = cfg.SCA_PIX // bin_factor
    group = handle.create_group(group_name)
    for array in arrays:
        stack = np.asarray(array.stack, dtype=np.float32)
        if stack.shape != (cfg.N_SCAS, side, side):
            raise ValueError(
                f"activity {array.key!r}: stack shape {stack.shape} does not "
                f"match ({cfg.N_SCAS}, {side}, {side}) for bin {bin_factor}")
        dataset = group.create_dataset(array.key, data=stack, **_COMPRESSION)
        attrs = dict(array.attrs)
        attrs.setdefault("units", "DN/s")
        attrs.setdefault("n_sca", int(array.coverage().sum()))
        attrs.setdefault("scas_present", ",".join(
            str(i + 1) for i in np.flatnonzero(array.coverage())))
        _set_attrs(dataset, attrs)

    return group


class _AtomicH5:
    """Open ``path + .tmp-<pid>`` for writing and ``os.replace`` it on success.

    A context manager rather than a try/finally at each call site because there
    are three writers and the invariant -- no partially written product ever
    appears under its final name -- has to hold for all of them. On an exception
    the temp file is removed and the original (if any) is left untouched.
    """

    def __init__(self, path):
        self.path = path
        self.temp = f"{path}.tmp-{os.getpid()}"
        self.handle = None

    def __enter__(self):
        import h5py

        directory = os.path.dirname(os.path.abspath(self.path))
        os.makedirs(directory, exist_ok=True)
        self.handle = h5py.File(self.temp, "w")

        return self.handle

    def __exit__(self, kind, value, traceback):
        self.handle.close()
        if kind is None:
            rcs_fsutil.replace(self.temp, self.path)
        elif os.path.exists(self.temp):
            os.remove(self.temp)

        return False


def write_raw(path, arrays, bin_factor=cfg.DEFAULT_BIN, root_attrs=None,
              table=None, reduction=None, dictionary=None,
              hk_columns=None, led_columns=None):
    """Write the RAW per-SCA product: L2 superpixels, no corrections applied.

    ``arrays`` is a list of :class:`ActivityArray` in activity order. ``table``
    is ``rcs_telemetry.build_telemetry_table``'s DataFrame (all rows, aux
    included) and supplies the ``housekeeping/`` group; ``reduction`` is the
    :class:`rcs_photodiode.PdReduction` and supplies ``photodiode/`` plus the
    ``RCS_photodiode`` field of the ``dictionary/`` mirror. Both are optional so
    a ``--skip-telemetry`` run still produces a readable product; what it will
    not produce is a *calibratable* one, and the absent groups are how stage 2
    finds that out.

    Returns the path written.
    """
    import read_per_sca as rps

    bin_factor = cfg.validate_bin(bin_factor)
    hk_columns = list(hk_columns if hk_columns is not None else rps.HK_COLUMNS)
    led_columns = list(led_columns if led_columns is not None
                       else rps.LED_SELECT_COLUMNS)
    attrs = dict(root_attrs or {})

    with _AtomicH5(path) as handle:
        _write_stacks(handle, arrays, bin_factor)
        per_sca = _write_coverage(handle, arrays)

        lvdt_valid = None
        if table is not None and len(table):
            lvdt_valid = _write_housekeeping(handle, table, hk_columns,
                                             led_columns)

        if dictionary is None and table is not None and len(table):
            core = table[~table["is_aux"].astype(bool)] \
                if "is_aux" in table else table
            photodiode = None
            if reduction is not None:
                # Aligned to the core rows by activity order, which is how the
                # reduction is built; a length mismatch means the PD reduction
                # and the staged table disagree about what ran, so it is left
                # to the compiler's own raw difference rather than guessed at.
                net = reduction.photodiode_array()
                photodiode = net[:len(core)] if len(net) >= len(core) else None
            dictionary = legacy_dictionary(core, photodiode=photodiode,
                                           hk_columns=hk_columns)
            attrs.setdefault(
                "photodiode_source",
                "pd_net (dark-window pedestal)" if photodiode is not None
                else "pd_raw - pd_raw[0] (compiler rule)")
        if dictionary is not None:
            _write_dictionary(handle, dictionary)

        attrs.update({
            "schema_version": cfg.SCHEMA_VERSION,
            "stage": "raw",
            "product_kind": "per_sca",
            "bin_factor": int(bin_factor),
            "sca_pix": int(cfg.SCA_PIX),
            "n_sca": int(cfg.N_SCAS),
            "n_activities": len(arrays),
            "n_aux_activities": sum(1 for a in arrays
                                    if a.attrs.get("is_aux")),
            "coverage_n_sca": int(per_sca.sum()),
            "coverage_complete": bool(per_sca.all()),
            "created": datetime.datetime.now(
                datetime.timezone.utc).isoformat(timespec="seconds"),
            "pipeline_version": PIPELINE_VERSION,
        })
        if lvdt_valid is not None:
            attrs["acm_lvdt_channels_valid"] = int(lvdt_valid.sum())
        _set_attrs(handle, attrs)

    if reduction is not None:
        # After the atomic replace, not before: write_photodiode_group opens the
        # file itself in append mode, and it has to be the final path so a
        # reader cannot see a product whose photodiode/ group is half written.
        import rcs_photodiode

        rcs_photodiode.write_photodiode_group(path, reduction)

    return path


def _write_named_group(handle, name, payload, attrs=None):
    """One group from ``{dataset: values}``, string or numeric, plus attrs.

    Hoisted out of ``write_calibrated``'s ``calibration`` block, which this
    reproduces exactly -- including the ``sorted()`` on the dataset names, so
    the file layout is unchanged.
    """
    group = handle.create_group(name)
    for key, values in sorted(payload.items()):
        values = np.asarray(values)
        if values.dtype.kind in "USO":
            group.create_dataset(key, data=_string_array(values))
        else:
            group.create_dataset(key, data=values)
    if attrs:
        _set_attrs(group, attrs)
    return group


def write_calibrated(path, source, arrays, calibration=None, root_attrs=None,
                     groups=None, group_attrs=None):
    """Write the CALIBRATED per-SCA product: corrected rates, same layout.

    ``source`` is the RAW product's path. Its ``coverage/``, ``housekeeping/``,
    ``photodiode/`` and ``dictionary/`` groups are copied verbatim so the
    calibrated file is self-describing and stage 3 never has to hold both open.
    The copy costs ~1 MB against a 33 MB product.

    ``calibration`` is the ``(6,)``-per-field record of what was applied, from
    :mod:`rcs_corrections`. Stored as its own group rather than as dataset
    attributes because it is the thing most likely to be read on its own: a
    sweep for epochs whose photodiode factor went invalid should not have to
    touch a single pixel.

    ``groups`` is ``{name: {dataset: values}}`` for any further group, and
    ``group_attrs`` is ``{name: {attr: value}}`` for group-level attributes on
    either those or ``calibration``. Both default to nothing written, so a
    caller that passes neither takes the identical code path it always did --
    which is what lets the temperature-gain block be *absent* rather than
    present-and-empty on a product calibrated without a gain model. A consumer
    that needs it then gets a ``KeyError`` instead of a NaN it carries onward.
    """
    import h5py

    attrs = dict(root_attrs or {})
    bin_factor = int(read_metadata(source)["bin_factor"])

    with _AtomicH5(path) as handle:
        _write_stacks(handle, arrays, bin_factor)

        with h5py.File(source, "r") as origin:
            for name in ("coverage", "housekeeping", "photodiode",
                         "dictionary"):
                if name in origin:
                    origin.copy(name, handle)
            inherited = {key: value for key, value in origin.attrs.items()
                         if key not in attrs}

        group_attrs = dict(group_attrs or {})
        if calibration:
            _write_named_group(handle, "calibration", calibration,
                               group_attrs.get("calibration"))
        for name, payload in sorted((groups or {}).items()):
            _write_named_group(handle, name, payload, group_attrs.get(name))

        per_sca = (np.asarray(handle["coverage"]["per_sca"][:], dtype=bool)
                   if "coverage" in handle
                   else np.zeros(cfg.N_SCAS, dtype=bool))

        merged = dict(inherited)
        merged.update(attrs)
        merged.update({
            "schema_version": cfg.SCHEMA_VERSION,
            "stage": "calibrated",
            "product_kind": "per_sca",
            "bin_factor": bin_factor,
            "n_activities": len(arrays),
            "coverage_n_sca": int(per_sca.sum()),
            "coverage_complete": bool(per_sca.all()),
            "created": datetime.datetime.now(
                datetime.timezone.utc).isoformat(timespec="seconds"),
            "pipeline_version": PIPELINE_VERSION,
        })
        _set_attrs(handle, merged)

    return path


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------

def _text(value):
    """Decode an h5 attribute or dataset scalar that may be bytes."""
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    if isinstance(value, np.ndarray):
        return ",".join(_text(v) for v in value.tolist())

    return str(value)


# Pre-3.11 ``datetime.fromisoformat`` accepts at most 6 fractional digits and
# flight timestamps carry 7, so the extra digits are trimmed rather than the
# interpreter version depended on. The .venv here is Python 3.10.
_FRACTIONAL_SECONDS = re.compile(r"(\.\d{6})\d+")

# Only a fallback now. The pass number is a root attribute of every per-SCA
# product, and this regex exists for the products written before it was -- the
# field just before the revision and date, e.g.
# CAR190_01039_02_022_001_20260917.h5 is pass 22.
_PASS_NUMBER = re.compile(r"_(\d{3})_\d{3}_\d{8}")

# TVAC/SCIPA filenames mark the electronics side; flight filenames never do.
_MCE_SIDE = re.compile(r"_MCE([AB])\b")


def parse_timestamp(stamp):
    """Parse an RCS product timestamp into an aware UTC datetime.

    Flight files carry 7 fractional-second digits and no zone marker; TVAC
    SCIPA files instead carry a trailing ``Z``, which pre-3.11
    ``fromisoformat`` rejects outright. Both are UTC.
    """
    if isinstance(stamp, bytes):
        stamp = stamp.decode("utf-8")
    stamp = str(stamp)
    if stamp.endswith("Z"):
        stamp = stamp[:-1] + "+00:00"
    parsed = datetime.datetime.fromisoformat(
        _FRACTIONAL_SECONDS.sub(r"\1", stamp))

    return parsed if parsed.tzinfo else parsed.replace(
        tzinfo=datetime.timezone.utc)


def pass_number_from(name, attrs=None, sequence_number=None):
    """Pass number from the ``pass_number`` attribute, the filename, or order.

    Attribute first: the filename regex is what the pipeline used to depend on,
    and a product renamed on its way into a directory then silently became a
    different epoch. SCIPA files have no pass field at all and fall back to
    their position in the list, which is harmless because epoch *order* comes
    from each file's own timestamp, never from this number.
    """
    if attrs:
        value = attrs.get("pass_number")
        if value is not None and str(value) != "":
            try:
                return int(value)
            except (TypeError, ValueError):
                pass

    match = _PASS_NUMBER.search(str(name))
    if match:
        return int(match.group(1))
    if sequence_number is not None:
        return int(sequence_number)

    raise ValueError(f"{name!r} has no pass_number attribute and does not "
                     f"match the expected ..._<pass>_<rev>_<date>.h5 naming")


def mce_side_from(name, attrs=None, assume=None):
    """``(side, source)`` for an epoch's MCE electronics side.

    The resolution order is attribute, then the TVAC/SCIPA ``_MCE[AB]``
    filename marker, then ``assume``, then a raise. **This function exists
    because of a real latent bug**: the digest code classified side from
    ``"MCEB" in name``, and flight filenames carry no such marker, so every
    flight epoch was silently side A. If that assumption is ever wrong the
    per-LED B-side corrections -- 1.5 % to 6 %, the same size as the
    film-growth signal the trend measures -- are simply omitted, with nothing
    in the output to say so. Raising beats defaulting, and ``source`` is
    recorded so a reader can tell a measurement from an assumption.
    """
    if attrs:
        side = _text(attrs.get("mce_side", "")).strip().upper()
        if side in ("A", "B"):
            return side, _text(attrs.get("mce_side_source", "attribute"))

    match = _MCE_SIDE.search(str(name))
    if match:
        return match.group(1), "filename:_MCE[AB]"

    if assume:
        return str(assume).strip().upper(), "assumed"

    raise ValueError(
        f"{name!r} records no MCE side: no mce_side attribute and no "
        f"_MCEA/_MCEB in the name. The B-side per-LED corrections are 1.5-6%, "
        f"so defaulting to A would be a silent error the size of the signal. "
        f"Re-stage with --mce-side, or pass --assume-side to accept it.")


def read_metadata(path):
    """Root attributes, with the legacy product's implied values filled in.

    The classification rule, and the reason discovery keys on attributes rather
    than filenames: a file with no ``schema_version`` but a ``led_arrays`` group
    *is* a legacy r=20 mosaic, whatever it is called. Everything downstream can
    then ask ``meta["product_kind"]`` and get an answer for all three shapes
    instead of branching on the file's provenance.

    ``bin_factor`` for a legacy product is 20 -- the net factor, r=4 per SCA
    followed by a 5x mosaic rebin -- which is exactly the value that does not
    divide 4096 and so cannot be fed to :func:`rcs_sca_grid.mosaic_to_stack`.
    Recording it is what lets that function refuse rather than silently
    mis-slice.
    """
    import h5py

    with h5py.File(path, "r") as handle:
        attrs = {key: (_text(value) if isinstance(value, bytes) else value)
                 for key, value in handle.attrs.items()}
        has_stack = "sca_arrays" in handle
        has_mosaic = "led_arrays" in handle
        groups = sorted(handle.keys())
        if has_stack:
            keys = sorted(handle["sca_arrays"].keys())
        elif has_mosaic:
            keys = sorted(handle["led_arrays"].keys())
            keys += [f"AUX:{k}" for k in sorted(handle.get("aux_arrays", {}))]
        else:
            keys = []

    legacy = "schema_version" not in attrs and not has_stack
    meta = {
        "path": path,
        "name": os.path.basename(path),
        "groups": groups,
        "array_keys": keys,
        "stage": _text(attrs.get("stage", "legacy" if legacy else "raw")),
        "product_kind": _text(attrs.get(
            "product_kind", "per_sca" if has_stack else "mosaic")),
        "bin_factor": int(attrs.get("bin_factor", 20)),
        "schema_version": _text(attrs.get("schema_version", "legacy/0")),
    }
    for name in ("run_label", "car_label", "decon_cycle", "mce_side",
                 "mce_bank", "orientation", "timestamp", "provenance",
                 "reference_card", "reference_run_label"):
        if name in attrs:
            meta[name] = _text(attrs[name])
    for name in ("program", "pass_number", "segment", "execution_plan",
                 "coverage_n_sca", "n_activities"):
        if name in attrs:
            try:
                meta[name] = int(attrs[name])
            except (TypeError, ValueError):
                meta[name] = _text(attrs[name])
    for name in ("dark_subtracted", "dark_blank", "coverage_complete",
                 "bridge_applied", "dq_applied"):
        if name in attrs:
            meta[name] = bool(attrs[name])
    meta["attrs"] = attrs

    return meta


def coverage_from_h5(path, min_fraction=0.0):
    """``(18,)`` bool per-SCA coverage for any of the three product shapes.

    Three cases, tried in order, and the fallbacks are the point: this is what
    ``batch/run_manifest_worker.py`` calls to decide whether an existing product
    is complete, so it has to give a real answer for products written before
    ``coverage/`` existed. Otherwise the coverage-aware skip would treat every
    legacy file as degraded and re-pull the entire archive.

    1. an explicit ``coverage/per_sca`` dataset (per-SCA products);
    2. a ``sca_arrays/`` stack, AND-reduced over activities with any data --
       the same rule :func:`_write_coverage` applies, so a product written
       without the group and one written with it agree;
    3. a legacy ``led_arrays/`` mosaic, whose per-SCA occupancy has to be
       recovered through :func:`rcs_sca_grid.sca_footprint_masks`.

    ``min_fraction`` raises the bar from "any finite pixel" to a minimum finite
    fraction per SCA, for the case a listing returned a product that decoded to
    almost all NaN. It only applies to cases 2 and 3; case 1's stored booleans
    were computed at write time.
    """
    import h5py

    with h5py.File(path, "r") as handle:
        if "coverage" in handle and "per_sca" in handle["coverage"]:
            return np.asarray(handle["coverage"]["per_sca"][:], dtype=bool)

        if "sca_arrays" in handle:
            rows = []
            for key in sorted(handle["sca_arrays"].keys()):
                stack = handle["sca_arrays"][key][:]
                rows.append(grid.coverage_fraction(stack) > min_fraction)
            rows = np.array(rows, dtype=bool) if rows \
                else np.zeros((0, cfg.N_SCAS), dtype=bool)
            populated = rows[rows.any(axis=1)] if len(rows) else rows

            return (populated.all(axis=0) if len(populated)
                    else np.zeros(cfg.N_SCAS, dtype=bool))

        if "led_arrays" not in handle:
            return np.zeros(cfg.N_SCAS, dtype=bool)

        covered = np.ones(cfg.N_SCAS, dtype=bool)
        masks = None
        for key in sorted(handle["led_arrays"].keys()):
            mosaic = handle["led_arrays"][key][:]
            if masks is None:
                masks = grid.sca_footprint_masks(mosaic.shape)
            present = np.zeros(cfg.N_SCAS, dtype=bool)
            for name in grid.sorted_scas(masks):
                block = mosaic[masks[name]]
                finite = float(np.isfinite(block).mean()) if block.size else 0.0
                present[grid.sca_index(name)] = finite > min_fraction
            if present.any():
                covered &= present

        return covered


def load_legacy_view(path, keys=None, orientation=None):
    """``(dictionary, led_arrays)`` from a per-SCA product, mosaics built on the fly.

    A drop-in replacement for :func:`compile_rcs_trend.load_from_hdf5` for tools
    that still want mosaics -- ``animate_trend.py``, ``compare_rcs_h5.py``, the
    quick-look notebooks. ``load_from_hdf5`` itself cannot read a per-SCA
    product (it requires a ``led_arrays`` group), and rather than write a decoy
    empty group this rebuilds the view through
    :func:`rcs_sca_grid.stack_to_mosaic`.

    The mosaics are *not* the legacy r=20 ones. They are at the product's own
    bin factor, so a mosaic from here is ``(1125, 1750)`` at bin 16 rather than
    ``(900, 1400)``, and its pixels do not straddle SCA edges. Anything
    comparing absolute pixel positions against a legacy product has to go
    through the physical extent, not the array indices --
    ``plot_mpa_mosaic.show_mosaic``'s ``EXTENT`` is in mm and r-independent, so
    plotting is unaffected.
    """
    import h5py

    meta = read_metadata(path)
    if meta["product_kind"] != "per_sca":
        from compile_rcs_trend import load_from_hdf5

        return load_from_hdf5(path)

    with h5py.File(path, "r") as handle:
        dictionary = {}
        for key in handle["dictionary"].keys():
            data = handle["dictionary"][key][()]
            kind = _text(handle["dictionary"][key].attrs.get(
                "original_type", "unknown"))
            if isinstance(data, bytes):
                dictionary[key] = data.decode("utf-8")
            elif kind == "tuple":
                dictionary[key] = tuple(data) if np.ndim(data) else (data.item(),)
            elif kind == "list":
                dictionary[key] = data.tolist()
            elif kind == "scalar":
                dictionary[key] = data.item()
            else:
                dictionary[key] = data

    wanted = list(keys) if keys is not None else cfg.LED_NAMES
    stacks = read_stacks(path, [k for k in wanted])
    led_arrays = {key: grid.stack_to_mosaic(stack, meta["bin_factor"],
                                            orientation=orientation)
                  for key, stack in stacks.items()}

    return dictionary, led_arrays


def read_stack(path, key, group="sca_arrays"):
    """One activity's ``(18, n, n)`` stack out of a per-SCA product."""
    import h5py

    with h5py.File(path, "r") as handle:
        if group not in handle or key not in handle[group]:
            raise KeyError(f"{os.path.basename(path)} has no {group}/{key}")

        return np.asarray(handle[group][key][:], dtype=np.float32)


def read_activity_arrays(path, keys=None, group="sca_arrays", drop=()):
    """``[ActivityArray]`` with both the stacks and their per-dataset attrs.

    This is the read side of the calibration pass: the corrected product has to
    carry the raw one's per-activity provenance (visit_id, exposure times,
    hardware LED) forward, and re-deriving any of it from the filename is
    exactly the kind of guess the attribute set exists to replace.

    ``drop`` names attributes to leave behind so :func:`_write_stacks`
    recomputes them from the outgoing array. The calibration pass drops
    ``n_sca``/``scas_present``, because multiplying by a NaN factor empties an
    activity and a carried-over count would then claim 18 SCAs of data that is
    no longer there.
    """
    import h5py

    arrays = []
    with h5py.File(path, "r") as handle:
        if group not in handle:
            raise KeyError(f"{os.path.basename(path)} has no {group}/ group")
        wanted = list(keys) if keys is not None \
            else sorted(handle[group].keys())
        for key in wanted:
            if key not in handle[group]:
                raise KeyError(f"{os.path.basename(path)} is missing "
                               f"{group}/{key}")
            dataset = handle[group][key]
            attrs = {name: (_text(value) if isinstance(value, bytes) else value)
                     for name, value in dataset.attrs.items()
                     if name not in drop}
            arrays.append(ActivityArray(
                key=key, stack=np.asarray(dataset[:], dtype=np.float32),
                attrs=attrs))

    return arrays


def read_stacks(path, keys=None, group="sca_arrays"):
    """``{key: stack}`` for the requested activities, or all of them."""
    import h5py

    with h5py.File(path, "r") as handle:
        if group not in handle:
            raise KeyError(f"{os.path.basename(path)} has no {group}/ group")
        available = list(handle[group].keys())
        wanted = list(keys) if keys is not None else sorted(available)
        missing = [k for k in wanted if k not in available]
        if missing:
            raise KeyError(f"{os.path.basename(path)} is missing "
                           f"{group}/{{{','.join(missing)}}}")

        return {key: np.asarray(handle[group][key][:], dtype=np.float32)
                for key in wanted}


def read_led_temperatures(path, mnemonic, led_names=None):
    """``(values, rules)``, both ``(6,)``, for one housekeeping mnemonic.

    One temperature per LED *activity*, in ``cfg.LED_NAMES`` order, plus the
    companion ``rule_<mnemonic>`` saying how each was resolved: ``window``
    means the telemetry covered that activity, ``nearest`` means it did not and
    the value is an extrapolation from outside it.

    This lives here rather than in :mod:`housekeeping_trends` because keying a
    mnemonic by ``activity_key`` is h5 schema knowledge, and that module works
    from the assembled long table across a whole directory. The two must agree;
    the self-test checks they do on a real product.

    Keyed, never sliced. ``housekeeping/activity_key`` is ``DARK`` followed by
    the six LEDs on a plain epoch, but a CAR-216 epoch also carries
    ``AUX_LED3FLAT*`` activities, so a positional ``[1:7]`` is right on one and
    silently wrong on the other -- the same trap ``_pd_from_group`` already
    documents in :mod:`make_sca_digests`. ``DARK`` has a temperature too and is
    dropped by name, not by position.

    Returns NaN and ``"missing"`` for an LED with no activity in this product,
    rather than shortening the result: the caller's array is per-LED and a
    short one would misalign against ``calibration/led_name``.
    """
    import h5py

    led_names = list(led_names or cfg.LED_NAMES)
    with h5py.File(path, "r") as handle:
        if "housekeeping" not in handle:
            raise KeyError(f"{os.path.basename(path)} has no housekeeping/ "
                           f"group, so {mnemonic} cannot be read")
        group = handle["housekeeping"]
        if mnemonic not in group:
            raise KeyError(
                f"{os.path.basename(path)} has no housekeeping/{mnemonic}; "
                f"a gain model fitted against one thermal channel must not be "
                f"evaluated against another. Available: "
                f"{sorted(k for k in group if k.startswith('WFI_'))}")
        keys = [_text(v) for v in group["activity_key"][:]]
        column = np.asarray(group[mnemonic][:], dtype=float)
        rule_key = f"rule_{mnemonic}"
        rules = ([_text(v) for v in group[rule_key][:]] if rule_key in group
                 else ["unknown"] * len(keys))

    values = np.full(len(led_names), np.nan)
    resolved = np.array(["missing"] * len(led_names), dtype=object)
    for index, led in enumerate(led_names):
        if led in keys:
            at = keys.index(led)
            values[index] = column[at]
            resolved[index] = rules[at]
    return values, resolved.astype(str)


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------

def self_test(verbose=True):
    """Round-trip a synthetic product through every writer and reader.

    No data, no network, no credentials. What it is really checking is the
    coverage contract: that a stack with a hole in it produces the same answer
    from the stored ``coverage/`` group as from the array-scanning fallback,
    because the batch skip logic depends on those two agreeing.
    """
    import tempfile

    import pandas as pd
    import read_per_sca as rps

    failures = []

    def check(name, condition, detail=""):
        if condition:
            if verbose:
                print(f"  ok   {name}")
        else:
            failures.append(name)
            print(f"  FAIL {name} {detail}")

    bin_factor = cfg.DEFAULT_BIN
    side = cfg.SCA_PIX // bin_factor
    rng = np.random.default_rng(190)

    arrays = []
    for position, key in enumerate(["DARK"] + cfg.LED_NAMES):
        stack = empty_stack(bin_factor)
        if key != "DARK":
            stack[:] = rng.normal(100.0 + position, 1.0,
                                  size=stack.shape).astype(np.float32)
            if key == "LED3":
                # One SCA deliberately absent from one LED only: the AND rule
                # must drop it from per_sca even though five LEDs have it.
                stack[10] = np.nan
        arrays.append(ActivityArray(
            key=key, stack=stack,
            attrs={"activity_number": position + 1, "is_dark": key == "DARK",
                   "is_aux": False, "hardware_led": -1 if key == "DARK"
                   else position}))

    rows = []
    for position, array in enumerate(arrays):
        row = {"SC Timestamp": f"2026-09-01T0{position}:00:00.000",
               "end_time": f"2026-09-01T0{position}:10:00.000",
               "h5_key": array.key, "activity_number": position + 1,
               "is_aux": False}
        row.update({column: 1.0 + position for column in rps.HK_COLUMNS})
        row.update({f"rule_{column}": "window" for column in rps.HK_COLUMNS})
        row.update({column: "DIS" for column in rps.LED_SELECT_COLUMNS})
        rows.append(row)
    table = pd.DataFrame(rows)

    with tempfile.TemporaryDirectory() as tmp:
        path = product_path(tmp, "SELFTEST_00000_00_001", stage="raw")
        write_raw(path, arrays, bin_factor=bin_factor, table=table,
                  root_attrs={"run_label": "SELFTEST_00000_00_001",
                              "car_label": "CAR190", "decon_cycle": "decon2",
                              "mce_side": "A", "orientation": "identity"})
        check("write_raw lands at the final path", os.path.exists(path))

        # run_label_of inverts product_path for every stage. The legacy ".h5"
        # case is the one that matters: it is a suffix of the other two, so a
        # naive strip would turn "X_raw.h5" into "X_raw".
        label = "SELFTEST_00000_00_001"
        for stage in PRODUCT_SUFFIX:
            check(f"run_label_of inverts product_path for stage {stage}",
                  run_label_of(product_path(tmp, label, stage=stage)) == label,
                  run_label_of(product_path(tmp, label, stage=stage)))
        check("run_label_of leaves an unsuffixed name alone",
              run_label_of(label) == label)

        check("no temp file left behind",
              not [f for f in os.listdir(tmp) if ".tmp-" in f])

        meta = read_metadata(path)
        check("stage is raw", meta["stage"] == "raw", meta["stage"])
        check("product_kind is per_sca", meta["product_kind"] == "per_sca")
        check("bin_factor round-trips", meta["bin_factor"] == bin_factor)
        check("run_label round-trips",
              meta["run_label"] == "SELFTEST_00000_00_001")
        check("all seven activities present", len(meta["array_keys"]) == 7,
              str(meta["array_keys"]))

        stored = coverage_from_h5(path)
        check("coverage excludes the SCA missing from one LED",
              stored.sum() == cfg.N_SCAS - 1 and not stored[10],
              f"sum={stored.sum()} sca11={stored[10]}")

        # The agreement the batch skip depends on: delete the group and the
        # array-scanning fallback must reach the identical answer.
        import h5py

        fallback_path = os.path.join(tmp, "no_coverage.h5")
        import shutil as _shutil
        _shutil.copy2(path, fallback_path)
        with h5py.File(fallback_path, "a") as handle:
            del handle["coverage"]
        check("array fallback matches the stored coverage",
              np.array_equal(coverage_from_h5(fallback_path), stored))

        check("read_stack shape",
              read_stack(path, "LED1").shape == (cfg.N_SCAS, side, side))
        check("read_stacks refuses a missing key",
              _raises(KeyError, read_stacks, path, ["LED9"]))

        # The dictionary mirror. load_from_hdf5 is expected to *fail* here --
        # it requires a led_arrays group -- and load_legacy_view is the path
        # that works. Asserting the failure keeps the docstring honest: if
        # someone later adds a decoy empty led_arrays group, this breaks.
        from compile_rcs_trend import load_from_hdf5

        check("load_from_hdf5 refuses a per-SCA product (no led_arrays)",
              _raises(KeyError, load_from_hdf5, path))

        dictionary, led_arrays = load_legacy_view(path)
        check("mirror has the compiler's scalars",
              {"timestamp", "COBA_temp", "RCS_Sphere_temp", "RCS_Board_temp",
               "MPA_A_temp", "MPA_B_temp", "ACM_LVDT"} <= set(dictionary),
              str(sorted(dictionary)))
        check("ACM_LVDT is six channels",
              np.shape(dictionary["ACM_LVDT"]) == (6,))
        check("RCS_photodiode has one entry per core activity",
              len(dictionary["RCS_photodiode"]) == 7)
        check("timestamp came back as a string",
              isinstance(dictionary["timestamp"], str))
        check("legacy view rebuilds six mosaics",
              sorted(led_arrays) == cfg.LED_NAMES, str(sorted(led_arrays)))
        check("the view's mosaic is at the product's own bin factor",
              led_arrays["LED1"].shape ==
              grid.stack_to_mosaic(read_stack(path, "LED1"),
                                   bin_factor).shape)

        # Mosaic view round trip, which is the reason bin 16 was chosen.
        stack = read_stack(path, "LED1")
        mosaic = grid.stack_to_mosaic(stack, bin_factor)
        back = grid.mosaic_to_stack(mosaic, bin_factor)
        check("stack -> mosaic -> stack is exact",
              np.array_equal(np.nan_to_num(stack, nan=-1.0),
                             np.nan_to_num(back, nan=-1.0)))

        # Calibrated product: same layout, inherited groups, new attrs.
        cal_arrays = [ActivityArray(key=a.key, stack=a.stack * 2.0,
                                    attrs=dict(a.attrs, applied_factor=2.0))
                      for a in arrays if a.key != "DARK"]
        cal_path = product_path(tmp, "SELFTEST_00000_00_001", stage="calibrated")
        write_calibrated(
            cal_path, path, cal_arrays,
            calibration={"led_name": cfg.LED_NAMES,
                         "total_factor": np.full(cfg.N_LEDS, 2.0),
                         "valid": np.ones(cfg.N_LEDS, dtype=bool)},
            root_attrs={"corrections_applied": ["photodiode", "side", "acm"],
                        "bridge_applied": False})
        cal_meta = read_metadata(cal_path)
        check("calibrated stage", cal_meta["stage"] == "calibrated")
        check("calibrated inherits run_label",
              cal_meta.get("run_label") == "SELFTEST_00000_00_001")
        check("calibrated inherits the dictionary mirror",
              "dictionary" in cal_meta["groups"] and
              "housekeeping" in cal_meta["groups"])
        check("calibrated coverage matches the raw",
              np.array_equal(coverage_from_h5(cal_path), stored))
        check("calibration group round-trips",
              np.allclose(_read_calibration(cal_path)["total_factor"], 2.0))

        # A wrong-shaped stack must be refused, not written.
        bad = [ActivityArray(key="LED1", stack=np.zeros((18, 8, 8), np.float32))]
        bad_path = os.path.join(tmp, "bad.h5")
        check("a mis-binned stack is refused",
              _raises(ValueError, write_raw, bad_path, bad,
                      bin_factor=bin_factor))
        check("the refused write left no file", not os.path.exists(bad_path))

    print(f"rcs_products.self_test: "
          f"{'ok' if not failures else 'FAILED'} ({len(failures)} failure(s))")

    return not failures


def _read_calibration(path):
    """``{field: array}`` out of a calibrated product's ``calibration/`` group."""
    import h5py

    with h5py.File(path, "r") as handle:
        return {key: handle["calibration"][key][:]
                for key in handle["calibration"].keys()}


def _raises(kind, function, *args, **kwargs):
    """Whether ``function`` raises ``kind``; keeps the self-test readable."""
    try:
        function(*args, **kwargs)
    except kind:
        return True

    return False


if __name__ == "__main__":
    import sys

    sys.exit(0 if self_test() else 1)
