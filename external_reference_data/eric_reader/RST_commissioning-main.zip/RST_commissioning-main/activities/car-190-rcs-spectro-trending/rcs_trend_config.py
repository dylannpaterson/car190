"""
Configuration and constants for RCS thin film analysis

This module centralizes all constants, configuration parameters, and correction
factors used in the thin film analysis pipeline. This provides a single source
of truth for all magic numbers and instrument parameters.

On side corrections: B_SIDE_CORRECTIONS below is a ground-derived SCA-response
table and is the only side-dependent quantity applied today. The photodiode side
story is separate and is written up in PD_CORRECTION.md section 8 -- in short,
the diodes themselves differ between MCE sides, so the PD *reference* has to be
re-established at a swap (``--pd-reference per-side``) while the per-epoch
pedestal already handles it. The remaining gap is that both tables are gauged
A-nominal and the flight A<->B numbers do not exist yet.
"""
import os
from dataclasses import dataclass, field
from typing import Dict, Optional
import astropy.units as u

# From released RCS parameters
# https://github.com/RomanSpaceTelescope/roman-technical-information
# WideFieldInstrument/RelativeCalibrationSystem/WFI_RCS_LEDP_centers_FWHM.ecsv
LED_WAVELENGTHS: Dict[str, u.Quantity] = {
    "LED1": 624 * u.nm,
    "LED2": 853 * u.nm,
    "LED3": 1039 * u.nm,
    "LED4": 1270 * u.nm,
    "LED5": 1481 * u.nm,
    "LED6": 1670 * u.nm
}

LED_NAMES = ["LED1", "LED2", "LED3", "LED4", "LED5", "LED6"]
N_LEDS = 6

N_SCAS = 18
SCA_NAMES = [f"SCA{i+1}" for i in range(N_SCAS)]

# Per-LED B-side scale, based on Maxime's fits to the trend data.
#
# Provenance, which determines what it may be composed with: these came from
# **ground data for the SCA response**, not from the photodiode. So they carry no
# diode responsivity ratio, and a per-side PD reference (see PD_CORRECTION.md
# section 8) is independent of them rather than a double count. The individual
# numerators and denominators below are not documented anywhere; only the ratio
# is meaningful. Range is +1.39% (LED3) to +6.27% (LED1), an across-LED spread of
# 4.81% -- i.e. 3-30x the whole photodiode correction, so this is the dominant
# chromatic side term by a wide margin.
#
# To be replaced by a flight measurement: once there are B-side data, the A<->B
# step comes from bridging the *detector* trend across the swap, cleanest from a
# --no-side run so the fit measures the raw ratio rather than a residual on top
# of these ground numbers.
#
# Gauge, and the planned inversion: this table is A-nominal, matching
# b_side_correction_for's "putting an epoch on the A-side scale". Since the
# instrument is expected to stay on B once it moves, the intended convention is
# eventually **B-nominal** with the A-side correction derived instead. That is a
# separate gauge from the response origin, which stays at A-side t=0 either way:
# this table only says what to multiply an A-side number by to read it on the
# B-side scale.
B_SIDE_CORRECTIONS: Dict[str, float] = {
    "LED1": 1.017 / 0.957,
    "LED2": 0.972 / 0.946,
    "LED3": 1.021 / 1.007,
    "LED4": 1.040 / 1.015,
    "LED5": 1.024 / 0.995,
    "LED6": 1.009 / 0.986
}

# The ACM position affects illumination geometry slightly
# These are based on fits to the trend pre/post

ACM_COEF_MCEB = -0.0095  # Coefficient for MCEB configuration
ACM_COEF_DEFAULT = -0.0100  # Coefficient for nominal electronics
MCEB_ACM_OFFSET = 60.0  # LVDT offset for MCEB (microns)

DEFAULT_N_WATER = 1.25  # Refractive index of water ice
DEFAULT_ACM_NOMINAL = -2753.0  # Nominal ACM LVDT position
DEFAULT_QE_REBIN = 1  # No rebinning by default
DEFAULT_QE_MULTIPLIER = 0.95  # Fudge factor to bring QE < 1
DEFAULT_QE_CLIP_MAX = 0.9999  # Maximum QE value for stability

# ---------------------------------------------------------------------------
# ACM move detection and bridging
# ---------------------------------------------------------------------------

# An ACM move large enough to start a new configuration segment.  Detection is
# on |delta| alone and is deliberately NOT conditioned on a sign change: the
# flight trend contains a stow->deploy move (which does cross zero) followed by
# two deployed-to-deployed repositionings of ~2400 units that do not.  Requiring
# the sign change missed both, which left ~86% fractional LVDT travel inside a
# single segment to be extrapolated by the linear correction below.
#
# The margin is wide in both directions: within-segment LVDT scatter is < 200
# units and the smallest real move seen is ~2400.
ACM_MOVE_MIN_DELTA = 500.0

# Retained so a caller can reproduce the pre-2026-10 segmentation exactly
# (``--acm-move-min-delta 5000`` plus the old sign rule); see rcs_acm.py.
ACM_DEPLOY_MIN_DELTA = 5000.0

# An LVDT move smaller than a segment break but far above noise: worth counting
# in the log, handled by the linear correction.
ACM_EXCURSION_NOTE = 100.0

# Fractional LVDT travel beyond which the linear ACM correction stops being the
# small perturbation it was fit as, and is worth announcing as an extrapolation.
ACM_TRAVEL_WARN = 0.10

# Bridge solver: iteratively reweighted log-space least squares.
WEIGHT_ITERATIONS = 3
WEIGHT_FLOOR = 0.25   # a side may not be called more than 1/this times quieter
SCREEN_TOLERANCE = 2.5

# Two segments at the same LVDT should bridge to unity if the ACM effect is
# purely geometric; this is how close "the same LVDT" has to be to test that.
ACM_CLOSURE_LVDT_TOLERANCE = 50.0

# ---------------------------------------------------------------------------
# Product geometry
# ---------------------------------------------------------------------------

SCHEMA_VERSION = "rcs-per-sca/1.0"

SCA_PIX = 4096  # full padded SCA array; science data is 4088 inset by 4

# Superpixel bin factor for the per-SCA product.  Must divide SCA_PIX, which
# rules out the historical net factor of 20 (4096/20 = 204.8): at r=20 every SCA
# block is a ragged 204 or 205 pixels and superpixels straddle SCA edges and the
# inter-SCA gaps.  16 gives exactly 256x256 per SCA.
DEFAULT_BIN = 16

# The working trend tree: h5/ (stage 1), cal/ (stage 2), the card, the bridge
# solution, and since 2026-10-12 the digests and figures as well. One constant
# so batch/refresh.py, run_trend.py and the other tools cannot point at
# different trees.
#
# Deployed on the shared mount since 2026-10-12, seeded there from
# /data/eswitzer/rcs_trend_v4 with `batch/refresh.py seed` (SEEDED_FROM.txt in
# the tree records it). rcs_trend_v4 itself was seeded from v3 on 2026-10-09
# to receive the first side-B passes; v3 is left untouched as the last
# single-side set. $RCS_TREND_ROOT overrides the default for one shell, e.g.
# to run against a scratch copy; --root does it for one command.
DEPLOY_ROOT = "/mnt/smdc-rom-com-ops/rrn-ops/activities/car-190-rcs-spectro-trending"
TREND_ROOT = os.environ.get("RCS_TREND_ROOT",
                            os.path.join(DEPLOY_ROOT, "rcs_trend_v4"))

# The RCS sequence variants the trend has seen, by their L1 signature
# (rcs_activities.sequence_signature: one token per observation,
# <obs>:<D|F><led>x<n exposures>@<seconds, to 10 s>). `refresh.py status`
# names each new pass's variant and stops on an unknown one, because a new
# layout can break stage 1 (it did at decon3: the aux observations renumbered).
# Observations 1-7 are the core sequence in all three; only the aux tail
# differs. "ma_table" is the MA table number of the core LED flats, which
# batch/refresh.py check compares with what each product recorded (stage 1
# reads it off the L2 frames from 2026-10-30), since the signature cannot see a
# readout change and SCA18 steps ~0.8 % at one. To add one: confirm stage 1
# plans it (DATA_PULL.md, "A new sequence variant"), then add it here with the
# date and passes it was first seen on.
SEQUENCE_VARIANTS = {
    "car190": {
        "programs": (1039,),
        "signature": ("1:Dx1@180 2:F1x1@40 3:F2x1@40 4:F3x1@40 5:F4x1@40 "
                      "6:F5x1@40 7:F6x1@40"),
        "description": "dark + six LED flats",
        "readout": "DROP_2_OF_3 (MA table 9008): reads 1,4,7,10,13",
        "ma_table": 9008,
        "first_seen": "2026-09-12, CAR-190 plan 2 pass 1",
    },
    "car216": {
        "programs": (1063,),
        "signature": ("1:Dx1@180 2:F1x1@40 3:F2x1@40 4:F3x1@40 5:F4x1@40 "
                      "6:F5x1@40 7:F6x1@40 8:Dx4@40 9:F3x4@40"),
        "description": "the CAR-190 sequence + 4 darks + 4 band-3 flats",
        "readout": "DROP_2_OF_3 (MA table 9008), as CAR-190",
        "ma_table": 9008,
        "first_seen": "2026-09-24, CAR-216 plan 2 pass 1",
    },
    "car216_decon3": {
        "programs": (1063,),
        "signature": ("1:Dx1@180 2:F1x1@40 3:F2x1@40 4:F3x1@40 5:F4x1@40 "
                      "6:F5x1@40 7:F6x1@40 8:Dx1@180 9:Dx4@40 10:F3x5@70 "
                      "11:F3x4@40 12:Dx1@180"),
        "description": ("the CAR-190 sequence + persistence dark, 4 darks, 5 "
                        "low-flux (150 e/pix/s) and 4 high-flux (1500 e/pix/s) "
                        "band-3 flats, persistence dark; the low-flux flats "
                        "are 22 resultants, past L2's 16, so never at L2"),
        # Not visible in the signature (exposure times are unchanged), only in
        # each frame's meta.exposure, which stage 1 records per activity. It
        # puts a ~0.8 % SCA18-only offset between this variant and CAR-190.
        "readout": ("IM_DIAGNOSTIC (MA table 9010): every read 1-13, a "
                    "full-frame downlink"),
        "ma_table": 9010,
        "first_seen": "2026-10-20, CAR-216 plan 6 pass 1 (decon3)",
    },
}

# Dated operations events the digests do not carry, drawn as dashed lines on
# the windowed trend figures (digest_trend_plots.py; the full-period figures
# from run_trend.py do not draw them). Decons, ACM moves and the side swap are
# not here: the digests carry those and every figure shades them. Only events
# with a known time go in; MANIFEST.md has the evidence for each. UTC.
TREND_EVENTS = (
    ("2026-10-09T05:11", "enclosure 132 -> 139"),
    ("2026-10-17T23:01", "enclosure 139 -> 143"),
    ("2026-10-30T01:48", "AOM +5.2 K"),
    ("2026-11-01T23:48", "AMS +5.0 K"),
    ("2026-11-05T04:30", "AOM, AMS back"),
)

# Side-status mnemonics, reserved. The MCE side is an operator label
# (batch/run_manifest.csv mce_side) corroborated by batch/side_witness.py,
# because no telemetry the EDP serves names it. WFIF_ICDH_HPSM_MCE_OHPA_STS and
# _OHPB_STS were suggested as side indicators; on 2026-10-09 neither was among
# the 20,750 mnemonics of the MAST EDP dictionary (no WFIF_ICDH_* name is), and
# the data endpoint rejected both with HTTP 400. NOT YET WIRED: when they
# appear, check one with trend_housekeeping.py --mnemonic, then add them to the
# stage-1 query in rcs_telemetry.build_telemetry_table (they are status
# strings, so they need sampling like the LED enables, not like the floats)
# and to the side_witness table. Until then this tuple is documentation.
SIDE_STATUS_MNEMONICS = ("WFIF_ICDH_HPSM_MCE_OHPA_STS",
                         "WFIF_ICDH_HPSM_MCE_OHPB_STS")

# Per-LED bridge-step spread at an *MCE side* boundary above which the step is
# called out rather than just recorded.  Calibrated against the real ACM
# boundaries: over 36 fitted ACM steps in the v3 digests the per-LED spread runs
# 1.4e-4 to 1.8e-3, so 5e-3 is ~3x the worst fit noise ever seen and ~10x the
# median, while still an order of magnitude below the 4.81% across-LED spread of
# B_SIDE_CORRECTIONS.  Note rather than refusal: a chromatic step across a swap
# is *expected*, since the ground-derived side table is known to need a flight
# replacement.  The unambiguous error -- a 'global' photodiode reference across
# a swap -- is refused at ReferenceCard.build, where it is actionable.
SIDE_LED_SPREAD_WARN = 0.005

# ---------------------------------------------------------------------------
# Photodiode
# ---------------------------------------------------------------------------
#
# Every constant in this block is applied to *both* diodes -- PD2 (HgCdTe, the
# measurement and the baseline) and PD1 (InGaAs, BANK1's measurement diode,
# reduced here only as a check). PEDESTAL_MIN_SAMPLES and MIN_INTERVAL_SAMPLES
# in particular gate PD1's independent pedestal as well as PD2's, which matters
# because the two pedestals genuinely differ (median 4.33 mV apart) and PD1's
# dark noise is ~18x lower. PD_MIN_NET guards PD2's net as a correction
# denominator and PD1's only as a ratio denominator. See PD_CORRECTION.md.

# pd_net is a *denominator* in the photodiode correction, so a pedestal taken
# from a window that was not actually dark can turn a ~0.24 V net into a few mV
# and produce a 60x response factor that looks like a real instrument event.
# Below this, refuse to form a factor at all.  Nominal pd_net is 0.23-0.28 V.
PD_MIN_NET = 0.01

# Samples required in an all-off interval before it can set the pedestal.
PEDESTAL_MIN_SAMPLES = 5

# Runs shorter than this in the LED-enable timeline are treated as transitions
# rather than states, so one flipped sample cannot manufacture an interval.
MIN_INTERVAL_SAMPLES = 3

# Padding around the activity span when pulling the photodiode time stream, so
# an all-off interval exists both before the first LED and after the last.
#
# Measured caveat (CAR-216 pass 66, 2026-10-03): trend passes run back to back,
# so 10 minutes of pad reaches *into the adjacent pass* -- 59% of the pre-run pad
# and 60% of the post-run pad have an LED enabled, in states the run itself never
# visits. The pad therefore does not reliably supply quiet telemetry, which is
# why the pedestal prefers the off interval overlapping the dark activity's own
# window over pooling every off interval it can find. Pooling is still a correct
# fallback -- a neighbour's inter-exposure gap is genuinely LEDs-off -- but it
# measures a pedestal from a different part of the thermal cycle.
PD_PAD_MINUTES = 10.0

# The photodiode readings rail at exactly 2.5000 V. Observed on CAR-216 pass 66:
# 220 of 2620 samples sit at precisely that value, all of them in the *gaps*
# between exposures while the LED drive is settling, and none inside any exposure
# window. So it is benign today and must not be assumed to stay benign: a railed
# sample is clipped, not measured, and a window that ever included one would pull
# pd_raw up, inflate pd_net, and inflate the response factor -- in the direction
# that looks like the lamp got brighter. Counted and flagged per activity rather
# than clipped, since clipping would hide the condition.
PD_RAIL_V = 2.5

# LED-enable state codes on the photodiode sample grid.
PD_STATE_UNKNOWN = -1   # before the first telemetry sample for a channel
PD_STATE_OFF = 0
PD_STATE_MULTIPLE = 7   # more than one LED enabled at once

# ---------------------------------------------------------------------------
# MAST querying
# ---------------------------------------------------------------------------

# Schema tag written into every cached query plan, so a plan from an older
# layout is refused rather than half-read.
PLAN_SCHEMA_VERSION = "rcs-query-plan/1.0"

# SCAs required per *lit* activity before streaming is allowed to start.  The
# dark is deliberately exempt: it is not processed to L2 at all (see
# rcs_mast.check_plan_coverage), so requiring 18 there would reject every run.
MIN_SCAS = 18

# Where a short product is moved to, relative to the directory it was found in.
# Lives here because two independent tools relocate into it -- the batch worker
# when it decides an existing product is not complete, and
# batch/triage_products.py --move-degraded -- and if they ever spelled it
# differently the worker would retry a pass whose evidence sat in the other
# directory.  A *move*, never a delete: the short product is the record of what
# the listing returned.
DEGRADED_SUBDIR = "degraded"

# Declared equivalences between L2 calibration configurations, keyed on the
# ``ref_file_id`` that rcs_l2_source.read_provenance hashes out of the L2
# ``ref_file`` branch.  Epochs in the same class may be trended together;
# epochs in different classes may not, because the difference is a per-SCA
# multiplicative flux scale and it enters the trend as a step.
#
# This table exists because the hash cannot answer the question on its own.
# Two configurations that differ in every reference file may still produce
# identical pixels, and the only way to know is to divide one by the other.
# So each entry here is a *measurement*, not a convention, and the comment is
# the measurement.
#
# Measured 2026-10-05 on CAR-190 plan 2 pass 1, the one pass MAST reprocessed
# as a trial, so both configurations exist for the same exposures:
#
#   57375af18e138f28  cal 1.0.1  roman_0067.pmap  photom SKIPPED  (aux,
#                     /mnt/roman-s3-romcom/activities/CAR190, reference files
#                     from /teams/team-rtb/run_for_record_reffiles/)
#   1aa8a84bc016ea68  cal 1.0.2  roman_0072.pmap  photom COMPLETE (MAST)
#
# Pixel ratio aux/MAST over 16.7 M illuminated pixels: median 1.00000000, with
# 99.98 % of pixels agreeing to better than 1e-6 relative.  Through the full
# pipeline the per-SCA medians agree to 0.0007 % rms, 0.003 % worst.  So
# photom in roman_0072 is a no-op and skipping it is equivalent to applying it.
#
# roman_0073 needs no measurement and gets no entry of its own: it resolves to
# byte-identically the same 17 reference files as roman_0072 -- checked field by
# field on CAR-190 passes 42 and 51 -- so it hashes to 1aa8a84bc016ea68 too.
# That identity is also why the hash excludes the ``crds`` sub-dict; see
# rcs_l2_source.read_provenance.
#
# roman_0075 (CAR-190 p3 pass 75 and CAR-216 p4 on, from 2026-10-09) hashes to
# 5c871b249e2f6eaf. Diffed against roman_0074 on the SCA01 provenance frame of
# passes 74 and 75: of the 17 reference files only distortion moved, 0027 ->
# 0053, and the cal_step branch is identical (photom_0080 COMPLETE, flat
# SKIPPED). Distortion feeds assign_wcs, which attaches a WCS and leaves the
# data array alone. No exposure exists under both contexts (MAST still serves
# pass 74 as roman_0074), so this measurement is weaker than the pass-1 one: a
# per-(SCA, LED) trend with a step at 74|75, fitted over the seven B-side
# epochs 71-75 and CAR-216 p4 1-2, puts a per-SCA achromatic step of
# 0.0151 % rms (linear) or 0.0085 % (quadratic) there. Null splits read
# 0.0098-0.0169 % and 0.0040-0.0092 %. So any step is at the trend's noise
# floor, more than 100x below the 1.787 % of the old family. Reproduce with
#   trend_change_check.py steptest --first CAR190_01039_03_071 --last CAR216_01063_04_002 --at CAR190_01039_03_075
#
# roman_0076 (CAR-216 p4 pass 4 on, from 2026-10-10) hashes to
# 2dd418ec414b1196. The same check against roman_0075 (p4 passes 3 and 4)
# again finds only distortion moved, 0053 -> 0061, with cal_step identical.
# Fitting a quadratic over the twelve B-side epochs (71-75, p4 1-7) puts a
# per-SCA achromatic step of 0.0037 % rms at p4 3|4. Null splits read
# 0.0042-0.0074 %; linear, 0.0171 % against 0.0081-0.0270 %. Reproduce with
#   trend_change_check.py steptest --first CAR190_01039_03_071 --last CAR216_01063_04_007 --at CAR216_01063_04_004
#
# roman_0077 (CAR-190 p3 pass 76 on, from 2026-10-13) hashes to
# 2c8d2de83f5ace81. Against roman_0076 (CAR-216 p5 6 vs CAR-190 p3 76) only
# distortion moved again, 0061 -> 0078; cal_step identical. Over the nineteen
# B-side epochs CAR-216 p4 1 .. CAR-190 p3 77 the degree-2 per-SCA achromatic
# step at p5.6|p3.76 is 0.0103 % rms, inside the null range 0.0041-0.0136 %.
# Weaker than 0075/0076: only two 0077 epochs, the boundary is also a CAR-216
# -> CAR-190 switch, and its focal-plane LED1 step (-0.172 %) was outside the
# nulls' +/-0.10 %. Re-tested 2026-10-17 with six 0077 epochs (window to
# CAR-190 p3 81): per-SCA 0.0148 % against nulls 0.0058-0.0182 %, and the LED1
# step flips to +0.150 % against nulls of -0.219..+0.176 %. So the LED1 reading
# was LED1's growth curvature at a window edge, not a calibration step.
# Reproduce with
#   trend_change_check.py steptest --first CAR216_01063_04_001
#     --last CAR190_01039_03_081 --at CAR190_01039_03_076 --degree 2
#
# romancal 1.0.2 -> 1.0.3 at CAR-216 p5.23 (2026-11-03) keeps this id: same
# roman_0077 context, same reference files and steps (refdiff), so nothing
# here changes, but the code can move pixels on its own. Measured 2026-11-09
# over CAR-190 p3.84 .. p3.98: per-SCA achromatic step at p5.22|p5.23 0.126 %
# rms, inside nulls of 0.028-0.264 % that the AOM/AMS-era curvature widens,
# so only a step well above ~0.13 % is excluded; SCA18 against the rest
# (relative --sca 18 --at CAR216_01063_05_023) reads -0.15..+0.01 % in
# LED2-6, nothing like the 0.76 % its read-1 correction gave at an MA-table
# change. OPEN: the pixel test, when MAST serves a pre-1.0.3 pass from 1.0.3
# (refdiff now says so); re-run the steptest once the bumps are further back.
#
# The three ids below the fold are the *same two* calibrations as fingerprinted
# by the superseded hash, which included the context string.  Products written
# before 2026-10-05 carry them, so they stay mapped rather than being allowed
# to trip the guard on a hash-definition change that has no physical content.
#   fb7be0c9d705b6ae  = 57375af18e138f28  (aux @ roman_0067)
#   c7fab59daf321aec  = 1aa8a84bc016ea68  (MAST @ roman_0072)
#   9f3f1a24216da0ad  = 1aa8a84bc016ea68  (MAST @ roman_0073)
#
# The configuration that is *not* equivalent, and is the reason this exists, is
# the old MAST family (cal 1.0.1, roman_0061/0065/0066/0067 as served before
# the 2026-09-24 reprocessing, photom reference 0040).  Against the above it
# applies a per-SCA achromatic scale of -2.28 % to +3.08 %, 1.787 % rms, with
# an across-LED spread of only 0.028 % -- a 64:1 achromatic signature, which is
# how it was told apart from a film reset.  It is deliberately absent from this
# table: its ref_file_id gets a class of its own, so a set mixing it with
# anything above is refused.
# Software changes under one ref_file_id, once measured: (ref_file_id, old,
# new) -> the result, which make_sca_digests prints in place of the NOTE that
# asks for the measurement. The numbers and commands are in the comment above.
MEASURED_SOFTWARE_CHANGES = {
    ("2c8d2de83f5ace81", "1.0.2", "1.0.3"):
        "measured 2026-11-09: per-SCA step 0.126 % inside nulls 0.028-0.264 %, "
        "SCA18 within 0.15 %; pixel test open",
}

CALIBRATION_EQUIVALENCE = {
    "57375af18e138f28": "unity-photom",     # aux  @ roman_0067
    "1aa8a84bc016ea68": "unity-photom",     # MAST @ roman_0072 and roman_0073
    "5c871b249e2f6eaf": "unity-photom",     # MAST @ roman_0075 (distortion only)
    "2dd418ec414b1196": "unity-photom",     # MAST @ roman_0076 (distortion only)
    "2c8d2de83f5ace81": "unity-photom",     # MAST @ roman_0077 (distortion only)
    # Superseded-hash aliases for the same two calibrations; see above.
    "fb7be0c9d705b6ae": "unity-photom",
    "c7fab59daf321aec": "unity-photom",
    "9f3f1a24216da0ad": "unity-photom",
}


def calibration_class(ref_file_id):
    """Equivalence class of one ``ref_file_id``.

    An unrecognised id is its own class, which is the safe default: an
    unmeasured calibration is assumed *not* to be equivalent to anything, so
    it trips the guard rather than passing silently.  To clear it, divide one
    configuration's pixels by the other's and, if they agree, add it above
    **with the number**.
    """
    ref_file_id = str(ref_file_id or "")
    return CALIBRATION_EQUIVALENCE.get(ref_file_id, ref_file_id)


# get_unique_product_list fetches one listing request per matched dataset and,
# under load, returns a merged table with no 'filename' column.  Six attempts
# with exponential backoff and jitter, capped, rather than three flat waits.
QUERY_RETRIES = 6
QUERY_BACKOFF_BASE = 5.0
QUERY_BACKOFF_CAP = 120.0

# Concurrent *listing* calls allowed across all batch ranks sharing a staging
# root.  Streaming is not leased: the listing API is the binding constraint.
QUERY_LEASES = 4
QUERY_LEASE_TIMEOUT = 900.0   # steal a lease held longer than this; a holder
                              # that died must not block the whole fan-out

# Measured 2026-10-03: MastMissions.read_product resolves a product name to a
# presigned S3 URL at *read* time, and that signature carries
# X-Amz-Expires=300.  One SCA takes ~5.5 s end to end, so a single read uses
# under 2% of its own signature's life -- but see the module docstring of
# rcs_mast for why this bounds how long an AsdfFile may be held open, and why a
# cached plan must store product *names* and never URLs.
PRESIGNED_URL_TTL_SECONDS = 300.0

@dataclass
class AnalysisConfig:
    """
    Top-level configuration for thin film analysis

    Attributes
    ----------
    wfi_ref : str
        Path to WFI reference files directory
    use_acm_nom : Optional[float]
        Reference ACM value; if None, uses first record
    qe_rebin : int
        Rebinning factor for QE data (1 = no rebinning)
    use_qe_median : bool
        If True, normalize QE by median value
    qe_mult : float
        Multiplicative factor for QE (fudge factor)
    n_water : float
        Refractive index of water ice
    """
    wfi_ref: str = "./reference_files/"
    use_acm_nom: Optional[float] = DEFAULT_ACM_NOMINAL
    qe_rebin: int = DEFAULT_QE_REBIN
    use_qe_median: bool = False
    qe_mult: float = DEFAULT_QE_MULTIPLIER
    n_water: float = DEFAULT_N_WATER


@dataclass
class CorrectionFlags:
    """
    Flags controlling which corrections to apply when adding trend points

    Attributes
    ----------
    correct_pd : bool
        If True, correct for photodiode variations
    correct_side : bool
        If True, correct for A/B side (MCEB) differences
    correct_acm : bool
        If True, correct for ACM position changes
    multiplier : float
        Optional multiplicative factor (useful for A/B swaps)
    """
    correct_pd: bool = True
    correct_side: bool = True
    correct_acm: bool = True
    multiplier: float = 1.0
    

def normalize_side(side) -> str:
    """Canonical ``"A"``/``"B"`` from a side label, ``bool``, or filename.

    The per-SCA h5 products carry an explicit ``mce_side`` attribute, so the
    electronics side no longer has to be sniffed out of a filename (flight
    filenames never contained ``MCEA``/``MCEB`` in the first place -- only the
    TVAC SCIPA products did, which silently made every flight epoch A-side).
    """
    if isinstance(side, bool):
        return "B" if side else "A"
    text = str(side).strip().upper()
    if text in ("A", "B"):
        return text
    if "MCEB" in text:
        return "B"
    if "MCEA" in text:
        return "A"
    raise ValueError(f"cannot read an electronics side from {side!r}; "
                     "expected 'A', 'B', or a name containing MCEA/MCEB")


def acm_coefficient_for(side) -> float:
    """Linear ACM response coefficient for an electronics side."""
    return ACM_COEF_MCEB if normalize_side(side) == "B" else ACM_COEF_DEFAULT


def acm_offset_for(side) -> float:
    """LVDT readout offset for an electronics side."""
    return MCEB_ACM_OFFSET if normalize_side(side) == "B" else 0.0


def b_side_correction_for(led_name: str, side) -> float:
    """Per-LED scale putting an epoch on the A-side scale."""
    if normalize_side(side) == "B":
        return B_SIDE_CORRECTIONS.get(led_name, 1.0)
    return 1.0


def validate_bin(bin_factor, sca_pix: int = SCA_PIX) -> int:
    """Check a superpixel bin factor divides the SCA array, and return it.

    Called at argument-parse time rather than left to ``bin_frame``, which
    would otherwise raise only after a multi-gigabyte pull.
    """
    try:
        value = int(bin_factor)
    except (TypeError, ValueError):
        raise ValueError(f"bin factor {bin_factor!r} is not an integer")
    if value < 1:
        raise ValueError(f"bin factor {value} must be positive")
    if sca_pix % value:
        divisors = [d for d in range(1, sca_pix + 1)
                    if sca_pix % d == 0 and d <= 64]
        raise ValueError(
            f"bin factor {value} does not divide {sca_pix}: superpixels would "
            f"be ragged and straddle SCA edges. Divisors up to 64: {divisors}")
    return value


def get_acm_correction_coefficient(filename: str) -> tuple[float, float]:
    """
    Get ACM correction coefficient and offset based on filename

    Parameters
    ----------
    filename : str
        Path to data file

    Returns
    -------
    acm_coef : float
        ACM correction coefficient
    acm_offset : float
        ACM offset to apply (0 for non-MCEB, MCEB_ACM_OFFSET for MCEB)

    Notes
    -----
    Legacy filename-sniffing wrapper, kept for the TVAC/SCIPA products whose
    names carry ``MCEA``/``MCEB``.  Flight products carry an explicit
    ``mce_side`` attribute; prefer ``acm_coefficient_for``/``acm_offset_for``.
    """
    side = "B" if is_mceb_file(filename) else "A"
    return acm_coefficient_for(side), acm_offset_for(side)


def get_b_side_correction(led_name: str, filename: str) -> float:
    """
    Get B-side correction factor for a given LED and filename

    Parameters
    ----------
    led_name : str
        LED identifier (e.g., 'LED1')
    filename : str
        Path to data file (checked for 'MCEB' to identify B-side)

    Returns
    -------
    float
        Correction factor (1.0 if not B-side, B_SIDE_CORRECTIONS[led_name] if B-side)

    Notes
    -----
    Legacy filename-sniffing wrapper; see ``get_acm_correction_coefficient``.
    Prefer ``b_side_correction_for(led_name, side)``.
    """
    return b_side_correction_for(led_name, "B" if is_mceb_file(filename) else "A")


def is_mceb_file(filename: str) -> bool:
    """
    Check if a file is from the B-side electronics (MCEB)

    Parameters
    ----------
    filename : str
        Path to data file

    Returns
    -------
    bool
        True if file contains 'MCEB' in name
    """
    return "MCEB" in filename
