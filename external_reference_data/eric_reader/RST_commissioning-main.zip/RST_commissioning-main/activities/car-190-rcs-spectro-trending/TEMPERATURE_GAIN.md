# The temperature-dependent photometric gain

The MPA falls from ~124 K to a 89.5 K asymptote with a ~10 h e-folding after
each decon, and the RCS response follows it. This document reports a
free-standing measurement of that gain from the calibrated products, and what it
implies for where the correction belongs.

Entry point:

```bash
.venv/bin/python fit_temperature_gain.py --out-dir plots/temperature_gain
```

It reads the per-SCA digests and the products' own `housekeeping/` group. No
network, no credentials, no re-run of stages 1-3, and it writes nothing any
other stage reads -- it is a measurement, not a correction. **Nothing in the
pipeline applies a temperature gain today.**

## The headline

**G(124 K) - 1 = -1.07 %**, relative to 1 at the 89.5 K nominal: the detectors
are ~1 % less responsive at the top of a decon cooldown than at equilibrium.
Fitted on 19 008 points (18 SCAs x 6 LEDs x 176 epochs).

The questions, answered:

| question | answer | where |
|---|---|---|
| achromatic? | **yes**, across LED2-LED6 (853-1670 nm, agreeing to 0.17 %). LED1's apparent excess is film-model error, specifically from the thickness's *time* dependence. | `tempgain_growth_freedom.png` |
| SCA-dependent? | **mildly** -- 0.250 % (1sigma) across 18 detectors, 23 % of the mean effect. Not spatial. | `tempgain_per_sca.*` |
| applies to decon 1? | **yes** -- a gain fitted on decon 2 describes decon 1 nearly as well as a local fit. | `tempgain_transfer.png` |
| how to model it? | one achromatic polynomial in MPA T, pinned to 1 at 89.5 K, with a per-SCA coefficient. | Sec. "How to model it" |
| is the film one rate? | **no** -- 8.4 % across detectors, and decon 2 grows **30 % faster** than decon 1 on 17/18. The gain moves 0.03 % when all of it is freed. | Sec. 5 |
| does a decon add pure phase? | **yes, within the error that matters** -- the amplitude ratio across the decon is 0.97 +/- 0.09, where the +/-0.09 is the growth model, 15x the 0.006 statistical error. | Sec. 5, last part |

## Why this cannot be regressed naively

The response is a product of two things that both move monotonically early in
each decon episode:

```
R = G(T) * F_film(d)
```

The cooldown and the film growth are **confounded**. A naive response-vs-T
regression reads one as the other, and the per-LED correlations come out mixed
in sign (LED1 +0.41, LED4 -0.67) -- the signature of a fit absorbing the wrong
effect. About 90 % of LED1's swing survives at thermal equilibrium, which is to
say most of it was never temperature. A joint fit is mandatory.

### What separates them

Four levers, in descending order of strength:

1. **The film is chromatic with *known relative* fringe frequencies.**
   `omega_l = 2 k_l * rate` with `k_l = 2pin/lambda_l`, so the six bands' fringe rates are
   locked by wavelength ratios alone -- 2.68x between the extremes (1670/624).
   One free `rate` sets all six. An achromatic gain cannot imitate that
   structure, and this is what carries the measurement.
2. **Timescale separation.** The MPA decays with a ~10 h e-folding; the fringes
   run over hundreds of hours.
3. **Two cooldowns from different start temperatures** (decon 1 ~110 K, decon 2
   ~124 K) put the same film age at two temperatures.
4. **The intra-epoch gradient** -- the MPA drifts measurably *within* one LED
   sequence. Weakest lever, worth ~+/-1 % of the chromatic modulation, because the
   per-LED offset is nearly proportional to `(T_mean - T_nom)`.

### The ordering trap, and why the gain is evaluated per LED

**LED sequence order is wavelength order.** So an achromatic gain acting through
the intra-epoch gradient (lever 4) produces a monotonic *apparent-chromatic*
ramp -- a perfectly achromatic detector will look chromatic if the gain is
evaluated at an epoch-mean temperature. The fit therefore evaluates `G` at
`T[epoch, led]`, never at an epoch mean, and the injected-truth self-test
asserts that the per-LED mode does **not** manufacture chromaticity from
achromatic input.

How big is the trap? `housekeeping_intra_epoch.png` measures the per-LED
temperature spread at 0.81 K at the hot end (LED1 +0.36 K to LED6 -0.45 K,
strictly ordered). With `dG/dT = -0.044 %/K` at 124 K, evaluating the gain at an
epoch mean would manufacture **0.035 %** of apparent chromaticity -- 5x smaller
than the 0.172 % agreement among LED2-LED6 and 34x smaller than LED1's 1.19 %
excess. So the guard is correct but it is not what the chromaticity result turns
on: neither the agreement nor the outlier can be explained by the ordering
trap.

### It is detector-side, not lamp-side

`SPHERE_T` varies by ~8 mK and `BOARD_T` by ~0.3 degC over the same period in
which the MPA swings 34 K. The effect is in the focal plane.

## The model

```
R[s,l,e] = G_g(T[e,l]) * (a + b*cos(omega_l tau_e) + c*sin(omega_l tau_e))
G_g(T)   = 1 + Sigma_k alpha[g,k] * ((T - 89.5) / 10)^k
omega_l      = 2 k_l * rate,   k_l = 2pin/lambda_l,   n = 1.25
```

- **89.5 K is measured, not fitted.** Both cooldowns land on it within 40 mK.
  Pinning `G(T_nom) = 1` is what breaks the degeneracy between the gain and the
  film amplitude `a` -- without a pinned point the two are a single product.
- **`tau` is `decon_time_hours`**, not `time_hours`: a decon resets the film, so
  the film clock restarts at each episode boundary
  (`decon_episode_bounds = [[1,35],[36,176]]`).
- **`n = 1.25`** matches `rcs_trend_config.DEFAULT_N_WATER`. The round-trip
  phase is `2 k d`, following `film_optics.film_wavenumbers()`, where the
  `cos theta_d` factor is deliberately absent.
- **`(a, b, c)` are solved in closed form** per `(sca, led, episode)` -- they are
  linear given the gain and the growth -- so only `growth` and `alpha` reach the
  optimiser. The sinusoid is linearised rather than phase-fitted, which is what
  makes an 18x6x176 joint fit tractable.
- **Multi-start on growth.** A single start hops fringe branches; that failure is
  already on record for the per-epoch thickness fits, where a grid clipped below
  the truth produced a confident fit to the wrong branch.

### chi^2/dof is 35, so every uncertainty here is empirical

The model is deliberately incomplete -- the sinusoid is linearised, growth is a
low-order polynomial, and nothing accounts for per-epoch lamp jitter. Formal
Jacobian errors are therefore meaningless, and none are quoted. Every bar in
this document is a spread: across the 18 detectors, across 8 model variants, or
across interleaved halves of the epoch set.

## 1. Is it achromatic?

**Yes, and the first reading of the data says no.** This is the one result worth
following in detail, because the naive statistic is both true and wrong.

The raw band-to-band spread is 1.193 % against a 0.059 % per-detector standard
error -- 20x the noise, which reads as strong chromaticity. But the spread is
**LED1 alone**: LED2 through LED6, spanning 853-1670 nm, agree to 0.17 %. A real
QE or band-edge effect would be monotonic in wavelength. One band standing away
from a tight pack of five is a per-band systematic.

And LED1 is exactly the band where a film-model error would land. Since
`k propto 1/lambda`, the shortest band has the **fastest** fringe: LED1 accumulates
`2kd ~ 3.12` rad of phase over the episode against 1.17 rad for LED6, so
constant growth is the worst approximation precisely there. The test is to give
the film more freedom and watch:

| growth degree | LED1 | LED2 | LED3 | LED4 | LED5 | LED6 | spread | without LED1 | rate | chi^2/dof |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 (constant) | **-2.127** | -0.935 | -1.082 | -1.107 | -0.990 | -0.956 | 1.193 | 0.172 | 0.4106 | 21.35 |
| 2 | **-2.018** | -0.984 | -1.070 | -1.117 | -1.004 | -0.963 | 1.055 | 0.154 | 0.4477 | 20.18 |
| 3 | **-1.805** | -1.049 | -1.057 | -1.113 | -1.019 | -0.985 | 0.819 | 0.127 | 0.5627 | 19.23 |

(percent deviation at 124 K)

LED1 moves 0.32 % toward the pack while chi^2/dof improves monotonically and every
other band moves by less than 0.12 %. That is the signature of gain absorbing
film-model error, not of a detector property: a real chromatic gain would hold
still as the film is freed.

**Conclusion: the gain is achromatic across the five stable bands. LED1's excess
is film-model leakage -- specifically leakage from the thickness's *time*
dependence.** It has not converged by degree 3, so 0.32 % is a *lower bound* on
the leakage, and LED1 should be treated as the band whose temperature-film
separation is least trustworthy.

#### Which film freedom, and the test that nearly inverted this

The table above varies one thing -- the growth polynomial's degree -- and a table
with one knob in it cannot tell *"the film model is wrong"* from *"the film
model is wrong in this particular way."* Those have different consequences, so
the freedom was split in two and each half run separately:

- **curvature** -- the thickness nonlinear in time, `d(tau) = Sigma rho_m (tau/100 h)^m`,
  shared across detectors. The table above.
- **placement** -- a *constant* rate, but free per detector, per decon, or both.
  This needs the alternating fit, since a per-LED gain couples the detectors.

| variant | freedom | chi^2/dof | LED1 - pack |
|---|---|---|---|
| shared rate | none | 21.353 | **-1.137** |
| rate per decon | placement | 21.345 | -1.152 |
| rate per detector | placement | 18.578 | -1.163 |
| rate per detector + decon | placement | 18.105 | **-1.136** |
| growth deg 2 | curvature | 20.177 | -1.014 |
| growth deg 3 | curvature | 19.228 | **-0.755** |
| per decon + deg 2 | both | 19.275 | -0.887 |
| per detector + decon + deg 2 | both | 16.236 | -0.958 |

**The two freedoms separate completely, and they separate the opposite way to
the natural guess.** Placement is by far the better *fit* -- chi^2/dof 21.35 -> 18.11,
a 15 % improvement against curvature's 10 % -- and it moves LED1's excess by
**0.001 %**, i.e. not at all (-1.137 -> -1.136). Curvature fits less well and
moves LED1 by 0.38 %.

So chi^2 improvement is **not** evidence about LED1 in either direction, which is
the trap this test exists to avoid: a fit that is materially better while LED1
sits exactly where it was. And the mechanism is coherent rather than merely
observed -- LED1's exposure to film error comes from phase accumulated over tau,
and giving each detector its own *constant* rate does not change the time
dependence of anything. It re-scales tau, which the fringe amplitude and phase
(free per `(SCA, LED, episode)` already) absorb without residual.

**Consequence for the calibration:** a per-SCA or per-decon growth rate will not
fix LED1, so do not reach for one expecting it to. Only a better `d(tau)` will.

### What would change this conclusion -- both tests have now been run

The previous version of this section named two outcomes that would overturn the
leakage reading, and recorded that neither had been run. Both have now been run
and **neither fired**:

1. *"An LED1 gain that **stops** moving once growth is flexible enough while
   still sitting ~0.8 % below the pack."* It has not stopped. Degree 3 takes it
   to -0.755 % and the step from degree 2 to degree 3 (0.26 %) is still most of
   the step from 1 to 2 (0.12 %) -- it is accelerating, not converging.
2. *"A per-SCA version of the growth test in which LED1's excess tracks a
   detector's film rate rather than being common across detectors."* The
   opposite: LED1's excess is **completely insensitive** to per-detector rate
   (-1.137 -> -1.163 -> -1.136 across the three placement variants, a 0.03 %
   wobble on a 1.14 % excess). It is common across detectors.

The conclusion therefore survives, with a sharper mechanism than it had: not
generic film-model slack, but the growth's time dependence specifically.

What would *still* overturn it is unchanged in spirit and now better specified:
an LED1 excess that plateaus above ~0.5 % under a growth model with real
freedom in `d(tau)` -- a spline, or the per-epoch thickness the rank-1 fit already
solves -- while chi^2/dof keeps improving. The polynomial ladder cannot settle that,
because a degree-3 polynomial over a 271 h episode is still a stiff curve.

`tempgain_residuals.png` corroborates this from a figure that was not built to
test it: LED1 dominates the residuals in **both** panels, against five bands
that sit flat near zero, and its residual-vs-time shape is a slow film-like
wander rather than a thermal step. The band with the worst-modelled film is the
band with the structured residual and the anomalous gain -- one cause, three
symptoms.

Reporting the spread alone would have written this up as chromaticity -- the same
failure mode as the PD1 wavelength mislabel recorded in `PD_CORRECTION.md` Sec. 3,
where a physically absurd number was explained rather than doubted.

## 2. How SCA-dependent?

**0.250 % (1sigma) across the 18 detectors**, on a -1.07 % mean -- 23 % relative.
The range is -1.586 % (SCA1) to -0.648 % (SCA3), so the extremes differ by a
factor of 2.4 even though every detector shows the effect with the same sign.

**It is not spatial.** SCA1, SCA17 and SCA18 cluster at the deviant end
(-1.45 to -1.59 %), which invites a focal-plane reading, so the clustering was
tested rather than eyeballed: Pearson r against each of `x_center`, `y_center`,
`|y_center|` and focal-plane radius, each with a permutation p-value (shuffled
labels rather than a Gaussian tail, because 18 points of a fitted quantity put
real weight on the distributional assumption). The strongest coordinate is
`y_center` at r = -0.40, p = 0.11 -- not significant, and nothing else is close.

So the scatter is **detector-to-detector**, which is why there is no
focal-plane heatmap among the figures: a 3x6 map of eighteen numbers with no
gradient in them is an invitation to read a pattern into noise. The consequence
for the calibration is concrete -- a per-SCA lookup is the right form, and a
spatial model would be fitting noise.

## 3. Does it apply to the decon-1 cooldown?

**Yes.** This is a genuine held-out test: a gain is fitted on decon-2 epochs
only, then **held fixed** while the film is refitted freely on decon-1 epochs.
Holding the gain and freeing the film is what makes a failure attributable -- a
poor score cannot be blamed on the film having been held at the wrong value.

| decon-1 chi^2/dof | |
|---|---|
| local gain (fitted on decon 1) | 29.5 |
| **imported gain (fitted on decon 2)** | **33.3** |
| no gain at all | 87.2 |

The gain is **essential** -- omitting it costs a factor of 2.6 in chi^2 -- and the
imported gain recovers most of what a local fit achieves. Normalised,
`bracket = (imported - local) / (none - local) = 0.066`, i.e. the decon-2 gain
is 93 % of the way to a locally optimal one.

This matters because the two cooldowns start from different temperatures
(~110 K vs ~124 K), so this is not a repeat measurement of the same thing: it is
the same `G(T)` curve read over two different intervals, which is the behaviour
a single temperature-indexed correction requires.

## 4. How should it be modelled in the calibration?

The measurement supports a **single achromatic quadratic in MPA temperature,
pinned to 1 at 89.5 K, with a per-SCA coefficient set**:

```
G_sca(T) = 1 + alpha_1[sca]*u + alpha_2[sca]*u^2,   u = (T - 89.5) / 10
```

Coefficients are in `tempgain_per_sca.ecsv`; the shared/achromatic curve is in
`tempgain_curve.ecsv`. Those two are analysis outputs, overwritten wholesale by
the next fit run. The **pipeline** form of the same numbers is
`tempgain_model.ecsv` at the activity root, written by
`fit_temperature_gain.py --model-out` and documented in
`RCS_TREND_REFERENCE.md` Sec. 6.4 -- one row per (SCA, LED), 108 rows, with meta that
**names its own parametric form** (`form: poly_pinned_v1`) so a later model is a
different file rather than a code change. It is a pinned, committed calibration
input whose sha256 is recorded in every product it touches.

What justifies that form, point by point:

- **It is not an artefact of the film parametrisation.** The headline moves only
  **0.065 %** across 8 model variants (gain degree 1/2/3, growth degree 1/2/3,
  interleaved epoch halves, and a T < 110 K subset extrapolated to 124 K) --
  four times smaller than the 0.250 % detector scatter. The film
  parametrisation is therefore not the limiting uncertainty.
- **The polynomial is not imposing the answer.** A binned common-mode estimate
  that uses **no gain model at all** traces the fitted curve almost exactly
  (`tempgain_nonparametric.ecsv`, drawn on `tempgain_curve.png`).
- **It is not degenerate with the ACM bridge.** Both ACM boundaries whose step
  was **fitted** from the response (`method = 'bridge'`) sit within 13 mK of
  nominal, where `G ~ 1`, so no fitted step could have absorbed the gain. The
  one boundary at high temperature (idx 35, 123.98 K, the decon-2 transition)
  had its step **modelled from the LVDT** (`method = 'multiplier'`) and never
  looked at the response at all. The *method*, not the temperature, is what
  decides whether a boundary can contaminate the gain -- judging by temperature
  alone raises a false alarm here, and did on the first pass.

### Where it belongs

**Downstream of the h5 calibrated products, inside the thin-film modelling** --
not as a stage-2 multiplier. The reason is in Sec. "Why this cannot be regressed
naively": the gain and the film are separable only in a *joint* fit that uses
the known chromatic fringe structure. A stage-2 correction would have to apply
some gain before the film is known, and any error in it would be absorbed by the
film fit as a growth-rate bias -- which is the one quantity the film fit exists
to measure. The LED1 result above is that failure mode caught in miniature,
running in the other direction.

The practical consequence for `fit_film_rank1.py` / `fit_film_thickness.py` is
that `G_sca(T)` enters as a multiplicative term with **no free parameters** when
the coefficients are imported, or with one shared scale factor if a residual
calibration is wanted.

**What is implemented, and the line it does not cross.** The model now travels
with the data without being applied to it. Stage 2 takes
`--tempgain-model tempgain_model.ecsv` and writes `calibration/tempgain/` into
each calibrated product (a top-level `tempgain/` group in schema 1) holding the
**evaluated multiplier** `1/G(T)` per LED and per SCA, with `applied = False`
and a note saying so. Since schema 2 this is how *every* calibration step is
recorded, and the gain is simply the one step left out of `total_multiplier`. Nothing is multiplied in: the
pixels are bit-identical to a run without the flag, verified across the whole
176-product set. Stage 3 applies it only to conditional `LEDx_tgcorr` columns and
the `*_tgcorr` comparison figures -- each drawn on the same axes as its delivered
counterpart so the two can be blinked -- leaving `LED1..LED6`, which every fitter
in this activity reads, including this one, gain-free.

So the architecture above is unchanged as an argument: the correction still
belongs downstream, in the joint fit, and the product records a reference
multiplier rather than adopting an interpretation. What the block buys is that a
downstream consumer no longer has to find this document and re-derive the
coefficients to use them. The h5 description is deliberately **model-agnostic** --
it answers only "what is the multiplier for this LED, this SCA, at this one
trend point", and the coefficients are *not* in the product, so there is exactly
one answer to that question in each file.

Two directional notes, because both are easy to get backwards:

- The product stores **`1/G`, not `G`** -- the factor a consumer multiplies by to
  *remove* the gain. Both sit near 1.0 and differ only in the sign of a ~1 %
  term. A detector is less responsive hot, so above nominal the stored
  multiplier is greater than 1. Over the 176-epoch set it runs
  **0.999989 to 1.016318**, and the low end is not a bug: the model is pinned to
  1 at 89.5 K, so the handful of LEDs measured a few hundredths of a kelvin
  *below* nominal get a multiplier a few parts in 10^6 under 1. Do not write a
  consumer-side check that the multiplier exceeds 1 -- the sign of `T - 89.5 K`
  is what sets its direction, not the fact that the run was mostly warm.
- A trend series gauged to a reference epoch needs the **ratio** `m_i/m_0`, not
  `m_i`. Using the absolute multiplier rescales the series by a constant -- a
  smooth, plausible, uniformly wrong trend.

Applying the gain by default remains out of scope while it is provisional, and
`tempgain_applied` exists so that the day it changes, the change is visible in
the product rather than silent.

### Caveats to carry

- **Constant growth is an approximation, and Sec. 5 measures how bad.** One rate per
  detector per decon improves chi^2/dof from 21.4 to 16.1 while moving the headline
  by 0.015 %. The approximation is real; it is what LED1's leakage is made of;
  and it is not what limits the gain.
- **LED1's leakage had not converged by growth degree 3**, so its quoted gain is
  a lower bound on the contamination rather than a measurement. Freeing the rate
  per detector or per decon does **not** reduce it (Sec. 1), so a flexible `d(tau)` is
  the only route to converging it.
- **One thermal channel, and almost no leverage on side B.** `WFI_COBA_WTSC10P_K`
  also tracks a cooldown (170 -> 143.5 K) and is available as an independent
  regressor; it has not been used. The four side-B epochs (2026-10-06 on) all sit
  on the 89.5 K plateau, so they add nothing to the gain's temperature leverage.
  They enter the fit through the side-bridged digests. `WFI_MCE_ADC_WTSM00` is
  read off the MCE ADC, which changed side; it stepped by -0.02 K at the swap,
  negligible here, but a B-side cooldown would be the first test of whether the
  channel's calibration carried over.
- **Nothing is applied to the h5 pixels or to the canonical digest columns.** The
  model *travels with the data*, which is a different thing: stage 2 records the
  evaluated per-LED, per-SCA multiplier as `calibration/tempgain/` with
  `applied = False`, and stage 3 applies it only to the conditional `LEDx_tgcorr`
  digest columns and the `*_tgcorr` blink-pair figures. It is left out of
  `calibration/total_multiplier`, and the canonical `LED1..LED6` columns are
  gain-free. That is both what Sec. 4's argument above requires and what keeps this
  fit from reading its own output. Format in `RCS_TREND_REFERENCE.md` Sec. 4 and
  Sec. 6.2; the flow is `run_trend.py --fit-tempgain`.

### The v4 refit (2026-10-09, 185 epochs, sides A and B)

`run_trend.py --fit-tempgain` refitted the model from the v4 pass-1 digests,
side-bridged. The result is the tree's `tempgain_model.ecsv` (written to
`/data/eswitzer/rcs_trend_v4/`, deployed with the tree to
`/mnt/smdc-rom-com-ops/rrn-ops/activities/car-190-rcs-spectro-trending/rcs_trend_v4/` on 2026-10-12, and
`run_trend.py`'s default model from then on),
sha `24548054c3f7`, and is recorded in every v4 product. The committed
`tempgain_model.ecsv` (the v3 fit, sha `3c0cff96b0ae`) is unchanged.

| | v3 (176 epochs) | v4 (185 epochs) |
|---|---|---|
| gain at 124 K, median over SCAs | -1.073 % | -1.067 % |
| range over SCAs | -1.586 ... -0.648 % | -1.524 ... -0.640 % |
| per-SCA change v4 - v3 | -- | +0.006 % median, 0.022 % rms, 0.071 % max |
| reduced chi^2 of the joint fit | 21.7 | **41.2** |

The gain is stable to well under the 0.24 % detector-to-detector scatter.
**The chi^2 nearly doubling is not explained yet.** The gain did not move, so it is
the film/growth model fitting the longer set worse. The leading suspects are the
shared growth rate over a decon2 arm now extended to 2026-10-08 (decon2 grows
~30 % faster than decon1, Sec. 5), and the side-bridged B-side epochs. The verdict
file's "rate per detector+decon" variant reads chi^2/dof 23.6, against 38.8 for a
shared rate, which points at the first. Check per-epoch residuals before adopting
the v4 model as the committed one.

## 5. Is the film one number? (No -- and the gain does not care)

The growth rate varies across the focal plane, varies *more* across a decon, and
may vary within a detector. Those are three separate claims with three different
answers, so they are measured separately. The short version: **the film is
strongly structured and the gain is insensitive to all of it.**

### What was already free, and what was not

Worth stating first, because it determines which of these questions were open at
all. The fringe **amplitude and phase are already free per `(SCA, LED, episode)`**
in every fit in this document -- they are the `(b, c)` of
`a + b*cos(omegatau) + c*sin(omegatau)`, solved in closed form per block, with
`A = hypot(b, c)` and `phi = atan2(c, b)`. The 216 rows of
`tempgain_film_params.ecsv` (18 x 6 x 2) are that freedom written down. Position-
dependent phase and amplitude, and a per-decon phase, were therefore never
assumptions here.

What was *not* free is the **rate**, which sets the fringe **frequency** -- and a
frequency cannot be absorbed by an amplitude and a phase. That is the one gap,
and it is what Sec. 5 closes.

### Per detector: real, 8.4 %

| quantity | value |
|---|---|
| rate, one shared | 0.4571 nm/h |
| rate, per detector | 0.3818 - 0.5197 nm/h, sigma = 0.0381 (**8.4 %**) |
| chi^2/dof | 21.709 -> 19.283 |

Narrower than the rank-1 fit's 0.4379-1.0183, as it should be: that fit solves a
per-epoch thickness, so its range mixes detector-to-detector variation with the
per-epoch variation this model has no term for. Landing inside it is consistent,
not confirmatory.

### Per decon: the big one, and it is a rate change not just a phase change

**Decon 2's film grows ~ 30 % faster than decon 1's** -- ratio **1.2965** median
(sigma 0.1162), with **17 of 18** detectors faster, and chi^2/dof 19.283 -> 16.111. This
is the single largest film-model improvement available anywhere in this
document, and it is a *rate* difference, not the phase reset a decon obviously
produces.

It also explains a number measured earlier and left unexplained: the ~ +10 %
LED1 fringe-amplitude ratio across the decon in `tempgain_film_params.ecsv`. A
rate error shows up as an amplitude ratio once the episodes are fitted with a
common rate.

### Within a detector: not established, and quote it as a limit

A spread of rates *within* a detector damps the fringe as
`<cos 2kd> = exp(-2k^2sigma_d^2)*cos(2k*dbar)` -- amplitude loss growing with fringe
order, which is a different signature from a phase shift and therefore testable.
It is also **degenerate with growth curvature**, so it was compared against the
alternatives at a matched parameter count. Without the matching the comparison
is vacuous: any of them will improve chi^2 by spending one parameter per detector.

| model | params/SCA | chi^2/dof |
|---|---|---|
| one rate per detector | 1 | 19.283 |
| rate per decon | 2 | 16.111 |
| rate + intra-detector spread | 2 | 15.775 |
| **quadratic growth in time** | 2 | **14.659** |

Curvature wins at equal cost. And the dispersion fit pulls the rate down to
0.1726-0.3758 nm/h, giving **sigma_d/rate ~ 0.86** -- not a thickness non-uniformity,
which would be a few tens of percent, but the signature of a degenerate fit
trading rate against damping.

Fitting it *after* the per-decon rate -- i.e. after removing the growth error that
is actually there -- drops sigma_d from a median 22.4 to **8.56 nm/100 h** and
sigma_d/rate from 0.86 to **~ 0.18**. So most of what the dispersion term was
measuring was the per-decon rate error being re-measured through a different
parameter.

**Report sigma_d/rate < 0.2 as a limit, not a measurement.** A real ~ 18 % intra-
detector thickness non-uniformity is physically plausible and the data permits
it; the data does not *require* it, and curvature fits better.

### And the gain does not notice any of it

This is the part that matters for the calibration. Across every form of film
freedom above -- chi^2/dof falling 21.4 -> 13.0, a 39 % improvement:

| film model | mean G(124 K) - 1 | detector sigma |
|---|---|---|
| one shared rate | -1.1042 % | 0.2499 % |
| rate per detector | -1.1054 % | 0.2591 % |
| rate per detector + dispersion | -1.1061 % | 0.2571 % |
| quadratic growth per detector | -1.1190 % | 0.2555 % |
| rate per detector per decon | -1.0901 % | 0.2587 % |

The headline moves **0.029 %** across all of them and the detector scatter stays
inside 0.2499-0.2591 %. Both are far below the 0.250 % scatter that is already
the quoted uncertainty. **The -1.07 % headline and the 0.250 % scatter both
survive freeing the film completely.**

### The rate/gain correlation, and why it is not contamination

`corr(rate, G(124 K))` across the 18 detectors is **+0.549**, permutation
p = **0.0154** (20 000 draws) -- marginally significant on 18 points. That invites
the reading that part of the 0.250 % gain scatter is film leaking into the gain.

It is not, and the permutation test is the wrong test for it. The right test is
whether **pinning** every detector to one rate changes the gain:

- largest change to any detector's gain: **0.048 %**
- detector scatter: 0.2499 % (pinned) -> 0.2591 % (free) -- it *grows* slightly

A rate error can move any one detector by at most 0.048 %, which is 0.19x the
scatter it would have to explain -- **at most ~3 % of the variance**. Both
quantities vary across the focal plane and happen to co-vary; the correlation is
not a channel.

This is the distinction worth keeping: a significant correlation between a
nuisance parameter and a result does **not** establish that the nuisance is
contaminating the result. Freeing the nuisance and watching the result does.

### The user's prior: does an added layer act as pure phase?

The prior is `r_current = r_prior * exp(2ik*deltad)`, so `|r|` is invariant and a
decon's new layer contributes **pure phase** -- the fringe amplitude should carry
across a decon while the phase need not. Tested as pulls, in
`tempgain_amplitude_invariance.ecsv` and `tempgain_amplitude_invariance.png`.

**Read the pulls, not the ratios.** The raw per-band medians (LED1 1.098, LED2
1.099, LED3 1.052, LED4 0.969, LED5 1.107, LED6 1.353) look like a wavelength
trend and it is an artefact: the error on each ratio is set by how much fringe
that episode covers, and **coverage falls as 1/lambda** (episode 0 accumulates 3.12
rad at LED1 against 1.17 rad at LED6). The per-band sigma grows 0.083 -> 0.496 along
exactly that direction. Inverse-variance weighting removes the trend; the
unweighted median manufactures one.

The weighting works as designed: the apparent trend disappears, LED6's 1.353
becoming 1.106 +/- 0.014.

**But the weighted ratios are still 4-11 % from 1 against 0.2-1.4 % errors, so
the pull test reports a 5-7sigma violation of the prior -- and that verdict is
wrong, because the error bar is the wrong one.** The fringe amplitude is
degenerate with the growth rate: a wrong rate mis-sets the fringe frequency and
the closed-form `(a, b, c)` solve absorbs part of the mismatch into
`hypot(b, c)`. Sec. 5 has just established the shared-rate growth model *is* wrong,
by 30 % across the decon. So the amplitude ratio is only as good as the growth
model on both sides of the boundary, and the right error bar is how much it
moves when that model changes. Measured over four growth models
(`film_invariance_systematic`, `tempgain_amplitude_systematic.ecsv`):

| growth model | chi^2/dof | median band ratio | median \|ratio-1\| |
|---|---|---|---|
| shared rate | 35.123 | 1.041 | 5.2 % |
| rate per decon | 33.064 | 0.799 | 20.1 % |
| growth deg 2 | 28.963 | 0.931 | 8.5 % |
| **rate per decon + deg 2** | **25.040** | **0.973** | **6.2 %** |

The growth model moves these ratios by **0.090 against a 0.006 statistical
error -- 15x**. That settles the question in both directions:

- **The statistical pull is not the test.** Quoting `sigma_ratio` alone turns a
  growth-model systematic into a 5-7sigma detection of an optical effect. Both
  ECSVs now carry the systematic in their metadata for this reason, and
  `tempgain_amplitude_invariance.ecsv`'s `warning` key says so explicitly -- the
  per-pair table is the one a reader is most likely to open and least likely to
  have the context for.
- **Under the best-fitting growth model the prior holds.** At chi^2/dof 25.0, the
  best of the four, the six band ratios are 1.104, 0.947, 0.999, 1.078, 0.946,
  0.929 -- median **0.973**, i.e. 2.7 % from 1, against that 9 % systematic. The
  deviations that remain are ~6 %, two-sided, and **do not survive a change of
  growth model**: they move by more than their own size when it changes, which
  is the signature of the rate/amplitude degeneracy rather than of a change in
  `|r|`.

So **the prior holds at the few-percent level, with a ~9 % error bar set by the
growth model rather than by the data's noise.**

**Resist the sharper-sounding version of this.** Those same six ratios have a
*mean* of 1.0005 -- 0.05 % from 1 -- which reads as a far more impressive
confirmation than the median's 2.7 %. The gap between the two summaries (2.7 %)
is itself well inside the systematic (9 %), so the choice between them is not
information, and quoting the mean would be picking the statistic that flatters
the prior. The honest statement is the one with the error bar on it: 0.97-1.00,
+/-0.09. (The code reports the median, because a band whose episode covers almost
no fringe returns a near-unbounded ratio and a mean hands that band the answer.)

Note also the direction of the evidence: the per-decon rate *alone* drives the
ratio to **0.799** -- a systematic 20 % drop, worse than the shared rate -- and
only adding curvature restores it. A freedom that improves chi^2 can make this test
worse. The amplitude was never reporting an optical change; it was reporting
which growth model it had been handed.

**One guard worth knowing about.** The central value is read from the
lowest-chi^2 model, but chi^2 cannot see an amplitude driven to ~0, which makes the
ratio unbounded. `film_invariance_systematic` bars any model whose median band
ratio leaves `(0.1, 10)` from supplying the central value and reports the
exclusion. This is live, not hypothetical: the noise fixture's lowest-chi^2 model
returns a median band ratio of 10^6, and without the guard the verdict quoted it.

## Where to look

`plots/temperature_gain/` -- thirteen figures:

| figure | what it answers |
|---|---|
| `tempgain_curve.png` | the gain curve, with the model-free binned estimate over it |
| `tempgain_chromaticity.png` | per-band gain vs wavelength, against the detector scatter |
| `tempgain_chromaticity_growth.png` | per-band gain as the growth *degree* is raised |
| `tempgain_growth_freedom.png` | **the decisive one** -- LED1's excess vs the *kind* of film freedom, plotted against chi^2 so "better fit, same LED1" is visible rather than asserted |
| `tempgain_growth_structure.png` | the rate per detector, the rate per decon, and that the gain ignores both |
| `tempgain_amplitude_invariance.png` | the pure-phase prior, with ratios plotted against their own errors |
| `tempgain_per_sca.png` | the 18 detector gains, and all 18 curves |
| `tempgain_decomposition.png` | R, G(T) and F_film separated for one median detector |
| `tempgain_decomposition_per_sca.png` | the same decomposition at all 18 detectors, LED1, shared vs own rate |
| `tempgain_transfer.png` | the decon-2 -> decon-1 held-out test |
| `tempgain_residuals.png` | residuals vs time, T and tau, with the ACM boundaries marked |
| `tempgain_robustness.png` | the headline across 8 model variants vs detector scatter |
| `tempgain_acm_boundaries.png` | each ACM boundary's temperature, split fitted vs modelled |

Twelve ECSV tables with the same stems (`tempgain_curve`,
`tempgain_nonparametric`, `tempgain_per_led`, `tempgain_per_sca`,
`tempgain_robustness`, `tempgain_transfer`, `tempgain_chromaticity_growth`,
`tempgain_film_params`, `tempgain_growth_structure`,
`tempgain_growth_freedom`, `tempgain_amplitude_invariance`,
`tempgain_amplitude_systematic`), each carrying the chi^2/dof caveat in its
metadata, plus `tempgain_verdict.txt` with the answers as printed.

Four of those tables carry a warning in their metadata that is the whole point
of the table, so it is repeated here:

- `tempgain_growth_structure` -- `sigma_d` is a **limit**, not a measurement, and
  `gain_hot_shared_rate` is the *control* against which
  `gain_hot_free_rate` must be read. Comparing the free-rate gain against
  nothing is how the rate/gain correlation gets misread as contamination.
- `tempgain_growth_freedom` -- the `freedom` column is the axis the table exists
  to separate. A film-leakage claim must name which freedom was given, because
  on this set the two give opposite answers.
- `tempgain_amplitude_invariance` -- read `pull`, not `amplitude_ratio`, **and
  then do not read the pull either.** `sigma_ratio` is statistical only and is
  the *smaller* error by 10-100x. The dominant error is the growth-model
  systematic, carried in this table's `growth_model_systematic` and
  `warning` keys. Taking `sigma_ratio` as the error turns a confirmed prior
  into a 5-7sigma violation of it.
- `tempgain_amplitude_systematic` -- the spread **down** each `ratio_*` column is
  the error bar; read the central value off the lowest-`chi2_red` row. One row
  per growth model, which is the only reason the previous table's numbers can be
  interpreted at all.

To regenerate, with the per-detector fits in parallel:

```bash
.venv/bin/python fit_temperature_gain.py --processes 16
```

To regenerate *and* emit the pipeline model file that stage 2 ingests:

```bash
.venv/bin/python fit_temperature_gain.py --processes 16 \
    --model-out tempgain_model.ecsv
#   the genuinely per-(SCA, LED) variant, for comparison only
.venv/bin/python fit_temperature_gain.py --processes 16 --chromatic \
    --model-out /tmp/tempgain_model_chromatic.ecsv
```

The committed file is the **achromatic** one: the per-SCA coefficient replicated
across all six LEDs, with `derivation` on every row recording that, because Sec. 1
finds LED1's apparent excess to be film-model leakage rather than chromaticity.
The schema stays per-(SCA, LED) regardless, so nothing downstream changes if that
conclusion ever reverses.

This fit **refuses to run on a digest set whose canonical columns carry a gain.**
It reads `LED1..LED6`, so if those columns were ever gain-corrected the fit would
be a fixed-point iteration on its own output -- converging to coefficients near
zero, which reads as a clean null result rather than as a bug.
`load_dataset` checks the digest's own `tempgain_applied_to` meta and raises.

The parallelism is worth having and is also a trap. Every linear-algebra call
here is an Nx3 least-squares solve, where a multithreaded BLAS spends more time
on barriers than on solving -- measured at 800 % CPU for one fit that can use one
core's worth of work, and 16 workers x 8 threads oversubscribes a 16-core node
eightfold. `fit_temperature_gain.py` therefore pins the five BLAS thread
variables **before `numpy` is imported**, which is when the pools are sized. Any
module that imports `numpy` above it silently undoes that -- `tempgain_report.py`
carries an `isort: skip` and a comment for exactly this reason.

`plots/housekeeping/` -- the inputs, from `housekeeping_trends.py`:

| output | what it is |
|---|---|
| `housekeeping_all.png` | every float channel in `housekeeping/` over the trending period |
| `housekeeping_cooldown.png` | the MPA decay in both decon episodes, on the film clock |
| `housekeeping_intra_epoch.png` | the within-sequence gradient -- lever 4, and the ordering trap |
| `housekeeping_trend.ecsv` | long format, 26 040 rows = 176 epochs x 15 mnemonics |

## Self-tests

Both modules self-test under the credential-free gate:

```bash
.venv/bin/python fit_temperature_gain.py --self-test
.venv/bin/python tempgain_report.py
```

The physics assertions are in `fit_temperature_gain.self_test`, which injects a
known gain and a known growth rate and requires: the rate recovered to better
than 3 % (it comes back to 0.04 %), the gain curve to 3e-5, that the per-LED mode
does **not** invent chromaticity from achromatic truth, that relaxing growth to
quadratic neither invents a gain that is not there nor destroys one that is, and
that an imported gain scores like its source.

For the Sec. 5 machinery it also injects a rate that differs **per detector and per
decon** and requires: `fit_per_sca` recovers the per-detector rates to < 3 %;
the per-decon rates to 6.0 and 4.0 nm/100 h, stated separately rather than
averaged, because the two episodes have very different fringe coverage and one
blended tolerance would hide that; `fit_alternating` with a per-LED gain and a
per-detector growth recovers the rates **and does not manufacture
chromaticity**; and dispersion is recovered when injected and **not invented
when absent** -- both directions, since a term that always fires is worse than no
term.

That last pair came from a real failure. An earlier fixture gave episode 1 only
60 h, under 1 rad of phase, where rate and amplitude are not separable; the fit
returned 2.0 nm/100 h for an injected 44. The fix was to make the fixture
faithful to the real set (a 35/176 split, tau to 271 h and 202 h) rather than to
loosen the tolerance -- the assertion was right and the synthetic data was the
thing that was wrong.

`tempgain_report.self_test` is a smoke test over the figure and table paths,
including the guards that each fixed a real wrong answer: a non-finite transfer
bracket must print "UNDECIDABLE" rather than a confident "NO"; the ACM boundary
split must be by method rather than by temperature; every freedom family must be
represented in `growth_freedom_test`, or the verdict's separation test silently
degrades to saying nothing; and `film_invariance_test` on a single-episode
subset must return the not-testable form rather than raising, because the real
decon-1-only subsets go down that path. It runs the per-detector fits
**serially** on purpose -- a traceback raised inside a worker process loses its
frames, so the pool is exercised in `fit_temperature_gain.self_test` instead.

## Related

- [RCS_TREND_REFERENCE.md](RCS_TREND_REFERENCE.md) -- product formats, the
  housekeeping group, `decon_episode_bounds`
- [PD_CORRECTION.md](PD_CORRECTION.md) -- the lamp-side correction, and Sec. 3 for
  the mislabel this analysis's chromaticity test was built to avoid repeating
- [PER_DECON_NORM.md](PER_DECON_NORM.md) -- why a decon must not re-base the
  response, which is the same episode structure used here as the film clock
