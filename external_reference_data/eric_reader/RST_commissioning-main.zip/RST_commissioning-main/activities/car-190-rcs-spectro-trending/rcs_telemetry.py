"""Housekeeping: the EDP query, per-activity sampling, and the compiler's CSV.

Split out of ``process_rcs_trending.py``. The output is a pandas frame whose
column names and row semantics match ``read_per_sca.build_activity_table``
exactly, so the frozen compiler cannot tell the flight path from the TVAC one.
What differs is only the source -- one ~2500-key blob per L2 file there, one
windowed EDP query here.

:func:`build_telemetry_table` can also hand back the raw per-mnemonic series it
queried (``return_series=True``). Nothing needs that yet; it exists because the
photodiode pedestal has to be derived from the PD *time stream* rather than from
the per-activity medians, and re-querying the EDP for it would double the
requests for data already in hand.
"""
import numpy as np
import pandas as pd

import rcs_edp
import read_per_sca as rps
from rcs_activities import _as_str

# Three of the 15 HK_COLUMNS are TVAC-only mnemonic names: the EDP rejects them
# with HTTP 400 on the flight side. Maps compiler column name -> the mnemonic to
# query instead, or None where flight has no equivalent. The keys must stay
# exactly as they are: compile_rcs_trend.py reads these column names out of the
# CSV verbatim, so the columns are renamed back before sampling.
#
# UNVERIFIED, pending confirmation from the instrument team. The two
# substitutions are the ones this activity's README already records as the MPA
# and COBA temperatures, and their values over the first run are physically
# plausible (WTSM00 ~109.8 K for the MPA, WTSM04 ~169.7 K for COBA), but nothing
# in the EDP metadata names a subsystem, so the index-to-sensor assignment rests
# on that README note alone. CDHA_TCS_WTSC10P tracks WTSM04 to within a few
# tenths once converted (-103.0 C = 170.1 K), which is consistent with WTSM04
# being the same COBA sensor already in Kelvin, as the TVAC name's _K implies.
FLIGHT_MNEMONIC_ALIASES = {
    "WFI_COBA_WTSC10P_K": "WFI_MCE_ADC_WTSM04",
    "WFI_MCU_A_MPA_CSENS_FPSSEN_K": "WFI_MCE_ADC_WTSM00",
    # No B side: flight has no redundant MPA temperature. The EDP exposes the
    # MPA temperature once, off the MCE ADC rather than per-MCU, and the only
    # WFI_MCU_*_MPA_* mnemonics are heater/DAC, not CSENS. Deliberately not
    # pointed at WTSM00 as well -- that would make MPA_B_temp look like an
    # independent reading of a sensor that is only measured once.
    "WFI_MCU_B_MPA_CSENS_FPSSEN_K": None,
}


def led_select_columns(bank="BANK2"):
    """The LED-enable mnemonics for one MCE bank."""
    return rps.LED_SELECT_COLUMNS if bank == "BANK2" \
        else rps.LED_SELECT_COLUMNS_B1


def build_telemetry_table(activities, token=None, pad_minutes=5.0,
                          bank="BANK2", return_series=False):
    """Assemble the compiler's telemetry table from EDP, one row per activity.

    Column names and row semantics match ``read_per_sca.build_activity_table``
    exactly, so the compiler cannot tell the two paths apart. What differs is
    the source: one blob per file there, one windowed query here -- and, for the
    three columns in ``FLIGHT_MNEMONIC_ALIASES``, the mnemonic actually queried.

    The whole run is fetched in a single pass per mnemonic and then sampled per
    activity, rather than one query per activity, which is 21 requests instead of
    147.

    With ``return_series`` the raw ``{mnemonic: frame}`` dict is returned
    alongside the table, under the *compiler's* column names (the aliases have
    already been renamed back). Its time coverage is the run window padded by
    ``pad_minutes`` on each side, which is what makes an off-LED interval
    available before the first exposure and after the last.
    """
    led_columns = led_select_columns(bank)
    queried = [FLIGHT_MNEMONIC_ALIASES.get(column, column)
               for column in rps.HK_COLUMNS]
    mnemonics = [name for name in queried if name is not None] + led_columns

    starts = [e["start_time"] for e in activities if e["start_time"]]
    ends = [e["end_time"] or e["start_time"] for e in activities
            if e["end_time"] or e["start_time"]]
    if not starts:
        raise ValueError("no exposure start times available; cannot window the "
                         "EDP query. Check that exposure_start_time survived "
                         "the MAST query.")
    pad = pd.Timedelta(minutes=pad_minutes)
    t0 = pd.to_datetime(min(starts), utc=True).tz_localize(None) - pad
    t1 = pd.to_datetime(max(ends), utc=True).tz_localize(None) + pad

    series = rcs_edp.query_mnemonics(mnemonics, t0, t1, token=token)

    # Sample under the compiler's column names, not the queried ones. A column
    # aliased to None has no flight equivalent at all and stays absent here, so
    # sample_activities records it missing and the compiler sees NaN.
    for column, flight_mnemonic in FLIGHT_MNEMONIC_ALIASES.items():
        if flight_mnemonic is not None and flight_mnemonic in series:
            series[column] = series.pop(flight_mnemonic)

    windows = []
    for entry in activities:
        start = pd.to_datetime(entry["start_time"], utc=True).tz_localize(None)
        end = entry["end_time"] or entry["start_time"]
        windows.append((start,
                        pd.to_datetime(end, utc=True).tz_localize(None)))

    sampled, rules = rcs_edp.sample_activities(
        series, windows, rps.HK_COLUMNS, led_columns)

    rows = []
    for entry, values, rule in zip(activities, sampled, rules):
        row = {
            "SC Timestamp": entry["start_time"],
            # Reconstruct the SDH path shape so the compiler's
            # r'/(\d{19})/Science/' regex matches, as read_ql_sca also does.
            "exp_path_done": f"/{entry['staging_id']}/Science/000000001/fits",
        }
        row.update(values)

        enabled = rcs_edp.enabled_leds(values, led_columns)
        edp_led = enabled[0] if len(enabled) == 1 else (
            "DRK" if not enabled else "MULTIPLE")
        # These two are expected to *disagree*, and that is not an error. The
        # MAST/meta.rcs.led value counts LEDs in activity order, while the EDP
        # BANK2SEL enables name the hardware LED. TVAC already showed the two
        # orders differ -- activity 2 lit hardware LED6 -- and flight matches
        # TVAC exactly. Both are recorded per row; the compiler keys off CSV row
        # order, so neither is load-bearing. What *would* be an error is the EDP
        # reporting no single LED at all, which is checked after the loop.
        product_led = "DRK" if entry["is_dark"] else f"LED{_as_str(entry['led'])}"

        row.update({
            "activity_number": entry["activity_number"],
            "h5_key": entry["key"],
            "visit_id": entry["visit_id"],
            "staging_id": entry["staging_id"],
            "id_synthetic": entry["id_synthetic"],
            "exposure": entry["exposure"],
            "file_set_name": entry["file_set_name"],
            "product_led": product_led,
            "edp_led": edp_led,
            "led_agrees": edp_led == product_led,
            "is_dark": entry["is_dark"],
            "is_aux": entry.get("is_aux", False),
            "optical_element": entry.get("optical_element", ""),
            "exposure_type": entry.get("exposure_type", ""),
            "exposure_time": _as_str(entry.get("exposure_time")),
            "end_time": entry["end_time"],
            "n_sca": len(entry["frames"]),
            "scas_present": ",".join(str(s) for s in sorted(entry["frames"])),
        })
        row.update({f"rule_{name}": value for name, value in rule.items()})
        rows.append(row)

    table = pd.DataFrame(rows)
    report_led_order(table)

    if return_series:
        return table, series

    return table


def build_empty_telemetry_table(activities, bank="BANK2"):
    """The telemetry table with the mnemonic columns blank.

    For ``--skip-telemetry``: lets the mosaic half of the pipeline be exercised
    before the EDP endpoint is reachable. The resulting h5 has valid image cubes
    and NaN housekeeping scalars, which is useless for trending but fine for
    checking the geometry end to end.
    """
    led_columns = led_select_columns(bank)
    rows = []
    for entry in activities:
        row = {
            "SC Timestamp": entry["start_time"],
            "exp_path_done": f"/{entry['staging_id']}/Science/000000001/fits",
        }
        row.update({column: np.nan for column in rps.HK_COLUMNS})
        row.update({column: "DIS" for column in led_columns})
        row.update({
            "activity_number": entry["activity_number"],
            "h5_key": entry["key"],
            "visit_id": entry["visit_id"],
            "staging_id": entry["staging_id"],
            "id_synthetic": entry["id_synthetic"],
            "exposure": entry["exposure"],
            "file_set_name": entry["file_set_name"],
            "product_led": "DRK" if entry["is_dark"]
                           else f"LED{_as_str(entry['led'])}",
            "edp_led": "",
            "led_agrees": False,
            "is_dark": entry["is_dark"],
            "is_aux": entry.get("is_aux", False),
            "optical_element": entry.get("optical_element", ""),
            "exposure_type": entry.get("exposure_type", ""),
            "exposure_time": _as_str(entry.get("exposure_time")),
            "end_time": entry["end_time"],
            "n_sca": len(entry["frames"]),
            "scas_present": ",".join(str(s) for s in sorted(entry["frames"])),
        })
        rows.append(row)

    return pd.DataFrame(rows)


def report_led_order(table):
    """Print the activity-order to hardware-order LED map and check it is sane.

    The map is expected to be a shift, not the identity: in TVAC the first lit
    activity drove hardware LED6 and the rest ran 1..5, and flight reproduces
    that exactly. Printing it every run is how a *change* in the wiring or the
    activity sequence would be noticed, since neither value is load-bearing --
    the compiler names its arrays by CSV row order alone, so a silent reordering
    would not fail anything.

    Only two things are actually warned about: the EDP reporting more than one
    LED enabled during an exposure, and the six *core* lit activities not
    covering six distinct hardware LEDs. CAR-216's aux activities (obs 9,
    ``AUX_LED3FLAT1``..``4``) deliberately repeat LED3 four times, so they are
    excluded from that second check -- it would otherwise fire every CAR-216
    run for a repeat that is by design, not a wiring problem.
    """
    core = table[~table["is_aux"].astype(bool)] \
        if "is_aux" in table.columns else table
    lit = core[~core["is_dark"].astype(bool)]
    pairs = " ".join(f"{row.h5_key}->{row.edp_led}"
                     for row in table.itertuples())
    print(f"  LED map (CSV row -> EDP BANK2SEL hardware LED): {pairs}")
    print("    a shift is expected here, not the identity; TVAC's order was "
          "(dark, 6, 1, 2, 3, 4, 5) and the compiler keys off row order")

    multiple = list(lit[lit["edp_led"] == "MULTIPLE"]["h5_key"])
    if multiple:
        print(f"  WARNING: the EDP reports more than one LED enabled during "
              f"{multiple}; the flat is not a single-LED measurement")
    hardware = sorted(set(lit["edp_led"]))
    if len(hardware) != len(lit):
        print(f"  WARNING: the {len(lit)} core lit activities map onto only "
              f"{len(hardware)} distinct hardware LEDs {hardware}; expected one "
              f"each. Check the EDP window sampling before trusting this run.")


def report_pull_timing(activities, table):
    """Print per-activity and run-total MAST/S3 pull rates; add them to ``table``.

    Reads ``pull_bytes``/``pull_seconds`` off each activity dict -- set inside
    the streaming loop in ``process_rcs_trending.stage_run``, one increment per
    SCA -- rather than re-deriving them. Also writes ``pull_MB``/
    ``pull_seconds``/``pull_MBps`` columns onto ``table`` so they land in
    ``activity_table.csv`` (provenance, outside the compiler's glob, so new
    columns there are free). A ``dark_blank`` activity pulls nothing, so its
    rate is left as NaN rather than a division by zero.
    """
    print("  -- MAST/S3 pull timing, per activity (downlink of L2 products) --")
    by_number = {entry["activity_number"]: entry for entry in activities}
    mb_col, sec_col, rate_col = [], [], []
    total_bytes = 0
    total_seconds = 0.0
    for _, row in table.iterrows():
        activity = int(row["activity_number"])
        entry = by_number[activity]
        pull_bytes = entry.get("pull_bytes", 0)
        pull_seconds = entry.get("pull_seconds", 0.0)
        mb = pull_bytes / 1e6
        rate = mb / pull_seconds if pull_seconds > 0 else np.nan
        mb_col.append(mb)
        sec_col.append(pull_seconds)
        rate_col.append(rate)
        total_bytes += pull_bytes
        total_seconds += pull_seconds
        if entry.get("dark_blank"):
            print(f"    act{activity} {entry['key']:5s}  no L2 pulled (blank dark)")
        else:
            print(f"    act{activity} {entry['key']:5s}  {mb:8.1f} MB  "
                  f"{pull_seconds:6.1f} s  {rate:6.1f} MB/s")

    table["pull_MB"] = mb_col
    table["pull_seconds"] = sec_col
    table["pull_MBps"] = rate_col

    total_mb = total_bytes / 1e6
    total_rate = total_mb / total_seconds if total_seconds > 0 else np.nan
    print(f"    {'total':10s}{total_mb:8.1f} MB  {total_seconds:6.1f} s  "
          f"{total_rate:6.1f} MB/s")


# ---------------------------------------------------------------------------
# Self test
# ---------------------------------------------------------------------------

def self_test(verbose=True):
    """EDP sampling, the blank table, and the two reports; no network."""
    def say(text):
        if verbose:
            print(text)

    say("== EDP windowed sampling ==")
    frame = pd.DataFrame({
        rcs_edp.TIME_COLUMN: ["2027-03-14T06:00:00", "2027-03-14T06:05:00",
                              "2027-03-14T06:10:00"],
        rcs_edp.VALUE_COLUMN: [10.0, 20.0, 90.0]})
    value, rule = rcs_edp.sample_window(frame, "2027-03-14T05:59:00",
                                        "2027-03-14T06:06:00")
    assert (value, rule) == (15.0, rcs_edp.RULE_WINDOW), (value, rule)
    say(f"  in-window median = {value} ({rule})")

    value, rule = rcs_edp.sample_window(frame, "2027-03-14T07:00:00",
                                        "2027-03-14T07:01:00")
    assert (value, rule) == (90.0, rcs_edp.RULE_NEAREST), (value, rule)
    say(f"  empty window falls back to nearest sample = {value} ({rule})")

    enables = pd.DataFrame({
        rcs_edp.TIME_COLUMN: ["2027-03-14T06:00:00", "2027-03-14T06:01:00",
                              "2027-03-14T06:02:00"],
        rcs_edp.VALUE_COLUMN: ["ENA", "ENA", "DIS"]})
    value, rule = rcs_edp.sample_window(enables, "2027-03-14T06:00:00",
                                        "2027-03-14T06:02:00", how="mode")
    assert (value, rule) == ("ENA", rcs_edp.RULE_WINDOW), (value, rule)
    say(f"  string mode = {value!r} ({rule})")

    value, rule = rcs_edp.sample_window(None, "2027-03-14T06:00:00",
                                        "2027-03-14T06:02:00", how="mode")
    assert (value, rule) == ("", rcs_edp.RULE_MISSING)
    assert rcs_edp.compact_iso("2027-03-14T06:07:40.714") == "2027-03-14T06:07:40"
    say("  missing mnemonic and compact ISO formatting")

    say("== mnemonic aliases ==")
    # Every alias key has to be a column the compiler actually reads, or the
    # rename back is a no-op and the queried mnemonic's values are dropped.
    for column in FLIGHT_MNEMONIC_ALIASES:
        assert column in rps.HK_COLUMNS, column
    assert len(led_select_columns("BANK2")) == 6
    assert led_select_columns("BANK1") == rps.LED_SELECT_COLUMNS_B1
    say(f"  {len(FLIGHT_MNEMONIC_ALIASES)} aliases all name real HK_COLUMNS; "
        f"6 LED-select mnemonics per bank")

    say("== blank telemetry table ==")
    blank_activities = [
        {"activity_number": n + 1, "key": key, "visit_id": "0" * 19,
         "staging_id": f"{'0' * 15}{n + 1:04d}", "id_synthetic": True,
         "exposure": n + 1, "file_set_name": "", "led": "" if n == 0 else str(n),
         "is_dark": n == 0, "start_time": "2027-03-14T06:00:00",
         "end_time": "2027-03-14T06:02:00", "frames": {s: "" for s in range(1, 19)}}
        for n, key in enumerate(["DARK", "LED1", "LED2"])]
    blank = build_empty_telemetry_table(blank_activities)
    assert len(blank) == 3
    assert blank["n_sca"].tolist() == [18, 18, 18]
    assert all(np.isnan(blank[column]).all() for column in rps.HK_COLUMNS)
    assert (blank[rps.LED_SELECT_COLUMNS] == "DIS").all().all()
    assert blank["product_led"].tolist() == ["DRK", "LED1", "LED2"]
    say("  housekeeping NaN, enables DIS, product_led from the led value")

    say("== LED order report ==")
    # The real flight/TVAC map: the first lit activity drives hardware LED6.
    ordered = pd.DataFrame([
        {"h5_key": key, "edp_led": hardware, "is_dark": key == "DARK",
         "is_aux": False}
        for key, hardware in zip(["DARK"] + [f"LED{n}" for n in range(1, 7)],
                                 ["DRK", "LED6", "LED1", "LED2", "LED3",
                                  "LED4", "LED5"])])
    report_led_order(ordered)
    say("  the expected (dark, 6, 1, 2, 3, 4, 5) map passes without a warning")

    say("== pull timing ==")
    pull_activities = [
        {"activity_number": 1, "key": "DARK", "dark_blank": True},
        {"activity_number": 2, "key": "LED1", "pull_bytes": 200_000_000,
         "pull_seconds": 5.0},
        {"activity_number": 3, "key": "LED2", "pull_bytes": 100_000_000,
         "pull_seconds": 2.0},
    ]
    pull_table = pd.DataFrame([{"activity_number": e["activity_number"]}
                               for e in pull_activities])
    report_pull_timing(pull_activities, pull_table)
    assert list(pull_table["pull_MB"]) == [0.0, 200.0, 100.0]
    assert list(pull_table["pull_seconds"]) == [0.0, 5.0, 2.0]
    assert np.isnan(pull_table["pull_MBps"].iloc[0])
    assert pull_table["pull_MBps"].iloc[1] == 40.0
    assert pull_table["pull_MBps"].iloc[2] == 50.0
    say("  per-activity MB/seconds/MB-per-s columns computed, blank dark is NaN")

    return True


if __name__ == "__main__":
    print("rcs_telemetry self test")
    self_test()
    print("all checks passed")
