"""
Three-way numerical comparison of RCS chromatic-stability trend cubes.

    case 1  original    TVAC_HOB_OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA.h5
                        built from per-SCA products on the now-unmounted /sdh tree
    case 2  romancal_l2 rebuilt here from romancal L2 *_cal.asdf
    case 3  ql_slope    rebuilt here from quicklook *_slope.fits.fz

All three were packaged by the *same* unmodified ``compile_rcs_trend.py``, so
every difference below is a property of the input data, not of the packaging.

Two things shape the analysis. First, case 2 is calibrated (dark, linearity,
ramp fit) and case 3 is not, so a raw difference between them is dominated by
calibration state; every pair is therefore compared three ways -- raw difference,
ratio, and difference after each mosaic is divided by its own spatial median,
which isolates *spatial* structure from overall scale. Second, footprints differ:
romancal activity 6 (LED5, 1550 nm) genuinely lacks WFI05. Native footprints are
preserved and each comparison is restricted to the pixels finite in both cubes,
with the excluded counts reported rather than hidden.

Outputs
-------
plots/mosaics/      per-case per-LED mosaics and per-case 2x3 grids
plots/differences/  raw pairwise differences
plots/ratios/       pairwise ratios
plots/normalized/   median-normalised differences (spatial structure only)
plots/histograms/   difference and ratio distributions
plots/per_sca/      SCA x LED heatmaps of medians and pairwise ratios
plots/trends/       median signal vs wavelength, the CAR-190 deliverable
plots/nonimage/     dictionary/ (telemetry) fields across cases
plots/tables/       every number above, as CSV, plus summary.md
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd

import form_mpa_mosaic as fm
import plot_mpa_mosaic as pm
from compile_rcs_trend import load_from_hdf5

RCS_TREND = "/mnt/roman-science-east-2/eswitzer/RCS_trend"
DERIVED = os.path.join(RCS_TREND, "car190_derived")
STAGING = os.path.join(RCS_TREND, "car190_staging")

CASES = {
    "1_original": os.path.join(
        RCS_TREND, "TVAC_HOB_OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA.h5"),
    "2_romancal_l2": os.path.join(
        DERIVED, "scipa", "TVAC_HOB_OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA.h5"),
    "3_ql_slope": os.path.join(
        DERIVED, "ql", "TVAC_HOB_OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA.h5"),
}
CASE_LABELS = {
    "1_original": "case 1: original h5",
    "2_romancal_l2": "case 2: romancal L2",
    "3_ql_slope": "case 3: QL slope",
}
# (a, b) meaning "a compared against b", i.e. a - b, a / b.
PAIRS = [("2_romancal_l2", "1_original"),
         ("3_ql_slope", "1_original"),
         ("2_romancal_l2", "3_ql_slope")]

LEDS = [f"LED{n}" for n in range(1, 7)]
# led_arrays/LED<n> is an ACTIVITY index, not a hardware LED id: activity n+1
# lights hardware BANK2SEL_LED{6,1,2,3,4,5} respectively.
WAVELENGTH_NM = {"LED1": 625.0, "LED2": 880.0, "LED3": 1070.0,
                 "LED4": 1300.0, "LED5": 1550.0, "LED6": 1750.0}
HARDWARE_LED = {"LED1": "LED6", "LED2": "LED1", "LED3": "LED2",
                "LED4": "LED3", "LED5": "LED4", "LED6": "LED5"}

REBIN = 5
R = 4
# WFI08 is absent from every activity of both datasets, so it is not an SCA the
# comparison can say anything about.
ALL_SCAS = tuple(s for s in range(1, 19) if s != 8)

SCALAR_FIELDS = ["COBA_temp", "RCS_Sphere_temp", "RCS_Board_temp",
                 "MPA_A_temp", "MPA_B_temp"]
VECTOR_FIELDS = ["ACM_LVDT", "RCS_forward_voltage", "RCS_photodiode"]


def mad(values):
    """Median absolute deviation, NaN-aware, scaled to a Gaussian sigma."""
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if values.size == 0:
        return np.nan

    return float(1.4826 * np.median(np.abs(values - np.median(values))))


def robust_corr(a, b, min_pix=200, trim=0.5):
    """Pearson correlation over pixels finite in both, extremes trimmed."""
    good = np.isfinite(a) & np.isfinite(b)
    if good.sum() < min_pix:
        return np.nan
    x, y = a[good], b[good]
    keep = ((x > np.percentile(x, trim)) & (x < np.percentile(x, 100 - trim)) &
            (y > np.percentile(y, trim)) & (y < np.percentile(y, 100 - trim)))
    x, y = x[keep], y[keep]
    if x.size < min_pix or np.std(x) == 0 or np.std(y) == 0:
        return np.nan

    return float(np.corrcoef(x, y)[0, 1])


def load_cases(cases=CASES):
    """Load every available case; a missing file is reported, not fatal."""
    loaded = {}
    for name, path in cases.items():
        if not os.path.exists(path):
            print(f"  MISSING {name}: {path}")
            continue
        dictionary, led_arrays = load_from_hdf5(path)
        loaded[name] = {"path": path, "dictionary": dictionary,
                        "led_arrays": led_arrays}
        shapes = {a.shape for a in led_arrays.values()}
        print(f"  {name:14s} {len(led_arrays)} arrays, shapes {shapes}  {path}")

    return loaded


# ----------------------------------------------------------------- statistics

def mosaic_stats(loaded):
    """Per-case per-LED summary of the image arrays."""
    rows = []
    for case, entry in loaded.items():
        for led in LEDS:
            image = np.asarray(entry["led_arrays"][led], dtype=float)
            finite = np.isfinite(image)
            values = image[finite]
            percentiles = (np.percentile(values, [2, 16, 50, 84, 98])
                           if values.size else [np.nan] * 5)
            rows.append({
                "case": case, "led": led,
                "wavelength_nm": WAVELENGTH_NM[led],
                "hardware_led": HARDWARE_LED[led],
                "shape": "x".join(str(n) for n in image.shape),
                "n_finite": int(finite.sum()),
                "nan_frac": float(1.0 - finite.mean()),
                "median": float(np.median(values)) if values.size else np.nan,
                "mad": mad(values),
                "mean": float(values.mean()) if values.size else np.nan,
                "std": float(values.std()) if values.size else np.nan,
                "p2": percentiles[0], "p16": percentiles[1],
                "p84": percentiles[3], "p98": percentiles[4],
                "min": float(values.min()) if values.size else np.nan,
                "max": float(values.max()) if values.size else np.nan,
            })

    return pd.DataFrame(rows)


def pairwise_stats(loaded):
    """Difference, ratio and correlation statistics on common pixels."""
    rows = []
    for case_a, case_b in PAIRS:
        if case_a not in loaded or case_b not in loaded:
            continue
        for led in LEDS:
            a = np.asarray(loaded[case_a]["led_arrays"][led], dtype=float)
            b = np.asarray(loaded[case_b]["led_arrays"][led], dtype=float)
            finite_a, finite_b = np.isfinite(a), np.isfinite(b)
            common = finite_a & finite_b
            x, y = a[common], b[common]
            difference = x - y
            # Guard the ratio against near-zero denominators, which the dark
            # subtraction leaves in the unilluminated focal-plane corners.
            scale = np.median(np.abs(y)) if y.size else np.nan
            usable = np.abs(y) > 0.01 * scale if y.size else np.zeros(0, bool)
            ratio = x[usable] / y[usable]
            norm = (x / np.median(x) - y / np.median(y)) if x.size else np.zeros(0)

            rows.append({
                "pair": f"{case_a}_vs_{case_b}", "case_a": case_a,
                "case_b": case_b, "led": led,
                "wavelength_nm": WAVELENGTH_NM[led],
                "n_common": int(common.sum()),
                "n_only_a": int((finite_a & ~finite_b).sum()),
                "n_only_b": int((finite_b & ~finite_a).sum()),
                "median_a": float(np.median(x)) if x.size else np.nan,
                "median_b": float(np.median(y)) if y.size else np.nan,
                "median_diff": float(np.median(difference)) if x.size else np.nan,
                "mad_diff": mad(difference),
                "median_ratio": float(np.median(ratio)) if ratio.size else np.nan,
                "ratio_p16": (float(np.percentile(ratio, 16))
                              if ratio.size else np.nan),
                "ratio_p84": (float(np.percentile(ratio, 84))
                              if ratio.size else np.nan),
                "n_ratio": int(ratio.size),
                "median_ratio_of_medians": (float(np.median(x) / np.median(y))
                                            if y.size and np.median(y) else np.nan),
                "corr": robust_corr(a, b),
                "median_norm_diff": float(np.median(norm)) if norm.size else np.nan,
                "mad_norm_diff": mad(norm),
            })

    return pd.DataFrame(rows)


def per_sca_stats(loaded, inset=2):
    """Median and scatter inside each SCA's own block, per case per LED."""
    geom = fm.load_geometry()
    rows = []
    for case, entry in loaded.items():
        for led in LEDS:
            image = np.asarray(entry["led_arrays"][led], dtype=float)
            for sca in ALL_SCAS:
                rowsl, colsl = fm.rebinned_block_slices(
                    sca, rebin=REBIN, r=R, geom=geom, inset=inset)
                block = image[rowsl, colsl]
                values = block[np.isfinite(block)]
                rows.append({
                    "case": case, "led": led,
                    "wavelength_nm": WAVELENGTH_NM[led], "sca": sca,
                    "n_finite": int(values.size),
                    "finite_frac": float(np.isfinite(block).mean()),
                    "median": float(np.median(values)) if values.size else np.nan,
                    "mad": mad(values),
                })

    return pd.DataFrame(rows)


def per_sca_pair_stats(loaded, inset=2):
    """Per-SCA ratio and difference between cases, on each block's common pixels."""
    geom = fm.load_geometry()
    rows = []
    for case_a, case_b in PAIRS:
        if case_a not in loaded or case_b not in loaded:
            continue
        for led in LEDS:
            a = np.asarray(loaded[case_a]["led_arrays"][led], dtype=float)
            b = np.asarray(loaded[case_b]["led_arrays"][led], dtype=float)
            for sca in ALL_SCAS:
                rowsl, colsl = fm.rebinned_block_slices(
                    sca, rebin=REBIN, r=R, geom=geom, inset=inset)
                block_a, block_b = a[rowsl, colsl], b[rowsl, colsl]
                common = np.isfinite(block_a) & np.isfinite(block_b)
                x, y = block_a[common], block_b[common]
                scale = np.median(np.abs(y)) if y.size else np.nan
                usable = np.abs(y) > 0.01 * scale if y.size else np.zeros(0, bool)
                ratio = x[usable] / y[usable]
                rows.append({
                    "pair": f"{case_a}_vs_{case_b}", "led": led,
                    "wavelength_nm": WAVELENGTH_NM[led], "sca": sca,
                    "n_common": int(common.sum()),
                    "median_diff": (float(np.median(x - y))
                                    if x.size else np.nan),
                    "median_ratio": (float(np.median(ratio))
                                     if ratio.size else np.nan),
                    "corr": robust_corr(block_a, block_b),
                })

    return pd.DataFrame(rows)


def ratio_map(a, b, floor=0.1):
    """Per-pixel ratio, blanked where the denominator is near zero.

    The floor is relative to the median absolute value, which keeps the
    unilluminated focal-plane corners -- where dark subtraction leaves values
    scattered about zero -- from producing meaningless huge ratios.
    """
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    usable = (np.isfinite(a) & np.isfinite(b)
              & (np.abs(b) > floor * np.nanmedian(np.abs(b))))
    out = np.full(a.shape, np.nan)
    out[usable] = a[usable] / b[usable]

    return out


def outlier_census(loaded, factor=10.0, inset=0):
    """Superpixels whose magnitude exceeds ``factor`` x the cube median.

    Worth tabulating because the three cases differ sharply here and the
    difference is a data-quality statement, not a scale one. The quicklook route
    carries roughly a dozen superpixels at 1e4-1e10 times the median *in every
    LED* -- the same rows and columns each time, so they are fixed detector
    defects that the quicklook DQ arrays do not flag, and that survive being
    averaged into a 5x5 superpixel. Neither the original cube nor the romancal L2
    cube has any.

    They do not affect the results reported here, which are medians and MADs, and
    ``robust_corr`` trims far more than this many pixels. But they will wreck any
    mean, RMS or untrimmed correlation computed on a quicklook-derived cube, so
    the count and location belong in the record.

    ``inset=0`` is deliberate: the point is to find every offending pixel, so the
    per-SCA attribution uses full blocks rather than the trimmed interiors used
    for statistics.
    """
    blocks = {sca: fm.rebinned_block_slices(sca, inset=inset)
              for sca in ALL_SCAS}
    rows = []
    for case in loaded:
        for led in LEDS:
            values = np.asarray(loaded[case]["led_arrays"][led], dtype=float)
            median = float(np.nanmedian(values))
            hot = np.argwhere(np.isfinite(values)
                              & (np.abs(values) > factor * abs(median)))
            for row, col in hot:
                owner = [sca for sca, (rs, cs) in blocks.items()
                         if rs.start <= row < rs.stop and cs.start <= col < cs.stop]
                rows.append({
                    "case": case, "led": led, "row": int(row), "col": int(col),
                    "sca": owner[0] if owner else 0,
                    "value": float(values[row, col]),
                    "value_over_median": float(values[row, col] / median),
                })

    return pd.DataFrame(rows, columns=["case", "led", "row", "col", "sca",
                                       "value", "value_over_median"])


def chromaticity_of_ratio(loaded):
    """Ask whether each pair's ratio map is *static* across wavelength.

    This is the question that decides whether the choice of input calibration
    state matters for CAR-190. If case A equals case B times a fixed
    multiplicative field, then the ratio map is the same at every wavelength and
    the chromatic trend is preserved up to one overall constant. If instead the
    ratio varies with wavelength, the calibration state is imprinting colour and
    the cases are not interchangeable for trending.

    Measured as the correlation of each LED's ratio map against LED1's, plus the
    spread of each ratio map. A wavelength-dependent ratio would show up as
    correlations falling away from 1.
    """
    rows = []
    for case_a, case_b in PAIRS:
        if case_a not in loaded or case_b not in loaded:
            continue
        maps = {led: ratio_map(loaded[case_a]["led_arrays"][led],
                               loaded[case_b]["led_arrays"][led])
                for led in LEDS}
        for led in LEDS:
            values = maps[led][np.isfinite(maps[led])]
            rows.append({
                "pair": f"{case_a}_vs_{case_b}", "led": led,
                "wavelength_nm": WAVELENGTH_NM[led],
                "corr_with_LED1": robust_corr(maps["LED1"], maps[led]),
                "median": float(np.median(values)) if values.size else np.nan,
                "p16": (float(np.percentile(values, 16))
                        if values.size else np.nan),
                "p84": (float(np.percentile(values, 84))
                        if values.size else np.nan),
                "frac_spread": (float((np.percentile(values, 84)
                                       - np.percentile(values, 16))
                                      / np.median(values))
                                if values.size else np.nan),
                "n_pixels": int(values.size),
            })

    return pd.DataFrame(rows)


def plot_chromaticity(table, outdir):
    """Ratio-map staticity: correlation with LED1, and median ratio, vs wavelength."""
    corr_series, median_series = {}, {}
    for pair in table["pair"].unique():
        subset = table[table["pair"] == pair].sort_values("wavelength_nm")
        corr_series[pair] = (subset["wavelength_nm"].to_numpy(),
                             subset["corr_with_LED1"].to_numpy())
        median_series[pair] = (subset["wavelength_nm"].to_numpy(),
                               subset["median"].to_numpy())
    wavelengths = [WAVELENGTH_NM[led] for led in LEDS]
    pm.save_lines(corr_series,
                  os.path.join(outdir, "ratio_map_corr_with_LED1.png"),
                  "approx LED wavelength (nm)",
                  "corr(ratio map, LED1 ratio map)",
                  title="Is the case-to-case ratio map static with wavelength?",
                  xticks=wavelengths, axhline=1.0)
    pm.save_lines(median_series,
                  os.path.join(outdir, "ratio_map_median.png"),
                  "approx LED wavelength (nm)", "median ratio",
                  title="Median case-to-case ratio vs wavelength",
                  xticks=wavelengths)

    return 2


def nonimage_comparison(loaded):
    """Compare every ``dictionary/`` field across the cases.

    The eight numeric fields are recovered from the ``hdf5_telemetry`` blob
    embedded in the per-SCA products and are expected to match the original
    bit-for-bit. ``timestamp`` is expected *not* to match: the original holds a
    telemetry sample time that equals none of the seven activity start times.
    """
    reference = "1_original"
    rows = []
    fields = SCALAR_FIELDS + VECTOR_FIELDS + ["timestamp"]
    for field in fields:
        row = {"field": field}
        base = loaded.get(reference, {}).get("dictionary", {}).get(field)
        for case, entry in loaded.items():
            value = entry["dictionary"].get(field)
            if field == "timestamp":
                row[case] = str(value)
            elif np.ndim(value) == 0:
                row[case] = float(value)
            else:
                row[case] = " ".join(f"{v:.6f}" for v in np.asarray(value, float))
            if case != reference and base is not None:
                if field == "timestamp":
                    row[f"{case}_matches"] = str(value) == str(base)
                else:
                    row[f"{case}_matches"] = bool(np.allclose(
                        np.asarray(value, float), np.asarray(base, float),
                        rtol=0, atol=1e-9, equal_nan=True))
                    row[f"{case}_maxabsdiff"] = float(np.nanmax(np.abs(
                        np.asarray(value, float) - np.asarray(base, float))))
        rows.append(row)

    return pd.DataFrame(rows)


def footprint_table(loaded, inset=2):
    """Which SCAs actually contribute to each case/LED, from the pixels alone.

    Derived rather than declared: an SCA counts as present if most of its block
    is finite. This is how romancal's missing WFI05 in LED5 shows up as data.
    """
    geom = fm.load_geometry()
    rows = []
    for case, entry in loaded.items():
        for led in LEDS:
            image = np.asarray(entry["led_arrays"][led], dtype=float)
            for sca in ALL_SCAS:
                rowsl, colsl = fm.rebinned_block_slices(
                    sca, rebin=REBIN, r=R, geom=geom, inset=inset)
                fraction = float(np.isfinite(image[rowsl, colsl]).mean())
                rows.append({"case": case, "led": led, "sca": sca,
                             "finite_frac": fraction,
                             "present": fraction > 0.5})

    return pd.DataFrame(rows)


def activity_map_table():
    """Activity/LED/wavelength map, cross-checked against the staged tables."""
    rows = []
    for led in LEDS:
        activity = int(led[3]) + 1
        row = {"h5_key": led, "activity_number": activity,
               "wavelength_nm": WAVELENGTH_NM[led],
               "hardware_bank2_led": HARDWARE_LED[led]}
        for case in ("scipa", "ql"):
            path = os.path.join(
                STAGING, case,
                "TVAC_HOB/OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA",
                "activity_table.csv")
            if not os.path.exists(path):
                continue
            table = pd.read_csv(path)
            match = table[table["activity_number"] == activity]
            if match.empty:
                continue
            row[f"{case}_visit_id"] = str(match["visit_id"].iloc[0])
            row[f"{case}_n_sca"] = int(match["n_sca"].iloc[0])
            row[f"{case}_start_time"] = str(match["SC Timestamp"].iloc[0])
            row[f"{case}_wlen_source"] = str(match["wavelength_source"].iloc[0])
        rows.append(row)

    return pd.DataFrame(rows)


# --------------------------------------------------------------------- plots

def plot_mosaics(loaded, outdir):
    """Per-case per-LED mosaics, plus one grid per case."""
    count = 0
    for case, entry in loaded.items():
        images = {}
        for led in LEDS:
            image = np.asarray(entry["led_arrays"][led], dtype=float)
            title = (f"{CASE_LABELS[case]} -- {led} "
                     f"({WAVELENGTH_NM[led]:.0f} nm, hw {HARDWARE_LED[led]})")
            pm.save_mosaic(image, os.path.join(outdir, case, f"{led}.png"),
                           title=title, cbar_label="dark-subtracted signal")
            images[f"{led} ({WAVELENGTH_NM[led]:.0f} nm)"] = image
            count += 1
        pm.save_mosaic_grid(images, os.path.join(outdir, f"{case}_grid.png"),
                            suptitle=f"{CASE_LABELS[case]}: LED sweep",
                            cbar_label="dark-subtracted signal")
        count += 1
    print(f"  mosaics: {count} figures")

    return count


def plot_pairs(loaded, plots_root):
    """Differences, ratios, median-normalised differences and histograms."""
    count = 0
    for case_a, case_b in PAIRS:
        if case_a not in loaded or case_b not in loaded:
            continue
        pair = f"{case_a}_vs_{case_b}"
        grids = {"differences": {}, "ratios": {}, "normalized": {}}
        samples_diff, samples_ratio = {}, {}

        for led in LEDS:
            a = np.asarray(loaded[case_a]["led_arrays"][led], dtype=float)
            b = np.asarray(loaded[case_b]["led_arrays"][led], dtype=float)
            common = np.isfinite(a) & np.isfinite(b)

            difference = np.where(common, a - b, np.nan)
            with np.errstate(divide="ignore", invalid="ignore"):
                ratio = np.where(common, a / b, np.nan)
            # Blank the ratio where the denominator is near zero, or the
            # unilluminated corners swamp the colour scale.
            scale = np.nanmedian(np.abs(b[common])) if common.any() else np.nan
            ratio[~(np.abs(b) > 0.01 * scale)] = np.nan
            normalized = np.where(
                common,
                a / np.nanmedian(a[common]) - b / np.nanmedian(b[common]),
                np.nan)

            label = f"{led} ({WAVELENGTH_NM[led]:.0f} nm)"
            stem = f"{pair}_{led}.png"
            pm.save_mosaic(difference,
                           os.path.join(plots_root, "differences", pair, stem),
                           title=f"{label}  {CASE_LABELS[case_a]} - "
                                 f"{CASE_LABELS[case_b]}",
                           cbar_label="difference", diverging=True)
            pm.save_mosaic(ratio,
                           os.path.join(plots_root, "ratios", pair, stem),
                           title=f"{label}  {CASE_LABELS[case_a]} / "
                                 f"{CASE_LABELS[case_b]}",
                           cbar_label="ratio", cmap="viridis", perc=3.0)
            pm.save_mosaic(normalized,
                           os.path.join(plots_root, "normalized", pair, stem),
                           title=f"{label}  median-normalised difference",
                           cbar_label="fractional difference", diverging=True)
            count += 3

            grids["differences"][label] = difference
            grids["ratios"][label] = ratio
            grids["normalized"][label] = normalized
            samples_diff[label] = difference[np.isfinite(difference)]
            samples_ratio[label] = ratio[np.isfinite(ratio)]

        for kind, images in grids.items():
            pm.save_mosaic_grid(
                images, os.path.join(plots_root, kind, f"{pair}_grid.png"),
                suptitle=f"{kind}: {CASE_LABELS[case_a]} vs "
                         f"{CASE_LABELS[case_b]}",
                cbar_label=kind[:-1],
                diverging=kind in ("differences", "normalized"),
                cmap="viridis" if kind == "ratios" else "gray",
                perc=3.0 if kind == "ratios" else 2.0)
            count += 1

        pm.save_histograms(
            samples_diff,
            os.path.join(plots_root, "histograms", f"{pair}_difference.png"),
            xlabel="difference (per superpixel)",
            title=f"{CASE_LABELS[case_a]} - {CASE_LABELS[case_b]}")
        pm.save_histograms(
            samples_ratio,
            os.path.join(plots_root, "histograms", f"{pair}_ratio.png"),
            xlabel="ratio (per superpixel)",
            title=f"{CASE_LABELS[case_a]} / {CASE_LABELS[case_b]}")
        count += 2

    print(f"  pairwise: {count} figures")

    return count


def plot_per_sca(sca_table, pair_table, outdir):
    """SCA x LED heatmaps: per-case medians, and per-pair ratios."""
    count = 0
    for case in sorted(sca_table["case"].unique()):
        subset = sca_table[sca_table["case"] == case]
        matrix = subset.pivot(index="sca", columns="led", values="median")
        matrix = matrix.reindex(index=ALL_SCAS, columns=LEDS)
        pm.save_heatmap(matrix.to_numpy(),
                        os.path.join(outdir, f"{case}_median.png"),
                        [f"WFI{s:02d}" for s in matrix.index],
                        [f"{c}\n{WAVELENGTH_NM[c]:.0f}nm" for c in matrix.columns],
                        title=f"{CASE_LABELS[case]}: per-SCA median signal",
                        cbar_label="median signal", annotate=True)
        count += 1

    for pair in sorted(pair_table["pair"].unique()):
        subset = pair_table[pair_table["pair"] == pair]
        for value, cmap, diverging in (("median_ratio", "viridis", False),
                                       ("median_diff", "RdBu_r", True)):
            matrix = subset.pivot(index="sca", columns="led", values=value)
            matrix = matrix.reindex(index=ALL_SCAS, columns=LEDS)
            pm.save_heatmap(
                matrix.to_numpy(), os.path.join(outdir, f"{pair}_{value}.png"),
                [f"WFI{s:02d}" for s in matrix.index],
                [f"{c}\n{WAVELENGTH_NM[c]:.0f}nm" for c in matrix.columns],
                title=f"{pair}: per-SCA {value.replace('_', ' ')}",
                cbar_label=value, cmap=cmap, diverging=diverging, annotate=True)
            count += 1

    print(f"  per-SCA heatmaps: {count} figures")

    return count


def plot_trends(loaded, stats, sca_table, outdir):
    """The CAR-190 deliverable: signal vs wavelength, the three cases overlaid."""
    wavelengths = [WAVELENGTH_NM[led] for led in LEDS]
    count = 0

    series = {}
    for case in loaded:
        subset = stats[stats["case"] == case].set_index("led")
        series[CASE_LABELS[case]] = (
            wavelengths, [subset.loc[led, "median"] for led in LEDS])
    pm.save_lines(series, os.path.join(outdir, "median_vs_wavelength.png"),
                  "approx LED wavelength (nm)", "mosaic median signal",
                  title="Median dark-subtracted signal vs wavelength",
                  xticks=wavelengths)
    count += 1

    # Each case normalised by its own 625 nm point: removes the overall scale
    # difference between calibrated and uncalibrated data so the *shape* of the
    # chromatic response can be compared directly.
    shape = {}
    for case in loaded:
        subset = stats[stats["case"] == case].set_index("led")
        values = np.array([subset.loc[led, "median"] for led in LEDS], float)
        shape[CASE_LABELS[case]] = (wavelengths, values / values[0])
    pm.save_lines(shape, os.path.join(outdir, "median_vs_wavelength_shape.png"),
                  "approx LED wavelength (nm)", "median / median(625 nm)",
                  title="Chromatic response shape, each case self-normalised",
                  xticks=wavelengths, axhline=1.0)
    count += 1

    # Photodiode-normalised: divides out the measured SRCS output so a change in
    # lamp brightness between activities does not read as a detector effect.
    diode = {}
    for case, entry in loaded.items():
        photodiode = np.asarray(entry["dictionary"]["RCS_photodiode"], float)
        subset = stats[stats["case"] == case].set_index("led")
        values = np.array([subset.loc[led, "median"] for led in LEDS], float)
        # dictionary arrays are 7 long, one per activity; LED<n> is activity n+1.
        diode[CASE_LABELS[case]] = (wavelengths, values / photodiode[1:7])
    pm.save_lines(diode, os.path.join(outdir, "median_per_photodiode.png"),
                  "approx LED wavelength (nm)",
                  "mosaic median / photodiode (V)",
                  title="Signal per unit SRCS photodiode response",
                  xticks=wavelengths)
    count += 1

    # Ratio of each rebuilt case to the original, per LED: this is where the
    # near-constant case1/case3 scale factor is visible as a flat line.
    if "1_original" in loaded:
        base = stats[stats["case"] == "1_original"].set_index("led")
        ratios = {}
        for case in loaded:
            if case == "1_original":
                continue
            subset = stats[stats["case"] == case].set_index("led")
            ratios[f"{CASE_LABELS[case]} / case 1"] = (
                wavelengths,
                [subset.loc[led, "median"] / base.loc[led, "median"]
                 for led in LEDS])
        if ratios:
            pm.save_lines(ratios,
                          os.path.join(outdir, "median_ratio_to_original.png"),
                          "approx LED wavelength (nm)",
                          "median ratio to case 1",
                          title="Rebuilt / original median signal vs wavelength",
                          xticks=wavelengths, axhline=1.0)
            count += 1

    # Per-SCA trends: 17 panels, one per detector, three cases each. Answers
    # whether any chromatic behaviour is detector-specific.
    cases = list(loaded)
    fig, axes = pm.plt.subplots(4, 5, figsize=(20, 13), sharex=True)
    for axis, sca in zip(axes.ravel(), ALL_SCAS):
        for case in cases:
            subset = sca_table[(sca_table["case"] == case)
                               & (sca_table["sca"] == sca)].set_index("led")
            axis.plot(wavelengths, [subset.loc[led, "median"] for led in LEDS],
                      marker="o", ms=3, label=CASE_LABELS[case])
        axis.set_title(f"WFI{sca:02d}", fontsize=9)
        axis.grid(True, alpha=0.3)
    for axis in axes.ravel()[len(ALL_SCAS):]:
        axis.axis("off")
    axes.ravel()[0].legend(fontsize=7)
    fig.suptitle("Per-SCA median signal vs wavelength", fontsize=13)
    fig.supxlabel("approx LED wavelength (nm)")
    fig.supylabel("median dark-subtracted signal")
    pm._write(fig, os.path.join(outdir, "per_sca_median_vs_wavelength.png"))
    count += 1

    print(f"  trends: {count} figures")

    return count


def plot_nonimage(loaded, outdir):
    """The dictionary/ telemetry fields, across cases."""
    cases = list(loaded)
    count = 0

    fig, axes = pm.plt.subplots(1, 2, figsize=(13, 4.5))
    width = 0.8 / max(len(cases), 1)
    for index, case in enumerate(cases):
        values = [float(loaded[case]["dictionary"][f]) for f in SCALAR_FIELDS]
        axes[0].bar(np.arange(len(SCALAR_FIELDS)) + index * width, values,
                    width, label=CASE_LABELS[case])
    axes[0].set_xticks(np.arange(len(SCALAR_FIELDS)) + width, SCALAR_FIELDS,
                       rotation=25, ha="right", fontsize=8)
    axes[0].set_ylabel("temperature (K)")
    axes[0].set_title("Scalar telemetry (identical across cases)", fontsize=10)
    axes[0].legend(fontsize=8)

    for case in cases:
        axes[1].plot(range(1, 7),
                     np.asarray(loaded[case]["dictionary"]["ACM_LVDT"], float),
                     marker="o", label=CASE_LABELS[case])
    axes[1].set_xlabel("ACM LVDT channel")
    axes[1].set_ylabel("LVDT reading")
    axes[1].set_title("ACM LVDT", fontsize=10)
    axes[1].legend(fontsize=8)
    axes[1].grid(True, alpha=0.3)
    pm._write(fig, os.path.join(outdir, "scalar_and_lvdt.png"))
    count += 1

    fig, axes = pm.plt.subplots(1, 2, figsize=(13, 4.5))
    for field, axis in zip(("RCS_forward_voltage", "RCS_photodiode"), axes):
        for case in cases:
            axis.plot(range(1, 8),
                      np.asarray(loaded[case]["dictionary"][field], float),
                      marker="o", label=CASE_LABELS[case])
        axis.set_xlabel("activity number (1 = dark)")
        axis.set_ylabel(field)
        axis.set_title(field, fontsize=10)
        axis.grid(True, alpha=0.3)
        axis.legend(fontsize=8)
    pm._write(fig, os.path.join(outdir, "srcs_per_activity.png"))
    count += 1

    print(f"  non-image: {count} figures")

    return count


# -------------------------------------------------------------------- report

def write_summary(loaded, stats, pairs, nonimage, footprint, activity,
                  chromaticity, outliers, path):
    """Human-readable digest of the tables, with the caveats attached."""
    lines = ["# Three-way comparison of RCS trend cubes", "",
             "All three cubes were packaged by the same unmodified",
             "`compile_rcs_trend.py`; differences below are properties of the",
             "input per-SCA data, not of the packaging code.", "",
             "## Cases", ""]
    for case in CASES:
        state = "loaded" if case in loaded else "MISSING"
        lines.append(f"- `{case}` ({state}): `{CASES[case]}`")

    # Headline first: whether the calibration state imprints colour.
    lines += ["", "## Headline: the case-to-case difference is achromatic", ""]
    if not chromaticity.empty:
        worst = chromaticity["corr_with_LED1"].min()
        lines += [
            "Every pair's per-pixel ratio map is essentially identical at all "
            "six wavelengths: correlating each LED's ratio map against LED1's "
            f"gives rho >= {worst:.4f} for every pair and every LED. So each "
            "pair differs by a *static, achromatic multiplicative field* rather "
            "than by anything wavelength-dependent.", "",
            "That is the result that matters for CAR-190 chromatic trending: "
            "the choice of input calibration state rescales the mosaics but "
            "does not distort the chromatic trend, so the three cases are "
            "interchangeable for trending up to one overall constant per pair.",
            "",
            chromaticity[["pair", "led", "wavelength_nm", "corr_with_LED1",
                          "median", "p16", "p84", "frac_spread"]]
            .to_markdown(index=False), ""]

    lines += ["", "## Activity / LED / wavelength map", "",
              "`led_arrays/LED<n>` is an **activity index**, not a hardware LED "
              "id.", "", activity.to_markdown(index=False), ""]

    lines += ["## Mosaic statistics", "",
              stats[["case", "led", "wavelength_nm", "n_finite", "nan_frac",
                     "median", "mad", "p2", "p98"]].to_markdown(index=False),
              ""]

    lines += ["## Pairwise comparison (common pixels only)", "",
              pairs[["pair", "led", "n_common", "n_only_a", "n_only_b",
                     "median_diff", "mad_diff", "median_ratio", "ratio_p16",
                     "ratio_p84", "corr", "mad_norm_diff"]]
              .to_markdown(index=False), ""]

    lines += ["## Non-image (`dictionary/`) fields", "",
              nonimage.to_markdown(index=False), ""]

    missing = footprint[~footprint["present"]]
    lines += ["## Footprint differences", ""]
    if missing.empty:
        lines.append("Every case/LED contains all 17 available SCAs.")
    else:
        lines += ["Detected from the pixels themselves:", "",
                  missing[["case", "led", "sca", "finite_frac"]]
                  .to_markdown(index=False)]
    lines += ["", "WFI08 is absent from every activity of both datasets and is "
                  "excluded from all per-SCA statistics.", ""]

    lines += ["## Extreme superpixels", ""]
    if outliers.empty:
        lines.append("No superpixel in any case exceeds 10x its cube median.")
    else:
        counts = (outliers.groupby(["case", "led"]).size()
                  .rename("n_extreme").reset_index())
        worst = (outliers.reindex(outliers["value_over_median"].abs()
                                  .sort_values(ascending=False).index)
                 .head(12))
        lines += [
            "Superpixels exceeding 10x the cube median in magnitude. These are "
            "confined to one case and repeat at the *same rows and columns in "
            "every LED*, so they are fixed detector defects rather than "
            "transient events -- and they are not flagged in the DQ arrays, "
            "since DQ masking is applied when the mosaics are built.", "",
            counts.to_markdown(index=False), "",
            "Largest offenders:", "",
            worst[["case", "led", "row", "col", "sca", "value",
                   "value_over_median"]].to_markdown(index=False), "",
            "They do not affect anything reported here -- every statistic above "
            "is a median, a MAD or a 0.5%-trimmed correlation -- but they will "
            "wreck any mean, RMS or untrimmed correlation taken on such a cube.",
            ""]

    lines += ["## Caveats", "",
              "- Per-SCA *correlations* between case 3 (QL) and the other two "
              "are erratic in sign even though the cases agree well in level. "
              "That is expected rather than alarming: within a single SCA the "
              "SRCS illumination is nearly flat, so its own dynamic range is "
              "comparable to the few-percent static ratio pattern, and the "
              "correlation ends up measuring that pattern with an arbitrary "
              "sign. Whole-mosaic and per-SCA *medians* are the meaningful "
              "comparisons here; the correlation column is not.",
              "- The whole-mosaic `corr` column is low (0.004 to 0.66) for every "
              "pair, and that is *not* evidence of disagreement. The focal "
              "plane's own illumination varies by only about 6-8% rms about its "
              "median, while the case-to-case ratio field varies by 10-12% rms, "
              "so a Pearson correlation between two cubes is dominated by the "
              "ratio field rather than by the signal they share. It falls "
              "further toward long wavelengths because the illumination flattens "
              "there. The ratio-map staticity above is the measurement that "
              "actually addresses agreement.",
              "- Orientation was measured, not assumed, and the answer is that "
              "no flip is applied (`identity`), which is *not* the "
              "`mosaic_plot_FPS.placeImages` convention. See "
              "`plots/orientation_calibration.md`.",
              "- `timestamp` is not reproducible from per-SCA metadata: the "
              "original holds a telemetry sample time matching none of the "
              "seven activity start times.",
              "- Case 2 (romancal L2) has dark, linearity and ramp-fit "
              "corrections applied; case 3 (QL slope) has none. An overall "
              "scale difference between them is expected, and the measured "
              "factor is a result rather than an error.",
              "- romancal activity 6 (LED5, 1550 nm) genuinely lacks WFI05. "
              "Native footprints are preserved; differences there are computed "
              "on the reduced common footprint, with excluded pixel counts in "
              "the pairwise table.",
              "- Per-SCA statistics inset 2 superpixels from each block edge, "
              "because the r=4 block bounds are not multiples of the rebin "
              "factor 5 and edge superpixels mix detectors.", ""]

    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w") as handle:
        handle.write("\n".join(lines) + "\n")

    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plots-root", default="plots")
    parser.add_argument("--tables-only", action="store_true")
    args = parser.parse_args()

    print("Loading cases:")
    loaded = load_cases()
    if "1_original" not in loaded:
        print("original cube missing; comparison would have no reference")
        return 1

    tables_dir = os.path.join(args.plots_root, "tables")
    os.makedirs(tables_dir, exist_ok=True)

    print("\nComputing tables:")
    stats = mosaic_stats(loaded)
    pairs = pairwise_stats(loaded)
    sca_table = per_sca_stats(loaded)
    pair_sca = per_sca_pair_stats(loaded)
    nonimage = nonimage_comparison(loaded)
    footprint = footprint_table(loaded)
    activity = activity_map_table()
    chromaticity = chromaticity_of_ratio(loaded)
    outliers = outlier_census(loaded)

    for name, table in (("mosaic_stats", stats),
                        ("pairwise_diff_stats", pairs),
                        ("ratio_map_chromaticity", chromaticity),
                        ("extreme_superpixels", outliers),
                        ("per_sca_stats", sca_table),
                        ("per_sca_pair_stats", pair_sca),
                        ("nonimage_comparison", nonimage),
                        ("sca_footprint", footprint),
                        ("activity_wavelength_map", activity)):
        out = os.path.join(tables_dir, f"{name}.csv")
        table.to_csv(out, index=False)
        print(f"  {out} ({len(table)} rows)")

    figures = 0
    if not args.tables_only:
        print("\nGenerating figures:")
        figures += plot_mosaics(loaded, os.path.join(args.plots_root, "mosaics"))
        figures += plot_pairs(loaded, args.plots_root)
        figures += plot_per_sca(sca_table, pair_sca,
                                os.path.join(args.plots_root, "per_sca"))
        figures += plot_trends(loaded, stats, sca_table,
                               os.path.join(args.plots_root, "trends"))
        figures += plot_nonimage(loaded, os.path.join(args.plots_root, "nonimage"))
        figures += plot_chromaticity(chromaticity,
                                     os.path.join(args.plots_root, "trends"))
        print(f"  total {figures} figures")

    summary = write_summary(loaded, stats, pairs, nonimage, footprint, activity,
                            chromaticity, outliers,
                            os.path.join(tables_dir, "summary.md"))
    print(f"\nWrote {summary}")

    print("\nHeadline numbers:")
    for _, row in pairs.iterrows():
        print(f"  {row['pair']:28s} {row['led']}  "
              f"median ratio {row['median_ratio']:.4f}  "
              f"median diff {row['median_diff']:+.4f}  "
              f"corr {row['corr']:+.4f}  n_common {row['n_common']}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
