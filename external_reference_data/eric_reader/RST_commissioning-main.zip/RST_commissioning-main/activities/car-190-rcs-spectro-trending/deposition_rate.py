"""
Net growth/loss rate as a function of MPA temperature.

Pulls the MPA temperature around ``--trend-start`` (default
``2026-09-12T01:22:16.1080000``, when trending starts) via
``trend_housekeeping.pull_mnemonic_window``, runs it through
``sublimation.sublimation_rate`` (Murphy-Koop vapor pressure + Hertz-Knudsen),
and plots

    mdot_net(t) = mdot_incident - mdot_sublimation(T(t))

in nm/day, alongside the sublimation term alone. 

``--hours`` is the window *before* ``--trend-start``; the window extends past
``--trend-start`` by 10% of ``--hours`` (e.g. ``--hours 10`` -> -10h to +1h
relative to trend start), so the plot shows the approach to the trend-start
temperature as well as a bit of what follows it.

Default mnemonic ``WFI_MCE_ADC_WTSM00`` is the flight EDP alias
``process_rcs_trending.FLIGHT_MNEMONIC_ALIASES`` and ``README.md`` use for the
MPA-A ``CSENS`` temperature (``WFI_MCU_A_MPA_CSENS_FPSSEN_K``), already in
Kelvin -- **unverified, per README.md, pending instrument-team confirmation.**

    python deposition_rate.py
    python deposition_rate.py --hours 24 --incident-rate 5.0
    python deposition_rate.py --trend-start 2026-09-12T01:22:16.108 --hours 10
"""
import argparse
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import astropy.units as u
from astropy.table import Table

import sublimation
from trend_housekeeping import MNEMONIC, pull_mnemonic_window

TREND_START = "2026-09-12T01:22:16.1080000"

SUB_COLOR = "#bf4025"
NET_COLOR = "#256abf"


def compute_rates(data, incident_rate):
    """Sublimation and net growth rate (nm/day) for a temperature pull.

    Parameters
    ----------
    data : DataFrame
        ``time``/``value`` (Kelvin) as returned by ``pull_mnemonic_window``.
    incident_rate : astropy Quantity
        Constant incident deposition rate (nm/day equivalent).

    Returns
    -------
    mdot_sub, mdot_net : astropy Quantity arrays (nm/day)
        Sublimation rate and ``incident_rate - mdot_sub`` (positive = net
        growth, negative = net loss), one entry per row of ``data``.
    """
    if len(data) == 0:
        empty = np.array([]) * u.nm / u.day
        return empty, empty

    T = data["value"].to_numpy() * u.K
    mdot_sub = sublimation.sublimation_rate(T).to(u.nm / u.day)
    mdot_net = (incident_rate - mdot_sub).to(u.nm / u.day)

    return mdot_sub, mdot_net


def integrate_total(time, mdot_net):
    """Trapezoidal time-integral of ``mdot_net`` (nm/day), starting only once
    ``mdot_net`` first turns positive (net ice growth).

    Before that first crossing the surface is net subliming, which is not ice
    buildup to accumulate; once it crosses, the integral runs to the end of
    the window (including any later negative dips), tracking net accumulated
    thickness from that point on. Zero if ``mdot_net`` never goes positive, or
    fewer than two samples remain from the crossing onward.
    """
    positive = np.flatnonzero(mdot_net.to(u.nm / u.day).value > 0)
    if len(positive) == 0:
        return 0.0 * u.nm

    start = positive[0]
    time_from_start = time.iloc[start:]
    net_from_start = mdot_net[start:]
    if len(time_from_start) < 2:
        return 0.0 * u.nm

    elapsed_days = ((time_from_start - time_from_start.iloc[0])
                     .dt.total_seconds().to_numpy() / 86400.0)
    total = np.trapz(net_from_start.to(u.nm / u.day).value, elapsed_days)

    return total * u.nm


def plot_rates(data, mdot_sub, mdot_net, total, incident_rate, trend_start,
               out_path):
    """Write time-vs-rate plot (sublimation and net) to ``out_path``."""
    fig, ax = plt.subplots(figsize=(9, 4.5))
    if len(data):
        ax.plot(data["time"], mdot_sub.value, color=SUB_COLOR, linewidth=2,
                label="sublimation (Murphy-Koop)")
        ax.plot(data["time"], mdot_net.value, color=NET_COLOR, linewidth=2,
                label=f"net (incident - sublimation); integrated: {total:.3g}")
        ax.axhline(0, color="gray", linewidth=1, alpha=0.6)
        ax.axvline(trend_start, color="gray", linewidth=1, linestyle="--",
                   alpha=0.6, label="trend start")
        ax.legend(loc="best", fontsize=9)

        incident_value = incident_rate.to(u.nm / u.day).value
        if incident_value != 0:
            ax.set_ylim(-incident_value, incident_value * 1.2)
    else:
        ax.text(0.5, 0.5, "no samples in window", ha="center", va="center",
                transform=ax.transAxes, color="gray")

    ax.set_title("Net deposition rate")
    ax.set_ylabel("rate (nm/day)")
    ax.xaxis.set_major_locator(mdates.AutoDateLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d %H:%M"))
    fig.autofmt_xdate()
    ax.grid(True, alpha=0.3)
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(False)

    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--mnemonic", default=MNEMONIC)
    parser.add_argument("--trend-start", default=TREND_START,
                        help="timestamp trending starts at (UTC); --hours is "
                             "measured before this, the plot extends 10%% of "
                             "--hours past it")
    parser.add_argument("--hours", type=float, default=70.0,
                        help="window before --trend-start")
    parser.add_argument("--incident-rate", type=float, default=0.0,
                        help="constant mdot_incident in nm/day (default: 0, "
                             "set by hand -- no chamber-pressure estimate yet)")
    parser.add_argument("--out", default="plots/deposition/mpa_deposition_rate.png")
    parser.add_argument("--out-ecsv", default=None,
                        help="optional per-sample table path")
    args = parser.parse_args()

    trend_start = pd.Timestamp(args.trend_start)
    t_start = trend_start - pd.Timedelta(hours=args.hours)
    t_end = trend_start + pd.Timedelta(hours=0.1 * args.hours)

    data = pull_mnemonic_window(args.mnemonic, t_start, t_end)
    print(f"  {len(data)} samples for {args.mnemonic} over {t_start} .. {t_end}")

    incident_rate = args.incident_rate * u.nm / u.day
    mdot_sub, mdot_net = compute_rates(data, incident_rate)
    total = integrate_total(data["time"], mdot_net)

    if len(data):
        print(f"  T: min={data['value'].min():.2f}K mean={data['value'].mean():.2f}K "
              f"max={data['value'].max():.2f}K")
        print(f"  mdot_sublimation: mean={mdot_sub.mean():.4g}")
        print(f"  mdot_net (incident={incident_rate:.3g} - sublimation): "
              f"mean={mdot_net.mean():.4g}")
    print(f"  integrated net (from first net>0 crossing): {total:.4g}")

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    plot_rates(data, mdot_sub, mdot_net, total, incident_rate, trend_start, args.out)
    print(f"  wrote {args.out}")

    if args.out_ecsv:
        # Via a DataFrame (rather than Table({"time": ...}) directly) so the
        # datetime64 column round-trips as an astropy Time -- constructing
        # the Table straight from datetime64 triggers an ECSV datatype
        # warning (same pattern trend_housekeeping.main uses for its ecsv).
        frame = pd.DataFrame({
            "time": data["time"],
            "temperature_K": data["value"],
            "mdot_sublimation_nm_day": mdot_sub.to(u.nm / u.day).value,
            "mdot_net_nm_day": mdot_net.to(u.nm / u.day).value,
        })
        os.makedirs(os.path.dirname(args.out_ecsv) or ".", exist_ok=True)
        Table.from_pandas(frame).write(args.out_ecsv, format="ascii.ecsv",
                                       overwrite=True)
        print(f"  wrote {args.out_ecsv}")


if __name__ == "__main__":
    main()
