"""
Hertz-Knudsen ice film growth rate calculator with Murphy & Koop (2005)
sublimation vapor pressure and equilibrium temperature finding.

Uses amorphous solid water (ASW) density throughout.
"""

import numpy as np
import astropy.units as u
import astropy.constants as const
from scipy.optimize import brentq

H2O_MOLECULAR_MASS = (18.015 * u.u).to(u.kg)
H2O_MOLAR_MASS = 18.015 * u.g / u.mol
ASW_DENSITY = 930.0 * u.kg / u.m**3
ASW_NUMBER_DENSITY = (ASW_DENSITY * const.N_A / H2O_MOLAR_MASS).to(1 / u.m**3)

# Murphy & Koop (2005) coefficients
# These are parameterized with T_reduced = T / 273.15 K
MK_C1 = 29.3577
MK_C2 = -20.9521
MK_C3 = 3.53068
MK_C4 = -1.98951
MK_T_REF = 273.15  # normalization temperature in K


def murphy_koop_pressure(T):
    """
    Murphy & Koop (2005) sublimation vapor pressure of ice.

    P_sub(T) = exp[c1 + c2/Tr + c3*ln(Tr) + c4*Tr]  (Pa)

    where Tr = T / 273.15 K is the reduced temperature.

    Valid for T ~ 110-273 K.

    Parameters
    ----------
    T : astropy Quantity
        Temperature (K or equivalent).

    Returns
    -------
    P_sub : astropy Quantity
        Sublimation vapor pressure in Pa.
    """
    T_reduced = T.to(u.K).value / MK_T_REF

    ln_P = (MK_C1
            + MK_C2 / T_reduced
            + MK_C3 * np.log(T_reduced)
            + MK_C4 * T_reduced)

    P_sub = np.exp(ln_P) * u.Pa

    return P_sub


def sublimation_rate(T, sticking_coefficient=1.0):
    """
    Compute the sublimation rate of an ice film at temperature T.

    Uses Murphy & Koop (2005) vapor pressure and the Hertz-Knudsen
    formula to convert to a film thickness loss rate.

    The sublimating molecules leave the surface with a thermal velocity
    characterized by the surface temperature T.

    Parameters
    ----------
    T : astropy Quantity
        Surface temperature (K or equivalent).
    sticking_coefficient : float, optional
        Sticking/evaporation coefficient (detailed balance). Default: 1.0.

    Returns
    -------
    rate : astropy Quantity
        Sublimation rate in um/day (positive = film thinning).
    """
    P_sub = murphy_koop_pressure(T)

    # Hertz-Knudsen sublimation flux
    flux = P_sub / np.sqrt(2 * np.pi * H2O_MOLECULAR_MASS * const.k_B * T)
    flux = flux.to(1 / (u.m**2 * u.s))

    # Convert to thickness rate
    rate = (sticking_coefficient * flux / ASW_NUMBER_DENSITY).to(u.um / u.day)

    return rate


def deposition_rate(partial_pressure, temperature=293 * u.K,
                    sticking_coefficient=1.0):
    """
    Compute the Hertz-Knudsen deposition rate for water vapor.

    Parameters
    ----------
    partial_pressure : astropy Quantity
        Partial pressure of water vapor.
    temperature : astropy Quantity, optional
        Gas temperature (determines molecular velocity). Default: 293 K.
    sticking_coefficient : float, optional
        Sticking coefficient. Default: 1.0.

    Returns
    -------
    rate : astropy Quantity
        Film growth rate in um/day.
    """
    flux = partial_pressure / np.sqrt(
        2 * np.pi * H2O_MOLECULAR_MASS * const.k_B * temperature
    )
    flux = flux.to(1 / (u.m**2 * u.s))

    rate = (sticking_coefficient * flux / ASW_NUMBER_DENSITY).to(u.um / u.day)

    return rate


def find_equilibrium_temperature(partial_pressure, T_gas=293 * u.K,
                                 sticking_coefficient=1.0,
                                 T_bracket=(80, 270)):
    """
    Find the surface temperature at which the sublimation rate equals
    the Hertz-Knudsen deposition rate for a given partial pressure.

    At equilibrium:
        rate_deposition(P, T_gas) = rate_sublimation(T_surface)

    Below T_eq, net ice accumulates.
    Above T_eq, net sublimation occurs.

    Parameters
    ----------
    partial_pressure : astropy Quantity
        Ambient partial pressure of water vapor.
    T_gas : astropy Quantity, optional
        Gas temperature for incoming molecules. Default: 293 K.
    sticking_coefficient : float, optional
        Sticking/evaporation coefficient. Default: 1.0.
    T_bracket : tuple of float, optional
        (T_low, T_high) in Kelvin for root-finding bracket. Default: (80, 270).

    Returns
    -------
    T_eq : astropy Quantity
        Equilibrium surface temperature in K.
    rate_dep : astropy Quantity
        Deposition rate at this condition (um/day).
    rate_sub : astropy Quantity
        Sublimation rate at T_eq (should equal rate_dep).
    """
    # Deposition rate (fixed, depends on P and T_gas)
    r_dep = deposition_rate(partial_pressure, T_gas, sticking_coefficient)

    # Objective: sublimation_rate(T) - deposition_rate = 0
    def objective(T_K):
        T = T_K * u.K
        r_sub = sublimation_rate(T, sticking_coefficient)
        return (r_sub - r_dep).to(u.um / u.day).value

    # Solve using Brent's method
    T_eq_K = brentq(objective, T_bracket[0], T_bracket[1], xtol=1e-4)
    T_eq = T_eq_K * u.K

    r_sub = sublimation_rate(T_eq, sticking_coefficient)

    return T_eq, r_dep, r_sub


if __name__ == "__main__":

    print("=" * 70)
    print("Hertz-Knudsen Deposition & Murphy-Koop Sublimation Equilibrium")
    print("Amorphous Solid Water (ASW), rho = 930 kg/m^3")
    print("=" * 70)
    print()

    # --- Murphy-Koop sublimation rate table ---
    print("Murphy & Koop (2005) sublimation rate vs. temperature:")
    print(f"  Coefficients: c1={MK_C1}, c2={MK_C2}, c3={MK_C3}, c4={MK_C4}")
    print(f"  T_ref = {MK_T_REF} K (reduced temperature Tr = T/T_ref)")
    print("-" * 70)
    print(f"{'T (K)':>8s} {'P_sub (Pa)':>12s} {'P_sub (Torr)':>14s} "
          f"{'Rate (um/day)':>14s}")
    print("-" * 70)

    T_table = np.arange(100, 210, 10) * u.K
    for T in T_table:
        P = murphy_koop_pressure(T)
        r = sublimation_rate(T)
        print(f"  {T.value:6.0f}   {P.value:12.3e}   "
              f"{P.to(u.Torr).value:12.3e}   {r.value:12.4e}")
    print()

    # --- Verify at 273.15 K (should be ~611 Pa, triple point) ---
    T_check = 273.15 * u.K
    P_check = murphy_koop_pressure(T_check)
    print(f"  Verification: P_sub(273.15 K) = {P_check:.2f} "
          f"(expect ~611 Pa at triple point)")
    print()

    # --- Find equilibrium temperatures ---
    pressures = [1e-6 * u.Torr, 5e-8 * u.Torr]
    T_gas = 293 * u.K

    print("=" * 70)
    print("Equilibrium temperature (net growth rate = 0)")
    print(f"  Gas temperature: {T_gas}")
    print(f"  Sticking coefficient: 1.0")
    print(f"  ASW number density: {ASW_NUMBER_DENSITY:.4e}")
    print("=" * 70)
    print()

    for P in pressures:
        print(f"  P_H2O = {P:.1e} = {P.to(u.Pa):.3e}")
        print(f"  {'-' * 55}")

        T_eq, r_dep, r_sub = find_equilibrium_temperature(P, T_gas=T_gas)

        P_sub_eq = murphy_koop_pressure(T_eq)

        print(f"  Deposition rate (Hertz-Knudsen):  {r_dep:.4f}")
        print(f"  Sublimation rate at T_eq:         {r_sub:.4f}")
        print(f"  Equilibrium temperature:          {T_eq:.2f}")
        print(f"  Murphy-Koop P_sub at T_eq:        {P_sub_eq.to(u.Torr):.3e}")
        print(f"  (cf. ambient P_H2O:               {P.to(u.Torr):.3e})")
        print()
        print(f"  -> Ice accumulates for T_surface < {T_eq:.1f}")
        print(f"  -> Ice sublimes    for T_surface > {T_eq:.1f}")
        print()
        print()

    # --- Net rate at a few temperatures for each pressure ---
    print("=" * 70)
    print("Net growth rate = deposition - sublimation (um/day)")
    print("  Positive = ice growing; Negative = ice subliming")
    print("=" * 70)
    print()

    T_sweep = np.arange(100, 200, 5) * u.K

    for P in pressures:
        r_dep = deposition_rate(P, T_gas)
        print(f"  P_H2O = {P:.1e},  deposition rate = {r_dep:.4f}")
        print(f"  {'T (K)':>8s} {'Sub rate (um/d)':>16s} {'Net rate (um/d)':>16s}")
        print(f"  {'-' * 45}")
        for T in T_sweep:
            r_sub = sublimation_rate(T)
            r_net = r_dep - r_sub
            print(f"  {T.value:8.0f} {r_sub.value:16.4e} {r_net.value:16.4f}")
        print()
        
    print("Murphy & Koop (2005) sublimation rate (ASW, rho = 930 kg/m^3)")
    print("-" * 45)
    print(f"  {'T (K)':>6s}   {'Rate (um/day)':>14s}")
    print("-" * 45)

    T_sweep = np.arange(120, 185, 1) * u.K
    for T in T_sweep:
        r = sublimation_rate(T)
        print(f"  {T.value:6.0f}   {r.value:14.4e}")
