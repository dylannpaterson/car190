#!/usr/bin/env python
"""Read RCS trend products and apply their calibration -- a free-standing helper.

Copy this one file into your own repo: it needs only ``numpy`` and ``h5py``
(``astropy`` for ``--ecsv``, ``matplotlib`` for ``--plot``, both imported only
when used). Nothing from the pipeline that wrote the products is imported.

A calibrated product is self-contained. Everything the pipeline's digests
report can be rebuilt from a directory of ``*_cal.h5`` files with this module
alone -- every digest column, the bridge meta families, and the per-LED blink
figures -- and ``python rcs_trend_reader.py compare CAL_DIR DIGEST_DIR`` checks
that it is. 

What it reads
-------------
A calibrated per-SCA product, ``<run_label>_cal.h5``, schema 2:

* ``sca_arrays/<LED>``: ``(18, n, n)`` superpixel rates, **exactly as stage 1
  wrote them** -- no calibration is applied to the pixels;
* ``calibration/<step>/multiplier``: one ``(6, 18)`` array per calibration
  step on ``(led_name, sca)``, all with one rule::

      calibrated = raw * multiplier

  so applying any subset of steps is multiplying their multipliers;
* ``calibration/bridge_solution/``: the whole fitted bridge solution, every
  step at every ACM move and side swap with its errors, method and the side
  bridge's illumination-pattern test -- the same table in every product.

Calibrations applied:
=============  ==================================================  =========
step           what it removes                                     varies by
=============  ==================================================  =========
photodiode     lamp output drift; 1.0 at the first epoch of each   LED
               MCE side
acm            linear ACM-position response within one segment     (scalar)
acm_bridge     the step across each ACM reconfiguration            SCA
side_bridge    the step across an MCE side swap: electronics, LED  LED
               drive and photodiode at once; NOT SCA-dependent
tempgain       the temperature-dependent detector gain;            LED, SCA
               provisional
=============  ==================================================  =========
Gauge choices:
--------------------------------------
The recorded multipliers are absolute and gauged to the *present*: the
bridges are 1.0 in the instrument's current configuration (side B, latest ACM
segment) and scale earlier epochs up to it, and the photodiode is 1.0 at the
start of each side. A trend is usually wanted relative to its first epoch, and
:meth:`RcsTrend.series` does that by dividing every epoch's multiplier by the
first epoch's. Both views describe the same calibrated data.

Using it
--------
::

    from rcs_trend_reader import RcsProduct, RcsTrend

    p = RcsProduct("CAR190_01039_03_071_001_20261006_cal.h5")
    p.summary()                                  # prints the key numbers
    m = p.multiplier(exclude=("tempgain",))      # (6, 18)
    led3 = p.stack("LED3", exclude=("tempgain",))   # (18, n, n), calibrated
    rows = p.bridge_solution()                   # every fitted bridge step

    t = RcsTrend("<trend root>/cal")              # e.g. the shared rcs_trend_v4/cal
    series = t.series(exclude=("tempgain",))     # {"SCA1": (n_epoch, 6), ...}
    columns = t.digest("SCA4")                   # every digest column
    t.to_ecsv("my_digests")                      # digest-shaped ECSVs
    t.plot_pair("LED1", "my_figures")            # the blink pair

Command line::

    python rcs_trend_reader.py summary FILE
    python rcs_trend_reader.py factors FILE [--steps photodiode,acm]
    python rcs_trend_reader.py bridges FILE       # the embedded bridge solution
    python rcs_trend_reader.py steps DIR          # which steps each product has
    python rcs_trend_reader.py trend DIR --ecsv OUT --plot OUT
    python rcs_trend_reader.py compare DIR DIGEST_DIR   # against the pipeline
    python rcs_trend_reader.py --self-test
"""
import argparse
import datetime
import glob
import os
import re
import sys

import numpy as np

LED_NAMES = ("LED1", "LED2", "LED3", "LED4", "LED5", "LED6")
STEPS = ("photodiode", "acm", "acm_bridge", "side_bridge", "tempgain")
# What the digests' canonical LED1..LED6 apply: everything but the gain, which
# is provisional and has its own LEDx_tgcorr columns.
DIGEST_EXCLUDE = ("tempgain",)
SCHEMA = 2


def _text(value):
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    if isinstance(value, np.ndarray) and value.ndim == 0:
        return _text(value.item())
    return str(value)


def _timestamp(value):
    """Aware UTC datetime from a product timestamp (7 fractional digits)."""
    text = re.sub(r"(\.\d{6})\d+", r"\1", _text(value).strip())
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    moment = datetime.datetime.fromisoformat(text)
    return moment if moment.tzinfo else moment.replace(
        tzinfo=datetime.timezone.utc)


def _sca_number(name):
    return int(str(name).replace("SCA", ""))


def _get(row, column):
    """A bridge-solution cell; NaN (or "") where an older table lacks the column."""
    if column in row:
        return row[column]
    if column in ("boundary_index", "sca", "n_early", "n_late"):
        return -1
    return "" if column in ("note", "method", "transition", "led", "kind",
                            "boundary_run_label", "boundary_utc") else float("nan")


class RcsProduct:
    """One calibrated per-SCA product, read on demand.

    Opening reads only the metadata, the ``(6, 18)`` multipliers and the
    embedded bridge solution; pixels are read by :meth:`stack` and
    :meth:`response`. The canonical axis order is ``LED1..LED6`` x
    ``SCA1..SCA18``; a product stored in another order is reordered by its own
    axis labels, never assumed.
    """

    def __init__(self, path):
        import h5py

        self.path = str(path)
        with h5py.File(self.path, "r") as handle:
            self.attrs = {key: handle.attrs[key] for key in handle.attrs}
            self.schema = int(self.attrs.get("calibration_schema", 0) or 0)
            if self.schema < SCHEMA:
                raise ValueError(
                    f"{os.path.basename(self.path)} is calibration schema "
                    f"{self.schema or 'none'}. This reader handles schema "
                    f"{SCHEMA}, where nothing is applied to the pixels; a "
                    f"schema-1 product already has photodiode, side and ACM "
                    f"multiplied in, and a raw product has no calibration/ "
                    f"group at all.")
            calibration = handle["calibration"]
            leds = [_text(v) for v in calibration["led_name"][()]]
            scas = [int(v) for v in calibration["sca"][()]]
            self.sca_names = [f"SCA{n}" for n in sorted(scas)]
            led_order = [leds.index(led) for led in LED_NAMES]
            sca_order = [scas.index(n) for n in sorted(scas)]
            self.steps, self.step_attrs, self.step_errors = {}, {}, {}
            for name in STEPS:
                if name in calibration:
                    group = calibration[name]
                    grid = np.asarray(group["multiplier"][()], dtype=float)
                    self.steps[name] = grid[np.ix_(led_order, sca_order)]
                    self.step_attrs[name] = {key: group.attrs[key]
                                             for key in group.attrs}
                    if "error" in group:
                        error = np.asarray(group["error"][()], dtype=float)
                        self.step_errors[name] = (
                            error[led_order] if len(error) == len(LED_NAMES)
                            else error[sca_order])
            self.total = np.asarray(calibration["total_multiplier"][()],
                                    dtype=float)[np.ix_(led_order, sca_order)]
            self._solution = None
            if "bridge_solution" in calibration:
                group = calibration["bridge_solution"]
                self._solution = (
                    {key: group[key][()] for key in group},
                    {key: group.attrs[key] for key in group.attrs})
            dictionary = handle["dictionary"]
            self.timestamp = _timestamp(dictionary["timestamp"][()])
            lvdt = np.asarray(dictionary["ACM_LVDT"][()], dtype=float)
            # nanmean, as the pipeline does: one dead channel must not NaN
            # the epoch's position.
            self.acm_lvdt = (float(np.nanmean(lvdt)) if np.isfinite(lvdt).any()
                             else float("nan"))
            self.coverage = (np.asarray(handle["coverage"]["per_sca"][()],
                                        dtype=bool)
                             if "coverage" in handle else None)
            self.activities = list(handle["sca_arrays"].keys())
            # The MA table of the LED flats, off LED3's dataset attrs (stage 1
            # records it per activity from 2026-10-30). It matters on SCA18:
            # IM_DIAGNOSTIC (full frames) and DROP_2_OF_3 read ~0.8 % apart.
            arrays = handle["sca_arrays"]
            led3 = arrays["LED3"].attrs if "LED3" in arrays else {}
            self.readout = {key: _text(led3[key]) for key in
                            ("ma_table_name", "ma_table_number", "nresultants")
                            if key in led3}

    # -- metadata -------------------------------------------------------------

    def attr(self, name, default=""):
        return _text(self.attrs.get(name, default))

    @property
    def run_label(self):
        return self.attr("run_label") or os.path.basename(self.path)[:-3]

    @property
    def name(self):
        return os.path.basename(self.path)

    def resolve(self, steps=None, exclude=()):
        """The step names a request means, checked against what is recorded.

        ``steps=None`` or ``"all"`` is every step this product records. A
        named step the product does not record raises: silently treating it as
        1.0 would hand back an uncalibrated number labelled as calibrated.
        """
        if steps is None or steps == "all":
            chosen = [name for name in STEPS if name in self.steps]
        else:
            chosen = [steps] if isinstance(steps, str) else list(steps)
        unknown = [name for name in chosen + list(exclude) if name not in STEPS]
        if unknown:
            raise ValueError(f"unknown step(s) {unknown}; the steps are "
                             f"{list(STEPS)}")
        missing = [name for name in chosen if name not in self.steps]
        if missing:
            raise KeyError(f"{self.run_label} does not record "
                           f"{', '.join(missing)} (it records "
                           f"{', '.join(self.steps) or 'nothing'})")
        return [name for name in chosen if name not in exclude]

    def multiplier(self, steps=None, exclude=()):
        """``(6, 18)``: the product of the chosen steps' multipliers."""
        out = np.ones((len(LED_NAMES), len(self.sca_names)))
        for name in self.resolve(steps, exclude):
            out = out * self.steps[name]
        return out

    def bridge_solution(self):
        """Every fitted bridge step, as a list of row dicts, plus the meta.

        Returns ``(rows, meta)``; ``([], {})`` for a product without one. The
        same table is in every product calibrated with it (compare
        ``meta['solution_sha256']``), so any one product carries all of it.
        ``kind`` is ``acm`` (a per-SCA step, ``led == 'ALL'``), ``side`` (the
        per-LED step common to all SCAs, ``sca == 0``) or ``side_sca`` (one
        SCA's own estimate, for the pattern test; never applied). ``value``
        multiplies every epoch before ``boundary_utc``.
        """
        if self._solution is None:
            return [], {}
        columns, meta = self._solution
        names = list(columns)
        rows = []
        for i in range(len(columns["kind"])):
            row = {}
            for name in names:
                value = columns[name][i]
                row[name] = (_text(value) if isinstance(value, (bytes, str))
                             else value.item() if hasattr(value, "item")
                             else value)
            rows.append(row)
        return rows, meta

    # -- pixels ---------------------------------------------------------------

    def stack(self, led, steps=None, exclude=(), raw=False):
        """``(18, n, n)`` for one LED: raw, or multiplied by the chosen steps."""
        import h5py

        with h5py.File(self.path, "r") as handle:
            data = np.asarray(handle["sca_arrays"][led][()], dtype=float)
        if raw:
            return data
        if led not in LED_NAMES:
            raise ValueError(f"{led} is not one of the six LEDs; the CAR-216 "
                             f"aux flats carry no calibration of their own")
        row = self.multiplier(steps, exclude)[LED_NAMES.index(led)]
        return data * row[:, None, None]

    def response(self, steps=None, exclude=()):
        """``(6, 18)`` per-SCA nanmedian of each calibrated LED stack."""
        multiplier = self.multiplier(steps, exclude)
        out = np.full(multiplier.shape, np.nan)
        for i, led in enumerate(LED_NAMES):
            data = self.stack(led, raw=True)
            for j in range(data.shape[0]):
                if np.isfinite(data[j]).any():
                    out[i, j] = np.nanmedian(data[j]) * multiplier[i, j]
        return out

    # -- reporting ------------------------------------------------------------

    def summary(self, out=print):
        out(f"{self.run_label}  ({self.name})")
        out(f"  time        {self.timestamp.isoformat()}")
        out(f"  program     {self.attr('car_label')} pass {self.attr('pass_number')}"
            f"  decon {self.attr('decon_cycle')}")
        out(f"  MCE side    {self.attr('mce_side')} "
            f"({self.attr('mce_side_source')})")
        # The RCS sequence variant the pass ran; products staged from a plan
        # written before 2026-10-22 do not record it until they are re-staged.
        out(f"  sequence    {self.attr('sequence_variant') or 'not recorded'}"
            + (f"  ({self.attr('sequence_signature')})"
               if self.attr('sequence_signature') else ""))
        out("  readout     " + (
            f"{self.readout.get('ma_table_name')} (MA table "
            f"{self.readout.get('ma_table_number')}, "
            f"{self.readout.get('nresultants')} resultants)"
            if self.readout.get("ma_table_name") else "not recorded"))
        out(f"  ACM         LVDT {self.acm_lvdt:.1f}, segment "
            f"{self.attr('acm_segment')}, reference LVDT "
            f"{self.attr('acm_segment_reference_lvdt')}")
        if self.coverage is not None:
            out(f"  coverage    {int(self.coverage.sum())}/{len(self.coverage)} "
                f"SCAs")
        out(f"  pixels      raw (nothing applied); activities "
            f"{', '.join(self.activities)}")
        out(f"  steps       {', '.join(self.steps) or 'none'}  "
            f"(calibrated = raw * multiplier)")
        out(f"  {'step':<12}" + "".join(f"{led:>18}" for led in LED_NAMES))
        for name in self.steps:
            grid = self.steps[name]
            cells = []
            for row in grid:
                lo, hi = np.nanmin(row), np.nanmax(row)
                cells.append(f"{lo:.5f}" if np.isclose(lo, hi, rtol=0, atol=5e-7)
                             else f"{lo:.4f}-{hi:.4f}")
            out(f"  {name:<12}" + "".join(f"{cell:>18}" for cell in cells))
        out(f"  {'total*':<12}" + "".join(
            f"{np.nanmedian(row):>18.5f}" for row in self.total))
        out("  (* calibration/total_multiplier, SCA median: every step except "
            "tempgain)")
        rows, meta = self.bridge_solution()
        if rows:
            kinds = {kind: sum(1 for r in rows if r["kind"] == kind)
                     for kind in ("acm", "side", "side_sca")}
            out(f"  bridge solution embedded: {kinds['acm']} ACM rows, "
                f"{kinds['side']} side rows, {kinds['side_sca']} per-SCA side "
                f"estimates (sha {_text(meta.get('solution_sha256', ''))[:12]})"
                f"; `bridges` prints it")


class RcsTrend:
    """A time-ordered set of calibrated products: a digest you can rebuild.

    ``source`` is a directory (every ``*_cal.h5`` in it) or a list of paths.
    Ordered by each product's own timestamp, never by filename -- pass numbers
    restart per program, so filename order interleaves CAR-190 and CAR-216.
    """

    def __init__(self, source):
        paths = (sorted(glob.glob(os.path.join(source, "*_cal.h5")))
                 if isinstance(source, str) and os.path.isdir(source)
                 else list(source))
        if not paths:
            raise ValueError(f"no *_cal.h5 products in {source!r}")
        self.products = sorted((RcsProduct(p) for p in paths),
                               key=lambda p: p.timestamp)
        self.sca_names = self.products[0].sca_names
        self._medians = None

    @property
    def hours(self):
        t0 = self.products[0].timestamp
        return np.array([(p.timestamp - t0).total_seconds() / 3600.0
                         for p in self.products])

    def _ratio_medians(self):
        """``(n_epoch, 6, 18)``: per-SCA nanmedian of stack / first stack.

        Computed once and reused for every choice of steps. A multiplier is one
        positive number per SCA plane, so it commutes with that plane's median
        -- exactly for an odd number of finite pixels, to one rounding for an
        even number, where the median averages two values.
        """
        if self._medians is not None:
            return self._medians
        first = self.products[0]
        reference = {led: first.stack(led, raw=True) for led in LED_NAMES}
        out = np.full((len(self.products), len(LED_NAMES), len(self.sca_names)),
                      np.nan)
        for e, product in enumerate(self.products):
            for i, led in enumerate(LED_NAMES):
                with np.errstate(divide="ignore", invalid="ignore"):
                    planes = product.stack(led, raw=True) / reference[led]
                for j in range(len(self.sca_names)):
                    if np.isfinite(planes[j]).any():
                        out[e, i, j] = float(np.nanmedian(planes[j]))
        self._medians = out
        return out

    def _multiplier_ratio(self, steps, exclude, gauge):
        grids = np.stack([p.multiplier(steps, exclude) for p in self.products])
        if gauge == "first":
            return grids / grids[0][None, :, :]
        if gauge == "absolute":
            return grids
        raise ValueError("gauge is 'first' or 'absolute'")

    def series(self, steps=None, exclude=(), gauge="first"):
        """``{sca: (n_epoch, 6)}`` calibrated relative response.

        Per SCA plane: the nanmedian of ``stack_epoch / stack_first``, times
        that SCA's multiplier ratio ``m_epoch / m_first`` -- the reduction the
        pipeline's digests use, so with ``exclude=("tempgain",)`` this
        reproduces their LED columns. ``gauge="absolute"`` skips the division
        by the first epoch's multiplier.
        """
        values = self._ratio_medians() * self._multiplier_ratio(steps, exclude,
                                                                gauge)
        return {sca: values[:, :, j] for j, sca in enumerate(self.sca_names)}

    def _step_ratio(self, name):
        """``(n_epoch, 6, 18)`` of one step's multiplier over the first epoch's."""
        grids = np.stack([p.steps[name] for p in self.products])
        return grids / grids[0][None, :, :]

    def decon_time_hours(self):
        """Hours since the first epoch of each epoch's own decon episode.

        Episodes are CONTIGUOUS runs of one label, not a grouping by label: a
        cycle name that recurs after an intervening decon is a new film.
        """
        labels = [p.attr("decon_cycle") for p in self.products]
        hours, out, start = self.hours, np.empty(len(labels)), 0
        for e in range(len(labels)):
            if e and labels[e] != labels[e - 1]:
                start = e
            out[e] = hours[e] - hours[start]
        return out

    def digest(self, sca):
        """Every column of the pipeline digest ``time_series_<sca>.ecsv``.

        Returns ``{column: array}`` with the digests' names and gauges:
        ``LEDx`` with every step but the gain, ``LEDx_tgcorr`` and
        ``tempgain_LEDx`` when the products carry the gain, ``bridge_factor``,
        ``side_bridge_LEDx`` when a side bridge is recorded -- each ratioed to
        the first epoch.
        """
        j = self.sca_names.index(sca)
        first = self.products[0]
        out = {
            "time_hours": self.hours,
            "timestamp": np.array([p.timestamp.isoformat()
                                   for p in self.products]),
            "pass_number": np.array([int(p.attrs.get("pass_number", -1))
                                     for p in self.products]),
            "car_label": np.array([p.attr("car_label") for p in self.products]),
            "decon_cycle": np.array([p.attr("decon_cycle")
                                     for p in self.products]),
            "decon_time_hours": self.decon_time_hours(),
        }
        canonical = self.series(exclude=DIGEST_EXCLUDE)[sca]
        for i, led in enumerate(LED_NAMES):
            out[led] = canonical[:, i]
        if "tempgain" in first.steps:
            ratio = self._step_ratio("tempgain")[:, :, j]
            for i, led in enumerate(LED_NAMES):
                out[f"{led}_tgcorr"] = canonical[:, i] * ratio[:, i]
            for i, led in enumerate(LED_NAMES):
                out[f"tempgain_{led}"] = ratio[:, i]
        out["bridge_factor"] = (self._step_ratio("acm_bridge")[:, 0, j]
                                if "acm_bridge" in first.steps
                                else np.ones(len(self.products)))
        sides = [p.attr("mce_side") for p in self.products]
        if "side_bridge" in first.steps and len(set(sides)) > 1:
            side = self._step_ratio("side_bridge")[:, :, 0]
            for i, led in enumerate(LED_NAMES):
                out[f"side_bridge_{led}"] = side[:, i]
        out["acm_lvdt"] = np.array([p.acm_lvdt for p in self.products])
        out["acm_segment"] = np.array([int(p.attrs.get("acm_segment", -1))
                                       for p in self.products])
        return out

    def bridge_meta(self, sca):
        """The digests' ``bridge_*`` and ``side_bridge_*`` meta, from the products.

        Read from the bridge solution every product embeds, so the numbers a
        digest quotes about its bridges -- step, error, systematic, method,
        fallback note, LED spread, residual rms, the side bridge's error split
        and pattern test -- are all recoverable without the digest.
        """
        rows, meta = self.products[0].bridge_solution()
        if not rows:
            return {}
        number = _sca_number(sca)
        acm = sorted((r for r in rows if _get(r, "kind") == "acm"
                      and int(_get(r, "sca")) == number),
                     key=lambda r: _get(r, "boundary_utc"))
        out = {}
        if acm:
            fitted = any(_get(r, "method") == "bridge" for r in acm)
            out.update({
                "bridge_steps": [float(_get(r, "value")) for r in acm],
                "bridge_method": [_get(r, "method") for r in acm],
                "bridge_notes": [_get(r, "note") for r in acm],
                "bridge_boundary_epochs": [_get(r, "boundary_run_label") for r in acm],
                "bridge_degree": int(meta.get("acm_bridge_degree", -1)),
                "bridge_window_hours": float(meta.get("acm_bridge_window_hours",
                                                      np.nan)),
                "bridge_systematic_per_boundary": [float(_get(r, "systematic"))
                                                   for r in acm],
            })
            if fitted:
                out.update({
                    "bridge_step_errors": [float(_get(r, "stat_error")) for r in acm],
                    "bridge_led_spread": [float(_get(r, "led_spread")) for r in acm],
                    "bridge_rms_pre": [float(_get(r, "rms_early")) for r in acm],
                    "bridge_rms_post": [float(_get(r, "rms_late")) for r in acm],
                })
                systematic = np.array(out["bridge_systematic_per_boundary"])
                out["bridge_systematic"] = (float(np.nanmax(systematic))
                                            if np.isfinite(systematic).any()
                                            else float("nan"))
        side = [r for r in rows if _get(r, "kind") == "side"]
        if side:
            boundaries = sorted({_get(r, "boundary_utc") for r in side})

            def per_led(utc, column):
                by_led = {_get(r, "led"): r for r in side if _get(r, "boundary_utc") == utc}
                return [float(_get(by_led[led], column)) for led in LED_NAMES]

            def first_row(utc):
                return next(r for r in side if _get(r, "boundary_utc") == utc)

            mine = [r for r in rows if _get(r, "kind") == "side_sca"
                    and int(_get(r, "sca")) == number]
            out.update({
                "side_bridge_epoch_indices": [int(_get(first_row(u), "boundary_index"))
                                              for u in boundaries],
                "side_bridge_epochs": [_get(first_row(u), "boundary_run_label")
                                       for u in boundaries],
                "side_bridge_transitions": [_get(first_row(u), "transition")
                                            for u in boundaries],
                "side_bridge_method": [_get(first_row(u), "method") for u in boundaries],
                "side_bridge_steps": [per_led(u, "value") for u in boundaries],
                "side_bridge_stat_errors": [per_led(u, "stat_error")
                                            for u in boundaries],
                "side_bridge_sca_scatter_errors": [
                    per_led(u, "sca_scatter_error") for u in boundaries],
                "side_bridge_systematic": [per_led(u, "systematic")
                                           for u in boundaries],
                "side_bridge_total_errors": [per_led(u, "total_error")
                                             for u in boundaries],
                "side_bridge_n_early": [int(_get(first_row(u), "n_early"))
                                        for u in boundaries],
                "side_bridge_n_late": [int(_get(first_row(u), "n_late"))
                                       for u in boundaries],
                "side_bridge_pattern_rms": [float(_get(first_row(u), "pattern_rms"))
                                            for u in boundaries],
                "side_bridge_pattern_noise": [float(_get(first_row(u), "pattern_noise"))
                                              for u in boundaries],
                "side_bridge_this_sca_steps": [
                    [float(next(_get(r, "value") for r in mine
                                if _get(r, "boundary_utc") == u and _get(r, "led") == led))
                     for led in LED_NAMES] for u in boundaries],
                "side_bridge_this_sca_pattern_offset": [
                    float(next(_get(r, "pattern_offset") for r in mine
                               if _get(r, "boundary_utc") == u)) for u in boundaries],
            })
        return out

    def set_meta(self, sca=None):
        """The digests' set-level meta, derived from the products' attributes.

        Everything here is a per-epoch attribute or a deterministic function of
        them, which is why the products need not store it again:

        * ACM structure: a move is where ``acm_segment`` changes. Its kind comes
          from the embedded bridge solution, and is ``side`` at a side change.
          Its LVDTs are the epochs' ``dictionary/ACM_LVDT`` nanmeans.
        * fractional travel: ``(lvdt + acm_offset) / segment_reference - 1``,
          from ``calibration/acm`` attrs, maximised over epochs;
        * decon episodes: contiguous runs of ``decon_cycle``;
        * flagged photodiode epochs: any NaN in ``calibration/photodiode``;
        * with ``sca``, that SCA's gain reference multiplier.
        """
        products = self.products
        names = [p.name for p in products]
        segments = [int(p.attrs.get("acm_segment", -1)) for p in products]
        rows, _ = products[0].bridge_solution()
        transition = {int(_get(r, "boundary_index")): _get(r, "transition")
                      for r in rows if _get(r, "kind") == "acm"}
        moves = [e for e in range(1, len(products)) if segments[e] != segments[e - 1]]

        def kind(e):
            text = transition.get(e + 1, "")
            return "side" if "->" in text else text

        lvdt = np.array([p.acm_lvdt for p in products])
        references = {}
        for p, segment in zip(products, segments):
            references.setdefault(segment, float(p.attrs.get(
                "acm_segment_reference_lvdt", np.nan)))
        offsets = np.array([float(p.step_attrs.get("acm", {}).get(
            "acm_offset", 0.0)) for p in products])
        travel = np.array([(lvdt[e] + offsets[e]) / references[segments[e]] - 1.0
                           for e in range(len(products))])
        labels = [p.attr("decon_cycle") for p in products]
        episodes = []
        for e, label in enumerate(labels):
            if episodes and labels[e - 1] == label:
                episodes[-1][1] = e
            else:
                episodes.append([e, e])
        out = {
            "n_epochs": len(products),
            "reference_epoch": names[0],
            "epoch_files": names,
            "time_range_hours": [float(self.hours[0]), float(self.hours[-1])],
            "mce_sides_present": sorted({p.attr("mce_side") for p in products}
                                        - {""}),
            "car_labels_present": sorted({p.attr("car_label") for p in products}
                                         - {""}),
            "decon_cycles_present": sorted(set(labels) - {""}),
            "n_acm_segments": len(set(segments)),
            "acm_n_moves": len(moves),
            "acm_move_epochs": [names[e] for e in moves],
            "acm_move_epoch_indices": [e + 1 for e in moves],
            "acm_move_kinds": [kind(e) for e in moves],
            "acm_move_manual": [kind(e) == "side" for e in moves],
            "acm_move_lvdt_before": [float(lvdt[e - 1]) for e in moves],
            "acm_move_lvdt_after": [float(lvdt[e]) for e in moves],
            "acm_move_delta_lvdt": [float(lvdt[e] - lvdt[e - 1]) for e in moves],
            "acm_segment_reference_lvdt": [references[s]
                                           for s in sorted(references)],
            "acm_max_fractional_travel": float(np.nanmax(np.abs(travel))),
            "decon_n_episodes": len(episodes),
            "decon_episode_bounds": [[a + 1, b + 1] for a, b in episodes],
            "decon_episode_labels": [labels[a] or "unlabelled"
                                     for a, _ in episodes],
            "decon_reference_epochs": [names[a] for a, _ in episodes],
            "photodiode_flagged_epochs": [
                p.name for p in products if "photodiode" in p.steps
                and not np.isfinite(p.steps["photodiode"]).all()],
        }
        first = products[0]
        out.update({
            "product_kind": first.attr("product_kind"),
            "product_stage": first.attr("stage"),
            "bin_factor": int(first.attrs.get("bin_factor", -1)),
            "calibration_schema": int(first.schema),
            # Not "photodiode_source": the digests' key of that name says which
            # h5 group the DIGEST read the photodiode from, a property of that
            # run; the product's attribute of the same name says how stage 1
            # formed pd_net. Same name, different quantity.
            "acm_move_min_delta_lvdt": float(first.attrs.get("acm_move_min_delta",
                                                             np.nan)),
        })
        # The deploy is the first move whose LVDT crosses zero (stowed is
        # positive), the same rule the pipeline classifies by.
        deploys = [e for e in moves if lvdt[e - 1] > 0 > lvdt[e]]
        out["acm_deploy_detected"] = bool(deploys)
        if deploys:
            e = deploys[0]
            out.update({"acm_deploy_epoch": names[e],
                        "acm_deploy_epoch_index": e + 1,
                        "acm_deploy_lvdt_before": float(lvdt[e - 1]),
                        "acm_deploy_lvdt_after": float(lvdt[e]),
                        "acm_deploy_delta_lvdt": float(lvdt[e] - lvdt[e - 1])})
        _, solution_meta = first.bridge_solution()
        if any(_get(r, "kind") == "side" for r in rows):
            count = len({_get(r, "boundary_utc") for r in rows
                         if _get(r, "kind") == "side"})
            out["side_bridge_degree"] = [int(solution_meta.get(
                "side_bridge_degree", -1))] * count
            out["side_bridge_window_hours"] = [float(solution_meta.get(
                "side_bridge_window_hours", np.nan))] * count
        side = products[0].step_attrs.get("side_bridge", {})
        if "ground_b_side_corrections" in side and len(
                {p.attr("mce_side") for p in products}) > 1:
            out["side_bridge_ground_inverse_b_side"] = [
                float(1.0 / v) for v in side["ground_b_side_corrections"]]
        gain = products[0].step_attrs.get("tempgain")
        if gain is not None:
            out.update({
                "tempgain_model": _text(gain.get("model", "")),
                "tempgain_model_sha256": _text(gain.get("model_sha256", "")),
                "tempgain_form": _text(gain.get("model_form", "")),
                "tempgain_mnemonic": _text(gain.get("temperature_mnemonic", "")),
            })
            if sca is not None:
                j = self.sca_names.index(sca)
                out["tempgain_reference_multiplier"] = [
                    float(v) for v in products[0].steps["tempgain"][:, j]]
        return out

    def to_ecsv(self, out_dir, steps=None, exclude=None, gauge="first"):
        """One ``time_series_<SCA>.ecsv`` per SCA. Needs astropy.

        With the defaults, digest-shaped: every pipeline column and the bridge
        meta. With ``steps``/``exclude`` given, only time and the ``LEDx``
        columns for that choice of steps.
        """
        from astropy.table import Table

        os.makedirs(out_dir, exist_ok=True)
        written = []
        custom = steps is not None or exclude is not None
        if custom:
            series = self.series(steps, exclude or (), gauge)
            chosen = self.products[0].resolve(steps, exclude or ())
        for sca in self.sca_names:
            table = Table()
            if custom:
                table["time_hours"] = self.hours
                table["timestamp"] = [p.timestamp.isoformat()
                                      for p in self.products]
                for i, led in enumerate(LED_NAMES):
                    table[led] = series[sca][:, i]
                table.meta["steps_applied"] = chosen
                table.meta["gauge"] = gauge
            else:
                for name, values in self.digest(sca).items():
                    table[name] = values
                table.meta.update(self.set_meta(sca))
                table.meta.update(self.bridge_meta(sca))
                table.meta["steps_applied"] = self.products[0].resolve(
                    None, DIGEST_EXCLUDE)
            table.meta["sca_name"] = sca
            table.meta["epoch_files"] = [p.name for p in self.products]
            table.meta["source"] = "rcs_trend_reader.py, from the h5 products alone"
            path = os.path.join(out_dir, f"time_series_{sca}.ecsv")
            table.write(path, format="ascii.ecsv", overwrite=True)
            written.append(path)
        return written

    def compare(self, digest_dir, out=print):
        """Every column and bridge meta key against a pipeline digest set.

        Returns the worst absolute difference over everything numeric. The
        reader and the digests reduce the same pixels the same way, so the
        expectation is round-off; anything larger names its column.
        """
        from astropy.table import Table

        worst, report = 0.0, {}
        for sca in self.sca_names:
            path = os.path.join(digest_dir, f"time_series_{sca}.ecsv")
            if not os.path.exists(path):
                out(f"  {sca}: no digest")
                continue
            digest = Table.read(path, format="ascii.ecsv")
            mine = self.digest(sca)
            missing = [c for c in digest.colnames if c not in mine]
            extra = [c for c in mine if c not in digest.colnames]
            if missing or extra:
                out(f"  {sca}: columns only in the digest {missing}, only "
                    f"here {extra}")
            for name in digest.colnames:
                if name not in mine:
                    continue
                theirs = digest[name]
                if name == "timestamp":
                    theirs = np.array([str(t)[:19] for t in theirs.isot])
                    same = np.array_equal(theirs, np.array(
                        [t[:19] for t in mine[name]]))
                    report[name] = max(report.get(name, 0.0), 0.0 if same else 1.0)
                    continue
                theirs = np.asarray(theirs)
                if theirs.dtype.kind in "USO":
                    same = np.array_equal(theirs.astype(str),
                                          np.asarray(mine[name]).astype(str))
                    report[name] = max(report.get(name, 0.0), 0.0 if same else 1.0)
                    continue
                diff = float(np.nanmax(np.abs(np.asarray(theirs, dtype=float)
                                              - np.asarray(mine[name], dtype=float))))
                report[name] = max(report.get(name, 0.0), diff)
            for key, value in {**self.set_meta(sca),
                               **self.bridge_meta(sca)}.items():
                if key not in digest.meta:
                    report[f"meta:{key}"] = float("inf")
                    continue
                theirs = digest.meta[key]
                try:
                    a = np.asarray(theirs, dtype=float)
                    b = np.asarray(value, dtype=float)
                    diff = (float(np.nanmax(np.abs(a - b))) if a.size else 0.0)
                    if np.isnan(a).sum() != np.isnan(b).sum():
                        diff = float("inf")
                except (TypeError, ValueError):
                    diff = 0.0 if [str(v) for v in np.atleast_1d(theirs)] == \
                        [str(v) for v in np.atleast_1d(value)] else 1.0
                report[f"meta:{key}"] = max(report.get(f"meta:{key}", 0.0), diff)
        for name, diff in report.items():
            worst = max(worst, diff)
            out(f"  {name:38s} max |diff| {diff:.3e}")
        out(f"worst over {len(report)} columns and meta keys: {worst:.3e}")
        return worst, report

    # -- figures --------------------------------------------------------------

    def _boundaries(self):
        """``[(index, label)]``: where the ACM segment changes, and what it is."""
        segments = [int(p.attrs.get("acm_segment", -1)) for p in self.products]
        sides = [p.attr("mce_side") for p in self.products]
        out = []
        for e in range(1, len(segments)):
            if segments[e] != segments[e - 1]:
                out.append((e, f"MCE {sides[e - 1]}->{sides[e]}"
                            if sides[e] != sides[e - 1] else "ACM move"))
        return out

    def plot_led(self, led, out_path, corrected=False, frame=None):
        """One LED, every SCA, against date: the digests' figure, from the h5.

        ``corrected=True`` draws the response with the temperature gain change
        removed, i.e. the digests' ``LEDx_tgcorr``. ``frame`` fixes the y
        limits; :meth:`plot_pair` passes one shared frame so the two figures
        blink.
        """
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.dates as mdates
        import matplotlib.pyplot as plt

        index = LED_NAMES.index(led)
        column = f"{led}_tgcorr" if corrected else led
        dates = [p.timestamp for p in self.products]
        n = len(self.sca_names)
        cmap = plt.get_cmap("viridis")
        figure, axis = plt.subplots(figsize=(11.0, 6.0))
        for e, label in self._boundaries():
            axis.axvspan(dates[e - 1], dates[e], color="#f0efec", zorder=1,
                         linewidth=0)
            axis.annotate(label, xy=(dates[e - 1] + (dates[e] - dates[e - 1]) / 2,
                                     0.02),
                          xycoords=("data", "axes fraction"), rotation=90,
                          ha="center", va="bottom", fontsize=9, color="#8a8983")
        for k, sca in enumerate(self.sca_names):
            values = self.digest(sca)[column] if corrected else \
                self.series(exclude=DIGEST_EXCLUDE)[sca][:, index]
            axis.plot(dates, values, color=cmap(k / max(n - 1, 1)),
                      linewidth=2.2, zorder=3)
        if frame is not None:
            axis.set_ylim(frame)
        locator = mdates.AutoDateLocator()
        axis.xaxis.set_major_locator(locator)
        axis.xaxis.set_major_formatter(mdates.ConciseDateFormatter(locator))
        axis.set_xlabel("date (UTC)")
        axis.set_ylabel("response / first epoch")
        form = _text(self.products[0].step_attrs.get("tempgain", {}).get(
            "model_form", ""))
        axis.set_title(f"{led} relative response, all {n} SCAs"
                       + (f" -- provisional temperature gain removed ({form})"
                          if corrected else "")
                       + "  [rcs_trend_reader]")
        axis.grid(alpha=0.3)
        mappable = plt.cm.ScalarMappable(cmap=cmap,
                                         norm=plt.Normalize(vmin=1, vmax=n))
        mappable.set_array([])
        bar = figure.colorbar(mappable, ax=axis, pad=0.015)
        bar.set_label("SCA")
        bar.set_ticks(range(1, n + 1))
        figure.tight_layout()
        if corrected:
            # After tight_layout, so the footnote cannot move the axes and
            # break the blink -- as the pipeline's figure does it.
            ratio = self._step_ratio("tempgain")[:, index, :]
            figure.text(0.008, 0.008,
                        f"gain applied: {100 * (np.nanmin(ratio) - 1):+.2f}% to "
                        f"{100 * (np.nanmax(ratio) - 1):+.2f}%; blink against "
                        f"time_series_{led}_all_scas.png, identical axes",
                        fontsize=8, va="bottom", ha="left")
        figure.savefig(out_path, dpi=150, facecolor="#ffffff")
        plt.close(figure)
        return out_path

    def shared_frame(self, led, margin=0.05):
        """The y limits spanning both the delivered and the gain-corrected curves."""
        index = LED_NAMES.index(led)
        values = [self.series(exclude=DIGEST_EXCLUDE)[sca][:, index]
                  for sca in self.sca_names]
        if "tempgain" in self.products[0].steps:
            values += [self.digest(sca)[f"{led}_tgcorr"] for sca in self.sca_names]
        values = np.concatenate(values)
        low, high = float(np.nanmin(values)), float(np.nanmax(values))
        pad = margin * (high - low) or margin
        return low - pad, high + pad

    def plot_pair(self, led, out_dir):
        """``time_series_<LED>_all_scas{,_tgcorr}.png`` on one y frame, to blink."""
        os.makedirs(out_dir, exist_ok=True)
        frame = self.shared_frame(led)
        written = [self.plot_led(led, os.path.join(
            out_dir, f"time_series_{led}_all_scas.png"), frame=frame)]
        if "tempgain" in self.products[0].steps:
            written.append(self.plot_led(led, os.path.join(
                out_dir, f"time_series_{led}_all_scas_tgcorr.png"),
                corrected=True, frame=frame))
        return written


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------

def _split(value):
    return tuple(v.strip() for v in value.split(",") if v.strip()) if value else ()


def main(argv=None):
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--self-test", action="store_true", dest="self_test")
    sub = parser.add_subparsers(dest="command")
    summary = sub.add_parser("summary", help="key numbers for one product")
    summary.add_argument("file")
    factors = sub.add_parser("factors", help="the (LED, SCA) multiplier table")
    factors.add_argument("file")
    bridges = sub.add_parser("bridges", help="the bridge solution a product embeds")
    bridges.add_argument("file")
    steps = sub.add_parser("steps", help="which steps each product records")
    steps.add_argument("directory")
    trend = sub.add_parser("trend", help="per-SCA time series over a directory")
    trend.add_argument("directory")
    for command in (factors, trend):
        command.add_argument("--steps", default=None,
                             help="comma list of steps to apply; default all "
                                  "recorded")
        command.add_argument("--exclude", default=None,
                             help="comma list of steps to leave out, e.g. "
                                  "tempgain")
    trend.add_argument("--gauge", choices=("first", "absolute"), default="first")
    trend.add_argument("--ecsv", default=None,
                       help="write ECSVs here: digest-shaped by default, or "
                            "just LEDx for an explicit --steps/--exclude")
    trend.add_argument("--plot", default=None,
                       help="write the per-LED blink pairs into this directory")
    compare = sub.add_parser("compare",
                             help="check this reader against a digest set")
    compare.add_argument("directory")
    compare.add_argument("digest_dir")
    args = parser.parse_args(argv)

    if args.self_test:
        return 0 if self_test() else 1
    if args.command == "summary":
        RcsProduct(args.file).summary()
    elif args.command == "factors":
        product = RcsProduct(args.file)
        chosen = product.resolve(_split(args.steps) or None,
                                 _split(args.exclude))
        grid = product.multiplier(_split(args.steps) or None,
                                  _split(args.exclude))
        print(f"{product.run_label}: product of {', '.join(chosen) or 'nothing'}")
        print(f"{'SCA':>6}" + "".join(f"{led:>10}" for led in LED_NAMES))
        for j, sca in enumerate(product.sca_names):
            print(f"{sca:>6}" + "".join(f"{grid[i, j]:10.6f}"
                                        for i in range(len(LED_NAMES))))
    elif args.command == "bridges":
        rows, meta = RcsProduct(args.file).bridge_solution()
        if not rows:
            print("no bridge solution in this product")
            return 1
        print(f"bridge solution {_text(meta.get('solution', ''))} "
              f"(sha {_text(meta.get('solution_sha256', ''))[:12]}); value "
              f"multiplies every epoch before boundary_utc")
        for kind in ("side", "acm"):
            chosen = [r for r in rows if r["kind"] == kind]
            for utc in sorted({r["boundary_utc"] for r in chosen}):
                at = [r for r in chosen if r["boundary_utc"] == utc]
                head = at[0]
                print(f"\n{kind} step at epoch {head['boundary_index']} "
                      f"({head['boundary_run_label']}), {head['transition']}, "
                      f"{utc[:16]} UTC")
                if kind == "side":
                    print(f"  pattern test {head['pattern_rms'] * 1e5:.1f}e-5 vs "
                          f"{head['pattern_noise'] * 1e5:.1f}e-5 from noise")
                    for r in at:
                        print(f"  {r['led']}: {r['value']:.5f} +- "
                              f"{r['total_error']:.5f} (stat {r['stat_error']:.5f}"
                              f", SCA scatter {r['sca_scatter_error']:.5f}, syst "
                              f"{r['systematic']:.5f})")
                else:
                    values = np.array([r["value"] for r in at])
                    methods = sorted({r["method"] for r in at})
                    print(f"  {len(at)} SCAs, {values.min():.5f}-"
                          f"{values.max():.5f}, method(s) {'+'.join(methods)}")
    elif args.command == "steps":
        trend = RcsTrend(args.directory)
        print(f"{len(trend.products)} product(s), in time order")
        for product in trend.products:
            print(f"  {product.run_label:34s} {product.timestamp:%Y-%m-%dT%H:%M}"
                  f"  side {product.attr('mce_side'):1s}  "
                  f"{', '.join(product.steps)}")
    elif args.command == "trend":
        trend = RcsTrend(args.directory)
        explicit = args.steps is not None or args.exclude is not None
        chosen = _split(args.steps) or None
        exclude = _split(args.exclude) if explicit else DIGEST_EXCLUDE
        print(f"{len(trend.products)} epochs; LEDx applies "
              f"{', '.join(trend.products[0].resolve(chosen, exclude))}")
        if args.ecsv:
            written = (trend.to_ecsv(args.ecsv, chosen, exclude, args.gauge)
                       if explicit else trend.to_ecsv(args.ecsv))
            print(f"wrote {len(written)} ECSV(s) to {args.ecsv}")
        if args.plot:
            count = sum(len(trend.plot_pair(led, args.plot)) for led in LED_NAMES)
            print(f"wrote {count} figure(s) to {args.plot}")
        if not (args.ecsv or args.plot):
            series = trend.series(chosen, exclude, args.gauge)
            print(f"{'epoch':34s}" + "".join(f"{led:>10}" for led in LED_NAMES)
                  + "   (SCA median)")
            for e, product in enumerate(trend.products):
                row = np.nanmedian(np.stack([series[s][e] for s in series]), axis=0)
                print(f"{product.run_label:34s}"
                      + "".join(f"{v:10.5f}" for v in row))
    elif args.command == "compare":
        worst, _ = RcsTrend(args.directory).compare(args.digest_dir)
        return 0 if worst < 1e-9 else 1
    else:
        parser.print_help()
        return 2
    return 0


def self_test():
    """Synthetic products only; no network, nothing from the pipeline."""
    import ast
    import tempfile

    import h5py

    def report(name):
        print(f"  ok   {name}")

    # Free-standing is the point of this file, so it is tested, not promised.
    tree = ast.parse(open(__file__).read())
    imported = {alias.name.split(".")[0] for node in ast.walk(tree)
                if isinstance(node, ast.Import) for alias in node.names}
    imported |= {node.module.split(".")[0] for node in ast.walk(tree)
                 if isinstance(node, ast.ImportFrom) and node.module}
    allowed = {"argparse", "ast", "datetime", "glob", "os", "re", "sys",
               "tempfile", "numpy", "h5py", "astropy", "matplotlib"}
    assert imported <= allowed, f"non-standalone imports: {imported - allowed}"
    report("imports only numpy, h5py, the standard library and (lazily) "
           "astropy/matplotlib")

    def write(path, stamp, value, steps, side="A", segment=0, decon="decon2"):
        with h5py.File(path, "w") as handle:
            handle.attrs.update({"calibration_schema": 2, "run_label":
                                 os.path.basename(path)[:-7], "mce_side": side,
                                 "mce_side_source": "test", "pass_number": 7,
                                 "car_label": "CAR190", "decon_cycle": decon,
                                 "acm_segment": segment})
            handle["dictionary/timestamp"] = stamp
            handle["dictionary/ACM_LVDT"] = np.array([-2815.0, np.nan] + [-2815.0] * 4)
            for led in LED_NAMES:
                handle[f"sca_arrays/{led}"] = np.full((18, 4, 4), value,
                                                      dtype=np.float32)
            calibration = handle.create_group("calibration")
            # Stored in REVERSED SCA order, so a reader that trusted the
            # layout instead of the labels would transpose the detectors.
            calibration["led_name"] = np.array(LED_NAMES, dtype="S")
            calibration["sca"] = np.arange(18, 0, -1)
            total = np.ones((6, 18))
            for name, grid in steps.items():
                calibration[f"{name}/multiplier"] = grid[:, ::-1]
                if name != "tempgain":
                    total = total * grid
            calibration["total_multiplier"] = total[:, ::-1]
            # As a real table is shaped: one ACM row per SCA (only SCA1 here),
            # a side row per LED, and that SCA's own side estimate per LED.
            # Columns a real table also has but this test does not use are
            # left out, which the reader must tolerate.
            kinds = ["acm"] + ["side"] * 6 + ["side_sca"] * 6
            solution = calibration.create_group("bridge_solution")
            solution["kind"] = np.array(kinds, dtype="S")
            solution["sca"] = np.array([1] + [0] * 6 + [1] * 6)
            solution["led"] = np.array(["ALL"] + list(LED_NAMES) * 2, dtype="S")
            solution["value"] = np.array([1.017] + [0.9] * 6 + [0.95] * 6)
            solution["boundary_utc"] = np.array(
                ["2026-09-30T12:00:00+00:00"] * len(kinds), dtype="S")
            solution["method"] = np.array(
                ["bridge"] + ["side"] * 6 + ["pattern_test"] * 6, dtype="S")
            solution.attrs["solution_sha256"] = "f" * 64

    pd_grid = np.repeat(np.linspace(1.0, 1.05, 6)[:, None], 18, axis=1)
    acm_bridge = np.repeat(np.linspace(1.0, 1.017, 18)[None, :], 6, axis=0)
    gain = np.full((6, 18), 1.01)
    with tempfile.TemporaryDirectory() as tmp:
        write(os.path.join(tmp, "E1_cal.h5"), "2026-10-01T00:00:00.0000000",
              100.0, {"photodiode": pd_grid, "acm_bridge": np.ones((6, 18)),
                      "tempgain": gain * 1.02}, segment=1)
        write(os.path.join(tmp, "E0_cal.h5"), "2026-09-30T00:00:00.0000000",
              50.0, {"photodiode": np.ones((6, 18)), "acm_bridge": acm_bridge,
                     "tempgain": gain})
        product = RcsProduct(os.path.join(tmp, "E1_cal.h5"))
        assert np.allclose(product.steps["photodiode"], pd_grid)
        assert product.acm_lvdt == -2815.0
        report("axes are reordered by their labels; the LVDT is a nanmean")
        assert np.allclose(product.multiplier(exclude=("tempgain",)),
                           product.total)
        report("steps compose by multiplying; excluding tempgain reproduces "
               "total_multiplier")
        assert np.allclose(product.stack("LED6", steps=("photodiode",))[3],
                           100.0 * 1.05)
        report("stack() applies the chosen steps per (LED, SCA); raw=True "
               "does not")
        try:
            product.multiplier(steps=("side_bridge",))
        except KeyError:
            report("asking for a step the product does not record raises, "
                   "never returns 1.0")
        else:
            raise AssertionError("an absent step was treated as 1.0")
        rows, meta = product.bridge_solution()
        assert [r["kind"] for r in rows] == ["acm"] + ["side"] * 6 + ["side_sca"] * 6
        report("the embedded bridge solution reads back row by row")

        trend = RcsTrend(tmp)
        assert [p.run_label for p in trend.products] == ["E0", "E1"]
        report("products are ordered by timestamp, not filename")
        series = trend.series(exclude=("tempgain",))
        # SCA18: raw ratio 2, photodiode 1.05 on LED6, ACM bridge 1/1.017
        # relative to the first epoch.
        assert np.allclose(series["SCA18"][1, 5], 2.0 * 1.05 / 1.017)
        assert np.allclose(series["SCA1"][0], 1.0)
        report("series(): 1.0 at the first epoch, then (raw ratio) x "
               "(multiplier ratio)")
        columns = trend.digest("SCA18")
        assert np.allclose(columns["bridge_factor"], [1.0, 1 / 1.017])
        assert np.allclose(columns["tempgain_LED1"], [1.0, 1.02])
        assert np.allclose(columns["LED1_tgcorr"], columns["LED1"] * [1.0, 1.02])
        assert list(columns["acm_segment"]) == [0, 1]
        report("digest(): bridge_factor, tempgain_LEDx and LEDx_tgcorr in the "
               "digests' own gauge")
        meta = trend.bridge_meta("SCA1")
        assert meta["bridge_steps"] == [1.017]
        assert meta["side_bridge_this_sca_steps"][0][0] == 0.95
        report("bridge_meta(): the digests' bridge and side-bridge meta, "
               "from the products alone")
    print("rcs_trend_reader self-test: all passed")
    return True


if __name__ == "__main__":
    sys.exit(main())
