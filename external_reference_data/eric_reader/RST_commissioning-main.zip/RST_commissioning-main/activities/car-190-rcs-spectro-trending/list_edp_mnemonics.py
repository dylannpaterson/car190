"""
Dump the EDP mnemonic dictionary -- or a substring-filtered slice of it -- to
CSV, via ``rcs_edp.mnemonic_metadata``.

This is the fast way to check whether a mnemonic exists in the live flight EDP
before spending a full timeseries query on it. ``WFI_MCU_A/B_MPA_CSENS_FPSSEN_K``
and ``WFI_COBA_WTSC10P_K`` -- both used by ``read_per_sca.HK_COLUMNS`` for TVAC
telemetry -- turned up absent this way; a search for "MPA" or "TEMP" finds no
close match either, so the flight EDP does not yet expose an MPA temperature
mnemonic under any obvious name.

    python list_edp_mnemonics.py                       # full ~20k-row dictionary
    python list_edp_mnemonics.py --pattern WFI_MCE_SRCS # one subsystem's mnemonics
"""
import argparse

import rcs_edp
from trend_housekeeping import load_token


def main():
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--pattern", default="",
                        help="substring filter, e.g. WFI_MCE_SRCS "
                             "(default: none, dumps the whole dictionary)")
    parser.add_argument("--out", default="edp_mnemonics.csv")
    args = parser.parse_args()

    table = rcs_edp.mnemonic_metadata(args.pattern, token=load_token())
    print(f"  {len(table)} mnemonics matching {args.pattern!r}")
    table.to_csv(args.out, index=False)
    print(f"  wrote {args.out}")


if __name__ == "__main__":
    main()
