"""Diagnostics for the temperature-gain / thin-film separation.

The fitting lives in ``fit_temperature_gain``; this module runs the suite of
fits that answer the four questions the exercise was set up to ask, writes the
figures and ECSVs, and prints a verdict block.

The four questions, and which output answers each
-------------------------------------------------
**Is it achromatic?**  ``tempgain_chromaticity.png`` + ``tempgain_per_led.ecsv``.
The per-LED gain is fitted with the gain evaluated at each LED's *own*
temperature, so the intra-epoch thermal ramp cannot masquerade as chromaticity.
The reference for "is this spread real" is not a formal error -- it is the
per-SCA scatter within each LED, which is the only noise estimate here that
includes the systematics.

**How SCA-dependent?**  ``tempgain_per_sca.png`` + ``tempgain_per_sca.ecsv``.
Eighteen independent gain curves, reported as the gain at the hot end where the
lever arm is longest.

**Does it transfer to the decon-1 cooldown?**  ``tempgain_transfer.png`` +
``tempgain_transfer.ecsv``. A held-out test, bracketed between a gain fitted on
decon 1 itself and no gain at all, so the number means something.

**How should it be modelled in calibration?**  The verdict block, informed by
``tempgain_robustness.png``: whether the answer survives relaxing constant
growth, changing the polynomial degree, and splitting the set.

The honesty caveat that governs every number here
-------------------------------------------------
chi2/dof is ~35, not ~1. The model is deliberately incomplete -- linearised
film, strictly polynomial growth, no AOI projection, no LED bandwidth, no real
Fresnel -- so the residual is dominated by model error, not noise. Formal
parameter errors from the Jacobian would therefore be meaningless and are not
quoted. Every uncertainty reported here is instead *empirical*: the spread of
the same quantity across detectors, across model variants, and across halves of
the set. Read those as the error bar.
"""
import os
import time

# Imported before numpy on purpose: this module pins the BLAS thread count,
# and the pools are sized when numpy is first imported, so importing numpy
# above it would silently undo the pinning and leave the per-detector parallel
# fits oversubscribing the node. See its import block for why.
import fit_temperature_gain as tg                         # isort: skip
import numpy as np                                        # noqa: E402

import rcs_trend_config as cfg
from housekeeping_trends import (LED_COLORS, LED_MARKERS, T_NOMINAL_K, _save)

# The hot end of the sampled range, where the gain's lever arm is longest and
# the per-LED / per-SCA comparison is least degenerate. Defined alongside the
# model so the fitter and the report cannot drift apart on it.
T_HOT_K = tg.T_HOT_K

# Reporting units: the gain is a sub-percent effect, so percent-deviation
# from unity is the readable scale and is used in every axis label.
PCT = 100.0

# The per-SCA growth rate range (nm/h) from the repo's independent rank-1 film
# fit, for reference on the growth figures. Quoted rather than recomputed
# because that fit solves a per-epoch thickness and so measures something
# wider than this one does: its range mixes genuine detector-to-detector
# variation with the per-epoch variation that this model has no term for. A
# rate from here landing inside it is consistent, not confirmatory.
RANK1_RATE_RANGE = (0.4379, 1.0183)


def _pct(gain):
    """Gain as percent deviation from 1."""
    return (np.asarray(gain, float) - 1.0) * PCT


def _pct_err(error):
    """An error *on* the gain, in the same percent units as ``_pct``.

    Separate from ``_pct`` because an uncertainty must not have the 1.0 pinned
    offset subtracted from it -- doing that by accident is how an error bar
    ends up drawn 100 percentage points long.
    """
    return np.asarray(error, float) * PCT


def led_wavelengths(led_names):
    return np.array([cfg.LED_WAVELENGTHS[n].to_value("nm") for n in led_names])


# --------------------------------------------------------------- the fit suite

def run_fits(data, degree=2, quiet=False, t_nominal=T_NOMINAL_K, modes=None):
    """Every fit the report needs, in one place so the log is a single block.

    ``t_nominal`` and ``degree`` reach these headline fits and the episode
    transfer, and nothing else. The robustness variants below are pinned on
    purpose: each one exists to change exactly *one* assumption against a fixed
    baseline, so taking a CLI knob there would make the comparison read a
    different model in two columns at once.
    """
    out = {}
    for mode in (modes or tg.GAIN_MODES):
        t0 = time.time()
        out[mode] = tg.fit(data, mode=mode, degree=degree,
                           t_nominal=t_nominal, quiet=quiet)
        out[mode]["seconds"] = time.time() - t0
    return out


def robustness_suite(data, quiet=False):
    """Variants that test whether the headline gain is a modelling artefact.

    Each entry changes one assumption. The gain at ``T_HOT_K`` is the single
    number compared across them: if it moves by more than the per-SCA scatter,
    the headline is model-dependent and should be quoted with that wider bar.
    """
    variants = []

    def add(label, note, result, subset=None):
        variants.append(dict(label=label, note=note, result=result,
                             gain_hot=float(tg.gain_at(result, T_HOT_K)),
                             rate=result["rate"], chi2_red=result["chi2_red"],
                             bic=result["bic"], n_data=result["n_data"],
                             subset=subset or "all"))

    add("baseline", "gain deg 2, growth deg 1 (constant growth)",
        tg.fit(data, mode="shared", degree=2, quiet=quiet))
    add("gain_deg1", "gain linear in T -- is curvature needed?",
        tg.fit(data, mode="shared", degree=1, quiet=quiet))
    add("gain_deg3", "gain cubic in T -- does the curve run away?",
        tg.fit(data, mode="shared", degree=3, quiet=quiet))
    add("growth_deg2", "film growth quadratic -- rank-1 says rate varies 2.3x",
        tg.fit(data, mode="shared", degree=2, growth_degree=2, quiet=quiet))
    add("growth_deg3", "film growth cubic -- the stress test on constant growth",
        tg.fit(data, mode="shared", degree=2, growth_degree=3, quiet=quiet))

    # Split halves. Interleaved rather than first-half/second-half, because a
    # contiguous split puts the whole cooldown in one half and leaves the other
    # with no temperature lever at all -- it would fail for the wrong reason.
    order = np.argsort(data.hours)
    for label, pick in (("epochs_even", order[::2]), ("epochs_odd", order[1::2])):
        half = tg.Dataset(
            data.response[:, :, np.sort(pick)], data.temperature[np.sort(pick)],
            data.tau[np.sort(pick)], data.episode[np.sort(pick)], data.sigma,
            data.hours[np.sort(pick)], data.sca_names, data.led_names,
            [data.epoch_files[i] for i in np.sort(pick)], data.meta)
        add(label, "interleaved half of the epochs -- is it stable in time?",
            tg.fit(half, mode="shared", degree=2, quiet=quiet), subset=label)

    # Drop the hottest epochs. If the gain is really a smooth function of T,
    # removing the extreme lever should widen the error but not move the curve.
    warm = data.temperature.mean(axis=1) < 110.0
    if warm.sum() > 40:
        cool = tg.Dataset(
            data.response[:, :, warm], data.temperature[warm], data.tau[warm],
            data.episode[warm], data.sigma, data.hours[warm], data.sca_names,
            data.led_names, [n for n, k in zip(data.epoch_files, warm) if k],
            data.meta)
        add("drop_hot", "T < 110 K only -- extrapolated to 124 K",
            tg.fit(cool, mode="shared", degree=2, quiet=quiet),
            subset="T<110K")
    return variants


def chromaticity_growth_test(data, degrees=(1, 2, 3), quiet=True):
    """Per-band gain as the film is given progressively more freedom.

    This is the test that decides whether an apparently chromatic gain is
    real. ``k = 2 pi n / lambda`` makes the shortest band's fringe the fastest,
    so the shortest band is the one most exposed to error in the growth model
    -- and the user's starting assumption, strictly constant growth, is known
    to be wrong (the repo's rank-1 fit finds the rate varying 2.3x within an
    episode). If a band's excess gain *shrinks* as growth is relaxed, that
    excess was film-model error being absorbed by the gain term; if it holds
    still while chi2 improves, it is a property of the detector.

    Reported per band rather than as a single spread, because the spread alone
    cannot distinguish one outlier band from a wavelength trend, and those two
    have completely different consequences for calibration.
    """
    rows = []
    for growth_degree in degrees:
        result = tg.fit(data, mode="per-led", degree=2,
                        growth_degree=growth_degree, quiet=quiet)
        hot = np.array([float(tg.gain_at(result, T_HOT_K, group=i))
                        for i in range(len(data.led_names))])
        rows.append(dict(growth_degree=growth_degree, gain_hot=hot,
                         rate=result["rate"], chi2_red=result["chi2_red"],
                         d_end=result["d_end"]))
    return rows


def growth_structure(data, shared=None, processes=None, n_permute=20000,
                     seed=0, quiet=True):
    """Does the film grow at one rate? And does the gain care if it does not?

    Three claims are separable here and they do not come out the same way, so
    they are measured separately rather than as one "is the growth variable"
    question:

    *per detector*  each detector gets its own rate, everything else as the
                    baseline. The rate does vary across the focal plane.
    *per decon*     each detector gets a rate per decon episode. This is the
                    larger effect by a wide margin -- a decon does not just
                    reset the fringe phase, it resets the growth rate.
    *dispersion*    a spread of rates *within* a detector, which damps the
                    fringe as ``exp(-2 k^2 sigma_d^2)`` rather than shifting
                    its phase. Fitted last and reported as a limit, because it
                    is degenerate with growth curvature (see ``curvature``
                    below, which fits better at the same parameter count).

    The gain is carried through all of them, because that is the only reason
    the calibration cares: a growth rate that varies while the gain sits still
    is a film result, not a gain result.

    ``corr(rate, gain)`` gets a permutation test *and* a direct check, because
    the permutation test answers the wrong question on its own. A real
    correlation could mean film error is leaking into the gain -- but the test
    for that is whether pinning every detector to one rate *changes* the gain
    scatter, and it is possible (and is in fact the case here) for the
    correlation to be significant while the gain barely moves.
    """
    n_sca = data.response.shape[0]
    n_episode = len(np.unique(data.episode))
    if shared is None:
        shared = tg.fit(data, mode="shared", degree=2, quiet=quiet)
    out = dict(shared_rate=float(shared["rate"]),
               shared_chi2_red=float(shared["chi2_red"]),
               rank1_range=RANK1_RATE_RANGE, n_episode=n_episode)

    # Per-SCA gain on a shared rate: the existing scatter, and the control the
    # free-rate scatter has to be compared against.
    pinned = tg.fit(data, mode="per-sca", degree=2, warm_start=shared,
                    quiet=quiet)
    out["gain_hot_shared_rate"] = [float(tg.gain_at(pinned, T_HOT_K, group=s))
                                   for s in range(n_sca)]

    out["independent"] = tg.fit_per_sca(data, degree=2, warm_start=shared,
                                        processes=processes, quiet=quiet)
    out["gain_hot_free_rate"] = out["independent"]["gain_hot"].tolist()
    if n_episode > 1:
        out["per_episode"] = tg.fit_per_sca(
            data, degree=2, growth_mode="per-episode", warm_start=shared,
            processes=processes, quiet=quiet)

    rate = out["independent"]["rate"][:, 0]
    hot_free = _pct(out["gain_hot_free_rate"])
    hot_pinned = _pct(out["gain_hot_shared_rate"])
    r = float(np.corrcoef(rate, hot_free)[0, 1])
    rng = np.random.default_rng(seed)
    null = np.array([np.corrcoef(rng.permutation(rate), hot_free)[0, 1]
                     for _ in range(n_permute)])
    out["rate_gain"] = dict(
        r=r, p_permutation=float((np.abs(null) >= abs(r)).mean()),
        n_permute=int(n_permute), rate=rate.tolist(),
        gain_sd_shared_rate=float(np.std(hot_pinned, ddof=1)),
        gain_sd_free_rate=float(np.std(hot_free, ddof=1)),
        gain_shift_max=float(np.max(np.abs(hot_free - hot_pinned))),
        gain_shift_mean=float(np.mean(hot_free - hot_pinned)))

    # Dispersion against the two things it is degenerate with, at a matched
    # parameter count. Without the matching this comparison is meaningless:
    # any of them will improve chi2 by spending a parameter per detector.
    out["matched"] = {}
    for label, note, kwargs in (
            ("rate", "one rate per detector (1 param/SCA)",
             dict(growth_degree=1)),
            ("dispersion", "rate + intra-detector spread (2/SCA)",
             dict(growth_degree=1, dispersion=True)),
            ("curvature", "quadratic growth in time (2/SCA)",
             dict(growth_degree=2)),
            ("per_episode", "a rate per decon (2/SCA)",
             dict(growth_degree=1, growth_mode="per-episode"))):
        if kwargs.get("growth_mode") == "per-episode" and n_episode < 2:
            continue
        result = tg.fit_per_sca(data, degree=2, warm_start=shared,
                                processes=processes, quiet=quiet, **kwargs)
        row = dict(label=label, note=note, chi2_red=result["chi2_red"],
                   rate_min=float(result["rate"].min()),
                   rate_max=float(result["rate"].max()),
                   gain_mean=float(np.mean(_pct(result["gain_hot"]))),
                   gain_sd=float(np.std(_pct(result["gain_hot"]), ddof=1)))
        if kwargs.get("dispersion"):
            sigma = np.array([float(result["fits"][s]["dispersion"][0])
                              for s in range(n_sca)])
            row["sigma_median"] = float(np.median(sigma))
            # sigma/rate is the number that decides whether this is physical:
            # a spread comparable to the rate itself is not a 30% thickness
            # non-uniformity, it is a degenerate fit.
            row["sigma_over_rate"] = float(np.median(
                sigma / (result["rate"][:, 0] * tg.TAU_SCALE_H)))
        out["matched"][label] = row

    # The honest version of the dispersion number: fit it only after the real
    # growth error (the per-decon rate) has been removed, so it is not just
    # re-measuring that.
    if n_episode > 1:
        result = tg.fit_per_sca(data, degree=2, growth_mode="per-episode",
                                dispersion=True, warm_start=shared,
                                processes=processes, quiet=quiet)
        sigma = np.array([float(result["fits"][s]["dispersion"][0])
                          for s in range(n_sca)])
        rate_h = result["rate"].mean(axis=1) * tg.TAU_SCALE_H
        out["dispersion_after_episode"] = dict(
            sigma=sigma.tolist(), sigma_median=float(np.median(sigma)),
            sigma_over_rate=float(np.median(sigma / rate_h)),
            chi2_red=float(result["chi2_red"]),
            gain_mean=float(np.mean(_pct(result["gain_hot"]))),
            gain_sd=float(np.std(_pct(result["gain_hot"]), ddof=1)))

    if not quiet:
        print(f"  rate per detector {rate.min():.4f}-{rate.max():.4f} nm/h "
              f"(shared {out['shared_rate']:.4f}), chi2/dof "
              f"{out['shared_chi2_red']:.3f} -> "
              f"{out['independent']['chi2_red']:.3f}")
        if "per_episode" in out:
            ratio = (out["per_episode"]["rate"][:, 1]
                     / out["per_episode"]["rate"][:, 0])
            print(f"  decon 2 / decon 1 rate = {np.median(ratio):.4f} median, "
                  f"{int((ratio > 1).sum())}/{n_sca} faster, chi2/dof -> "
                  f"{out['per_episode']['chi2_red']:.3f}")
        print(f"  corr(rate, gain) = {r:+.4f}, p = "
              f"{out['rate_gain']['p_permutation']:.4f}; gain sd "
              f"{out['rate_gain']['gain_sd_shared_rate']:.4f} -> "
              f"{out['rate_gain']['gain_sd_free_rate']:.4f} %, max shift "
              f"{out['rate_gain']['gain_shift_max']:.4f} %")
    return out


# Which freedom each variant adds, which is the axis the result separates on.
# ``curvature`` makes the thickness nonlinear in time; ``placement`` only moves
# a constant rate around in space or across a decon. The two are not
# interchangeable even though both improve chi2.
GROWTH_FREEDOM = (
    ("shared rate", "none", dict()),
    ("growth deg 2", "curvature", dict(growth_degree=2)),
    ("growth deg 3", "curvature", dict(growth_degree=3)),
    ("rate per decon", "placement", dict(growth_mode="per-episode")),
    ("rate per decon + deg 2", "both",
     dict(growth_degree=2, growth_mode="per-episode")),
    ("rate per detector", "placement", dict(growth_mode="per-sca")),
    ("rate per detector+decon", "placement",
     dict(growth_mode="per-sca-episode")),
    ("per detector+decon + deg 2", "both",
     dict(growth_degree=2, growth_mode="per-sca-episode")),
)


def growth_freedom_test(data, processes=None, n_round=4, quiet=True):
    """Which *kind* of film freedom absorbs LED1's excess gain -- and which does not.

    This supersedes ``chromaticity_growth_test`` as the decisive version of
    that test. The earlier one varied only the growth polynomial's degree,
    saw LED1 move toward the other five bands, and read the excess as film
    leakage. Degree is only one of two freedoms, and separating them changes
    the reading: LED1 tracks *curvature* -- a thickness nonlinear in time --
    and is untouched by where a constant rate is *placed*, across the focal
    plane or across a decon, even though placement buys the bigger chi2
    improvement. A single "is the excess film error" verdict cannot be stated
    without naming which freedom was given, which is why the rows are kept.

    The per-detector variants need the alternating fit: a per-LED gain couples
    the detectors, so they cannot simply be fitted one at a time.
    """
    n_episode = len(np.unique(data.episode))
    n_led = len(data.led_names)
    rows = []
    base = None
    for label, freedom, kwargs in GROWTH_FREEDOM:
        mode = kwargs.get("growth_mode", "shared")
        if "episode" in mode and n_episode < 2:
            continue
        if "per-sca" in mode:
            result = tg.fit_alternating(data, mode="per-led", degree=2,
                                        n_round=n_round, processes=processes,
                                        quiet=quiet, **kwargs)
        else:
            result = tg.fit(data, mode="per-led", degree=2,
                            warm_start=base, quiet=quiet, **kwargs)
        hot = _pct([float(tg.gain_at(result, T_HOT_K, group=i))
                    for i in range(n_led)])
        if base is None:
            base = result
        pack = float(np.median(hot[1:]))
        rows.append(dict(label=label, freedom=freedom, hot=hot.tolist(),
                         pack_median=pack, led1_pack=float(hot[0] - pack),
                         spread=float(np.ptp(hot)),
                         chi2_red=float(result["chi2_red"]),
                         growth_degree=kwargs.get("growth_degree", 1),
                         growth_mode=mode))
        if not quiet:
            print(f"  {label:28s} {freedom:10s} chi2/dof="
                  f"{result['chi2_red']:.3f}  LED1-pack "
                  f"{hot[0] - pack:+.3f} %")
    return rows


def film_block_parameters(data, result):
    """Per ``(sca, led, episode)`` fringe amplitude and phase, with errors.

    The amplitude and phase are already free in every fit -- they fall out of
    the closed-form ``(a, b, c)`` solve, with ``A = hypot(b, c)`` and
    ``phi = atan2(c, b)``. What was missing was an *error* on them, without
    which the episode-to-episode comparison cannot be read: the long bands'
    apparent instability turns out to be their fringe coverage, not their
    physics, and only a propagated error says so.

    Two error estimates per block, deliberately both:

    ``sigma_A``       from the design matrix and the series' own noise. This is
                      the measurement error, and it is what tells a weakly
                      covered fringe apart from a well covered one.
    ``sigma_A_scaled``the same inflated by the block's own sqrt(chi2/dof). The
                      model is incomplete (chi2/dof ~ 35 overall), so the
                      unscaled bar is optimistic by design; quoting only the
                      scaled one would instead hide which blocks are badly
                      *covered* as opposed to badly *modelled*.
    """
    growth = np.atleast_2d(result["growth_matrix"])
    growth_groups = result["growth_groups"]
    wavenumber = tg.led_wavenumbers(data.led_names)
    thickness = np.stack([tg.film_thickness(row, data.tau) for row in growth])
    gain = result["gain"]

    rows = []
    for sca, led, episode, ep_index, mask in tg._blocks(data):
        angle = 2.0 * wavenumber[led] * thickness[growth_groups[sca, ep_index]][mask]
        design = np.stack([np.ones_like(angle), np.cos(angle), np.sin(angle)],
                          axis=1) * gain[sca, led, mask][:, None]
        target = data.response[sca, led, mask]
        good = np.isfinite(target) & np.all(np.isfinite(design), axis=1)
        if good.sum() < 6:
            continue
        design, target = design[good], target[good]
        coef, *_ = np.linalg.lstsq(design, target, rcond=None)
        resid = target - design @ coef
        noise = float(data.sigma[sca, led])
        dof = max(good.sum() - 3, 1)
        chi2_red = float(np.sum(resid ** 2) / dof / noise ** 2)
        try:
            cov = np.linalg.inv(design.T @ design) * noise ** 2
        except np.linalg.LinAlgError:
            continue
        a, b, c = coef
        amp = float(np.hypot(b, c))
        if amp <= 0:
            continue
        # dA/db = b/A, dA/dc = c/A; dphi/db = -c/A^2, dphi/dc = b/A^2
        grad_a = np.array([b / amp, c / amp])
        grad_p = np.array([-c / amp ** 2, b / amp ** 2])
        sub = cov[1:, 1:]
        sigma_amp = float(np.sqrt(grad_a @ sub @ grad_a))
        sigma_phase = float(np.sqrt(grad_p @ sub @ grad_p))
        # Phase coverage is the discriminator for whether any of this is
        # measurable at all: below ~1 rad the amplitude and the offset are not
        # separable and the "amplitude" is a fitting artefact.
        rows.append(dict(
            sca=sca, sca_name=str(data.sca_names[sca]), led=led,
            led_name=data.led_names[led], episode=episode,
            offset=float(a), b=float(b), c=float(c), amplitude=amp,
            phase_rad=float(np.arctan2(c, b)),
            sigma_amplitude=sigma_amp, sigma_phase=sigma_phase,
            sigma_amplitude_scaled=sigma_amp * np.sqrt(max(chi2_red, 1.0)),
            sigma_phase_scaled=sigma_phase * np.sqrt(max(chi2_red, 1.0)),
            chi2_red=chi2_red, n_epoch=int(good.sum()),
            phase_span_rad=float(np.ptp(angle[good])),
        ))
    return rows


def film_invariance_test(data, result, quiet=True):
    """Is the fringe amplitude invariant across a decon, with pure phase added?

    The user's physics prior, stated as a test: a layer added on top of an
    existing stack rotates the reflectance phase and leaves ``|r|`` alone, so
    the *amplitude* of the harmonic response should carry across a decon while
    the phase need not. ``r_current = r_prior * exp(2 i k dd)`` has exactly
    that property.

    The naive version of this test -- compare median amplitude ratios by band
    -- reads as a strong wavelength trend and is mostly an artefact. Each
    ratio's error is dominated by how much fringe the episode covers, and
    coverage falls as ``1/lambda``: episode 0 accumulates 3.12 rad at LED1 and
    1.17 rad at LED6. So the long bands' scatter has to be divided out before
    anything is read off it, which is what the pulls below do.
    """
    rows = film_block_parameters(data, result)
    by_key = {(r["sca"], r["led"], r["episode"]): r for r in rows}
    episodes = sorted({r["episode"] for r in rows})
    if len(episodes) < 2:
        return dict(pairs=[], bands=[], verdict="single episode, not testable")

    first, last = episodes[0], episodes[-1]
    pairs = []
    for (sca, led, episode), row in by_key.items():
        if episode != first:
            continue
        other = by_key.get((sca, led, last))
        if other is None:
            continue
        ratio = other["amplitude"] / row["amplitude"]
        # Relative errors add in quadrature for a ratio.
        rel = np.hypot(row["sigma_amplitude_scaled"] / row["amplitude"],
                       other["sigma_amplitude_scaled"] / other["amplitude"])
        delta = np.arctan2(np.sin(other["phase_rad"] - row["phase_rad"]),
                           np.cos(other["phase_rad"] - row["phase_rad"]))
        pairs.append(dict(
            sca=sca, sca_name=row["sca_name"], led=led,
            led_name=row["led_name"], amplitude_ratio=float(ratio),
            sigma_ratio=float(ratio * rel),
            pull=float((ratio - 1.0) / (ratio * rel)) if rel > 0 else np.nan,
            phase_change_deg=float(np.degrees(delta)),
            sigma_phase_change_deg=float(np.degrees(np.hypot(
                row["sigma_phase_scaled"], other["sigma_phase_scaled"]))),
            coverage_rad=min(row["phase_span_rad"], other["phase_span_rad"]),
        ))

    bands = []
    for led in sorted({p["led"] for p in pairs}):
        pick = [p for p in pairs if p["led"] == led]
        ratio = np.array([p["amplitude_ratio"] for p in pick])
        sigma = np.array([p["sigma_ratio"] for p in pick])
        pull = np.array([p["pull"] for p in pick])
        weight = 1.0 / sigma ** 2
        mean = float(np.sum(ratio * weight) / np.sum(weight))
        bands.append(dict(
            led=led, led_name=pick[0]["led_name"], n=len(pick),
            ratio_median=float(np.median(ratio)),
            ratio_weighted=mean,
            ratio_weighted_error=float(1.0 / np.sqrt(np.sum(weight))),
            ratio_sd=float(np.std(ratio, ddof=1)),
            sigma_median=float(np.median(sigma)),
            pull_rms=float(np.sqrt(np.mean(pull ** 2))),
            coverage_rad=float(np.median([p["coverage_rad"] for p in pick])),
            phase_change_median_deg=float(np.median(
                [p["phase_change_deg"] for p in pick])),
            phase_change_sigma_deg=float(np.median(
                [p["sigma_phase_change_deg"] for p in pick])),
        ))

    pull = np.array([p["pull"] for p in pairs])
    pull = pull[np.isfinite(pull)]
    # Invariance is read from the pulls, not the spread: a ratio 1.35 +- 0.40
    # and a ratio 1.10 +- 0.02 say opposite things about the same prior.
    consistent = float(np.sqrt(np.mean(pull ** 2)))
    weighted = np.array([row["ratio_weighted"] for row in bands])
    # Median, not mean, across the bands. A band whose episode happens to
    # cover almost no fringe can return an essentially unbounded ratio, and a
    # mean hands that band the answer -- the noise fixture drives one to 1e6.
    # The prior being tested is that |r| is unchanged in EVERY band, so the
    # centre of the six is the right summary either way.
    out = dict(pairs=pairs, bands=bands, pull_rms=consistent,
               pull_median=float(np.median(pull)), n_pair=len(pairs),
               first_episode=int(first), last_episode=int(last),
               ratio_band_median=float(np.median(weighted)),
               ratio_band_spread=float(np.ptp(weighted)),
               deviation_median=float(np.median(np.abs(weighted - 1.0))))
    if consistent < 2.0:
        out["verdict"] = (
            f"AMPLITUDE INVARIANT: {len(pairs)} (detector, band) pairs have "
            f"amplitude ratios consistent with 1 across the decon, pull RMS "
            f"{consistent:.2f}. The added layer acts as pure phase, as "
            f"expected for r -> r*exp(2ik dd).")
    else:
        worst = max(bands, key=lambda row: abs(row["ratio_weighted"] - 1.0))
        out["verdict"] = (
            f"AMPLITUDE NOT INVARIANT at the statistical error: pull RMS "
            f"{consistent:.2f} over {len(pairs)} pairs; worst band "
            f"{worst['led_name']} at {worst['ratio_weighted']:.3f} +- "
            f"{worst['ratio_weighted_error']:.3f}. The typical band sits "
            f"{100 * out['deviation_median']:.1f}% from 1. Check the "
            f"growth-model systematic before reading this as a violation -- "
            f"the amplitude is degenerate with the rate.")
    if not quiet:
        print(f"  {out['verdict']}")
        for row in bands:
            print(f"    {row['led_name']}: ratio {row['ratio_weighted']:.3f} "
                  f"+- {row['ratio_weighted_error']:.3f} (median "
                  f"{row['ratio_median']:.3f}, sd {row['ratio_sd']:.3f}), "
                  f"pull RMS {row['pull_rms']:.2f}, coverage "
                  f"{row['coverage_rad']:.2f} rad")
    return out


def film_invariance_systematic(data, growth_variants=None, quiet=True):
    """The amplitude-invariance test with the error bar it actually needs.

    ``film_invariance_test`` propagates the *statistical* error on each
    amplitude, and on this set that error (0.2-1.4% per band) is 10-100x
    smaller than the amount the ratio moves when the growth model changes
    (10-35%). Quoting the statistical error alone reports a 5-7 sigma violation
    of the user's pure-phase prior, which is an artefact of leaving the
    dominant error out.

    The reason the ratio is so model-sensitive is the physics of the
    degeneracy: the fringe amplitude and the growth rate trade against each
    other. A wrong rate mis-sets the fringe frequency, and the closed-form
    ``(a, b, c)`` solve absorbs part of that into ``hypot(b, c)``. So the
    amplitude ratio across a decon is only as good as the growth model is on
    both sides of it -- and §5 establishes the growth model is *wrong* with a
    shared rate, by 30%.

    The spread across growth models is therefore the error bar, and the test
    is whether the band-averaged ratio sits at 1 within it. Reported with both
    errors side by side, because the conclusion is as much about which error
    dominates as about the number.
    """
    if growth_variants is None:
        growth_variants = (
            ("shared rate", dict()),
            ("rate per decon", dict(growth_mode="per-episode")),
            ("rate per decon + deg 2",
             dict(growth_mode="per-episode", growth_degree=2)),
            ("growth deg 2", dict(growth_degree=2)),
        )
    n_episode = len(np.unique(data.episode))
    rows = []
    for label, kwargs in growth_variants:
        if kwargs.get("growth_mode") == "per-episode" and n_episode < 2:
            continue
        result = tg.fit(data, mode="shared", degree=2, quiet=True, **kwargs)
        inner = film_invariance_test(data, result)
        if not inner.get("bands"):
            continue
        rows.append(dict(
            label=label, chi2_red=float(result["chi2_red"]),
            ratio=[row["ratio_weighted"] for row in inner["bands"]],
            error=[row["ratio_weighted_error"] for row in inner["bands"]],
            band_median=inner["ratio_band_median"],
            deviation_median=inner["deviation_median"],
            pull_rms=inner["pull_rms"]))
    if not rows:
        return dict(rows=[], verdict="single episode, not testable")

    ratio = np.array([row["ratio"] for row in rows])           # (model, band)
    stat = float(np.median([np.median(row["error"]) for row in rows]))
    # Robust on both axes, for the same reason the band summary is: a single
    # degenerate (model, band) cell must not be able to set the error bar that
    # the verdict then compares against.
    deviation = np.abs(ratio - np.median(ratio, axis=0, keepdims=True))
    systematic = float(np.median(1.4826 * np.median(deviation, axis=0)))
    # The best-fitting growth model is the one to read the central value from,
    # but "best chi2" alone is not enough to trust it with. If a fit drives one
    # episode's fringe amplitude to ~0 the ratio is unbounded, and chi2 does
    # not notice -- on the noise fixture the lowest-chi2 model returns a median
    # band ratio of 1e6. That is a failed amplitude decomposition, not an |r|
    # change of a millionfold, so such a model is barred from supplying the
    # central value and the exclusion is reported rather than silent. The
    # bracket is loose on purpose: the prior and any physical violation of it
    # both live within tens of percent, nowhere near a factor of 10.
    usable = [row for row in rows if 0.1 < row["band_median"] < 10.0]
    degenerate = [row["label"] for row in rows if row not in usable]
    best = min(usable or rows, key=lambda row: row["chi2_red"])
    out = dict(rows=rows, stat_error=stat, systematic_error=systematic,
               best_label=best["label"], band_median=best["band_median"],
               deviation_median=best["deviation_median"],
               n_model=len(rows), n_band=ratio.shape[1],
               degenerate=degenerate)
    # Summarised across the bands, because a per-band shift is what a rate
    # error produces (through the k-dependence) while a genuine |r| change
    # would be common to all six.
    offset = abs(best["band_median"] - 1.0)
    if systematic > 3.0 * stat:
        lead = (f"the growth model moves the ratio by {systematic:.3f}, "
                f"{systematic / stat:.0f}x the statistical error "
                f"{stat:.3f}, so the statistical pull is not the test")
    else:
        lead = (f"statistical error {stat:.3f} dominates the "
                f"{systematic:.3f} growth-model spread")
    if offset < max(systematic, 2.0 * stat):
        out["verdict"] = (
            f"AMPLITUDE INVARIANT within the dominant error: {lead}. Under the "
            f"best growth model ({best['label']}, chi2/dof "
            f"{best['chi2_red']:.2f}) the median band ratio is "
            f"{best['band_median']:.4f}, i.e. 1 to {100 * offset:.2f}%. The "
            f"per-band scatter of {100 * best['deviation_median']:.1f}% is "
            f"two-sided and does not survive a change of growth model, so it "
            f"is rate degeneracy, not an |r| change.")
    else:
        out["verdict"] = (
            f"AMPLITUDE NOT INVARIANT: {lead}, and the median band ratio is "
            f"still {best['band_median']:.4f} under the best growth model. A "
            f"common offset in every band is what an |r| change looks like.")
    if degenerate:
        out["verdict"] += (
            f" NOTE: {len(degenerate)} of {len(rows)} growth models "
            f"({', '.join(degenerate)}) drove an episode amplitude to ~0 and "
            f"returned an unbounded ratio; they are excluded from the central "
            f"value because that is a failed decomposition, not a measurement."
        )
    if not quiet:
        print(f"  {out['verdict']}")
        for row in rows:
            print(f"    {row['label']:24s} chi2/dof {row['chi2_red']:7.3f}  "
                  f"band median {row['band_median']:.4f}  median |ratio-1| "
                  f"{100 * row['deviation_median']:5.1f}%  ratios "
                  + " ".join(f"{v:.3f}" for v in row["ratio"]))
    return out


def plot_chromaticity_growth(data, rows, path, dpi=120):
    """Is the band spread a detector property or a film-model artefact?"""
    import matplotlib.pyplot as plt

    lam = led_wavelengths(data.led_names)
    degrees = [r["growth_degree"] for r in rows]
    figure, axes = plt.subplots(1, 2, figsize=(12.6, 4.9))

    axis = axes[0]
    for index, name in enumerate(data.led_names):
        values = [_pct(r["gain_hot"][index]) for r in rows]
        axis.plot(degrees, values, LED_MARKERS[index] + "-", ms=9, lw=1.7,
                  color=LED_COLORS[index],
                  label=f"{name} ({lam[index]:.0f} nm)")
    # Legend only, no direct labels: the whole point of the panel is that five
    # of the six bands sit on top of each other, so end-of-line labels for all
    # six necessarily collide -- LED3 and LED5 overprinted. The legend carries
    # identity and the distinct markers carry it again at the marks.
    axis.set_xticks(degrees)
    axis.set_xlabel("film growth polynomial degree (1 = constant growth)")
    axis.set_ylabel(f"gain deviation at {T_HOT_K:g} K (%)")
    axis.set_title("A band whose gain moves when the film is freed\n"
                   "was absorbing film-model error", fontsize=11)
    axis.legend(fontsize=7.5, frameon=False, loc="center right", ncol=1)

    axis = axes[1]
    full = [float(np.ptp(r["gain_hot"])) for r in rows]
    median = [float(np.ptp(np.delete(
        r["gain_hot"], int(np.argmax(np.abs(
            r["gain_hot"] - np.median(r["gain_hot"]))))))) for r in rows]
    axis.plot(degrees, _pct_err(np.array(full)), "o-", ms=9, lw=1.8,
              color="#eb6834", label="all six bands")
    axis.plot(degrees, _pct_err(np.array(median)), "s-", ms=9, lw=1.8,
              color="#1baf7a", label="excluding the outlier band")
    for index, row in enumerate(rows):
        axis.annotate(f"chi2/dof {row['chi2_red']:.1f}\nrate "
                      f"{row['rate']:.3f} nm/h",
                      xy=(degrees[index], _pct_err(full[index])),
                      xytext=(-16, 14), textcoords="offset points",
                      fontsize=7.5, color="#4b5563")
    axis.set_xticks(degrees)
    axis.set_ylim(bottom=0.0)
    axis.set_xlabel("film growth polynomial degree (1 = constant growth)")
    axis.set_ylabel(f"band-to-band spread at {T_HOT_K:g} K (%)")
    axis.set_title("Band spread against film freedom", fontsize=11)
    axis.legend(fontsize=8, frameon=False, loc="center right")
    for axis in axes:
        for spine in ("top", "right"):
            axis.spines[spine].set_visible(False)
    figure.tight_layout()
    _save(figure, path, dpi)


# ------------------------------------------------------------------- the plots

def plot_curve(data, fits, nonparam, path, dpi=120):
    """The headline: G(T), with the model-light check and the per-SCA family."""
    import matplotlib.pyplot as plt

    shared, per_sca = fits["shared"], fits["per-sca"]
    probe = np.linspace(T_NOMINAL_K, np.nanmax(data.temperature), 240)
    figure, axes = plt.subplots(1, 2, figsize=(12.4, 4.9))

    axis = axes[0]
    for index in range(per_sca["n_group"]):
        axis.plot(probe, _pct(tg.gain_at(per_sca, probe, group=index)),
                  color="#9aa5b1", lw=1.0, alpha=0.75, zorder=1,
                  label="per detector" if index == 0 else None)
    axis.plot(probe, _pct(tg.gain_at(shared, probe)), color="#2a78d6", lw=2.0,
              zorder=4, label="shared (achromatic) fit")
    centre, value, error, _count = nonparam
    axis.errorbar(centre, _pct(value), yerr=_pct_err(error), fmt="o",
                  ms=8, color="#111827", mfc="#ffffff", mew=1.6, lw=1.4,
                  capsize=0, zorder=5, label="binned common mode (no gain model)")
    axis.axhline(0.0, color="#6b7280", lw=1.0, ls=":", zorder=2)
    axis.axvline(T_NOMINAL_K, color="#6b7280", lw=1.0, ls="--", zorder=2)
    # Opaque background: this sits in the densest part of the panel, where all
    # eighteen detector curves converge on the pinned point, and unbacked text
    # there reads as truncated rather than as overlapped.
    axis.annotate(f"nominal {T_NOMINAL_K:g} K\nG = 1 by construction",
                  xy=(T_NOMINAL_K, 0.0), xytext=(6, -38),
                  textcoords="offset points", fontsize=8, color="#4b5563",
                  zorder=6,
                  bbox=dict(boxstyle="round,pad=0.28", fc="#ffffff",
                            ec="none", alpha=0.85))
    hot = float(tg.gain_at(shared, T_HOT_K))
    axis.annotate(f"{_pct(hot):+.2f}% at {T_HOT_K:g} K",
                  xy=(T_HOT_K, _pct(hot)), xytext=(-104, 6),
                  textcoords="offset points", fontsize=9, color="#2a78d6",
                  fontweight="bold")
    axis.set_xlabel("MPA temperature (K)")
    axis.set_ylabel("gain deviation from nominal (%)")
    axis.set_title("Temperature-dependent gain G(T)", fontsize=11)
    axis.legend(fontsize=8, frameon=False, loc="lower left")

    # Right: the same information as the thing a calibration would apply,
    # i.e. the multiplicative correction, plus where the data actually sit.
    axis = axes[1]
    temp = data.temperature.mean(axis=1)
    axis.hist(temp, bins=60, color="#cbd5e1", edgecolor="none")
    axis.set_xlabel("MPA temperature (K)")
    axis.set_ylabel("epochs per bin")
    axis.set_title("Where the constraint comes from (epoch temperatures)",
                   fontsize=11)
    equilibrium = int((temp < T_NOMINAL_K + 0.5).sum())
    axis.annotate(f"{equilibrium} of {temp.size} epochs within 0.5 K of\n"
                  f"nominal -- the whole curve above {T_NOMINAL_K + 0.5:g} K "
                  f"rests on {temp.size - equilibrium} epochs",
                  xy=(0.97, 0.93), xycoords="axes fraction", ha="right",
                  va="top", fontsize=8.5, color="#374151")
    for spine in ("top", "right"):
        for one in axes:
            one.spines[spine].set_visible(False)
    figure.tight_layout()
    _save(figure, path, dpi)


def plot_chromaticity(data, fits, path, dpi=120):
    """Is it achromatic? Per-LED gain against the shared value."""
    import matplotlib.pyplot as plt

    shared, per_led, per_sca = fits["shared"], fits["per-led"], fits["per-sca"]
    lam = led_wavelengths(data.led_names)
    probe = np.linspace(T_NOMINAL_K, np.nanmax(data.temperature), 240)
    figure, axes = plt.subplots(1, 2, figsize=(12.4, 4.9))

    axis = axes[0]
    for index, name in enumerate(data.led_names):
        axis.plot(probe, _pct(tg.gain_at(per_led, probe, group=index)),
                  color=LED_COLORS[index], lw=1.8,
                  label=f"{name} ({lam[index]:.0f} nm)")
    axis.plot(probe, _pct(tg.gain_at(shared, probe)), color="#111827", lw=2.2,
              ls="--", label="shared (achromatic)")
    axis.axhline(0.0, color="#6b7280", lw=1.0, ls=":")
    axis.set_xlabel("MPA temperature (K)")
    axis.set_ylabel("gain deviation from nominal (%)")
    axis.set_title("Per-LED gain, each evaluated at its own measured T",
                   fontsize=11)
    axis.legend(fontsize=8, frameon=False, loc="lower left", ncol=2)

    # Right: the test. Per-LED gain at the hot end against wavelength, with the
    # per-SCA scatter as the error bar -- the only error estimate here that
    # includes systematics. The achromatic value is the null.
    axis = axes[1]
    hot_shared = float(tg.gain_at(shared, T_HOT_K))
    per_sca_hot = np.array([tg.gain_at(per_sca, T_HOT_K, group=i)
                            for i in range(per_sca["n_group"])])
    scatter = float(np.std(per_sca_hot, ddof=1))
    stderr = scatter / np.sqrt(per_sca_hot.size)
    axis.axhspan(_pct(hot_shared - stderr), _pct(hot_shared + stderr),
                 color="#111827", alpha=0.12, lw=0,
                 label="achromatic null +- per-detector s.e.")
    axis.axhline(_pct(hot_shared), color="#111827", lw=1.6, ls="--")
    hot_led = np.array([tg.gain_at(per_led, T_HOT_K, group=i)
                        for i in range(len(data.led_names))])
    for index, name in enumerate(data.led_names):
        axis.errorbar(lam[index], _pct(hot_led[index]), yerr=_pct_err(stderr),
                      fmt=LED_MARKERS[index], ms=10, color=LED_COLORS[index],
                      mew=1.4, mfc=LED_COLORS[index], lw=1.6, capsize=0)
        axis.annotate(name, xy=(lam[index], _pct(hot_led[index])),
                      xytext=(0, 13), textcoords="offset points", ha="center",
                      fontsize=8.5, color=LED_COLORS[index])
    axis.set_xlabel("LED wavelength (nm)")
    axis.set_ylabel(f"gain deviation at {T_HOT_K:g} K (%)")
    spread = float(np.ptp(hot_led))
    axis.set_title(f"Chromaticity test: band-to-band spread {spread * PCT:.3f}% "
                   f"vs detector s.e. {stderr * PCT:.3f}%", fontsize=11)
    axis.legend(fontsize=8, frameon=False, loc="lower left")
    for axis in axes:
        for spine in ("top", "right"):
            axis.spines[spine].set_visible(False)
    figure.tight_layout()
    _save(figure, path, dpi)


def plot_per_sca(data, fits, path, dpi=120):
    """How SCA-dependent? The eighteen gains at the hot end."""
    import matplotlib.pyplot as plt

    shared, per_sca = fits["shared"], fits["per-sca"]
    probe = np.linspace(T_NOMINAL_K, np.nanmax(data.temperature), 200)
    hot = np.array([float(tg.gain_at(per_sca, T_HOT_K, group=i))
                    for i in range(per_sca["n_group"])])
    hot_shared = float(tg.gain_at(shared, T_HOT_K))
    figure, axes = plt.subplots(1, 2, figsize=(12.6, 4.9),
                               gridspec_kw=dict(width_ratios=[1.35, 1.0]))

    axis = axes[0]
    index = np.arange(hot.size)
    axis.axhline(_pct(hot_shared), color="#111827", lw=1.6, ls="--",
                 label="shared fit")
    axis.axhspan(_pct(hot_shared - np.std(hot, ddof=1)),
                 _pct(hot_shared + np.std(hot, ddof=1)), color="#111827",
                 alpha=0.10, lw=0, label="+- 1 sigma across detectors")
    axis.plot(index, _pct(hot), "o", ms=9, color="#2a78d6", mfc="#ffffff",
              mew=1.8, label="per detector")
    # No per-point labels: the x tick directly below each marker already names
    # the detector, so an annotation above it is the same string twice.
    axis.set_xticks(index)
    axis.set_xticklabels([str(n) for n in data.sca_names], fontsize=8)
    axis.set_xlabel("SCA")
    axis.set_ylabel(f"gain deviation at {T_HOT_K:g} K (%)")
    axis.set_title("Gain by detector", fontsize=11)
    # Below the axes rather than inside it: every in-axes corner is occupied
    # here, and "lower left" in particular lands on the SCA1 point, which is
    # the single most important marker in the panel.
    axis.legend(fontsize=8, frameon=False, loc="upper center",
                bbox_to_anchor=(0.5, -0.16), ncol=3)

    axis = axes[1]
    for group in range(per_sca["n_group"]):
        axis.plot(probe, _pct(tg.gain_at(per_sca, probe, group=group)),
                  color="#9aa5b1", lw=1.1, alpha=0.8)
    axis.plot(probe, _pct(tg.gain_at(shared, probe)), color="#2a78d6", lw=2.2)
    axis.axhline(0.0, color="#6b7280", lw=1.0, ls=":")
    axis.set_xlabel("MPA temperature (K)")
    axis.set_ylabel("gain deviation from nominal (%)")
    axis.set_title("All eighteen curves, and the shared fit", fontsize=11)
    for axis in axes:
        for spine in ("top", "right"):
            axis.spines[spine].set_visible(False)
    figure.tight_layout()
    _save(figure, path, dpi)


def spatial_structure_test(data, fits, n_permute=20000, seed=0):
    """Is the per-detector gain spread organised on the focal plane?

    Worth asking because SCA1/17/18 sit at the deviant end together, and three
    detectors clustering invites a spatial reading.  Worth asking *as a test*
    rather than as a figure because the honest answer turns out to be no: a
    3x6 focal-plane heatmap of eighteen numbers with no real gradient is an
    invitation to read a pattern into noise, which is exactly what a null
    result should not be drawn as.

    Each candidate coordinate gets a Pearson r against the hot-end gain and a
    permutation p-value.  Permutation rather than the analytic t, because with
    eighteen points and a quantity that is itself a fit output the Gaussian
    assumption is doing real work in the tail, and shuffling the labels
    assumes nothing.
    """
    import digest_plots

    per_sca = fits["per-sca"]
    hot = np.array([float(tg.gain_at(per_sca, T_HOT_K, group=i))
                    for i in range(per_sca["n_group"])])
    centers, _, _ = digest_plots.read_sca_geometry()
    x = np.array([centers[f"SCA{int(n)}"][0] for n in data.sca_names], float)
    y = np.array([centers[f"SCA{int(n)}"][1] for n in data.sca_names], float)
    coordinates = {
        "x_center": x,
        "y_center": y,
        "abs_y_center": np.abs(y - y.mean()),
        "radius": np.hypot(x - x.mean(), y - y.mean()),
    }
    generator = np.random.default_rng(seed)
    rows = []
    for name, values in coordinates.items():
        r = float(np.corrcoef(values, hot)[0, 1])
        null = np.array([np.corrcoef(generator.permutation(values), hot)[0, 1]
                         for _ in range(n_permute)])
        rows.append({"coordinate": name, "pearson_r": r,
                     "p_permute": float(np.mean(np.abs(null) >= abs(r)))})
    return {"rows": rows,
            "gain_hot": hot,
            "x_center": x,
            "y_center": y,
            "spread": float(np.std(hot, ddof=1)),
            "best": min(rows, key=lambda row: row["p_permute"])}


def median_gain_sca(fits):
    """Index of the detector whose fitted gain is closest to the median.

    The default detector for the decomposition figure, because SCA1 -- the
    obvious default -- happens to be the most deviant detector in this set,
    and a reader shown the extreme as an illustration will take the extreme
    for typical.
    """
    per_sca = fits["per-sca"]
    hot = np.array([float(tg.gain_at(per_sca, T_HOT_K, group=i))
                    for i in range(per_sca["n_group"])])
    return int(np.argmin(np.abs(hot - np.median(hot))))


def plot_decomposition(data, fits, path, sca_index=None, dpi=120):
    """What the fit actually claims, per LED, for one detector.

    Small multiples rather than one crowded axis, and the film-only curve is
    drawn against the same y-scale as the data so the reader can see directly
    where the thermal term is doing work: the gap between the two curves opens
    only at the start of each decon episode, which is where the cooldown is,
    and closes once the focal plane reaches its asymptote.
    """
    import matplotlib.pyplot as plt

    shared = fits["shared"]
    if sca_index is None:
        sca_index = median_gain_sca(fits)
    gain = shared["gain"]
    film = shared["prediction"] / np.where(gain == 0, np.nan, gain)
    figure, axes = plt.subplots(2, 3, figsize=(13.2, 6.6), sharex=True)
    order = np.argsort(data.hours)
    hours = data.hours[order]
    for index, name in enumerate(data.led_names):
        axis = axes.flat[index]
        obs = data.response[sca_index, index][order]
        mod = shared["prediction"][sca_index, index][order]
        flm = film[sca_index, index][order]
        axis.plot(hours, obs, ".", ms=3.4, color="#9aa5b1", label="data")
        # Charcoal, not a palette hue: this curve appears in all six panels, so
        # any LED color would collide with the one panel that owns it -- orange
        # here meant both "LED2" and "film only" in the LED2 panel.
        axis.plot(hours, flm, lw=1.3, color="#374151", ls=(0, (5, 2)),
                  label="film only (gain divided out)")
        axis.plot(hours, mod, lw=1.5, color=LED_COLORS[index],
                  label="film x gain")
        axis.set_title(f"{name}  "
                       f"{cfg.LED_WAVELENGTHS[name].to_value('nm'):.0f} nm",
                       fontsize=10, color=LED_COLORS[index])
        if index >= 3:
            axis.set_xlabel("time (h)")
        if index % 3 == 0:
            axis.set_ylabel("relative response")
        for spine in ("top", "right"):
            axis.spines[spine].set_visible(False)
    axes.flat[0].legend(fontsize=7.5, frameon=False, loc="best")
    # Wrapped explicitly: as one line this overran both figure edges and lost
    # the SCA name at the left, which is the one thing the title must carry.
    figure.suptitle(
        f"SCA{data.sca_names[sca_index]} (the median-gain detector): the film "
        f"carries the trend, the gain carries the cooldown\n"
        f"Shared fit, rate {shared['rate']:.3f} nm/h. LED1's swing is ~20x "
        f"LED6's, which is why LED1 is the band most exposed to film-model "
        f"error", fontsize=10.5)
    figure.tight_layout(rect=(0, 0, 1, 0.92))
    _save(figure, path, dpi)


def plot_decomposition_per_sca(data, fits, growth, path, led_index=0, dpi=120):
    """The decomposition figure, one panel per detector instead of per band.

    The per-band version shows what the fit claims for one detector; this
    shows whether that claim is the *same* claim for all eighteen. Drawn for
    one band rather than all six, because the question here is detector-to-
    detector variation and a six-band panel per detector would be 108 axes.

    LED1 by default: its fringe is the fastest (3.12 rad per episode against
    1.17 for LED6), so a detector whose film grows at its own rate shows that
    most clearly here, and it is also the band whose gain is anomalous.

    The per-detector-rate model is overdrawn on the shared-rate one so the
    difference between them is visible rather than asserted -- on this set the
    two curves are nearly indistinguishable at most detectors, which is itself
    the result.
    """
    import matplotlib.pyplot as plt

    shared = fits["shared"]
    gain = shared["gain"]
    film = shared["prediction"] / np.where(gain == 0, np.nan, gain)
    order = np.argsort(data.hours)
    hours = data.hours[order]
    name = data.led_names[led_index]
    n_sca = data.response.shape[0]

    figure, axes = plt.subplots(3, 6, figsize=(17.4, 7.8), sharex=True)
    rate_free = growth["independent"]["rate"][:, 0]
    for sca in range(n_sca):
        axis = axes.flat[sca]
        axis.plot(hours, data.response[sca, led_index][order], ".", ms=2.4,
                  color="#9aa5b1")
        axis.plot(hours, film[sca, led_index][order], lw=1.0, color="#374151",
                  ls=(0, (4, 2)))
        axis.plot(hours, shared["prediction"][sca, led_index][order], lw=1.2,
                  color=LED_COLORS[led_index])
        free = growth["independent"]["fits"][sca]
        axis.plot(hours, free["prediction"][0, led_index][order], lw=1.0,
                  color="#111827", alpha=0.85)
        axis.set_title(f"SCA{data.sca_names[sca]}   "
                       f"{rate_free[sca]:.3f} nm/h", fontsize=8.5)
        axis.tick_params(labelsize=7.5)
        for spine in ("top", "right"):
            axis.spines[spine].set_visible(False)
    for sca in range(n_sca, axes.size):
        axes.flat[sca].set_visible(False)
    for axis in axes[-1]:
        axis.set_xlabel("time (h)", fontsize=8.5)
    for axis in axes[:, 0]:
        axis.set_ylabel("relative response", fontsize=8.5)

    handles = [
        plt.Line2D([], [], ls="none", marker=".", ms=6, color="#9aa5b1",
                   label="data"),
        plt.Line2D([], [], lw=1.2, color="#374151", ls=(0, (4, 2)),
                   label="film only, shared rate"),
        plt.Line2D([], [], lw=1.4, color=LED_COLORS[led_index],
                   label="film x gain, shared rate"),
        plt.Line2D([], [], lw=1.4, color="#111827",
                   label="film x gain, this detector's own rate"),
    ]
    figure.legend(handles=handles, fontsize=8.5, frameon=False, ncol=4,
                  loc="lower center", bbox_to_anchor=(0.5, -0.005))
    shared_rate = shared["rate"]
    figure.suptitle(
        f"{name} ({cfg.LED_WAVELENGTHS[name].to_value('nm'):.0f} nm) at every "
        f"detector: is it the same film everywhere?\n"
        f"Panel titles give each detector's independently fitted rate; the "
        f"shared fit says {shared_rate:.3f} nm/h for all of them "
        f"(spread {np.ptp(rate_free):.3f} nm/h, "
        f"{100 * np.std(rate_free, ddof=1) / np.mean(rate_free):.1f}% of the "
        f"mean)", fontsize=10.5)
    figure.tight_layout(rect=(0, 0.045, 1, 0.91))
    _save(figure, path, dpi)


def plot_growth_structure(data, growth, path, dpi=120):
    """Per-detector and per-decon growth rate, and what it costs to ignore it.

    Three panels, because "the rate varies" has three separable claims in it
    and they do not all come out the same way:

    left    the rate by detector, against the one shared rate the original fit
            uses and against the range the repo's independent rank-1 fit
            finds. Answers "does it vary across the focal plane".
    centre  each detector's two decons. Answers "does a decon reset it", which
            is the claim with by far the largest effect here.
    right   what any of it does to the gain -- the only reason the calibration
            cares. A rate that varies but leaves the gain alone is a film
            result, not a gain result.
    """
    import matplotlib.pyplot as plt

    n_sca = data.response.shape[0]
    index = np.arange(n_sca)
    labels = [f"{s}" for s in data.sca_names]
    ind = growth["independent"]
    per_ep = growth["per_episode"]
    figure, axes = plt.subplots(1, 3, figsize=(16.2, 5.0))

    axis = axes[0]
    rate = ind["rate"][:, 0]
    axis.axhspan(*growth["rank1_range"], color="#9aa5b1", alpha=0.18, lw=0,
                 label="rank-1 fit's range (per epoch)")
    axis.axhline(growth["shared_rate"], color="#374151", ls=(0, (5, 2)),
                 lw=1.4, label=f"one shared rate ({growth['shared_rate']:.3f})")
    axis.plot(index, rate, "o", ms=7, color="#2a78d6", label="per detector")
    axis.set_xticks(index)
    axis.set_xticklabels(labels, fontsize=8)
    axis.set_xlabel("SCA")
    axis.set_ylabel("film growth rate (nm/h)")
    axis.set_title(f"Each detector's own rate\nspread {np.ptp(rate):.3f} nm/h "
                   f"= {100 * np.std(rate, ddof=1) / np.mean(rate):.1f}% (1s) "
                   f"of the mean", fontsize=10)
    axis.legend(fontsize=8, frameon=False, loc="upper center",
                bbox_to_anchor=(0.5, -0.14), ncol=1)

    axis = axes[1]
    for episode, colour, marker in ((0, "#eb6834", "s"), (1, "#1baf7a", "^")):
        axis.plot(index, per_ep["rate"][:, episode], marker, ms=6.5,
                  color=colour, label=f"decon {episode + 1}")
    ratio = per_ep["rate"][:, 1] / per_ep["rate"][:, 0]
    axis.set_xticks(index)
    axis.set_xticklabels(labels, fontsize=8)
    axis.set_xlabel("SCA")
    axis.set_ylabel("film growth rate (nm/h)")
    axis.set_title(f"A decon resets the rate, not just the phase\n"
                   f"decon 2 / decon 1 = {np.median(ratio):.3f} "
                   f"(median), {int((ratio > 1).sum())}/{n_sca} detectors "
                   f"faster", fontsize=10)
    axis.legend(fontsize=8, frameon=False, loc="upper center",
                bbox_to_anchor=(0.5, -0.14), ncol=2)

    axis = axes[2]
    hot_shared = np.array(growth["gain_hot_shared_rate"])
    hot_free = np.array(growth["gain_hot_free_rate"])
    axis.plot(_pct(hot_shared), _pct(hot_free), "o", ms=6.5, color="#eda100")
    span = [min(_pct(hot_shared).min(), _pct(hot_free).min()) - 0.05,
            max(_pct(hot_shared).max(), _pct(hot_free).max()) + 0.05]
    axis.plot(span, span, color="#9aa5b1", lw=1.2, ls=(0, (4, 2)),
              label="unchanged")
    axis.set_xlim(span)
    axis.set_ylim(span)
    axis.set_xlabel(f"gain at {T_HOT_K:g} K, one shared rate (%)")
    axis.set_ylabel(f"gain at {T_HOT_K:g} K, own rate (%)")
    axis.set_title(f"...and the gain does not notice\n"
                   f"max move {np.max(np.abs(_pct(hot_free) - _pct(hot_shared))):.3f} %, "
                   f"against a {np.std(_pct(hot_free), ddof=1):.3f} % "
                   f"detector spread", fontsize=10)
    axis.legend(fontsize=8, frameon=False, loc="upper left")

    for axis in axes:
        for spine in ("top", "right"):
            axis.spines[spine].set_visible(False)
    figure.suptitle(
        "Film growth is not one number: it varies by detector and resets at "
        "each decon, but the temperature gain is insensitive to both",
        fontsize=11)
    figure.tight_layout(rect=(0, 0, 1, 0.93))
    _save(figure, path, dpi)


def plot_growth_freedom(data, rows, path, dpi=120):
    """Which *kind* of growth freedom absorbs LED1's excess, and which does not.

    The earlier version of this test varied only the growth polynomial's
    degree, found LED1 moving toward the other bands, and read the excess as
    film-model leakage. That test confounded two freedoms that this one
    separates, and they do not come out the same way: LED1 responds to
    *curvature* in the growth (a nonlinear d(tau) within an episode) and is
    untouched by where the rate is *placed* -- per detector, per decon, or
    both -- even though placement buys the larger chi2 improvement.

    Plotted against chi2 rather than as a list, because the question is not
    "does LED1 move" but "does it move when the fit gets better". A variant
    that improves the fit more while leaving LED1 exactly where it was is the
    evidence, and a one-dimensional list of variants hides it.
    """
    import matplotlib.pyplot as plt

    figure, axes = plt.subplots(1, 2, figsize=(13.6, 5.4))
    chi2 = np.array([row["chi2_red"] for row in rows])
    excess = np.array([row["led1_pack"] for row in rows])
    kinds = [row["freedom"] for row in rows]
    # The two families whose separation is the whole result.
    colour = {"curvature": "#eb6834", "placement": "#2a78d6",
              "both": "#008300", "none": "#374151"}
    name = {"none": "no extra film freedom",
            "curvature": "growth CURVATURE free (d nonlinear in time)",
            "placement": "rate PLACEMENT free (per detector / per decon)",
            "both": "both"}

    axis = axes[0]
    for kind in ("none", "curvature", "placement", "both"):
        pick = [i for i, k in enumerate(kinds) if k == kind]
        if not pick:
            continue
        axis.plot(chi2[pick], excess[pick], "o", ms=9, color=colour[kind],
                  label=name[kind])
    for index, row in enumerate(rows):
        axis.annotate(row["label"], (chi2[index], excess[index]),
                      textcoords="offset points", xytext=(7, 4), fontsize=7.5,
                      color="#374151")
    axis.set_xlabel("chi2 / dof  (better fit to the left)")
    axis.set_ylabel("LED1 gain minus the other five bands' median (%)")
    axis.set_title("LED1's excess does not follow the fit quality\n"
                   "only growth curvature moves it; rate placement does not",
                   fontsize=10)
    axis.legend(fontsize=8, frameon=False, loc="best")
    axis.invert_xaxis()

    axis = axes[1]
    order = np.argsort(chi2)[::-1]
    position = np.arange(len(rows))
    for index, row_index in enumerate(order):
        row = rows[row_index]
        for led in range(len(row["hot"])):
            axis.plot(position[index], row["hot"][led], LED_MARKERS[led],
                      ms=6.5, color=LED_COLORS[led],
                      label=data.led_names[led] if index == 0 else None)
    axis.set_xticks(position)
    axis.set_xticklabels([rows[i]["label"] for i in order], rotation=28,
                         ha="right", fontsize=8)
    axis.set_ylabel(f"gain at {T_HOT_K:g} K (%)")
    axis.set_title("Every band, as the film is freed in different ways\n"
                   "the five-band pack holds; LED1 stays apart", fontsize=10)
    axis.legend(fontsize=8, frameon=False, ncol=3, loc="lower center",
                bbox_to_anchor=(0.5, -0.02))

    for axis in axes:
        for spine in ("top", "right"):
            axis.spines[spine].set_visible(False)
    figure.tight_layout()
    _save(figure, path, dpi)


def plot_amplitude_invariance(data, invariance, path, dpi=120,
                              systematic=None):
    """Does the fringe amplitude survive a decon, as pure-phase growth requires?

    Two artefacts stand between the data and the answer, so there are three
    panels rather than one.

    The first is that the error on an amplitude ratio is set by how much fringe
    the episode covers, and coverage falls as 1/lambda -- so the ratio is
    plotted *against* its own error, where a prior consistent with the data
    looks like a wedge opening to the right rather than like a wavelength
    trend.

    The second is larger and is why the third panel exists: the amplitude is
    degenerate with the growth rate, so the ratio moves further when the growth
    model changes than any of these error bars. Drawing panels 1-2 alone would
    show a 5-7 sigma violation of the prior with no hint that the error bar is
    the wrong one.
    """
    import matplotlib.pyplot as plt

    pairs = invariance["pairs"]
    bands = invariance["bands"]
    n_panel = 3 if systematic and systematic.get("rows") else 2
    figure, axes = plt.subplots(1, n_panel,
                                figsize=(6.7 * n_panel, 5.2))

    axis = axes[0]
    for led in range(len(data.led_names)):
        pick = [p for p in pairs if p["led"] == led]
        if not pick:
            continue
        axis.errorbar([p["sigma_ratio"] for p in pick],
                      [p["amplitude_ratio"] for p in pick],
                      fmt=LED_MARKERS[led], ms=5.5, color=LED_COLORS[led],
                      ls="none", label=data.led_names[led], alpha=0.85)
    axis.axhline(1.0, color="#374151", lw=1.3,
                 label="invariant amplitude (the prior)")
    grid = np.linspace(0, max(p["sigma_ratio"] for p in pairs) * 1.02, 60)
    for n_sigma, alpha in ((1, 0.16), (2, 0.09)):
        axis.fill_between(grid, 1 - n_sigma * grid, 1 + n_sigma * grid,
                          color="#9aa5b1", alpha=alpha, lw=0,
                          label=f"{n_sigma}s of the prior")
    axis.set_xlabel("error on the ratio (dominated by fringe coverage)")
    axis.set_ylabel("fringe amplitude, decon 2 / decon 1")
    axis.set_title(f"Ratios track their own errors\nstatistical pull RMS "
                   f"{invariance['pull_rms']:.2f} over "
                   f"{invariance['n_pair']} pairs -- but see panel 3",
                   fontsize=10)
    axis.legend(fontsize=7.5, frameon=False, ncol=2, loc="upper right")

    axis = axes[1]
    lam = led_wavelengths(data.led_names)
    weighted = np.array([row["ratio_weighted"] for row in bands])
    error = np.array([row["ratio_weighted_error"] for row in bands])
    median = np.array([row["ratio_median"] for row in bands])
    scatter = np.array([row["ratio_sd"] for row in bands])
    axis.errorbar(lam, median, yerr=scatter, fmt="s", ms=7, color="#9aa5b1",
                  capsize=3, label="median +- detector scatter (the naive read)")
    for index in range(len(bands)):
        axis.errorbar(lam[index], weighted[index], yerr=error[index],
                      fmt=LED_MARKERS[index], ms=8, color=LED_COLORS[index],
                      capsize=3)
    axis.plot([], [], "o", ms=8, color="#374151",
              label="inverse-variance weighted +- its error")
    axis.axhline(1.0, color="#374151", lw=1.3)
    axis.set_xlabel("wavelength (nm)")
    axis.set_ylabel("fringe amplitude, decon 2 / decon 1")
    axis.set_title("Weighting removes the apparent wavelength trend\n"
                   "the scatter was fringe coverage, not physics", fontsize=10)
    axis.legend(fontsize=8, frameon=False, loc="best")

    if n_panel == 3:
        # The panel that decides the question. Each growth model is a row of
        # six band ratios; the vertical spread between rows is the real error
        # bar, and it dwarfs the per-point errors drawn in panels 1-2.
        axis = axes[2]
        rows = sorted(systematic["rows"], key=lambda r: r["chi2_red"])
        best = rows[0]
        for index, row in enumerate(rows):
            shade = "#111827" if row is best else "#9aa5b1"
            axis.plot(lam, row["ratio"], "-", color=shade, lw=2.0,
                      alpha=1.0 if row is best else 0.55, zorder=3)
            for band in range(len(lam)):
                axis.plot(lam[band], row["ratio"][band], LED_MARKERS[band],
                          ms=8 if row is best else 6,
                          color=LED_COLORS[band] if row is best else shade,
                          mec="white", mew=1.0, zorder=4)
        axis.axhline(1.0, color="#374151", lw=1.3, zorder=2)
        # Direct labels, because four growth models with a colour that means
        # "best" and not "which" cannot be told apart from a legend box. Two
        # models can end at nearly the same ratio though (29.0 and 35.1 land
        # 0.003 apart here), so the label rows are pushed apart before they
        # are drawn rather than overlapping into an unreadable smear.
        ends = sorted(((row["ratio"][-1], row) for row in rows),
                      key=lambda item: item[0])
        span = max(np.ptp([row["ratio"] for row in rows]), 1e-9)
        floor = 0.055 * span
        placed = []
        for value, row in ends:
            if placed and value - placed[-1][0] < floor:
                value = placed[-1][0] + floor
            placed.append((value, row))
        for value, row in placed:
            shade = "#111827" if row is best else "#9aa5b1"
            axis.annotate(f"{row['label']} ({row['chi2_red']:.1f})",
                          xy=(lam[-1], row["ratio"][-1]),
                          xytext=(lam[-1] + 70, value), fontsize=7.5,
                          color=shade, va="center", ha="left",
                          arrowprops=dict(arrowstyle="-", color=shade,
                                          lw=0.7, shrinkA=0, shrinkB=3,
                                          alpha=0.6))
        axis.set_xlabel("wavelength (nm)")
        axis.set_ylabel("fringe amplitude, decon 2 / decon 1")
        axis.set_xlim(lam[0] - 60, lam[-1] + 430)
        axis.set_title(
            f"The growth model moves the ratio "
            f"{systematic['systematic_error'] / systematic['stat_error']:.0f}x "
            f"more than its error bar\nbest model (dark) has median band "
            f"ratio {systematic['band_median']:.4f}", fontsize=10)

    for axis in axes:
        for spine in ("top", "right"):
            axis.spines[spine].set_visible(False)
    headline = (systematic["verdict"] if systematic and systematic.get("rows")
                else invariance["verdict"])
    figure.suptitle(
        "Does an added ice layer act as pure phase? "
        f"{headline.split(':')[0]}", fontsize=11)
    figure.tight_layout(rect=(0, 0, 1, 0.93))
    _save(figure, path, dpi)


def plot_transfer(data, transfer, path, dpi=120):
    """Does the decon-2 gain describe the decon-1 cooldown?"""
    import matplotlib.pyplot as plt

    figure, axes = plt.subplots(1, 2, figsize=(12.4, 4.9))
    source_lo, source_hi = transfer["source_t_range"]
    target_lo, target_hi = transfer["target_t_range"]
    probe = np.linspace(T_NOMINAL_K, max(source_hi, target_hi), 240)

    axis = axes[0]
    axis.axvspan(target_lo, target_hi, color="#eb6834", alpha=0.10, lw=0,
                 label=f"decon {transfer['target_episode'] + 1} T range")
    axis.axvspan(source_lo, source_hi, color="#2a78d6", alpha=0.08, lw=0,
                 label=f"decon {transfer['source_episode'] + 1} T range")
    # Each curve is solid only over the range its own episode actually
    # sampled, and faint beyond it. Drawing a quadratic at full strength 15 K
    # past its last data point invites the reader to compare an extrapolation
    # against a measurement -- decon 1 never got above ~110 K, so its curve
    # above that is the polynomial's tail and carries no information.
    for key, episode, color, style in (
            ("source", transfer["source_episode"], "#2a78d6", "-"),
            ("local", transfer["target_episode"], "#eb6834", "--")):
        lo, hi = (transfer["source_t_range"] if key == "source"
                  else transfer["target_t_range"])
        curve = _pct(tg.gain_at(transfer[key], probe))
        inside = (probe >= lo) & (probe <= hi)
        axis.plot(probe, curve, color=color, lw=1.0, ls=style, alpha=0.3)
        axis.plot(probe[inside], curve[inside], color=color, lw=2.2, ls=style,
                  label=f"fitted on decon {episode + 1} "
                        f"({lo:.0f}-{hi:.0f} K sampled)")
    axis.axhline(0.0, color="#6b7280", lw=1.0, ls=":")
    axis.set_xlabel("MPA temperature (K)")
    axis.set_ylabel("gain deviation from nominal (%)")
    axis.set_title("The same gain, measured independently on each cooldown\n"
                   "(faint = extrapolated past that episode's own data)",
                   fontsize=11)
    axis.legend(fontsize=8, frameon=False, loc="lower left")

    axis = axes[1]
    labels = ["gain fitted here\n(best case)", "gain imported from\nthe other "
              "cooldown", "no gain at all\n(film only)"]
    keys = ["local", "transfer", "nogain"]
    colors = ["#1baf7a", "#2a78d6", "#9aa5b1"]
    values = [transfer[k]["chi2_red"] for k in keys]
    bars = axis.bar(np.arange(3), values, color=colors, width=0.62)
    for bar, value in zip(bars, values):
        axis.annotate(f"{value:.1f}", xy=(bar.get_x() + bar.get_width() / 2,
                                          value), xytext=(0, 4),
                      textcoords="offset points", ha="center", fontsize=9,
                      color="#374151")
    axis.set_xticks(np.arange(3))
    axis.set_xticklabels(labels, fontsize=8.5)
    axis.set_ylabel("chi2 / dof on the held-out cooldown")
    bracket = transfer["bracket"]
    axis.set_title(f"Held out on decon {transfer['target_episode'] + 1}: "
                   f"imported gain is {bracket * 100:.0f}% of the way\n"
                   f"from a local fit to no gain at all", fontsize=11)
    for axis in axes:
        for spine in ("top", "right"):
            axis.spines[spine].set_visible(False)
    figure.tight_layout()
    _save(figure, path, dpi)


def plot_residuals(data, fits, path, dpi=120):
    """Where the model is wrong, against the two axes that matter."""
    import matplotlib.pyplot as plt

    shared = fits["shared"]
    resid = data.response - shared["prediction"]
    figure, axes = plt.subplots(1, 3, figsize=(14.4, 4.6))

    axis = axes[0]
    for index, name in enumerate(data.led_names):
        temp = data.temperature[:, index]
        pooled = np.nanmean(resid[:, index, :], axis=0)
        order = np.argsort(temp)
        edges = np.linspace(np.nanmin(temp), np.nanmax(temp), 15)
        pick = np.digitize(temp[order], edges) - 1
        xs, ys = [], []
        for bin_index in range(len(edges) - 1):
            take = pick == bin_index
            if take.sum() >= 3:
                xs.append(0.5 * (edges[bin_index] + edges[bin_index + 1]))
                ys.append(np.nanmean(pooled[order][take]))
        axis.plot(xs, ys, LED_MARKERS[index] + "-", ms=6, lw=1.4,
                  color=LED_COLORS[index], label=name)
    axis.axhline(0.0, color="#6b7280", lw=1.0, ls=":")
    axis.set_xlabel("MPA temperature (K)")
    axis.set_ylabel("mean residual (relative response)")
    axis.set_title("Residual vs temperature, by band", fontsize=11)
    axis.legend(fontsize=8, frameon=False, ncol=2)

    axis = axes[1]
    order = np.argsort(data.hours)
    for index, name in enumerate(data.led_names):
        axis.plot(data.hours[order], np.nanmean(resid[:, index, :], axis=0)[order],
                  lw=1.0, color=LED_COLORS[index], alpha=0.9, label=name)
    axis.axhline(0.0, color="#6b7280", lw=1.0, ls=":")
    for position in data.meta.get("boundary_hours", []) or []:
        axis.axvline(position, color="#6b7280", lw=1.0, ls="--", alpha=0.6)
    axis.set_xlabel("time (h)")
    axis.set_ylabel("mean residual (relative response)")
    axis.set_title("Residual vs time -- the unmodelled film shape", fontsize=11)

    axis = axes[2]
    scaled = (resid / data.sigma[:, :, None]).ravel()
    scaled = scaled[np.isfinite(scaled)]
    axis.hist(scaled, bins=90, color="#cbd5e1", edgecolor="none")
    axis.axvline(0.0, color="#6b7280", lw=1.0, ls=":")
    axis.set_xlabel("residual / empirical sigma")
    axis.set_ylabel("count")
    axis.set_title(f"chi2/dof = {shared['chi2_red']:.1f}: model error, "
                   f"not noise", fontsize=11)
    for axis in axes:
        for spine in ("top", "right"):
            axis.spines[spine].set_visible(False)
    figure.tight_layout()
    _save(figure, path, dpi)


def plot_robustness(variants, scatter, path, dpi=120):
    """Does the headline number survive the assumptions it was built on?"""
    import matplotlib.pyplot as plt

    figure, axes = plt.subplots(1, 2, figsize=(12.8, 5.0),
                               gridspec_kw=dict(width_ratios=[1.25, 1.0]))
    baseline = variants[0]["gain_hot"]
    labels = [v["label"] for v in variants]
    values = np.array([v["gain_hot"] for v in variants])
    index = np.arange(len(variants))

    axis = axes[0]
    axis.axvspan(_pct(baseline - scatter / np.sqrt(18)),
                 _pct(baseline + scatter / np.sqrt(18)), color="#2a78d6",
                 alpha=0.12, lw=0, label="baseline +- per-detector s.e.")
    axis.axvline(_pct(baseline), color="#2a78d6", lw=1.6, ls="--")
    axis.plot(_pct(values), index, "o", ms=9, color="#111827", mfc="#ffffff",
              mew=1.7)
    axis.set_yticks(index)
    axis.set_yticklabels(labels, fontsize=9)
    axis.invert_yaxis()
    axis.set_xlabel(f"gain deviation at {T_HOT_K:g} K (%)")
    axis.set_title("Headline gain across model variants", fontsize=11)
    axis.legend(fontsize=8, frameon=False, loc="lower right")

    axis = axes[1]
    rates = np.array([v["rate"] for v in variants])
    axis.plot(rates, index, "s", ms=8, color="#eb6834", mfc="#ffffff", mew=1.7)
    axis.axvline(rates[0], color="#eb6834", lw=1.4, ls="--",
                 label="baseline rate")
    axis.axvspan(*RANK1_RATE_RANGE, color="#1baf7a", alpha=0.10, lw=0,
                 label="rank-1 fit's per-SCA rate range")
    axis.set_yticks(index)
    axis.set_yticklabels([""] * len(index))
    axis.invert_yaxis()
    axis.set_xlabel("leading film rate (nm/h)")
    axis.set_title("The nuisance parameter, for context", fontsize=11)
    axis.legend(fontsize=8, frameon=False, loc="lower right")
    for axis in axes:
        for spine in ("top", "right"):
            axis.spines[spine].set_visible(False)
    figure.tight_layout()
    _save(figure, path, dpi)


def plot_acm_boundaries(data, path, dpi=120):
    """Do the ACM bridge boundaries sit at thermal equilibrium?

    The ones that matter must, or the bridge step and the thermal gain are
    degenerate: a step *fitted* from the epochs either side of a boundary where
    the temperature is still falling would absorb part of G(T), and the gain
    measured here would be reading a bridge artefact instead of the detectors.

    Which boundaries matter is decided by the bridge *method*, not by the
    temperature. Only ``bridge`` steps were fitted from the response and can
    absorb anything; a ``multiplier`` step was predicted from the LVDT and
    never looked at the response, and ``none`` means no step was applied. This
    distinction is load-bearing on the real set: one boundary coincides with
    the decon-2 transition and so sits 34 K off nominal, but the bridge refuses
    to fit across a decon and fell back to the LVDT model there -- judging that
    boundary by its temperature alone raises a false alarm about a step that
    was never fitted to the data.
    """
    import matplotlib.pyplot as plt

    temp = data.temperature.mean(axis=1)
    order = np.argsort(data.hours)
    methods = list(data.meta.get("boundary_methods") or [])
    kinds = list(data.meta.get("boundary_kinds") or [])
    figure, axis = plt.subplots(figsize=(11.6, 4.6))
    axis.plot(data.hours[order], temp[order], "-", lw=1.3, color="#2a78d6")
    axis.plot(data.hours[order], temp[order], ".", ms=4, color="#2a78d6")
    axis.axhline(T_NOMINAL_K, color="#6b7280", lw=1.2, ls="--")
    # Right-aligned at the far edge: the left edge is where the first boundary
    # label lands, and the two overprinted each other there.
    axis.annotate(f"nominal {T_NOMINAL_K:g} K", xy=(0.995, T_NOMINAL_K),
                  xycoords=("axes fraction", "data"), xytext=(0, 6),
                  textcoords="offset points", fontsize=8.5, color="#4b5563",
                  ha="right")

    rows = []
    for index, position in enumerate(data.meta.get("boundary_hours", []) or []):
        near = int(np.argmin(np.abs(data.hours - position)))
        method = methods[index] if index < len(methods) else "unknown"
        kind = kinds[index] if index < len(kinds) else "?"
        fitted = method == "bridge"
        rows.append(dict(hours=float(position), temperature=float(temp[near]),
                         method=method, kind=kind, fitted=fitted,
                         delta_k=float(temp[near] - T_NOMINAL_K)))
        color = "#eb6834" if fitted else "#9aa5b1"
        axis.axvline(position, color=color, lw=1.6 if fitted else 1.2,
                     ls=":" if fitted else "--")
        # Anchored in axes fraction, staggered, with an opaque background: the
        # labels are tall and the curve fills the panel, so anchoring them to
        # the data point put them off the top edge or on top of each other.
        axis.annotate(f"{kind} / {method}\n"
                      f"{temp[near] - T_NOMINAL_K:+.3f} K from nominal"
                      + ("" if fitted else "\n(step modelled, not fitted:\n"
                                           "cannot absorb G(T))"),
                      xy=(position, 0.60 if index % 2 == 0 else 0.80),
                      xycoords=("data", "axes fraction"), xytext=(8, 0),
                      textcoords="offset points", fontsize=7.8, color=color,
                      va="center",
                      bbox=dict(boxstyle="round,pad=0.3", fc="#ffffff",
                                ec="none", alpha=0.85))
    axis.set_xlabel("time (h)")
    axis.set_ylabel("MPA temperature (K)")
    # Linear, deliberately. A log-of-excursion-above-nominal axis makes the
    # small departures legible but has to clip everything at or below nominal
    # to a floor, and the floor rendered as a flat run at "85 K" -- a
    # temperature the MPA never reaches (the minimum is 89.47 K). A reader
    # believing that is worse off than one who cannot resolve 13 mK, and the
    # 13 mK is in the title and the table anyway.
    fitted_rows = [r for r in rows if r["fitted"]]
    worst = (max(abs(r["delta_k"]) for r in fitted_rows)
             if fitted_rows else float("nan"))
    axis.set_title(
        "ACM boundaries against the thermal state: fitted steps sit within "
        f"{worst:.3f} K of nominal,\nso no fitted step could have absorbed "
        "G(T)", fontsize=11)
    for spine in ("top", "right"):
        axis.spines[spine].set_visible(False)
    figure.tight_layout()
    _save(figure, path, dpi)
    return rows


# ------------------------------------------------------------------ the tables

def write_tables(data, fits, variants, transfer, nonparam, out_dir,
                 growth_rows=None, spatial=None, growth=None,
                 freedom_rows=None, invariance=None, invariance_sys=None):
    from astropy.table import Table

    shared, per_led, per_sca = fits["shared"], fits["per-led"], fits["per-sca"]
    lam = led_wavelengths(data.led_names)
    common = dict(
        t_nominal_k=float(shared["t_nominal"]), t_hot_k=T_HOT_K,
        gain_scale_k=tg.T_SCALE_K, n_water=float(cfg.DEFAULT_N_WATER),
        digest_dir=data.meta["digest_dir"], cal_dir=data.meta["cal_dir"],
        mnemonic=data.meta["mnemonic"],
        caveat=("chi2/dof >> 1 by construction: the film model is linearised "
                "and growth is polynomial, so formal errors are meaningless. "
                "Quoted uncertainties are empirical spreads."))
    written = []

    def emit(table, name, extra=None):
        table.meta.update(common)
        table.meta.update(extra or {})
        path = os.path.join(out_dir, name)
        table.write(path, format="ascii.ecsv", overwrite=True)
        print(f"  wrote {path}")
        written.append(path)

    probe = np.linspace(T_NOMINAL_K, float(np.nanmax(data.temperature)), 200)
    per_sca_hot = np.array([float(tg.gain_at(per_sca, T_HOT_K, group=i))
                            for i in range(per_sca["n_group"])])
    scatter = float(np.std(per_sca_hot, ddof=1))
    curve = Table()
    curve["temperature_k"] = probe
    curve["gain_shared"] = tg.gain_at(shared, probe)
    curve["gain_sca_mean"] = np.mean(
        [tg.gain_at(per_sca, probe, group=i)
         for i in range(per_sca["n_group"])], axis=0)
    curve["gain_sca_std"] = np.std(
        [tg.gain_at(per_sca, probe, group=i)
         for i in range(per_sca["n_group"])], axis=0, ddof=1)
    emit(curve, "tempgain_curve.ecsv",
         dict(alpha=list(map(float, shared["alpha"][0])),
              rate_nm_per_h=shared["rate"], chi2_red=shared["chi2_red"]))

    binned = Table()
    binned["temperature_k"], binned["gain"] = nonparam[0], nonparam[1]
    binned["gain_err"], binned["n_points"] = nonparam[2], nonparam[3]
    binned["gain_model"] = tg.gain_at(shared, nonparam[0])
    emit(binned, "tempgain_nonparametric.ecsv")

    table = Table()
    table["led"] = list(data.led_names)
    table["wavelength_nm"] = lam
    table["gain_hot"] = [float(tg.gain_at(per_led, T_HOT_K, group=i))
                         for i in range(len(data.led_names))]
    table["gain_hot_shared"] = np.full(len(data.led_names),
                                       float(tg.gain_at(shared, T_HOT_K)))
    table["detector_scatter"] = np.full(len(data.led_names), scatter)
    for degree in range(per_led["degree"]):
        table[f"alpha{degree + 1}"] = per_led["alpha"][:, degree]
    table["sigma_response"] = np.nanmedian(data.sigma, axis=0)
    emit(table, "tempgain_per_led.ecsv",
         dict(band_spread=float(np.ptp(table["gain_hot"])),
              detector_stderr=scatter / np.sqrt(per_sca["n_group"]),
              reading=("compare band_spread against detector_stderr; the "
                       "gain is evaluated at each LED's own temperature so "
                       "the intra-epoch ramp is not folded in")))

    table = Table()
    table["sca"] = list(data.sca_names)
    table["gain_hot"] = per_sca_hot
    for degree in range(per_sca["degree"]):
        table[f"alpha{degree + 1}"] = per_sca["alpha"][:, degree]
    table["sigma_response"] = np.nanmedian(data.sigma, axis=1)
    extra = dict(scatter=scatter, mean_gain_hot=float(np.mean(per_sca_hot)),
                 shared_gain_hot=float(tg.gain_at(shared, T_HOT_K)))
    if spatial is not None:
        # The focal-plane coordinates travel with the gains so a reader can
        # redo the spatial test, or a better one, without re-fitting.
        table["x_center"] = spatial["x_center"]
        table["y_center"] = spatial["y_center"]
        extra["spatial_test"] = [
            f"{row['coordinate']}: r={row['pearson_r']:+.3f} "
            f"p={row['p_permute']:.4f}" for row in spatial["rows"]]
        extra["spatial_reading"] = (
            "no focal-plane coordinate predicts the per-detector gain, so the "
            "scatter is detector-to-detector and a per-SCA lookup is the right "
            "form; a spatial model would be fitting noise")
    emit(table, "tempgain_per_sca.ecsv", extra)

    table = Table()
    table["variant"] = [v["label"] for v in variants]
    table["note"] = [v["note"] for v in variants]
    table["subset"] = [v["subset"] for v in variants]
    table["gain_hot"] = [v["gain_hot"] for v in variants]
    table["rate_nm_per_h"] = [v["rate"] for v in variants]
    table["chi2_red"] = [v["chi2_red"] for v in variants]
    table["bic"] = [v["bic"] for v in variants]
    table["n_data"] = [v["n_data"] for v in variants]
    emit(table, "tempgain_robustness.ecsv",
         dict(baseline_gain_hot=variants[0]["gain_hot"],
              variant_spread=float(np.ptp([v["gain_hot"] for v in variants])),
              detector_scatter=scatter))

    table = Table()
    keys = ["source", "local", "transfer", "nogain"]
    table["fit"] = keys
    table["role"] = ["gain fitted on source episode",
                     "gain fitted on target episode",
                     "source gain imported, film refitted",
                     "no gain, film only"]
    table["chi2_red"] = [transfer[k]["chi2_red"] for k in keys]
    table["rms"] = [transfer[k]["rms"] for k in keys]
    table["rate_nm_per_h"] = [transfer[k]["rate"] for k in keys]
    table["gain_hot"] = [float(tg.gain_at(transfer[k], T_HOT_K)) for k in keys]
    emit(table, "tempgain_transfer.ecsv",
         dict(source_episode=transfer["source_episode"],
              target_episode=transfer["target_episode"],
              source_t_range=list(transfer["source_t_range"]),
              target_t_range=list(transfer["target_t_range"]),
              bracket=transfer["bracket"],
              reading=("bracket 0 = imported gain as good as one fitted "
                       "locally; 1 = bought nothing; >1 = actively wrong")))

    if growth_rows:
        table = Table()
        table["growth_degree"] = [r["growth_degree"] for r in growth_rows]
        table["rate_nm_per_h"] = [r["rate"] for r in growth_rows]
        table["d_end_nm"] = [r["d_end"] for r in growth_rows]
        table["chi2_red"] = [r["chi2_red"] for r in growth_rows]
        for index, name in enumerate(data.led_names):
            table[f"gain_hot_{name}"] = [r["gain_hot"][index]
                                         for r in growth_rows]
        table["band_spread"] = [float(np.ptp(r["gain_hot"]))
                                for r in growth_rows]
        table["band_spread_no_outlier"] = [
            float(np.ptp(np.delete(r["gain_hot"], int(np.argmax(np.abs(
                r["gain_hot"] - np.median(r["gain_hot"])))))))
            for r in growth_rows]
        emit(table, "tempgain_chromaticity_growth.ecsv",
             dict(reading=("a band whose gain_hot moves as growth_degree "
                           "rises was absorbing film-model error, not "
                           "measuring a detector property; k ~ 1/lambda makes "
                           "the shortest band the most exposed")))

    rows = []
    for (sca, led, episode), coef in sorted(shared["coefficients"].items()):
        rows.append((data.sca_names[sca], data.led_names[led], episode,
                     float(coef[0]), float(coef[1]), float(coef[2]),
                     float(np.hypot(coef[1], coef[2]))))
    table = Table(rows=rows, names=("sca", "led", "episode", "a", "b", "c",
                                    "fringe_amplitude"))
    emit(table, "tempgain_film_params.ecsv",
         dict(model="R = G(T) * (a + b cos(2 k d) + c sin(2 k d))",
              rate_nm_per_h=shared["rate"], d_end_nm=shared["d_end"]))

    if growth is not None:
        rate_free = np.asarray(growth["independent"]["rate"])[:, 0]
        columns = dict(
            sca=list(data.sca_names), rate_nm_per_h=rate_free,
            gain_hot_free_rate=_pct(growth["gain_hot_free_rate"]),
            gain_hot_shared_rate=_pct(growth["gain_hot_shared_rate"]))
        if "per_episode" in growth:
            per_ep = np.asarray(growth["per_episode"]["rate"])
            for index in range(per_ep.shape[1]):
                columns[f"rate_decon{index + 1}"] = per_ep[:, index]
            columns["rate_ratio_decon2_decon1"] = per_ep[:, -1] / per_ep[:, 0]
        if "dispersion_after_episode" in growth:
            columns["sigma_d_nm_per_100h"] = np.asarray(
                growth["dispersion_after_episode"]["sigma"])
        table = Table(columns)
        emit(table, "tempgain_growth_structure.ecsv",
             dict(shared_rate_nm_per_h=growth["shared_rate"],
                  chi2_red_shared_rate=growth["shared_chi2_red"],
                  chi2_red_free_rate=growth["independent"]["chi2_red"],
                  corr_rate_gain=growth["rate_gain"]["r"],
                  corr_rate_gain_p=growth["rate_gain"]["p_permutation"],
                  gain_shift_max_pct=growth["rate_gain"]["gain_shift_max"],
                  rank1_rate_range=list(RANK1_RATE_RANGE),
                  gain_units="percent deviation from 1 at t_hot_k",
                  note=("rate_nm_per_h and gain_hot_free_rate come from one "
                        "independent fit per detector; gain_hot_shared_rate "
                        "is the same gain with every detector pinned to the "
                        "shared rate, which is the control for whether the "
                        "rate/gain correlation is film leakage. sigma_d is a "
                        "LIMIT, not a measurement: it is degenerate with "
                        "growth curvature, which fits better at equal cost.")))

    if freedom_rows:
        rows = [(row["label"], row["freedom"], row["growth_mode"],
                 row["growth_degree"], row["chi2_red"], row["led1_pack"],
                 row["spread"]) + tuple(row["hot"]) for row in freedom_rows]
        table = Table(rows=rows, names=(
            "variant", "freedom", "growth_mode", "growth_degree", "chi2_red",
            "led1_minus_pack", "band_spread")
            + tuple(f"gain_{n}" for n in data.led_names))
        emit(table, "tempgain_growth_freedom.ecsv",
             dict(gain_mode="per-led", gain_degree=2,
                  gain_units="percent deviation from 1 at t_hot_k",
                  note=("'freedom' is the axis this table exists to separate: "
                        "curvature makes the thickness nonlinear in time, "
                        "placement only moves a constant rate across the "
                        "focal plane or across a decon. On this set the two "
                        "are not interchangeable -- placement improves "
                        "chi2 more and moves LED1's excess less -- so a "
                        "film-leakage claim must name which one was given.")))

    if invariance is not None and invariance.get("pairs"):
        rows = [(p["sca_name"], p["led_name"], p["amplitude_ratio"],
                 p["sigma_ratio"], p["pull"], p["phase_change_deg"],
                 p["sigma_phase_change_deg"], p["coverage_rad"])
                for p in invariance["pairs"]]
        table = Table(rows=rows, names=(
            "sca", "led", "amplitude_ratio", "sigma_ratio", "pull",
            "phase_change_deg", "sigma_phase_change_deg", "coverage_rad"))
        meta = dict(first_episode=invariance["first_episode"],
                    last_episode=invariance["last_episode"],
                    pull_rms=invariance["pull_rms"],
                    verdict=invariance["verdict"],
                    prior="r_current = r_prior * exp(2 i k dd), so |r| is "
                          "invariant and the added layer is pure phase",
                    note=("read the pull, not the ratio: the error on each "
                          "ratio is set by how much fringe that episode "
                          "covers and coverage falls as 1/lambda, so the raw "
                          "ratios show a wavelength trend that is an "
                          "artefact."))
        if invariance_sys is not None and invariance_sys.get("rows"):
            # The columns carry the statistical error; on this set it is the
            # smaller error by 10-100x, so a reader who takes sigma_ratio as
            # THE error concludes a 5-7 sigma violation of a prior that the
            # growth-model spread puts at 1.00. The dominant error has to
            # travel with the table.
            meta.update(
                growth_model_systematic=invariance_sys["systematic_error"],
                statistical_error=invariance_sys["stat_error"],
                best_growth_model=invariance_sys["best_label"],
                band_median_best_model=invariance_sys["band_median"],
                systematic_verdict=invariance_sys["verdict"],
                warning=("sigma_ratio is STATISTICAL only and is not the "
                         "dominant error. The fringe amplitude is degenerate "
                         "with the growth rate, so changing the growth model "
                         "moves these ratios by "
                         f"{invariance_sys['systematic_error']:.3f} against a "
                         f"{invariance_sys['stat_error']:.3f} statistical "
                         "error. Quote the band median under the best growth "
                         "model with the model spread as its error; the "
                         "per-band pulls are degeneracy, not optics."))
        emit(table, "tempgain_amplitude_invariance.ecsv", meta)
    if invariance_sys is not None and invariance_sys.get("rows"):
        rows = [(row["label"], row["chi2_red"], row["band_median"],
                 row["deviation_median"], row["pull_rms"]) + tuple(row["ratio"])
                for row in invariance_sys["rows"]]
        table = Table(rows=rows, names=(
            "growth_model", "chi2_red", "ratio_band_median",
            "median_abs_deviation", "pull_rms_statistical")
            + tuple(f"ratio_{name}" for name in data.led_names))
        emit(table, "tempgain_amplitude_systematic.ecsv",
             dict(stat_error=invariance_sys["stat_error"],
                  systematic_error=invariance_sys["systematic_error"],
                  best_growth_model=invariance_sys["best_label"],
                  verdict=invariance_sys["verdict"],
                  note=("the spread down each ratio_* column IS the error bar "
                        "on the amplitude-invariance test. Read the row with "
                        "the lowest chi2_red for the central value. A ratio "
                        "that moves with the growth model is reporting the "
                        "rate/amplitude degeneracy, not a change in |r|.")))
    return written, scatter


# ------------------------------------------------------- the model parameters

# What the ``derivation`` column records. Not a free-text note: it is the one
# field that says whether a row's six LEDs carry a genuinely fitted chromatic
# coefficient or one achromatic coefficient replicated, and a reader comparing
# two model files needs to be able to tell those apart without re-running
# anything.
DERIVATION_ACHROMATIC = "per-sca joint fit, achromatic, replicated across LEDs"
DERIVATION_CHROMATIC = "per-sca-led joint fit, chromatic"


def write_model(data, result, path, derivation, scatter=None,
                variant_spread=None, detector_stderr=None, chromatic=False,
                reference=None):
    """Write the committed model-parameter file that stage 2 ingests.

    This is the hand-off from analysis to pipeline, and the only output of this
    module that anything downstream reads. Everything else here is a diagnostic
    that a human looks at.

    ``result`` is a fit result dict. For the default achromatic file that is the
    ``per-sca`` fit, whose ``alpha`` is one coefficient set per detector,
    replicated across the six LEDs on write; the schema stays per-(SCA, LED) so
    that improving the model to a genuinely chromatic one changes a file and not
    a single reader. ``chromatic=True`` takes the ``per-sca-led`` fit's 108 rows
    as they are.

    On the uncertainty column: no covariance for ``alpha`` is computed anywhere
    in this analysis and chi2/dof is ~35 by construction, so a formal
    per-coefficient error would be meaningless (see this module's docstring).
    ``sigma_gain_hot`` is therefore the *empirical* bar on the derived quantity
    people actually use -- the across-detector scatter of the gain at the hot
    end -- and ``uncertainty_kind`` exists so that a future file computing a
    real covariance can say so and a reader can tell the difference.

    ``reference`` is the fit the chromatic variant should be read against, and
    is recorded so its chi2 travels in the same file as the improved one.
    """
    import tempgain_model as tgm

    alpha = np.asarray(result["alpha"], float)
    if chromatic:
        alpha = alpha.reshape(len(data.sca_names), len(data.led_names), -1)

    # Hash the digests the coefficients were actually fitted from. The path
    # alone is not provenance: DEFAULT_DIGEST_DIR is a dated directory in an
    # untracked tree, so the next stage-3 run writes a different set under a
    # different name and nothing here would record that this file no longer
    # describes it.
    digest_dir = data.meta["digest_dir"]
    source_hashes = []
    for sca in data.sca_names:
        source = os.path.join(digest_dir, f"time_series_SCA{sca}.ecsv")
        if os.path.exists(source):
            source_hashes.append(f"SCA{sca}:{tgm.file_sha256(source)}")

    meta = dict(
        digest_dir=digest_dir, cal_dir=data.meta["cal_dir"],
        temperature_mnemonic=data.meta["mnemonic"],
        episode_labels=[str(v) for v in data.meta.get("episode_labels", [])],
        source_digest_sha256=source_hashes,
        source_reference_epoch=str(data.meta.get("reference_epoch", "")),
        source_corrections=str(data.meta.get("corrections", "")),
        n_epoch=int(data.response.shape[-1]),
        fit_gain_mode=str(result["mode"]),
        fit_growth_mode=str(result["growth_mode"]),
        fit_growth_degree=int(result["growth_degree"]),
        fit_rate_nm_per_h=float(result["rate"]),
        chi2_red=float(result["chi2_red"]),
        uncertainty_kind="empirical-across-detector",
        sigma_note=(
            "sigma_gain_hot is the across-detector standard deviation of "
            "G(124 K), NOT a formal error on the coefficients: no covariance "
            "is computed and chi2/dof is ~35 by construction, so a Jacobian "
            "error would be meaningless. The model-variant spread is the "
            "alternative bar (see model_variant_spread_gain_hot) and is the "
            "smaller of the two. detector_scatter_gain_hot is a POPULATION "
            "spread -- the width of the per-detector gains, not the error on "
            "any one of them -- so it must not be added in quadrature with "
            "detector_stderr_gain_hot, which is that width over sqrt(N)."),
        provisional=True,
        caveat=(
            "PROVISIONAL. Recorded in the calibrated products as a reference "
            "multiplier and NEVER applied to their pixels. Applying a thermal "
            "gain upstream of the thin-film fit would let its error be "
            "absorbed as a growth-rate bias, which is the one quantity that "
            "fit exists to measure. See TEMPERATURE_GAIN.md."),
        chromatic_caveat=(
            "The measured gain is achromatic across LED2-LED6 to better than "
            "0.2 % (in both the per-led and the per-sca-led fit), and LED1's "
            "apparent excess is thin-film model leakage rather than "
            "chromaticity. The achromatic file is therefore the default; a "
            "chromatic file would bake that artefact into a calibration."
            + ("" if not chromatic else
               " THIS IS THE CHROMATIC FILE. It is a diagnostic for "
               "comparison against the achromatic default, not a candidate "
               "for it. chi2/dof improves substantially over the achromatic "
               "fit (see chi2_red and reference_chi2_red) for ~200 extra "
               "gain parameters, but with two gain parameters per (SCA, LED) "
               "series the gain is nearly unidentifiable from that same "
               "series' own film amplitude, so the improvement measures "
               "absorbed film-model error and not chromaticity.")),
        created=tgm.utc_now(),
        software_version=cfg.SCHEMA_VERSION,
        comments=[
            "Temperature-dependent detector gain, per SCA and per LED.",
            "Produced by fit_temperature_gain.py --model-out; read by "
            "calibrate_rcs_products.py --tempgain-model, which records the "
            "evaluated multiplier in each calibrated product's tempgain/ "
            "group WITHOUT applying it.",
            "'form' names the parametric form and 'param_powers' gives each "
            "parameter column's exponent; evaluate with tempgain_model.py "
            "rather than assuming the polynomial.",
            "The gain must be evaluated at each LED's OWN temperature. Within "
            "one epoch the six LEDs span up to 0.8 K on a cooldown, and "
            "because sequence order is wavelength order, an epoch mean turns "
            "this achromatic gain into an apparent chromatic ramp.",
        ])
    if scatter is not None:
        meta["detector_scatter_gain_hot"] = float(scatter)
    if detector_stderr is not None:
        meta["detector_stderr_gain_hot"] = float(detector_stderr)
    if variant_spread is not None:
        meta["model_variant_spread_gain_hot"] = float(variant_spread)
    if reference is not None:
        # The chromatic file's whole claim is a chi2 improvement, so the
        # number it improved on travels with it. Without the baseline in the
        # same file, "chi2/dof = 6" reads as a good fit rather than as the
        # 198-parameter purchase it is.
        meta["reference_chi2_red"] = float(reference["chi2_red"])
        meta["reference_gain_mode"] = str(reference["mode"])
        meta["reference_n_param"] = int(reference["n_param"])
        meta["n_param"] = int(result["n_param"])
        meta["warm_start_from"] = str(reference["mode"])
        meta["warm_start_note"] = (
            "The gain coefficients were polished from the "
            f"{reference['mode']} solution with each detector's coefficients "
            "replicated across its six LEDs, so they inherit that fit's "
            "fringe branch and are NOT an independent determination. That is "
            "intended: the film branch is a property of the film, which this "
            "variant is not re-measuring.")

    model = tgm.TempGainModel.from_alpha(
        alpha, sca_names=data.sca_names, led_names=list(data.led_names),
        t_nominal_k=float(result["t_nominal"]), t_scale_k=tg.T_SCALE_K,
        derivation=derivation, sigma_gain_hot=scatter, meta=meta)
    model.write(path)
    print(f"  wrote {path}")
    print(f"  sha256 {model.sha256}")
    print(f"  {len(model.sca_names)} SCA(s) x {len(model.led_names)} LED(s), "
          f"form={model.form}, G({T_HOT_K:g}K) spans "
          + "%.3f..%.3f %%" % tuple(
              _pct(np.array([
                  np.min(model.gain_grid(
                      np.full(len(model.led_names), T_HOT_K))),
                  np.max(model.gain_grid(
                      np.full(len(model.led_names), T_HOT_K)))]))))

    return model


# -------------------------------------------------------------------- the run

def run(args):
    out_dir = args.out_dir
    os.makedirs(out_dir, exist_ok=True)
    print(f"temperature-gain analysis -> {out_dir}")
    data = tg.load_dataset(args.digest_dir, args.cal_dir, args.mnemonic,
                           quiet=args.quiet)

    print("fits:")
    fits = run_fits(data, degree=args.degree, t_nominal=args.t_nominal,
                    quiet=False)
    print("robustness variants:")
    variants = robustness_suite(data, quiet=True)
    for variant in variants:
        print(f"  {variant['label']:14s} G({T_HOT_K:g}K)-1 = "
              f"{_pct(variant['gain_hot']):+.3f}%  rate="
              f"{variant['rate']:.4f}  chi2/dof={variant['chi2_red']:.2f}")
    print("episode transfer (fit on decon 2, test on decon 1):")
    transfer = tg.episode_transfer(data, source_episode=1, target_episode=0,
                                   degree=args.degree,
                                   t_nominal=args.t_nominal, quiet=True)
    for key in ("source", "local", "transfer", "nogain"):
        print(f"  {key:9s} chi2/dof={transfer[key]['chi2_red']:9.2f}  "
              f"rms={transfer[key]['rms']:.2e}")
    print(f"  bracket = {transfer['bracket']:.3f}")

    print("chromaticity vs film freedom (the test that decides whether an "
          "apparently chromatic gain is real):")
    growth_rows = chromaticity_growth_test(data)
    for row in growth_rows:
        print(f"  growth_deg={row['growth_degree']}  rate={row['rate']:.4f}  "
              f"chi2/dof={row['chi2_red']:.2f}  spread="
              f"{_pct_err(np.ptp(row['gain_hot'])):.3f}%  bands: "
              + " ".join(f"{_pct(v):+.3f}" for v in row["gain_hot"]))

    print("focal-plane structure in the per-detector gain:")
    spatial = spatial_structure_test(data, fits)
    for row in spatial["rows"]:
        print(f"  {row['coordinate']:14s} r={row['pearson_r']:+.3f}  "
              f"p={row['p_permute']:.4f}")

    print("growth structure (per detector, per decon, and intra-detector):")
    growth = growth_structure(data, shared=fits["shared"],
                              processes=args.processes, quiet=False)
    print("which film freedom moves the chromaticity:")
    freedom_rows = growth_freedom_test(data, processes=args.processes,
                                       quiet=False)
    print("is the fringe amplitude invariant across a decon?")
    invariance = film_invariance_test(data, fits["shared"], quiet=False)
    print("  ... and how much of that is the growth model:")
    invariance_sys = film_invariance_systematic(data, quiet=False)

    nonparam = tg.nonparametric_gain(data, fits["shared"], n_bins=18)

    print("figures:")
    plot_curve(data, fits, nonparam,
               os.path.join(out_dir, "tempgain_curve.png"), args.dpi)
    plot_chromaticity(data, fits,
                      os.path.join(out_dir, "tempgain_chromaticity.png"),
                      args.dpi)
    plot_chromaticity_growth(
        data, growth_rows,
        os.path.join(out_dir, "tempgain_chromaticity_growth.png"), args.dpi)
    plot_per_sca(data, fits, os.path.join(out_dir, "tempgain_per_sca.png"),
                 args.dpi)
    plot_decomposition(data, fits,
                       os.path.join(out_dir, "tempgain_decomposition.png"),
                       dpi=args.dpi)
    plot_decomposition_per_sca(
        data, fits, growth,
        os.path.join(out_dir, "tempgain_decomposition_per_sca.png"),
        led_index=0, dpi=args.dpi)
    plot_growth_structure(
        data, growth, os.path.join(out_dir, "tempgain_growth_structure.png"),
        args.dpi)
    plot_growth_freedom(
        data, freedom_rows,
        os.path.join(out_dir, "tempgain_growth_freedom.png"), args.dpi)
    if invariance.get("pairs"):
        plot_amplitude_invariance(
            data, invariance,
            os.path.join(out_dir, "tempgain_amplitude_invariance.png"),
            args.dpi, systematic=invariance_sys)
    plot_transfer(data, transfer,
                  os.path.join(out_dir, "tempgain_transfer.png"), args.dpi)
    plot_residuals(data, fits,
                   os.path.join(out_dir, "tempgain_residuals.png"), args.dpi)
    boundaries = plot_acm_boundaries(
        data, os.path.join(out_dir, "tempgain_acm_boundaries.png"), args.dpi)

    print("tables:")
    _written, scatter = write_tables(data, fits, variants, transfer, nonparam,
                                     out_dir, growth_rows=growth_rows,
                                     spatial=spatial, growth=growth,
                                     freedom_rows=freedom_rows,
                                     invariance=invariance,
                                     invariance_sys=invariance_sys)
    plot_robustness(variants, scatter,
                    os.path.join(out_dir, "tempgain_robustness.png"), args.dpi)

    if getattr(args, "model_out", None):
        variant_spread = float(np.ptp([v["gain_hot"] for v in variants]))
        stderr = scatter / np.sqrt(fits["per-sca"]["n_group"])
        chromatic = bool(getattr(args, "chromatic", False))
        if chromatic:
            # Same joint fit and same growth model as the achromatic file, so
            # the *only* difference between the two files is the gain grouping.
            # Warm-started from the achromatic solution, because 108 gain rows
            # from the 40-point cold growth grid is both slow and free to land
            # on a different fringe branch than the file it is compared with.
            #
            # The seed is built here rather than handed to ``_warm_start_values``
            # as the per-sca result dict: that helper sees 18 seed rows against
            # 108 groups, takes its shape-mismatch branch, and broadcasts the
            # *median* over detectors to every group -- which would throw away
            # the per-SCA structure that is the entire content of the seed. A
            # tuple goes through unbroadcast.
            #
            # np.repeat, not np.tile: gain_group_index is SCA-major
            # (arange(n_sca * n_led).reshape(n_sca, n_led)), so a detector's
            # six LED rows are adjacent. np.tile would attach SCA1's
            # coefficients to LED1 on every detector and still converge.
            n_led = len(data.led_names)
            seed = (np.atleast_2d(fits["per-sca"]["growth_matrix"]),
                    np.repeat(fits["per-sca"]["alpha"], n_led, axis=0))
            print(f"model parameters ({tg.GAIN_MODE_CHROMATIC}, "
                  f"{len(data.sca_names) * n_led} gain rows, warm-started "
                  f"from per-sca):")
            t0 = time.time()
            source = tg.fit(data, mode=tg.GAIN_MODE_CHROMATIC,
                            degree=args.degree, t_nominal=args.t_nominal,
                            warm_start=seed, quiet=False)
            print(f"  fitted in {time.time() - t0:.1f} s")
        else:
            print("model parameters (achromatic, the default):")
            source = fits["per-sca"]
        write_model(data, source, args.model_out,
                    DERIVATION_CHROMATIC if chromatic
                    else DERIVATION_ACHROMATIC,
                    scatter=scatter, variant_spread=variant_spread,
                    detector_stderr=stderr, chromatic=chromatic,
                    reference=fits["per-sca"] if chromatic else None)

    verdict(data, fits, variants, transfer, scatter, boundaries, out_dir,
            growth_rows=growth_rows, spatial=spatial,
            freedom_rows=freedom_rows, growth=growth, invariance=invariance,
            invariance_sys=invariance_sys)


def verdict(data, fits, variants, transfer, scatter, boundaries, out_dir,
            growth_rows=None, spatial=None, freedom_rows=None, growth=None,
            invariance=None, invariance_sys=None):
    """Print, and file, the answers to the four questions."""
    shared, per_led, per_sca = fits["shared"], fits["per-led"], fits["per-sca"]
    hot_shared = float(tg.gain_at(shared, T_HOT_K))
    hot_led = np.array([float(tg.gain_at(per_led, T_HOT_K, group=i))
                        for i in range(len(data.led_names))])
    hot_sca = np.array([float(tg.gain_at(per_sca, T_HOT_K, group=i))
                        for i in range(per_sca["n_group"])])
    stderr = scatter / np.sqrt(hot_sca.size)
    band_spread = float(np.ptp(hot_led))
    variant_spread = float(np.ptp([v["gain_hot"] for v in variants]))

    lines = []
    def say(text=""):
        lines.append(text)
        print(text)

    say()
    say("=" * 78)
    say(f"VERDICT  (gain quoted as deviation from 1 at {T_HOT_K:g} K, "
        f"{T_HOT_K - T_NOMINAL_K:.1f} K above nominal)")
    say("=" * 78)
    say(f"size        G({T_HOT_K:g} K) - 1 = {_pct(hot_shared):+.3f}%   "
        f"(shared/achromatic fit, {shared['n_data']} points)")
    say(f"            film rate {shared['rate']:.4f} nm/h, "
        f"d({shared['tau_max']:.0f} h) = {shared['d_end']:.1f} nm "
        f"-- nuisance, but it lands inside the rank-1 range 0.44-1.02")
    say(f"            chi2/dof = {shared['chi2_red']:.1f}: the model is "
        f"incomplete, so all bars below are empirical spreads")
    say()
    say(f"1 achromatic?   band-to-band spread {band_spread * PCT:.3f}% vs "
        f"per-detector s.e. {stderr * PCT:.3f}%")
    ratio = band_spread / stderr if stderr > 0 else np.inf
    if not np.isfinite(ratio):
        say("                -> UNDECIDABLE: the per-detector scatter is zero, "
            "so there is no yardstick to judge the band spread against")
    elif ratio < 1.0:
        say("                -> consistent with achromatic; an achromatic "
            "gain is adequate at this precision")
    elif ratio < 3.0:
        say("                -> marginal. Chromaticity is at most comparable "
            "to the detector scatter; do not model it yet")
    else:
        say(f"                -> the bands are NOT all equal: spread is "
            f"{ratio:.1f}x the detector scatter")
    lam = led_wavelengths(data.led_names)
    order = np.argsort(lam)
    say("                by band: " + ", ".join(
        f"{data.led_names[i]} {_pct(hot_led[i]):+.3f}%" for i in order))

    # The SHAPE matters more than the spread, and reporting only the spread is
    # how a single outlier band gets written up as a chromatic trend. A real
    # QE/band-edge effect is monotonic in wavelength; one band away from a
    # tight pack is a per-band systematic instead -- and the shortest band is
    # the one most exposed to film-model error, because k ~ 1/lambda makes its
    # fringe the fastest and constant growth the worst approximation for it.
    ranked = hot_led[order]
    monotonic = (np.all(np.diff(ranked) > 0) or np.all(np.diff(ranked) < 0))
    deviation = np.abs(hot_led - np.median(hot_led))
    outlier = int(np.argmax(deviation))
    rest = np.delete(hot_led, outlier)
    rest_spread = float(np.ptp(rest))
    say(f"                shape: {'MONOTONIC in wavelength' if monotonic else 'NOT monotonic in wavelength'}; "
        f"drop {data.led_names[outlier]} ({lam[outlier]:.0f} nm) and the "
        f"remaining {rest.size} bands span only {rest_spread * PCT:.3f}%")
    if not monotonic and rest_spread < 0.34 * band_spread:
        say(f"                -> this is ONE OUTLIER BAND "
            f"({data.led_names[outlier]}), not a chromatic trend. A QE or "
            f"band-edge effect would be monotonic in wavelength and strongest "
            f"at the long end; this is neither.")
        if outlier == int(np.argmin(lam)):
            say("                   and the outlier is the SHORTEST band, "
                "whose fringe is the fastest (k ~ 1/lambda), so film-model "
                "error leaking into the gain is the leading explanation")
    elif monotonic:
        say("                -> a monotonic wavelength trend, which is what a "
            "QE/band-edge effect looks like. A per-band gain is warranted")

    # The growth test is what turns "one band is odd" into a cause.
    if growth_rows:
        first, last = growth_rows[0], growth_rows[-1]
        moved = np.abs(last["gain_hot"] - first["gain_hot"])
        say(f"                film-freedom test (growth degree "
            f"{first['growth_degree']} -> {last['growth_degree']}, "
            f"chi2/dof {first['chi2_red']:.1f} -> {last['chi2_red']:.1f}):")
        for index in order:
            say(f"                   {data.led_names[index]:5s} "
                f"{_pct(first['gain_hot'][index]):+7.3f}% -> "
                f"{_pct(last['gain_hot'][index]):+7.3f}%  "
                f"(moved {_pct_err(moved[index]):.3f}%)")
        worst = int(np.argmax(moved))
        stable = np.delete(moved, worst)
        ratio = moved[worst] / np.max(stable) if np.max(stable) > 0 else np.inf
        # Direction is the discriminator, not the size of the movement. Gain
        # absorbing film-model error must shrink TOWARD the other bands as the
        # film is freed, because what it was absorbing is being explained
        # instead. A real detector property has no reason to move that
        # particular way. A bare "does it move more than the others" ratio
        # answers a weaker question and needs a cliff-edge threshold to do it;
        # with the direction and the chi2 in hand, a lower bar is stronger
        # evidence rather than weaker.
        pack = float(np.median(np.delete(last["gain_hot"], worst)))
        toward = (abs(last["gain_hot"][worst] - pack)
                  < abs(first["gain_hot"][worst] - pack))
        improved = last["chi2_red"] < first["chi2_red"]
        say(f"                {data.led_names[worst]} moves most "
            f"({_pct_err(moved[worst]):.3f}%, {ratio:.1f}x the worst other "
            f"band at {_pct_err(np.max(stable)):.3f}%), "
            f"{'toward' if toward else 'away from'} the other bands, with "
            f"chi2/dof {'improving' if improved else 'not improving'}")
        if ratio > 2.0 and toward and improved:
            say(f"                -> VERDICT: the gain is achromatic across "
                f"the {stable.size} bands that hold still (to within "
                f"{_pct_err(np.max(stable)):.3f}%). "
                f"{data.led_names[worst]}'s excess is GROWTH-CURVATURE error "
                f"being absorbed by the gain, NOT detector chromaticity -- do "
                f"not put a per-band term in the calibration for it")
            say(f"                   (curvature specifically: see the "
                f"freedom test below, where freeing the rate per detector or "
                f"per decon improves chi2 more and moves it not at all)")
            # Not converged means the number is a bound, and saying so is the
            # difference between a measurement and a floor.
            if len(growth_rows) > 2:
                previous = abs(growth_rows[-2]["gain_hot"][worst]
                               - last["gain_hot"][worst])
                if previous > 0.25 * moved[worst]:
                    say(f"                -> but it has NOT converged by "
                        f"degree {last['growth_degree']} (last step "
                        f"{_pct_err(previous):.3f}% of "
                        f"{_pct_err(moved[worst]):.3f}%), so "
                        f"{_pct_err(moved[worst]):.3f}% is a LOWER BOUND on "
                        f"the leakage, not a measurement of it")
        elif ratio > 2.0 and not toward:
            # The case that must not be silently folded into either verdict:
            # something band-specific is there, but freeing the film makes it
            # worse rather than better, so leakage does not explain it.
            say(f"                -> UNEXPLAINED. {data.led_names[worst]} is "
                f"film-model-sensitive but moves AWAY from the other bands, "
                f"so leakage does not account for it. Do not add a per-band "
                f"term on this evidence and do not dismiss it either")
        else:
            say(f"                -> the bands hold still to within "
                f"{_pct_err(float(np.max(moved))):.3f}% as the film is freed, "
                f"which bounds film-model leakage below the band spread; on "
                f"this evidence the band differences survive the film model")

    # Which KIND of film freedom. The block above varies only the growth
    # polynomial's degree, so on its own it cannot tell "the film model is
    # wrong" from "the film model is wrong in this particular way" -- and the
    # two have different consequences: curvature is a shared-across-detectors
    # error that a better d(tau) would fix, while rate placement is per-SCA
    # structure that no amount of polynomial would.
    if freedom_rows:
        say()
        say("                WHICH film freedom moves it (per-LED gain "
            "throughout; LED1 minus the other five bands' median):")
        for row in freedom_rows:
            say(f"                   {row['label']:28s} {row['freedom']:10s} "
                f"chi2/dof {row['chi2_red']:6.3f}   LED1-pack "
                f"{row['led1_pack']:+.3f}%")
        families = {}
        for row in freedom_rows:
            families.setdefault(row["freedom"], []).append(row)
        base_row = next((r for r in freedom_rows if r["freedom"] == "none"),
                        None)
        curve = families.get("curvature", [])
        place = families.get("placement", [])
        if base_row and curve and place:
            # Each family summarised by its best chi2 and by how far LED1 came
            # with it. The comparison that matters is between those two pairs.
            best_curve = min(curve, key=lambda r: r["chi2_red"])
            best_place = min(place, key=lambda r: r["chi2_red"])
            pull_curve = abs(base_row["led1_pack"]) - abs(best_curve["led1_pack"])
            pull_place = abs(base_row["led1_pack"]) - abs(best_place["led1_pack"])
            say(f"                curvature: chi2/dof "
                f"{base_row['chi2_red']:.2f} -> {best_curve['chi2_red']:.2f} "
                f"and LED1's excess shrinks by {pull_curve:+.3f}%")
            say(f"                placement: chi2/dof "
                f"{base_row['chi2_red']:.2f} -> {best_place['chi2_red']:.2f} "
                f"and LED1's excess shrinks by {pull_place:+.3f}%")
            better = best_place["chi2_red"] < best_curve["chi2_red"]
            if better and pull_place < 0.25 * pull_curve:
                say("                -> THE TWO FREEDOMS SEPARATE. Rate "
                    "placement fits BETTER than curvature and moves LED1 "
                    "essentially not at all, so LED1's excess is not generic "
                    "film-model slack being absorbed -- it is specifically "
                    "sensitive to the thickness's TIME dependence.")
                say("                   Consequence: a per-SCA or per-decon "
                    "rate will not fix LED1, and chi2 improvement is not "
                    "evidence about LED1 either way. Only a better d(tau) is.")
            elif pull_place > 0.75 * pull_curve:
                say("                -> both freedoms move it similarly, so "
                    "the excess is generic film-model slack and the degree "
                    "ladder above is an adequate test of it on its own")
            else:
                say("                -> partially separable; neither family "
                    "alone accounts for LED1's excess, so quote it as "
                    "film-sensitive without naming a mechanism")
    say()
    say(f"2 SCA-dependent?  spread {scatter * PCT:.3f}% across "
        f"{hot_sca.size} detectors, range "
        f"{_pct(hot_sca.min()):+.3f}% to {_pct(hot_sca.max()):+.3f}%")
    relative = scatter / abs(hot_shared - 1.0) if hot_shared != 1.0 else np.inf
    say(f"                  that is {relative * 100:.0f}% of the mean effect")
    worst = int(np.argmax(np.abs(hot_sca - np.mean(hot_sca))))
    say(f"                  most deviant: SCA{data.sca_names[worst]} at "
        f"{_pct(hot_sca[worst]):+.3f}%")
    if spatial is not None:
        best = spatial["best"]
        say(f"                  focal plane: best coordinate "
            f"{best['coordinate']} gives r={best['pearson_r']:+.3f}, "
            f"p={best['p_permute']:.3f} (permutation, "
            f"{hot_sca.size} detectors)")
        if best["p_permute"] < 0.01:
            say("                  -> SPATIAL. The scatter is organised on "
                "the focal plane, so model it as a function of position "
                "rather than as eighteen independent numbers")
        else:
            # Stated as a null with its consequence, because the useful part
            # is not "no gradient" but "therefore a per-SCA lookup, and do
            # not read the SCA1/17/18 cluster as a map feature".
            say("                  -> NOT SPATIAL. No coordinate predicts "
                "the gain, so the scatter is detector-to-detector and a "
                "per-SCA lookup is the right form; the deviant detectors "
                "clustering is not a focal-plane gradient")
    say()
    say(f"3 transfers to decon 1?  held-out chi2/dof: local "
        f"{transfer['local']['chi2_red']:.1f}, imported "
        f"{transfer['transfer']['chi2_red']:.1f}, none "
        f"{transfer['nogain']['chi2_red']:.1f}")
    bracket = transfer["bracket"]
    say(f"                  bracket = {bracket:.3f} "
        f"(0 = as good as local, 1 = bought nothing)")
    # The nan guard is load-bearing: every comparison against nan is False, so
    # without it a degenerate bracket falls through to the harshest branch and
    # prints a confident "NO" about data that carried no information at all.
    if not np.isfinite(bracket):
        say("                  -> UNDECIDABLE. A gain fitted on the target "
            "episode is no better than none, so the bracket has no span and "
            "the target cooldown does not constrain a gain either way")
    elif bracket < 0.35:
        say("                  -> YES. One G(T) describes both cooldowns")
    elif bracket <= 1.0:
        say("                  -> PARTLY. The decon-2 gain helps on decon 1 "
            "but is not the whole story there")
    else:
        say("                  -> NO. The imported gain is worse than none; "
            "the effect is not a pure function of MPA temperature")
    say(f"                  decon 1 spans {transfer['target_t_range'][0]:.1f}"
        f"-{transfer['target_t_range'][1]:.1f} K, decon 2 "
        f"{transfer['source_t_range'][0]:.1f}-"
        f"{transfer['source_t_range'][1]:.1f} K")
    say()
    say(f"4 how to model it?  headline moves {variant_spread * PCT:.3f}% "
        f"across {len(variants)} model variants, vs "
        f"{scatter * PCT:.3f}% detector scatter")
    if variant_spread < scatter:
        say("                  -> the number is robust to the film "
            "parametrisation; a single achromatic polynomial in MPA T, "
            "pinned to 1 at nominal, is defensible")
    else:
        say("                  -> MODEL-DEPENDENT. The film parametrisation "
            "moves the gain by more than the detector scatter, so the "
            "correction cannot be pinned down without the full film model")
    # Only a step FITTED from the response can absorb G(T). Judging every
    # boundary by temperature alone raises a false alarm on the decon
    # transition, where the bridge declined to fit and used the LVDT model.
    fitted = [b for b in boundaries if b["fitted"]]
    modelled = [b for b in boundaries if not b["fitted"]]
    if fitted:
        worst_boundary = max(abs(b["delta_k"]) for b in fitted)
        say(f"                  {len(fitted)} of {len(boundaries)} ACM "
            f"boundaries had a step FITTED from the response; those sit "
            f"within {worst_boundary:.3f} K of nominal -- "
            + ("bridge and gain are not degenerate"
               if worst_boundary < 0.5 else
               "WARNING: a fitted step sits off nominal, so it and the gain "
               "are partly degenerate there"))
    for boundary in modelled:
        say(f"                  boundary at {boundary['hours']:.0f} h is "
            f"{boundary['delta_k']:+.1f} K off nominal but its step was "
            f"'{boundary['method']}' (not fitted to the response), so it "
            f"cannot have absorbed the gain")

    # Film structure, reported as its own section rather than folded into "how
    # to model it", because the answer is two-sided: the growth is strongly
    # structured AND the gain is insensitive to that structure. Collapsing
    # those into one line loses whichever half the reader needs.
    if growth is not None:
        say()
        say(f"5 is the film one number?  per-detector rate "
            f"{min(growth['independent']['rate'][:, 0]):.4f}-"
            f"{max(growth['independent']['rate'][:, 0]):.4f} nm/h "
            f"against one shared {growth['shared_rate']:.4f}")
        rate = np.asarray(growth["independent"]["rate"])[:, 0]
        say(f"                  = {100 * np.std(rate, ddof=1) / np.mean(rate):.1f}% "
            f"(1 sigma) detector-to-detector, chi2/dof "
            f"{growth['shared_chi2_red']:.2f} -> "
            f"{growth['independent']['chi2_red']:.2f}")
        if "per_episode" in growth:
            per_ep = np.asarray(growth["per_episode"]["rate"])
            ratio = per_ep[:, -1] / per_ep[:, 0]
            say(f"                  a decon RESETS the rate: decon 2 / decon 1 "
                f"= {np.median(ratio):.3f} median "
                f"({int((ratio > 1).sum())}/{rate.size} detectors faster), "
                f"chi2/dof -> {growth['per_episode']['chi2_red']:.2f}")
            say("                  -> so a decon adds more than a phase. The "
                "user's 'at least a different phase, perhaps a different "
                "rate' is confirmed on the rate, and it is the single largest "
                "film-model improvement available")
        gauge = growth["rate_gain"]
        say(f"                  corr(rate, gain) = {gauge['r']:+.3f}, "
            f"p = {gauge['p_permutation']:.4f} "
            f"({gauge['n_permute']} permutations)")
        # The correlation on its own does not say the gain is contaminated.
        # The test for contamination is whether pinning the rate changes the
        # gain, and these two can and do disagree.
        say(f"                  but pinning every detector to one rate moves "
            f"the gain by at most {gauge['gain_shift_max']:.4f}% and changes "
            f"the detector scatter {gauge['gain_sd_shared_rate']:.4f}% -> "
            f"{gauge['gain_sd_free_rate']:.4f}%")
        leak = (gauge["gain_shift_max"] / gauge["gain_sd_free_rate"]
                if gauge["gain_sd_free_rate"] > 0 else np.inf)
        if leak < 0.35:
            say(f"                  -> the correlation is NOT the gain scatter "
                f"being film leakage: the largest a rate error could move any "
                f"detector is {leak:.2f}x its scatter, i.e. at most "
                f"{100 * leak ** 2:.0f}% of the variance. Both quantities vary "
                f"across the focal plane and happen to co-vary")
        else:
            say(f"                  -> WARNING: freeing the rate moves the "
                f"gain by {leak:.2f}x the detector scatter, so part of that "
                f"scatter is film leakage and the per-SCA gain table should "
                f"be built with the rate free")
        matched = growth.get("matched", {})
        if {"dispersion", "curvature"} <= set(matched):
            disp, curv = matched["dispersion"], matched["curvature"]
            say(f"                  intra-detector rate spread, at the SAME "
                f"parameter count as the alternatives:")
            for key in ("rate", "dispersion", "curvature", "per_episode"):
                if key in matched:
                    say(f"                     {matched[key]['note']:38s} "
                        f"chi2/dof {matched[key]['chi2_red']:.3f}")
            if curv["chi2_red"] < disp["chi2_red"]:
                say(f"                  -> dispersion is NOT established: "
                    f"growth curvature fits better at the same cost "
                    f"({curv['chi2_red']:.2f} vs {disp['chi2_red']:.2f}), and "
                    f"the dispersion fit drops the rate to "
                    f"{disp['rate_min']:.3f}-{disp['rate_max']:.3f} nm/h, "
                    f"which is the signature of a degenerate fit, not of a "
                    f"measured non-uniformity")
            after = growth.get("dispersion_after_episode")
            if after is not None:
                # The direction is the finding, so it is read off the numbers
                # rather than asserted: a sigma that holds up once the decon
                # rate is fitted first would mean the dispersion is real and
                # merely degenerate, which is a different conclusion.
                before = disp.get("sigma_over_rate", float("nan"))
                shrank = np.isfinite(before) and after["sigma_over_rate"] < before
                say(f"                     with the per-decon rate fitted "
                    f"first, sigma/rate "
                    f"{before:.2f} -> {after['sigma_over_rate']:.2f} "
                    f"(sigma {disp.get('sigma_median', float('nan')):.2f} -> "
                    f"{after['sigma_median']:.2f} nm/100h)"
                    + (", so much of it was the decon rate error being "
                       "re-measured" if shrank else
                       ", so it is not simply the decon rate error"))
                say(f"                  -> quote intra-detector spread as a "
                    f"LIMIT, sigma/rate < "
                    f"{max(after['sigma_over_rate'], before if np.isfinite(before) else 0.0):.2f}"
                    f", not as a measurement: it is degenerate with curvature")

    if invariance is not None and invariance.get("pairs"):
        say()
        say(f"6 does a decon add pure phase?  the prior is |r| invariant, "
            f"r -> r exp(2ik dd)")
        say(f"                  {invariance['n_pair']} (detector, band) "
            f"amplitude ratios across the decon, pull RMS "
            f"{invariance['pull_rms']:.2f}")
        for row in invariance["bands"]:
            say(f"                     {row['led_name']:5s} ratio "
                f"{row['ratio_weighted']:.3f} +- "
                f"{row['ratio_weighted_error']:.3f} (median "
                f"{row['ratio_median']:.3f}, sd {row['ratio_sd']:.3f}), "
                f"coverage {row['coverage_rad']:.2f} rad, phase change "
                f"{row['phase_change_median_deg']:+.0f} deg")
        say(f"                  -> {invariance['verdict']}")
        # The trap this test exists to avoid: the unweighted medians look like
        # a wavelength trend, and that trend is fringe coverage.
        cover = [row["coverage_rad"] for row in invariance["bands"]]
        if max(cover) > 1.5 * min(cover):
            say(f"                  note: fringe coverage falls "
                f"{max(cover):.2f} -> {min(cover):.2f} rad across the bands "
                f"(k ~ 1/lambda), so the long bands' raw scatter is coverage, "
                f"not physics -- read the weighted column, not the median")

    if invariance_sys is not None and invariance_sys.get("rows"):
        say()
        say(f"  the growth-model systematic on that ratio, which is the error "
            f"bar it needs:")
        for row in invariance_sys["rows"]:
            say(f"                     {row['label']:24s} chi2/dof "
                f"{row['chi2_red']:7.3f}  band median "
                f"{row['band_median']:.4f}  median |ratio-1| "
                f"{PCT * row['deviation_median']:5.1f}%")
        say(f"                  stat error {invariance_sys['stat_error']:.4f}, "
            f"growth-model spread {invariance_sys['systematic_error']:.4f} "
            f"({invariance_sys['systematic_error'] / invariance_sys['stat_error']:.0f}x)")
        say(f"                  -> {invariance_sys['verdict']}")
    say("=" * 78)

    path = os.path.join(out_dir, "tempgain_verdict.txt")
    with open(path, "w") as handle:
        handle.write("\n".join(lines) + "\n")
    print(f"  wrote {path}")


def self_test(verbose=True):
    """Exercise the plotting and table paths on the synthetic dataset.

    Deliberately a smoke test: the physics assertions live in
    ``fit_temperature_gain.self_test``, and what can break here is a figure
    that raises on an edge case (one episode, a degenerate bin) or a table
    column that does not match its length.
    """
    import tempfile
    import matplotlib
    matplotlib.use("Agg")
    from astropy.table import Table

    rng = np.random.default_rng(5)
    n_sca, n_led, n_epoch = 3, 6, 90
    led_names = list(cfg.LED_NAMES)
    episode = np.where(np.arange(n_epoch) < n_epoch // 2, 0, 1)
    tau = np.concatenate([np.linspace(0, 240, n_epoch // 2),
                          np.linspace(0, 80, n_epoch - n_epoch // 2)])
    temp_mean = T_NOMINAL_K + np.where(episode == 0, 20.0, 34.0) * np.exp(
        -tau / 10.0)
    temperature = temp_mean[:, None] + np.linspace(
        0.01, -0.01, n_led)[None, :] * (temp_mean - T_NOMINAL_K)[:, None]
    response = 0.9 + 0.05 * rng.standard_normal((n_sca, n_led, n_epoch))
    data = tg.Dataset(response, temperature, tau, episode,
                      np.full((n_sca, n_led), 1e-3), np.arange(n_epoch) * 1.0,
                      [1, 2, 3], led_names,
                      [f"E{i}" for i in range(n_epoch)],
                      dict(digest_dir="synthetic", cal_dir="synthetic",
                           mnemonic="synthetic", boundary_hours=[30.0, 60.0],
                           # One fitted and one modelled step, so the report's
                           # method split is exercised. The modelled one is
                           # deliberately the hot boundary: on the real set
                           # that is the decon transition, and judging it by
                           # temperature alone is a false alarm.
                           boundary_methods=["bridge", "multiplier"],
                           boundary_kinds=["deploy", "reposition"]))
    grid = np.linspace(20.0, 90.0, 4)
    fits = {m: tg.fit(data, mode=m, degree=2, growth_grid=grid, quiet=True)
            for m in tg.GAIN_MODES}
    nonparam = tg.nonparametric_gain(data, fits["shared"], n_bins=8)
    transfer = tg.episode_transfer(data, 1, 0, growth_grid=grid)
    variants = [dict(label="baseline", note="n", subset="all",
                     gain_hot=float(tg.gain_at(fits["shared"], T_HOT_K)),
                     rate=fits["shared"]["rate"],
                     chi2_red=fits["shared"]["chi2_red"],
                     bic=fits["shared"]["bic"],
                     n_data=fits["shared"]["n_data"])]

    with tempfile.TemporaryDirectory() as out_dir:
        plot_curve(data, fits, nonparam,
                   os.path.join(out_dir, "curve.png"), 60)
        plot_chromaticity(data, fits, os.path.join(out_dir, "chrom.png"), 60)
        plot_per_sca(data, fits, os.path.join(out_dir, "sca.png"), 60)
        plot_decomposition(data, fits, os.path.join(out_dir, "dec.png"), dpi=60)
        plot_transfer(data, transfer, os.path.join(out_dir, "xfer.png"), 60)
        plot_residuals(data, fits, os.path.join(out_dir, "resid.png"), 60)
        rows = plot_acm_boundaries(data, os.path.join(out_dir, "acm.png"), 60)
        assert len(rows) == 2, rows
        # The method split, not the temperature, decides which boundary could
        # have absorbed the gain. Without this the hot decon boundary raises a
        # false alarm about a step that was never fitted to the response.
        assert [r["fitted"] for r in rows] == [True, False], rows
        growth_rows = chromaticity_growth_test(data, degrees=(1, 2),
                                               quiet=True)
        assert len(growth_rows) == 2 and growth_rows[0]["gain_hot"].size == 6
        plot_chromaticity_growth(data, growth_rows,
                                 os.path.join(out_dir, "chromgrow.png"), 60)
        # Few permutations here on purpose: this asserts the plumbing (real
        # SCA names resolve against the geometry, the p-values come back
        # finite), not the significance of a 3-detector correlation.
        spatial = spatial_structure_test(data, fits, n_permute=200)
        assert len(spatial["rows"]) == 4, spatial["rows"]
        assert all(np.isfinite(r["p_permute"]) for r in spatial["rows"])
        assert spatial["gain_hot"].size == n_sca
        # Serial on purpose: a traceback raised inside a worker process loses
        # its frames, which makes this the wrong place to exercise the pool.
        # The parallel path has its own coverage in fit_temperature_gain.
        growth = growth_structure(data, shared=fits["shared"], processes=1,
                                  n_permute=200, quiet=True)
        assert np.asarray(growth["independent"]["rate"]).shape == (n_sca, 1)
        assert np.asarray(growth["per_episode"]["rate"]).shape == (n_sca, 2)
        assert {"rate", "dispersion", "curvature", "per_episode"} \
            <= set(growth["matched"]), growth["matched"].keys()
        # The control fit must exist and be per-detector, or the leakage test
        # in the verdict silently compares the free rate against itself.
        assert len(growth["gain_hot_shared_rate"]) == n_sca
        assert np.isfinite(growth["rate_gain"]["p_permutation"])
        plot_growth_structure(data, growth,
                              os.path.join(out_dir, "growth.png"), 60)
        plot_decomposition_per_sca(data, fits, growth,
                                   os.path.join(out_dir, "decsca.png"),
                                   led_index=0, dpi=60)

        freedom_rows = growth_freedom_test(data, processes=1, n_round=2,
                                           quiet=True)
        assert len(freedom_rows) == len(GROWTH_FREEDOM), freedom_rows
        # Every family must be represented, or the verdict's separation test
        # quietly degrades to "no comparison available" and says nothing.
        assert {r["freedom"] for r in freedom_rows} == {
            "none", "curvature", "placement", "both"}
        assert all(len(r["hot"]) == n_led for r in freedom_rows)
        plot_growth_freedom(data, freedom_rows,
                            os.path.join(out_dir, "freedom.png"), 60)

        invariance = film_invariance_test(data, fits["shared"], quiet=True)
        assert invariance["n_pair"] == n_sca * n_led, invariance["n_pair"]
        assert len(invariance["bands"]) == n_led
        assert np.isfinite(invariance["pull_rms"])
        assert np.isfinite(invariance["ratio_band_median"])
        invariance_sys = film_invariance_systematic(data, quiet=True)
        # All four growth models must report, or the "spread across models"
        # error bar is computed from too few rows to mean anything -- and the
        # whole point of this test is that that spread, not sigma_ratio, is
        # the error on the prior.
        assert invariance_sys["n_model"] == 4, invariance_sys["n_model"]
        assert invariance_sys["n_band"] == n_led
        assert invariance_sys["systematic_error"] > 0.0
        assert invariance_sys["stat_error"] > 0.0
        assert np.isfinite(invariance_sys["band_median"])
        # The degeneracy guard: whatever the fixture does, the quoted central
        # value must stay in the range where the ratio means anything. The
        # noise fixture's lowest-chi2 model returns 1e6, so this assertion is
        # live here rather than hypothetical.
        assert 0.1 < invariance_sys["band_median"] < 10.0, invariance_sys
        assert invariance_sys["degenerate"], "the noise fixture should trip it"
        plot_amplitude_invariance(data, invariance,
                                  os.path.join(out_dir, "invar.png"), 60,
                                  systematic=invariance_sys)
        # A single-episode set must return the not-testable form rather than
        # raising: the real decon-1-only subsets go down this path.
        one = tg.subset_episodes(data, [0])
        assert film_invariance_test(one, tg.fit(one, degree=2, quiet=True)
                                    )["pairs"] == []
        assert film_invariance_systematic(one, quiet=True)["rows"] == []

        written, scatter = write_tables(data, fits, variants, transfer,
                                        nonparam, out_dir,
                                        growth_rows=growth_rows,
                                        spatial=spatial, growth=growth,
                                        freedom_rows=freedom_rows,
                                        invariance=invariance,
                                        invariance_sys=invariance_sys)
        assert len(written) == 12, written
        amp_table = Table.read(
            os.path.join(out_dir, "tempgain_amplitude_systematic.ecsv"))
        assert len(amp_table) == 4, len(amp_table)
        # The dominant error must travel with the per-pair table, not only
        # with the summary one: a reader who opens the pair table and takes
        # sigma_ratio as the error reaches the opposite conclusion.
        pair_table = Table.read(
            os.path.join(out_dir, "tempgain_amplitude_invariance.ecsv"))
        assert "growth_model_systematic" in pair_table.meta, pair_table.meta
        assert scatter >= 0.0
        sca_table = Table.read(os.path.join(out_dir, "tempgain_per_sca.ecsv"))
        assert "x_center" in sca_table.colnames, sca_table.colnames
        assert "spatial_test" in sca_table.meta, sca_table.meta
        growth_table = Table.read(
            os.path.join(out_dir, "tempgain_growth_structure.ecsv"))
        assert "rate_ratio_decon2_decon1" in growth_table.colnames
        assert len(growth_table) == n_sca
        plot_robustness(variants, scatter, os.path.join(out_dir, "rob.png"), 60)
        verdict(data, fits, variants, transfer, scatter, rows, out_dir,
                growth_rows=growth_rows, spatial=spatial,
                freedom_rows=freedom_rows, growth=growth,
                invariance=invariance, invariance_sys=invariance_sys)
        path = os.path.join(out_dir, "tempgain_verdict.txt")
        assert os.path.exists(path)
        # This fixture is pure noise, so the transfer bracket is degenerate.
        # The verdict must SAY so rather than reporting a confident failure:
        # nan compares False against every threshold, so without an explicit
        # guard it falls through to the harshest branch.
        assert not np.isfinite(transfer["bracket"]), transfer["bracket"]
        text = open(path).read()
        assert "UNDECIDABLE" in text, text
    if verbose:
        print("tempgain_report self-test OK")
    return True


if __name__ == "__main__":
    self_test()
