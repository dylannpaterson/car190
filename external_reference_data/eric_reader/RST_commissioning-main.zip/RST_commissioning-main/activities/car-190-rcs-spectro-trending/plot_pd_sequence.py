#!/usr/bin/env python
"""Per-activity LED sequence diagnostics: enable, settle, exposure.

Reads the ``photodiode/`` group out of staged RCS products and writes one
``plots/pd_sequence/<run_label>.png`` per epoch, plus an ECSV of the settle
measurement across every epoch seen.

**On the premise.** This started as "plot the PD time stream against the PD in
the L2 file metadata". There is no PD in the L2 metadata: ``meta.rcs`` is
``{active, bank, counts, electronics, led}``, and none of the 146 metadata leaves
of a ``*_cal.asdf`` matches photo/diode/pd/current/volt/lamp/srcs. The PD lives
only in EDP housekeeping. What L2 contributes is the LED flag, the commanded
drive (``counts``) and the exposure bracket -- so the comparison this makes is
between the PD stream and the **in-exposure median** of that stream over the L2
exposure window, which is the value the L2 frame integrated against and the one
``rcs_corrections`` consumes.

No network and no credentials: the PD stream is ~2600 samples per epoch and is
already stored in the product, so this is offline and runs in well under a second
per epoch. Products staged before ``rcs_photodiode.write_photodiode_group``
existed have no ``photodiode/`` group and are reported as skipped; re-stage them,
or run ``process_rcs_trending.py --pd-only --pd-stream-h5`` which writes the
group without pulling any imagery.

Usage
-----
    .venv/bin/python plot_pd_sequence.py --in /data/eswitzer/rcs_trend_v2_test/h5
    .venv/bin/python plot_pd_sequence.py --in one_product.h5 --out-dir /tmp/seq
    .venv/bin/python plot_pd_sequence.py --self-test
"""
import argparse
import glob
import os
import sys

import numpy as np

DEFAULT_OUT_DIR = os.path.join("plots", "pd_sequence")
SUMMARY_COLUMNS = ("run_label", "key", "hardware_led", "enable_seconds",
                   "rail_seconds", "settled_at_s", "exposure_start_s",
                   "exposure_seconds", "settle_margin_s", "pd_exposure_v")


def discover(target):
    """h5 paths under ``target``, which may be a file or a directory."""
    if os.path.isdir(target):
        return sorted(glob.glob(os.path.join(target, "*.h5")))

    return sorted(glob.glob(target)) if any(c in target for c in "*?[") \
        else [target]


def run_label_for(path):
    """The product's ``run_label`` attribute, falling back to the filename."""
    import h5py

    with h5py.File(path, "r") as handle:
        value = handle.attrs.get("run_label")
    if value is None:
        return os.path.splitext(os.path.basename(path))[0]

    return value.decode() if isinstance(value, bytes) else str(value)


def write_summary(records, path):
    """Write the pooled settle measurement as an ECSV.

    Worth persisting rather than only plotting: ``settle_margin_s`` is a
    per-epoch, per-LED number, so once it exists across the trend a *change* in
    it is detectable -- a lamp that starts taking longer to come off the PD rail
    is a real degradation signature, and it is invisible in any quantity the
    digests currently carry.
    """
    from astropy.table import Table

    table = Table({name: [record[name] for record in records]
                   for name in SUMMARY_COLUMNS})
    table.meta["comments"] = [
        "RCS LED turn-on settle, measured from the photodiode housekeeping.",
        "rail_seconds: in-enable samples at the 2.5 V PD rail (saturated).",
        "settled_at_s: seconds after LED enable at which the PD reads on-scale.",
        "settle_margin_s: settled_at_s to exposure start. Negative would mean",
        "  the exposure integrated while the PD was off-scale.",
        "pd_exposure_v: in-exposure PD median -- the value the L2 frame",
        "  integrated against. L2 metadata itself carries no PD field.",
    ]
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    table.write(path, format="ascii.ecsv", overwrite=True)

    return path


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--in", dest="target",
                        help="h5 product, directory of products, or glob")
    parser.add_argument("--out-dir", default=DEFAULT_OUT_DIR)
    parser.add_argument("--summary", default=None,
                        help="ECSV of the pooled settle measurement "
                             "(default <out-dir>/pd_settle_summary.ecsv)")
    parser.add_argument("--dpi", type=int, default=120)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args(argv)

    if args.self_test:
        return 0 if self_test() else 1
    if not args.target:
        parser.error("--in is required unless --self-test is given")

    import rcs_photodiode
    import rcs_trend_plots

    paths = discover(args.target)
    if not paths:
        print(f"no h5 products matched {args.target}")
        return 1

    records, skipped, written = [], [], []
    for path in paths:
        label = run_label_for(path)
        reduction = rcs_photodiode.read_photodiode_group(path)
        if reduction is None:
            skipped.append(path)
            continue
        runs = rcs_photodiode.enable_runs(reduction)
        out = os.path.join(args.out_dir, f"{label}.png")
        rcs_trend_plots.plot_pd_sequence_timeline(reduction, label, out,
                                                  dpi=args.dpi, runs=runs)
        written.append(out)
        for record in runs:
            records.append(dict(record, run_label=label))
        margins = [r["settle_margin_s"] for r in runs]
        rails = [r["rail_seconds"] for r in runs]
        print(f"  {label}: {len(runs)} activities, "
              f"{sum(1 for r in rails if r)} railing, "
              f"min settle margin {min(margins) if margins else float('nan'):.0f} s"
              f"{'   NEGATIVE MARGIN' if margins and min(margins) < 0 else ''}")

    for path in skipped:
        print(f"  skipped (no photodiode/ group): {os.path.basename(path)}")

    if records:
        summary = args.summary or os.path.join(args.out_dir,
                                               "pd_settle_summary.ecsv")
        print(f"\nwrote {len(written)} figure(s) to {args.out_dir}")
        print(f"wrote {write_summary(records, summary)}")
        negative = [r for r in records if r["settle_margin_s"] < 0]
        print(f"activities exposing while the PD was railed: {len(negative)}"
              f"{'' if not negative else '  <-- INVESTIGATE'}")

    return 0


def self_test():
    """Render the sequence timeline from a synthetic reduction via a temp h5."""
    import tempfile

    import rcs_photodiode
    import rcs_trend_plots

    failures = []
    series, activities, _, _ = rcs_photodiode._synthetic_series()
    reduction = rcs_photodiode.reduce_photodiode(series, activities, quiet=True)

    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "synthetic.h5")
        rcs_photodiode.write_photodiode_group(path, reduction)

        # The round trip is the thing to test, not just the figure: the plot
        # reads a rebuilt reduction, so a reader that silently drops a field
        # would show up as a blank panel rather than an exception.
        restored = rcs_photodiode.read_photodiode_group(path)
        if restored is None:
            failures.append("read_photodiode_group returned None for a group "
                            "that was just written")
            restored = reduction

        if not np.allclose(restored.photodiode_array(),
                           reduction.photodiode_array(),
                           equal_nan=True):
            failures.append("pd_net did not survive the h5 round trip")
        if len(restored.intervals) != len(reduction.intervals):
            failures.append(
                f"interval count changed in the round trip: "
                f"{len(reduction.intervals)} -> {len(restored.intervals)}")
        if restored.pedestal.source != reduction.pedestal.source:
            failures.append("the pedestal source did not survive the round trip")

        runs = rcs_photodiode.enable_runs(restored)
        if not runs:
            failures.append("enable_runs found no activities in the synthetic "
                            "reduction")
        for record in runs:
            # Ordering invariants that hold by construction and would catch an
            # off-by-one in the run-to-exposure matching.
            if record["exposure_start_s"] < 0:
                failures.append(f"{record['key']}: exposure starts before its "
                                f"own LED enable")
            if record["exposure_start_s"] > record["enable_seconds"]:
                failures.append(f"{record['key']}: exposure starts after the "
                                f"LED enable interval ends")

        figure = os.path.join(tmp, "seq.png")
        rcs_trend_plots.plot_pd_sequence_timeline(restored, "synthetic", figure)
        if not os.path.exists(figure) or os.path.getsize(figure) < 10_000:
            failures.append("the sequence timeline PNG was not written, or is "
                            "implausibly small")

        empty = rcs_photodiode.reduce_photodiode({}, activities, quiet=True)
        blank = os.path.join(tmp, "empty.png")
        rcs_trend_plots.plot_pd_sequence_timeline(empty, "empty", blank)
        if not os.path.exists(blank):
            failures.append("the no-samples sequence figure was not written")

        if write_summary([dict(r, run_label="synthetic") for r in runs],
                         os.path.join(tmp, "s.ecsv")) is None:
            failures.append("the settle summary ECSV was not written")

    for message in failures:
        print(f"  FAIL {message}")
    print(f"plot_pd_sequence.self_test: "
          f"{'FAILED' if failures else 'ok'} ({len(failures)} failure(s))")

    return not failures


if __name__ == "__main__":
    sys.exit(main())
