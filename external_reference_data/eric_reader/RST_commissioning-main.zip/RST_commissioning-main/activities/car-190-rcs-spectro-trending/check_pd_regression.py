"""Check the new photodiode reduction against the arrays stored in existing h5.

The decisive test that the time-stream derivation in :mod:`rcs_photodiode`
matches the frozen compiler's ``pd_raw - pd_raw[0]`` *before* the old path is
removed. It needs no pixels and no network: ``process_rcs_trending.py --pd-only``
writes one ECSV per pass in seconds, and this compares those against
``dictionary/RCS_photodiode`` in whatever products already exist.

Two different comparisons, and the distinction is the point of the script:

``pd_net_legacy``
    The reduction's reimplementation of the old rule -- median over *all*
    in-window samples, minus the dark activity's own window. This must be
    **bit-exact**, and is checked at ``--legacy-atol`` (1e-12 by default). It is
    a pure regression gate: a failure here means the windowing or the median
    changed, not that the physics did.

``pd_net``
    The new quantity: median over the modal-state samples, minus the pedestal
    adopted from the dark-period off *interval*. This is deliberately **not**
    bit-exact, because the off interval is not the dark exposure window. Measured
    on the two anchor passes the two differ by exactly 8 quanta of the
    2.98e-07 V telemetry LSB (``10 V / 2**25``), i.e. 1e-5 of ``pd_net``, and
    that offset tracks the pedestal drift the reduction reports independently
    (-9.1e-06 V/hr over a 0.6 hr run). So the tolerance here is a statement
    about how much pedestal drift is tolerable, not about floating point.

A common offset shared by all six LEDs is the benign case: it cancels in the
``reference_pd / epoch_pd`` ratio that ``led_scale_factors`` actually forms. The
number to watch is therefore the *spread* across LEDs, which this reports
separately and which the response-factor column translates into the units that
matter.
"""
import argparse
import glob
import os
import sys

import h5py
import numpy as np
from astropy.table import Table

# 10 V full scale over 25 bits, inferred from the spacing of distinct PD levels
# in the EDP stream: the smallest nonzero step between adjacent levels is
# 2.9802322e-07 V across thousands of samples. Used only to express differences
# in units the hardware can actually represent -- a disagreement below one
# quantum is not a disagreement.
PD_QUANTUM_V = 10.0 / 2 ** 25


def _stored_arrays(path):
    with h5py.File(path, "r") as handle:
        if "dictionary/RCS_photodiode" not in handle:
            return None, None
        return (handle["dictionary/RCS_photodiode"][...].astype(float),
                handle["dictionary/RCS_forward_voltage"][...].astype(float))


def _find_product(h5_dirs, run_label):
    for directory in h5_dirs:
        matches = sorted(glob.glob(os.path.join(directory, f"{run_label}.h5")))
        if matches:
            return matches[0]

    return None


def compare(ecsv_path, h5_dirs, atol, legacy_atol):
    """One pass: the ECSV against its stored product. Returns a result dict."""
    table = Table.read(ecsv_path)
    run_label = table.meta.get("run_label") or \
        os.path.basename(ecsv_path)[3:].rsplit(".", 1)[0]
    product = _find_product(h5_dirs, run_label)
    if product is None:
        return {"run_label": run_label, "status": "no-product"}

    stored, stored_forward = _stored_arrays(product)
    if stored is None:
        return {"run_label": run_label, "status": "no-dictionary"}

    # CAR-216 reduces 11 activities but the legacy dictionary holds only the
    # core 7; the aux flats have no slot there. Comparing the leading 7 is the
    # whole of what the old product can speak to.
    n = len(stored)
    if len(table) < n:
        return {"run_label": run_label, "status": "short-ecsv"}

    new_net = np.asarray(table["pd_net"][:n], dtype=float)
    legacy = np.asarray(table["pd_net_legacy"][:n], dtype=float)
    forward = np.asarray(table["forward_v"][:n], dtype=float)

    delta = new_net - stored
    lit = slice(1, n)                       # entry 0 is the dark, net 0 by rule
    result = {
        "run_label": run_label,
        "product": product,
        "n": n,
        "legacy_max": float(np.nanmax(np.abs(legacy - stored))),
        "new_max": float(np.nanmax(np.abs(delta))),
        "new_offset": float(np.nanmedian(delta)),
        "new_spread": float(np.nanstd(delta[lit])),
        "forward_max": float(np.nanmax(np.abs(forward - stored_forward))),
        # What the disagreement does to the thing the corrections form. A
        # fractional change in pd_net is a fractional change in the response
        # factor, so this is the number with physical units attached.
        "factor_ppm": float(np.nanmax(np.abs(delta[lit] / stored[lit])) * 1e6),
        "pedestal_source": table.meta.get("pedestal_source", "?"),
        "pedestal_drift": float(table.meta.get("pedestal_drift_v_per_hr",
                                               np.nan)),
        "warnings": list(table.meta.get("warnings") or []),
        "invalid": [str(row["key"]) for row in table
                    if not row["pd_net_valid"] and not row["is_dark"]],
    }
    result["status"] = "ok"
    if result["legacy_max"] > legacy_atol:
        result["status"] = "LEGACY-MISMATCH"
    elif result["new_max"] > atol:
        result["status"] = "DRIFT"

    return result


def main():
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--pd-dir", required=True, dest="pd_dir",
                        help="directory of pd_<run_label>.ecsv files written by "
                             "process_rcs_trending.py --pd-only")
    parser.add_argument("--h5-dir", required=True, dest="h5_dirs", nargs="+",
                        help="one or more directories of existing products to "
                             "compare against, searched in order")
    parser.add_argument("--atol", type=float, default=1e-5,
                        help="tolerance on pd_net vs the stored array (default "
                             "1e-5 V, ~34 telemetry quanta). This bounds "
                             "pedestal drift, not floating point")
    parser.add_argument("--legacy-atol", type=float, default=1e-12,
                        dest="legacy_atol",
                        help="tolerance on the legacy mirror, which must be "
                             "bit-exact (default 1e-12)")
    parser.add_argument("--quiet", action="store_true",
                        help="only print rows that are not ok")
    args = parser.parse_args()

    paths = sorted(glob.glob(os.path.join(args.pd_dir, "pd_*.ecsv")))
    if not paths:
        raise SystemExit(f"no pd_*.ecsv files in {args.pd_dir}")

    results = [compare(path, args.h5_dirs, args.atol, args.legacy_atol)
               for path in paths]

    print(f"{'run_label':<34} {'stat':>7} {'legacy':>10} {'new':>10} "
          f"{'offset':>10} {'spread':>9} {'ppm':>7} {'pedestal':>12}")
    for result in results:
        if result["status"] in ("no-product", "no-dictionary", "short-ecsv"):
            if not args.quiet:
                print(f"{result['run_label']:<34} {result['status']:>7}")
            continue
        if args.quiet and result["status"] == "ok":
            continue
        print(f"{result['run_label']:<34} {result['status']:>7} "
              f"{result['legacy_max']:10.2e} {result['new_max']:10.2e} "
              f"{result['new_offset']:+10.2e} {result['new_spread']:9.2e} "
              f"{result['factor_ppm']:7.1f} {result['pedestal_source']:>12}")
        for message in result["warnings"]:
            print(f"    WARNING: {message}")
        if result["invalid"]:
            print(f"    pd_net_valid is False for: "
                  f"{', '.join(result['invalid'])}")

    compared = [r for r in results if r["status"] not in
                ("no-product", "no-dictionary", "short-ecsv")]
    bad = [r for r in compared if r["status"] != "ok"]
    print()
    print(f"{len(compared)} of {len(results)} ECSV(s) had a product to compare "
          f"against; {len(bad)} outside tolerance")
    if compared:
        worst_legacy = max(r["legacy_max"] for r in compared)
        worst_ppm = max(r["factor_ppm"] for r in compared)
        print(f"  worst legacy mirror disagreement : {worst_legacy:.2e} V "
              f"({worst_legacy / PD_QUANTUM_V:.2f} telemetry quanta)")
        print(f"  worst response-factor impact     : {worst_ppm:.1f} ppm")
    print("VERDICT:", "FAIL" if bad else "PASS")

    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
