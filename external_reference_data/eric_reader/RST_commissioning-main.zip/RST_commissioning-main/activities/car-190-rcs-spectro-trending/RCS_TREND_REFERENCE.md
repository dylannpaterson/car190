# RCS trending products: format reference

This is for RCS reference h5 consumers. For producers see
`README.md` ("Running the pipeline", "Work flows", "Batch processing with SLURM"); for the
reasoning behind individual corrections see `PD_CORRECTION.md` (photodiode), `PER_DECON_NORM.md`
(decon gauging) and `DIGEST_TRENDS.md` (reading the trends).

Describes the rcs_trend_v4 tree (MCE side A, then B from 2026-10-06), which grows with every
intake; revised 2026-10-14. Calibrated products are
**schema 2**: nothing is applied to the pixels, every factor is recorded (Sec. 4).

---

## Data levels

There are three stages of data products: 

| stage | script | output | one file per |
|---|---|---|---|
| 1 | `process_rcs_trending.py` | `<run_label>_raw.h5` (~17 MB CAR-190, ~28 MB CAR-216) + `pd/pd_<run_label>.{h5,ecsv}` | epoch |
| 2 | `calibrate_rcs_products.py` | `<run_label>_cal.h5` (same size: same pixels, plus `calibration/`) + `rcs_reference_card.ecsv` | epoch (+ one card per set) |
| 3 | `make_sca_digests.py` | `time_series_SCA<n>.ecsv` + `run_log.txt` + figures + `rcs_bridge_solution.ecsv` | detector |

Two pinned inputs sit beside stage 2 rather than in it, each fitted from the whole trend and fed
back so that every per-epoch file carries it:

- `rcs_bridge_solution.ecsv` (Sec. 6.7), the fitted ACM and side-swap bridges, written by stage 3
  (`--solution-out`) and recorded by stage 2 (`--bridge-solution`);
- `tempgain_model.ecsv` (Sec. 6.4), written by `fit_temperature_gain.py` and recorded by stage 2
  (`--tempgain-model`).

Both are a bootstrap, not a loop. They are fitted from response that the second stage-2 pass
does not change, since it adds metadata and no pixel or per-file factor moves. `run_trend.py`
runs the whole sequence and verifies it closes: the bridges refit identically, and `LED1...LED6`
are bit-identical between the two digest passes.

Pick by question:

- **"What did the instrument read at this epoch?"** -> the raw h5, or the calibrated one: their
  pixels are bit-identical. Only the raw sidecars hold the full photodiode timestream.
- **"What is the calibrated image at this epoch?"** -> the calibrated h5's pixels times the steps
  you want (Sec. 4). `rcs_trend_reader.py` does it: `RcsProduct(path).stack("LED3")`.
- **"Which corrections are there, and how big?"** -> `calibration/<step>/multiplier` (Sec. 4), or
  `python rcs_trend_reader.py summary FILE`.
- **"How did the response trend?"** -> the digests. This is what the film-growth fitters read, and
  what you want 95 % of the time. They apply every step except the provisional temperature gain,
  which is in their `LEDx_tgcorr` columns.
- **"Why does the trend look like that?"** -> `run_log.txt` next to the digests. It holds
  everything the digest numbers are conditioned on but does not itself contain:
  - CAR and decon membership;
  - where the ACM moved, and whether the step was measured or modelled;
  - the side swap and its bridge;
  - which photodiode readings were refused;
  - detector coverage.

The current set, deployed on the shared mount since 2026-10-12
(`ROOT = /mnt/smdc-rom-com-ops/rrn-ops/activities/car-190-rcs-spectro-trending/rcs_trend_v4`,
group `romcom`; `rcs_trend_config.TREND_ROOT`):

```
$ROOT/h5/          raw products, one per epoch, + h5/pd/ (an ECSV and an h5 sidecar each)
$ROOT/cal/         calibrated products, one per epoch, schema 2
$ROOT/rcs_reference_card.ecsv       per-side PD reference
$ROOT/rcs_bridge_solution.ecsv      ACM + side bridges
$ROOT/tempgain_model.ecsv           the v4 gain fit
$ROOT/digests/digests_v4_<mm_dd_yy>/  18 digests + run_log.txt   <-- the newest set is current
$ROOT/digest_plots/, $ROOT/plots/   the figures
$ROOT/SEEDED_FROM.txt               where the tree was copied from, and when
```

Digest sets from before the deployment (through `digests_v4_10_10_26`) are in the
repo's `digests/`.

`rcs_trend_v3` (176 epochs, side A only, schema 1) is kept unchanged; `digests_v3_10_07_26` is
its digest set.

---

## 2. Conventions that hold across every product

**Two LED namespaces, and the map between them depends on the MCE side.** Activity keys
`LED1...LED6` are *sequence* names. They carry the wavelengths and name the same physical LED on
both sides. `hardware_led` is the EDP `BANK2SEL` select line enabled during the activity, and
the B-side MCE numbers those lines differently:

| sequence key | LED1 | LED2 | LED3 | LED4 | LED5 | LED6 |
|---|---|---|---|---|---|---|
| wavelength (nm) | 624 | 853 | 1039 | 1270 | 1481 | 1670 |
| WFI filter | F062 | F087 | F106 | F129 | F158 | F184 |
| `hardware_led`, side A (181 epochs) | 6 | 1 | 2 | 3 | 4 | 5 |
| `hardware_led`, side B (from pass 71) | 1 | 3 | 2 | 4 | 6 | 5 |

The renumbering is not a wavelength change: PD1's InGaAs 1670 nm cutoff stays on sequence LED6
across the swap, and LED2 keeps its PD1/PD2 ratio. **Key everything by sequence name.** Two
mistakes this repo has made by keying on the hardware number:
- it once documented PD1's suppressed channel at 1481 nm, when it is the 1670 nm cutoff;
- keyed by hardware number, the two-diode ratio would compare different LEDs at four of six
  positions across the swap.

The LED map is also a per-pass side witness (`batch/side_witness.py`).

**NaN is the absence marker, never 0.** A detector that did not downlink is an all-NaN plane, so
the finiteness pattern of a stack *is* the coverage record. Use `np.nanmedian` and friends
throughout. On the current set the lit LED stacks are 99.90 % finite (edge superpixels lost to DQ
and binning), and `sca_arrays/DARK` is **0 % finite** -- see Sec. 3.

**Units.** Pixels are DN/s. Photodiode and LED forward voltages are volts. LVDT is in raw counts.
Times in the digests are hours since the reference epoch; times inside the h5 are ISO-8601
strings, except `photodiode/stream/time`, which is int64 nanoseconds since the Unix epoch
(its `units` attr says so).

**Ordering is by timestamp, never by filename.** Filenames sort lexicographically, which puts
pass 100 before pass 36 and interleaves CAR190 with CAR216. Use `make_sca_digests.discover_h5_files`
(or sort on the product's own `dictionary/timestamp`); `sorted(os.listdir())` has produced a
confidently wrong decon verdict in this repo before.

**`pass_number` is not a unique key.** On the current set, CAR216 passes 1-36 each occur **twice**
-- once in execution plan 2 and once in plan 3 -- so 36 `(car_label, pass_number)` pairs are
duplicated. The unique epoch key is `run_label`, which encodes program, plan and pass
(`CAR216_01063_03_012_001_20260927`). Joining anything on `pass_number` alone will silently
double-count.

**Several gauges, which are easy to conflate.**

| gauge | what is exactly 1.0 | set by |
|---|---|---|
| response origin (digests) | the earliest epoch, A-side pass 1 (`reference_epoch`) | the reference card |
| photodiode | the first epoch **of each MCE side** | the card's `side_reference_pd` |
| linear ACM | each ACM segment's *own first* epoch; a side change opens a segment | `segment_reference_lvdt` |
| ACM and side bridges (h5) | the **present** configuration: side B, the latest ACM segment | the bridge solution |

The h5 products record the last three. The digests divide every epoch's multiplier by the
reference epoch's, which is what makes them 1.0 at pass 1. Both describe the same calibrated
data, and differ by one constant per (LED, SCA). The attribute name
`acm_segment_reference_lvdt` says "segment" because the segment's reference epoch is usually not
the response origin.

---

## 3. The raw product -- `<run_label>_raw.h5`

`stage = "raw"`, `schema_version = "rcs-per-sca/1.0"`, `product_kind = "per_sca"`,
`pipeline_version = "rcs-trending/2.0"`. Written atomically (`rcs_products._AtomicH5`, writes
`path.tmp-<pid>` then `os.replace`), gzip-4 + shuffle + fletcher32 on every dataset.

Five groups. `photodiode/` is appended in a deliberate second pass after the atomic replace, so a
product can exist with imagery and no photodiode group if that second pass failed.

### `sca_arrays/<activity_key>` -- the pixels

One `(18, 256, 256)` float32 dataset per activity: 18 detectors, 256x256 superpixels of 16x16
raw pixels (`bin_factor = 16`, `sca_pix = 4096`, 4096/16 = 256 exactly -- see the legacy-binning
trap in Sec. 8).

Activity keys present depend on the CAR:

- **CAR190**: 7 activities -- `DARK`, `LED1`...`LED6`.
- **CAR216**: 11 activities -- the same 7 plus `AUX_LED3FLAT1`...`AUX_LED3FLAT4` (`n_aux_activities = 4`,
  `is_aux = True`), the four 41 s band-3 flats. They are obs 9 in the `car216` sequence and obs 11 in
  `car216_decon3` (CAR-216 plan 6 on, 2026-10-20), which also has low-flux band-3 flats and more
  darks. Only the 41 s flats reach L2: the 66 s low-flux flats are 22 resultants, and L2
  processing takes 16 or fewer. Aux keys are assigned by what an exposure is
  (`rcs_activities.aux_key_base`), so a future layout that does reach L2 adds keys such as
  `AUX_LED3LOWFLUX1..5` rather than renaming these. Only `DARK` and `LED1`...`LED6` are trended.
  MANIFEST.md, *Sequence variants*, lists every layout.

`DARK` is a **named all-NaN placeholder on this entire generation of products**, not dark
imagery: `dark_image_available = False`, `dark_policy = "none; the dark has no L2 products and
its stack is an all-NaN placeholder"`. The activity is kept so the product's activity list matches
the sequence that ran, and so the photodiode's dark window has something to be keyed to. Nothing
has ever been dark-subtracted at any stage (`dark_subtracted = False`); the justification is that
the dark is negligible against the illuminated frames and baking a subtraction in would destroy
the ability to check it later.

Per-dataset attributes: `activity_led`, `activity_number`, `dark_blank`, `end_time`, `exposure`,
`exposure_time`, `file_set_name`, `hardware_led`, `is_aux`, `is_dark`, `n_sca`, `observation`,
`optical_element`, `pull_bytes`, `pull_seconds`, `scas_present` (a comma string, e.g.
`"1,2,...,18"`), `staging_id`, `start_time`, `units` (`"DN/s"`), `visit_id`.

Note `optical_element = "DARK"` on the *lit* LED stacks too: that is the WFI element wheel
position (the RCS illuminates through the dark position), not a statement about the exposure.

### `coverage/` -- which detector has data

`activity_key` (per activity), `per_activity` (n_act, 18) bool, `per_sca` (18) bool, `fraction`
(n_act, 18) float32. `per_sca` carries a `rule` attr spelling out how it was reduced
(`"logical AND over activities with any coverage; all-NaN placeholders excluded"`), which matters
because the DARK placeholder would otherwise zero it out.

### `housekeeping/` -- telemetry, resolved per activity

Index columns `activity_key`, `activity_number`, `start_time`, `end_time`, `is_aux`; one float64
column per mnemonic; `led_select_1...6`; `ACM_LVDT_valid` (6) bool. The 15 mnemonics:

`WFI_MCE_LVDT_ACM_1...6`, `WFI_MCE_SRCS_PD1_V`, `WFI_MCE_SRCS_PD2_V`,
`WFI_MCE_SRCS_BANK1_LED_V`, `WFI_MCE_SRCS_BANK2_LED_V`, `WFI_MCE_SRCS_SPHERE_T`,
`WFI_MCE_SRCS_BOARD_T`, `WFI_COBA_WTSC10P_K`, `WFI_MCU_A_MPA_CSENS_FPSSEN_K`,
`WFI_MCU_B_MPA_CSENS_FPSSEN_K`.

**Every mnemonic has a companion `rule_<mnemonic>` string column** valued `window`, `nearest` or
`missing`. `window` means samples fell inside the activity's own time window and were reduced;
`nearest` means the closest sample outside the window was substituted; `missing` means no value.
A `nearest` value is an *extrapolation* and must not be treated as a measurement of that
activity -- that is the entire point of carrying the column.

### `photodiode/` -- the lamp-output record

Group attrs: `pd_column` (`WFI_MCE_SRCS_PD2_V`, the measurement diode), `pd_check_column`
(`WFI_MCE_SRCS_PD1_V`, the check diode), `forward_column`, `pd_min_net` (0.01 V), `pd_rail_v`
(2.5 V), `n_railed_in_window`, `warnings`, and `dictionary_is_legacy` (**do not read this as
provenance** -- see Sec. 8).

| subgroup | shape | contents |
|---|---|---|
| `stream/` | (n_samples,) -- 2 623 on a CAR216 epoch | `time` (int64 ns), `pd_v`, `forward_v`, `pd_check_v`, `state` (int8), `activity_index` (int8). The raw timestream. |
| `intervals/` | (n_intervals,) -- 22 | `state`, `t_begin`, `t_end`, `n_samples`, `pd_median`, `pd_mad`, `is_transition`. The stream segmented by LED-enable state. |
| `per_activity/` | (n_act,) | 21 fields, the per-activity reduction: `pd_raw`, `pd_raw_all`, `pd_net`, `pd_rms`, `pd_n_samples`, `pd_net_valid`, `pd_net_legacy`, `pd_check_v`, `pd_check_net`, `pd_check_ratio`, `forward_v`, `hardware_led`, `state_code`, `state_pure`, `state_fraction`, `n_railed`, `rule`, `is_dark`, `number`, `multiple_leds`, `activity_key`. |
| `pedestal/` | attrs only | PD2's dark level: `value`, `rms`, `n_samples`, `source`, `drift_v_per_hr`, `warnings`. |
| `check_pedestal/` | attrs only | PD1's own dark level, same fields. PD1 and PD2 are different devices with different pedestals -- ~4.3 mV apart on this set, from the same dark window. |

`pd_net = pd_raw - pedestal` is the denominator of the photodiode correction. `source` is one of
`dark_window`, `pooled_off`, `nearest_off`, `unavailable`.

### `dictionary/` -- the frozen legacy mirror

A positional mirror of the pre-2.0 product layout, kept so legacy readers keep working:
`timestamp`, `COBA_temp`, `RCS_Sphere_temp`, `RCS_Board_temp`, `MPA_A_temp`, `MPA_B_temp`,
`ACM_LVDT` (6), `RCS_forward_voltage` (7), `RCS_photodiode` (7). Each dataset carries an
`original_type` attr.

`RCS_photodiode` holds the *dark-first* vector: index 0 is the dark activity, 1-6 are the LEDs.
Stage 2 reads this array and drops index 0. On this generation it is element-wise equal to
`photodiode/per_activity/pd_net` (verified), i.e. it holds the **new** pedestal-subtracted
values despite living in the group flagged "legacy". Only the *layout* is legacy. The root attr
`photodiode_source` is what tells you which reduction a file holds; on this set it reads
`"pd_net (dark-window pedestal)"`.

### Root attributes

33 on a MAST-sourced product, 43 on an aux-sourced one (the difference is the ten-attr L2
provenance block -- see Sec. 7, this is specific to the current generation).

*Identity:* `run_label`, `car_label`, `program`, `execution_plan`, `pass_number`, `segment`,
`decon_cycle`, `timestamp`, `time_start`, `time_end`, `created`.
*Format:* `schema_version`, `stage`, `product_kind`, `pipeline_version`, `bin_factor`, `sca_pix`,
`n_sca`, `n_activities`, `n_aux_activities`, `orientation`.
*Coverage:* `coverage_n_sca`, `coverage_complete`, `acm_lvdt_channels_valid`.
*Instrument configuration:* `mce_side`, `mce_side_source`, `mce_bank`.
*Sequence:* `sequence_variant` (a name in `rcs_trend_config.SEQUENCE_VARIANTS`, or `UNKNOWN`),
`sequence_signature` (the pass's L1 layout), `sequence_source`. Recorded from 2026-10-22, from the
query plan; a product staged from an older plan has `sequence_variant = ""` and a
`sequence_source` saying so, until a batch rerun re-plans and re-stages it.
*What was and was not done:* `dq_applied`, `dark_subtracted`, `dark_image_available`,
`dark_policy`, `photodiode_source`, `provenance`.
*L2 provenance (aux products only on this set):* `l2_source`, `l2_source_dir`, `crds_context`,
`crds_version`, `ref_file_id`, `l2_file_date`, `l2_provenance_frame`, `cal_step_photom`,
`cal_step_flat_field`, `calibration_software_version`.

Three of these are weaker than they look:

- **`n_sca = 18` is nominal focal-plane geometry**, not coverage. Per-activity coverage is
  `sca_arrays/<key>@n_sca` and `@scas_present`.
- **`mce_bank = "BANK2"` is hard-coded**, not read from telemetry.
- **`mce_side` is `assumed`** on every product in this set; `mce_side_source` says so. See Sec. 7.

### The PD sidecars -- `pd/pd_<run_label>.{h5,ecsv}`

Written beside the imagery, and the only way to get the photodiode without opening a 33 MB file.
The **h5** sidecar holds the full settle structure; the **ECSV** holds only the per-activity
reduction, so interval/settle structure is *not* recoverable from it.

ECSV columns, one row per activity including the dark: `key`, `number`, `state_code`,
`hardware_led` (**-1 substitutes for "none"** -- dark, off, unknown or multiple -- because astropy
cannot type `None`), `pd_raw`, `pd_raw_all`, `pd_net`, `pd_rms`, `pd_n_samples`, `forward_v`,
`pd_check_v`, `pd_check_net`, `pd_check_ratio`, `pd_net_valid`, `state_pure`, `state_fraction`,
`is_dark`, `rule`, `n_railed`, `pd_net_legacy`.

Meta: `pedestal_v`, `pedestal_rms_v`, `pedestal_n_samples`, `pedestal_source`,
`pedestal_drift_v_per_hr`, `check_pedestal_v`, `check_pedestal_source`,
`check_pedestal_drift_v_per_hr`, `pd_check_column`, `pd_column`, `pd_min_net`, `pd_rail_v`,
`n_railed_in_window`, `n_pd_samples`, `n_state_intervals`, `warnings`, `run_label`,
`pd_pad_minutes`. A newer `check_pedestal_rms_v` key exists in the writer but is carried by
**0 of the 176** sidecars on disk; read PD1's dark scatter from `pd/<...>.h5`
`photodiode/check_pedestal@rms` instead.

---

## 4. The calibrated product -- `<run_label>_cal.h5`, schema 2

`stage = "calibrated"`, root `calibration_schema = 2`. **Nothing is applied to the pixels.**
Measured on the v4 set, `sca_arrays/` are bit-identical to the raw product's, dtype included.
What the calibrated product adds is `calibration/`, holding every factor needed to calibrate the
epoch. Each one is recorded but not applied, so a consumer picks the steps it wants:

- the digests apply all of them, the temperature gain separately;
- `rcs_trend_reader.py` applies whichever a user names.

Schema 1 (`rcs_trend_v3/cal`) had photodiode, side and ACM multiplied into the pixels. Stage 3
still reads it, but refuses a set that mixes the two schemas.

**The product is NOT normalized to the reference epoch.** The multipliers are absolute (Sec. 2,
gauges). The ratio to pass 1 is a stage-3 operation, and so is the per-SCA median.

### `calibration/` -- one group per step, one rule

```
calibration/led_name          (6,)  vlen str    axis label
calibration/sca               (18,) int         axis label, 1-based
calibration/total_multiplier  (6, 18)           product of every step except tempgain
calibration/total_valid       (6, 18) bool
calibration/<step>/multiplier (6, 18)           on (led_name, sca)
calibration/<step>/valid      (6,)  bool
calibration/<step>/error      acm_bridge (18,), side_bridge (6,): composed total error
calibration/bridge_solution/  the WHOLE fitted bridge solution, one dataset per column (Sec. 6.7)
```

**calibrated = raw x multiplier**, for every step. A step that does not vary by SCA is broadcast
to `(6, 18)`, not stored as `(6,)`, so every step has the same shape and applying any subset is
one product. The ACM term, which divides in its own formula, is stored as its reciprocal for the
same reason. Index by the axis **labels**: a permuted grid hands one detector another's
correction with nothing to notice.

| step | varies by | definition | parameters in the group |
|---|---|---|---|
| `photodiode` | LED | `pd_reference / pd_net` | datasets `pd_net`, `pd_reference`; attrs `pd_reference_mode` (`per-side`), `pd_reference_epoch`, `gauge`, `invalid_policy` |
| `acm` | -- (scalar) | `1 / (1 + acm_coefficient * ((acm_lvdt + acm_offset)/acm_segment_reference_lvdt - 1))` | attrs `acm_lvdt`, `acm_segment`, `acm_segment_reference_lvdt`, `acm_coefficient` (-0.0100 A / -0.0095 B), `acm_offset` (0 A / 60 B) |
| `acm_bridge` | SCA | product of the fitted per-SCA steps at every ACM boundary **after** this epoch | dataset `error` (18,); attrs `boundaries_after`, `gauge`, `solution`, `solution_sha256`, `details` |
| `side_bridge` | LED | product of the fitted per-LED, SCA-common steps at every side change after this epoch | dataset `error` (6,); attrs `boundaries_after`, `gauge`, `ground_b_side_corrections` (TVAC table, comparison only), `ground_note`, `solution`, `solution_sha256` |
| `tempgain` | LED, SCA | `1/G(T)` at each LED's own activity temperature; **provisional** | datasets `temperature_k`, `temperature_rule`; attrs as below |

Every step group also carries `applied = False`, `axes`, `rule` and `definition`. A step whose
input was not given is **absent**, never present-and-unity:
- the bridges need `--bridge-solution`;
- the gain needs `--tempgain-model`.

A consumer that needs an absent step therefore fails on a missing key instead of carrying an
uncorrected 1.0. Across a set there are three legal states for each of the bridges and the gain:
every product carries it from one source file, none does, or the stage-3 build refuses.

The `calibration/` group attrs name the composition: `calibration_schema`, `rule`,
`steps_recorded`, `total_multiplier_steps`, `pixels`, `trend_gauge_note`, `helper`.

#### The temperature-gain step

The product carries the **evaluated multiplier, not the model**: what to multiply by, for this
LED, this SCA, at this trend point. The coefficients are deliberately absent;
`model_sha256` points back to `tempgain_model.ecsv` (Sec. 6.4). `multiplier = 1/G(T)`: a detector
is less responsive hot, so above nominal the multiplier is **greater** than 1. A few LEDs read a
few hundredths of a kelvin below 89.5 K and get a multiplier just under 1. That is right, not a
bug.

Two rules, unchanged from schema 1:
- **The gain is evaluated per LED activity, never at an epoch mean.** The six LEDs span up to
  0.8 K on a cooldown, and sequence order is wavelength order, so an epoch mean would turn an
  achromatic gain into a chromatic ramp.
- **An LED with no usable temperature gets NaN.**

Attrs: `model`, `model_sha256`, `model_form`, `model_t_nominal_k`, `model_t_scale_k`,
`temperature_mnemonic`, `temperature_note`, `n_invalid`, `coverage_note`, `provisional_note`.
It is excluded from `total_multiplier`, and so from the digests' `LED1...LED6`. The gain fit reads
those columns, so including it would make the fit read its own output.

#### Loading and applying

```python
import h5py, numpy as np

with h5py.File("CAR190_01039_03_071_001_20261006_cal.h5") as h5:
    cal = h5["calibration"]
    leds = [s.decode() if isinstance(s, bytes) else str(s) for s in cal["led_name"][()]]
    scas = list(cal["sca"][()])                       # 1..18
    raw = h5["sca_arrays/LED3"][()]                   # (18, 256, 256), nothing applied
    row = leds.index("LED3")
    order = [scas.index(n) for n in range(1, 19)]     # by label, never by position

    everything = cal["total_multiplier"][()][row, order]          # all but the gain
    with_gain = everything * cal["tempgain/multiplier"][()][row, order]
    no_bridges = (cal["photodiode/multiplier"][()] * cal["acm/multiplier"][()])[row, order]

calibrated = raw * everything[:, None, None]          # one factor per detector plane
```

or, without writing any of that:

```python
from rcs_trend_reader import RcsProduct
p = RcsProduct(path)
calibrated = p.stack("LED3", exclude=("tempgain",))
```

**For a trend, apply the ratio to your first epoch, `m[i]/m[0]`.** The absolute multipliers are
gauged to the present configuration and to each side's photodiode reference, so applying them
as they stand gives a series offset from 1.0 by a constant per (LED, SCA). The constant is
correct but surprising. `RcsTrend(cal_dir).series()` and the digests both divide it out.
Do not apply the gain to the digests' `LED1...LED6` *and* use their `LEDx_tgcorr` columns; that
counts it twice.

### `calibration/bridge_solution/` -- every bridge number, in every product

The two bridge steps above give only this epoch's composed multiplier. What the
digests say *about* the bridges is embedded alongside it:
- each step at each boundary;
- its errors, method and fallback note;
- LED spread and residual rms;
- the side bridge's error split, its pattern test, and each SCA's own estimate.

It is the complete `rcs_bridge_solution.ecsv` table (Sec. 6.7), one dataset per column (one row per
boundary and SCA for the ACM bridges, per boundary and LED for the side bridge), with the file's meta as group attributes. Every product calibrated against one
solution carries the same table (`solution_sha256`), so **any single product holds all of it**.
Until 2026-10-09 these numbers existed only in the digests' `bridge_*` / `side_bridge_*` meta and
in the solution file; a product carried the multiplier but not how well it is known.

```python
from rcs_trend_reader import RcsProduct
rows, meta = RcsProduct(path).bridge_solution()      # list of row dicts + attrs
# or: python rcs_trend_reader.py bridges FILE
```

It is not a step (no `multiplier`), and `kind = side_sca` rows are never applied.

### Self-contained: rebuilding the digests from the products alone

A directory of calibrated products holds everything the digests report. `rcs_trend_reader.py`
rebuilds the digests from it without importing anything from the pipeline:

```bash
python rcs_trend_reader.py compare $ROOT/cal $ROOT/digests/<newest digests_v4_* set>
python rcs_trend_reader.py trend   $ROOT/cal --ecsv out/ --plot out/
```

Measured on the current set: **102 columns and meta keys, 88 identical bit for bit, the other 14
within 6.7 x 10^-16**. The 14 are `LED1...6`, `LED1...6_tgcorr` and `bridge_factor`, the values that
involve a median. Where each comes from:

| digest quantity | from the products |
|---|---|
| `time_hours`, `timestamp` | `dictionary/timestamp`, relative to the earliest product |
| `pass_number`, `car_label`, `decon_cycle` | root attrs |
| `decon_time_hours`, `decon_episode_*`, `decon_reference_epochs` | contiguous runs of `decon_cycle` |
| `LED1...LED6` | per-SCA nanmedian of `sca_arrays/<LED>` / the first product's, x the ratio of `total_multiplier` to the first product's |
| `LEDx_tgcorr`, `tempgain_LEDx`, `tempgain_reference_multiplier` | the same x `calibration/tempgain/multiplier` ratioed to the first product |
| `bridge_factor` | `calibration/acm_bridge/multiplier`, ratioed to the first product |
| `side_bridge_LEDx` | `calibration/side_bridge/multiplier`, ratioed to the first product |
| `acm_lvdt` | nanmean of `dictionary/ACM_LVDT` |
| `acm_segment`, `acm_segment_reference_lvdt` | root attrs |
| `acm_move_*`, `acm_deploy_*`, `acm_n_moves`, `n_acm_segments` | where `acm_segment` changes; the kind from `bridge_solution/transition`; a deploy is the move whose LVDT crosses zero |
| `acm_max_fractional_travel` | `(acm_lvdt + acm_offset) / acm_segment_reference_lvdt - 1`, `acm_offset` from `calibration/acm` |
| `bridge_steps`, `_method`, `_notes`, `_step_errors`, `_systematic(_per_boundary)`, `_led_spread`, `_rms_pre/_post`, `_boundary_epochs`, `_degree`, `_window_hours` | `calibration/bridge_solution`, `kind = acm` rows and attrs |
| `side_bridge_*` (steps, the four errors, n, degree, window, pattern test, this SCA's own steps and offset) | `calibration/bridge_solution`, `kind = side` and `side_sca` rows and attrs |
| `side_bridge_ground_inverse_b_side` | `calibration/side_bridge` attr `ground_b_side_corrections` |
| `photodiode_flagged_epochs` | any NaN in `calibration/photodiode/multiplier` |
| `product_kind`, `product_stage`, `bin_factor`, `calibration_schema`, `acm_move_min_delta_lvdt`, `tempgain_model(_sha256)`, `tempgain_form`, `tempgain_mnemonic` | root and step attrs |

Not reproduced, by design, because they are not data about the instrument:

- fixed prose: the `*_note` keys and the `led_names` lists;
- descriptions of the digest run itself: `created`, `data_root`, `description`, `processing`,
  `sca_name`, and `bridge_solution_check`, which is the digest's verdict on the products;
- choices made at digest time: `bridge_gauge`, `bridge_applied`, `side_bridge_applied`,
  `corrections`, `corrections_applied_at`.

The digests' `photodiode_source` is one of these too: it names which h5 group the *digest*
read. The product attribute of the same name says how stage 1 formed `pd_net`, a different
quantity.

**The two reductions are not bitwise equal, and why.** The digest multiplies each pixel ratio
by the multiplier ratio and then takes the median. The reader takes the median once and
multiplies after, so one cached reduction serves every choice of steps. A positive per-SCA
scalar commutes with the median:
- exactly, for an odd number of finite pixels;
- to one rounding for an even number, where the median averages the two middle values.

**The figures.** `RcsTrend.plot_pair(led, dir)` writes `time_series_<LED>_all_scas.png` and
`_tgcorr.png` from the products. The two figures share a y-frame equal to the digest figure's to
<= 2.2 x 10^-16, are the same 1650 x 900 pixels, and draw the same curves. Both use a date axis,
viridis by SCA with a colorbar, shaded boundaries labelled "ACM move" or "MCE A->B", and the
gain footnote. They are not pixel-identical, deliberately: the title ends `[rcs_trend_reader]`,
the y label reads "response / first epoch", and the fonts and colours are matplotlib's defaults
rather than `digest_plots`' palette. The digests' other figures (bridge summaries, run
structure, decon evidence, side bridge) are diagnostics of the fits, not reproductions of data,
and the reader does not redraw them.

### `sca_arrays/<key>` and the copied groups

`sca_arrays/` is copied from the raw product untouched: no multiply, no `applied_factor`
attribute, `units = "DN/s"`. `coverage/`, `housekeeping/`, `photodiode/` and `dictionary/` are
byte-copied as well, so a calibrated product is self-describing. An invalid photodiode reading
now shows as a NaN **multiplier** for that LED. The pixels stay finite, which is the one place
the truthful field is `calibration/<step>/valid`, not coverage.

### Root attributes added at stage 2

| attribute | value on the current set |
|---|---|
| `calibration_schema` | `2` |
| `corrections_applied` | `""` -- nothing is in the pixels (schema 1 read `"photodiode,side,acm"`) |
| `calibration_recorded` | e.g. `"photodiode,acm,acm_bridge,side_bridge,tempgain"` |
| `calibration_in_total` | `"photodiode,acm,acm_bridge,side_bridge"` |
| `calibration_direction` | `calibrated = raw * multiplier` |
| `bridge_applied` / `bridge_recorded` | `False` / `True` once a bridge solution is recorded |
| `bridge_solution`, `bridge_solution_sha256` | the solution file and its hash |
| `tempgain_recorded`, `tempgain_applied` (`False`), `tempgain_model`, `tempgain_model_sha256`, `tempgain_form`, `tempgain_t_nominal_k`, `tempgain_t_scale_k`, `tempgain_note` | with `--tempgain-model` |
| `acm_mode` | `"linear"` |
| `reference_card`, `reference_card_sha256`, `reference_run_label` | the card, and the response origin |
| `pd_reference_mode` | `"per-side"` |
| `acm_segment`, `acm_segment_reference_lvdt`, `acm_move_min_delta` | this epoch's ACM configuration |
| `mce_side`, `mce_side_source` | from stage 1; `cli` for a labelled pass, `assumed:flight-side-A` for the pre-swap ones |
| `calibrated_from`, `calibrated_from_sha256` | the raw product |

`provenance` is rewritten: "Calibrated per-SCA RCS trend product, schema 2. NOTHING is applied
to the pixels; the factors for ... are recorded under calibration/<step>/multiplier."

---

## 5. The corrections, summarized

### What is recorded, where it is applied, and how big it is

| correction | recorded at | applied in | varies by | size on this set |
|---|---|---|---|---|
| photodiode (lamp output) | stage 2 | digests; reader | LED | up to 1.8 % from each side's first epoch |
| ACM position (linear) | stage 2 | digests; reader | -- | <= 0.11 % (the 53->54 move inside segment 3) |
| ACM bridge (across a move) | stage 2, from the bridge solution | digests (fitted there); reader | SCA | ~0.96, ~0.99, ~1.009 at the three moves |
| side bridge (across a swap) | stage 2, from the bridge solution | digests (fitted there); reader | LED | 0.893 ... 1.032 (A scaled onto B) |
| temperature gain | stage 2, from the model | digests' `_tgcorr` columns only; reader on request | LED, SCA | ~1 % at the top of a cooldown |
| ratio to the reference epoch | -- | stage 3 | -- | -- |
| L2 photom / flat / ramp | not a factor here: baked into the input pixels | -- | -- | provenance in `ref_file_id`, `crds_context`, `cal_step_*`, `l2_calibration_audit.ecsv` (Sec. 6.3) |

### The side swap

At an MCE side change the detector electronics, the LED drive and the photodiode all change
together. The photodiode is a different physical diode behind the same mnemonic, so nothing ties
the A-side photodiode to the B-side one. The pipeline therefore:

1. **re-bases the photodiode** to 1.0 at each side's first epoch (`--pd-reference per-side`, the
   card default; a two-side card in `global` mode is refused);
2. **opens an ACM segment** at the swap, so the linear ACM term is referenced within the side.
   The B electronics read the same ACM position with per-channel offsets of -172 to +205 counts;
3. **fits one step per LED, common to every SCA** across the swap. It is fitted jointly over 18
   SCAs against each (SCA, LED)'s own polynomial trend, within the decon episode, over its own
   window (+/-50 h by default). This step absorbs everything in points 1-2's wake, including the
   A->B photodiode ratio. There is no per-SCA ACM step at the swap; it is fixed at 1.0, so the
   two bridges never double-count and the swap cannot change the illumination pattern.

The gauge is **present-nominal**: side B (the instrument is not expected to return to A) is 1,
and side A is multiplied by the step. The digest then divides by pass 1, so its `LED1...LED6` stay
1.0 at A-side t=0, and side B reads x1/step.

**The illumination-pattern test.** Because the step is SCA-common, a real per-SCA change at the
swap would not be absorbed. It is measured: each SCA's independent per-LED steps, averaged over
LEDs, against the common step. Their rms is compared with what the per-SCA fit errors predict.
On the 2026-10-06 swap the ratio is **1.90x** (threshold 3), with SCA8, 17 and 18 the largest at
about -2 x 10^-4.

The TVAC ground table `B_SIDE_CORRECTIONS` is **no longer a step**. It covered the electronics
alone, in the opposite gauge, and the flight bridge supersedes it. It is recorded on
`side_bridge` as `ground_b_side_corrections` for comparison only.

### Refusals and NaN, which are not the same as "off"

- **Photodiode -> NaN multiplier, per LED**, where this epoch's or its side reference's
  `pd_net <= 0.01 V`. The guard exists because a pedestal from a window that was not dark gives a
  ~60x factor that looks like an instrument event. Do not back-fill it with 1.0.
- **ACM -> NaN, all six LEDs**, where the segment reference or this epoch's LVDT is non-finite.
- **Side -> never NaN.** The side is an operator label (`batch/run_manifest.csv`), resolved from
  the product attribute, then a TVAC filename marker, then `--assume-side`, then a refusal. It
  decides which photodiode reference and which side of the side bridge an epoch is on.
  `batch/side_witness.py` checks the labels against the LED map and the photodiode witnesses.
- **A bridge the fit cannot solve** falls back as before. An ACM boundary uses the linear LVDT
  model, method `multiplier`. A side change is left at 1.0, method `none`, and announced: the
  swap is then in the output at its full size.
- **`--no-photodiode` / `--no-acm`** leave that step **absent** from the product, not unity.

### What is deliberately **not** corrected

- **Dark subtraction**: never. There is no dark imagery in this generation.
- **Flat field**: not applied by either L2 source; see Sec. 7.
- **Per-decon re-gauging**: see `PER_DECON_NORM.md`. `decon_time_hours` and
  `decon_episode_bounds` make it a one-liner for a consumer.

### The double-application guard

Stage 3 branches on the products' schema. For **schema 2** it applies the recorded
`photodiode x acm` from each product, fits the bridges itself, and reads the recorded bridges
only to check them against its fit. For **schema 1** it applies nothing, because those factors
are already in the pixels. For **raw** products it computes the corrections itself. A set mixing
stages or schemas is refused. A factor applied twice is the failure this prevents, and it is
invisible: 1.002 twice is 1.004, against a signal of a fraction of a percent per pass.

---

## 6. The ECSV family

Two are git-tracked (`rcs_reference_card.ecsv`, `l2_calibration_audit.ecsv`); the rest are
working artifacts or released inputs. All are `ascii.ecsv`, `schema: astropy-2.0`, so
`Table.read(path)` recovers columns, units and meta.

### 6.1 `rcs_reference_card.ecsv` -- the pivot of the whole set

One row per epoch, sorted by the product's own timestamp. Columns: `run_label`, `name`,
`timestamp`, `pass_number`, `car_label`, `decon_cycle`, `mce_side`, `mce_side_source`, `stage`,
`product_kind`, `bin_factor`, `acm_lvdt`, `segment`, `is_reference`, `pd_valid_n`,
`pd_LED1`...`pd_LED6`.

Meta: `reference_run_label`, `reference_name`, `reference_timestamp`, `led_names`,
`reference_pd` (6 floats -- **the numerator of the photodiode correction**),
`segment_reference_lvdt` (`{segment: lvdt}`), `move_min_delta`, `max_fractional_travel`,
`acm_moves` (one dict per move: `index`, `lvdt_before`, `lvdt_after`, `crosses_zero`),
`comments`. In `per-side` photodiode mode only, two more appear: `pd_reference_mode` and
`side_reference_pd`.

The card exists to hold the three things one epoch cannot know on its own: which epoch is the
reference, that epoch's per-LED `pd_net`, and each ACM segment's reference LVDT. It is built by a
metadata-only pass (~0.1 s/file, no pixels) and written to disk rather than recomputed, so
calibration is a pure function of (product, card).

**Its file sha256 is stamped into every product it calibrates, and stage 3 raises `SystemExit` if
an input set carries more than one.** That is the hardest guard in the pipeline, and it is not
decoration: re-running calibration over a grown raw directory once rebuilt the card but skipped
epochs that already had products, leaving a 176-epoch set holding three different cards
(118 + 50 + 8). Stage 2 multiplies the card's factors into the pixels, so that disagreement is
not recoverable after the fact.

This is also why `pd_reference_mode` is omitted rather than written as `"global"` in the default
mode: adding a key unconditionally would move the card's sha256 and force a full re-calibration
for a documentation change.

Card values on the current set: reference `CAR190_01039_02_001_001_20260912`, 4 ACM segments at
LVDT `{0: 7558.17, 1: -2814.5, 2: -5231.67, 3: -2814.67}`, 3 moves at 0-based indices 14/34/164
(the first crossing zero), `move_min_delta = 500.0`, `max_fractional_travel = 0.000533`, no
`pd_reference_mode` key. md5 `f42a65f69a3bbc24708fd0e48d4674eb`, and the in-repo
`rcs_reference_card.ecsv` is byte-identical to the installed `rcs_reference_card_v3.ecsv`.

### 6.2 `time_series_SCA<n>.ecsv` -- the digests

One file per detector, one row per epoch. 15 columns; 21 when the set spans an MCE side
change (the `side_bridge_*` columns); 12 more when the products carry a temperature gain. The
current set has 33.

| column | unit | meaning |
|---|---|---|
| `time_hours` | h | hours since the reference epoch |
| `timestamp` | -- | astropy `Time` mixin, isot/utc |
| `pass_number` | -- | **not unique**; see Sec. 2 |
| `car_label`, `decon_cycle` | -- | `CAR190`/`CAR216`, `decon1`/`decon2` |
| `decon_time_hours` | h | hours since *this epoch's own* decon episode began. A convenience origin only -- the LED columns are **not** re-gauged. |
| `LED1`...`LED6` | -- | relative response, gauged to `reference_epoch`, with photodiode, linear ACM, ACM bridge and side bridge applied |
| `bridge_factor` | -- | the ACM bridge applied to this epoch; **divide** to recover the raw ratio |
| `side_bridge_LED1`...`side_bridge_LED6` | -- | *conditional, on a side change.* The side bridge applied, gauged to `reference_epoch`: exactly 1.0 on the reference epoch's side, `1/step` after the swap. The same on every SCA. **Divide** to undo |
| `acm_lvdt` | counts | mean LVDT for the epoch |
| `acm_segment` | -- | increments at *every* detected move, not only the deploy |
| `LED1_tgcorr`...`LED6_tgcorr` | -- | *conditional.* The same bridged response with the modelled temperature-gain **change** divided out, re-gauged to `reference_epoch`. Exactly 1.0 in row 0 |
| `tempgain_LED1`...`tempgain_LED6` | -- | *conditional.* The raw per-epoch multiplier `1/G(T)` copied from `tempgain/multiplier`, so the correction can be undone or re-gauged |

**`LED1...LED6` stay gain-free, and that is load-bearing.** Every fitter in this activity reads
those columns, including `fit_temperature_gain.py` itself, which is where the model comes from.
Applying the gain to the canonical columns would make that fit a fixed-point iteration on its
own output -- presenting as coefficients near zero, which reads as a converged null result.
`load_dataset` therefore refuses a digest whose `tempgain_applied_to` does not name only the
`_tgcorr` columns.

**The corrected column carries the ratio, not the multiplier.** `LEDx` is already divided by the
reference epoch, so the correction that belongs on it is `m_i/m_0`, not `m_i`:

```
LEDx_tgcorr[i] = LEDx[i] * tempgain_LEDx[i] / tempgain_LEDx[0]
```

Dividing out the absolute multiplier instead rescales the whole series by one constant -- a
smooth, plausible, uniformly wrong trend with nothing in the shape to give it away. One
consequence worth internalising: a gain that is *constant in time* is absorbed entirely by the
gauge and leaves `LEDx_tgcorr` bit-identical to `LEDx`. Only the *change* in gain is observable
in a ratio series, which is the same reason the correction is largest near pass 1 (the cooldown)
and why the h5 product is deliberately not normalized there.

The meta keys come in five unconditional families:

- **Comparability** -- `product_kind`, `product_stage`, `bin_factor`. Two digests are comparable
  only if all three agree. Plus `description`, `sca_name`, `n_epochs`, `time_range_hours`,
  `data_root`, `reference_epoch`, `epoch_files`, `processing`, `created`.
- **What is in the numbers** -- `corrections`, `corrections_applied_at`, `photodiode_source`,
  `photodiode_flagged_epochs`, `mce_sides_present`, `car_labels_present`, `decon_cycles_present`,
  `n_acm_segments`. `corrections` is read from the *products*, not the CLI flags, so a
  stage-2-calibrated digest cannot be mislabelled as raw.
- **Decon episodes** -- `decon_n_episodes`, `decon_episode_bounds` (1-based inclusive),
  `decon_episode_labels`, `decon_reference_epochs`, `decon_episode_note`. Keyed by *position*,
  not label, because a label that recurs after an intervening decon opens a new episode.
- **ACM** -- `acm_n_moves`, `acm_move_min_delta_lvdt`, `acm_max_fractional_travel`,
  `acm_segment_reference_lvdt`, `acm_move_epochs`, `acm_move_epoch_indices` (1-based),
  `acm_move_kinds`, `acm_move_manual`, `acm_move_lvdt_before`/`_after`/`acm_move_delta_lvdt`,
  the `acm_deploy_*` family, and `acm_deploy_min_delta_lvdt` + `acm_deploy_min_delta_note`
  (**historical only -- selects nothing**, kept for key stability).
- **Bridge** -- `bridge_applied`, `bridge_gauge`, `bridge_degree`, `bridge_window_hours`,
  `bridge_steps`, `bridge_method`, `bridge_method_note`, `bridge_notes`, `bridge_systematic`
  (scalar, the worst boundary), `bridge_systematic_per_boundary`, `bridge_systematic_note`,
  `bridge_boundary_epochs`. At a side change the ACM step is 1.0 with method `side`.

Plus `calibration_schema`, and on a schema-2 set `bridge_solution_check`: `current (<sha>, max
|diff| ...)` when the products carry the bridges this digest run fitted, `STALE ...` when they do
not, `absent` before the second stage-2 pass.

Three conditional families, and the condition is the point:

- `bridge_step_errors`, `bridge_led_spread`, `bridge_rms_pre`, `bridge_rms_post` appear **only if
  at least one step was actually fitted** -- omitted entirely rather than NaN-filled, so a
  consumer that needs an error bar (`bridge_noise.py`) fails on a missing key instead of quietly
  carrying a NaN one through.
- The `side_bridge_*` family appears **only when the set spans an MCE side change**. Each key
  is a list, one entry per side change:
  - **where:** `side_bridge_applied`, `side_bridge_epoch_indices` (1-based),
    `side_bridge_epochs`, `side_bridge_transitions`, `side_bridge_method` (`side` fitted,
    `none` left at 1.0);
  - **the step:** `side_bridge_led_names`, `side_bridge_steps` (per LED, multiplies the
    **early** side: present-nominal, as the h5 records it);
  - **its errors:** `side_bridge_stat_errors`, `side_bridge_sca_scatter_errors`,
    `side_bridge_systematic`, `side_bridge_total_errors` (= max(stat, SCA scatter) (+)
    systematic);
  - **the fit:** `side_bridge_n_early`/`_n_late`, `side_bridge_degree`,
    `side_bridge_window_hours`;
  - **the pattern test:** `side_bridge_pattern_rms`, `side_bridge_pattern_noise`, and this
    SCA's own `side_bridge_this_sca_steps` and `side_bridge_this_sca_pattern_offset`;
  - **for comparison:** `side_bridge_ground_inverse_b_side` (the TVAC table in this gauge);
  - `side_bridge_note`.

  The steps are common to every SCA. The per-SCA keys are the test that they should be, and
  are not applied.
- `tempgain_model`, `tempgain_model_sha256`, `tempgain_form`, `tempgain_mnemonic`,
  `tempgain_applied_to`, `tempgain_led_names`, `tempgain_reference_multiplier` (the row-0
  denominator of the gauge, per LED, so the ratio can be undone without reopening the h5),
  `tempgain_gauge`, `tempgain_order_note`, `tempgain_note` appear **only if every product in the set carried a
  `tempgain/` block**, alongside the twelve conditional columns above. `tempgain_applied_to`
  names only the `_tgcorr` columns and states that `LED1..LED6` are gain-free;
  `tempgain_order_note` records that the gain ratio is applied **after** the ACM bridge, because
  the bridge steps were fitted on gain-carrying response and re-ordering the two would change
  the steps.

**A part-corrected set is refused, not averaged.** Three states are legal across a 176-product
set: every product carries the block, none does, or the digest build fails. A set where some
products carry it puts a step the size of the correction (~1 %) at the changeover -- the same
class of error the mixed-reference-card guard exists to prevent. `assert_homogeneous` names an
offending epoch, and names both models if two different `tempgain_model_sha256` values appear.
With no block anywhere, the digest is byte-identical to one built before this feature existed.

### 6.3 `l2_calibration_audit.ecsv` -- the L2 provenance record

176 rows, committed, with **no in-repo writer** -- it is an evidence artifact. Columns: `epoch`,
`run_label`, `provenance_from`, `cal_version`, `crds_context`, `cal_step_photom`, `ref_file_id`,
`calibration_class`, `frame`. Match on `run_label`; `epoch` is a position in whatever list
produced the audit and means nothing across files.

`provenance_from` is the key column: `product` means the row was read from attrs the product
already carries; `streamed` means it was read from one L2 frame fetched fresh from MAST, which
describes the file MAST serves *now* -- the same file only if nothing was reprocessed since the
product was staged. That caveat lives in `meta["description"]` so it travels with the rows.
`meta["flat_field_finding"]` carries the flat-field result (Sec. 7).

### 6.4 `tempgain_model.ecsv` -- the temperature-gain model

108 rows (18 SCAs x 6 LEDs), committed at the activity root beside `rcs_reference_card.ecsv`.
Unlike everything in `plots/temperature_gain/`, which the next fit run overwrites wholesale,
this is a **pinned pipeline input** whose sha256 is recorded in every product it touches.

Columns: `sca` (int), `led` (str), `alpha1`, `alpha2` (float), `derivation` (str),
`sigma_gain_hot` (float).

The meta is what makes it swappable. It **names its own parametric form**, and the evaluator is
dispatched from that name:

| meta key | on the current file |
|---|---|
| `form` | `poly_pinned_v1` |
| `param_names` | `[alpha1, alpha2]` -- which columns are parameters, and in what order |
| `param_powers` | `[1, 2]` -- the exponent each parameter multiplies, **stored as data** |
| `t_nominal_k`, `t_scale_k` | `89.5`, `10.0` -- read from the file, never from the reader's own constants |
| `gain_definition` | `G(T) = 1 + sum_k alpha_k * u^k`, `u = (T - t_nominal_k)/t_scale_k` |
| `temperature_mnemonic` | `WFI_MCU_A_MPA_CSENS_FPSSEN_K`. A model fitted against one channel must not be evaluated against another |
| `uncertainty_kind`, `sigma_note` | `empirical-across-detector`. No covariance for `alpha` is computed anywhere and chi^2/dof is ~22, so a formal bar would be meaningless; `sigma_gain_hot` is the empirical across-detector scatter of `G(124 K)` |
| `fit_gain_mode`, `fit_growth_mode`, `chi2_red`, `n_epoch`, `fit_rate_nm_per_h`, `digest_dir`, `cal_dir` | provenance of the fit |
| `provisional: true`, `caveat`, `chromatic_caveat` | the caveat travels with the parameters |

`form` is **refused, never guessed**: `tempgain_model.resolve_form` raises on an unknown name and
lists the legal ones. A silently-defaulted form would evaluate a future model's parameters
against today's polynomial and produce plausible wrong multipliers.

`param_powers` exists to kill an off-by-one. In memory `alpha[g, j]` multiplies `u**(j+1)`; on
disk `alpha1` multiplies `u**1`. Storing the exponent as data rather than inferring it from the
column name is what lets a future form use different powers, and a self-test asserts that a file
with `[2, 1]` evaluates differently from one with `[1, 2]`.

The default file is **achromatic**: the per-SCA coefficient replicated across all six LEDs, with
`derivation` on every row recording that. The gain is achromatic across LED2-LED6 to 0.17 %, and
LED1's apparent excess is film-model leakage rather than chromaticity. The schema stays
per-(SCA, LED) so nothing downstream changes when the model improves --
`fit_temperature_gain.py --chromatic` emits the genuinely fitted per-(SCA, LED) variant for
comparison.

To replace the model, re-run stage 2 with a different `--tempgain-model`. Nothing else in the
pipeline needs to know, and the swap is detectable in every product through
`tempgain_model_sha256`.

### 6.5 Analysis outputs

The film fitters write their own ECSVs under `--out-dir` (`fit_film_thickness.py`:
`film_thickness_d_eff`, `fitted_r_initial`, `film_thickness_physical`, `sca_aoi_geometry`,
`alpha_profile`, `prior_comparison`; `fit_film_rank1.py`: `rank1_growth`, `rank1_amplitudes`,
`rank1_reflectance`, `rank1_adequacy`, `rank1_eta`, `rank1_profile`;
`fit_initial_offset.py`: `initial_offset`, `initial_offset_residuals`). These are analysis
products rather than pipeline products and are documented in `RATE_INFERENCE.md` and in each
table's own `meta["description"]`. Two conventions worth knowing before reading any of them:

- Every fitter table carries a model stamp (`forward_model`, `t0_utc`, `d_block_used`,
  `amplitude_polish`, `bandwidth`) because both forward models write the *same filenames* into the
  same output directory.
- The quoted caveats are load-bearing, not boilerplate: an `at_ceiling`/`at_bound` flag means that
  detector's thickness is a **lower limit**, and the reported widths cover only the white noise
  component -- the 30-40 % achromatic systematic is in none of them.

`bridge_noise.py` writes no ECSV; it is purely a consumer of digest meta.

### 6.6 Released input tables

Four static tables in this directory, all from the released Roman technical information, consumed
read-only:

| file | contents | used for |
|---|---|---|
| `WFI_RCS_LEDP_centers_FWHM.ecsv` | 6 rows: filter, band, measured center (nm), FWHM range at 200 K | the source of `LED_WAVELENGTHS`; the `gaussian` band model |
| `WFI_RCS_LEDP_spectral_energy_distribution.ecsv` | long-format measured SED, relative output % per band (bands paired 1-2/3-4/5-6 share a scan window, so sampling differs by band) | the default `measured` band model; finite-bandwidth fits |
| `WFI_Quantum_efficiency.ecsv` | QE vs wavelength, one column per Sensor Control Unit (SCU 1-18) | the per-LED reflectance ceiling. **There is no SCU->SCA map in this activity**, so the bound is taken over the ensemble and nothing is attributed to a named detector |
| `FPA_F158_AOI_1550nm.ecsv` | 28-term polynomial for FPA angle of incidence at 1550 nm | converting `d_eff` to physical thickness |

---

### 6.7 `rcs_bridge_solution.ecsv` -- the fitted bridges

Written by `make_sca_digests.py --solution-out` and recorded by
`calibrate_rcs_products.py --bridge-solution` (`run_trend.py` does both). It is recorded **twice
over** in each product: as this epoch's composed multipliers, and in full as
`calibration/bridge_solution/` (Sec. 4). It is read by `rcs_bridge_solution.BridgeSolution` (`.read`
for the file, `.from_columns` for the h5 group) or `rcs_trend_reader.RcsProduct.bridge_solution`.
Format 2, from 2026-10-09; format 1 files read with the newer columns as NaN.

| column | meaning |
|---|---|
| `kind` | `acm`: one row per boundary x SCA, `led = ALL`, the applied achromatic step. `side`: one row per boundary x LED, `sca = 0`, the applied SCA-common step. `side_sca`: one row per boundary x SCA x LED, that SCA's own independent estimate, for the pattern test only and **never applied** |
| `boundary_index`, `boundary_run_label` | 1-based first epoch after the boundary, and its label |
| `boundary_utc` | the midpoint of the gap -- rows are **keyed by time**, so stage 2 can evaluate one product without knowing the set's ordering |
| `transition` | the ACM move kind, or `A->B` |
| `sca`, `led` | which detector or LED the row is for |
| `value` | the step: multiplies every epoch **before** `boundary_utc` |
| `stat_error`, `systematic`, `total_error` | as in the digest meta; `stat_error` is NaN for a fallback step, as in `bridge_step_errors` |
| `method` | `bridge` / `multiplier` / `none` / `side` / `pattern_test` |
| `n_early`, `n_late`, `note` | the fit's epochs, and why a fallback happened |
| `sca_scatter_error` | `side` rows: the error from the scatter of the 18 per-SCA estimates |
| `led_spread`, `rms_early`, `rms_late` | `acm` rows: `bridge_led_spread`, `bridge_rms_pre`, `bridge_rms_post`; `side` rows: the joint fit's residual rms |
| `pattern_offset` | `side_sca` rows: that SCA's achromatic offset from the common step |
| `pattern_rms`, `pattern_noise` | `side` rows: the illumination-pattern test |
| `lvdt_before`, `lvdt_after` | `acm` rows at a detected move |

NaN where a column does not apply to a row's kind. Meta: `gauge` ("present-nominal: ..."),
`reference_card_sha256` (stage 2 refuses a solution fitted under another card), `n_epochs`,
`first_epoch`, `last_epoch`, `acm_bridge_degree`/`_window_hours`, `acm_move_min_delta_lvdt`,
`side_bridge_degree`/`_window_hours`, `side_bridge_n_choices`, `format_version`. An epoch's
recorded multiplier is the product of every `acm`/`side` row whose `boundary_utc` is after its
timestamp, so the latest configuration is exactly 1.

## 7. This generation of products

Everything below is specific to the 176-epoch set at `/data/eswitzer/rcs_trend_v3/`, staged
2026-10-04/05.

### 7.1 Composition

176 epochs, 2026-09-12T01:28 -> 2026-10-03T09:24, total span **511.9 h (21.3 d)**, three blocks:

| block | epochs | passes | L2 source | cadence (median) | span |
|---|---|---|---|---|---|
| CAR190 decon1, plan 2 | 35 | 1-37 (12 and 25 absent) | **aux local reprocessing** | 7.15 h | 271.4 h |
| CAR216 decon2, plans 2+3 | 126 | 1-90 / 1-36 | MAST | **0.40 h** | 51.0 h |
| CAR190 decon2, plans 2+3 | 15 | 38-46 / 47-52 | MAST | 11.13 h | 150.4 h |

The 20x cadence difference between CAR216 and CAR190 is not an artifact: CAR216 is the dense
campaign. One decon transition, at 0-based epoch index 35 (`CAR216_01063_02_001_001_20260924`),
with a 38.4 h gap across it. **Film growth must not be fitted across that boundary** -- the digest
meta records it as two episodes, `[[1, 35], [36, 176]]`.

Four ACM configurations, three moves:

| boundary | epoch idx (1-based) | kind | LVDT | step | method |
|---|---|---|---|---|---|
| 1 | 15 | deploy (crosses zero) | +7559 -> -2815 | 0.962912 | bridge |
| 2 | 35 | reposition | -2815 -> -5232 | 0.991414 | **multiplier** |
| 3 | 165 | reposition | -5232 -> -2815 | 1.009302 | bridge |

Boundary 2 fell back to the linear multiplier because it had only 3 early / 1 late epochs inside
the +/-25 h window and at least 2 of each are needed to separate a step from the trend. Worst
in-segment fractional LVDT travel is 0.000533, two orders below the 0.10 warning threshold.

### 7.2 The decon1 local reprocessing, and why it exists

MAST reprocessed only **CAR-190 plan 2 pass 1** as a trial. In lieu of the full reprocessing, the
decon1-period L2 frames were made available at `/mnt/roman-s3-romcom/activities/CAR190/`, and
stage 1 grew an aux-path override: if an aux tree holds a complete set of frames for a pass,
those supersede MAST for that pass. It is all-or-nothing per pass -- a partial aux reprocessing is
refused rather than mixed with older MAST data -- and the logging announces it loudly.

So 35 of the 176 products read `l2_source = "aux"`,
`l2_source_dir = "/mnt/roman-s3-romcom/activities/CAR190"`, and their `provenance` string says
"from a LOCAL REPROCESSING ... (superseding MAST)".

### 7.3 Two CRDS configurations, one equivalence class

| | aux (35 epochs) | MAST (141 epochs) |
|---|---|---|
| `calibration_software_version` | 1.0.1 | 1.0.2 |
| `crds_context` | `roman_0067.pmap` | `roman_0072.pmap` (x139), `roman_0073.pmap` (x2) |
| `crds_version` | 13.2.8 | -- |
| `cal_step_photom` | SKIPPED | COMPLETE |
| `cal_step_flat_field` | SKIPPED | SKIPPED |
| `ref_file_id` | `fb7be0c9d705b6ae` | `1aa8a84bc016ea68` |
| `calibration_class` | `unity-photom` | `unity-photom` |

Three things here are easy to get wrong.

**A CRDS context is not provenance; the reference files are.** `ref_file_id` is a truncated
sha256 over the L2 `meta.ref_file` branch **minus its `crds` sub-dict**. That is deliberate:
`roman_0072.pmap` and `roman_0073.pmap` resolve to byte-identically the same 17 reference files --
checked field by field -- so they hash to the same id. Two contexts, one calibration. The two
`roman_0073` epochs (CAR-190 plan 3 passes 51-52) are therefore not a third family.

**The equivalence is a measurement, not a convention.** `CALIBRATION_EQUIVALENCE`
(`rcs_trend_config.py:266-273`) maps both ids to `unity-photom` because on pass 1 -- the one pass
that exists from both sources -- the pixel ratio aux/MAST over 16.7 M illuminated pixels has
median 1.00000000, with 99.98 % of pixels agreeing to better than 1e-6, and the per-SCA medians
agree to 0.0007 % rms through the full pipeline. In other words `photom` in `roman_0072` is a
no-op and skipping it is equivalent to applying it. An unrecognised `ref_file_id` gets a class of
its own, so it trips the guard rather than passing silently.

**`roman_0075` (pass 75 and CAR-216 plan 4 on) is a third id, `5c871b249e2f6eaf`, in the same
class.** Only the distortion reference changed (0027 -> 0053; it is WCS-only), and with no
exposure under both contexts the evidence is a step fit on the B-side trend. The per-SCA
achromatic step at 74|75 is 0.0085 % rms (quadratic) against 0.0040-0.0092 % for null splits.
README -> *`roman_0075`* has the details. **`roman_0076`** (CAR-216 p4 pass 4 on, `2dd418ec414b1196`)
is the same story, distortion 0053 -> 0061: 0.0037 % at p4 3|4, against 0.0042-0.0074 % for null splits.
Both come from `trend_change_check.py` (README -> *Checking any change between passes*).

**CAR-216 plan 4 runs with the WFI enclosure about 1 K warmer** (heater setpoints 06-09 raised at
2026-10-09 05:11; pass 1 ends 2 min before). Nothing in the products records it; the products' housekeeping carries
only the MPA, which does not move. On the B-side trend there is no step at p4 1|2 (focal plane
-0.012 ... -0.001 % per LED, per-SCA 0.0050 % rms), and LED1's slope change over this period is the film
fringe turnover, staggered by SCA from 10-05 on. `MANIFEST.md` has the telemetry.

**The configuration that is *not* equivalent is the old pre-2026-09-24 MAST family** (cal 1.0.1,
photom reference 0040). Against the above it applies a per-SCA achromatic scale of -2.28 % to
+3.08 %, 1.787 % rms, with an across-LED spread of only 0.028 % -- a **64:1 achromatic
signature**, which is exactly how it was told apart from a film reset. That is the +/-2 % pass-1
versus pass-2 jump in the earlier product generation; it is a photometric reference change, not
instrument behaviour. It is deliberately absent from the equivalence table, so a set mixing it
with anything above is refused.

The `fb7be0c9d705b6ae` id on the aux products is the **superseded** hash -- the definition that
included the context string, used before 2026-10-05. Products written before that date carry it,
so it is mapped as an alias alongside `c7fab59daf321aec` and `9f3f1a24216da0ad` rather than being
allowed to trip a physics guard on a hash-definition change with no physical content. The current
definition gives `57375af18e138f28` for the same aux calibration.

**Neither L2 source applies a flat field.** Both classes report `cal_step_flat_field = SKIPPED`
with `ref_file.flat = INCOMPLETE`; the WFI flat reference is not delivered in CRDS at all. This
was checked against the pixels independently of the metadata, because a flat is a per-pixel
multiplicative map and so a differential one cannot hide in a pixel ratio: 46 M usable pixels
across SCA 1/9/18 give median ratio 1.00000000, rms 0.0000 %, 100.000 % of pixels within 1e-6.
Consequence: dividing MAST-sourced epochs by the aux-sourced t=0 reference introduces **no**
per-pixel calibration ratio, which is what removed the calibration motivation for per-decon
normalization (`PER_DECON_NORM.md`).

### 7.4 A schema asymmetry inside this one set

**The 141 MAST-sourced raw products carry no L2 provenance attributes at all.** They have 33 root
attrs; the 35 aux products have 43. The ten-attr provenance block is absent, not empty.

This is a staging-date artifact, not a code gap: the MAST products were written 2026-10-04, the
aux products 2026-10-05 02-03 UTC after the provenance work landed. The current code records
provenance for both sources. It has one practical consequence -- `l2_calibration_audit.ecsv` has to
*stream* 141 of its 176 rows from MAST rather than read them off the products, which is why those
rows are marked `provenance_from = "streamed"` and carry the "describes the file MAST serves now"
caveat. If you need provenance on a MAST-sourced epoch of this generation, the audit ECSV is the
only place it exists, and it is a re-read rather than a record of what was staged.

Calibrated products inherit the asymmetry: 44 root attrs where the raw had 33, 54 where it had 43.

### 7.5 The side swap of 2026-10-06

**The MCE swapped from A to B between CAR-190 plan 3 pass 57 (04:13 UTC) and pass 71 (11:54).**
Passes 58-70 were never executed; there was no decon (MPA 89.5 K throughout). The 181 earlier
products read `mce_side = "A"`, 176 of them `assumed:flight-side-A` and passes 53-57 `cli`.
Every pass from CAR-190 plan 3 pass 71 on reads `B` from `cli`. Nothing in the telemetry MAST serves names the side, so the
label comes from the manifest. Four witnesses corroborate it, all moving at this boundary and
nowhere else:

- the LED select map, `612345` -> `132465` (Sec. 2);
- the PD2 pedestal, -1.92 mV;
- the PD1 pedestal, +1.06 mV;
- the two-diode ratio, a chromatic 8.7-point spread.

`batch/side_witness.py --strict` checks the labels against them. `MANIFEST.md` has the record.

How it is calibrated (Sec. 5, *The side swap*):

- the photodiode is re-based to 1.0 at pass 71;
- the swap opens ACM segment 4, so the B electronics' LVDT offset (-172 to +205 counts by
  channel) does not reach the linear ACM term;
- one step per LED, common to every SCA, bridges the trend across it. B is nominal, and side A
  is multiplied by:

| LED1 | LED2 | LED3 | LED4 | LED5 | LED6 |
|---|---|---|---|---|---|
| 0.89325 | 0.94393 | 1.03224 | 0.99189 | 0.99106 | 1.00056 |
| +/-0.00131 | +/-0.00049 | +/-0.00015 | +/-0.00012 | +/-0.00012 | +/-0.00017 |

The fit uses 3 A-side and 4 B-side epochs within +/-50 h, and the errors are systematic-dominated
(5 accepted fit choices from 188 epochs on; later passes fall outside every scan window). The values have not moved since 185 epochs; the error has.
From 188 epochs the +/-75 h choices reach the three later B passes, which raises the scan's median
residual. That admits the linear +/-25 h choice, which has 2 epochs a side and 1 degree of freedom,
and its LED1 (0.89434) sets the ptp: LED1 +/-0.00026 -> +/-0.00131. The one choice that sees 6 B
epochs, degree 2 at +/-75 h, reads LED1 0.89305, so the new data agree with the step; the
error growth comes from the acceptance rule. The illumination-pattern test reads 1.90x noise. The step bears no
resemblance to the TVAC ground table (`1/B` = 0.941 ... 0.986), as expected: it also carries the
LED drive and the photodiode. Expect it to tighten as B-side passes accumulate. The window, and
so the step, is re-fitted every time `run_trend.py` runs.

Still unfixed and now biting: `bridge_noise.BridgeNoise.from_meta` raises `NotImplementedError`
above 2 ACM segments. The current set has 5 (three ACM moves and the side change), so the rank-1
film fit refuses it unless built with the 2-segment options in `README.md`, *Known constraint*.

---

## 8. Traps

Collected because each one has either bitten this repo or is the kind that makes a reader
confidently wrong rather than stuck.

**Attributes that read as provenance and are not**

1. **`provenance` on a calibrated product from before this generation is stale and says the
   opposite of the truth** (Sec. 4). Stage 2 now rewrites it, but older products on disk still carry
   the inherited "No corrections applied" string next to
   `corrections_applied = "photodiode,side,acm"`. On schema 1, `corrections_applied` is the
   authority. On schema 2 it is `""` **by design**, because nothing is in the pixels:
   `calibration_recorded` names the steps the file carries. An empty `corrections_applied` is
   not an uncalibrated product. Check `calibration_schema` first.
2. **`dictionary_is_legacy = True` is set on every per-SCA raw product**, including ones whose
   `dictionary/RCS_photodiode` holds the *new* pedestal-subtracted `pd_net` (verified element-wise
   equal on this set). It means "this group is the positional legacy *layout*", not "these values
   came from the legacy path". Use the root `photodiode_source` attr.
3. **`corrections_applied` is a comma-joined string with an unpinned type.** The consumer does
   `str(applied).split(",")`; hand it a list and `str(['photodiode','side','acm'])` splits into
   one garbage token. The pixels stay safe -- re-application is keyed on `stage`, not on this
   string -- so the blast radius is a mislabelled digest and a suppressed ACM travel warning.
4. **`segment` (root) != `acm_segment`.** `segment` is the visit-id segment field from stage 1;
   `acm_segment` is the ACM configuration index. Unrelated quantities, near-identical names, both
   on the root group of the same file.
5. **`acm_segment_reference_lvdt` is not the reference epoch's LVDT** -- it is *this* epoch's
   segment's. On this set the reference epoch is in segment 0 while three other segments exist.
6. **`acm_deploy_min_delta_lvdt` in the digest meta selects nothing.** It is kept for key
   stability. The live threshold is `acm_move_min_delta_lvdt`.

**Counts and flags that overstate**

7. **`n_sca = 18` is nominal geometry**, not coverage; `coverage_n_sca`/`coverage_complete` on a
   *calibrated* product are copied from the raw file and can claim 18 detectors while a NaN
   factor has emptied an LED stack. The truthful fields are the per-dataset `n_sca`/`scas_present`
   and `calibration/valid`.
8. **A `valid[i] == False` does not say which term failed** -- photodiode invalidity is per LED,
   ACM invalidity is all six at once.
9. **`sca_arrays/DARK` is a named all-NaN placeholder on this generation**, not dark imagery.
10. **`hardware_led = -1` in the PD sidecar ECSV means "none"** (dark/off/unknown/multiple), not
    a detector index.
11. **A `rule_<mnemonic>` of `nearest` is an extrapolation**, not a measurement of that activity.

**Joins and ordering**

12. **`pass_number` is not unique** -- 36 duplicated `(car_label, pass_number)` pairs on this set,
    because CAR216 plans 2 and 3 both start at pass 1. Join on `run_label`.
13. **Never sort products by filename**, and never match the audit ECSV on its `epoch` column
    (Sec. 2, Sec. 6.3).

**Set-level hazards**

14. **`digests/`, the default output and the fitters' default input, is not the newest set on
    disk.** Right now it holds a 166-epoch 2026-09-29 run from `/data/eswitzer/rcs_trend_batch`
    (a known query-overload casualty), while the current set is
    `digests/digests_v3_10_06_26/` (176 epochs, 15 columns). `digests/digests_v3_10_05_26/` is
    the same data root but one revision older and lacks `decon_time_hours`;
    `digests/20261004/` is from `rcs_trend_v2`. Always pass `--digest-dir` / `--data-root`
    explicitly.
15. **Re-running stage 2 over a grown raw directory silently mixes reference cards** unless
    `--force` is used (now the default in `batch/run_calibration.sh`), and the console output can
    look right while the old file stays on disk.
16. **`--stage calibrated` can double-apply.** Stage 2 validates `product_kind` but not `stage`.
17. **`--quiet` does not quiet the calibration loop** -- it reaches only the self-test and the card
    builder.
18. **Legacy mosaic products have `bin_factor = 20`**, and 4096/20 = 204.8, so superpixels
    straddle detector edges at the ~0.1 % level -- the size of the film signal. That is why the
    per-SCA path at bin 16 exists, and why `bin_factor` is one of the three keys that have to
    agree before two digests are comparable.

**The temperature gain**

19. **`calibration/tempgain/multiplier` (top-level `tempgain/multiplier` on schema 1) is `1/G`,
    not `G`.** It is the factor you *multiply by* to remove the
    gain. The two differ only in the sign of a ~1 % term, both sit near 1.0, and shipping the
    wrong one is a 2 %-of-signal error in the wrong direction with nothing in the file to notice.
    The direction check: a detector is **less** responsive hot, so above nominal the multiplier is
    **greater** than 1. This was a real bug during development, caught from the printed values and
    not by a test -- an equality test against `1/gain_grid(T)` passes happily if the sign flips on
    both sides at once, so the test that pins it asserts the *direction* separately.
20. **Apply the ratio to a trend, the multiplier to an epoch** -- for every step, not only the
    gain. Every `calibration/<step>/multiplier` is absolute. A series gauged to its first epoch
    needs `m_i/m_0` (Sec. 6.2). Using the absolute multipliers offsets the whole series by a
    constant per (LED, SCA). The bridges are gauged to the present configuration and the
    photodiode to each side's first epoch, so on this set the offset is the side step itself,
    up to 11 % on LED1, and the result is smooth and plausible.
21. **`applied = False` on every step of every schema-2 product.** A step being present does
    not mean the pixels include it; none do. `tempgain_applied` stays `False` for the same
    reason.

**The schema-2 calibration**

- **`total_multiplier` leaves out the temperature gain.** It is the digests' canonical
  combination. Multiply by `calibration/tempgain/multiplier` yourself if you want it, and do
  not then also use the digests' `_tgcorr` columns.
- **The bridges in a product change when the trend grows.** They are present-nominal and
  fitted from the whole set, so a new ACM move or side change re-gauges every earlier epoch.
  `bridge_solution_sha256` says which fit a product carries, and the digests'
  `bridge_solution_check` says whether it is the current one.
- **The hardware LED number changes meaning at the swap** (Sec. 2). Anything keyed by
  `hardware_led` across 2026-10-06 compares different LEDs.
22. **Never evaluate the gain at an epoch-mean temperature.** The six LEDs are measured in
    sequence over ~24 minutes and span up to 0.8 K during a cooldown (measured: 0.320 K in the
    first product of this set). Sequence order is wavelength order, so an epoch mean converts
    this achromatic gain into an apparent chromatic ramp. `TempGainModel.gain_grid` has no
    scalar-temperature overload for exactly this reason.
23. **A finite multiplier is not evidence of coverage.** It is a property of the model and the
    temperature; the detector may have no data. Use `coverage/` and `calibration/valid`.
24. **The digests' `LED1...LED6` are gain-free by design, not by omission** (Sec. 6.2). Applying the
    block to them double-counts against `LEDx_tgcorr`, and makes `fit_temperature_gain.py` a
    fixed-point iteration on its own output.

---

## 9. Regression gates

The checks that must pass before a product set is believed. All are credential-free except where
noted.

| gate | command | required output |
|---|---|---|
| the self-test gate | `process_rcs_trending.py --self-test` | every module's self-test green, ~20 s |
| card reproducibility | rebuild the card, `md5sum` against the installed one | equal |
| digest regression | `make_sca_digests.py --compare-dir <reference set>` | `worst response deviation 0.000e+00` |
| PD regression | `check_pd_regression.py --pd-dir <dir of pd_*.ecsv>` | `PASS`. Two tolerances on purpose: `pd_net_legacy` bit-exact at 1e-12, `pd_net` at 1e-5 V ~ 34 telemetry quanta, which bounds pedestal drift rather than floating point |
| audit annotation | `scripts/annotate_l2_audit_meta.py --check` | `meta["flat_field_finding"]` present and current |
| figure provenance | regenerate the `plots/calibration/` figures | only the figure you changed changes; the others byte-identical |
| temperature-gain pixel identity | stage 2 twice over the same raw set, with and without `--tempgain-model`, then compare every dataset recursively | **every dataset bit-identical**, the no-model tree carrying no `tempgain` group and no `tempgain_*` root attr. Measured on this set: 18 808 datasets, 2.05e9 float elements, zero differences |
| temperature-gain gauge | `LEDx_tgcorr[0]` in every digest | **exactly 1.0**, and `LEDx_tgcorr == LEDx * tempgain_LEDx / tempgain_LEDx[0]` to 1e-12. A time-constant gain must leave `LEDx_tgcorr` *bit-identical* to `LEDx` -- the gauge absorbs it, and that is the test that catches a dropped `/m[0]` |
| temperature-gain non-circularity | refit the gain on gain-carrying digests (`--digest-dir` at the gain-carrying set) | coefficients equal to the committed model. Measured on this set: **all 108 `alpha1`/`alpha2` identical to every digit**, `max dG(124 K) = 0`, same chi^2/dof and same rate. If they move, the canonical/`_tgcorr` column split has leaked and the fit is reading its own output |
| the delivered figure, no model | `time_series_LEDx_all_scas.png` from a run with **no** block | byte-identical to a build from before the feature existed, because with no blink partner the figure keeps matplotlib's own autoscale. The `_tgcorr` figure appears only in the gain run |
| the blink frame | the pair `time_series_LEDx_all_scas{,_tgcorr}.png` from a gain run | identical pixel dimensions **and identical y-limits** -- the pair is meant to be blinked, and an autoscale per file would show the axes rescaling rather than the data moving. Note the consequence: in a gain run the delivered figure adopts the shared frame, so it is *not* byte-identical to the no-model run. That is intended; the shared frame spans the union of both series because the corrected curves fall below the delivered autoscale on LED3 and LED6 (by 5.7 % and 9.1 % of the frame), and reusing the delivered limits would clip them |
| schema 2 reproduces schema 1 | v3 raw through the new stage 2 and stage 3, `--compare-dir digests/digests_v3_10_07_26` | worst response deviation **1.75e-7** over all 18 SCAs (float32 rounding: schema 1 multiplied float32 pixels, schema 2 multiplies a float64 ratio); the ACM closure reproduces at 0.067 % |
| schema-2 pixel identity | every `sca_arrays/<key>` of every `*_cal.h5` against its `*_raw.h5` | **bit-identical, dtype included**: 1 971 datasets over 201 pairs, zero differences (2026-10-12, deployed tree) |
| the bootstrap closes | `run_trend.py` (asserts both, and fails otherwise) | final `bridge_solution_check` reads `current` (max relative difference **2.2e-16**), and `LED1...LED6` **bit-identical** between the pass-1 and final digests |
| the h5 is self-contained | `python rcs_trend_reader.py compare CAL_DIR DIGEST_DIR` (exits non-zero above 1e-9) | **102 digest columns and meta keys** rebuilt from the products alone: 88 bit-identical, 14 within **6.7e-16**. That covers every column, the `bridge_*` and `side_bridge_*` families, ACM moves, travel, decon episodes and the gain reference. The blink figures' shared frame equals the digest figures' to 2.2e-16 |

Versioning convention across the board: **dated snapshot directories**, not versioned filenames
(`digests_9_29_26`, `digests/digests_v3_10_05_26`, `digests/digests_v3_10_06_26`). `_v3` in a
*path* refers to the `/data/eswitzer/rcs_trend_v3` data root. Within the files, version is
carried as content: `meta["created"]` in the digests, the model stamp in the fitter tables,
`ref_file_id` + `calibration_class` in the audit, and the card's file sha256 in every product it
touched.
