#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 16 02:59:41 2022
WFI Quicklook
@author: mscabrer
"""

import matplotlib.pyplot as plt
import numpy as np
from astropy.io import fits
import warnings
from os import makedirs
from os.path import dirname, exists

try:
    from pyds9 import DS9, ds9_targets, ds9_xpans
except ModuleNotFoundError:
    # print('pyds9 not installed in current environment - communication with DS9 window is impossible.')
    pass

from . import git_utils as gu

#UM_PER_PIX = 10
PIX_PER_MM = 100
xmax = 140
xmin=-140
ymax = 70
ymin = -110 

semiW = 20.44
# This constant is used to ensure that the function used to round the bounds of the mosaic frame and the function used
# to round the row/col offsets for each detector is consistent. This is done to avoid a possible out-of-bounds error.
PLCMNT_ROUND_FUN = round


# Ignoring the tight layout UserWarning
warnings.filterwarnings("ignore", category=UserWarning)

def createMosaicFrame(shift_background = 0., r=1):

    #mosaicFrame = np.zeros((int((ymax-ymin)*PIX_PER_MM/r), int((xmax-xmin)*PIX_PER_MM/r))) - shift_background
    mosaicFrame = np.zeros((int((ymax-ymin)*PIX_PER_MM/r), int((xmax-xmin)*PIX_PER_MM/r)))
    
    mosaicFrame[:, :] = np.nan

    midPoint = {'j' : int(abs(xmin)*PIX_PER_MM),
                'i' : int(abs(ymin)*PIX_PER_MM)}
    return mosaicFrame, midPoint


def placeImages(SCA_frms, midPoint, mosaicFrame, r=1, rotate_images=True):
    ##for detecNum in range(1, len(df)+1):
    for SCA_num in np.array(list(SCA_frms)):
        MPA_pos = SCA_num
        #MPA_pos = data2MPA_position(SCA_num)
        '''
        if (SCA_frms[SCA_num].shape[0] != 4096) | (SCA_frms[SCA_num].shape[1] != 4096):
            temp = np.empty((4096, 4096))
            temp[:,:] = np.nan
            row_shift = (4096 - SCA_frms[SCA_num].shape[0])//2
            col_shift = (4096 - SCA_frms[SCA_num].shape[1])//2
            temp[row_shift:-row_shift, col_shift:-col_shift] = SCA_frms[SCA_num]
            SCA_frms[SCA_num] = temp
        '''
        
        imgData = SCA_frms[SCA_num][:, :int(4096/r)]
        
        # Rotating the images from detector reference frame to science reference frame, if desired.
        if rotate_images:
            #print('Rotated image')
            imgData = imgData[:,::-1] # flip the horizontal axis since we are looking at the pixels from the top
            if MPA_SCA_info(MPA_pos)['r'] == 180:
                imgData = imgData[::-1,::-1]
        r1, r2, c1, c2 = getPlacement(MPA_SCA_info(MPA_pos)['x'], MPA_SCA_info(MPA_pos)['y'], midPoint, r=r)

        mosaicFrame[r1:r2,c1:c2] = imgData
    return mosaicFrame


def getPlacement(xOffset, yOffset, midPoint, r=1):
    rowOffset = PLCMNT_ROUND_FUN(float(yOffset * PIX_PER_MM))
    colOffset = -PLCMNT_ROUND_FUN(float(xOffset * PIX_PER_MM)) # keep the minus sign to display view from above (+x towards left)
    r1 = midPoint['i'] + rowOffset - 2048
    c1 = midPoint['j'] + colOffset - 2048
    r2 = r1 + 4096
    c2 = c1 + 4096
    return int(r1/r), int(r2/r), int(c1/r), int(c2/r)


# The x, y coordinates for each detector in the focal plane array. 'r' is the rotation of that detector in degrees.
def MPA_SCA_info(MPA_pos):
    return {
            1  : {'x' : -22.1400,  'y' : 12.1500,  'r' : 180},
            2  : {'x' : -22.2900,  'y' : -37.0300, 'r' : 180},
            3  : {'x' : -22.4400,  'y' : -82.0600, 'r' : 0},
            4  : {'x' : -66.4200,  'y' : 20.9000,  'r' : 180},
            5  : {'x' : -66.9200,  'y' : -28.2800, 'r' : 180},
            6  : {'x' : -67.4200,  'y' : -73.0600, 'r' : 0},
            7  : {'x' : -110.7000, 'y' : 42.2000,  'r' : 180},
            8  : {'x' : -111.4800, 'y' : -6.9800,  'r' : 180},
            9  : {'x' : -112.6400, 'y' : -51.0600, 'r' : 0},
            10 : {'x' : 22.1400,   'y' : 12.1500,  'r' : 180},
            11 : {'x' : 22.2900,   'y' : -37.0300, 'r' : 180},
            12 : {'x' : 22.4400,   'y' : -82.0600, 'r' : 0},
            13 : {'x' : 66.4200,   'y' : 20.9000,  'r' : 180},
            14 : {'x' : 66.9200,   'y' : -28.2800, 'r' : 180},
            15 : {'x' : 67.4200,   'y' : -73.0600, 'r' : 0},
            16 : {'x' : 110.7000,  'y' : 42.2000,  'r' : 180},
            17 : {'x' : 111.4800,  'y' : -6.9800,  'r' : 180},
            18 : {'x' : 112.6400,  'y' : -51.0600, 'r' : 0},
            #19 : {'x' : 110.7000, 'y' : -132.06,  'r' : 0},
            #20 : {'x' : 66.4200,  'y' : -132.06,  'r' : 0},
            #21 : {'x' : 22.1400,  'y' : -132.06,  'r' : 0},
            #22 : {'x' : -22.1400,   'y' : -132.06,  'r' : 0},
            #23 : {'x' : -66.4200,   'y' : -132.06,  'r' : 0},
            #24 : {'x' : -110.7000,  'y' : -132.06,  'r' : 0},
            }[MPA_pos]


def data2MPA_position(SCA_data_ch):
    return {0 : 16,
            1 : 13,
            2 : 10,
            3 : 1,
            4 : 4,
            5 : 7,
            6 : 17,
            7 : 14,
            8 : 11,
            9 : 2,
            10 : 5,
            11 : 8,
            12 : 18,
            13 : 15,
            14 : 12,
            15 : 3,
            16 : 6,
            17 : 9
            }[SCA_data_ch]


def MPA2data_position(SCA_pos):
    return {16 : 0,
            13 : 1,
            10 : 2,
            1 : 3,
            4 : 4,
            7 : 5,
            17 : 6,
            14 : 7,
            11 : 8,
            2 : 9,
            5 : 10,
            8 : 11,
            18 : 12,
            15 : 13,
            12 : 14,
            3 : 15,
            6 : 16,
            9 : 17
            }[SCA_pos]


def MPA2aceasic_position(SCA_pos):
    return {16 : 'ACE 1 | ASIC 1',
            13 : 'ACE 1 | ASIC 2',
            10 : 'ACE 1 | ASIC 3',
            1 : 'ACE 1 | ASIC 4',
            4 : 'ACE 2 | ASIC 1',
            7 : 'ACE 2 | ASIC 2',
            17 : 'ACE 2 | ASIC 3',
            14 : 'ACE 2 | ASIC 4',
            11 : 'ACE 3 | ASIC 1',
            2 : 'ACE 3 | ASIC 2',
            5 : 'ACE 3 | ASIC 3',
            8 : 'ACE 3 | ASIC 4',
            18 : 'ACE 4 | ASIC 1',
            15 : 'ACE 4 | ASIC 2',
            12 : 'ACE 4 | ASIC 3',
            3 : 'ACE 4 | ASIC 4',
            6 : 'ACE 5 | ASIC 1',
            9 : 'ACE 5 | ASIC 2'
            }[SCA_pos]


def MPA2SCA(MPA_pos):
    return {16 : 21643,
           13 : 22067,
           10 : 22078,
           1 : 22081,
           4 : 21115,
           7 : 22069,
           17 : 21319,
           14 : 21814,
           11 : 21947,
           2 : 21815,
           5 : 21816,
           8 : 21641,
           18 : 20833,
           15 : 21645,
           12 : 20829,
           3 : 21946,
           6 : 20663,
           9 : 21813
           }[MPA_pos]


#These are Semi-Flight FPS TVAC test SCAs
def Semi_FLT_MPA2SCA(MPA_pos):
    return {16 : 21643,
           13 : 22067,
           10 : 22078,
           1 : 22066,
           4 : 22073,
           7 : 22069,
           17 : 21319,
           14 : 21814,
           11 : 21947,
           2 : 21815,
           5 : 21816,
           8 : 21641,
           18 : 20833,
           15 : 21645,
           12 : 22077,
           3 : 21946,
           6 : 20663,
           9 : 21813
           }[MPA_pos]



def save_data_fits(data, fits_name, header = None, key_dict = None, overwrite_fits = True):
    #For this function, key_dict is a dictionary for things you want added to the header. The keyword of the dictionary will be the keyword of the header. To that key, you need to assign a list to it with two entries: First is the value and the second is any comment you would want to add, and it could just be set to None
    hdu=fits.PrimaryHDU()
    sci_hdu = fits.ImageHDU()
    sci_hdu.data = data
    sci_hdu.header["EXTNAME"] = 'SCI'
    #hdu.header.update('array','This contains only the active pixels')
    if type(header) == dict:
        key_dict = header
        
    if key_dict is not None:
        
        for key in list(key_dict):
            if (type(key_dict[key]) == list) | (type(key_dict[key]) == tuple):
                sci_hdu.header[key] = (key_dict[key][0], key_dict[key][1])
            else:
                # print(key, key_dict[key])
                try:
                    sci_hdu.header[key] = key_dict[key]
                except:
                    continue
                
    if (header is not None) & (key_dict is None):
        orig_hdr = sci_hdu.header.copy()
        for key_i, key in enumerate(list(orig_hdr)):
            if key in list(header):
                del header[key]
            header.insert(key_i, (key, orig_hdr[key], orig_hdr.comments[key]))
        sci_hdu.header = header
    
    hdulist=fits.HDUList([hdu, sci_hdu])
    gu.add_to_header(hdulist[0])
    hdulist.writeto(fits_name, overwrite = overwrite_fits)
    
    # if live_ds9_view:
            
    #     if ds9_targets() is None:
    #         dx = ds9_xpans()
    #         if dx == 1:
    #             while dx != 0:
    #                 dx = ds9_xpans()
    #     # finds the existing DS9 window, or open if needed
    #     d = DS9('quicklook')
        
    #     nu.display_ds9_hdul(d,
    #                         hdulist,
    #                         pct=2,
    #                         colormap='viridis')
    
    hdulist.close()


### Watch out for the extent parameter ###
### X axis points towards the left of the mosaic ###
def plot_mosaic(SCA_frms, perc=2, r=1, clrbar_txt = 'Counts', output_name = None, header = None, make_mosaic_plot = True, semi_flt = False, live_ds9_view = False, ret_mosaic = False, key_dict=None):
    '''
    plot mosiac from SCA frames

    Parameters
    ----------
    SCA_frms : dict
        dictonary of SCA numbers to numpy array of pixels
    perc : int, optional
        percentile used in scaling, 2 means 2 to 98 percentile scale. The default is 2.
    r : int, optional
        reduced data in x & y by every r pixels. If using decimated or binned data this scaling must be applied. 
        The default is 1.

    Returns
    -------
    None.

    '''
    
    mosaicFrame, midPoint = createMosaicFrame(r=r)
    img = placeImages(dict(SCA_frms), midPoint, mosaicFrame, r)
    if ret_mosaic:
        return img
    #img = m
    
    all_frms = np.array([SCA_frms[SCAnum] for SCAnum in list(SCA_frms)])
    scavmin = np.nanpercentile(all_frms[:, :, :int(4096//r)], perc)
    scavmax = np.nanpercentile(all_frms[:, :, :int(4096//r)], 100-perc)
    del all_frms
    
    #if scavmin < 0:
    #    shift = -1.*scavmin*1.1
    #else:
    #    shift = 0
    

    if output_name is not None:
        
        dname = dirname(output_name)
        if not exists(dname):
            makedirs(dname)
        save_data_fits(img.astype(np.float32), output_name, header = header, live_ds9_view = live_ds9_view, key_dict=key_dict)
    
    if make_mosaic_plot:
        fig, ax = plt.subplots(num = 1, clear = True)
        fig.set_size_inches(13.33, 6.5)
        
    
        plt.imshow(img,
                   vmin=scavmin,
                   vmax=scavmax,
                   extent=[xmax, xmin, ymin, ymax], cmap = 'gray', origin = 'lower')
    
        #plt.title('{:} Mosaic (e for 150s exposure) | view from above'.format(MosaicKey))
            
        ax.set_xlabel('FPA X axis (mm)')
        ax.set_ylabel('FPA Y axis (mm)')
        ax.tick_params(axis='both', which='major')
        plt.grid(False)
        cbar = plt.colorbar(fraction=0.046, pad=0.04, label = clrbar_txt)
        #cbar.ax.tick_params(labelsize=50)
        for detecNum in range(1, 19):
            if semi_flt:
                detSN = Semi_FLT_MPA2SCA(detecNum)
            else:
                detSN = MPA2SCA(detecNum)
            
            if detecNum in [9,6,3,12,15,18]:
                plt.text(MPA_SCA_info(detecNum)['x'],MPA_SCA_info(detecNum)['y']-semiW,str(detecNum)+"| "+str(detSN),ha="center", va="top",color='black')
            else:
                plt.text(MPA_SCA_info(detecNum)['x'],MPA_SCA_info(detecNum)['y']+semiW,str(detecNum)+"| "+str(detSN),ha="center", va="bottom",color='black')
    
        plt.tight_layout()
        fig.subplots_adjust(top = 1, bottom = 0.07, left = 0, right = 0.92, hspace = 0, wspace = 0)
        
        return fig, ax

def plot_mosaic_from_ax(img, ax, scavmin, scavmax, clrbar_txt='Counts', semi_flt=False):
    '''
    This takes a pre-made mosaic image and matplotlib axis, and shows the image.
    
    PARAMS:
    -------
    img - mosaic image
    ax - matplotlib axis object
    scavmin - int/float, VMIN for the color scale
    scavmax - int/float, VMIN for the color scale
    clrbar_txt - string, text for the color bar (default "Counts")
    semi_flt - bool, if true, will use the semi-flt detector SNs (default False)
    '''
    
    

    # fig.set_size_inches(13.33, 6.5)
    

    plt.imshow(img,
               vmin=scavmin,
               vmax=scavmax,
               extent=[xmax, xmin, ymin, ymax], cmap = 'gray', origin = 'lower')

    #plt.title('{:} Mosaic (e for 150s exposure) | view from above'.format(MosaicKey))
    
    ax.set_xlabel('FPA X axis (mm)')
    ax.set_ylabel('FPA Y axis (mm)')
    ax.tick_params(axis='both', which='major')
    plt.grid(False)
    cbar = plt.colorbar(fraction=0.046, pad=0.04, label = clrbar_txt)
    #cbar.ax.tick_params(labelsize=50)
    for detecNum in range(1, 19):
        if semi_flt:
            detSN = Semi_FLT_MPA2SCA(detecNum)
        else:
            detSN = MPA2SCA(detecNum)
        
        if detecNum in [9,6,3,12,15,18]:
            plt.text(MPA_SCA_info(detecNum)['x'],MPA_SCA_info(detecNum)['y']-semiW,str(detecNum)+"| "+str(detSN),ha="center", va="top",color='black')
        else:
            plt.text(MPA_SCA_info(detecNum)['x'],MPA_SCA_info(detecNum)['y']+semiW,str(detecNum)+"| "+str(detSN),ha="center", va="bottom",color='black')


        

    plt.tight_layout()
    # fig.subplots_adjust(top = 1, bottom = 0.07, left = 0, right = 0.92, hspace = 0, wspace = 0)
    
    return ax