"""Activity identity: visit identifiers, staging ids, run labels, grouping.

The bookkeeping half of the flight pipeline, split out of
``process_rcs_trending.py``. Everything here is a pure function over dicts,
astropy rows and pandas frames -- there is **no astroquery import** and no
network call, which is what keeps ``process_rcs_trending.py --self-test``
runnable without a MAST token. The query side lives in :mod:`rcs_mast` and the
housekeeping side in :mod:`rcs_telemetry`.

The one concept worth reading before anything else is the 19-digit Visit
Identifier and why :func:`assign_staging_ids` sometimes has to forge one: the
frozen compiler locates each telemetry row's mosaic by globbing that id, so a
run whose activities share an id silently pairs the dark's mosaic with every
LED row.
"""
from collections import Counter
import os
import re

import numpy as np
import pandas as pd

# Imported rather than redefined so the two entry points cannot drift on the
# conventions the compiler actually depends on.
from stage_rcs_inputs import ACTIVITY_TO_KEY

# CAR-190 is program 1039 (the value the streaming example notebook queries).
DEFAULT_PROGRAM = 1039

N_ACTIVITIES = 7

# Run-label prefix per program (see run_label); PROGRAM_LABELS.get(program,
# "CAR190") is the fallback for an unrecognized program.
PROGRAM_LABELS = {1039: "CAR190", 1063: "CAR216"}

# Expected total activity count per program, for survey/warning messages.
EXPECTED_EXPOSURES = {1039: 7, 1063: 15}

# The core sequence, the same in every variant seen: obs 1 is the dark
# reference and obs 2-7 are the six LED flats, one exposure each. Anything after
# obs 7 is an aux activity, stored in the product but never trended. The aux
# layout changes between variants, so it is keyed by what each exposure IS, not
# by its observation number (see aux_key_base):
#   CAR-216 to decon2: obs 8 = 4 darks, obs 9 = 4 LED3 flats (41 s).
#   CAR-216 decon3 (plan 6 on, 2026-10-20): obs 8 = a persistence dark (177 s),
#   obs 9 = 4 darks (41 s), obs 10 = 5 low-flux LED3 flats (66 s), obs 11 = 4
#   high-flux LED3 flats (41 s), obs 12 = a persistence dark.
# Darks never reach L2, nor do the decon3 low-flux flats (22 resultants; L2
# processing takes 16 or fewer), so in practice only the 41 s aux flats are
# stored.
CORE_OBSERVATIONS = frozenset(range(1, 8))
# A dark this long is a persistence clean-up dark (177 s), not a diagnostic one
# (41 s); a band-3 flat this long is the low-flux set (66 s), not the 41 s one.
PERSISTENCE_DARK_MIN_S = 120.0
LOW_FLUX_FLAT_MIN_S = 55.0

# Product root name, e.g. r0012301008002013005_0005_wfi06_f184_cal.asdf. The
# 19-digit group is the Visit Identifier PPPPPCCAAASSSOOOVVV = program(5) +
# execution_plan(2) + pass(3) + segment(3) + observation(3) + visit(3); the
# 4-digit group is the Exposure Identifier. Parsing the filename is deliberate:
# read_per_sca documents that per-SCA headers carry SCA01's detector id copied
# into every file, so the name is the authority for which detector this is.
PRODUCT_NAME_RE = re.compile(
    r"^r(?P<visit>\d{19})_(?P<exposure>\d{4})_wfi(?P<sca>\d{2})_"
    r"(?P<optical_element>[^_]+)_(?P<suffix>[a-z0-9]+)\.asdf$", re.I)

# Widths of the Visit Identifier's fields, in order.
VISIT_ID_FIELDS = (("program", 5), ("execution_plan", 2), ("pass", 3),
                   ("segment", 3), ("observation", 3), ("visit", 3))

# Values of meta.rcs.led (or the MAST 'led' column) that mean "no LED lit", i.e.
# the dark reference. Which of these flight actually uses is not yet known --
# see the --dry-run output, which prints every distinct value it saw so the set
# can be narrowed on first real data.
DARK_LED_VALUES = {"", "0", "none", "n/a", "na", "dark", "dis", "off", "-1",
                   "-99", "nan", "--"}


# ---------------------------------------------------------------------------
# Coercion of masked archive cells
# ---------------------------------------------------------------------------

def _as_int(value, default=None):
    """Coerce a possibly-masked astropy/pandas cell to int, or ``default``."""
    try:
        if value is None or (np.ndim(value) == 0 and pd.isna(value)):
            return default

        return int(value)
    except (TypeError, ValueError):
        return default


def _as_header_float(value, sentinel=-99.0):
    """Coerce to float for a FITS header, substituting a sentinel for NaN.

    FITS headers have no standard representation for NaN, so the mosaics use the
    same ``-99.0`` sentinel the TVAC path already uses for an unknown wavelength
    rather than writing something a reader has to special-case.
    """
    try:
        number = float(value)
    except (TypeError, ValueError):
        return sentinel

    return number if np.isfinite(number) else sentinel


def _as_str(value):
    """Coerce a possibly-masked cell to a stripped string."""
    if value is None:
        return ""
    try:
        if np.ndim(value) == 0 and pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass

    return str(value).strip()


def _product_filename(row):
    """The streamable name out of a product row, whatever the column is called.

    ``read_product`` takes the archive filename; which column carries it has
    varied across astroquery revisions (``filename`` in the streaming example,
    ``productFilename`` in the older download-oriented interface), and this runs
    against a pinned fork of a moving target.
    """
    for column in ("filename", "productFilename", "fileName", "product_name"):
        if column in row.colnames:
            name = _as_str(row[column])
            if name:
                return name

    raise KeyError(f"no filename-like column in product row; "
                   f"columns are {list(row.colnames)}")


# ---------------------------------------------------------------------------
# Identifiers
# ---------------------------------------------------------------------------

def visit_identifier(fields):
    """Compose the 19-digit Visit Identifier from its six numeric fields.

    Returns ``""`` if any field is missing, so callers fall back to parsing the
    product filename -- which always carries the id verbatim and is therefore
    the more reliable source. This exists mainly to cross-check that the MAST
    columns and the filename agree.
    """
    parts = []
    for name, width in VISIT_ID_FIELDS:
        number = _as_int(fields.get(name))
        if number is None:
            return ""
        parts.append(f"{number:0{width}d}")
    identifier = "".join(parts)

    return identifier if len(identifier) == 19 else ""


def _exposure_from_file_set(file_set):
    """The 4-digit Exposure Identifier out of a ``fileSetName``.

    e.g. ``r0103902001001001001_0001_wfi01_dark`` -> 1. MAST exposes no
    ``exposure`` column for Roman, so this is the only source outside the
    per-product filename, which the survey queries do not fetch.
    """
    match = re.search(r"(\d{19})[_-]?(\d{4})", _as_str(file_set))

    return int(match.group(2)) if match else None


def staging_identifier(visit_id, exposure, synthetic=False):
    """The 19-digit id used in ``exp_path_done`` and the mosaic filename.

    Normally the true Visit Identifier. When ``synthetic``, the low four digits
    are replaced by the exposure number -- see :func:`assign_staging_ids` for why
    that is sometimes necessary and why it loses nothing.
    """
    if not synthetic:
        return visit_id

    return f"{visit_id[:15]}{int(exposure):04d}"


def assign_staging_ids(activities):
    """Give each activity a 19-digit id that is unique within the run.

    This guards the pipeline's one silent-wrong-answer path.
    ``compile_rcs_trend.process_trending_run`` locates each row's mosaic by
    globbing ``mosaics/{visit_number}*`` and taking ``fits_files[0]``, where
    ``visit_number`` is the 19 digits its regex pulled out of ``exp_path_done``.

    The 19-digit Visit Identifier is *visit*-level; the exposure number is what
    varies within a visit. In TVAC the seven activities were seven distinct
    **observations**, so each had its own 19-digit id and the glob resolved
    uniquely. If in flight they are instead seven **exposures within one visit**,
    all seven share one id, the glob matches all seven mosaics, and
    ``fits_files[0]`` returns the same file for the dark and for every LED --
    producing dark-subtracted arrays of approximately zero with no exception
    raised anywhere.

    So when the true ids are not unique we substitute the exposure number into
    the low four digits. That is information-preserving here: in exactly the case
    where the fallback triggers, all seven activities share the same
    observation and visit digits, so the four digits being overwritten are
    identical across them and cannot be what distinguishes the rows. The true
    ``fileSetName`` and exposure number are recorded in the mosaic headers and
    the provenance CSV, so a synthetic id is never mistaken for an archive
    identifier.

    Mutates each activity dict in place, adding ``staging_id`` and
    ``id_synthetic``.

    CAR-216 has:
    core seven are each their own observation with a distinct visit id
    four aux dark/flat of one observation (e.g. obs 9's ``AUX_LED3FLAT1..4``)
    share a single visit id.

    Substituting the exposure into the low four digits is only lossless
    within a group that truly shares all 15 of the digits being kept; doing
    it run-wide here would instead overwrite the last digit of a distinct
    observation number too, since that digit falls inside the four being
    replaced -- collapsing e.g. observations 1 and 2's exposure-1 activities
    onto the same staging id.
    """
    true_ids = [entry["visit_id"] for entry in activities]
    counts = Counter(true_ids)
    shared_ids = sorted(visit_id for visit_id, count in counts.items() if count > 1)

    if shared_ids:
        print("  WARNING: the 19-digit visit ids are not unique across the "
              f"{len(activities)} activities ({shared_ids}).")
        print("  WARNING: these activities are exposures within one visit. "
              "Substituting the exposure number into the low 4 digits so the "
              "compiler's per-row mosaic glob stays unambiguous; the true "
              "fileSetName is preserved in FILESET/EXPNUM.")

    for entry in activities:
        synthetic = counts[entry["visit_id"]] > 1
        entry["id_synthetic"] = synthetic
        entry["staging_id"] = staging_identifier(
            entry["visit_id"], entry["exposure"], synthetic=synthetic)

    ids = [entry["staging_id"] for entry in activities]
    bad = [i for i in ids if not re.fullmatch(r"\d{19}", i)]
    if bad:
        raise ValueError(
            f"staging ids must be exactly 19 digits for the compiler's "
            f"r'/(\\d{{19}})/Science/' regex to match; got {bad}")
    if len(set(ids)) != len(ids):
        raise ValueError(
            f"staging ids are still not unique after the exposure-number "
            f"fallback: {ids}. Two activities appear to share both visit and "
            f"exposure, which should be impossible; inspect the query result.")

    return activities


def run_label(activities, program=None):
    """Compose the run's identifying label.

    ``<CAR190|CAR216>_<program>_<execution_plan>_<pass>_<segment>_<YYYYMMDD>``
    -- the ``PPPPPCCAAASSS`` prefix of the Visit Identifier plus the run's
    start date. That prefix is the granularity at which this activity repeats:
    the observation and visit digits vary *within* a run, so including them
    would make the label change between activities of the same run. The
    letter prefix comes from ``PROGRAM_LABELS``, falling back to ``CAR190``
    for an unrecognized program.
    """
    first = activities[0]
    digits = first["staging_id"] if not first["id_synthetic"] else first["visit_id"]
    prefix = digits[:13]
    program = _as_int(program, default=None)
    program_digits = f"{program:05d}" if program is not None else prefix[:5]
    car_label = PROGRAM_LABELS.get(program, "CAR190")

    starts = [entry["start_time"] for entry in activities if entry["start_time"]]
    date = "unknown"
    if starts:
        stamp = pd.to_datetime(min(starts), errors="coerce", utc=True)
        if not pd.isna(stamp):
            date = stamp.strftime("%Y%m%d")

    return (f"{car_label}_{program_digits}_{prefix[5:7]}_{prefix[7:10]}_"
            f"{prefix[10:13]}_{date}")


def is_dark(led):
    """Whether an ``meta.rcs.led`` / MAST ``led`` value means "no LED lit"."""
    return _as_str(led).lower() in DARK_LED_VALUES


# ---------------------------------------------------------------------------
# Run isolation
# ---------------------------------------------------------------------------

def assert_single_pass(activities):
    """Fail if the grouped activities span more than one pass.

    ``--pass`` is the front door, but this is the invariant: ``--run-label``,
    ``--visit`` and a hand-built ``search`` all reach :func:`group_activities`
    too, and a run that silently mixes passes is the failure mode described in
    ``rcs_mast.survey_passes``. Cheap to check, and the only place it can be
    checked once and cover every path.
    """
    passes = sorted({entry["visit_id"][7:10] for entry in activities})
    if len(passes) > 1:
        raise ValueError(
            f"the grouped activities span {len(passes)} passes {passes}. Passes "
            f"reuse observation numbers, so this run would subtract one pass's "
            f"dark from another pass's flats and window the EDP across both. "
            f"Re-run with --pass set to one of {passes}.")

    return passes[0]


def assert_single_execution_plan(activities):
    """Fail if the grouped activities span more than one execution plan.

    CAR-216 repeats its 9-observation sequence across execution plans 2 and 3
    each plan's pass numbers start over, so an
    unpinned query could mix a plan-2 pass with a plan-3 pass that happens to
    share a pass number. Sibling check to :func:`assert_single_pass`, same
    reasoning.
    """
    plans = sorted({entry["visit_id"][5:7] for entry in activities})
    if len(plans) > 1:
        raise ValueError(
            f"the grouped activities span {len(plans)} execution plans "
            f"{plans}. Re-run with --execution-plan set to one of {plans}.")

    return plans[0]


# ---------------------------------------------------------------------------
# Grouping products into activities
# ---------------------------------------------------------------------------

def group_activities(results, products, fallback_dark=None):
    """Group ``_cal`` products into one entry per activity (exposure).

    Returns a list of dicts, dark first and the six LED activities in exposure
    order after it, followed by any CAR-216 aux activities (obs 8, 9). That
    core ordering is load-bearing, not cosmetic: ``process_trending_run`` names
    its output arrays ``LED1``..``LED6`` by **CSV row order** and subtracts row
    0 from all of them as the dark reference. The hardware LED that was
    actually lit is recorded separately (``HWLED``), because TVAC already
    showed the hardware order is not the activity order -- activity 2 there
    lit hardware LED6.

    ``fallback_dark`` is used only when the L2 products contain no dark at all:
    an entry from ``rcs_mast.find_l1_dark`` carrying the dark exposure's real
    identity and timing but ``frames == {}``. It becomes row 0 with a NaN
    mosaic and disables dark subtraction.

    CAR-216 tacks two more observations onto the core seven: obs 8 (4 dark
    exposures) and obs 9 (4 LED3-flat exposures), identified by the MAST
    observation number embedded in the Visit Identifier
    (``AUX_OBSERVATION_KEYS``), not by the ``led``-value ``is_dark()``
    heuristic -- which would otherwise misclassify obs 8's aux darks as extra
    copies of the primary dark. They are split off into ``aux`` *before* the
    darks/lit logic below runs, so that logic only ever sees the core seven and
    CAR-190 is unaffected. Each aux entry is tagged ``is_aux`` and keyed
    ``AUX_DARK1``..``AUX_DARK4`` / ``AUX_LED3FLAT1``..``AUX_LED3FLAT4`` by
    :func:`_assign_aux_keys`, tacked onto the h5 by
    ``process_rcs_trending.attach_aux_activities`` after the compiler runs --
    never fed to it.
    """
    # Exposure-level metadata from the search result, keyed by (visit, exposure)
    # so it can be attached to each group. Filenames are parsed for the keys;
    # the query columns supply times and LED state.
    meta_by_key = {}
    for row in results:
        fields = {name: row[name] for name in row.colnames}
        visit_id = visit_identifier(fields)
        exposure = _as_int(fields.get("exposure"))
        file_set = _as_str(fields.get("fileSetName"))
        if not visit_id or exposure is None:
            # Fall back to whatever digits the fileSetName carries.
            match = re.search(r"(\d{19})[_-]?(\d{4})", file_set)
            if not match:
                continue
            visit_id = visit_id or match.group(1)
            exposure = exposure if exposure is not None else int(match.group(2))
        meta_by_key.setdefault((visit_id, exposure), {
            "file_set_name": file_set,
            "start_time": _as_str(fields.get("exposure_start_time")),
            "end_time": _as_str(fields.get("exposure_end_time")),
            "exposure_time": fields.get("exposure_time"),
            "led": _as_str(fields.get("led")),
            "optical_element": _as_str(fields.get("optical_element")),
            "exposure_type": _as_str(fields.get("exposure_type")),
        })

    groups = {}
    unparsed = []
    for row in products:
        filename = _product_filename(row)
        match = PRODUCT_NAME_RE.match(os.path.basename(filename))
        if not match:
            unparsed.append(filename)
            continue
        key = (match.group("visit"), int(match.group("exposure")))
        entry = groups.setdefault(key, {
            "visit_id": key[0],
            "exposure": key[1],
            "frames": {},
            "sizes": {},
            **meta_by_key.get(key, {}),
        })
        sca = int(match.group("sca"))
        entry["frames"][sca] = filename
        # Archive file size in bytes, straight from the product row -- the only
        # place it is available. Used for the data-pull rate report in
        # stage_run; absent (rather than 0) if this astroquery revision's
        # product table has no 'size' column, so a report that can't compute a
        # rate says so instead of claiming 0 bytes were pulled.
        if "size" in row.colnames:
            size = _as_int(row["size"])
            if size is not None:
                entry["sizes"][sca] = size

    if unparsed:
        print(f"  WARNING: {len(unparsed)} product name(s) did not match the "
              f"expected convention and were skipped, e.g. {unparsed[0]!r}")
    if not groups:
        raise ValueError("no products could be grouped into activities; "
                         "the file naming convention may have changed")

    activities = list(groups.values())
    for entry in activities:
        entry.setdefault("led", "")
        entry.setdefault("start_time", "")
        entry.setdefault("end_time", "")
        entry.setdefault("file_set_name", "")
        entry.setdefault("exposure_time", np.nan)
        entry.setdefault("dark_blank", False)
        entry["is_dark"] = is_dark(entry["led"])
        entry["observation"] = _as_int(entry["visit_id"][13:16])

    print(f"  grouped into {len(activities)} activities; distinct led values: "
          f"{sorted({entry['led'] for entry in activities})}")

    core = [e for e in activities if e["observation"] in CORE_OBSERVATIONS]
    aux = [e for e in activities if e["observation"] not in CORE_OBSERVATIONS]

    core.sort(key=lambda e: (str(e["start_time"]), e["exposure"]))
    darks = [e for e in core if e["is_dark"]]
    lit = [e for e in core if not e["is_dark"]]
    if not darks and fallback_dark is not None:
        darks = [fallback_dark]
        print("  the dark has no L2 products; standing in the L1 dark's "
              "identity and timing with a blank (all-NaN) mosaic, and dark "
              "subtraction is OFF for this run")
    if len(darks) != 1:
        hint = ("The dark is identified by meta.rcs.led / the MAST 'led' column "
                "against DARK_LED_VALUES; if flight uses a representation not "
                "in that set, add it there.")
        if not darks:
            # Seen on the first live run: all six flats had reached L2 while the
            # dark, a separate WFI_IM_DARK exposure, had not been processed yet.
            # That is a wait, not a DARK_LED_VALUES problem, and the two look
            # identical from here -- so name both causes rather than the one.
            hint = (
                "No dark is present among the L2 products at all. Either the "
                "dark exposure has not been processed to L2 yet (check whether "
                "the run's WFI_IM_DARK observation has _cal products; the six "
                "flats can land well before it does), or its led value is a "
                "representation missing from DARK_LED_VALUES. If it is the "
                "former and you want the run anyway, pass --blank-dark: the "
                "flats are stored without dark subtraction and row 0 becomes an "
                "all-NaN placeholder.")
        raise ValueError(
            f"expected exactly one dark reference activity, found {len(darks)} "
            f"among led values {[e['led'] for e in core]}. {hint}")

    if len(lit) != 6:
        # Seen live: the dark and some LEDs reach L2 well before the rest (the
        # dark-missing case above is the same phenomenon one exposure earlier).
        # Without this check, a partial set of LEDs stages fine here and only
        # blows up deep inside the frozen compiler's `range(1, 7)` LED loop
        # (compile_rcs_trend.py), as a cryptic pandas "N is not in range".
        raise ValueError(
            f"expected exactly six lit LED activities, found {len(lit)} among "
            f"led values {sorted(e['led'] for e in lit)}. Some flats for this "
            f"visit have likely not reached L2 yet; retry later.")

    ordered = darks + lit
    for index, entry in enumerate(ordered, start=1):
        entry["activity_number"] = index
        entry["key"] = ACTIVITY_TO_KEY[index] if index in ACTIVITY_TO_KEY \
            else f"EXTRA{index}"
        entry["is_aux"] = False

    aux_ordered = _assign_aux_keys(aux)
    for index, entry in enumerate(aux_ordered, start=len(ordered) + 1):
        entry["activity_number"] = index
        entry["is_aux"] = True

    return assign_staging_ids(ordered + aux_ordered)


def _duration_s(entry):
    """An exposure's length in seconds: ``exposure_time``, else end - start."""
    value = entry.get("exposure_time")
    try:
        value = float(value)
    except (TypeError, ValueError):
        value = np.nan
    if np.isfinite(value) and value > 0:
        return value
    try:
        start = np.datetime64(str(entry.get("start_time", ""))[:26])
        end = np.datetime64(str(entry.get("end_time", ""))[:26])
        return float((end - start) / np.timedelta64(1, "s"))
    except ValueError:
        return np.nan


def aux_key_base(entry):
    """The h5 key base of one aux activity, from what it is.

    ``AUX_PERSISTDARK`` (a dark of 120 s or more), ``AUX_DARK``,
    ``AUX_LED3LOWFLUX`` (a band-3 flat of 55 s or more), ``AUX_LED3FLAT``, and
    ``AUX_LED<n>FLAT`` for any other band. The CAR-216 keys before decon3
    (``AUX_DARK``, ``AUX_LED3FLAT``) come out unchanged, so aux arrays keep
    their names across the variant change.
    """
    duration = _duration_s(entry)
    if entry.get("is_dark", is_dark(entry.get("led", ""))):
        if np.isfinite(duration) and duration >= PERSISTENCE_DARK_MIN_S:
            return "AUX_PERSISTDARK"
        return "AUX_DARK"
    led = str(entry.get("led", "")).strip()
    if led == "3" and np.isfinite(duration) and duration >= LOW_FLUX_FLAT_MIN_S:
        return "AUX_LED3LOWFLUX"
    return f"AUX_LED{led}FLAT"


def _assign_aux_keys(entries):
    """Key the aux activities by content, ranked in (observation, exposure) order.

    Each key base (``aux_key_base``) is numbered from 1 in sequence order, so
    partial data still gets contiguous numbering (3 of 4 exposures present
    keys 1..3, not a gap), and a base that recurs in two observations (the two
    persistence darks of decon3) numbers straight through. Mutates each entry's
    ``key`` in place and returns them in sequence order. A pure function, so
    :func:`self_test` can cover it without a MAST query.
    """
    ordered, counts = [], {}
    for entry in sorted(entries, key=lambda e: (e["observation"], e["exposure"])):
        base = aux_key_base(entry)
        counts[base] = counts.get(base, 0) + 1
        entry["key"] = f"{base}{counts[base]}"
        ordered.append(entry)
    return ordered


# ---------------------------------------------------------------------------
# Sequence signatures: which variant of the RCS sequence a pass ran
# ---------------------------------------------------------------------------

def sequence_signature(rows):
    """A pass's sequence layout as a short string, from its L1 survey rows.

    ``rows`` are ``rcs_mast.survey_rows`` records for one pass at L1 (every
    exposure is at L1; darks never reach L2). One token per observation, in
    order: ``<obs>:<D|F><led>x<n>@<s>``, a dark (``D``) or a flat (``F`` and its
    LED), ``n`` exposures, each ``s`` seconds long rounded to 10 s. For example
    ``1:Dx1@180 2:F1x1@40 ... 7:F6x1@40`` is the CAR-190 sequence. Two passes
    with the same string ran the same sequence; the registry of known ones is
    ``rcs_trend_config.SEQUENCE_VARIANTS``.
    """
    import pandas as pd

    frame = pd.DataFrame(rows)
    if not len(frame):
        return ""
    tokens = []
    for observation, group in frame.groupby("observation"):
        exposures = group.groupby("exposure").agg(
            led=("led", "first"), start=("start_time", "min"),
            end=("end_time", "max"))
        # MAST gives some times with fractional seconds and some without, in
        # one listing; a single inferred format refuses the rest.
        seconds = (pd.to_datetime(exposures["end"], format="ISO8601",
                                  errors="coerce")
                   - pd.to_datetime(exposures["start"], format="ISO8601",
                                    errors="coerce")).dt.total_seconds()
        rounded = int(10 * round(float(seconds.median()) / 10)) \
            if seconds.notna().any() else 0
        leds = sorted({str(v) for v in exposures["led"]})
        kind = ("D" if all(is_dark(v) for v in leds)
                else "F" + "".join(v for v in leds if not is_dark(v)))
        tokens.append(f"{int(observation)}:{kind}x{len(exposures)}@{rounded}")
    return " ".join(tokens)


def _parse_tokens(signature):
    """``"9:Dx4@40 10:F3x5@70"`` -> ``[(9, "D", 4, 40), (10, "F3", 5, 70)]``."""
    out = []
    for token in str(signature or "").split():
        match = re.match(r"^(\d+):([DF]\d*)x(\d+)@(\d+)$", token)
        if not match:
            return None
        out.append((int(match.group(1)), match.group(2), int(match.group(3)),
                    int(match.group(4))))
    return out


def _is_partial_of(tokens, full):
    """True if ``tokens`` is ``full`` with the tail not yet indexed.

    Every observation present matches ``full`` in order; the last one present
    may have fewer exposures; and ``full`` has more. That is what a pass looks
    like while MAST is still indexing it: the aux observations arrive at L1
    after the core, and the last one can be part-way in.
    """
    if not tokens or len(tokens) > len(full) or tokens == full:
        return False
    for i, (got, want) in enumerate(zip(tokens, full)):
        if got == want:
            continue
        last = i == len(tokens) - 1
        if not (last and got[0] == want[0] and got[1] == want[1]
                and got[3] == want[3] and got[2] < want[2]):
            return False
    return True


def match_sequence(signature, variants, program=None):
    """``("exact", name)``, ``("partial", [names])`` or ``("unknown", None)``.

    A variant applies only to the programs it lists (``"programs"``), so a
    CAR-216 pass whose aux observations are not indexed yet -- the CAR-190
    layout to the letter -- is not mistaken for CAR-190. A signature that is a
    known layout with its tail missing is ``partial``, with every candidate:
    the variant cannot be named until the pass is fully at L1.
    """
    eligible = {name: entry for name, entry in variants.items()
                if program is None or program in entry.get("programs", (program,))}
    for name, entry in eligible.items():
        if entry["signature"] == signature:
            return "exact", name
    tokens = _parse_tokens(signature)
    if tokens:
        partial = [name for name, entry in eligible.items()
                   if _is_partial_of(tokens, _parse_tokens(entry["signature"]))]
        if partial:
            return "partial", sorted(partial)
    return "unknown", None


def classify_sequence(signature, variants, program=None):
    """The registered variant name for ``signature``, or ``None`` if not exact."""
    kind, name = match_sequence(signature, variants, program)
    return name if kind == "exact" else None


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------

def describe(activities, table=None):
    """Print the run plan: one line per activity."""
    print(f"  {'act':>3s} {'key':5s} {'staging_id':19s} {'exp':>4s} "
          f"{'led':>6s} {'nsca':>4s}  start")
    for entry in activities:
        note = "  <- blank (no L2); not subtracted" \
            if entry.get("dark_blank") else ""
        # is_dark rather than truthiness: MAST's 'led' column carries the
        # literal string "None" for the dark, which is truthy, so `or 'DRK'`
        # printed "None" here. is_dark already lowercases it against
        # DARK_LED_VALUES, which is the same test used to order the activities.
        led = "DRK" if entry["is_dark"] else _as_str(entry["led"])
        print(f"  {entry['activity_number']:3d} {entry['key']:5s} "
              f"{entry['staging_id']:19s} {entry['exposure']:4d} "
              f"{led:>6s} "
              f"{len(entry['frames']):4d}  {entry['start_time']}{note}")
    # Only the activities that are meant to have frames; a blank dark has none
    # by construction and would otherwise make all 18 look absent.
    with_frames = [e for e in activities if not e.get("dark_blank")]
    missing = sorted(set(range(1, 19))
                     - {s for e in with_frames for s in e["frames"]})
    if missing:
        print(f"  SCAs absent from every activity: {missing} (they stay NaN)")


# ---------------------------------------------------------------------------
# Self test
# ---------------------------------------------------------------------------

def self_test(verbose=True):
    """Identifier, label, grouping and aux-key logic on synthetic inputs.

    No credentials, no network, no flight data. Returns the synthetic shared-id
    list so ``process_rcs_trending.self_test`` can reuse it for the compiler
    glob check.
    """
    def say(text):
        if verbose:
            print(text)

    say("== identifiers ==")
    # The two real ids on record: TVAC activity 1, and the roman-docs example.
    tvac = "0077501056054001001"
    docs = "0012301008002013005"
    assert visit_identifier({"program": 123, "execution_plan": 1, "pass": 8,
                             "segment": 2, "observation": 13,
                             "visit": 5}) == docs
    assert visit_identifier({"program": 123, "execution_plan": 1}) == ""
    say(f"  visit_identifier composes {docs} from its six fields")

    name = f"r{docs}_0005_wfi06_f184_cal.asdf"
    match = PRODUCT_NAME_RE.match(name)
    assert match and match.group("visit") == docs
    assert int(match.group("exposure")) == 5 and int(match.group("sca")) == 6
    say(f"  product name regex parses {name}")

    assert _exposure_from_file_set(f"r{docs}_0007_wfi01_dark") == 7
    assert _exposure_from_file_set("") is None
    say("  exposure identifier recovered from a fileSetName")

    # Distinct-observation case (TVAC-like): true ids kept as-is.
    distinct = [{"visit_id": tvac[:16] + f"{n:03d}", "exposure": 1}
                for n in range(1, 8)]
    assign_staging_ids(distinct)
    assert not any(e["id_synthetic"] for e in distinct)
    assert [e["staging_id"] for e in distinct] == [e["visit_id"] for e in distinct]
    say("  distinct-observation ids pass through unchanged")

    # Exposures-within-one-visit case: the silent-failure setup. Must synthesize.
    shared = [{"visit_id": docs, "exposure": n} for n in range(1, 8)]
    assign_staging_ids(shared)
    ids = [e["staging_id"] for e in shared]
    assert all(e["id_synthetic"] for e in shared)
    assert len(set(ids)) == 7 and all(len(i) == 19 and i.isdigit() for i in ids)
    assert ids[0] == docs[:15] + "0001"
    say(f"  shared-visit ids synthesized uniquely: {ids[0]} .. {ids[-1]}")

    # Mixed case (CAR-216): seven distinct-observation activities, each with
    # exposure 1, alongside one observation's four exposures sharing a visit
    # id. A run-wide synthetic flag would overwrite the observation digit
    # that distinguishes the seven from each other, collapsing them onto one
    # staging id -- seen on a real CAR-216 run.
    mixed_core = [{"visit_id": tvac[:16] + f"{n:03d}", "exposure": 1}
                  for n in range(1, 8)]
    mixed_aux = [{"visit_id": tvac[:16] + "009", "exposure": n}
                 for n in range(1, 5)]
    mixed = mixed_core + mixed_aux
    assign_staging_ids(mixed)
    assert not any(e["id_synthetic"] for e in mixed_core)
    assert all(e["id_synthetic"] for e in mixed_aux)
    mixed_ids = [e["staging_id"] for e in mixed]
    assert len(set(mixed_ids)) == len(mixed_ids)
    say("  mixed distinct/shared visits in one run stay unique")

    for broken in ([{"visit_id": "123", "exposure": 1}],
                   [{"visit_id": "", "exposure": 1}]):
        try:
            assign_staging_ids(broken)
        except ValueError:
            pass
        else:
            raise AssertionError(f"malformed id {broken} was accepted")
    say("  malformed ids rejected")

    say("== run label ==")
    labelled = [dict(entry, start_time="2027-03-14T06:07:40.714",
                     id_synthetic=False) for entry in shared]
    for entry in labelled:
        entry["staging_id"] = docs
    assert run_label(labelled, program=123) == "CAR190_00123_01_008_002_20270314"
    say(f"  {run_label(labelled, program=123)}")

    say("== dark identification ==")
    assert is_dark("") and is_dark("NONE") and is_dark("0") and is_dark(None)
    assert not is_dark("5") and not is_dark("LED3")
    say("  DARK_LED_VALUES covers the plausible dark representations")

    say("== pass isolation ==")
    one_pass = [{"visit_id": f"010390100800201300{n}"} for n in range(1, 8)]
    assert assert_single_pass(one_pass) == "008"
    mixed_passes = one_pass[:4] + [{"visit_id": f"010390100900201300{n}"}
                                   for n in range(5, 8)]
    try:
        assert_single_pass(mixed_passes)
    except ValueError as error:
        assert "span 2 passes" in str(error), error
    else:
        raise AssertionError("a run mixing two passes was not caught")
    say("  single pass accepted, mixed passes rejected")

    say("== execution-plan isolation ==")
    plan_a = [{"visit_id": f"010630200800201300{n}"} for n in range(1, 8)]
    assert assert_single_execution_plan(plan_a) == "02"
    mixed_plans = plan_a[:4] + [{"visit_id": f"010630300800201300{n}"}
                                for n in range(5, 8)]
    try:
        assert_single_execution_plan(mixed_plans)
    except ValueError as error:
        assert "execution plans" in str(error), error
    else:
        raise AssertionError("a run mixing two execution plans was not caught")
    say("  single execution plan accepted, mixed plans rejected")

    say("== CAR-216 run label and aux activities ==")
    labelled_216 = [dict(entry, start_time="2027-03-14T06:07:40.714",
                         id_synthetic=False) for entry in shared]
    for entry in labelled_216:
        entry["staging_id"] = docs
    assert (run_label(labelled_216, program=1063)
            == "CAR216_01063_01_008_002_20270314")
    say(f"  {run_label(labelled_216, program=1063)}")

    aux_dark_id = visit_identifier({"program": 1063, "execution_plan": 2,
                                    "pass": 8, "segment": 2, "observation": 8,
                                    "visit": 1})
    aux_flat_id = visit_identifier({"program": 1063, "execution_plan": 2,
                                    "pass": 8, "segment": 2, "observation": 9,
                                    "visit": 1})
    aux_entries = (
        [{"observation": 8, "exposure": n, "visit_id": aux_dark_id,
          "led": "None", "is_dark": True, "exposure_time": 41.1}
         for n in range(1, 5)]
        + [{"observation": 9, "exposure": n, "visit_id": aux_flat_id,
            "led": "3", "is_dark": False, "exposure_time": 41.1}
           for n in range(1, 5)])
    keyed = _assign_aux_keys(aux_entries)
    assert [e["key"] for e in keyed] == (
        [f"AUX_DARK{n}" for n in range(1, 5)]
        + [f"AUX_LED3FLAT{n}" for n in range(1, 5)])
    say("  aux activities keyed AUX_DARK1..4, AUX_LED3FLAT1..4")

    partial = [{"observation": 8, "exposure": n, "visit_id": aux_dark_id,
                "led": "None", "is_dark": True, "exposure_time": 41.1}
               for n in (2, 4)]
    assert [e["key"] for e in _assign_aux_keys(partial)] == \
        ["AUX_DARK1", "AUX_DARK2"]
    say("  partial aux data still keys contiguously, not with a gap")

    # The decon3 CAR-216 layout (plan 6 on): the aux observations renumber, and
    # are keyed by content, so the 41 s band-3 flats keep their old name.
    def ex(obs, n, led, seconds):
        return {"observation": obs, "exposure": n, "visit_id": aux_flat_id,
                "led": led, "is_dark": is_dark(led), "exposure_time": seconds}
    decon3 = ([ex(8, 1, "None", 177.0)] + [ex(9, n, "None", 41.1)
                                           for n in range(1, 5)]
              + [ex(10, n, "3", 66.2) for n in range(1, 6)]
              + [ex(11, n, "3", 41.1) for n in range(1, 5)]
              + [ex(12, 1, "None", 177.0)])
    assert [e["key"] for e in _assign_aux_keys(decon3)] == (
        ["AUX_PERSISTDARK1"] + [f"AUX_DARK{n}" for n in range(1, 5)]
        + [f"AUX_LED3LOWFLUX{n}" for n in range(1, 6)]
        + [f"AUX_LED3FLAT{n}" for n in range(1, 5)] + ["AUX_PERSISTDARK2"])
    say("  decon3 aux layout keyed by content: AUX_PERSISTDARK1..2, "
        "AUX_DARK1..4, AUX_LED3LOWFLUX1..5, AUX_LED3FLAT1..4")
    assert CORE_OBSERVATIONS == set(range(1, 8))

    # Signatures: one token per observation, darks and flats, rounded lengths.
    def row(obs, exp, led, t0, seconds):
        start = np.datetime64("2026-10-20T20:00:00") + np.timedelta64(t0, "s")
        return {"observation": obs, "exposure": exp, "led": led,
                "start_time": str(start),
                "end_time": str(start + np.timedelta64(seconds, "s"))}
    rows = ([row(1, 1, "None", 0, 180)]
            + [row(o, 1, str(o - 1), 200 + 60 * o, 44) for o in range(2, 8)]
            + [row(10, n, "3", 900 + 90 * n, 70) for n in range(1, 6)])
    rows[3]["end_time"] = rows[3]["end_time"].split(".")[0]   # no fraction
    rows[4]["start_time"] = rows[4]["start_time"] + ".5000000"
    signature = sequence_signature(rows)
    assert signature == ("1:Dx1@180 2:F1x1@40 3:F2x1@40 4:F3x1@40 5:F4x1@40 "
                         "6:F5x1@40 7:F6x1@40 10:F3x5@70"), signature
    assert classify_sequence(signature, {"x": {"signature": signature}}) == "x"
    core = " ".join(signature.split()[:7])
    registry = {"car190": {"signature": core, "programs": (1039,)},
                "car216": {"signature": core + " 8:Dx4@40 9:F3x4@40",
                           "programs": (1063,)}}
    assert match_sequence(core, registry, 1039) == ("exact", "car190")
    assert match_sequence(core, registry, 1063) == ("partial", ["car216"])
    assert match_sequence(core + " 8:Dx2@40", registry, 1063) == \
        ("partial", ["car216"])
    assert match_sequence(core + " 8:Dx4@40 9:F3x4@40", registry, 1063) == \
        ("exact", "car216")
    assert match_sequence(core + " 8:Dx5@40", registry, 1063) == ("unknown", None)
    say("  a CAR-216 pass still indexing is partial, never CAR-190; a layout "
        "past any registered one is unknown")
    assert classify_sequence("1:Dx1@180", {"x": {"signature": signature}}) is None
    say("  sequence signatures name each observation's darks/flats, count and "
        "length")

    return ids


if __name__ == "__main__":
    print("rcs_activities self test")
    self_test()
    print("all checks passed")
