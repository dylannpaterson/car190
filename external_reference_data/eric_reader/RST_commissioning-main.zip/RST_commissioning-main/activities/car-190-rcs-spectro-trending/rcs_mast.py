"""Everything that talks to MAST: connection, product listing, streaming.

Split out of ``process_rcs_trending.py`` so the identity bookkeeping
(:mod:`rcs_activities`) stays importable without astroquery or credentials.
This module is the *only* one that imports astroquery, and it does so inside
:func:`connect` -- importing this module costs nothing and needs no token, so
``--self-test`` can still exercise the retry logic here against a fake handle.

Three queries, deliberately separate:

* :func:`_query_products` -- the main L2 query, reduced to ``_cal`` products.
  This is the one that overloads: ``get_unique_product_list`` fetches each
  dataset's listing in its own request, and under load the merged table comes
  back missing the ``filename`` column. See
  :func:`_get_unique_product_list_retrying`.
* :func:`_survey_rows` / :func:`survey_passes` -- the L1+L2 inventory that
  ``--pass`` is chosen from.
* :func:`find_l1_dark` -- metadata only, for ``--blank-dark``.

Presigned S3 URLs and why the cached plan holds names
-----------------------------------------------------

Streaming an L2 product does go through a presigned S3 URL with a short
time-to-live, so a naive "query everything now, fetch it later" design would
break. It does not break here, and the reason is worth stating because it is
what sets the safe batch size. Measured against the live archive on
2026-10-03:

* ``MastMissions.read_product(name)`` first builds a *stable* service URL,
  ``.../roman/api/v0.1/retrieve_product?product_name=<name>``. Nothing in it
  expires.
* That endpoint answers ``307`` with the presigned S3 URL in ``Location``, and
  astroquery passes it straight to ``fsspec``/``asdf``. The signature carries
  ``X-Amz-Expires=300`` -- **a five-minute TTL, minted per file at read time,
  not at query time.**
* One SCA takes ~5.5 s end to end (~3 s for the redirect plus ``asdf.open``,
  ~2.3 s to pull the 4088x4088 array and apply DQ), so a single read spends
  under 2% of its own signature's life. Headroom is a factor of ~50.

Two consequences, in the order they matter:

1. **A cached query plan stores product names, so it never expires.** This is
   what makes :func:`plan_pass` / ``--use-plan`` safe, and it is why
   :class:`QueryPlan` records names rather than the URLs a plan-then-fetch
   design would be tempted to keep. A plan may be reused days later. The only
   thing that ages in a plan is its *coverage* -- a plan built while MAST had
   indexed 6 of 18 SCAs stays a 6-SCA plan forever -- and that is caught by
   :func:`check_plan_coverage` rather than by an age limit, since a plan that
   is complete cannot become less so.
2. **The TTL bounds how long one file may be held open, not how many are
   planned.** ``asdf.open`` reads lazily through the handle opened against one
   signed URL, so the exposure is the interval from ``read_product`` to the
   last array access. ``process_rcs_trending.stage_run`` closes each
   ``AsdfFile`` in a ``finally`` before touching the next, which keeps that
   interval at ~5.5 s. Anything that collects open products and reads them
   afterwards -- batching reads, or holding 18 handles to parallelise -- would
   push past 300 s and fail mid-array. The retry in :func:`stream_product` is
   partly a signature-expiry retry for exactly this reason, which is why its
   documented symptom is a ``403`` *during* streaming.

So batch size is limited by the listing API (finding 2 in the plan: one
listing request per matched dataset, degrading to a table with no ``filename``
column under load), not by URL expiry. That is what :func:`query_lease` and
the backoff in :func:`_get_unique_product_list_retrying` address.
"""
import contextlib
import glob
import itertools
import json
import os
import random
import re
import socket
import tempfile
import time

import numpy as np
import pandas as pd

import rcs_edp
import rcs_fsutil
import rcs_trend_config as cfg
from rcs_activities import (CORE_OBSERVATIONS, DEFAULT_PROGRAM,
                           EXPECTED_EXPOSURES, N_ACTIVITIES, _as_int, _as_str,
                           _exposure_from_file_set, group_activities, is_dark,
                           run_label, sequence_signature, visit_identifier)

# Columns we would like from the MAST query. The schema is still settling, so
# _query_products degrades to MINIMAL_COLS if the service rejects any of these
# rather than failing the run.
# There is deliberately no "exposure" here: the Roman mission interface has no
# such column (it warns "Column 'exposure' not found. Did you mean
# exposure_type?" and drops it), and the Exposure Identifier is only available
# from the 4 digits after the visit id in fileSetName -- see
# rcs_activities._exposure_from_file_set. Every other name below is honoured.
SELECT_COLS = [
    "program", "execution_plan", "pass", "segment", "observation", "visit",
    "detector", "optical_element", "exposure_type", "led",
    "exposure_time", "exposure_start_time", "exposure_end_time",
    "instrument_name", "productLevel", "product_type", "fileSetName",
]
MINIMAL_COLS = [
    "program", "execution_plan", "pass", "segment", "visit", "observation",
    "optical_element", "exposure_type", "instrument_name", "detector",
    "productLevel", "product_type", "exposure_time", "exposure_start_time",
    "exposure_end_time", "fileSetName",
]

# Columns the L1/L2 survey asks for. Narrower than SELECT_COLS: the survey only
# counts detectors per exposure and needs no product-level columns.
SURVEY_COLS = ["program", "execution_plan", "pass", "segment", "observation",
               "visit", "detector", "exposure_type", "led",
               "exposure_start_time", "exposure_end_time", "productLevel",
               "fileSetName"]

# MastMissions.query_criteria caps a single response at 5000 rows and announces
# it only through a MaxResultsWarning, which is invisible in a log that filters
# warnings. A whole-program survey is well past that cap -- CAR-190 is 7
# exposures x 18 detectors = 126 files per pass, so ~40 passes fills it -- and a
# truncated survey does not look broken: it looks like a program with fewer
# passes. Measured 2026-10-03: an unpaginated survey of program 1039 returned
# exactly 5000 rows at each level and reported CAR-190 as ending at pass 48.
# So _survey_rows pages with explicit offsets and verifies the total itself.
SURVEY_PAGE = 5000
SURVEY_MAX_PAGES = 40   # 200k rows; a survey past this is a query bug, not data


def connect(token=None):
    """Authenticated ``MastMissions`` handle for Roman.

    The token is the same one ``rcs_edp`` uses, so a single ``variables.env``
    covers both halves of the pipeline. astroquery is imported here rather than
    at module scope so that importing this module -- which the self-test does --
    neither requires the fork to be installed nor touches credentials.
    """
    from astroquery.mast import MastMissions

    missions = MastMissions(mission="roman")
    missions.login(token=rcs_edp.edp_token() if token is None else token)

    return missions


def _backoff_delay(attempt, base=cfg.QUERY_BACKOFF_BASE,
                   cap=cfg.QUERY_BACKOFF_CAP, rng=random):
    """``base * 2**attempt``, jittered by U(0.5, 1.5) and capped.

    Jitter is the point, not politeness. Batch ranks start within seconds of
    each other and hit the same listing endpoint, so with a fixed backoff every
    rank that fails retries in the same instant and reproduces the overload
    that caused the failure. The cap is applied *before* the jitter so the
    longest possible wait is ``1.5 * cap``, which keeps a 6-attempt ladder
    inside a few minutes rather than an unbounded one.
    """
    return min(base * 2 ** attempt, cap) * rng.uniform(0.5, 1.5)


def _get_unique_product_list_retrying(missions, results, search,
                                      retries=cfg.QUERY_RETRIES,
                                      base=cfg.QUERY_BACKOFF_BASE,
                                      cap=cfg.QUERY_BACKOFF_CAP, sleep=time.sleep):
    """``missions.get_unique_product_list(results)``, retrying a transient
    astroquery-side ``KeyError: 'filename'`` with exponential backoff.

    Seen intermittently on real batch runs, some passes affected and others
    not: ``get_unique_product_list`` fetches each dataset's product listing
    in a separate request and merges them, and when at least one dataset in
    the batch has no per-SCA files indexed yet, even though the dataset
    itself already matched the ``query_criteria`` search above, the merged
    table comes back without the 'filename' column ``remove_duplicate_products``
    expects, which is an unhandled ``KeyError`` inside astroquery rather
    than a clean "not ready" signal. 46 of these appear in
    ``batch/status/*.failed`` from the 32-way run.

    Two things distinguish this from the previous three-flat-waits version.

    **The ladder is exponential and jittered** (:func:`_backoff_delay`), which
    is what gives a contended listing endpoint time to drain instead of
    hammering it at a fixed interval from every rank at once.

    **Only the missing-column failure is retried.** A ``KeyError`` naming
    anything other than a column astroquery was looking for is a real bug and
    is re-raised immediately -- retrying it six times with backoff would turn a
    one-line traceback into a four-minute one and still fail. "Query matched
    nothing" never reaches here at all: :func:`_query_products` checks
    ``len(results) == 0`` first and raises, because a run that has not been
    archived yet is a reason to come back later, not to retry in a loop.
    """
    retryable = {"filename", "productFilename", "fileName", "product_name"}
    for attempt in range(retries + 1):
        try:
            return missions.get_unique_product_list(results)
        except KeyError as error:
            column = error.args[0] if error.args else None
            if column not in retryable:
                raise
            if attempt == retries:
                raise ValueError(
                    f"MAST's per-dataset product listing for {search} came "
                    f"back without a {error} column after {retries + 1} "
                    f"attempt(s) with backoff. This has been seen when at "
                    f"least one exposure's per-SCA files are not yet indexed "
                    f"even though the exposure itself matched the query, and "
                    f"also under listing-API load -- usually transient, retry "
                    f"later, and consider fewer concurrent ranks or a lower "
                    f"--query-leases.") from error
            delay = _backoff_delay(attempt, base=base, cap=cap)
            print(f"  get_unique_product_list raised {error!r}; retrying in "
                  f"{delay:.0f}s ({attempt + 1}/{retries})")
            sleep(delay)


@contextlib.contextmanager
def query_lease(lease_root, n_leases=cfg.QUERY_LEASES,
                timeout=cfg.QUERY_LEASE_TIMEOUT, poll=5.0,
                label="", sleep=time.sleep):
    """Hold one of ``n_leases`` slots for the duration of a listing call.

    A lock *directory* rather than a lock file, because ``os.mkdir`` is atomic
    on POSIX and on the shared filesystem the batch ranks already write their
    staging to -- no lock daemon, no extra dependency, and it works across
    nodes, which a ``multiprocessing`` semaphore would not.

    This leases the **listing** call only. Streaming deliberately stays fully
    parallel: the measurements in the module docstring put one SCA at ~5.5 s of
    mostly-S3 transfer, which is not the resource that fell over. Serialising
    the pull to fix a listing problem would cost hours per fan-out and fix
    nothing.

    A rank that dies holding a lease must not block the fan-out forever, so
    each lease records its holder and start time and any lease older than
    ``timeout`` is stolen with a warning. ``timeout`` therefore has to exceed
    the slowest legitimate listing call by a wide margin; the default 900 s
    against observed single-digit seconds is that margin. Stealing is logged
    rather than silent precisely because the alternative reading -- a listing
    call that really did take 15 minutes -- is something worth knowing.
    """
    os.makedirs(lease_root, exist_ok=True)
    held = None
    waited = 0.0
    while held is None:
        for slot in range(n_leases):
            path = os.path.join(lease_root, f"lease{slot:02d}")
            try:
                os.mkdir(path)
            except FileExistsError:
                # Taken, unless its holder is gone. mtime of the marker file,
                # not of the directory, since we only ever write the marker.
                marker = os.path.join(path, "holder")
                try:
                    age = time.time() - os.path.getmtime(marker)
                except OSError:
                    # Mid-acquisition by someone else; leave it alone.
                    continue
                if age <= timeout:
                    continue
                try:
                    with open(marker) as handle:
                        stale = handle.read().strip()
                except OSError:
                    stale = "unknown"
                print(f"  WARNING: stealing query lease {slot} held {age:.0f}s "
                      f"(> {timeout:.0f}s) by {stale}; assuming that rank died. "
                      f"If it is in fact alive and listing, raise "
                      f"--query-lease-timeout.")
            with open(os.path.join(path, "holder"), "w") as handle:
                handle.write(f"{socket.gethostname()} pid={os.getpid()} "
                             f"{label} {time.strftime('%Y-%m-%dT%H:%M:%S')}")
            held = path
            break
        if held is None:
            sleep(poll)
            waited += poll
    if waited:
        print(f"  waited {waited:.0f}s for one of {n_leases} query lease(s)")
    try:
        yield held
    finally:
        try:
            os.remove(os.path.join(held, "holder"))
        except OSError:
            pass
        try:
            os.rmdir(held)
        except OSError:
            pass


def _query_products(missions, search):
    """Query, then reduce to a unique list of ``_cal`` product rows.

    Retries once with ``MINIMAL_COLS`` because ``select_cols`` naming is still
    settling on the Roman mission interface and an unknown column name fails the
    whole query. Losing the extra columns costs only cross-checks -- the
    filename carries the identifiers we actually need.
    """
    for columns in (SELECT_COLS, MINIMAL_COLS):
        try:
            results = missions.query_criteria(select_cols=columns, **search)
        except Exception as error:                # noqa: BLE001 - service-side
            if columns is MINIMAL_COLS:
                raise
            print(f"  query with full column list failed ({error});"
                  " retrying with the minimal set")
            continue
        break

    if len(results) == 0:
        raise ValueError(f"no products matched {search}")
    print(f"  query matched {len(results)} rows")

    products = _get_unique_product_list_retrying(missions, results, search)
    products = missions.filter_products(products, file_suffix="_cal")
    if len(products) == 0:
        raise ValueError(f"query matched {len(results)} rows but none had a "
                         f"'_cal' product; check productLevel/product_type")
    print(f"  filtered to {len(products)} _cal products")

    return results, products


def _survey_rows(missions, search, level, page=SURVEY_PAGE,
                 max_pages=SURVEY_MAX_PAGES):
    """One row per archived file for ``search`` at ``productLevel=level``.

    Deliberately its own query rather than a filter over the main one: the main
    query is pinned to L2 and reduced to ``_cal`` products, and the survey needs
    the L1 side precisely because that is where a run first becomes visible.
    Returns an empty frame rather than raising, so a survey of a pass that does
    not exist yet reads as "nothing here" instead of failing the run.

    **Paged, and that is not optional.** A single ``query_criteria`` response is
    capped at ``SURVEY_PAGE`` rows and the cap is reported only as a
    ``MaxResultsWarning``. A whole-program survey exceeds it, and the truncated
    result is indistinguishable from a shorter program -- which is exactly the
    way a survey can be wrong without looking wrong. So pages are requested
    with explicit offsets until one comes back short, and a partial page is the
    only accepted stop condition: running out of ``max_pages`` raises rather
    than returning what has been collected so far.
    """
    query = {key: value for key, value in search.items()
             if key != "productLevel"}
    query["productLevel"] = level

    tables, offset = [], 0
    for _ in range(max_pages):
        try:
            chunk = missions.query_criteria(select_cols=SURVEY_COLS,
                                            limit=page, offset=offset, **query)
        except Exception as error:                # noqa: BLE001 - service-side
            print(f"  WARNING: L{level} survey query failed ({error}); "
                  f"treating L{level} as unknown")

            return pd.DataFrame()
        tables.append(chunk)
        if len(chunk) < page:
            break
        offset += page
    else:
        raise RuntimeError(
            f"L{level} survey of {query} returned {max_pages} full pages of "
            f"{page} rows without a short page. Refusing to return a possibly "
            f"truncated survey, since a truncated survey reads as a shorter "
            f"program rather than as an error.")

    rows = []
    for row in itertools.chain.from_iterable(tables):
        fields = {name: row[name] for name in row.colnames}
        file_set = _as_str(fields.get("fileSetName"))
        visit_id = visit_identifier(fields)
        if not visit_id:
            match = re.search(r"(\d{19})", file_set)
            visit_id = match.group(1) if match else ""
        exposure = _exposure_from_file_set(file_set)
        if exposure is None:
            # Nothing downstream can key off a row with no exposure number, and
            # silently keeping it would make the L1/L2 counts wrong.
            print(f"  WARNING: survey skipping {file_set!r}: no exposure "
                  f"identifier in the fileSetName")
            continue
        rows.append({
            "level": level,
            "execution_plan": _as_int(fields.get("execution_plan")),
            "pass": _as_int(fields.get("pass")),
            "observation": _as_int(fields.get("observation")),
            "visit_id": visit_id,
            "exposure": exposure,
            "detector": _as_str(fields.get("detector")),
            "exposure_type": _as_str(fields.get("exposure_type")),
            "led": _as_str(fields.get("led")),
            "start_time": _as_str(fields.get("exposure_start_time")),
            "end_time": _as_str(fields.get("exposure_end_time")),
        })

    return pd.DataFrame(rows)


def survey_rows(missions, search, level):
    """Public name for the paged L1/L2 survey frame.

    ``survey_passes`` prints an inventory; this returns the frame so a caller
    can compute over it -- ``batch/make_manifest.py --from-survey`` derives the
    manifest's (plan, pass) rows from it. Exposed deliberately rather than
    leaving that an underscore-prefixed cross-module call, which would break
    silently on a rename.
    """
    return _survey_rows(missions, search, level)


def survey_passes(missions, search):
    """Print a per-(execution_plan, pass), per-observation inventory of L1/L2.

    This is what ``--pass`` is chosen from, and the reason it is required.
    CAR-190 and CAR-216 repeat, and consecutive passes reuse the same
    observation numbers -- only the ``pass`` field of the 19-digit Visit
    Identifier tells them apart. CAR-216 additionally repeats its whole
    sequence across execution plans 2 and 3, whose pass numbers also start
    over, so the inventory is keyed by ``(execution_plan, pass)`` rather than
    pass alone. An unpinned query therefore returns two interleaved runs, and
    nothing downstream would notice: ``rcs_activities.assign_staging_ids`` sees
    distinct ids and stays quiet, ``group_activities`` finds more than the
    expected lit activities only if both runs are complete, and
    ``rcs_telemetry.build_telemetry_table`` windows the EDP from the earliest
    start to the latest end -- hours instead of the ~15 minutes an actual run
    spans, so every housekeeping median would be taken over both runs plus the
    gap between them.

    Returns the combined survey frame; callers use it only for the printout.
    """
    frames = [_survey_rows(missions, search, level) for level in (1, 2)]
    survey = pd.concat([f for f in frames if len(f)], ignore_index=True) \
        if any(len(f) for f in frames) else pd.DataFrame()
    if not len(survey):
        print("  survey: no products found at either level for this query")

        return survey

    expected = EXPECTED_EXPOSURES.get(search.get("program", DEFAULT_PROGRAM),
                                      N_ACTIVITIES)

    print("\n----- per-(plan, pass) inventory (L1 = ingested, L2 = calibrated) -----")
    print(f"  {'plan':>4s} {'pass':>4s} {'obs':>3s} {'exp':>4s} "
          f"{'exposure_type':14s} {'led':>5s} {'L1':>3s} {'L2':>3s}  start")
    combos = sorted({(ep, p) for ep, p in
                     zip(survey["execution_plan"], survey["pass"])
                     if pd.notna(p)},
                    key=lambda c: (c[0] is None, c[0], c[1]))
    for execution_plan, pass_number in combos:
        in_pass = survey[(survey["execution_plan"] == execution_plan)
                         & (survey["pass"] == pass_number)]
        keys = sorted({(row.observation, row.exposure)
                       for row in in_pass.itertuples()},
                      key=lambda k: (k[0] is None, k[0], k[1]))
        n_complete = 0
        for observation, exposure in keys:
            same = in_pass[(in_pass["observation"] == observation)
                           & (in_pass["exposure"] == exposure)]
            n_l1 = same[same["level"] == 1]["detector"].nunique()
            n_l2 = same[same["level"] == 2]["detector"].nunique()
            first = same.iloc[0]
            flag = "" if n_l2 == 18 else ("  <- L2 incomplete" if n_l2
                                          else "  <- no L2 yet")
            n_complete += n_l2 == 18
            plan_str = f"{execution_plan:4d}" if execution_plan is not None \
                else "   ?"
            print(f"  {plan_str} {int(pass_number):4d} {observation:3d} "
                  f"{exposure:4d} {first['exposure_type'][:14]:14s} "
                  f"{first['led'] or 'DRK':>5s} {n_l1:3d} {n_l2:3d}  "
                  f"{first['start_time']}{flag}")

        starts = sorted(s for s in in_pass["start_time"] if s)
        ends = sorted(e for e in in_pass["end_time"] if e)
        span = f"{starts[0]} .. {ends[-1] if ends else starts[-1]}" \
            if starts else "no times"
        verdict = ("complete" if n_complete == expected
                   else f"{n_complete}/{expected} exposures at L2")
        print(f"       plan {execution_plan} pass {int(pass_number):03d}: "
              f"{len(keys)} exposures, {verdict}\n       span {span}")

    return survey


def pass_l1_rows(missions, search):
    """Every L1 file of the pass ``search`` names: the whole sequence.

    The pass and segment are kept and the level, exposure type and observation
    dropped, so the answer is every exposure the pass ran, darks included
    (they never reach L2). One listing call; :func:`plan_pass` makes it once and
    hands the rows to :func:`find_l1_dark` and to the sequence signature.
    """
    narrowed = {key: value for key, value in search.items()
                if key not in ("productLevel", "exposure_type", "observation")}
    return _survey_rows(missions, narrowed, 1)


def find_l1_dark(missions, search, rows=None):
    """The dark exposure's identity and timing from L1, with no frames.

    For ``--blank-dark``. The dark and the six flats are separate observations
    and reach L2 independently; on the first flight run all six flats were
    calibrated while the dark was still only at L1. The flats carry plenty of
    flux, so the dark is not what limits this measurement, and waiting on it
    holds up the whole trend point.

    What is taken from L1 is *only* metadata -- the 19-digit id, the exposure
    number and the exposure window. No L1 pixels are read: an L1 ramp is not a
    substitute for a calibrated rate image, and quietly differencing one against
    L2 rates would be worse than not subtracting at all. The window is the part
    that matters beyond bookkeeping, because it is what makes row 0 of the
    telemetry CSV a real EDP sample -- including the photodiode reading that the
    compiler unconditionally uses as its baseline (``pd_array -= pd_array[0]``).

    The dark's own ``exposure_type`` and ``observation`` differ from the flats',
    so both are dropped from the search; the pass and segment are kept, which is
    what confines the answer to this run.

    CAR-216 also has obs 8, four aux darks that are just as ``is_dark()``-true
    as the core dark from obs 1 -- this is only ever standing in for the core
    dark that ``group_activities`` puts at row 0, so aux observations are
    excluded here the same way ``group_activities`` splits them off, or this
    would find five dark-like L1 rows instead of one.
    """
    narrowed = {key: value for key, value in search.items()
                if key not in ("productLevel", "exposure_type", "observation")}
    if rows is None:
        rows = pass_l1_rows(missions, search)
    if not len(rows):
        raise ValueError(
            f"--blank-dark: no L1 products at all for {narrowed}, so the dark's "
            f"exposure window cannot be established. Without it row 0 of the "
            f"telemetry CSV has no timestamp to sample the EDP at.")

    dark_rows = rows[rows["led"].map(is_dark)
                     & rows["observation"].isin(CORE_OBSERVATIONS)]
    keys = sorted({(row.visit_id, row.exposure) for row in dark_rows.itertuples()})
    if len(keys) != 1:
        raise ValueError(
            f"--blank-dark: expected exactly one dark exposure at L1 in this "
            f"pass, found {len(keys)} {keys}. Narrow the query (--segment, "
            f"--visit) or check DARK_LED_VALUES against the led values present: "
            f"{sorted(set(rows['led']))}.")

    visit_id, exposure = keys[0]
    same = dark_rows[(dark_rows["visit_id"] == visit_id)
                     & (dark_rows["exposure"] == exposure)]
    first = same.iloc[0]
    print(f"  --blank-dark: L1 dark {visit_id} exp {exposure} "
          f"({same['detector'].nunique()}/18 SCAs at L1), "
          f"{first['start_time']} .. {first['end_time']}")

    return {
        "visit_id": visit_id,
        "exposure": int(exposure),
        # Empty by design, and the flag stage_run keys the NaN mosaic off.
        "frames": {},
        "sizes": {},
        "dark_blank": True,
        "file_set_name": "",
        "start_time": first["start_time"],
        "end_time": first["end_time"],
        "exposure_time": np.nan,
        "led": first["led"],
        "optical_element": "",
        "exposure_type": first["exposure_type"],
        "is_dark": True,
    }


def stream_product(missions, filename, retries=4, backoff=3.0):
    """``read_product`` with retry, returning an open in-memory ``AsdfFile``.

    The streaming example notebook documents a ``ClientResponseError: 403,
    Forbidden`` that is cleared simply by re-issuing the same ``read_product``
    call, attributed to a timeout mid-stream. With ~126 files per run, hitting it
    at least once is likely, so retrying is not optional here.
    """
    for attempt in range(1, retries + 1):
        try:
            return missions.read_product(filename)
        except Exception as error:                # noqa: BLE001 - transport
            if attempt == retries:
                raise
            wait = backoff * attempt
            print(f"      {os.path.basename(filename)}: attempt {attempt} "
                  f"failed ({type(error).__name__}: {error}); retrying in "
                  f"{wait:.0f}s")
            time.sleep(wait)

    raise RuntimeError("unreachable")


# ---------------------------------------------------------------------------
# Query plan cache
# ---------------------------------------------------------------------------

# The activity fields a plan carries. Fixed and explicit rather than "whatever
# the dict happens to hold", so that adding a field to group_activities without
# adding it here is caught by _plan_activity instead of silently vanishing on
# the round trip and reappearing as a KeyError deep inside stage_run.
PLAN_ACTIVITY_FIELDS = (
    "activity_number", "key", "visit_id", "staging_id", "id_synthetic",
    "exposure", "observation", "file_set_name", "led", "is_dark", "is_aux",
    "dark_blank", "optical_element", "exposure_type", "exposure_time",
    "start_time", "end_time", "frames", "sizes",
)


def _jsonable(value):
    """Coerce a MAST-derived scalar into something ``json.dump`` round-trips.

    Two hazards. Numpy scalars out of the astropy table are not JSON types, and
    ``float('nan')`` is written by Python as a bare ``NaN`` token that is not
    valid JSON -- Python's own loader accepts it, so it would work here and fail
    in anything else that reads these plans. NaN becomes ``null`` and is
    restored to ``np.nan`` on read.
    """
    if value is None:
        return None
    if isinstance(value, (np.generic,)):
        value = value.item()
    if isinstance(value, float) and not np.isfinite(value):
        return None
    if isinstance(value, (bool, int, float, str)):
        return value

    return str(value)


def _plan_activity(entry):
    """One activity dict reduced to its persistable fields."""
    unknown = set(entry) - set(PLAN_ACTIVITY_FIELDS) - {"pull_bytes",
                                                        "pull_seconds"}
    if unknown:
        raise KeyError(
            f"activity {entry.get('key')} carries field(s) {sorted(unknown)} "
            f"that a query plan does not persist. Add them to "
            f"PLAN_ACTIVITY_FIELDS, or they will be missing after --use-plan.")
    out = {}
    for field in PLAN_ACTIVITY_FIELDS:
        value = entry.get(field)
        if field in ("frames", "sizes"):
            # JSON object keys are strings; the SCA number is restored to int on
            # read. Left as str here rather than as a list of pairs so the plan
            # stays readable to a human checking coverage by eye.
            out[field] = {str(sca): _jsonable(v) for sca, v in (value or {}).items()}
        else:
            out[field] = _jsonable(value)

    return out


def _unplan_activity(record):
    """Invert :func:`_plan_activity`, restoring int SCA keys and NaN."""
    missing = set(PLAN_ACTIVITY_FIELDS) - set(record)
    if missing:
        raise KeyError(f"query plan activity is missing {sorted(missing)}; "
                       f"it was probably written by an older layout")
    entry = dict(record)
    entry["frames"] = {int(sca): name
                       for sca, name in (record["frames"] or {}).items()}
    entry["sizes"] = {int(sca): int(size)
                      for sca, size in (record["sizes"] or {}).items()}
    # np.nan rather than None: _as_header_float and the exposure-time column
    # both expect a float, and None would propagate as the string "None".
    if entry.get("exposure_time") is None:
        entry["exposure_time"] = np.nan

    return entry


class QueryPlan:
    """A pass's resolved product names, cached so MAST is listed once.

    This is the structural half of the fix for the listing overload. The
    expensive, fragile step is turning a search into per-SCA product names;
    streaming them is just bandwidth. Separating the two means a rerun after a
    transient listing failure, a coverage check, or a second attempt at a pass
    whose download was interrupted all cost **zero** listing calls.

    What is stored is product *names*, never URLs -- see this module's
    docstring for the measurement behind that choice. A plan therefore does not
    expire and is reusable indefinitely. What a plan *is* a snapshot of is
    coverage at the moment it was built, which is why
    :func:`check_plan_coverage` is called on read as well as on write.
    """

    def __init__(self, label, program, search, activities, created=None,
                 decon_cycle=None, blank_dark=False,
                 schema_version=cfg.PLAN_SCHEMA_VERSION, sequence_signature=""):
        self.label = label
        self.program = program
        self.search = dict(search)
        self.activities = list(activities)
        self.created = created or time.strftime("%Y-%m-%dT%H:%M:%S")
        self.decon_cycle = decon_cycle
        self.blank_dark = blank_dark
        self.schema_version = schema_version
        # The pass's L1 layout (rcs_activities.sequence_signature), from the
        # L1 listing planning already makes. Optional in the JSON, so plans
        # written before 2026-10-22 still load; they carry "" until re-planned.
        self.sequence_signature = sequence_signature or ""

    def to_dict(self):
        return {
            "schema_version": self.schema_version,
            "run_label": self.label,
            "program": self.program,
            "decon_cycle": self.decon_cycle,
            "blank_dark": bool(self.blank_dark),
            "created": self.created,
            "search": {key: _jsonable(value)
                       for key, value in self.search.items()},
            "activities": [_plan_activity(entry) for entry in self.activities],
            "sequence_signature": self.sequence_signature,
        }

    @classmethod
    def from_dict(cls, payload):
        version = payload.get("schema_version")
        if version != cfg.PLAN_SCHEMA_VERSION:
            raise ValueError(
                f"query plan schema is {version!r}, expected "
                f"{cfg.PLAN_SCHEMA_VERSION!r}. Re-run --plan-only to rebuild "
                f"it; a plan is cheap and mixing layouts is not.")

        return cls(
            label=payload["run_label"], program=payload["program"],
            search=payload.get("search", {}),
            activities=[_unplan_activity(record)
                        for record in payload["activities"]],
            created=payload.get("created"),
            decon_cycle=payload.get("decon_cycle"),
            blank_dark=payload.get("blank_dark", False),
            schema_version=version,
            sequence_signature=payload.get("sequence_signature", ""))

    # -- counts the CLI and the batch worker report on ------------------------

    @property
    def lit(self):
        """Core lit activities -- the ones a coverage requirement applies to."""
        return [e for e in self.activities
                if not e["is_dark"] and not e.get("is_aux")]

    def coverage(self):
        """``{activity key: n_scas}`` over every activity in the plan."""
        return {e["key"]: len(e["frames"]) for e in self.activities}

    def n_products(self):
        return sum(len(e["frames"]) for e in self.activities)

    def __repr__(self):
        return (f"QueryPlan({self.label!r}, {len(self.activities)} activities, "
                f"{self.n_products()} products)")

    # -- storage --------------------------------------------------------------

    @staticmethod
    def path_for(staging_root, label):
        return os.path.join(staging_root, "plans", f"{label}_plan.json")

    def write(self, staging_root):
        path = self.path_for(staging_root, self.label)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        # Write-then-rename: a rank reading plans while another writes must
        # never see a half-written file, and os.replace is atomic.
        temporary = f"{path}.tmp{os.getpid()}"
        with open(temporary, "w") as handle:
            json.dump(self.to_dict(), handle, indent=2, sort_keys=True)
            handle.write("\n")
        rcs_fsutil.replace(temporary, path)
        print(f"  wrote query plan {path} ({len(self.activities)} activities, "
              f"{self.n_products()} products)")

        return path

    @classmethod
    def read(cls, staging_root, label):
        path = cls.path_for(staging_root, label)
        if not os.path.exists(path):
            raise FileNotFoundError(
                f"--use-plan: no cached plan at {path}. Run --plan-only for "
                f"this pass first; that is the only step that lists MAST.")
        with open(path) as handle:
            plan = cls.from_dict(json.load(handle))
        print(f"  read query plan {path} (built {plan.created}, "
              f"{len(plan.activities)} activities, {plan.n_products()} "
              f"products); no MAST listing call needed")

        return plan

    @classmethod
    def find_for(cls, staging_root, search):
        """The cached plan whose recorded search equals ``search``.

        ``--use-plan`` cannot address a plan by run label, because the label
        (which carries the run's date) is derived from the activities the plan
        contains. Matching on the stored search instead is exact and needs
        nothing the caller does not already have on the command line -- which is
        also what lets ``batch/run_manifest_worker.py`` reuse a plan knowing
        only program, execution plan and pass.
        """
        pattern = os.path.join(staging_root, "plans", "*_plan.json")
        wanted = {key: _jsonable(value) for key, value in search.items()}
        matches = []
        for path in sorted(glob.glob(pattern)):
            try:
                with open(path) as handle:
                    payload = json.load(handle)
            except (OSError, ValueError):
                # A plan being written right now, or a damaged one. The
                # requested plan is either elsewhere or absent; either way this
                # is not the place to fail.
                continue
            if payload.get("search") == wanted:
                matches.append(path)

        if not matches:
            raise FileNotFoundError(
                f"--use-plan: no cached plan under {os.path.dirname(pattern)} "
                f"was built from the search {wanted}. Run --plan-only with the "
                f"same arguments first, or pass --run-label to name a plan "
                f"directly.")
        if len(matches) > 1:
            raise ValueError(
                f"--use-plan: {len(matches)} cached plans share the search "
                f"{wanted}: {[os.path.basename(m) for m in matches]}. Pass "
                f"--run-label to pick one.")

        with open(matches[0]) as handle:
            plan = cls.from_dict(json.load(handle))
        print(f"  read query plan {matches[0]} (built {plan.created}, "
              f"run {plan.label}, {len(plan.activities)} activities, "
              f"{plan.n_products()} products); no MAST listing call needed")

        return plan


def check_plan_coverage(plan, min_scas=cfg.MIN_SCAS):
    """Refuse a plan whose lit activities do not cover ``min_scas`` SCAs.

    The precondition that turns the quiet failure mode into a loud one. A
    listing degraded by load returns *some* products, and without this check
    the pipeline happily streams them, writes a 2-SCA product, and
    ``batch/_already_done`` counts it as finished forever. Checked against the
    plan, before anything is streamed, a short listing costs one cheap query
    instead of a 3.75 GB download and leaves no product behind to block its own
    retry.

    **The dark is exempt, by design and not as a loophole.** The RCS dark
    exposure is not processed to L2 at all -- confirmed across every pass
    surveyed so far -- so it contributes zero products and ``--blank-dark``
    stands in its identity and timing from L1. Requiring 18 SCAs there would
    reject every run that exists. Aux activities (CAR-216 obs 8/9) are exempt
    for the same reason in weaker form: obs 8 is four more darks, and nothing
    downstream treats the aux arrays as a trend point.

    Raises ``ValueError`` listing every short activity; returns the per-activity
    SCA counts when the plan passes.
    """
    short = [(entry["key"], len(entry["frames"])) for entry in plan.lit
             if len(entry["frames"]) < min_scas]
    counts = plan.coverage()
    if short:
        detail = ", ".join(f"{key} {n}/{min_scas}" for key, n in short)
        raise ValueError(
            f"query plan {plan.label} is short on {len(short)} lit "
            f"activit(y/ies): {detail}. Nothing has been streamed. This is the "
            f"signature of a MAST listing degraded by load, or of a pass whose "
            f"per-SCA products are still being indexed -- rebuild the plan with "
            f"--plan-only later, lower the concurrency, or pass "
            f"--min-scas to accept partial coverage deliberately.")
    print(f"  plan coverage: {len(plan.lit)} lit activities, all >= "
          f"{min_scas} SCAs ({sorted(set(counts[e['key']] for e in plan.lit))})")

    return counts


def plan_pass(missions, search, program=DEFAULT_PROGRAM, blank_dark=False,
              label=None, decon_cycle=None, lease_root=None,
              n_leases=cfg.QUERY_LEASES,
              lease_timeout=cfg.QUERY_LEASE_TIMEOUT):
    """Every MAST listing call for one pass, in one place, producing a plan.

    This is the only function that lists products, so it is the only one that
    needs a lease and the only one that can trigger the overload. Everything
    after it -- streaming, telemetry, compiling -- works from the returned
    :class:`QueryPlan`.

    ``lease_root`` is normally ``<staging_root>/plans/.query_lease``; pass None
    to skip leasing entirely, which is right for an interactive single run.
    """
    acquire = (query_lease(lease_root, n_leases=n_leases,
                           timeout=lease_timeout, label=label or str(search))
               if lease_root else contextlib.nullcontext())
    with acquire:
        results, products = _query_products(missions, search)
        l1_rows = pass_l1_rows(missions, search)
        fallback_dark = (find_l1_dark(missions, search, rows=l1_rows)
                         if blank_dark else None)

    # Outside the lease: pure computation over tables already in hand.
    activities = group_activities(results, products, fallback_dark=fallback_dark)
    label = label or run_label(activities, program=program)
    signature = sequence_signature(l1_rows.to_dict("records")) \
        if len(l1_rows) else ""

    return QueryPlan(label=label, program=program, search=search,
                     activities=activities, decon_cycle=decon_cycle,
                     blank_dark=blank_dark, sequence_signature=signature)


def startup_stagger(n_tasks=None, rank=None, max_seconds=None, sleep=time.sleep):
    """Sleep a rank-dependent interval so ranks do not all list at once.

    Replaces ``RANDOM % 61`` in the batch entrypoint, which was flat regardless
    of fan-out width: at 32-way that put ~32 ranks into a 61 s window, i.e. one
    listing burst every 2 s, which is the load the backoff and leases exist to
    survive. Spreading over ``n_tasks * 15`` seconds instead keeps the *rate*
    constant as the fan-out widens.

    Deterministic in ``rank`` rather than random, with a small random offset on
    top: a deterministic spread cannot coincidentally cluster the way 32 draws
    from U(0,61) will, and the offset keeps two ranks that restart together from
    re-colliding. Returns the delay actually slept, so a caller can log it.
    """
    n_tasks = int(n_tasks if n_tasks is not None
                  else os.environ.get("SLURM_NTASKS", 1) or 1)
    rank = int(rank if rank is not None
               else os.environ.get("SLURM_PROCID", 0) or 0)
    max_seconds = float(max_seconds if max_seconds is not None
                        else 15.0 * max(n_tasks, 1))
    if n_tasks <= 1:
        return 0.0
    delay = min((rank % n_tasks) * 15.0, max_seconds) \
        + random.uniform(0.0, 5.0)
    print(f"  startup stagger: rank {rank} of {n_tasks} sleeping "
          f"{delay:.0f}s before listing MAST")
    sleep(delay)

    return delay


# ---------------------------------------------------------------------------
# Self test
# ---------------------------------------------------------------------------

class _FlakyMissions:
    """Stand-in for a ``MastMissions`` handle, for the retry paths only.

    Raises ``KeyError(key_error)`` for the first ``n_failures`` listing calls
    and then succeeds -- exactly the astroquery behaviour
    :func:`_get_unique_product_list_retrying` exists for, with no network.
    ``key_error`` defaults to the transient missing-column case; set it to
    something else to check that a real bug is not retried.
    """

    def __init__(self, n_failures, product=None, key_error="filename"):
        self.n_failures = n_failures
        self.calls = 0
        self.product = product
        self.key_error = key_error

    def get_unique_product_list(self, results):
        self.calls += 1
        if self.calls <= self.n_failures:
            raise KeyError(self.key_error)

        return results

    def read_product(self, filename):
        self.calls += 1
        if self.calls <= self.n_failures:
            raise ConnectionError("403, Forbidden")

        return self.product


class _FixedRandom:
    """A ``random``-alike whose ``uniform`` returns a pinned value.

    Lets the backoff *ladder* be asserted exactly while the real jitter stays
    random. ``_FixedRandom(1.0)`` gives the un-jittered schedule; 0.5 and 1.5
    give the two extremes of the jitter window.
    """

    def __init__(self, value):
        self.value = value

    def uniform(self, low, high):
        assert low <= self.value <= high, (low, self.value, high)

        return self.value


class _Blocked(Exception):
    """Raised by :class:`_RaiseAfter` to prove a lease request blocked."""


class _RaiseAfter:
    """A ``sleep`` stand-in that records calls and bails out after ``n``.

    How a blocking lease acquisition is tested without actually blocking: the
    loop under test polls, and the n-th poll aborts it.
    """

    def __init__(self, record, n):
        self.record = record
        self.n = n

    def __call__(self, seconds):
        self.record.append(seconds)
        if len(self.record) >= self.n:
            raise _Blocked()


def _fake_activities(lit_scas=18):
    """A synthetic 7-activity run: a product-less dark plus six lit LEDs.

    Shaped like what ``group_activities`` returns, including the parts a plan
    round trip is most likely to corrupt -- int-keyed ``frames``/``sizes`` and
    a NaN ``exposure_time`` on the blank dark.
    """
    visit = "0103902001001002001"
    activities = [{
        "activity_number": 1, "key": "DARK", "visit_id": visit,
        "staging_id": visit, "id_synthetic": False, "exposure": 1,
        "observation": 1, "file_set_name": "", "led": "", "is_dark": True,
        "is_aux": False, "dark_blank": True, "optical_element": "",
        "exposure_type": "WFI_IM_DARK", "exposure_time": np.nan,
        "start_time": "2026-09-12T06:00:00", "end_time": "2026-09-12T06:02:00",
        "frames": {}, "sizes": {},
    }]
    for led in range(1, 7):
        activities.append({
            "activity_number": led + 1, "key": f"LED{led}", "visit_id": visit,
            "staging_id": f"{visit[:15]}{led + 1:04d}", "id_synthetic": True,
            "exposure": led + 1, "observation": led + 1,
            "file_set_name": f"r{visit}_{led + 1:04d}", "led": str(led),
            "is_dark": False, "is_aux": False, "dark_blank": False,
            "optical_element": "DARK", "exposure_type": "WFI_FLAT",
            "exposure_time": 3.04,
            "start_time": f"2026-09-12T06:{10 * led:02d}:00",
            "end_time": f"2026-09-12T06:{10 * led + 2:02d}:00",
            "frames": {sca: f"r{visit}_{led + 1:04d}_wfi{sca:02d}_dark_cal.asdf"
                       for sca in range(1, lit_scas + 1)},
            "sizes": {sca: 67_000_000 for sca in range(1, lit_scas + 1)},
        })

    return activities


def self_test(verbose=True):
    """Retry logic and column lists; no credentials, no network."""
    def say(text):
        if verbose:
            print(text)

    say("== product listing retry ==")
    # sleep is stubbed out so the ladder is checked without waiting for it;
    # the delays themselves are asserted on below.
    slept = []
    flaky = _FlakyMissions(n_failures=2)
    assert _get_unique_product_list_retrying(
        flaky, ["row"], {"program": 1039}, retries=2,
        sleep=slept.append) == ["row"]
    assert flaky.calls == 3
    assert len(slept) == 2, slept
    say("  a listing that fails twice then succeeds is recovered")

    hopeless = _FlakyMissions(n_failures=99)
    try:
        _get_unique_product_list_retrying(hopeless, ["row"], {"program": 1039},
                                          retries=2, sleep=lambda s: None)
    except ValueError as error:
        # The message is the operator-facing part: it has to say "retry later"
        # rather than look like a bug in this pipeline.
        assert "retry later" in str(error), error
    else:
        raise AssertionError("an always-failing listing was not reported")
    say("  an exhausted listing raises a ValueError naming it as transient")

    # A KeyError that is not a missing product-name column is a real bug.
    # Retrying it would turn a one-line traceback into a four-minute one.
    other = _FlakyMissions(n_failures=99, key_error="meta.rcs.led")
    try:
        _get_unique_product_list_retrying(other, ["row"], {}, retries=5,
                                          sleep=lambda s: None)
    except KeyError as error:
        assert "meta.rcs.led" in str(error), error
        assert other.calls == 1, f"retried a non-transient KeyError {other.calls}x"
    else:
        raise AssertionError("an unrelated KeyError was swallowed as transient")
    say("  a KeyError naming another column is re-raised on the first attempt")

    say("== backoff ladder ==")
    # The cap is applied before the jitter, so the worst case is 1.5 * cap.
    for attempt in range(8):
        delay = _backoff_delay(attempt, base=5.0, cap=120.0)
        assert 0.5 * 5.0 <= delay <= 1.5 * 120.0, (attempt, delay)
    lo = _backoff_delay(0, base=5.0, cap=120.0, rng=_FixedRandom(0.5))
    hi = _backoff_delay(0, base=5.0, cap=120.0, rng=_FixedRandom(1.5))
    assert (lo, hi) == (2.5, 7.5), (lo, hi)
    # Growth has to be real, not nominal: the whole point is that a contended
    # endpoint gets progressively longer to drain.
    mid = _FixedRandom(1.0)
    ladder = [_backoff_delay(n, base=5.0, cap=120.0, rng=mid) for n in range(7)]
    assert ladder == [5.0, 10.0, 20.0, 40.0, 80.0, 120.0, 120.0], ladder
    say(f"  6 retries ladder {ladder} s, jitter spans 0.5x-1.5x, capped at 120")

    say("== query plan round trip ==")
    plan = QueryPlan(label="CAR190_01039_02_001_001_20260912", program=1039,
                     search={"program": 1039, "pass": 1}, decon_cycle="decon1",
                     blank_dark=True, activities=_fake_activities())
    with tempfile.TemporaryDirectory() as tmp:
        plan.write(tmp)
        back = QueryPlan.read(tmp, plan.label)
    assert back.label == plan.label and back.decon_cycle == "decon1"
    assert back.blank_dark is True
    # The three things a hand-rolled JSON round trip gets wrong. SCA keys must
    # come back as ints: str keys would make entry["sizes"].get(sca, 0) return
    # 0 for every SCA and silently report a 0 MB/s pull, and sorted() over str
    # keys would pull in the order 1,10,11,...,2 rather than 1..18.
    lit = [e for e in back.activities if e["key"] == "LED1"][0]
    assert sorted(lit["frames"]) == list(range(1, 19)), sorted(lit["frames"])
    assert all(isinstance(sca, int) for sca in lit["sizes"])
    assert lit["sizes"][18] == 67_000_000
    # NaN survives as NaN, not as the string "nan" or as None.
    dark = [e for e in back.activities if e["is_dark"]][0]
    assert isinstance(dark["exposure_time"], float)
    assert np.isnan(dark["exposure_time"]), dark["exposure_time"]
    assert dark["frames"] == {} and dark["dark_blank"] is True
    say("  int SCA keys, NaN exposure_time and the blank dark all round-trip")

    # The sequence signature rides along; a plan written before it existed
    # still loads, with an empty signature rather than a refusal.
    signed = QueryPlan.from_dict(dict(plan.to_dict(),
                                      sequence_signature="1:Dx1@180"))
    assert signed.sequence_signature == "1:Dx1@180"
    assert QueryPlan.from_dict(signed.to_dict()).sequence_signature == "1:Dx1@180"
    older = plan.to_dict()
    older.pop("sequence_signature", None)
    assert QueryPlan.from_dict(older).sequence_signature == ""
    say("  the sequence signature round-trips, and a plan without one loads")

    # A plan written by an older layout must be refused, not half-read.
    payload = plan.to_dict()
    payload["schema_version"] = "rcs-query-plan/0.9"
    try:
        QueryPlan.from_dict(payload)
    except ValueError as error:
        assert "--plan-only" in str(error), error
    else:
        raise AssertionError("a stale plan schema was accepted")
    # And a field added to group_activities but not to PLAN_ACTIVITY_FIELDS has
    # to fail loudly here rather than vanish on the round trip.
    try:
        _plan_activity({**_fake_activities()[0], "new_field": 1})
    except KeyError as error:
        assert "PLAN_ACTIVITY_FIELDS" in str(error), error
    else:
        raise AssertionError("an unpersisted activity field was dropped quietly")
    say("  a stale schema and an unpersisted field are both refused")

    say("== plan coverage precondition ==")
    counts = check_plan_coverage(plan, min_scas=18)
    # The dark contributes no products at all and must not be required to:
    # the RCS dark is never processed to L2.
    assert counts["DARK"] == 0, counts
    short = QueryPlan(label="short", program=1039, search={},
                      activities=_fake_activities(lit_scas=2))
    try:
        check_plan_coverage(short, min_scas=18)
    except ValueError as error:
        assert "Nothing has been streamed" in str(error), error
        assert "LED1 2/18" in str(error), error
    else:
        raise AssertionError("a degraded plan was not refused")
    say("  18/18 accepted with a 0-SCA dark; a 2-SCA lit activity refused")

    say("== query leases ==")
    with tempfile.TemporaryDirectory() as tmp:
        root = os.path.join(tmp, ".query_lease")
        with query_lease(root, n_leases=2, label="a") as first:
            with query_lease(root, n_leases=2, label="b") as second:
                assert first != second
                assert len(os.listdir(root)) == 2
                # Both slots are taken, so a third must block. Rather than
                # actually waiting, assert it polls instead of over-issuing.
                polls = []
                try:
                    query_lease(root, n_leases=2, label="c",
                                sleep=_RaiseAfter(polls, 3)).__enter__()
                except _Blocked:
                    pass
                else:
                    raise AssertionError("a third lease was issued for 2 slots")
                assert len(polls) == 3, polls
        assert os.listdir(root) == [], os.listdir(root)
    say("  2 slots are exclusive, a third blocks, and both release on exit")

    with tempfile.TemporaryDirectory() as tmp:
        root = os.path.join(tmp, ".query_lease")
        os.makedirs(os.path.join(root, "lease00"))
        marker = os.path.join(root, "lease00", "holder")
        with open(marker, "w") as handle:
            handle.write("deadhost pid=1 dead")
        os.utime(marker, (time.time() - 10_000, time.time() - 10_000))
        with query_lease(root, n_leases=1, timeout=900.0) as stolen:
            assert stolen.endswith("lease00")
    say("  a lease whose holder died is stolen after the timeout, with a warning")

    say("== startup stagger ==")
    assert startup_stagger(n_tasks=1, rank=0, sleep=lambda s: None) == 0.0
    spread = [startup_stagger(n_tasks=8, rank=r, sleep=lambda s: None)
              for r in range(8)]
    assert spread[0] < spread[-1]
    assert max(spread) <= 15.0 * 8 + 5.0, spread
    say(f"  single rank does not sleep; 8 ranks spread over "
        f"{min(spread):.0f}-{max(spread):.0f}s, so the listing rate is flat")

    say("== product streaming retry ==")
    stream = _FlakyMissions(n_failures=1, product="asdf")
    assert stream_product(stream, "r0_0001_wfi01_f158_cal.asdf",
                          retries=3, backoff=0.0) == "asdf"
    say("  a 403 mid-stream is cleared by re-issuing read_product")

    say("== query column lists ==")
    # MINIMAL_COLS is the fallback, so it must not ask for anything SELECT_COLS
    # does not -- otherwise the fallback could fail for the same reason.
    assert set(MINIMAL_COLS) <= set(SELECT_COLS)
    # "exposure" is not a Roman column; asking for it drops it with a warning
    # and the exposure number then has to come out of the fileSetName.
    for columns in (SELECT_COLS, MINIMAL_COLS, SURVEY_COLS):
        assert "exposure" not in columns
        assert "fileSetName" in columns
    say(f"  MINIMAL_COLS ({len(MINIMAL_COLS)}) is a subset of SELECT_COLS "
        f"({len(SELECT_COLS)}), and none asks for a nonexistent 'exposure'")

    return True


if __name__ == "__main__":
    print("rcs_mast self test")
    self_test()
    print("all checks passed")
