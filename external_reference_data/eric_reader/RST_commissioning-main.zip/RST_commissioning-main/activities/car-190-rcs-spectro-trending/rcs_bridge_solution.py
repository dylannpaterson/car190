"""The cross-epoch bridge solution: what stage 3 fitted, in a form stage 2 records.

The two bridges -- the per-SCA achromatic step across each ACM move, and the
per-LED SCA-common step across an MCE side change -- are properties of the
*trend*, not of any one epoch: each is fitted from the epochs either side of a
boundary. So no per-file stage can compute them, yet the calibrated h5 is meant
to carry every factor needed to calibrate it. This file is the bridge between
the two, exactly as ``tempgain_model.ecsv`` is for the temperature gain:

    stage 2 (pass 1)  photodiode + linear ACM recorded, no bridges
    stage 3           fits the bridges, writes THIS file (--solution-out)
    stage 2 (pass 2)  records the bridges from it (--bridge-solution)
    stage 3           refits, and confirms the products carry the current one

That is a bootstrap, not an iteration. The bridges are fitted from the
photodiode- and ACM-corrected response, and the second stage-2 pass adds
metadata without moving a pixel or changing either of those factors, so the
refit sees bit-identical input and must return the same steps.

**Keyed by time, not by epoch index.** Each row carries ``boundary_utc``, the
midpoint between the last epoch before the boundary and the first after it. An
epoch's multiplier is the product of every step whose boundary lies *after* its
own timestamp, so stage 2 can evaluate it for any one product without knowing
the set's ordering or size.

**Gauge: present-nominal.** The latest configuration -- the current MCE side and
the current ACM segment -- has multiplier 1, and every earlier configuration is
scaled up to it. For the side swap that is the gauge asked for (the instrument
stays on side B, so the constants bring side A up to the present); for the ACM
it is the deployed gauge ``rcs_acm.bridge_factors`` already solves in. A digest
normalized to its reference epoch divides that epoch's multiplier out, which is
why its ``bridge_factor`` column reads 1.0 in row 0 while the product's does not.
"""
import dataclasses
import datetime
import hashlib
import os

import numpy as np

KIND_ACM = "acm"
KIND_SIDE = "side"
# One row per (side change, SCA, LED): that SCA's own independent step, the
# input to the illumination-pattern test. Recorded so the test can be redone
# from a product alone; NEVER applied -- the applied side step is SCA-common.
KIND_SIDE_SCA = "side_sca"
COLUMNS = ("kind", "boundary_index", "boundary_run_label", "boundary_utc",
           "transition", "sca", "led", "value", "stat_error", "systematic",
           "total_error", "method", "n_early", "n_late", "note",
           # Format 2: everything else the digests' bridge_* and side_bridge_*
           # meta report, so a product carrying the solution carries all of
           # it. NaN where a column does not apply to a row's kind.
           "sca_scatter_error", "led_spread", "rms_early", "rms_late",
           "pattern_offset", "pattern_rms", "pattern_noise",
           "lvdt_before", "lvdt_after")
FLOAT_COLUMNS = ("value", "stat_error", "systematic", "total_error",
                 "sca_scatter_error", "led_spread", "rms_early", "rms_late",
                 "pattern_offset", "pattern_rms", "pattern_noise",
                 "lvdt_before", "lvdt_after")
INT_COLUMNS = ("boundary_index", "sca", "n_early", "n_late")
GAUGE = ("present-nominal: an epoch is multiplied by the product of every "
         "step whose boundary_utc is AFTER its own timestamp, so the latest "
         "configuration has multiplier 1 and earlier ones are scaled up to it")
FORMAT_VERSION = 2


def _utc(value):
    """An aware UTC datetime from a datetime or an ISO string."""
    if isinstance(value, datetime.datetime):
        moment = value
    else:
        text = str(value).strip()
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        moment = datetime.datetime.fromisoformat(text)
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=datetime.timezone.utc)
    return moment.astimezone(datetime.timezone.utc)


def midpoint(earlier, later):
    """ISO UTC midpoint of two timestamps, the boundary a row is keyed by."""
    a, b = _utc(earlier), _utc(later)
    return (a + (b - a) / 2).isoformat(timespec="microseconds")


def file_sha256(path, chunk=1 << 20):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(chunk), b""):
            digest.update(block)
    return digest.hexdigest()


@dataclasses.dataclass
class BridgeSolution:
    """Rows of fitted bridge steps, plus provenance."""

    rows: list
    meta: dict = dataclasses.field(default_factory=dict)
    path: str = ""
    sha256: str = ""

    # -- evaluation ----------------------------------------------------------

    def _after(self, kind, timestamp):
        moment = _utc(timestamp)
        return [row for row in self.rows
                if row["kind"] == kind and _utc(row["boundary_utc"]) > moment]

    def acm_multiplier(self, timestamp, sca_names):
        """``(n_sca,)``: the composed ACM bridge for an epoch at ``timestamp``.

        One achromatic number per SCA. An SCA a later boundary has no row for
        is refused rather than left at 1.0: a missing step would leave that
        detector unbridged inside a bridged set.
        """
        out = np.ones(len(sca_names))
        rows = self._after(KIND_ACM, timestamp)
        for boundary in sorted({row["boundary_utc"] for row in rows}):
            by_sca = {int(row["sca"]): float(row["value"]) for row in rows
                      if row["boundary_utc"] == boundary}
            for index, sca in enumerate(sca_names):
                number = int(str(sca).replace("SCA", ""))
                if number not in by_sca:
                    raise KeyError(f"the bridge solution has no ACM step for "
                                   f"SCA{number} at {boundary}")
                out[index] *= by_sca[number]
        return out

    def side_multiplier(self, timestamp, led_names):
        """``(n_led,)``: the composed side bridge for an epoch at ``timestamp``.

        One number per LED, the same for every SCA -- the swap is not allowed
        to change the illumination pattern.
        """
        out = np.ones(len(led_names))
        rows = self._after(KIND_SIDE, timestamp)
        for boundary in sorted({row["boundary_utc"] for row in rows}):
            by_led = {str(row["led"]): float(row["value"]) for row in rows
                      if row["boundary_utc"] == boundary}
            for index, led in enumerate(led_names):
                if led not in by_led:
                    raise KeyError(f"the bridge solution has no side step for "
                                   f"{led} at {boundary}")
                out[index] *= by_led[led]
        return out

    def side_error(self, timestamp, led_names):
        """``(n_led,)`` total error of the composed side step, in quadrature."""
        variance = np.zeros(len(led_names))
        for row in self._after(KIND_SIDE, timestamp):
            if row["led"] in led_names:
                fractional = float(row["total_error"]) / float(row["value"])
                variance[list(led_names).index(row["led"])] += fractional ** 2
        return np.sqrt(variance)

    def acm_error(self, timestamp, sca_names):
        """``(n_sca,)`` total error of the composed ACM bridge, in quadrature."""
        variance = np.zeros(len(sca_names))
        numbers = [int(str(s).replace("SCA", "")) for s in sca_names]
        for row in self._after(KIND_ACM, timestamp):
            if int(row["sca"]) in numbers and float(row["value"]) > 0:
                fractional = float(row["total_error"]) / float(row["value"])
                variance[numbers.index(int(row["sca"]))] += np.nan_to_num(
                    fractional) ** 2
        return np.sqrt(variance)

    def boundaries(self, kind):
        """Distinct ``(boundary_utc, boundary_index, run_label, transition)``."""
        seen = {}
        for row in self.rows:
            if row["kind"] == kind:
                seen[row["boundary_utc"]] = (row["boundary_utc"],
                                             int(row["boundary_index"]),
                                             str(row["boundary_run_label"]),
                                             str(row["transition"]))
        return [seen[key] for key in sorted(seen)]

    def describe(self):
        acm, side = self.boundaries(KIND_ACM), self.boundaries(KIND_SIDE)
        lines = [f"bridge solution {os.path.basename(self.path) or '(unsaved)'}"
                 f"{'  sha256 ' + self.sha256[:12] if self.sha256 else ''}",
                 f"  {len(acm)} ACM boundary(ies), {len(side)} side "
                 f"boundary(ies); gauge present-nominal"]
        for utc, index, label, transition in side:
            values = {row["led"]: row for row in self.rows
                      if row["kind"] == KIND_SIDE and row["boundary_utc"] == utc}
            lines.append(f"  side {transition} at epoch {index} ({label}):")
            lines.append("    " + "  ".join(
                f"{led} {float(values[led]['value']):.5f}"
                f"+-{float(values[led]['total_error']):.5f}"
                for led in sorted(values)))
        return "\n".join(lines)

    # -- I/O -----------------------------------------------------------------

    def _complete(self, row):
        """A row with every column, defaults filled: NaN, 0 or empty."""
        out = dict(row)
        for name in COLUMNS:
            if name not in out:
                out[name] = (float("nan") if name in FLOAT_COLUMNS
                             else 0 if name in INT_COLUMNS else "")
        return out

    def as_columns(self):
        """``{column: array}``, the payload of a product's ``calibration/bridge_solution``.

        The whole table goes into every calibrated product, not just the
        composed multiplier for that epoch. It is ~200 rows, and without it a
        product could say what was applied to it but not how well it is known,
        which fit produced it, or what the pattern test read -- the things that
        used to live only in the digests' bridge_* meta.
        """
        rows = [self._complete(row) for row in self.rows]
        out = {}
        for name in COLUMNS:
            values = [row[name] for row in rows]
            out[name] = (np.asarray(values, dtype=float) if name in FLOAT_COLUMNS
                         else np.asarray(values, dtype=int) if name in INT_COLUMNS
                         else np.asarray([str(v) for v in values], dtype=object))
        return out

    @classmethod
    def from_columns(cls, columns, meta=None, path="", sha256=""):
        """Inverse of :meth:`as_columns`, e.g. from an h5 group."""
        def text(value):
            return value.decode() if isinstance(value, bytes) else str(value)

        n = len(columns["kind"])
        rows = []
        for i in range(n):
            row = {}
            for name in COLUMNS:
                if name not in columns:
                    row[name] = (float("nan") if name in FLOAT_COLUMNS
                                 else 0 if name in INT_COLUMNS else "")
                    continue
                value = columns[name][i]
                row[name] = (float(value) if name in FLOAT_COLUMNS
                             else int(value) if name in INT_COLUMNS
                             else text(value))
            rows.append(row)
        return cls(rows=rows, meta=dict(meta or {}), path=path, sha256=sha256)

    def write(self, path):
        from astropy.table import Table

        rows = [self._complete(row) for row in self.rows]
        table = Table(rows=[[row[name] for name in COLUMNS] for row in rows]
                      if rows else None, names=COLUMNS)
        meta = dict(self.meta)
        meta.setdefault("format_version", FORMAT_VERSION)
        meta["gauge"] = GAUGE
        meta.setdefault("created", datetime.datetime.now(
            datetime.timezone.utc).isoformat(timespec="seconds"))
        meta["comments"] = [
            "Bridge steps fitted by make_sca_digests.py --solution-out and "
            "recorded into calibrated h5 products by calibrate_rcs_products.py "
            "--bridge-solution. RECORDED, NOT APPLIED to any pixel.",
            "kind=acm: one row per (boundary, SCA), led='ALL'; an achromatic "
            "step per SCA. kind=side: one row per (boundary, LED), sca=0; a "
            "chromatic step common to every SCA. kind=side_sca: one row per "
            "(boundary, SCA, LED), that SCA's own independent step, for the "
            "illumination-pattern test only -- never applied.",
            "value multiplies every epoch BEFORE boundary_utc; see gauge.",
        ]
        table.meta.update(meta)
        directory = os.path.dirname(os.path.abspath(path))
        os.makedirs(directory, exist_ok=True)
        table.write(path, format="ascii.ecsv", overwrite=True)
        self.path, self.sha256 = str(path), file_sha256(path)
        return path

    @classmethod
    def read(cls, path):
        from astropy.table import Table

        table = Table.read(path, format="ascii.ecsv")
        version = int(table.meta.get("format_version", 0))
        if version not in (1, FORMAT_VERSION):
            raise ValueError(f"{path} is bridge-solution format {version}; "
                             f"this code reads 1 and {FORMAT_VERSION}")
        # Format 1 had only the first 15 columns; the rest read as NaN.
        required = COLUMNS[:15]
        missing = [name for name in required if name not in table.colnames]
        if missing:
            raise ValueError(f"{path} is not a bridge solution: missing "
                             f"column(s) {missing}")
        rows = []
        for record in table:
            row = {}
            for name in COLUMNS:
                if name not in table.colnames:
                    row[name] = (float("nan") if name in FLOAT_COLUMNS
                                 else 0 if name in INT_COLUMNS else "")
                elif np.ma.is_masked(record[name]):
                    # ECSV writes an empty string and astropy reads it back as
                    # a masked cell, whose str() is "--". A note that was
                    # empty would then reach every product as "--".
                    row[name] = (float("nan") if name in FLOAT_COLUMNS
                                 else 0 if name in INT_COLUMNS else "")
                elif name in FLOAT_COLUMNS:
                    row[name] = float(record[name])
                elif name in INT_COLUMNS:
                    row[name] = int(record[name])
                else:
                    row[name] = str(record[name])
            rows.append(row)
        meta = {key: value for key, value in table.meta.items()
                if key != "comments"}
        return cls(rows=rows, meta=meta, path=str(path),
                   sha256=file_sha256(path))


def self_test(verbose=True):
    """Round trip and the present-nominal composition, by hand."""
    import tempfile

    def report(name):
        if verbose:
            print(f"  ok   {name}")

    t_move = "2026-09-14T20:00:00+00:00"
    t_swap = "2026-10-06T08:00:00+00:00"
    rows = []
    for sca in (1, 2):
        rows.append({"kind": KIND_ACM, "boundary_index": 16,
                     "boundary_run_label": "P16", "boundary_utc": t_move,
                     "transition": "reposition", "sca": sca, "led": "ALL",
                     "value": 1.01 * sca, "stat_error": 1e-4, "systematic": 0.0,
                     "total_error": 1e-4, "method": "bridge", "n_early": 4,
                     "n_late": 4, "note": ""})
        rows.append({"kind": KIND_ACM, "boundary_index": 181,
                     "boundary_run_label": "P71", "boundary_utc": t_swap,
                     "transition": "A->B", "sca": sca, "led": "ALL",
                     "value": 1.0, "stat_error": 0.0, "systematic": 0.0,
                     "total_error": 0.0, "method": "side", "n_early": 0,
                     "n_late": 0, "note": "bridged by the side step"})
    for led, value in (("LED1", 0.95), ("LED2", 1.02)):
        rows.append({"kind": KIND_SIDE, "boundary_index": 181,
                     "boundary_run_label": "P71", "boundary_utc": t_swap,
                     "transition": "A->B", "sca": 0, "led": led,
                     "value": value, "stat_error": 1e-4, "systematic": 2e-4,
                     "total_error": 3e-4, "method": "side", "n_early": 5,
                     "n_late": 4, "note": ""})
    # A per-SCA estimate wildly different from the common step: if it were
    # ever composed into the applied multiplier the checks below would fail.
    rows.append({"kind": KIND_SIDE_SCA, "boundary_index": 181,
                 "boundary_run_label": "P71", "boundary_utc": t_swap,
                 "transition": "A->B", "sca": 1, "led": "LED1", "value": 9.0,
                 "method": "test", "pattern_offset": 2e-4})
    solution = BridgeSolution(rows=rows, meta={"source": "self-test"})

    early, middle, late = ("2026-09-12T01:00:00", "2026-10-01T00:00:00",
                           "2026-10-07T00:00:00")
    assert np.allclose(solution.acm_multiplier(early, ["SCA1", "SCA2"]),
                       [1.01, 2.02])
    assert np.allclose(solution.acm_multiplier(middle, ["SCA1", "SCA2"]), 1.0)
    assert np.allclose(solution.side_multiplier(middle, ["LED1", "LED2"]),
                       [0.95, 1.02])
    assert np.allclose(solution.side_multiplier(late, ["LED1", "LED2"]), 1.0)
    report("present-nominal: only boundaries AFTER an epoch apply to it, so "
           "the latest configuration is exactly 1")
    try:
        solution.acm_multiplier(early, ["SCA3"])
    except KeyError:
        report("an SCA with no step at a later boundary is refused, not "
               "left unbridged")
    else:
        raise AssertionError("a missing SCA was silently bridged at 1.0")

    with tempfile.TemporaryDirectory() as tmp:
        path = solution.write(os.path.join(tmp, "solution.ecsv"))
        back = BridgeSolution.read(path)
        assert back.sha256 == solution.sha256 and len(back.sha256) == 64
        assert np.allclose(back.side_multiplier(middle, ["LED1", "LED2"]),
                           [0.95, 1.02])
        assert back.boundaries(KIND_SIDE)[0][1] == 181
        assert np.isnan(back.rows[0]["pattern_rms"])
        assert back.rows[0]["note"] == "", repr(back.rows[0]["note"])
        report("ECSV round trip, with the sha256 that products record; "
               "columns a row does not use read back as NaN")
    columns = solution.as_columns()
    again = BridgeSolution.from_columns(columns)
    assert len(again.rows) == len(solution.rows)
    assert np.allclose(again.side_multiplier(middle, ["LED1", "LED2"]),
                       [0.95, 1.02])
    sca_rows = [r for r in again.rows if r["kind"] == KIND_SIDE_SCA]
    assert sca_rows[0]["value"] == 9.0 and sca_rows[0]["pattern_offset"] == 2e-4
    report("the column form a product embeds round-trips, and the per-SCA "
           "side estimates in it are never applied")
    assert midpoint("2026-10-06T04:13:00", "2026-10-06T11:55:00").startswith(
        "2026-10-06T08:04:00")
    report("boundary_utc is the midpoint of the gap")
    return True


if __name__ == "__main__":
    print("rcs_bridge_solution self-test")
    self_test()
    print("all passed")
