"""
Demo: pull one or more EDP mnemonics over a recent window.

A comma-separated ``--mnemonic`` list instead pulls all of them in one batched
EDP call (``pull_mnemonics``) and writes a long-format ``--out-ecsv`` table
(``mnemonic``/``time``/``value``) rather than a plot; pass ``--ecsv`` to get
that same table for a single mnemonic too (skipping the PNG).

Unlike ``process_rcs_trending.py``, this needs no MAST product query -- just
mnemonics and a time window -- so it doubles as the minimal HOWTO for an EDP
pull via ``rcs_edp.query_mnemonics``.

    python trend_housekeeping.py
    python trend_housekeeping.py --mnemonic WFI_MCE_SRCS_SPHERE_T --hours 24
    python trend_housekeeping.py --mnemonic WFI_MCE_ADC_WTSM00,WFI_MCE_SRCS_SPHERE_T --out-ecsv plots/tables/pull.ecsv
    python trend_housekeeping.py --mnemonic WFI_MCE_TEMP_EWA --ecsv --start 2026-09-12T01:28:34 --end 2026-09-20T17:28:34 --out-ecsv plots/tables/housekeeping_pull.ecsv
"""
import argparse
import os
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd
from astropy.table import Table

import rcs_edp

MNEMONIC = "WFI_MCE_ADC_WTSM00"
LINE_COLOR = "#256abf"

_WHEEL_POS_RE = re.compile(r"^POS_(\d+)_")


def _wheel_position_to_number(label):
    """Map a wheel-position label (e.g. EWA filter position) to a number.

    ``POS_<N>_<filter>`` -> N (the wheel slot, 1-10), ``HOME_DARK`` -> 0,
    ``POS_UNKNOWN`` -> -1; anything else -> NaN.
    """
    if label == "HOME_DARK":
        return 0.0
    if label == "POS_UNKNOWN":
        return -1.0
    match = _WHEEL_POS_RE.match(label)

    return float(match.group(1)) if match else float("nan")


def load_token():
    """Find ``variables.env`` whether run from here or the repo root.

    The README convention puts it in this activity directory; this session's
    token instead lives in the repo root's ``variables.env``, so both are
    tried before falling back to a bare exported ``MAST_API_TOKEN``.
    """
    here = os.path.dirname(os.path.abspath(__file__))
    for candidate in ("variables.env",
                      os.path.join(here, "variables.env"),
                      os.path.join(here, "..", "..", "variables.env")):
        if os.path.exists(candidate):
            return rcs_edp.edp_token(dotenv_path=candidate)

    return rcs_edp.edp_token(dotenv_path=None)


def _parse_frame(frame):
    """Turn one EDP response frame into a ``time``/``value``/``value_numeric``
    DataFrame.

    tz-naive UTC time, sorted by time; empty if ``frame`` is ``None`` or has
    nothing usable. ``value`` is the float EU value, except for a categorical
    mnemonic (e.g. a filter-wheel position label like ``POS_7_F158``) whose EU
    value never parses as a number -- there it is kept as the raw string
    rather than coerced to all-NaN and dropped. ``value_numeric`` is always a
    float: equal to ``value`` when it already is one, otherwise
    :func:`_wheel_position_to_number` applied to the label (NaN if that
    doesn't match either).
    """
    if frame is None or len(frame) == 0:
        return pd.DataFrame(columns=["time", "value", "value_numeric"])

    time = pd.to_datetime(frame[rcs_edp.TIME_COLUMN], errors="coerce", utc=True)
    raw_value = frame[rcs_edp.VALUE_COLUMN]
    value = pd.to_numeric(raw_value, errors="coerce")
    if value.notna().sum() == 0 and raw_value.notna().sum() > 0:
        value = raw_value.astype(str)
        value_numeric = value.map(_wheel_position_to_number)
    else:
        value_numeric = value
    out = pd.DataFrame({"time": time.dt.tz_localize(None), "value": value,
                         "value_numeric": value_numeric})
    out = out.dropna(subset=["time", "value"]).sort_values(
        "time").reset_index(drop=True)

    return out


def pull_mnemonics_window(mnemonics, t_start, t_end, token=None):
    """Fetch several mnemonics' timeseries over an explicit ``[t_start, t_end]``.

    One batched EDP call for all of ``mnemonics``. Returned as a single
    long-format DataFrame (``mnemonic``/``time``/``value``/``value_numeric``,
    tz-naive UTC) rather than a wide/pivoted table, since EDP sampling
    cadence differs per mnemonic (see ``rcs_edp.sample_window``) -- a wide
    table would need lossy resampling to align them, long format does not.
    Sorted by mnemonic, then time; a mnemonic with nothing in the window
    contributes no rows. See :func:`_parse_frame` for what ``value`` vs.
    ``value_numeric`` hold.
    """
    token = load_token() if token is None else token

    series = rcs_edp.query_mnemonics(list(mnemonics), t_start, t_end, token=token)

    parts = []
    for mnemonic in mnemonics:
        part = _parse_frame(series.get(mnemonic))
        part.insert(0, "mnemonic", mnemonic)
        parts.append(part)

    out = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(
        columns=["mnemonic", "time", "value", "value_numeric"])

    return out.sort_values(["mnemonic", "time"]).reset_index(drop=True)


def pull_mnemonics(mnemonics, hours=12.0, token=None):
    """Fetch several mnemonics' timeseries over the last ``hours`` (ending now).

    Thin wrapper around :func:`pull_mnemonics_window` for the common
    "now-anchored" case; see that function for the return shape.
    """
    t_end = pd.Timestamp.now(tz="UTC").tz_localize(None)
    t_start = t_end - pd.Timedelta(hours=hours)

    return pull_mnemonics_window(mnemonics, t_start, t_end, token=token)


def pull_mnemonic_window(mnemonic, t_start, t_end, token=None):
    """Fetch one mnemonic's timeseries over an explicit ``[t_start, t_end]``.

    Returns a ``time``/``value``/``value_numeric`` DataFrame (tz-naive UTC)
    sorted by time; empty if the EDP had nothing in the window.
    """
    table = pull_mnemonics_window([mnemonic], t_start, t_end, token=token)

    return table.drop(columns="mnemonic").reset_index(drop=True)


def pull_mnemonic(mnemonic=MNEMONIC, hours=12.0, token=None):
    """Fetch one mnemonic's timeseries over the last ``hours`` (ending now).

    Returns a ``time``/``value``/``value_numeric`` DataFrame (tz-naive UTC)
    sorted by time; empty if the EDP had nothing in the window.
    """
    table = pull_mnemonics([mnemonic], hours=hours, token=token)

    return table.drop(columns="mnemonic").reset_index(drop=True)


def plot_mnemonic(data, mnemonic, window_desc, out_path, show_minmax=False,
                   ylim=None):
    """Write a time-vs-value line plot of ``data`` to ``out_path``.

    Plots ``value_numeric`` (always a float; see :func:`_parse_frame`), but
    the latest-point annotation shows the raw ``value`` label for a
    categorical mnemonic (e.g. a filter-wheel position) rather than its
    mapped number. With ``show_minmax``, draws horizontal dashed lines at the
    min/max ``value_numeric`` over the window, each labeled with its value.
    ``ylim``, if given, is a ``(ymin, ymax)`` pair passed to ``ax.set_ylim``;
    either side may be ``None`` to leave that bound on autoscale.
    """
    is_categorical = not pd.api.types.is_numeric_dtype(data["value"])
    fmt = str if is_categorical else (lambda value: f"{value:.3g}")

    fig, ax = plt.subplots(figsize=(9, 4.5))
    if len(data):
        ax.plot(data["time"], data["value_numeric"], color=LINE_COLOR, linewidth=2)
        latest_time = data["time"].iloc[-1]
        latest_value = data["value"].iloc[-1]
        latest_numeric = data["value_numeric"].iloc[-1]
        ax.plot(latest_time, latest_numeric, "o", color=LINE_COLOR, markersize=6)
        ax.annotate(fmt(latest_value), (latest_time, latest_numeric),
                    xytext=(8, 0), textcoords="offset points", va="center",
                    color=LINE_COLOR, fontsize=9)
        if show_minmax:
            vmin, vmax = data["value_numeric"].min(), data["value_numeric"].max()
            for value, label in ((vmin, "min"), (vmax, "max")):
                ax.axhline(value, color="gray", linewidth=1, linestyle="--",
                           alpha=0.7)
                ax.annotate(f"{label}={value:.3g}", (data["time"].iloc[0], value),
                            xytext=(0, 4), textcoords="offset points",
                            color="gray", fontsize=8)
    else:
        ax.text(0.5, 0.5, "no samples in window", ha="center", va="center",
                transform=ax.transAxes, color="gray")

    if ylim is not None:
        ax.set_ylim(*ylim)

    ax.set_title(f"{mnemonic} — {window_desc}")
    ax.set_ylabel("EU value")
    ax.xaxis.set_major_locator(mdates.AutoDateLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d %H:%M"))
    fig.autofmt_xdate()
    ax.grid(True, alpha=0.3)
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(False)

    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--mnemonic", default=MNEMONIC,
                        help="one mnemonic (plots a PNG, unless --ecsv) or a "
                             "comma-separated list (always writes --out-ecsv)")
    parser.add_argument("--hours", type=float, default=12.0,
                        help="pull the last N hours, ending now; ignored if "
                             "--start/--end are given")
    parser.add_argument("--start", default=None,
                        help="explicit window start (ISO8601, tz-naive UTC), "
                             "e.g. 2026-09-12T01:28:34; requires --end")
    parser.add_argument("--end", default=None,
                        help="explicit window end (ISO8601, tz-naive UTC); "
                             "requires --start")
    parser.add_argument("--out", default="plots/housekeeping/housekeeping_trend.png")
    parser.add_argument("--out-ecsv", default="plots/tables/housekeeping_pull.ecsv",
                        help="only used in multi-mnemonic mode, or single-"
                             "mnemonic mode with --ecsv")
    parser.add_argument("--ecsv", action="store_true",
                        help="write --out-ecsv instead of a PNG even for a "
                             "single --mnemonic")
    parser.add_argument("--show-minmax", action="store_true",
                        help="draw min/max horizontal lines on the plot "
                             "(single-mnemonic mode only)")
    parser.add_argument("--ylim-min", type=float, default=None,
                        help="fix the plot's y-axis lower bound "
                             "(single-mnemonic mode only)")
    parser.add_argument("--ylim-max", type=float, default=None,
                        help="fix the plot's y-axis upper bound "
                             "(single-mnemonic mode only)")
    args = parser.parse_args()

    if (args.start is None) != (args.end is None):
        parser.error("--start and --end must be given together")

    window = None
    if args.start is not None:
        window = (pd.Timestamp(args.start), pd.Timestamp(args.end))

    mnemonics = [m.strip() for m in args.mnemonic.split(",") if m.strip()]

    if len(mnemonics) == 1 and not args.ecsv:
        if window is not None:
            data = pull_mnemonic_window(mnemonics[0], *window)
            window_desc = f"{window[0]} to {window[1]}"
            print(f"  {len(data)} samples for {mnemonics[0]} over "
                  f"[{window[0]}, {window[1]}]")
        else:
            data = pull_mnemonic(mnemonics[0], hours=args.hours)
            window_desc = f"last {args.hours:g}h"
            print(f"  {len(data)} samples for {mnemonics[0]} over the last "
                  f"{args.hours:g}h")
        if len(data):
            numeric = data["value_numeric"]
            print(f"  min={numeric.min():.3f}  mean={numeric.mean():.3f}"
                  f"  max={numeric.max():.3f}"
                  f"  latest={data['value'].iloc[-1]} @ {data['time'].iloc[-1]}")

        ylim = (args.ylim_min, args.ylim_max) if (
            args.ylim_min is not None or args.ylim_max is not None) else None

        os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
        plot_mnemonic(data, mnemonics[0], window_desc, args.out,
                      show_minmax=args.show_minmax, ylim=ylim)
        print(f"  wrote {args.out}")
        return

    if window is not None:
        table = pull_mnemonics_window(mnemonics, *window)
        window_desc = f"[{window[0]}, {window[1]}]"
    else:
        table = pull_mnemonics(mnemonics, hours=args.hours)
        window_desc = f"the last {args.hours:g}h"
    for mnemonic in mnemonics:
        count = int((table["mnemonic"] == mnemonic).sum())
        print(f"  {count} samples for {mnemonic} over {window_desc}")

    os.makedirs(os.path.dirname(args.out_ecsv) or ".", exist_ok=True)
    Table.from_pandas(table).write(args.out_ecsv, format="ascii.ecsv", overwrite=True)
    print(f"  wrote {args.out_ecsv}")


if __name__ == "__main__":
    main()
