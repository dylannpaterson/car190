"""The core of the ice-film response model

Shared, unchanged, by the user-space reader (``ice_response_model.py``, next to this
file) and by the fitting repository's packaged models (``fit_film/modal.py``,
``fit_film/response_model.py``), so the two cannot drift apart. Free-standing: numpy
and scipy only, no file I/O, no imports from the fitting code. Copy it with
``ice_response_model.py``.

The model (relative to the same detector with no ice)::

    P(lambda, t) = S(d) / S(0)
    S(d) = (1 - rho^2) a / (1 + |b|^2 rho^2 a^2 + 2 |b| rho a cos G)
    r = rho e^{i phi}                 detector reflectance (modal: mean + amplitudes @ modes)
    G = phi + 2 k d + arg b           b: vacuum-to-ice Fresnel coefficient
    a = exp(-2 k_a d)                 ice absorption
    k = 2 pi n(lambda) s / lambda,  k_a = 2 pi kappa(lambda) s / lambda
    s = sqrt(1 - n_ref^2 (1 - cos_theta^2) / n(lambda)^2) / cos_theta   (chromatic Snell)
    d = cos_theta (d_off[episode(t)] + a_g C(t))
    C(t) = sum over the rate blocks b of episode(t): mult_b clip(min(t, t1_b) - t0_b, 0)

with each episode's last rate block extended beyond its end at its fitted rate. An
achromatic level that switches on at fixed times (the per-decon gray) multiplies P:
``step_factor``.
"""
from __future__ import annotations

import datetime as _dt

import numpy as np

CORE_VERSION = "2"                   # 2: no_ice_transmission (2026-10-23)
SCA_PIX = 4096                       # detector pixels per SCA side


# --------------------------------------------------------------------------- #
# the film
# --------------------------------------------------------------------------- #
def film_response(r, k, ka, b, d):
    """``S(d) / S(0)`` for complex ``r`` (n, L), wavenumbers ``k, ka`` and Fresnel
    coefficient ``b`` (n, L) or (L,), and thickness ``d`` (n, T) in nm (including the
    cos_theta factor): ``(n, L, T)``."""
    rho, phi = np.abs(r)[..., None], np.angle(r)[..., None]
    c = np.abs(b)[..., None]
    psi = np.angle(b)[..., None]
    k = np.asarray(k)[..., None]
    ka = np.asarray(ka)[..., None]
    dd = d[:, None, :]
    a = np.exp(-2.0 * ka * dd)
    G = phi + 2.0 * k * dd + psi
    s_d = (1.0 - rho ** 2) * a / (1.0 + c ** 2 * rho ** 2 * a ** 2 + 2.0 * c * rho * a * np.cos(G))
    s_0 = (1.0 - rho ** 2) / (1.0 + c ** 2 * rho ** 2 + 2.0 * c * rho * np.cos(phi + psi))
    return s_d / s_0


def no_ice_transmission(r, b):
    """``S(0)``, the transmission into the detector without ice, ``(n, L)``, for complex
    ``r`` (n, L) and Fresnel coefficient ``b`` (n, L) or (L,): the denominator of
    :func:`film_response`. It carries the detector's reflectance ripple, so it is the
    per-position weight that makes a band average the ratio of detected signals."""
    rho, phi = np.abs(r), np.angle(r)
    c, psi = np.abs(b), np.angle(b)
    return (1.0 - rho ** 2) / (1.0 + c ** 2 * rho ** 2 + 2.0 * c * rho * np.cos(phi + psi))


def optics_at(lam_grid, n, kappa, b, lam_nm):
    """The ice index ``n``, extinction ``kappa`` and Fresnel coefficient ``b`` (all on
    ``lam_grid``), linearly interpolated to ``lam_nm``."""
    n_l = np.interp(lam_nm, lam_grid, n)
    kap = np.interp(lam_nm, lam_grid, kappa)
    b_l = np.interp(lam_nm, lam_grid, b.real) + 1j * np.interp(lam_nm, lam_grid, b.imag)
    return n_l, kap, b_l


def wavenumbers(lam_nm, n_l, kappa_l, cos_theta, n_snell_ref, chromatic_snell):
    """``(k, k_a)`` (n_sp, n_lam) in rad/nm, with the chromatic Snell factor."""
    ct = np.asarray(cos_theta, float)[:, None]
    ks = (np.sqrt(1.0 - n_snell_ref ** 2 * (1.0 - ct ** 2) / n_l[None, :] ** 2) / ct
          if chromatic_snell else np.ones((ct.shape[0], 1)))
    return 2 * np.pi * n_l / lam_nm * ks, 2 * np.pi * kappa_l / lam_nm * ks


def relative_response(r, lam_nm, d_phys, cos_theta, lam_grid, n, kappa, b, n_snell_ref,
                      chromatic_snell):
    """The ice film's relative response ``(n_sp, n_lam, n_t)`` for reflectance ``r``
    (n_sp, n_lam) at ``lam_nm`` and physical thickness ``d_phys`` (n_sp, n_t) in nm."""
    n_l, kap, b_l = optics_at(lam_grid, n, kappa, b, lam_nm)
    k, ka = wavenumbers(lam_nm, n_l, kap, cos_theta, n_snell_ref, chromatic_snell)
    d_eff = d_phys * np.asarray(cos_theta, float)[:, None]
    return film_response(r, k, ka, np.broadcast_to(b_l, r.shape), d_eff)


# --------------------------------------------------------------------------- #
# the detector reflectance
# --------------------------------------------------------------------------- #
def basis_at(lam_grid, mean, modes, lam_nm):
    """``(mean, modes)`` at ``lam_nm``, cubic-spline interpolated from ``lam_grid``.

    The mean and the modes are splined, not the product (it is linear in them). Linear
    interpolation of a 1 nm grid errs by ~2e-4 in r at the blue end, where the fastest
    ripples turn ~0.1 rad per nm (~50 ppm in the response); the cubic's error is ~1e-7.
    """
    from scipy.interpolate import CubicSpline
    lam_nm = np.atleast_1d(np.asarray(lam_nm, float))
    if lam_nm.min() < lam_grid[0] or lam_nm.max() > lam_grid[-1]:
        raise ValueError(f"wavelengths outside the model grid {lam_grid[0]:.0f}-"
                         f"{lam_grid[-1]:.0f} nm")
    cs = CubicSpline(lam_grid, np.vstack([mean[None, :], modes]), axis=1)
    out = cs(lam_nm)
    return out[0], out[1:]


def reflectance(amp, lam_grid, mean, modes, lam_nm=None):
    """Complex ``r = mean + amp @ modes`` (n_sp, n_lam): on the grid when ``lam_nm`` is
    None, else spline-interpolated (:func:`basis_at`)."""
    if lam_nm is None:
        return mean[None, :] + amp @ modes
    mu, V = basis_at(lam_grid, mean, modes, lam_nm)
    return mu[None, :] + amp @ V


# --------------------------------------------------------------------------- #
# time and deposition
# --------------------------------------------------------------------------- #
def _datetime64_utc(v):
    """One time as numpy datetime64 (UTC, naive): ISO strings (``Z`` or ``+00:00``),
    ``datetime`` (aware ones converted to UTC), ``numpy.datetime64``."""
    if isinstance(v, _dt.datetime):
        if v.tzinfo is not None:
            v = v.astimezone(_dt.timezone.utc).replace(tzinfo=None)
        return np.datetime64(v)
    if isinstance(v, np.datetime64):
        return v
    s = str(v).strip()
    if s.endswith("Z"):
        s = s[:-1]
    if len(s) > 6 and s[-6] in "+-" and s[-3] == ":":      # a UTC offset, e.g. +00:00
        sign = 1 if s[-6] == "+" else -1
        off = sign * (int(s[-5:-3]) * 60 + int(s[-2:]))      # minutes east of UTC
        return np.datetime64(s[:-6]) - np.timedelta64(off, "m")
    return np.datetime64(s)


def hours_since(t, t0_utc):
    """Hours since ``t0_utc`` (an ISO string) of ``t``: datetimes, ISO strings or numpy
    datetime64 (numbers are taken as hours already and passed through)."""
    t = np.asarray(t)
    if t.dtype.kind in "fiu":
        return t.astype(float)
    t0 = _datetime64_utc(t0_utc)
    tt = np.array([_datetime64_utc(v) for v in t.ravel()], dtype="datetime64[us]")
    return ((tt - t0) / np.timedelta64(1, "s")).astype(float).reshape(t.shape) / 3600.0


def cumulative(t, t_epoch, episode, blocks, mult, tau, offset_episodes):
    """``(episode, C)`` at hours ``t``: the episode of the last epoch at or before t,
    and the rate-weighted cumulative time C (hours) since that episode's start; each
    episode's last block extends beyond its end. Tied offsets add ``tau``."""
    t = np.asarray(t, float)
    k = np.clip(np.searchsorted(t_epoch, t, side="right") - 1, 0, t_epoch.size - 1)
    ep = episode[k]
    last = {}
    for i, (e, _, _) in enumerate(blocks):
        last[int(e)] = i
    C = np.zeros(t.size)
    for i, (e, a, b) in enumerate(blocks):
        b = np.inf if last[int(e)] == i else b
        C += np.where(ep == int(e), mult[i] * np.clip(np.minimum(t, b) - a, 0.0, None), 0.0)
    for j, e in enumerate(offset_episodes):              # tied offsets: d_off = tau a
        C += np.where(ep == int(e), tau[j], 0.0)
    return ep, C


def modelled(t, t_epoch, episode):
    """True where the deposition model describes hours ``t``: from the first epoch on,
    outside the decon warm-ups between episodes (where the ice is removed). After the
    last epoch the last rate block is extended at its rate."""
    t = np.atleast_1d(np.asarray(t, float))
    ok = t >= t_epoch[0]
    for e in np.unique(episode)[1:]:
        t_end = t_epoch[episode == e - 1].max()
        t_start = t_epoch[episode == e].min()
        ok &= ~((t > t_end) & (t < t_start))
    return ok


def thickness(t, log_a, d_off, t_epoch, episode, blocks, mult, tau, offset_episodes):
    """Physical ice thickness (nm, without cos_theta), ``(n_sp, n_t)``, for the rate
    amplitudes ``log_a`` (n_sp,; ln nm/hour of the pinned block) and the per-episode
    offsets ``d_off`` (n_sp, n_episode, or n_sp x 0 when tied)."""
    ep, C = cumulative(np.atleast_1d(t), t_epoch, episode, blocks, mult, tau,
                       offset_episodes)
    a = np.exp(np.asarray(log_a, float))[:, None]
    off = d_off[:, ep] if d_off.shape[1] else 0.0
    return off + a * C[None, :]


def block_at(t, t_epoch, episode, blocks):
    """The rate block in force at hours ``t`` (an episode's last block beyond its
    end), and -1 outside the modelled times."""
    t = np.atleast_1d(np.asarray(t, float))
    k = np.clip(np.searchsorted(t_epoch, t, side="right") - 1, 0, t_epoch.size - 1)
    ep = episode[k]
    out = np.full(t.size, -1)
    for i, (e, a, b) in enumerate(blocks):
        last = i == max(j for j, bl in enumerate(blocks) if bl[0] == e)
        sel = (ep == int(e)) & (t >= a) & ((t < b) | last)
        out[sel & (out < 0)] = i
    out[~modelled(t, t_epoch, episode)] = -1
    return out


def step_factor(t, start_hours, levels):
    """``1 + levels @ [t >= start]``: achromatic levels (n_sp, n_step) that switch on
    at ``start_hours`` (n_step,), as ``(n_sp, n_t)``. The per-decon gray is one."""
    t = np.atleast_1d(np.asarray(t, float))
    D = (t[:, None] >= np.asarray(start_hours, float)[None, :]).astype(float)
    return 1.0 + np.asarray(levels, float) @ D.T


# --------------------------------------------------------------------------- #
# geometry
# --------------------------------------------------------------------------- #
def superpixel_index(sca, x, y, n_bin, sca_of, row_of, col_of):
    """Superpixel index of full-SCA pixel ``(x, y)`` (0..4095; x = column, y = row) on
    SCA ``sca`` (1..18), for a layout that is SCA-major then row-major (checked against
    the stored ``sca_of``, ``row_of``, ``col_of``). Arrays broadcast together."""
    sca, x, y = np.broadcast_arrays(np.atleast_1d(sca), np.atleast_1d(x), np.atleast_1d(y))
    if np.any((sca < 1) | (sca > 18)):
        raise ValueError("SCA numbers are 1..18")
    if np.any((x < 0) | (x >= SCA_PIX) | (y < 0) | (y >= SCA_PIX)):
        raise ValueError(f"pixel coordinates are 0..{SCA_PIX - 1}")
    px = SCA_PIX // int(n_bin)
    r, c = np.asarray(y, int) // px, np.asarray(x, int) // px
    idx = (np.asarray(sca, int) - 1) * n_bin * n_bin + r * n_bin + c
    if not (np.all(sca_of[idx] == sca) and np.all(row_of[idx] == r)
            and np.all(col_of[idx] == c)):
        raise ValueError("superpixel layout is not the expected SCA-major, row-major order")
    return idx
