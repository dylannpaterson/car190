# Orientation calibration

DQ masking: on

## Test C -- romancal blocks vs existing h5

Staged with `ORIENT=identity`; the transform column is applied *on top of* that, so `identity` means 'as staged'. Compose the two to get the absolute convention.

| extra transform | LED | median rho | min rho | positive | rot180 SCAs | rot0 SCAs |
|---|---|---|---|---|---|---|
| identity | LED1 | +0.9457 | +0.8079 | 17/17 | +0.9507 | +0.9251 |
| fliplr | LED1 | +0.4950 | -0.7095 | 12/17 | +0.3516 | +0.6038 |
| flipud | LED1 | -0.2470 | -0.8987 | 6/17 | -0.1895 | -0.5272 |
| rot180 | LED1 | -0.6697 | -0.9070 | 0/17 | -0.7576 | -0.5582 |
| identity | LED6 | +0.9217 | +0.7247 | 17/17 | +0.9229 | +0.9133 |
| fliplr | LED6 | +0.5349 | -0.3376 | 15/17 | +0.6721 | +0.1003 |
| flipud | LED6 | -0.0447 | -0.6498 | 7/17 | -0.2212 | +0.1904 |
| rot180 | LED6 | -0.4355 | -0.7400 | 3/17 | -0.4700 | -0.3905 |

Best extra transform: **identity** (median rho +0.9457, 17/17 SCAs positive)

A correct convention is positive for *both* rotation classes at once. Any transform that is strong for one class and negative for the other is mirroring half the focal plane.

## Test D -- bad-pixel footprints (Jaccard overlap)

Transform applied to the *romancal* mask to match quicklook. `identity` means the two products share a convention.

| SCA | rot | n flagged QL | n flagged romancal | identity | fliplr | flipud | rot180 | best | margin |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 180 | 437685 | 819207 | 0.0541 | 0.0183 | 0.0158 | 0.0141 | identity | 3.0x |
| 2 | 180 | 103924 | 62110 | 0.1649 | 0.0026 | 0.0026 | 0.0047 | identity | 35.4x |
| 3 | 0 | 154588 | 117375 | 0.1507 | 0.0153 | 0.0036 | 0.0058 | identity | 9.9x |
| 4 | 180 | 101382 | 128747 | 0.1449 | 0.0032 | 0.0036 | 0.0048 | identity | 30.3x |
| 5 | 180 | 93641 | 99820 | 0.2413 | 0.0027 | 0.0678 | 0.0048 | identity | 3.6x |
| 6 | 0 | 84212 | 117784 | 0.1319 | 0.0047 | 0.0029 | 0.0048 | identity | 27.6x |
| 7 | 180 | 201484 | 237441 | 0.3785 | 0.0069 | 0.0072 | 0.0075 | identity | 50.2x |
| 9 | 0 | 73360 | 54411 | 0.2872 | 0.0020 | 0.0021 | 0.0046 | identity | 62.7x |
| 10 | 180 | 284405 | 179699 | 0.0521 | 0.0065 | 0.0061 | 0.0065 | identity | 8.0x |
| 11 | 180 | 101812 | 108608 | 0.1304 | 0.0030 | 0.0031 | 0.0043 | identity | 30.3x |
| 12 | 0 | 52305 | 46730 | 0.0714 | 0.0021 | 0.0048 | 0.0049 | identity | 14.7x |
| 13 | 180 | 330311 | 193162 | 0.0687 | 0.0061 | 0.0073 | 0.0070 | identity | 9.4x |
| 14 | 180 | 99600 | 81584 | 0.2465 | 0.0054 | 0.0066 | 0.0059 | identity | 37.3x |
| 15 | 0 | 84683 | 48314 | 0.0864 | 0.0021 | 0.0022 | 0.0045 | identity | 19.3x |
| 16 | 180 | 91637 | 45604 | 0.0792 | 0.0019 | 0.0019 | 0.0042 | identity | 18.9x |
| 17 | 180 | 64741 | 49206 | 0.1291 | 0.0016 | 0.0017 | 0.0043 | identity | 30.0x |
| 18 | 0 | 90453 | 583340 | 0.0672 | 0.0031 | 0.0040 | 0.0045 | identity | 14.8x |

Verdict: **identity** for 17/17 SCAs ({'identity': 17})

