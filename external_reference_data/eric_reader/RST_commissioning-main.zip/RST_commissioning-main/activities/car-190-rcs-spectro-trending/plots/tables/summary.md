# Three-way comparison of RCS trend cubes

All three cubes were packaged by the same unmodified
`compile_rcs_trend.py`; differences below are properties of the
input per-SCA data, not of the packaging code.

## Cases

- `1_original` (loaded): `/mnt/roman-science-east-2/eswitzer/RCS_trend/TVAC_HOB_OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA.h5`
- `2_romancal_l2` (loaded): `/mnt/roman-science-east-2/eswitzer/RCS_trend/car190_derived/scipa/TVAC_HOB_OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA.h5`
- `3_ql_slope` (loaded): `/mnt/roman-science-east-2/eswitzer/RCS_trend/car190_derived/ql/TVAC_HOB_OTP00775_RCSEChrmStbA_SCIPAc_R17_MCEA.h5`

## Headline: the case-to-case difference is achromatic

Every pair's per-pixel ratio map is essentially identical at all six wavelengths: correlating each LED's ratio map against LED1's gives rho >= 0.9982 for every pair and every LED. So each pair differs by a *static, achromatic multiplicative field* rather than by anything wavelength-dependent.

That is the result that matters for CAR-190 chromatic trending: the choice of input calibration state rescales the mosaics but does not distort the chromatic trend, so the three cases are interchangeable for trending up to one overall constant per pair.

| pair                        | led   |   wavelength_nm |   corr_with_LED1 |   median |      p16 |      p84 |   frac_spread |
|:----------------------------|:------|----------------:|-----------------:|---------:|---------:|---------:|--------------:|
| 2_romancal_l2_vs_1_original | LED1  |             625 |         1        | 0.590112 | 0.557252 | 0.643502 |    0.146159   |
| 2_romancal_l2_vs_1_original | LED2  |             880 |         0.999531 | 0.589368 | 0.556421 | 0.64207  |    0.145325   |
| 2_romancal_l2_vs_1_original | LED3  |            1070 |         0.999158 | 0.590584 | 0.557749 | 0.643199 |    0.144687   |
| 2_romancal_l2_vs_1_original | LED4  |            1300 |         0.998623 | 0.592186 | 0.55971  | 0.64508  |    0.144161   |
| 2_romancal_l2_vs_1_original | LED5  |            1550 |         0.998762 | 0.591213 | 0.558819 | 0.646642 |    0.148547   |
| 2_romancal_l2_vs_1_original | LED6  |            1750 |         0.998989 | 0.591918 | 0.559066 | 0.644735 |    0.144731   |
| 3_ql_slope_vs_1_original    | LED1  |             625 |         1        | 1.00355  | 1.00139  | 1.00613  |    0.00472356 |
| 3_ql_slope_vs_1_original    | LED2  |             880 |         0.998835 | 1.0035   | 1.00135  | 1.0061   |    0.00473422 |
| 3_ql_slope_vs_1_original    | LED3  |            1070 |         0.998401 | 1.00361  | 1.00147  | 1.00621  |    0.00471559 |
| 3_ql_slope_vs_1_original    | LED4  |            1300 |         0.998205 | 1.00379  | 1.00166  | 1.0064   |    0.00472415 |
| 3_ql_slope_vs_1_original    | LED5  |            1550 |         0.998198 | 1.00382  | 1.0017   | 1.0064   |    0.00467866 |
| 3_ql_slope_vs_1_original    | LED6  |            1750 |         0.998225 | 1.00376  | 1.00166  | 1.00631  |    0.00463778 |
| 2_romancal_l2_vs_3_ql_slope | LED1  |             625 |         1        | 0.587897 | 0.554253 | 0.63898  |    0.144118   |
| 2_romancal_l2_vs_3_ql_slope | LED2  |             880 |         0.999742 | 0.587193 | 0.553445 | 0.637811 |    0.143677   |
| 2_romancal_l2_vs_3_ql_slope | LED3  |            1070 |         0.999405 | 0.588372 | 0.554785 | 0.638951 |    0.143049   |
| 2_romancal_l2_vs_3_ql_slope | LED4  |            1300 |         0.998866 | 0.589913 | 0.55663  | 0.640839 |    0.142747   |
| 2_romancal_l2_vs_3_ql_slope | LED5  |            1550 |         0.999012 | 0.588913 | 0.555616 | 0.642047 |    0.146765   |
| 2_romancal_l2_vs_3_ql_slope | LED6  |            1750 |         0.999253 | 0.589647 | 0.555976 | 0.640445 |    0.143252   |


## Activity / LED / wavelength map

`led_arrays/LED<n>` is an **activity index**, not a hardware LED id.

| h5_key   |   activity_number |   wavelength_nm | hardware_bank2_led   |    scipa_visit_id |   scipa_n_sca | scipa_start_time        | scipa_wlen_source   |       ql_visit_id |   ql_n_sca | ql_start_time              | ql_wlen_source   |
|:---------|------------------:|----------------:|:---------------------|------------------:|--------------:|:------------------------|:--------------------|------------------:|-----------:|:---------------------------|:-----------------|
| LED1     |                 2 |             625 | LED6                 | 77501056054002001 |            17 | 2025-10-03T06:09:12.859 | file                | 77501056054002001 |         17 | 2025-10-03 06:09:13.068000 | activity_map     |
| LED2     |                 3 |             880 | LED1                 | 77501056054003001 |            17 | 2025-10-03T06:10:48.156 | file                | 77501056054003001 |         17 | 2025-10-03 06:10:51.452000 | activity_map     |
| LED3     |                 4 |            1070 | LED2                 | 77501056054004001 |            17 | 2025-10-03T06:12:19.041 | file                | 77501056054004001 |         17 | 2025-10-03 06:12:21.026000 | activity_map     |
| LED4     |                 5 |            1300 | LED3                 | 77501056054005001 |            17 | 2025-10-03T06:15:43.537 | file                | 77501056054005001 |         17 | 2025-10-03 06:15:45.185000 | activity_map     |
| LED5     |                 6 |            1550 | LED4                 | 77501056054006001 |            16 | 2025-10-03T06:18:56.819 | file                | 77501056054006001 |         17 | 2025-10-03 06:18:59.353000 | activity_map     |
| LED6     |                 7 |            1750 | LED5                 | 77501056054007001 |            17 | 2025-10-03T06:21:48.754 | file                | 77501056054007001 |         17 | 2025-10-03 06:21:50.372000 | activity_map     |

## Mosaic statistics

| case          | led   |   wavelength_nm |   n_finite |   nan_frac |   median |     mad |       p2 |     p98 |
|:--------------|:------|----------------:|-----------:|-----------:|---------:|--------:|---------:|--------:|
| 1_original    | LED1  |             625 |     717295 |   0.430718 | 1462.27  | 78.5191 | 1155.61  | 1619.41 |
| 1_original    | LED2  |             880 |     717295 |   0.430718 | 1420.48  | 76.2821 | 1196.25  | 1540.68 |
| 1_original    | LED3  |            1070 |     717295 |   0.430718 | 1506.3   | 89.7583 | 1283.55  | 1631.52 |
| 1_original    | LED4  |            1300 |     717295 |   0.430718 | 1623.06  | 90.0908 | 1383.42  | 1759.48 |
| 1_original    | LED5  |            1550 |     717295 |   0.430718 | 1644.6   | 90.7196 | 1407.11  | 1776.44 |
| 1_original    | LED6  |            1750 |     717295 |   0.430718 | 1603.15  | 87.3041 | 1373     | 1727.42 |
| 2_romancal_l2 | LED1  |             625 |     714855 |   0.432655 |  866.102 | 48.2349 |  748.842 | 1064.9  |
| 2_romancal_l2 | LED2  |             880 |     714857 |   0.432653 |  839.357 | 40.727  |  762.142 | 1065.12 |
| 2_romancal_l2 | LED3  |            1070 |     714857 |   0.432653 |  894.105 | 42.115  |  797.222 | 1103.05 |
| 2_romancal_l2 | LED4  |            1300 |     714857 |   0.432653 |  964.02  | 41.9059 |  855.857 | 1184.52 |
| 2_romancal_l2 | LED5  |            1550 |     672861 |   0.465983 |  976.396 | 42.1383 |  873.207 | 1199.95 |
| 2_romancal_l2 | LED6  |            1750 |     714857 |   0.432653 |  953.549 | 43.341  |  854.148 | 1167.71 |
| 3_ql_slope    | LED1  |             625 |     715384 |   0.432235 | 1470.84  | 76.071  | 1197.41  | 1626.85 |
| 3_ql_slope    | LED2  |             880 |     715384 |   0.432235 | 1428.98  | 74.9476 | 1270.33  | 1547.57 |
| 3_ql_slope    | LED3  |            1070 |     715384 |   0.432235 | 1515.54  | 88.113  | 1359.71  | 1639.39 |
| 3_ql_slope    | LED4  |            1300 |     715384 |   0.432235 | 1633.32  | 87.2518 | 1470.6   | 1767.71 |
| 3_ql_slope    | LED5  |            1550 |     715384 |   0.432235 | 1654.52  | 89.0328 | 1495.56  | 1784.77 |
| 3_ql_slope    | LED6  |            1750 |     715384 |   0.432235 | 1613.03  | 85.496  | 1454.01  | 1735.65 |

## Pairwise comparison (common pixels only)

| pair                        | led   |   n_common |   n_only_a |   n_only_b |   median_diff |   mad_diff |   median_ratio |   ratio_p16 |   ratio_p84 |      corr |   mad_norm_diff |
|:----------------------------|:------|-----------:|-----------:|-----------:|--------------:|-----------:|---------------:|------------:|------------:|----------:|----------------:|
| 2_romancal_l2_vs_1_original | LED1  |     714855 |          0 |       2440 |    -604.706   |   78.2297  |       0.590112 |    0.557252 |    0.643502 | 0.370468  |      0.0637782  |
| 2_romancal_l2_vs_1_original | LED2  |     714857 |          0 |       2438 |    -584.66    |   86.4659  |       0.589368 |    0.556421 |    0.642071 | 0.177848  |      0.0627533  |
| 2_romancal_l2_vs_1_original | LED3  |     714857 |          0 |       2438 |    -617.462   |   84.289   |       0.590584 |    0.557749 |    0.643199 | 0.0965776 |      0.063072   |
| 2_romancal_l2_vs_1_original | LED4  |     714857 |          0 |       2438 |    -660.254   |   86.7153  |       0.592187 |    0.55971  |    0.64508  | 0.127527  |      0.0627141  |
| 2_romancal_l2_vs_1_original | LED5  |     672861 |          0 |      44434 |    -673.18    |   96.8298  |       0.591213 |    0.558819 |    0.646642 | 0.0587118 |      0.0663141  |
| 2_romancal_l2_vs_1_original | LED6  |     714857 |          0 |       2438 |    -655.552   |   87.5132  |       0.591918 |    0.559066 |    0.644735 | 0.0541341 |      0.0626084  |
| 3_ql_slope_vs_1_original    | LED1  |     715384 |          0 |       1911 |       5.1893  |    3.29475 |       1.00355  |    1.00139  |    1.00613  | 0.922337  |      0.00227307 |
| 3_ql_slope_vs_1_original    | LED2  |     715384 |          0 |       1911 |       4.97188 |    3.23416 |       1.0035   |    1.00135  |    1.0061   | 0.873509  |      0.00226478 |
| 3_ql_slope_vs_1_original    | LED3  |     715384 |          0 |       1911 |       5.43098 |    3.40514 |       1.00361  |    1.00147  |    1.00621  | 0.869221  |      0.00225131 |
| 3_ql_slope_vs_1_original    | LED4  |     715384 |          0 |       1911 |       6.13401 |    3.69105 |       1.00379  |    1.00166  |    1.0064   | 0.866059  |      0.00224648 |
| 3_ql_slope_vs_1_original    | LED5  |     715384 |          0 |       1911 |       6.28031 |    3.69751 |       1.00382  |    1.0017   |    1.0064   | 0.855941  |      0.00222616 |
| 3_ql_slope_vs_1_original    | LED6  |     715384 |          0 |       1911 |       6.0106  |    3.56377 |       1.00376  |    1.00166  |    1.00631  | 0.855716  |      0.00221541 |
| 2_romancal_l2_vs_3_ql_slope | LED1  |     714855 |          0 |        529 |    -611.837   |   75.8193  |       0.587897 |    0.554253 |    0.63898  | 0.388776  |      0.0623051  |
| 2_romancal_l2_vs_3_ql_slope | LED2  |     714857 |          0 |        527 |    -590.858   |   85.8226  |       0.587193 |    0.553445 |    0.637811 | 0.206575  |      0.0612034  |
| 2_romancal_l2_vs_3_ql_slope | LED3  |     714857 |          0 |        527 |    -623.819   |   83.1271  |       0.588372 |    0.554785 |    0.638951 | 0.111099  |      0.0617083  |
| 2_romancal_l2_vs_3_ql_slope | LED4  |     714857 |          0 |        527 |    -667.178   |   85.3824  |       0.589913 |    0.55663  |    0.640839 | 0.139177  |      0.0613647  |
| 2_romancal_l2_vs_3_ql_slope | LED5  |     672861 |          0 |      42523 |    -680.546   |   96.2459  |       0.588913 |    0.555616 |    0.642047 | 0.0608107 |      0.0650817  |
| 2_romancal_l2_vs_3_ql_slope | LED6  |     714857 |          0 |        527 |    -662.493   |   85.9988  |       0.589647 |    0.555976 |    0.640445 | 0.0581145 |      0.0612615  |

## Non-image (`dictionary/`) fields

| field               | 1_original                                                                    | 2_romancal_l2                                                                 | 2_romancal_l2_matches   |   2_romancal_l2_maxabsdiff | 3_ql_slope                                                                    | 3_ql_slope_matches   |   3_ql_slope_maxabsdiff |
|:--------------------|:------------------------------------------------------------------------------|:------------------------------------------------------------------------------|:------------------------|---------------------------:|:------------------------------------------------------------------------------|:---------------------|------------------------:|
| COBA_temp           | 158.927505                                                                    | 158.927505                                                                    | True                    |                          0 | 158.927505                                                                    | True                 |                       0 |
| RCS_Sphere_temp     | 200.03765499999997                                                            | 200.03765499999997                                                            | True                    |                          0 | 200.03765499999997                                                            | True                 |                       0 |
| RCS_Board_temp      | 248.11900599999998                                                            | 248.11900599999998                                                            | True                    |                          0 | 248.11900599999998                                                            | True                 |                       0 |
| MPA_A_temp          | 92.631693                                                                     | 92.631693                                                                     | True                    |                          0 | 92.631693                                                                     | True                 |                       0 |
| MPA_B_temp          | 89.487876                                                                     | 89.487876                                                                     | True                    |                          0 | 89.487876                                                                     | True                 |                       0 |
| ACM_LVDT            | -3076.000000 -3345.000000 -3100.000000 -2930.000000 -2868.000000 -2974.000000 | -3076.000000 -3345.000000 -3100.000000 -2930.000000 -2868.000000 -2974.000000 | True                    |                          0 | -3076.000000 -3345.000000 -3100.000000 -2930.000000 -2868.000000 -2974.000000 | True                 |                       0 |
| RCS_forward_voltage | 0.605133 1.954314 1.438386 1.477151 0.984790 0.932527 0.868458                | 0.605133 1.954314 1.438386 1.477151 0.984790 0.932527 0.868458                | True                    |                          0 | 0.605133 1.954314 1.438386 1.477151 0.984790 0.932527 0.868458                | True                 |                       0 |
| RCS_photodiode      | 0.000000 0.223637 0.280522 0.262450 0.267111 0.264849 0.251648                | 0.000000 0.223637 0.280522 0.262450 0.267111 0.264849 0.251648                | True                    |                          0 | 0.000000 0.223637 0.280522 0.262450 0.267111 0.264849 0.251648                | True                 |                       0 |
| timestamp           | 2025-10-03T06:11:07.026Z                                                      | 2025-10-03T06:12:19.041                                                       | False                   |                        nan | 2025-10-03 06:12:21.026000                                                    | False                |                     nan |

## Footprint differences

Detected from the pixels themselves:

| case          | led   |   sca |   finite_frac |
|:--------------|:------|------:|--------------:|
| 2_romancal_l2 | LED5  |     5 |             0 |

WFI08 is absent from every activity of both datasets and is excluded from all per-SCA statistics.

## Extreme superpixels

No superpixel in any case exceeds 10x its cube median.
## Caveats

- Per-SCA *correlations* between case 3 (QL) and the other two are erratic in sign even though the cases agree well in level. That is expected rather than alarming: within a single SCA the SRCS illumination is nearly flat, so its own dynamic range is comparable to the few-percent static ratio pattern, and the correlation ends up measuring that pattern with an arbitrary sign. Whole-mosaic and per-SCA *medians* are the meaningful comparisons here; the correlation column is not.
- The whole-mosaic `corr` column is low (0.004 to 0.66) for every pair, and that is *not* evidence of disagreement. The focal plane's own illumination varies by only about 6-8% rms about its median, while the case-to-case ratio field varies by 10-12% rms, so a Pearson correlation between two cubes is dominated by the ratio field rather than by the signal they share. It falls further toward long wavelengths because the illumination flattens there. The ratio-map staticity above is the measurement that actually addresses agreement.
- Orientation was measured, not assumed, and the answer is that no flip is applied (`identity`), which is *not* the `mosaic_plot_FPS.placeImages` convention. See `plots/orientation_calibration.md`.
- `timestamp` is not reproducible from per-SCA metadata: the original holds a telemetry sample time matching none of the seven activity start times.
- Case 2 (romancal L2) has dark, linearity and ramp-fit corrections applied; case 3 (QL slope) has none. An overall scale difference between them is expected, and the measured factor is a result rather than an error.
- romancal activity 6 (LED5, 1550 nm) genuinely lacks WFI05. Native footprints are preserved; differences there are computed on the reduced common footprint, with excluded pixel counts in the pairwise table.
- Per-SCA statistics inset 2 superpixels from each block edge, because the r=4 block bounds are not multiples of the rebin factor 5 and edge superpixels mix detectors.

