# CAR-174: Dark attenuation

## Purpose

Measure attenuation of the dark element

## Contributors

- Name / team / contact

## Status

Choose one:

- Planned 

## Main files

## Input data

## How to run

## Outputs

## Notes and caveats

# TODO
* Fix the csv digest filename for the OTP directories
* Consolidate the OTP pull; command-line script?
* What directory to work in, where to find data
